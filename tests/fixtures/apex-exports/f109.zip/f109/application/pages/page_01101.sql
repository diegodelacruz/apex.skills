prompt --application/pages/page_01101
begin
--   Manifest
--     PAGE: 01101
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>109
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_page.create_page(
 p_id=>1101
,p_name=>'Nuevo Periodo'
,p_page_mode=>'MODAL'
,p_step_title=>'Nuevo Periodo'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'02'
,p_created_on=>wwv_flow_imp.dz('20230705164635Z')
,p_last_updated_on=>wwv_flow_imp.dz('20241231163952Z')
,p_last_updated_by=>'CVACA'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(350320656866592282)
,p_plug_name=>'Nuevo Periodo'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(37786313898106507)
,p_plug_display_sequence=>10
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'TEXT',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(350321319172592282)
,p_plug_name=>'Buttons'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(37787379178106507)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_03'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'TEXT',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(350321753913592284)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(350321319172592282)
,p_button_name=>'CANCEL'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860181880106559)
,p_button_image_alt=>'Cancel'
,p_button_position=>'CLOSE'
,p_button_alignment=>'RIGHT'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(350321259607592282)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(350321319172592282)
,p_button_name=>'DELETE'
,p_button_action=>'REDIRECT_URL'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860181880106559)
,p_button_image_alt=>'Delete'
,p_button_position=>'DELETE'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'javascript:apex.confirm(htmldb_delete_message,''DELETE'');'
,p_button_execute_validations=>'N'
,p_button_condition=>'P1101_ID'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_database_action=>'DELETE'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(350321195810592282)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(350321319172592282)
,p_button_name=>'SAVE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860181880106559)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Apply Changes'
,p_button_position=>'NEXT'
,p_button_alignment=>'RIGHT'
,p_button_condition=>'P1101_ID'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_database_action=>'UPDATE'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(350321056664592282)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(350321319172592282)
,p_button_name=>'CREATE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860181880106559)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Create'
,p_button_position=>'NEXT'
,p_button_alignment=>'RIGHT'
,p_button_condition=>'P1101_ID'
,p_button_condition_type=>'ITEM_IS_NULL'
,p_database_action=>'INSERT'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(350324156239592329)
,p_name=>'P1101_ID'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(350320656866592282)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Id'
,p_source=>'ID'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_label_alignment=>'RIGHT'
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_protection_level=>'S'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(350324537479592348)
,p_name=>'P1101_ANNO'
,p_is_required=>true
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(350320656866592282)
,p_use_cache_before_default=>'NO'
,p_prompt=>unistr('A\00F1o')
,p_source=>'ANNO'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'LOV_ANNOS'
,p_lov=>'select to_char(sysdate,''yyyy'') + (level-3) d,to_char(sysdate,''yyyy'') + (level-3) r from dual connect by level <= 4'
,p_lov_display_null=>'YES'
,p_lov_null_text=>'Seleccione'
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'NONE'
,p_updated_on=>wwv_flow_imp.dz('20241231163952Z')
,p_updated_by=>'CVACA'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(350324929612592353)
,p_name=>'P1101_MES'
,p_is_required=>true
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(350320656866592282)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Mes'
,p_source=>'MES'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'LOV_MESES'
,p_lov=>'select to_char(to_date(level,''MM''),''Month'') d, level r from dual connect by level <= 12'
,p_lov_display_null=>'YES'
,p_lov_null_text=>'Seleccione'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(350325353317592353)
,p_name=>'P1101_NUMEROVERSION'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(350320656866592282)
,p_use_cache_before_default=>'NO'
,p_source=>'NUMEROVERSION'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(350325767075592354)
,p_name=>'P1101_CODIGOESTADO'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(350320656866592282)
,p_use_cache_before_default=>'NO'
,p_source=>'CODIGOESTADO'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(350326198129592354)
,p_name=>'P1101_ULTIMOUSUARIO'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(350320656866592282)
,p_use_cache_before_default=>'NO'
,p_source=>'ULTIMOUSUARIO'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(350326502352592354)
,p_name=>'P1101_USERCREA'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(350320656866592282)
,p_use_cache_before_default=>'NO'
,p_source=>'USERCREA'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(350326989864592354)
,p_name=>'P1101_FECHCREA'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(350320656866592282)
,p_use_cache_before_default=>'NO'
,p_source=>'FECHCREA'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(350327748880592356)
,p_name=>'P1101_USERMODI'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(350320656866592282)
,p_use_cache_before_default=>'NO'
,p_source=>'USERMODI'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(350328164182592356)
,p_name=>'P1101_FECHMODI'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_imp.id(350320656866592282)
,p_use_cache_before_default=>'NO'
,p_source=>'FECHMODI'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(351223161641751301)
,p_name=>'P1101_COMPANIA'
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_imp.id(350320656866592282)
,p_use_cache_before_default=>'NO'
,p_item_default=>'to_char(:g_compania)'
,p_item_default_type=>'EXPRESSION'
,p_item_default_language=>'PLSQL'
,p_source=>'COMPANIA'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(350327460652592356)
,p_validation_name=>'P1101_FECHCREA must be timestamp'
,p_validation_sequence=>80
,p_validation=>'P1101_FECHCREA'
,p_validation_type=>'ITEM_IS_TIMESTAMP'
,p_error_message=>'#LABEL# must be a valid timestamp.'
,p_associated_item=>wwv_flow_imp.id(350326989864592354)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(350328675951592357)
,p_validation_name=>'P1101_FECHMODI must be timestamp'
,p_validation_sequence=>100
,p_validation=>'P1101_FECHMODI'
,p_validation_type=>'ITEM_IS_TIMESTAMP'
,p_error_message=>'#LABEL# must be a valid timestamp.'
,p_associated_item=>wwv_flow_imp.id(350328164182592356)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(364564158163580128)
,p_validation_name=>'VALIDA version periodo'
,p_validation_sequence=>110
,p_validation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare v_fechaingreso date;',
'v_qty_aprobado number;',
'v_qty_total number;',
'begin',
'    select count(*) into v_qty_total from t_finz_costeocab where anno = :p1101_anno and mes = :p1101_mes;',
'    select count(*) into v_qty_aprobado from t_finz_costeocab where anno = :p1101_anno and mes = :p1101_mes and codigoestado = ''APROBADO'';',
'',
'    if v_qty_total = 0 then',
'        return true;',
'    elsif (v_qty_aprobado/v_qty_total) = 1 then',
'        return true;',
'    else',
'        return false;',
'    end if;',
'end;'))
,p_validation2=>'PLSQL'
,p_validation_type=>'FUNC_BODY_RETURNING_BOOLEAN'
,p_error_message=>unistr('Existe una versi\00F3n no aprobada en el periodo que intenta crear.')
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(350321855075592284)
,p_name=>'Cancel Dialog'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(350321753913592284)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(350322680181592284)
,p_event_id=>wwv_flow_imp.id(350321855075592284)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CANCEL'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(350329326026592359)
,p_process_sequence=>10
,p_process_point=>'AFTER_HEADER'
,p_process_type=>'NATIVE_FORM_FETCH'
,p_process_name=>'Fetch Row from T_FINZ_COSTEOCAB'
,p_attribute_02=>'T_FINZ_COSTEOCAB'
,p_attribute_03=>'P1101_ID'
,p_attribute_04=>'ID'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>350329326026592359
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(350306218430572403)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'numeroversion'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'	select nvl(max(numeroversion),0) + 1,''REGISTRADO'',:app_user',
'	into :p1101_numeroversion,:p1101_codigoestado,:p1101_ultimousuario',
'	from t_finz_costeocab where anno = :p1101_anno and mes = :p1101_mes;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>350306218430572403
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(350329771592592359)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_FORM_PROCESS'
,p_process_name=>'Process Row of T_FINZ_COSTEOCAB'
,p_attribute_02=>'T_FINZ_COSTEOCAB'
,p_attribute_03=>'P1101_ID'
,p_attribute_04=>'ID'
,p_attribute_11=>'I:U:D'
,p_attribute_12=>'Y'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_success_message=>'Action Processed.'
,p_internal_uid=>350329771592592359
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(350330195980592359)
,p_process_sequence=>30
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_SESSION_STATE'
,p_process_name=>'reset page'
,p_attribute_01=>'CLEAR_CACHE_CURRENT_PAGE'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(350321259607592282)
,p_internal_uid=>350330195980592359
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(350330556184592359)
,p_process_sequence=>40
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_CLOSE_WINDOW'
,p_process_name=>'Close Dialog'
,p_attribute_02=>'N'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>'CREATE,SAVE,DELETE'
,p_process_when_type=>'REQUEST_IN_CONDITION'
,p_internal_uid=>350330556184592359
);
wwv_flow_imp.component_end;
end;
/
