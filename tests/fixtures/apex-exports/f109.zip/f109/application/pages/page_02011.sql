prompt --application/pages/page_02011
begin
--   Manifest
--     PAGE: 02011
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>109
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_page.create_page(
 p_id=>2011
,p_name=>'Detalle de Pagos'
,p_step_title=>'Detalle de Pagos'
,p_autocomplete_on_off=>'OFF'
,p_javascript_code=>'var htmldb_delete_message=''"DELETE_CONFIRM_MSG"'';'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'02'
,p_created_on=>wwv_flow_imp.dz('20230705164635Z')
,p_last_updated_on=>wwv_flow_imp.dz('20230118200526Z')
,p_last_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(86118761288091128)
,p_plug_name=>'Pagos'
,p_region_name=>'rptPagos'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(37806762584106520)
,p_plug_display_sequence=>30
,p_include_in_reg_disp_sel_yn=>'Y'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select x.id',
'	, apex_item.checkbox(5,x.id) seleccion',
'	, x.idcab',
'	, x.usercrea',
'	, x.fechcrea',
'	, x.usermodi',
'	, x.fechmodi',
'	, x.pago',
'	, x.descpago',
'	, x.fechavence',
'	, x.montodeuda',
'	, x.montocuota',
'	, x.montoiva',
'	, x.montoreten',
'	, x.montoiva - x.montocuota ivacuota',
'	, x.estado',
'	, x.factura',
'	, apex_item.text(',
'		p_idx			=> 1,',
'		p_value			=> x.factura,',
'		p_maxlength		=> 10,',
'		p_item_id		=> x.id,',
'		p_attributes	=> ''class = "TX01" style="width: 75px; text-align: right;"'') txtfactura',
'	, x.documento',
'	, apex_item.text(',
'		p_idx			=> 2,',
'		p_value			=> x.documento,',
'		p_maxlength		=> 10,',
'		p_item_id		=> x.id,',
'		p_attributes	=> ''class = "TX02" style="width: 75px; text-align: right;"'') txtdocumento',
'	, x.fecha',
'	, apex_item.text(',
'		p_idx			=> 3,',
'		p_value			=> x.fecha,',
'		p_maxlength		=> 10,',
'		p_item_id		=> x.id,',
'		p_attributes	=> ''class = "TX03" style="width: 75px; text-align: right;"'') txtfecha',
'	, x.batch',
'	, apex_item.text(',
'		p_idx			=> 4,',
'		p_value			=> x.batch,',
'		p_maxlength		=> 10,',
'		p_item_id		=> x.id,',
'		p_attributes	=> ''class = "TX04" style="width: 75px; text-align: right;"'') txtbatch',
'from t_finz_amortizacionfeedet x where idcab = :p2011_id;'))
,p_plug_source_type=>'NATIVE_IR'
,p_ajax_items_to_submit=>'P2011_ID'
,p_plug_display_condition_type=>'EXISTS'
,p_plug_display_when_condition=>'select * from t_finz_amortizacionfeedet where idcab = :p2011_id;'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>210
,p_prn_height=>297
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(86118801758091129)
,p_max_row_count=>'1000000'
,p_search_button_label=>'Buscar'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_show_search_textbox=>'N'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'DDELACRUZ'
,p_internal_uid=>86118801758091129
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(85731490564745427)
,p_db_column_name=>'SELECCION'
,p_display_order=>10
,p_column_identifier=>'Z'
,p_column_label=>'<input type="checkbox" id="selectunselectall">'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(86118972234091130)
,p_db_column_name=>'ID'
,p_display_order=>20
,p_column_identifier=>'A'
,p_column_label=>'ID'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(86119021779091131)
,p_db_column_name=>'IDCAB'
,p_display_order=>30
,p_column_identifier=>'B'
,p_column_label=>'Idcab'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(86119184853091132)
,p_db_column_name=>'USERCREA'
,p_display_order=>40
,p_column_identifier=>'C'
,p_column_label=>'Usercrea'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(86119259769091133)
,p_db_column_name=>'FECHCREA'
,p_display_order=>50
,p_column_identifier=>'D'
,p_column_label=>'Fechcrea'
,p_column_type=>'DATE'
,p_display_text_as=>'HIDDEN'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(86119363385091134)
,p_db_column_name=>'USERMODI'
,p_display_order=>60
,p_column_identifier=>'E'
,p_column_label=>'Usermodi'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(86119482195091135)
,p_db_column_name=>'FECHMODI'
,p_display_order=>70
,p_column_identifier=>'F'
,p_column_label=>'Fechmodi'
,p_column_type=>'DATE'
,p_display_text_as=>'HIDDEN'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(86119506847091136)
,p_db_column_name=>'PAGO'
,p_display_order=>80
,p_column_identifier=>'G'
,p_column_label=>'Pago'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'NUMBER'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(86119602109091137)
,p_db_column_name=>'DESCPAGO'
,p_display_order=>90
,p_column_identifier=>'H'
,p_column_label=>unistr('Descripci\00F3n')
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(86119758942091138)
,p_db_column_name=>'FECHAVENCE'
,p_display_order=>100
,p_column_identifier=>'I'
,p_column_label=>'Fecha Vence'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(86119864323091139)
,p_db_column_name=>'MONTODEUDA'
,p_display_order=>110
,p_column_identifier=>'J'
,p_column_label=>'Deuda'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G990D00'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(86119942229091140)
,p_db_column_name=>'MONTOIVA'
,p_display_order=>120
,p_column_identifier=>'K'
,p_column_label=>'Cuota + IVA'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G990D00'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(86120239386091143)
,p_db_column_name=>'MONTORETEN'
,p_display_order=>130
,p_column_identifier=>'N'
,p_column_label=>unistr('Retenci\00F3n')
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G990D00'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(86120388672091144)
,p_db_column_name=>'ESTADO'
,p_display_order=>140
,p_column_identifier=>'O'
,p_column_label=>'Estado'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(86120473822091145)
,p_db_column_name=>'FACTURA'
,p_display_order=>150
,p_column_identifier=>'P'
,p_column_label=>'Factura'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'NUMBER'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(86120599740091146)
,p_db_column_name=>'DOCUMENTO'
,p_display_order=>160
,p_column_identifier=>'Q'
,p_column_label=>'Documento'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'NUMBER'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(86120679066091147)
,p_db_column_name=>'FECHA'
,p_display_order=>170
,p_column_identifier=>'R'
,p_column_label=>'Fecha'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(86120744689091148)
,p_db_column_name=>'BATCH'
,p_display_order=>180
,p_column_identifier=>'S'
,p_column_label=>'Batch'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'NUMBER'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(85731211822745425)
,p_db_column_name=>'MONTOCUOTA'
,p_display_order=>190
,p_column_identifier=>'T'
,p_column_label=>'Cuota'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G990D00'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(85731354166745426)
,p_db_column_name=>'IVACUOTA'
,p_display_order=>200
,p_column_identifier=>'U'
,p_column_label=>'IVA Cuota'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G990D00'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(86120891436091149)
,p_db_column_name=>'TXTFACTURA'
,p_display_order=>210
,p_column_identifier=>'V'
,p_column_label=>'Factura*'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(86120903663091150)
,p_db_column_name=>'TXTDOCUMENTO'
,p_display_order=>220
,p_column_identifier=>'W'
,p_column_label=>'Documento*'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(87116010351254501)
,p_db_column_name=>'TXTFECHA'
,p_display_order=>230
,p_column_identifier=>'X'
,p_column_label=>'Fecha*'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(87116179088254502)
,p_db_column_name=>'TXTBATCH'
,p_display_order=>240
,p_column_identifier=>'Y'
,p_column_label=>'Batch*'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(86222064479752126)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'862221'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'SELECCION:PAGO:DESCPAGO:FECHAVENCE:MONTODEUDA:MONTOCUOTA:IVACUOTA:MONTOIVA:ESTADO:TXTDOCUMENTO:TXTFECHA:TXTFACTURA:'
,p_sort_column_1=>'ID'
,p_sort_direction_1=>'ASC'
,p_sort_column_2=>'0'
,p_sort_direction_2=>'ASC'
,p_sort_column_3=>'0'
,p_sort_direction_3=>'ASC'
,p_sort_column_4=>'0'
,p_sort_direction_4=>'ASC'
,p_sort_column_5=>'0'
,p_sort_direction_5=>'ASC'
,p_sort_column_6=>'0'
,p_sort_direction_6=>'ASC'
,p_sum_columns_on_break=>'MONTOCUOTA:IVACUOTA:MONTOIVA'
,p_created_on=>wwv_flow_imp.dz('20230705164635Z')
,p_updated_on=>wwv_flow_imp.dz('20230705164635Z')
,p_created_by=>'CVACA'
,p_updated_by=>'CVACA'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(86183794459447631)
,p_plug_name=>'Detalle de Pagos'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(38289867500120143)
,p_plug_display_sequence=>20
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'TEXT',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(255595054770096606)
,p_plug_name=>'Acciones'
,p_region_template_options=>'#DEFAULT#:t-Form--stretchInputs'
,p_plug_template=>wwv_flow_imp.id(38289497777120142)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(86184418399447634)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(255595054770096606)
,p_button_name=>'CANCEL'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860056812106557)
,p_button_image_alt=>'Cancel'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'LEFT'
,p_button_redirect_url=>'f?p=&APP_ID.:2009:&SESSION.::&DEBUG.:::'
,p_icon_css_classes=>'fa-arrow-left'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(86118124924091122)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(255595054770096606)
,p_button_name=>'GENERAR'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860056812106557)
,p_button_image_alt=>'Generar Pagos'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_button_condition=>'select * from data.t_finz_amortizacionfeedet where idcab = :p2011_id'
,p_button_condition_type=>'NOT_EXISTS'
,p_icon_css_classes=>'fa-gear'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(86184343756447634)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(255595054770096606)
,p_button_name=>'DELETE'
,p_button_action=>'REDIRECT_URL'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860056812106557)
,p_button_image_alt=>'Delete'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'javascript:apex.confirm(htmldb_delete_message,''DELETE'');'
,p_button_execute_validations=>'N'
,p_button_condition=>'select * from t_finz_amortizacionfeedet where idcab = :p2011_id;'
,p_button_condition_type=>'NOT_EXISTS'
,p_icon_css_classes=>'fa-trash-o'
,p_database_action=>'DELETE'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(86184241939447634)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(255595054770096606)
,p_button_name=>'SAVE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860056812106557)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Apply Changes'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_button_condition_type=>'NEVER'
,p_icon_css_classes=>'fa-save'
,p_database_action=>'UPDATE'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(86184125021447634)
,p_button_sequence=>50
,p_button_plug_id=>wwv_flow_imp.id(255595054770096606)
,p_button_name=>'CREATE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860056812106557)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Create'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_button_condition_type=>'NEVER'
,p_database_action=>'INSERT'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(92882295992350931)
,p_button_sequence=>60
,p_button_plug_id=>wwv_flow_imp.id(255595054770096606)
,p_button_name=>'FACTURAS'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860056812106557)
,p_button_image_alt=>'Buscar Facturas'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_button_condition=>'select ''x'' from t_finz_amortizacionfeedet x where idcab = :p2011_id and x.estado = ''PROCESADO'';'
,p_button_condition_type=>'EXISTS'
,p_icon_css_classes=>'fa-database-search'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(212073722021340817)
,p_button_sequence=>70
,p_button_plug_id=>wwv_flow_imp.id(255595054770096606)
,p_button_name=>'PRECANCELAR'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860056812106557)
,p_button_image_alt=>'Precancelar'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_button_condition=>'select ''x'' from t_finz_amortizacionfeedet x where idcab = :p2011_id and (nvl(x.estado,''PENDIENTE'') = ''PENDIENTE'' and factura is not null and documento is not null and fecha is not null);'
,p_button_condition_type=>'EXISTS'
,p_icon_css_classes=>'fa-dollar'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(85731790315745430)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(86118761288091128)
,p_button_name=>'DOCUMENTO'
,p_button_static_id=>'btnGenerarFactura'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860056812106557)
,p_button_image_alt=>'Generar Documento'
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
,p_button_alignment=>'RIGHT'
,p_button_condition=>'select * from data.t_finz_amortizacionfeedet where estado = ''PENDIENTE'' and idcab = :p2011_id'
,p_button_condition_type=>'EXISTS'
,p_icon_css_classes=>'fa-clipboard-wrench'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(85732232711745435)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(86118761288091128)
,p_button_name=>'FACTURA'
,p_button_static_id=>'btnGenerarFactura'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860056812106557)
,p_button_image_alt=>'Generar Factura'
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
,p_button_alignment=>'RIGHT'
,p_button_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'with ult as(',
'	select max(FECHMODI) ultimo from data.t_finz_amortizacionfeedet where estado = ''PROCESADO'' and idcab = :p2011_id',
') select ultimo from ult where (ultimo + (5/1440)) < systimestamp'))
,p_button_condition_type=>'EXISTS'
,p_icon_css_classes=>'fa-clipboard-user'
,p_button_comment=>unistr('Valido que haya pasado 5 minutos desde la \00FAltima generaci\00F3n del documento.')
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(85731580029745428)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(86118761288091128)
,p_button_name=>'PAGAR'
,p_button_static_id=>'btnPagar'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860056812106557)
,p_button_image_alt=>'Marcar como pagados'
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
,p_button_alignment=>'RIGHT'
,p_button_condition=>'select * from data.t_finz_amortizacionfeedet where estado != ''PAGADO'' and factura is not null and documento is not null and fecha is not null and idcab = :p2011_id'
,p_button_condition_type=>'EXISTS'
,p_icon_css_classes=>'fa-clipboard-new'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(86186085599447636)
,p_branch_name=>'Go To Page 2009'
,p_branch_action=>'f?p=&APP_ID.:2009:&SESSION.&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_imp.id(86184343756447634)
,p_branch_sequence=>1
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(85732069973745433)
,p_name=>'P2011_TOTALIVA'
,p_item_sequence=>120
,p_item_plug_id=>wwv_flow_imp.id(86183794459447631)
,p_prompt=>'Total + IVA'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(86117871841091119)
,p_name=>'P2011_SUBTOTAL'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(86183794459447631)
,p_prompt=>'Sub Total'
,p_format_mask=>'FML999G999G999G999G990D00'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(86118058123091121)
,p_name=>'P2011_PENDIENTE'
,p_item_sequence=>140
,p_item_plug_id=>wwv_flow_imp.id(86183794459447631)
,p_prompt=>'Pendiente'
,p_format_mask=>'FML999G999G999G999G990D00'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(86186482032447639)
,p_name=>'P2011_ID'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(86183794459447631)
,p_use_cache_before_default=>'NO'
,p_source=>'ID'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_protection_level=>'S'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(86186853645447640)
,p_name=>'P2011_USERCREA'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(86183794459447631)
,p_use_cache_before_default=>'NO'
,p_source=>'USERCREA'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(86187271533447644)
,p_name=>'P2011_FECHCREA'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(86183794459447631)
,p_use_cache_before_default=>'NO'
,p_source=>'FECHCREA'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(86188086592447645)
,p_name=>'P2011_USERMODI'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(86183794459447631)
,p_use_cache_before_default=>'NO'
,p_source=>'USERMODI'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(86188404697447647)
,p_name=>'P2011_FECHMODI'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(86183794459447631)
,p_use_cache_before_default=>'NO'
,p_source=>'FECHMODI'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(86189259736447647)
,p_name=>'P2011_CODIGOCLIENTE'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(86183794459447631)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Cliente'
,p_source=>'CODIGOCLIENTE'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'LOV_CLIENTES'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select CODIGO||''-''||NOMBRES as d,',
'     CODIGO   as r',
'  from VT_JDE_CLIENTE',
' order by 1'))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_read_only_when_type=>'ALWAYS'
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(86189629745447648)
,p_name=>'P2011_MONTOTOTAL'
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_imp.id(86183794459447631)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Total'
,p_format_mask=>'FML999G999G999G999G990D00'
,p_source=>'MONTOTOTAL'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(86190048450447650)
,p_name=>'P2011_VALORIVA'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(86183794459447631)
,p_use_cache_before_default=>'NO'
,p_prompt=>'% IVA'
,p_source=>'VALORIVA'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(86190834963447653)
,p_name=>'P2011_MONTOABONO'
,p_item_sequence=>130
,p_item_plug_id=>wwv_flow_imp.id(86183794459447631)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Abono'
,p_format_mask=>'FML999G999G999G999G990D00'
,p_source=>'MONTOABONO'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(86191237616447654)
,p_name=>'P2011_FECHAINICIO'
,p_item_sequence=>150
,p_item_plug_id=>wwv_flow_imp.id(86183794459447631)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Fecha Inicio'
,p_source=>'FECHAINICIO'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(86191640369447656)
,p_name=>'P2011_CANTPAGOS'
,p_item_sequence=>160
,p_item_plug_id=>wwv_flow_imp.id(86183794459447631)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Pagos'
,p_source=>'CANTPAGOS'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(87116250344254503)
,p_name=>'P2011_TABLAID'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(86118761288091128)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(87116362646254504)
,p_name=>'P2011_TABLAVALOR'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(86118761288091128)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(86187750971447644)
,p_validation_name=>'P2011_FECHCREA must be timestamp'
,p_validation_sequence=>30
,p_validation=>'P2011_FECHCREA'
,p_validation_type=>'ITEM_IS_TIMESTAMP'
,p_error_message=>'#LABEL# must be a valid timestamp.'
,p_associated_item=>wwv_flow_imp.id(86187271533447644)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(86188989307447647)
,p_validation_name=>'P2011_FECHMODI must be timestamp'
,p_validation_sequence=>50
,p_validation=>'P2011_FECHMODI'
,p_validation_type=>'ITEM_IS_TIMESTAMP'
,p_error_message=>'#LABEL# must be a valid timestamp.'
,p_associated_item=>wwv_flow_imp.id(86188404697447647)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(90017721442362046)
,p_name=>unistr('Selecci\00F3n IR')
,p_event_sequence=>5
,p_triggering_element_type=>'JQUERY_SELECTOR'
,p_triggering_element=>'#selectunselectall'
,p_bind_type=>'live'
,p_bind_delegate_to_selector=>'#rptPagos'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(90018123262362051)
,p_event_id=>wwv_flow_imp.id(90017721442362046)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'if ($(''#rptPagos #selectunselectall'' ).is('':checked'')) {',
'    $(''#rptPagos input[type=checkbox][name=f05]'').prop(''checked'',true);',
'} else {',
'    $(''#rptPagos input[type=checkbox][name=f05]'').prop(''checked'',false);',
'}'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(87125008812295752)
,p_name=>'Guarda Factura'
,p_event_sequence=>20
,p_triggering_element_type=>'JQUERY_SELECTOR'
,p_triggering_element=>'.TX01'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(87125435207295754)
,p_event_id=>wwv_flow_imp.id(87125008812295752)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'var i=$(this.triggeringElement).attr(''id'');',
'var v=$(this.triggeringElement).val();',
'console.log("cambio id:"+i+" valor:"+v)',
'apex.item("P2011_TABLAVALOR").setValue(v);',
'apex.item("P2011_TABLAID").setValue(i);',
'mensajeExito(''Cambios guardados'');'))
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(87125902969295754)
,p_event_id=>wwv_flow_imp.id(87125008812295752)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'    update t_finz_amortizacionfeedet x set x.factura = :p2011_tablavalor where id = :p2011_tablaid;',
'end;'))
,p_attribute_02=>'P2011_TABLAVALOR,P2011_TABLAID'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(87116492073254505)
,p_name=>'Guarda Documento'
,p_event_sequence=>30
,p_triggering_element_type=>'JQUERY_SELECTOR'
,p_triggering_element=>'.TX02'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(87116591203254506)
,p_event_id=>wwv_flow_imp.id(87116492073254505)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'var i=$(this.triggeringElement).attr(''id'');',
'var v=$(this.triggeringElement).val();',
'console.log("cambio id:"+i+" valor:"+v)',
'apex.item("P2011_TABLAVALOR").setValue(v);',
'apex.item("P2011_TABLAID").setValue(i);',
'mensajeExito(''Cambios guardados'');'))
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(87116647891254507)
,p_event_id=>wwv_flow_imp.id(87116492073254505)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'    update t_finz_amortizacionfeedet x set x.documento = :p2011_tablavalor where id = :p2011_tablaid;',
'end;'))
,p_attribute_02=>'P2011_TABLAVALOR,P2011_TABLAID'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(87116789117254508)
,p_name=>'Guarda Fecha'
,p_event_sequence=>40
,p_triggering_element_type=>'JQUERY_SELECTOR'
,p_triggering_element=>'.TX03'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(87116880696254509)
,p_event_id=>wwv_flow_imp.id(87116789117254508)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'var i=$(this.triggeringElement).attr(''id'');',
'var v=$(this.triggeringElement).val();',
'console.log("cambio id:"+i+" valor:"+v)',
'apex.item("P2011_TABLAVALOR").setValue(v);',
'apex.item("P2011_TABLAID").setValue(i);',
'mensajeExito(''Cambios guardados'');'))
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(87116986125254510)
,p_event_id=>wwv_flow_imp.id(87116789117254508)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'	if pk_commons.f_esfecha(:p2011_tablavalor) = 1 then',
'		update t_finz_amortizacionfeedet x set x.fecha = :p2011_tablavalor where id = :p2011_tablaid;',
'	else',
'		apex_error.add_error (',
unistr('			p_message		=> ''Formato de fecha inv\00E1lido. Ingrese dd/mm/yyyy.'','),
'			p_display_location	=>apex_error.c_inline_in_notification );',
'	end if;',
'end;'))
,p_attribute_02=>'P2011_TABLAVALOR,P2011_TABLAID'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(87117055679254511)
,p_name=>'Guarda Batch'
,p_event_sequence=>50
,p_triggering_element_type=>'JQUERY_SELECTOR'
,p_triggering_element=>'.TX04'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(87117194448254512)
,p_event_id=>wwv_flow_imp.id(87117055679254511)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'var i=$(this.triggeringElement).attr(''id'');',
'var v=$(this.triggeringElement).val();',
'console.log("cambio id:"+i+" valor:"+v)',
'apex.item("P2011_TABLAVALOR").setValue(v);',
'apex.item("P2011_TABLAID").setValue(i);',
'mensajeExito(''Cambios guardados'');'))
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(87117202255254513)
,p_event_id=>wwv_flow_imp.id(87117055679254511)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'    update t_finz_amortizacionfeedet x set x.batch = :p2011_tablavalor where id = :p2011_tablaid;',
'end;'))
,p_attribute_02=>'P2011_TABLAVALOR,P2011_TABLAID'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(86192484484447658)
,p_process_sequence=>10
,p_process_point=>'AFTER_HEADER'
,p_process_type=>'NATIVE_FORM_FETCH'
,p_process_name=>'Fetch Row from T_FINZ_AMORTIZACIONFEEFRQ'
,p_attribute_02=>'T_FINZ_AMORTIZACIONFEEFRQ'
,p_attribute_03=>'P2011_ID'
,p_attribute_04=>'ID'
,p_internal_uid=>86192484484447658
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(86117900827091120)
,p_process_sequence=>20
,p_process_point=>'AFTER_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>unistr('C\00E1lculos')
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'	select to_char(montototal,''FML999G999G999G999G990D00'')',
'		, to_char(montototal - nvl(montoabono,0),''FML999G999G999G999G990D00'')',
'        , to_char(montototal*(1+(valoriva/100)),''FML999G999G999G999G990D00'')',
'	into :p2011_subtotal',
'		, :p2011_pendiente',
'        , :p2011_totaliva',
'	from t_finz_amortizacionfeefrq where id = :p2011_id;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>86117900827091120
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(86192850480447658)
,p_process_sequence=>30
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_FORM_PROCESS'
,p_process_name=>'Process Row of T_FINZ_AMORTIZACIONFEEFRQ'
,p_attribute_02=>'T_FINZ_AMORTIZACIONFEEFRQ'
,p_attribute_03=>'P2011_ID'
,p_attribute_04=>'ID'
,p_attribute_11=>'I:U:D'
,p_attribute_12=>'Y'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_success_message=>'Action Processed.'
,p_internal_uid=>86192850480447658
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(86193257232447658)
,p_process_sequence=>40
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_SESSION_STATE'
,p_process_name=>'reset page'
,p_attribute_01=>'CLEAR_CACHE_CURRENT_PAGE'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(86184343756447634)
,p_internal_uid=>86193257232447658
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(85732156908745434)
,p_process_sequence=>50
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Generar Pagos'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'	data.pk_finz_franquicias.sp_tablaamortizacion(:g_compania,:app_user,:p2011_id);',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(86118124924091122)
,p_internal_uid=>85732156908745434
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(92882317340350932)
,p_process_sequence=>60
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Buscar Facturas'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'    data.pk_finz_franquicias.sp_buscarfactura;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(92882295992350931)
,p_internal_uid=>92882317340350932
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(85731819741745431)
,p_process_sequence=>70
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Generar Documento'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'v_iddet number;',
'v_aux_num1	number;',
'begin',
'	for i in 1..apex_application.g_f05.count loop',
'		v_iddet := apex_application.g_f05(i);',
'        ',
'        pk_finz_franquicias.sp_generafacturafee(',
'            p_compania		=> :g_compania',
'            , p_usuario		=> :app_user',
'            , p_id			=> v_iddet',
'            , p_respuesta	=> v_aux_num1);',
'        end loop;',
'	commit;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(85731790315745430)
,p_internal_uid=>85731819741745431
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(85732333084745436)
,p_process_sequence=>80
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Generar Factura'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'v_iddet number;',
'v_aux_num1	number;',
'begin',
'	for i in 1..apex_application.g_f05.count loop',
'		v_iddet := apex_application.g_f05(i);',
'        ',
'        pk_finz_franquicias.sp_procesarorden(',
'            p_compania		=> :g_compania',
'            , p_usuario		=> :app_user',
'            , p_id			=> v_iddet',
'            , p_respuesta	=> v_aux_num1);',
'        end loop;',
'	commit;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(85732232711745435)
,p_internal_uid=>85732333084745436
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(85731924008745432)
,p_process_sequence=>90
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Marcar Pagados'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'v_iddet number;',
'v_aux_num1	number;',
'begin',
'	for i in 1..apex_application.g_f05.count loop',
'		v_iddet := apex_application.g_f05(i);',
'		',
'		update t_finz_amortizacionfeedet x set estado = ''PAGADO'' where id = v_iddet and estado != ''PAGADO'' and factura is not null and documento is not null and fecha is not null;',
'		v_aux_num1 := sql%rowcount;',
'	end loop;',
'	commit;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_process_error_message=>'No se pudo procesar los registros seleccionados.'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(85731580029745428)
,p_process_success_message=>'Registros Procesados'
,p_internal_uid=>85731924008745432
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(212073820251340818)
,p_process_sequence=>100
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Precancelar'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'	update t_finz_amortizacionfeedet x set x.estado = ''GENERADO''',
'	where idcab = :p2011_id',
'		and nvl(x.estado,''PENDIENTE'') = ''PENDIENTE''',
'		and factura is not null',
'		and documento is not null',
'		and fecha is not null;',
'	commit;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(212073722021340817)
,p_internal_uid=>212073820251340818
);
wwv_flow_imp.component_end;
end;
/
