prompt --application/pages/page_00113
begin
--   Manifest
--     PAGE: 00113
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>109
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_page.create_page(
 p_id=>113
,p_name=>'Aprobar Bloqueo de Pago'
,p_step_title=>'Aprobar Bloqueo de Pago'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_page_is_public_y_n=>'Y'
,p_page_component_map=>'03'
,p_created_on=>wwv_flow_imp.dz('20230705164634Z')
,p_last_updated_on=>wwv_flow_imp.dz('20231109163856Z')
,p_last_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1051073289268634021)
,p_plug_name=>unistr('Aprobaci\00F3n Bloqueo de Pagos &P113_DOCUMENTO.')
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(37817215439106526)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(37761271469106475)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(37860983999106559)
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(1209070037402466778)
,p_name=>unistr('Aprobaci\00F3n Bloqueo')
,p_template=>wwv_flow_imp.id(37807886111106520)
,p_display_sequence=>20
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select apex_item.checkbox(1,rid,''CHECKED class="chkF01"'') seleccion',
'	, a.compania',
'	, b.numerodocumento',
'	, c.descripcion proveedor',
'	, a.ordendecompra',
'	, a.tipoordencompra',
'	, a.numerofactura',
'	, a.motivo',
'	, a.montototal',
'	, a.montopendiente',
'	, a.montobloqueo',
'	, b.tipo',
'from t_finz_retencionpagos a, vt_finz_mesatrabajo_bloqueo b, vt_jde_maestroproveedor c',
'where a.id_proceso = b.numerodocumento',
'	and a.compania = b.compania',
'	and a.codigoproveedor = c.codigoproveedor',
'	and a.id_proceso = :p113_documento ',
'	and b.aprobador = :p113_aprobador',
'	and a.estado = ''EN_PROCESO'''))
,p_ajax_enabled=>'Y'
,p_ajax_items_to_submit=>'P113_DOCUMENTO,P113_APROBADOR'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(37830327650106535)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_no_data_found=>'No existen datos para aprobar'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_query_row_count_max=>500
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_prn_format=>'PDF'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20231109163127Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(340065474404719126)
,p_query_column_id=>1
,p_column_alias=>'SELECCION'
,p_column_display_sequence=>1
,p_use_as_row_header=>'N'
,p_column_alignment=>'CENTER'
,p_disable_sort_column=>'N'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(338734537647136010)
,p_query_column_id=>2
,p_column_alias=>'COMPANIA'
,p_column_display_sequence=>2
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(337500585102323014)
,p_query_column_id=>3
,p_column_alias=>'NUMERODOCUMENTO'
,p_column_display_sequence=>3
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(337500618846323015)
,p_query_column_id=>4
,p_column_alias=>'PROVEEDOR'
,p_column_display_sequence=>4
,p_column_heading=>'Proveedor'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(337500753006323016)
,p_query_column_id=>5
,p_column_alias=>'ORDENDECOMPRA'
,p_column_display_sequence=>5
,p_column_heading=>'OC'
,p_use_as_row_header=>'N'
,p_column_alignment=>'CENTER'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20231109162727Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(337500824230323017)
,p_query_column_id=>6
,p_column_alias=>'TIPOORDENCOMPRA'
,p_column_display_sequence=>6
,p_column_heading=>'Tipo OC'
,p_use_as_row_header=>'N'
,p_column_alignment=>'CENTER'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20231109162727Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(337500947401323018)
,p_query_column_id=>7
,p_column_alias=>'NUMEROFACTURA'
,p_column_display_sequence=>7
,p_column_heading=>'Factura'
,p_use_as_row_header=>'N'
,p_column_alignment=>'CENTER'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20231109162727Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(337501011980323019)
,p_query_column_id=>8
,p_column_alias=>'MOTIVO'
,p_column_display_sequence=>22
,p_column_heading=>'Motivo'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20231109162758Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(337501130378323020)
,p_query_column_id=>9
,p_column_alias=>'MONTOTOTAL'
,p_column_display_sequence=>9
,p_column_heading=>'Total'
,p_use_as_row_header=>'N'
,p_column_format=>'FML999G999G999G999G990D00'
,p_column_alignment=>'RIGHT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20231109162727Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(337501289665323021)
,p_query_column_id=>10
,p_column_alias=>'MONTOPENDIENTE'
,p_column_display_sequence=>10
,p_column_heading=>'Pendiente'
,p_use_as_row_header=>'N'
,p_column_format=>'FML999G999G999G999G990D00'
,p_column_alignment=>'RIGHT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20231109162727Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(337501384847323022)
,p_query_column_id=>11
,p_column_alias=>'MONTOBLOQUEO'
,p_column_display_sequence=>11
,p_column_heading=>'Bloqueado'
,p_use_as_row_header=>'N'
,p_column_format=>'FML999G999G999G999G990D00'
,p_column_alignment=>'RIGHT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20231109162727Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(339864809555312516)
,p_query_column_id=>12
,p_column_alias=>'TIPO'
,p_column_display_sequence=>12
,p_hidden_column=>'Y'
,p_derived_column=>'N'
,p_updated_on=>wwv_flow_imp.dz('20231109162758Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1561024516250474913)
,p_plug_name=>'Barra de acciones'
,p_region_template_options=>'#DEFAULT#:t-Form--stretchInputs'
,p_plug_template=>wwv_flow_imp.id(38289497777120142)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'REGION_POSITION_01'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1683503001335529753)
,p_plug_name=>'Botones'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(38290276266120143)
,p_plug_display_sequence=>40
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_condition_type=>'EXPRESSION'
,p_plug_display_when_condition=>'PK_CORP_FLUJOAPROBACION.F_APROBADORFLUJO(:P113_USUARIO, :P113_APROBADOR, :APP_MODULO ,:G_COMPANIA)=1'
,p_plug_display_when_cond2=>'PLSQL'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(338726502636136001)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(1561024516250474913)
,p_button_name=>'Regresar'
,p_button_static_id=>'btnRegresar'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860056812106557)
,p_button_image_alt=>'Regresar'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'LEFT'
,p_button_redirect_url=>'f?p=&APP_ID.:100:&SESSION.::&DEBUG.:RP::'
,p_icon_css_classes=>'fa-arrow-left'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(338726924782136003)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(1561024516250474913)
,p_button_name=>'Ver_Ruta'
,p_button_action=>'REDIRECT_APP'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860056812106557)
,p_button_image_alt=>'Ver Ruta'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=100:104:&SESSION.::&DEBUG.:RP,:G_OBJETO,G_OBJETO_ID,G_TODO:&APP_OBJETO.,&P113_DOCUMENTO.,true'
,p_icon_css_classes=>'fa-road'
,p_updated_on=>wwv_flow_imp.dz('20231109163236Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(338730279402136007)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(1683503001335529753)
,p_button_name=>'APROBAR'
,p_button_static_id=>'btnAprobar'
,p_button_action=>'REDIRECT_APP'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860181880106559)
,p_button_image_alt=>'Aprobar'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=100:102:&SESSION.::&DEBUG.:RP:G_COMPANIA,G_MODULO,G_USUARIO,G_OBJETO,G_OBJETO_ID,G_USUARIO_FLUJO:&G_COMPANIA.,&APP_MODULO.,&APP_USER.,RETENCION_DE_PAGO,&P113_DOCUMENTO.,&P113_APROBADOR.'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(338730695609136007)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(1683503001335529753)
,p_button_name=>'RECHAZAR'
,p_button_static_id=>'btnRechazar'
,p_button_action=>'REDIRECT_APP'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860181880106559)
,p_button_image_alt=>'Rechazar'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=100:103:&SESSION.::&DEBUG.:RP:G_COMPANIA,G_MODULO,G_USUARIO,G_OBJETO,G_OBJETO_ID,G_USUARIO_FLUJO:&G_COMPANIA.,&APP_MODULO.,&APP_USER.,RETENCION_DE_PAGO,&P113_DOCUMENTO.,'
,p_grid_new_row=>'N'
,p_grid_new_column=>'N'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(338746114746136037)
,p_branch_name=>'Regresa a Mesa'
,p_branch_action=>'f?p=&APP_ID.:100:&SESSION.::&DEBUG.:RP::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_sequence=>10
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(106107906430260243)
,p_name=>'P113_USUARIO'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(1209070037402466778)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(338736156081136015)
,p_name=>'P113_APROBADOR'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(1209070037402466778)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(338736558064136015)
,p_name=>'P113_DOCUMENTO'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(1209070037402466778)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(338736916979136015)
,p_name=>'P113_APROBACION_EXITO'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(1209070037402466778)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(338737319652136015)
,p_name=>'P113_TERMINA_FLUJO'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(1209070037402466778)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(340404021485473215)
,p_name=>'P113_SINSELECCION'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(1209070037402466778)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(338745115505136035)
,p_name=>unistr('Cierre di\00E1logo: aprobar')
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(338730279402136007)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(338745667426136035)
,p_event_id=>wwv_flow_imp.id(338745115505136035)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'var trama = JSON.parse(this.data.G_RESULTADO);',
'var isTerminoFlujo= trama.resultado.terminoFlujo;',
'apex.item( "P113_TERMINA_FLUJO" ).setValue(0);',
'',
'if(this.data.G_EXITO==''true''){',
'    mensaje(''exito'', this.data.G_MENSAJE);',
'    if(isTerminoFlujo){',
'        apex.item( "P113_TERMINA_FLUJO" ).setValue(1);',
'    }',
'    $(''#btnAprobar'').hide();',
'    $(''#btnRechazar'').hide();',
'}',
'else{',
'    mensaje(''error'', this.data.G_MENSAJE);',
'}'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(338739926404136031)
,p_name=>unistr('Cierre di\00E1logo: aprobar exito')
,p_event_sequence=>20
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(338730279402136007)
,p_condition_element=>'P113_TERMINA_FLUJO'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'1'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
,p_updated_on=>wwv_flow_imp.dz('20231109163856Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(338741495172136032)
,p_event_id=>wwv_flow_imp.id(338739926404136031)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'	update t_finz_retencionpagos set',
'		estado = ''BLOQUEADO''',
'		, aprobador = :app_user',
'	where id_proceso = :p113_documento',
'		and (rid not in (',
'			select regexp_substr(:p113_sinseleccion,''[^,]+'',1,level)',
'			from dual connect by regexp_substr(:p113_sinseleccion,''[^,]+'',1,level) is not null)',
'			or :p113_sinseleccion is null',
'		);',
'',
'	pk_finz_retencionpagos.sp_procesa_bloqueo_aprobado(:p113_documento);',
'	pk_finz_retencionpagos.sp_notifica_bloqueo_aprobado(:p113_documento);',
'',
'	commit;',
'end;'))
,p_attribute_02=>'P113_DOCUMENTO,P113_SINSELECCION'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20231109163856Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(338740458795136032)
,p_event_id=>wwv_flow_imp.id(338739926404136031)
,p_event_result=>'TRUE'
,p_action_sequence=>50
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
' $(''#btnRegresar'').trigger("click");',
'    $(''#btnAprobar'').hide();',
'    $(''#btnRechazar'').hide();'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(338742885384136034)
,p_name=>unistr('Cierre di\00E1logo: rechazar')
,p_event_sequence=>30
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(338730695609136007)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(338743353305136034)
,p_event_id=>wwv_flow_imp.id(338742885384136034)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'apex.item( "P113_TERMINA_FLUJO" ).setValue(0);',
'if(this.data.G_EXITO==''true''){',
'    mensaje(''exito'', this.data.G_MENSAJE);',
'    apex.item( "P113_TERMINA_FLUJO" ).setValue(1);',
'    $(''#btnAprobar'').hide();',
'    $(''#btnRechazar'').hide();',
'}    ',
'else{',
'    mensaje(''error'', this.data.G_MENSAJE);',
'}',
'',
'/*',
'var trama = JSON.parse(this.data.G_RESULTADO);',
'var isTerminoFlujo= trama.resultado.terminoFlujo;',
'apex.item( "P113_TERMINA_FLUJO" ).setValue(0);',
'',
'if(this.data.G_EXITO==''true''){',
'    mensaje(''exito'', this.data.G_MENSAJE);',
'    if(isTerminoFlujo){',
'        apex.item( "P113_TERMINA_FLUJO" ).setValue(1);',
'    $(''#btnAprobar'').hide();',
'    $(''#btnRechazar'').hide();',
'    }',
'    else{',
'    mensaje(''error'', this.data.G_MENSAJE);',
'}',
'}',
'*/'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(338743762595136035)
,p_name=>unistr('Cierre di\00E1logo: rechazar exito')
,p_event_sequence=>40
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(338730695609136007)
,p_condition_element=>'P113_TERMINA_FLUJO'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'1'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
,p_updated_on=>wwv_flow_imp.dz('20231106213827Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(338744710667136035)
,p_event_id=>wwv_flow_imp.id(338743762595136035)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'    UPDATE T_FINZ_RETENCIONPAGOS',
'    SET ESTADO = ''RECHAZADO'', APROBADOR = :APP_USER',
'    WHERE ID_PROCESO = :P113_DOCUMENTO',
'    AND (RID NOT IN (SELECT regexp_substr(:P113_SINSELECCION,''[^,]+'', 1, level) FROM DUAL connect by regexp_substr(:P113_SINSELECCION, ''[^,]+'', 1, level) is not null )',
'    OR :P113_SINSELECCION IS NULL);',
'    commit;',
'end;'))
,p_attribute_02=>'P113_APROBADOR,P113_SINSELECCION'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20231106213827Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(338744293918136035)
,p_event_id=>wwv_flow_imp.id(338743762595136035)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
' $(''#btnRegresar'').trigger("click");',
'    $(''#btnAprobar'').hide();',
'    $(''#btnRechazar'').hide();'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(340406225815499675)
,p_name=>'Seleccionados'
,p_event_sequence=>50
,p_triggering_element_type=>'JQUERY_SELECTOR'
,p_triggering_element=>'.chkF01'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(340406638660499681)
,p_event_id=>wwv_flow_imp.id(340406225815499675)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P113_SELECCION'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'var lineas =""; ',
'document.querySelectorAll(''.chkF01'').forEach(function(seleccion) {',
'    if(!seleccion.checked){',
'        var linea = seleccion.value',
'        if(lineas==""){',
'            lineas = linea;',
'        }else{',
'            ',
'            lineas = lineas+'',''+linea;',
'        }      ',
'    }else{',
'        ',
'    }',
'    ',
'});',
'',
'apex.item("P113_SINSELECCION").setValue(lineas);',
''))
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(106107868783260242)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Page Setup'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE V_TIPO VARCHAR2(999):='''';',
'BEGIN',
'    :P113_USUARIO := :APP_USER;',
'    IF(:G_DETALLE_ID IS NOT NULL AND :G_TOKEN IS NOT NULL) THEN --APROBACION CON TOKEN (DESDE LINK DEL CORREO)',
'        PK_CORP_FLUJOAPROBACION.SP_BUSCARAPROBACION(:G_DETALLE_ID, :G_TOKEN, :G_COMPANIA, :P113_APROBADOR, V_TIPO, :P113_DOCUMENTO);',
'        :P113_USUARIO := :P113_APROBADOR;',
'        ',
'    END IF;',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>106107868783260242
);
wwv_flow_imp.component_end;
end;
/
