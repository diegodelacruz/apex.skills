prompt --application/pages/page_00402
begin
--   Manifest
--     PAGE: 00402
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>109
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_page.create_page(
 p_id=>402
,p_name=>'DOCUMENTOS ELECTRONICOS - DLG - EDITAR'
,p_alias=>'DOCUMENTOS-ELECTRONICOS-FORMATOS-XML-EDITAR'
,p_page_mode=>'MODAL'
,p_step_title=>'&P402_TITULO.'
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'OFF'
,p_javascript_code_onload=>'$(secItems).hide();'
,p_step_template=>wwv_flow_imp.id(37774372912106498)
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'16'
,p_created_on=>wwv_flow_imp.dz('20240520133702Z')
,p_last_updated_on=>wwv_flow_imp.dz('20240607161511Z')
,p_last_updated_by=>'EMASABANDA'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(172249860820747020)
,p_plug_name=>'Items'
,p_region_name=>'secItems'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(38289867500120143)
,p_plug_display_sequence=>50
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(172266951156897303)
,p_plug_name=>'FORMATOS XML EDITAR'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(38289867500120143)
,p_plug_display_sequence=>20
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT  ID, IDORIGEN, DESCRIPCION, TIPODOCUMENTOSRI, TIPODOCUMENTOERP, tramaversion,tramaxml FROM T_FINZ_FORMATO_XML ',
'where id=:P402_ID'))
,p_is_editable=>true
,p_edit_operations=>'i:u:d'
,p_lost_update_check_type=>'VALUES'
,p_plug_source_type=>'NATIVE_FORM'
,p_ajax_items_to_submit=>'P402_ID'
,p_plug_read_only_when_type=>'EXPRESSION'
,p_plug_read_only_when=>':P402_TIPO not in(1,4)'
,p_plug_read_only_when2=>'PLSQL'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(173122311650025021)
,p_plug_name=>'Formatos XML Editar Etiquetas'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(38289867500120143)
,p_plug_display_sequence=>40
,p_plug_display_condition_type=>'EXPRESSION'
,p_plug_display_when_condition=>':P402_TIPO in (2,3)'
,p_plug_display_when_cond2=>'PLSQL'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(173675571638313504)
,p_plug_name=>'Barra de Botones'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(38290276266120143)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_03'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(172270120239897315)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(173675571638313504)
,p_button_name=>'Salir'
,p_button_static_id=>'btnAtras'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--primary:t-Button--simple'
,p_button_template_id=>wwv_flow_imp.id(37860181880106559)
,p_button_image_alt=>'Salir'
,p_button_alignment=>'RIGHT'
,p_icon_css_classes=>'fa-arrow-left'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(172271161752897316)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(173675571638313504)
,p_button_name=>'Grabar'
,p_button_static_id=>'btnGrabar'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--primary:t-Button--simple'
,p_button_template_id=>wwv_flow_imp.id(37860181880106559)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Grabar'
,p_button_alignment=>'RIGHT'
,p_icon_css_classes=>'fa-save'
,p_database_action=>'UPDATE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(172250769843747029)
,p_name=>'P402_TIPO'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(172249860820747020)
,p_prompt=>'Tipo'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(172250838438747030)
,p_name=>'P402_TRAMAVERSION'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(172266951156897303)
,p_item_source_plug_id=>wwv_flow_imp.id(172266951156897303)
,p_prompt=>unistr('Versi\00F3n')
,p_placeholder=>'0.0.0'
,p_source=>'TRAMAVERSION'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_cMaxlength=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_attribute_06=>'UPPER'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(172251500793747037)
,p_name=>'P402_TRAMAXML'
,p_data_type=>'CLOB'
,p_source_data_type=>'CLOB'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(172266951156897303)
,p_item_source_plug_id=>wwv_flow_imp.id(172266951156897303)
,p_prompt=>'Trama XML'
,p_source=>'TRAMAXML'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_MARKDOWN_EDITOR'
,p_display_when=>':P402_TIPO in(1,4)'
,p_display_when2=>'PLSQL'
,p_display_when_type=>'EXPRESSION'
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'SIMPLE'
,p_attribute_02=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20240607161511Z')
,p_updated_by=>'EMASABANDA'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(172267367217897304)
,p_name=>'P402_ID'
,p_source_data_type=>'NUMBER'
,p_is_primary_key=>true
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(172249860820747020)
,p_item_source_plug_id=>wwv_flow_imp.id(172266951156897303)
,p_prompt=>'Id'
,p_source=>'ID'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(172267746807897310)
,p_name=>'P402_DESCRIPCION'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(172266951156897303)
,p_item_source_plug_id=>wwv_flow_imp.id(172266951156897303)
,p_prompt=>unistr('Descripci\00F3n')
,p_source=>'DESCRIPCION'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>32
,p_cMaxlength=>300
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_attribute_06=>'UPPER'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(172268105016897313)
,p_name=>'P402_TIPODOCUMENTOSRI'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(172266951156897303)
,p_item_source_plug_id=>wwv_flow_imp.id(172266951156897303)
,p_prompt=>'Documento SRI'
,p_source=>'TIPODOCUMENTOSRI'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'LOV_UDC_DOCE'
,p_lov=>'SELECT DESCRIPCION, VALOR FROM vt_finz_udc_documentossri order by ID_CABECERA, ID_TABLA;'
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(172268545163897313)
,p_name=>'P402_TIPODOCUMENTOERP'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(172266951156897303)
,p_item_source_plug_id=>wwv_flow_imp.id(172266951156897303)
,p_prompt=>'Documento ZM'
,p_source=>'TIPODOCUMENTOERP'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'LOV_UDC_DOJDE'
,p_lov=>'SELECT DESCRIPCION, VALOR FROM vt_finz_udc_documentosjde order by ID_CABECERA, ID_TABLA;'
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(173122146753025019)
,p_name=>'P402_ETQID'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(172249860820747020)
,p_prompt=>'P402_ETQID'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(173122459980025022)
,p_name=>'P402_ETIQUETATIPO'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(173122311650025021)
,p_prompt=>'Tipo Etiqueta'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'LOV_UDC_DOCTIPO'
,p_lov=>'SELECT DESCRIPCION, VALOR FROM vt_finz_udc_doce_tipoetiqueta  order by ID_CABECERA, ID_TABLA;'
,p_cHeight=>1
,p_read_only_when=>'P402_ETIQUETASTANDAR'
,p_read_only_when2=>'1'
,p_read_only_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(173122501842025023)
,p_name=>'P402_ETIQUETADESCRIPCION'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(173122311650025021)
,p_prompt=>unistr('Descripci\00F3n')
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(173122639259025024)
,p_name=>'P402_ETIQUETAOBJETOLECTURA'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(173122311650025021)
,p_prompt=>'Objeto Lectura'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'LOV_UDC_DOCOR'
,p_lov=>'SELECT DESCRIPCION, VALOR FROM vt_finz_udc_doce_origendatos order by TO_NUMBER(ID_TABLA);'
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_updated_on=>wwv_flow_imp.dz('20240607161234Z')
,p_updated_by=>'EMASABANDA'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(173122746708025025)
,p_name=>'P402_ETIQUETACAMPOLECTURA'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(173122311650025021)
,p_prompt=>'Campo Lectura'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ',
'       col.column_name decripcion, ',
'       col.column_name valor',
'from sys.all_tab_columns@datadl col',
'where 1=1',
'and col.table_name = :P402_ETIQUETAOBJETOLECTURA',
'order by col.owner, col.table_name, col.column_id;',
''))
,p_lov_cascade_parent_items=>'P402_ETIQUETAOBJETOLECTURA'
,p_ajax_items_to_submit=>'P402_ETIQUETAOBJETOLECTURA'
,p_ajax_optimize_refresh=>'Y'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'POPUP'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_04=>'N'
,p_attribute_05=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(173122849714025026)
,p_name=>'P402_ETIQUETAIMPRESION'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_imp.id(173122311650025021)
,p_prompt=>unistr('Impresi\00F3n')
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'LOV_UDC_DOCIMP'
,p_lov=>'SELECT DESCRIPCION, VALOR FROM vt_finz_udc_doce_tipoimpresion order by ID_CABECERA, ID_TABLA;'
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(173122935960025027)
,p_name=>'P402_ETIQUETANIVEL'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(173122311650025021)
,p_prompt=>'Nivel'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'with lvl as (SELECT LEVEL-1 AS id ,LEVEL-1 AS NIVEL  FROM dual CONNECT BY LEVEL <=20 )',
'select nivel ||'' ''||',
'case when :P402_COLOCAR<0 then ''Etiqueta Mismo Nivel'' ',
'else case when :P402_COLOCAR>0 ',
'    then ',
'        decode(nivel,:P402_ETIQUETANIVEL,''Etiqueta Mismo Nivel'',:P402_ETIQUETANIVEL+1,''Etiqueta Nivel Hija'')',
'    end',
'end nivel , id ',
'from lvl where',
'(nvl(:P402_COLOCAR,0)=0 and NIVEL = :P402_ETIQUETANIVEL)',
'or ',
'(:P402_COLOCAR<0 and NIVEL = :P402_ETIQUETANIVEL)',
'or ',
'(:P402_COLOCAR>0 and NIVEL BETWEEN :P402_ETIQUETANIVEL and :P402_ETIQUETANIVEL+1)',
'',
'',
''))
,p_cHeight=>1
,p_display_when=>':P402_ETIQUETASTANDAR=0'
,p_display_when2=>'PLSQL'
,p_display_when_type=>'EXPRESSION'
,p_read_only_when=>'nvl(:P402_COLOCAR,0)<=0 and :P402_ETIQUETASTANDAR>0'
,p_read_only_when2=>'PLSQL'
,p_read_only_when_type=>'EXPRESSION'
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(173123055414025028)
,p_name=>'P402_ETIQUETAORDEN'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(172249860820747020)
,p_prompt=>'Orden'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_read_only_when_type=>'ALWAYS'
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(173123179129025029)
,p_name=>'P402_ETIQUETASTANDAR'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(173122311650025021)
,p_prompt=>'Estandar'
,p_display_as=>'NATIVE_SINGLE_CHECKBOX'
,p_cattributes_element=>'style="color:red;"'
,p_begin_on_new_line=>'N'
,p_read_only_when_type=>'ALWAYS'
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'1'
,p_attribute_03=>'0'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(173123231954025030)
,p_name=>'P402_ETIQUETANOMBRE'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(173122311650025021)
,p_prompt=>'Nombre'
,p_placeholder=>'1.- <nomberetq/>       2.- <nomberetq>    3.- </nomberetq> '
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_cattributes_element=>'style="color:red" title="Ejemplo: 1.- <nomberetq/> 2.- <nomberetq>    3.- </nomberetq> "'
,p_read_only_when=>'P402_ETIQUETASTANDAR'
,p_read_only_when2=>'1'
,p_read_only_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(173124224327025040)
,p_name=>'P402_COLOCAR'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(172249860820747020)
,p_prompt=>'Colocar'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(173125062527025048)
,p_name=>'P402_PAGINA'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(172249860820747020)
,p_prompt=>'Pagina'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(173676739800313516)
,p_name=>'P402_ETIQUETASECCION'
,p_item_sequence=>120
,p_item_plug_id=>wwv_flow_imp.id(173122311650025021)
,p_prompt=>unistr('Secci\00F3n')
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'LOV_UDC_DOCSEC'
,p_lov=>'select ID_CABECERA, ID_TABLA, VALOR, DESCRIPCION, DESCRIPCION3, VALOR2, ACTIVO from vt_finz_udc_doce_seccionetiqueta ;'
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(173678077870313529)
,p_name=>'P402_IDORIGEN'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(172249860820747020)
,p_item_source_plug_id=>wwv_flow_imp.id(172266951156897303)
,p_prompt=>'Idorigen'
,p_source=>'IDORIGEN'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'left'
,p_attribute_04=>'decimal'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(173680011443313549)
,p_name=>'P402_TITULO'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(172249860820747020)
,p_prompt=>'Titulo'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(176225875126946901)
,p_name=>'P402_GRABADO'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(172249860820747020)
,p_prompt=>'Grabado'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(176229327583946936)
,p_name=>'P402_EMPTY'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(173122311650025021)
,p_prompt=>'Empty'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_display_when=>':P402_ETIQUETASTANDAR=0'
,p_display_when2=>'PLSQL'
,p_display_when_type=>'EXPRESSION'
,p_field_template=>wwv_flow_imp.id(37859379436106556)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(190569415665919533)
,p_name=>'P402_ESTADO'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(172266951156897303)
,p_prompt=>'Estado'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'LOV_ESTADO'
,p_lov=>'.'||wwv_flow_imp.id(103334473958064327)||'.'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'NONE'
,p_updated_on=>wwv_flow_imp.dz('20240607161511Z')
,p_updated_by=>'EMASABANDA'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(198204584736087905)
,p_name=>'P402_ETIQUETASECCIONORD'
,p_item_sequence=>130
,p_item_plug_id=>wwv_flow_imp.id(173122311650025021)
,p_prompt=>unistr('\00D3rden en Secci\00F3n')
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT  LEVEL -1 AS D , LEVEL-1 AS R',
'FROM dual',
'CONNECT BY level < 14'))
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(198204713894087907)
,p_name=>'P402_EMPTY_1'
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_imp.id(173122311650025021)
,p_prompt=>'Empty'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(37859379436106556)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(172248728876747009)
,p_validation_name=>'DESCRIPCION no vacio'
,p_validation_sequence=>10
,p_validation=>'P402_DESCRIPCION'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>'#LABEL# debe tener un valor'
,p_when_button_pressed=>wwv_flow_imp.id(172271161752897316)
,p_associated_item=>wwv_flow_imp.id(172267746807897310)
,p_error_display_location=>'INLINE_WITH_FIELD'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(172248845237747010)
,p_validation_name=>'TIPODOCUMENTOSRI no vacio'
,p_validation_sequence=>20
,p_validation=>'P402_TIPODOCUMENTOSRI'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>'#LABEL# debe tener un valor'
,p_validation_condition=>'P402_TIPO'
,p_validation_condition2=>'1'
,p_validation_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_when_button_pressed=>wwv_flow_imp.id(172271161752897316)
,p_associated_item=>wwv_flow_imp.id(172268105016897313)
,p_error_display_location=>'INLINE_WITH_FIELD'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(173677848211313527)
,p_validation_name=>'TIPODOCUMENTOERP no vacio'
,p_validation_sequence=>30
,p_validation=>'P402_TIPODOCUMENTOERP'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>'#LABEL# debe tener un valor'
,p_validation_condition=>':P402_TIPO!=1 AND :P402_IDORIGEN IS NOT NULL'
,p_validation_condition2=>'PLSQL'
,p_validation_condition_type=>'EXPRESSION'
,p_when_button_pressed=>wwv_flow_imp.id(172271161752897316)
,p_associated_item=>wwv_flow_imp.id(172268545163897313)
,p_error_display_location=>'INLINE_WITH_FIELD'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(172250936659747031)
,p_validation_name=>'VERSION no vacio'
,p_validation_sequence=>40
,p_validation=>'P402_TRAMAVERSION'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>'#LABEL# debe tener un valor'
,p_when_button_pressed=>wwv_flow_imp.id(172271161752897316)
,p_associated_item=>wwv_flow_imp.id(172250838438747030)
,p_error_display_location=>'INLINE_WITH_FIELD'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(173677981602313528)
,p_validation_name=>'TRAMAXML no vacio'
,p_validation_sequence=>50
,p_validation=>'P402_TRAMAXML'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>'#LABEL# debe tener un valor'
,p_validation_condition=>'P402_TIPO'
,p_validation_condition2=>'1'
,p_validation_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_when_button_pressed=>wwv_flow_imp.id(172271161752897316)
,p_associated_item=>wwv_flow_imp.id(172251500793747037)
,p_error_display_location=>'INLINE_WITH_FIELD'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(173678886130313537)
,p_validation_name=>'OBJETOLECTURA no vacio'
,p_validation_sequence=>70
,p_validation=>'P402_ETIQUETAOBJETOLECTURA'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>'#LABEL# debe tener un valor'
,p_validation_condition=>':P402_ETIQUETATIPO=2  and :P402_ETIQUETAIMPRESION >0'
,p_validation_condition2=>'PLSQL'
,p_validation_condition_type=>'EXPRESSION'
,p_when_button_pressed=>wwv_flow_imp.id(172271161752897316)
,p_associated_item=>wwv_flow_imp.id(173122639259025024)
,p_error_display_location=>'INLINE_WITH_FIELD'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(173678948678313538)
,p_validation_name=>'ETIQUETACAMPOLECTURA'
,p_validation_sequence=>80
,p_validation=>'P402_ETIQUETACAMPOLECTURA'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>'#LABEL# debe tener un valor'
,p_validation_condition=>':P402_ETIQUETATIPO=2  and :P402_ETIQUETAIMPRESION >0'
,p_validation_condition2=>'PLSQL'
,p_validation_condition_type=>'EXPRESSION'
,p_when_button_pressed=>wwv_flow_imp.id(172271161752897316)
,p_associated_item=>wwv_flow_imp.id(173122746708025025)
,p_error_display_location=>'INLINE_WITH_FIELD'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(198204969354087909)
,p_validation_name=>'ETIQUETASECCIONORD no cero'
,p_validation_sequence=>90
,p_validation=>'P402_ETIQUETASECCIONORD'
,p_validation_type=>'ITEM_NOT_NULL_OR_ZERO'
,p_error_message=>'#LABEL# debe tener un valor'
,p_validation_condition=>':P402_ETIQUETATIPO=2  and :P402_ETIQUETAIMPRESION >0 and :P402_ETIQUETASECCION!='''''
,p_validation_condition2=>'PLSQL'
,p_validation_condition_type=>'EXPRESSION'
,p_when_button_pressed=>wwv_flow_imp.id(172271161752897316)
,p_associated_item=>wwv_flow_imp.id(198204584736087905)
,p_error_display_location=>'INLINE_WITH_FIELD'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(173678591644313534)
,p_name=>'CambioTipo'
,p_event_sequence=>10
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P402_ETIQUETATIPO'
,p_condition_element=>'P402_ETIQUETATIPO'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'2'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(173678795363313536)
,p_event_id=>wwv_flow_imp.id(173678591644313534)
,p_event_result=>'FALSE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P402_ETIQUETAOBJETOLECTURA,P402_ETIQUETACAMPOLECTURA'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(174943059202158950)
,p_event_id=>wwv_flow_imp.id(173678591644313534)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P402_ETIQUETACAMPOLECTURA,P402_ETIQUETAOBJETOLECTURA'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(176229029929946933)
,p_name=>'New'
,p_event_sequence=>20
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P402_ETIQUETAIMPRESION'
,p_triggering_condition_type=>'JAVASCRIPT_EXPRESSION'
,p_triggering_expression=>'$v("P402_ETIQUETAIMPRESION")==1 || $v("P402_ETIQUETAIMPRESION")==3'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(176229113318946934)
,p_event_id=>wwv_flow_imp.id(176229029929946933)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P402_ETIQUETASECCION,P402_ETIQUETASECCIONORD'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(176229244289946935)
,p_event_id=>wwv_flow_imp.id(176229029929946933)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P402_ETIQUETASECCION,P402_ETIQUETASECCIONORD'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(190569519939919534)
,p_name=>'tipo1'
,p_event_sequence=>30
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P402_TIPO'
,p_condition_element=>'P402_TIPO'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'1'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(190569617674919535)
,p_event_id=>wwv_flow_imp.id(190569519939919534)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P402_TIPODOCUMENTOSRI,P402_TRAMAXML'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(190569799579919536)
,p_event_id=>wwv_flow_imp.id(190569519939919534)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P402_TIPODOCUMENTOSRI,P402_TRAMAXML'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(190569811647919537)
,p_name=>'tipo dif_1'
,p_event_sequence=>40
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P402_TIPO'
,p_triggering_condition_type=>'JAVASCRIPT_EXPRESSION'
,p_triggering_expression=>'$v("P402_TIPO")!=1 && $v("P402_IDORIGEN") !=""'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(190569999456919538)
,p_event_id=>wwv_flow_imp.id(190569811647919537)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P402_TIPODOCUMENTOERP'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(190570188536919540)
,p_event_id=>wwv_flow_imp.id(190569811647919537)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P402_TIPODOCUMENTOERP'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(173675499848313503)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_CLOSE_WINDOW'
,p_process_name=>'Close Dialog'
,p_attribute_02=>'N'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(172270120239897315)
,p_internal_uid=>173675499848313503
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(172272615051897322)
,p_process_sequence=>30
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Process form DOCUMENTOS ELETRONICOS - FORMATOS XML EDITAR'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare ',
'v_accion varchar2(5);',
'v_mensaje varchar2(3999);',
'',
'begin ',
'    :P402_GRABADO:=1;',
'    if (:p402_tipo IN (1,4)) then',
'        pk_finz_sri_gestion.          sp_inserupdateforamtoxml(:p402_id,:p402_descripcion,:p402_tipodocumentosri,:p402_tipodocumentoerp,:p402_tramaversion, :p402_tramaxml,v_mensaje,:P402_ESTADO);',
'        if(v_mensaje is not null)then',
'            apex_error.add_error (',
'            p_message          => v_mensaje,',
'            p_display_location =>apex_error.c_inline_in_notification ,',
'            p_page_item_name   => ''P402_TIPODOCUMENTOSRI'');',
'            :P402_GRABADO:=0;',
'        end if;',
'    elsif(:p402_tipo in (2,3)) then',
'        if (nvl(trim(:P402_ETIQUETAIMPRESION),0)=0 ) then ',
'            :P402_ETIQUETASECCION:=null;',
'            :p402_etiquetaobjetolectura:=null;',
'            :p402_etiquetacampolectura:=null;',
'            :p402_etiquetadescripcion:='''';',
'        end if;',
'        if (trim(:P402_ETIQUETASECCION) is null) then :P402_ETIQUETASECCIONORD:=0;end if;',
'        pk_finz_sri_gestion.sp_insertupdateetiquetasformatoxml(:p402_id,:p402_etiquetanombre,replace(:p402_etiquetaorden,'','',''.''),:p402_etiquetanivel,:p402_etiquetatipo,:p402_etiquetadescripcion,:p402_etiquetaimpresion,:p402_etiquetaobjetolectura,:p4'
||'02_etiquetacampolectura,:p402_etiquetastandar,:P402_ETIQUETASECCION,:P402_ETIQUETASECCIONORD);',
'    end if;',
'end;',
''))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(172271161752897316)
,p_process_success_message=>'Datos almacenados correctamente'
,p_internal_uid=>172272615051897322
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(173676257115313511)
,p_process_sequence=>40
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_CLOSE_WINDOW'
,p_process_name=>'Close Dialog_1'
,p_attribute_02=>'N'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(172271161752897316)
,p_process_when=>'P402_GRABADO'
,p_process_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_process_when2=>'1'
,p_internal_uid=>173676257115313511
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(172249438527747016)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'SetupPage'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
'    begin',
'        SELECT ',
'                IDORIGEN, DESCRIPCION, TIPODOCUMENTOSRI, TIPODOCUMENTOERP, TRAMAVERSION,TRAMAXML, ESTADO',
'        INTO    :P402_IDORIGEN,:P402_DESCRIPCION,:P402_TIPODOCUMENTOSRI,:P402_TIPODOCUMENTOERP,:P402_TRAMAVERSION,:P402_TRAMAXML,:P402_ESTADO',
'        FROM T_FINZ_FORMATO_XML',
'        WHERE ID = :P402_ID;',
'    EXCEPTION WHEN OTHERS THEN',
'     :P402_IDORIGEN:=null;:P402_DESCRIPCION:=null;:P402_TIPODOCUMENTOSRI:=null;:P402_TIPODOCUMENTOERP:=null;:P402_TRAMAVERSION:=null;:P402_TRAMAXML:=null;:P402_ESTADO:=NULL;',
'    END;',
'    ',
'            SELECT  decode(:P402_TIPO,3,(:P402_COLOCAR/2),0)+ORD,                NIV, decode(:P402_TIPO,3,'' '',ETQ)ETQ,               TIP,decode(:P402_TIPO,3,'' '',DES)DES,                    IMP,                        LEC,                       CAM,de'
||'code(:P402_TIPO,3,0,STD)STA,     NVL(sec,'' '')sec,                    sor',
'            INTO                            :P402_ETIQUETAORDEN,:P402_ETIQUETANIVEL,            :P402_ETIQUETANOMBRE,:P402_ETIQUETATIPO,      :P402_ETIQUETADESCRIPCION,:P402_ETIQUETAIMPRESION,:P402_ETIQUETAOBJETOLECTURA,:P402_ETIQUETACAMPOLECTURA,   '
||'     :P402_ETIQUETASTANDAR,:P402_ETIQUETASECCION,:P402_ETIQUETASECCIONORD',
'            FROM TABLE( PK_FINZ_SRI_GESTION.f_infoetiqueta(:P402_ID))',
'            WHERE 1=1 and ORD>0 AND  ETQID= :P402_ETQID;',
'EXCEPTION WHEN OTHERS THEN',
'    NULL;',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>172249438527747016
);
wwv_flow_imp.component_end;
end;
/
