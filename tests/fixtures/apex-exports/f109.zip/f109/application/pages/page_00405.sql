prompt --application/pages/page_00405
begin
--   Manifest
--     PAGE: 00405
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>109
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_page.create_page(
 p_id=>405
,p_name=>'DOCUMENTOS ELECTRONICOS - PAG - APROBAR DOCUMENTO JDE'
,p_alias=>'DOCUMENTOS-ELECTRONICOS-PAG-APROBAR-DOCUMENTO-JDE'
,p_step_title=>'APROBAR DOCUMENTO JDE'
,p_autocomplete_on_off=>'OFF'
,p_javascript_code_onload=>'//$(secItems).hide();'
,p_step_template=>wwv_flow_imp.id(37767916443106493)
,p_page_template_options=>'#DEFAULT#'
,p_page_is_public_y_n=>'Y'
,p_page_component_map=>'17'
,p_created_on=>wwv_flow_imp.dz('20240520133703Z')
,p_last_updated_on=>wwv_flow_imp.dz('20240614161317Z')
,p_last_updated_by=>'EMASABANDA'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(190567660926919515)
,p_plug_name=>'items'
,p_region_name=>'secItems'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(38289867500120143)
,p_plug_display_sequence=>40
,p_include_in_reg_disp_sel_yn=>'Y'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(176230393480946946)
,p_name=>'P405_NUMERODOCUMENTO'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(190567660926919515)
,p_prompt=>'Numerodocumento'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(176230589303946948)
,p_name=>'P405_TIPODOCUMENTO'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(190567660926919515)
,p_prompt=>'Tipodocumento'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(190568159863919520)
,p_name=>'P405_TERMINA'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(190567660926919515)
,p_prompt=>'Termina'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(190568478142919523)
,p_name=>'New'
,p_event_sequence=>10
,p_condition_element=>'P405_TERMINA'
,p_triggering_condition_type=>'NOT_NULL'
,p_bind_type=>'bind'
,p_bind_event_type=>'ready'
,p_updated_on=>wwv_flow_imp.dz('20240521160038Z')
,p_updated_by=>'JBALCAZAR'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(190568552008919524)
,p_event_id=>wwv_flow_imp.id(190568478142919523)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'window.close();'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(190568025948919519)
,p_process_sequence=>10
,p_process_point=>'AFTER_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Procesar'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'    DECLARE',
'      P_TIPODOCUMENTO VARCHAR2(200);',
'      P_CODDOCUMENTO VARCHAR2(200);',
'    BEGIN ',
'        :P405_TERMINA:=NULL;',
'        P_TIPODOCUMENTO := :P405_TIPODOCUMENTO;',
'        P_CODDOCUMENTO  := :P405_NUMERODOCUMENTO;',
'        PK_CORP_COMMONS.SP_ASYNC('' PK_FINZ_SRI_AUTORIZACION.sp_documento_jde_aprobar(',
'            P_TIPODOCUMENTO => ''''''||P_TIPODOCUMENTO||'''''',',
'            P_CODDOCUMENTO => ''||P_CODDOCUMENTO||'',',
'            p_imprime => 1,',
'            p_notifica =>1',
'        );'');',
'',
'',
'',
'        ---commit;',
'        :P405_TERMINA:=1;',
'       -- APEX_UTIL.REDIRECT_URL(p_url => ''javascript:window.close();'');',
'    --EXCEPTION WHEN OTHERS THEN',
'    --    :P405_TERMINA:=3;',
'    END;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>190568025948919519
,p_updated_on=>wwv_flow_imp.dz('20240614161317Z')
,p_updated_by=>'EMASABANDA'
);
wwv_flow_imp.component_end;
end;
/
