prompt --application/pages/page_00600
begin
--   Manifest
--     PAGE: 00600
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>109
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_page.create_page(
 p_id=>600
,p_name=>'Mesa de trabajo - Cierre'
,p_alias=>'MESA-DE-TRABAJO-CIERRE1'
,p_step_title=>'Mesa de trabajo - Cierre'
,p_autocomplete_on_off=>'OFF'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'/* Estado Verde (0%) - Borde inferior sutil o normal */',
'.tab-success a { ',
'    border-bottom: 3px solid #28a745 !important; ',
'}',
'.tab-success .a-RDS-label { color: #28a745 !important; font-weight: bold; }',
'',
'/* Estado Naranja (1% - 40%) */',
'.tab-warning a { ',
'    border-bottom: 3px solid #ffc107 !important; ',
'}',
'.tab-warning .a-RDS-label { color: #e6a700 !important; font-weight: bold; }',
'',
'/* Estado Rojo (> 40%) */',
'.tab-danger a { ',
'    border-bottom: 3px solid #dc3545 !important; ',
'}',
'.tab-danger .a-RDS-label { color: #dc3545 !important; font-weight: bold; }'))
,p_page_template_options=>'#DEFAULT#'
,p_page_component_map=>'03'
,p_last_updated_on=>wwv_flow_imp.dz('20260604182011Z')
,p_last_updated_by=>'JBALCAZAR'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(422130609559564049)
,p_plug_name=>'Barra de accion'
,p_region_template_options=>'#DEFAULT#:t-Form--stretchInputs'
,p_plug_template=>wwv_flow_imp.id(38289497777120142)
,p_plug_display_sequence=>20
,p_plug_display_point=>'REGION_POSITION_01'
,p_location=>null
,p_ai_enabled=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(424841437095598556)
,p_plug_name=>'VARIABLES'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_region_attributes=>'style="display:none"'
,p_plug_template=>wwv_flow_imp.id(38289867500120143)
,p_plug_display_sequence=>20
,p_location=>null
,p_ai_enabled=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(436643424875448356)
,p_plug_name=>'Ventas'
,p_parent_plug_id=>wwv_flow_imp.id(424841437095598556)
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(38289867500120143)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_location=>null
,p_ai_enabled=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(436643509338448357)
,p_plug_name=>'Compras'
,p_parent_plug_id=>wwv_flow_imp.id(424841437095598556)
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(38289867500120143)
,p_plug_display_sequence=>20
,p_plug_display_point=>'SUB_REGIONS'
,p_location=>null
,p_ai_enabled=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(436643634440448358)
,p_plug_name=>'Activos fijos'
,p_parent_plug_id=>wwv_flow_imp.id(424841437095598556)
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(38289867500120143)
,p_plug_display_sequence=>110
,p_plug_display_point=>'SUB_REGIONS'
,p_location=>null
,p_ai_enabled=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(436643750989448359)
,p_plug_name=>unistr('Log\00EDstica PT')
,p_parent_plug_id=>wwv_flow_imp.id(424841437095598556)
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(38289867500120143)
,p_plug_display_sequence=>80
,p_plug_display_point=>'SUB_REGIONS'
,p_location=>null
,p_ai_enabled=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(436643827137448360)
,p_plug_name=>unistr('Producci\00F3n Absorbente')
,p_parent_plug_id=>wwv_flow_imp.id(424841437095598556)
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(38289867500120143)
,p_plug_display_sequence=>30
,p_plug_display_point=>'SUB_REGIONS'
,p_location=>null
,p_ai_enabled=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(436643892151448361)
,p_plug_name=>'Contabilidad'
,p_parent_plug_id=>wwv_flow_imp.id(424841437095598556)
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(38289867500120143)
,p_plug_display_sequence=>120
,p_plug_display_point=>'SUB_REGIONS'
,p_location=>null
,p_ai_enabled=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(436922573206209333)
,p_plug_name=>unistr('Producci\00F3n Envases')
,p_parent_plug_id=>wwv_flow_imp.id(424841437095598556)
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(38289867500120143)
,p_plug_display_sequence=>70
,p_plug_display_point=>'SUB_REGIONS'
,p_location=>null
,p_ai_enabled=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(436924709780209355)
,p_plug_name=>unistr('Tesorer\00EDa')
,p_parent_plug_id=>wwv_flow_imp.id(424841437095598556)
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(38289867500120143)
,p_plug_display_sequence=>150
,p_plug_display_point=>'SUB_REGIONS'
,p_location=>null
,p_ai_enabled=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(436925376103209361)
,p_plug_name=>'RRHH'
,p_parent_plug_id=>wwv_flow_imp.id(424841437095598556)
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(38289867500120143)
,p_plug_display_sequence=>190
,p_plug_display_point=>'SUB_REGIONS'
,p_location=>null
,p_ai_enabled=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(438211108536625022)
,p_plug_name=>'Cuentas x Pagar'
,p_parent_plug_id=>wwv_flow_imp.id(424841437095598556)
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(38289867500120143)
,p_plug_display_sequence=>130
,p_plug_display_point=>'SUB_REGIONS'
,p_location=>null
,p_ai_enabled=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(438212304384625034)
,p_plug_name=>unistr('Producci\00F3n Cosm\00E9tica')
,p_parent_plug_id=>wwv_flow_imp.id(424841437095598556)
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(38289867500120143)
,p_plug_display_sequence=>40
,p_plug_display_point=>'SUB_REGIONS'
,p_location=>null
,p_ai_enabled=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(438214713926625058)
,p_plug_name=>'Transformaciones'
,p_parent_plug_id=>wwv_flow_imp.id(424841437095598556)
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(38289867500120143)
,p_plug_display_sequence=>60
,p_plug_display_point=>'SUB_REGIONS'
,p_location=>null
,p_ai_enabled=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(440529556642634217)
,p_plug_name=>unistr('Log\00EDstica MP')
,p_parent_plug_id=>wwv_flow_imp.id(424841437095598556)
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(38289867500120143)
,p_plug_display_sequence=>90
,p_plug_display_point=>'SUB_REGIONS'
,p_location=>null
,p_ai_enabled=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(440529673311634218)
,p_plug_name=>unistr('Log\00EDstica BDG Menores')
,p_parent_plug_id=>wwv_flow_imp.id(424841437095598556)
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(38289867500120143)
,p_plug_display_sequence=>100
,p_plug_display_point=>'SUB_REGIONS'
,p_location=>null
,p_ai_enabled=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(443733498808602326)
,p_plug_name=>'Cuentas x Pagar (Colaboradores)'
,p_parent_plug_id=>wwv_flow_imp.id(424841437095598556)
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(38289867500120143)
,p_plug_display_sequence=>140
,p_plug_display_point=>'SUB_REGIONS'
,p_location=>null
,p_ai_enabled=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(452340916867712944)
,p_plug_name=>'Cuentas x Cobrar'
,p_parent_plug_id=>wwv_flow_imp.id(424841437095598556)
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(38289867500120143)
,p_plug_display_sequence=>160
,p_plug_display_point=>'SUB_REGIONS'
,p_location=>null
,p_ai_enabled=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(452878500315778131)
,p_plug_name=>unistr('Conciliaci\00F3n Bancaria')
,p_parent_plug_id=>wwv_flow_imp.id(424841437095598556)
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(38289867500120143)
,p_plug_display_sequence=>170
,p_plug_display_point=>'SUB_REGIONS'
,p_location=>null
,p_ai_enabled=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(459363599763930629)
,p_plug_name=>'Impuestos'
,p_parent_plug_id=>wwv_flow_imp.id(424841437095598556)
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(38289867500120143)
,p_plug_display_sequence=>180
,p_plug_display_point=>'SUB_REGIONS'
,p_location=>null
,p_ai_enabled=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(428697844435310434)
,p_plug_name=>'Mesa'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(38289867500120143)
,p_plug_display_sequence=>40
,p_location=>null
,p_plug_source_type=>'NATIVE_DISPLAY_SELECTOR'
,p_ai_enabled=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'display_region_icons', 'N',
  'include_show_all', 'N',
  'rds_mode', 'STANDARD',
  'remember_selection', 'SESSION')).to_clob
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(426702785133699053)
,p_name=>'Activos Fijos'
,p_parent_plug_id=>wwv_flow_imp.id(428697844435310434)
,p_template=>wwv_flow_imp.id(38289867500120143)
,p_display_sequence=>130
,p_include_in_reg_disp_sel_yn=>'Y'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_component_template_options=>'#DEFAULT#:u-colors:t-Cards--displaySubtitle:t-Cards--basic:t-Cards--5cols:t-Cards--hideBody:t-Cards--animRaiseCard:t-Report--hideNoPagination'
,p_display_point=>'SUB_REGIONS'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT CONTADOR AS CARD_TITLE, ENLACE   CARD_SUBTITLE , COLOR AS CARD_COLOR,  ORDEN  ',
'FROM (',
'    SELECT TO_NUMBER(:P600_ACFI_1) CONTADOR,',
'        ''<a href="''||',
'        apex_page.get_url(',
'            p_application => 109,',
'            p_page => 603,',
'            p_items => ''P603_ID_REGION,P603_MODULO'',',
'            p_values =>''1,ACTFI''',
unistr('        )||''">''||''12501.01 QUE TENGA FECHA TRANSACCI\00D3N <90 D\00CDAS <span style="color: red;">*</span>''||''</a>'' ENLACE, '),
'        ''#27AE60''COLOR, 1 ORDEN ',
'    FROM DUAL WHERE :P600_ACFI_1 >= 0',
'    UNION ALL',
'    SELECT TO_NUMBER(:P600_ACFI_2) CONTADOR,',
'        ''<a href="''||',
'        apex_page.get_url(',
'            p_application => 109,',
'            p_page => 603,',
'            p_items => ''P603_ID_REGION,P603_MODULO'',',
'            p_values =>''2,ACTFI''',
unistr('        )||''">''||''ACTIVOS FIJOS QUE EST\00C1N PENDIENTES DE ACTIVACI\00D3N <span style="color: red;">*</span>''||''</a>'' ENLACE, '),
'        ''#27AE60''COLOR, 2 ORDEN ',
'    FROM DUAL WHERE :P600_ACFI_2 >= 0',
'    UNION ALL',
'    SELECT TO_NUMBER(:P600_ACFI_3) CONTADOR,',
'        ''<a href="''||',
'        apex_page.get_url(',
'            p_application => 109,',
'            p_page => 603,',
'            p_items => ''P603_ID_REGION,P603_MODULO'',',
'            p_values =>''3,ACTFI''',
unistr('        )||''">''||''DEPRECIACI\00D3N DEL MES REALIZADA <span style="color: red;">*</span>''||''</a>'' ENLACE, '),
'        ''#27AE60''COLOR, 3 ORDEN ',
'    FROM DUAL WHERE :P600_ACFI_3 >= 0',
'    UNION ALL',
'    SELECT TO_NUMBER(:P600_ACFI_4) CONTADOR,',
'        ''<a href="''||',
'        apex_page.get_url(',
'            p_application => 109,',
'            p_page => 603,',
'            p_items => ''P603_ID_REGION,P603_MODULO'',',
'            p_values =>''4,ACTFI''',
unistr('        )||''">''||''DIFERENCIAS DE DEPRECIACI\00D3N Y CONTABLE POR ACTIVO''||''</a>'' ENLACE, '),
'        ''#27AE60''COLOR, 4 ORDEN ',
'    FROM DUAL WHERE :P600_ACFI_4 >= 0',
'    UNION ALL',
'    SELECT TO_NUMBER(:P600_ACFI_5) CONTADOR,',
'        ''<a href="''||',
'        apex_page.get_url(',
'            p_application => 109,',
'            p_page => 603,',
'            p_items => ''P603_ID_REGION,P603_MODULO'',',
'            p_values =>''5,ACTFI''',
'        )||''">''||''ACTIVOS FIJOS QUE NO TENGAN VALOR RESUDIAL EN EL MAESTRO''||''</a>'' ENLACE, ',
'        ''#27AE60''COLOR, 5 ORDEN ',
'    FROM DUAL WHERE :P600_ACFI_5 >= 0',
'    UNION ALL',
'    SELECT TO_NUMBER(:P600_ACFI_6) CONTADOR,',
'        ''<a href="''||',
'        apex_page.get_url(',
'            p_application => 109,',
'            p_page => 603,',
'            p_items => ''P603_ID_REGION,P603_MODULO'',',
'            p_values =>''6,ACTFI''',
unistr('        )||''">''||''ACTIVOS FIJOS QUE NO TENGAN MISMO CENTRO DE COSTOS VS UBICACI\00D3N''||''</a>'' ENLACE, '),
'        ''#27AE60''COLOR, 6 ORDEN ',
'    FROM DUAL WHERE :P600_ACFI_6 >= 0',
'    UNION ALL',
'    SELECT ',
'        TO_NUMBER(:P600_ACFI_1) +',
'        TO_NUMBER(:P600_ACFI_2) +',
'        TO_NUMBER(:P600_ACFI_3) +',
'        TO_NUMBER(:P600_ACFI_4) +',
'        TO_NUMBER(:P600_ACFI_5) +',
'        TO_NUMBER(:P600_ACFI_6)',
'    ',
'        CONTADOR,',
'        ''<a>TOTAL</a>'' ENLACE, ',
'        ''#F95C4C''COLOR, 100 ORDEN ',
'    FROM DUAL',
')',
'ORDER BY ORDEN ASC'))
,p_display_when_condition=>':P600_MODULO_ACTIVO = ''1'' OR INSTR(:P600_MODULO_ACTIVO, ''ACTFI'') > 0'
,p_display_when_cond2=>'PLSQL'
,p_display_condition_type=>'EXPRESSION'
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(37833900716106539)
,p_query_num_rows=>100
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_show_nulls_as=>'-'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
,p_updated_on=>wwv_flow_imp.dz('20260506173110Z')
,p_updated_by=>'JBALCAZAR'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(244443858279546040)
,p_query_column_id=>1
,p_column_alias=>'CARD_TITLE'
,p_column_display_sequence=>10
,p_column_heading=>'Card Title'
,p_use_as_row_header=>'N'
,p_column_html_expression=>'<span style = "color : #CARD_COLOR#"> #CARD_TITLE#</span>'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(244445085085546041)
,p_query_column_id=>2
,p_column_alias=>'CARD_SUBTITLE'
,p_column_display_sequence=>40
,p_column_heading=>'Card Subtitle'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(244444649784546041)
,p_query_column_id=>3
,p_column_alias=>'CARD_COLOR'
,p_column_display_sequence=>30
,p_column_heading=>'Card Color'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(244444215950546040)
,p_query_column_id=>4
,p_column_alias=>'ORDEN'
,p_column_display_sequence=>20
,p_column_heading=>'Orden'
,p_use_as_row_header=>'N'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(428697923322310435)
,p_name=>'Ventas'
,p_parent_plug_id=>wwv_flow_imp.id(428697844435310434)
,p_template=>wwv_flow_imp.id(38289867500120143)
,p_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_component_template_options=>'#DEFAULT#:u-colors:t-Cards--displaySubtitle:t-Cards--basic:t-Cards--spanHorizontally:t-Cards--hideBody:t-Cards--animRaiseCard:t-Report--hideNoPagination'
,p_display_point=>'SUB_REGIONS'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT CONTADOR AS CARD_TITLE, ENLACE   CARD_SUBTITLE , COLOR AS CARD_COLOR,  ORDEN  ',
'FROM (',
'    SELECT TO_NUMBER(:P600_VTAS_1) CONTADOR,',
'        ''<a href="''||',
'        apex_page.get_url(',
'            p_application => 109,',
'            p_page => 603,',
'            p_items => ''P603_ID_REGION,P603_MODULO'',',
'            p_values =>''1,DCO250''',
unistr('        )||''">''||''\00D3RDENES SIN CONTABILIZAR''||''</a>'' ENLACE, '),
'        ''#27AE60''COLOR, 1 ORDEN ',
'    FROM DUAL WHERE :P600_VTAS_1 >= 0',
'    UNION ALL',
'    SELECT TO_NUMBER(:P600_VTAS_2) CONTADOR,',
'        ''<a href="''||',
'        apex_page.get_url(',
'            p_application => 109,',
'            p_page => 603,',
'            p_items => ''P603_ID_REGION,P603_MODULO'',',
'            p_values =>''2,DCO250''',
unistr('        )||''">''||''\00D3RDENES INGRESADAS \00DALTIMO D\00CDA DEL MES <span style="color: red;">*</span>''||''</a>'' ENLACE, '),
'        ''#27AE60''COLOR, 2 ORDEN ',
'    FROM DUAL WHERE :P600_VTAS_2 >= 0',
'    UNION ALL',
'    SELECT TO_NUMBER(:P600_VTAS_3) CONTADOR,',
'        ''<a href="''||',
'        apex_page.get_url(',
'            p_application => 109,',
'            p_page => 603,',
'            p_items => ''P603_ID_REGION,P603_MODULO'',',
'            p_values =>''3,DCO250''',
unistr('        )||''">''||''\00D3RDENES CON DIFERENCIAS DE KARDEX <span style="color: red;">*</span>''||''</a>'' ENLACE, '),
'        ''#27AE60''COLOR, 3 ORDEN ',
'    FROM DUAL WHERE :P600_VTAS_3 >= 0',
'    UNION ALL',
'    SELECT TO_NUMBER(:P600_VTAS_4) CONTADOR,',
'        ''<a href="''||',
'        apex_page.get_url(',
'            p_application => 109,',
'            p_page => 603,',
'            p_items => ''P603_ID_REGION,P603_MODULO'',',
'            p_values =>''4,DCO250''',
unistr('        )||''">''||''\00D3RDENES INGRESADAS M\00C1S DE 48H SIN PROCESAR <span style="color: red;">*</span>''||''</a>'' ENLACE, '),
'        ''#27AE60''COLOR, 4 ORDEN ',
'    FROM DUAL WHERE :P600_VTAS_4 >= 0',
'    UNION ALL',
'    SELECT TO_NUMBER(:P600_VTAS_1)+TO_NUMBER(:P600_VTAS_2)+',
'    TO_NUMBER(:P600_VTAS_3)+TO_NUMBER(:P600_VTAS_4) CONTADOR,',
'        ''<a>TOTAL</a>'' ENLACE, ',
'        ''#F95C4C''COLOR, 5 ORDEN ',
'    FROM DUAL',
')',
'ORDER BY ORDEN ASC'))
,p_display_when_condition=>':P600_MODULO_ACTIVO = ''1'' OR INSTR(:P600_MODULO_ACTIVO, ''DCO250'') > 0'
,p_display_when_cond2=>'PLSQL'
,p_display_condition_type=>'EXPRESSION'
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(37833900716106539)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_show_nulls_as=>'-'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
,p_updated_on=>wwv_flow_imp.dz('20260513175148Z')
,p_updated_by=>'JBALCAZAR'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(244447842758546045)
,p_query_column_id=>1
,p_column_alias=>'CARD_TITLE'
,p_column_display_sequence=>10
,p_column_heading=>'Card Title'
,p_use_as_row_header=>'N'
,p_column_html_expression=>'<span style = "color : #CARD_COLOR#"> #CARD_TITLE#</span>'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(244449007753546046)
,p_query_column_id=>2
,p_column_alias=>'CARD_SUBTITLE'
,p_column_display_sequence=>40
,p_column_heading=>'Card Subtitle'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(244448648920546046)
,p_query_column_id=>3
,p_column_alias=>'CARD_COLOR'
,p_column_display_sequence=>30
,p_column_heading=>'Card Color'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(244448297056546046)
,p_query_column_id=>4
,p_column_alias=>'ORDEN'
,p_column_display_sequence=>20
,p_column_heading=>'Orden'
,p_use_as_row_header=>'N'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(428698513269310441)
,p_name=>'Compras'
,p_parent_plug_id=>wwv_flow_imp.id(428697844435310434)
,p_template=>wwv_flow_imp.id(38289867500120143)
,p_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_component_template_options=>'#DEFAULT#:u-colors:t-Cards--displaySubtitle:t-Cards--basic:t-Cards--spanHorizontally:t-Cards--hideBody:t-Cards--animRaiseCard:t-Report--hideNoPagination'
,p_display_point=>'SUB_REGIONS'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT CONTADOR AS CARD_TITLE, ENLACE   CARD_SUBTITLE , COLOR AS CARD_COLOR,  ORDEN  ',
'FROM (',
'    SELECT TO_NUMBER(:P600_COMP_1) CONTADOR,',
'        ''<a href="''||',
'        apex_page.get_url(',
'            p_application => 109,',
'            p_page => 603,',
'            p_items => ''P603_ID_REGION,P603_MODULO'',',
'            p_values =>''1,DOP356''',
unistr('        )||''">''||''\00D3RDENES PENDIENTES DE RECEPCIONAR''||''</a>'' ENLACE, '),
'        ''#27AE60''COLOR, 1 ORDEN ',
'    FROM DUAL WHERE :P600_COMP_1 >= 0',
'    UNION ALL',
'    SELECT TO_NUMBER(:P600_COMP_2) CONTADOR,',
'        ''<a href="''||',
'        apex_page.get_url(',
'            p_application => 109,',
'            p_page => 603,',
'            p_items => ''P603_ID_REGION,P603_MODULO'',',
'            p_values =>''2,DOP356''',
unistr('        )||''">''||''\00D3RDENES RECEPCIONADAS SIN FACTURA''||''</a>'' ENLACE, '),
'        ''#27AE60''COLOR, 2 ORDEN ',
'    FROM DUAL WHERE :P600_COMP_2 >= 0',
'    UNION ALL',
'    SELECT TO_NUMBER(:P600_COMP_1) + TO_NUMBER(:P600_COMP_2) CONTADOR,',
'        ''<a>TOTAL</a>'' ENLACE, ',
'        ''#F95C4C''COLOR, 5 ORDEN ',
'    FROM DUAL',
')',
'ORDER BY ORDEN ASC'))
,p_display_when_condition=>':P600_MODULO_ACTIVO = ''1'' OR INSTR(:P600_MODULO_ACTIVO, ''DOP356'') > 0'
,p_display_when_cond2=>'PLSQL'
,p_display_condition_type=>'EXPRESSION'
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(37833900716106539)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_show_nulls_as=>'-'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(244441840018546038)
,p_query_column_id=>1
,p_column_alias=>'CARD_TITLE'
,p_column_display_sequence=>10
,p_column_heading=>'Card Title'
,p_use_as_row_header=>'N'
,p_column_html_expression=>'<span style = "color : #CARD_COLOR#"> #CARD_TITLE#</span>'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(244443079705546039)
,p_query_column_id=>2
,p_column_alias=>'CARD_SUBTITLE'
,p_column_display_sequence=>40
,p_column_heading=>'Card Subtitle'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(244442673936546039)
,p_query_column_id=>3
,p_column_alias=>'CARD_COLOR'
,p_column_display_sequence=>30
,p_column_heading=>'Card Color'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(244442291004546039)
,p_query_column_id=>4
,p_column_alias=>'ORDEN'
,p_column_display_sequence=>20
,p_column_heading=>'Orden'
,p_use_as_row_header=>'N'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(428699005971310446)
,p_name=>unistr('Producci\00F3n Absorbente')
,p_parent_plug_id=>wwv_flow_imp.id(428697844435310434)
,p_template=>wwv_flow_imp.id(38289867500120143)
,p_display_sequence=>30
,p_include_in_reg_disp_sel_yn=>'Y'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_component_template_options=>'#DEFAULT#:u-colors:t-Cards--displaySubtitle:t-Cards--basic:t-Cards--5cols:t-Cards--hideBody:t-Cards--animRaiseCard:t-Report--hideNoPagination'
,p_display_point=>'SUB_REGIONS'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT CONTADOR AS CARD_TITLE, ENLACE   CARD_SUBTITLE , COLOR AS CARD_COLOR,  ORDEN  ',
'FROM (',
'    SELECT TO_NUMBER(:P600_PRAB_1) CONTADOR,',
'        ''<a href="''||',
'        apex_page.get_url(',
'            p_application => 109,',
'            p_page => 603,',
'            p_items => ''P603_ID_REGION,P603_MODULO'',',
'            p_values =>''1,DMA430''',
unistr('        )||''">''||''CIERRE DE PRODUCCI\00D3N VS DOCUMENTO <span style="color: red;">*</span>''||''</a>'' ENLACE, '),
'        ''#27AE60''COLOR, 1 ORDEN ',
'    FROM DUAL WHERE :P600_PRAB_1 >= 0',
'    UNION ALL',
'    SELECT TO_NUMBER(:P600_PRAB_2) CONTADOR,',
'        ''<a href="''||',
'        apex_page.get_url(',
'            p_application => 109,',
'            p_page => 603,',
'            p_items => ''P603_ID_REGION,P603_MODULO'',',
'            p_values =>''2,DMA430''',
'        )||''">''||''DOCUMENTOS NO CONTABILIZADOS <span style="color: red;">*</span>''||''</a>'' ENLACE, ',
'        ''#27AE60''COLOR, 2 ORDEN ',
'    FROM DUAL WHERE :P600_PRAB_2 >= 0',
'    UNION ALL',
'    SELECT TO_NUMBER(:P600_PRAB_3) CONTADOR,',
'        ''<a href="''||',
'        apex_page.get_url(',
'            p_application => 109,',
'            p_page => 603,',
'            p_items => ''P603_ID_REGION,P603_MODULO'',',
'            p_values =>''3,DMA430''',
unistr('        )||''">''||''ETIQUETAS QUE NO EST\00C1N DESCARGADAS CORRECTAMENTE''||''</a>'' ENLACE, '),
'        ''#27AE60''COLOR, 3 ORDEN ',
'    FROM DUAL WHERE :P600_PRAB_3 >= 0',
'    UNION ALL',
'    SELECT TO_NUMBER(:P600_PRAB_4) CONTADOR,',
'        ''<a href="''||',
'        apex_page.get_url(',
'            p_application => 109,',
'            p_page => 603,',
'            p_items => ''P603_ID_REGION,P603_MODULO'',',
'            p_values =>''4,DMA430''',
'        )||''">''||''ETIQUETAS DUPLICADAS''||''</a>'' ENLACE, ',
'        ''#27AE60''COLOR, 4 ORDEN ',
'    FROM DUAL WHERE :P600_PRAB_4 >= 0',
'    UNION ALL',
'    SELECT TO_NUMBER(:P600_PRAB_5) CONTADOR,',
'        ''<a href="''||',
'        apex_page.get_url(',
'            p_application => 109,',
'            p_page => 603,',
'            p_items => ''P603_ID_REGION,P603_MODULO'',',
'            p_values =>''5,DMA430''',
'        )||''">''||''REPORTE-IC SIN CONSUMO-IM <span style="color: red;">*</span>''||''</a>'' ENLACE, ',
'        ''#27AE60''COLOR, 5 ORDEN ',
'    FROM DUAL WHERE :P600_PRAB_5 >= 0',
'    UNION ALL',
'    SELECT TO_NUMBER(:P600_PRAB_6) CONTADOR,',
'        ''<a href="''||',
'        apex_page.get_url(',
'            p_application => 109,',
'            p_page => 603,',
'            p_items => ''P603_ID_REGION,P603_MODULO'',',
'            p_values =>''6,DMA430''',
'        )||''">''||''DESPERDICIO PM1 EN REPORTE PRIMERA''||''</a>'' ENLACE, ',
'        ''#27AE60''COLOR, 6 ORDEN ',
'    FROM DUAL WHERE :P600_PRAB_6 >= 0',
'    UNION ALL',
'    SELECT TO_NUMBER(:P600_PRAB_7) CONTADOR,',
'        ''<a href="''||',
'        apex_page.get_url(',
'            p_application => 109,',
'            p_page => 603,',
'            p_items => ''P603_ID_REGION,P603_MODULO'',',
'            p_values =>''7,DMA430''',
unistr('        )||''">''||''\00D3RDENES CON ESTADO <= 30 <span style="color: red;">*</span>''||''</a>'' ENLACE, '),
'        ''#27AE60''COLOR, 7 ORDEN ',
'    FROM DUAL WHERE :P600_PRAB_7 >= 0',
'    UNION ALL',
'    SELECT TO_NUMBER(:P600_PRAB_8) CONTADOR,',
'        ''<a href="''||',
'        apex_page.get_url(',
'            p_application => 109,',
'            p_page => 603,',
'            p_items => ''P603_ID_REGION,P603_MODULO'',',
'            p_values =>''8,DMA430''',
'        )||''">''||''PROCESOS DE INVENTARIOS ABIERTOS <span style="color: red;">*</span>''||''</a>'' ENLACE, ',
'        ''#27AE60''COLOR, 8 ORDEN ',
'    FROM DUAL WHERE :P600_PRAB_8 >= 0',
'    UNION ALL',
'    SELECT TO_NUMBER(:P600_PRAB_9) CONTADOR,',
'        ''<a href="''||',
'        apex_page.get_url(',
'            p_application => 109,',
'            p_page => 603,',
'            p_items => ''P603_ID_REGION,P603_MODULO'',',
'            p_values =>''9,DMA430''',
'        )||''">''||''DUPLICIDAD TRANSFERENCIA ENTRE BODEGAS''||''</a>'' ENLACE, ',
'        ''#27AE60''COLOR, 9 ORDEN ',
'    FROM DUAL WHERE :P600_PRAB_9 >= 0',
'    UNION ALL',
'    SELECT TO_NUMBER(:P600_PRAB_10) CONTADOR,',
'        ''<a href="''||',
'        apex_page.get_url(',
'            p_application => 109,',
'            p_page => 603,',
'            p_items => ''P603_ID_REGION,P603_MODULO'',',
'            p_values =>''10,DMA430''',
unistr('        )||''">''||''ESPERA DE CONFIRMACI\00D3N CONTRAPARTIDA DE TRANSFERENCIA ENTRE BODEGAS''||''</a>'' ENLACE, '),
'        ''#27AE60''COLOR, 10 ORDEN ',
'    FROM DUAL WHERE :P600_PRAB_10 >= 0',
'    UNION ALL',
'    SELECT TO_NUMBER(:P600_PRAB_11) CONTADOR,',
'        ''<a href="''||',
'        apex_page.get_url(',
'            p_application => 109,',
'            p_page => 603,',
'            p_items => ''P603_ID_REGION,P603_MODULO'',',
'            p_values =>''11,DMA430''',
'        )||''">''||''ESTADO MENOR A 620 DE TRANSFERENCIA ENTRE BODEGAS''||''</a>'' ENLACE, ',
'        ''#27AE60''COLOR, 11 ORDEN ',
'    FROM DUAL WHERE :P600_PRAB_11 >= 0',
'    UNION ALL',
'    SELECT TO_NUMBER(:P600_PRAB_12) CONTADOR,',
'        ''<a href="''||',
'        apex_page.get_url(',
'            p_application => 109,',
'            p_page => 603,',
'            p_items => ''P603_ID_REGION,P603_MODULO'',',
'            p_values =>''12,DMA430''',
'        )||''">''||''DUPLICIDAD COSTO REPORTE HORAS -IH''||''</a>'' ENLACE, ',
'        ''#27AE60''COLOR, 12 ORDEN ',
'    FROM DUAL WHERE :P600_PRAB_12 >= 0',
'    UNION ALL',
'    SELECT TO_NUMBER(:P600_PRAB_13) CONTADOR,',
'        ''<a href="''||',
'        apex_page.get_url(',
'            p_application => 109,',
'            p_page => 603,',
'            p_items => ''P603_ID_REGION,P603_MODULO'',',
'            p_values =>''13,DMA430''',
'        )||''">''||''SOBREGIROS COSTO DESPERDICIO- IS''||''</a>'' ENLACE, ',
'        ''#27AE60''COLOR, 13 ORDEN ',
'    FROM DUAL WHERE :P600_PRAB_13 >= 0',
'    UNION ALL',
'    SELECT TO_NUMBER(:P600_PRAB_14) CONTADOR,',
'        ''<a href="''||',
'        apex_page.get_url(',
'            p_application => 109,',
'            p_page => 603,',
'            p_items => ''P603_ID_REGION,P603_MODULO'',',
'            p_values =>''14,DMA430''',
unistr('        )||''">''||''SALDOS NEGATIVOS EN M\00C1QUINA''||''</a>'' ENLACE, '),
'        ''#27AE60''COLOR, 14 ORDEN ',
'    FROM DUAL WHERE :P600_PRAB_14 >= 0',
'    UNION ALL',
'    SELECT TO_NUMBER(:P600_PRAB_15) CONTADOR,',
'        ''<a href="''||',
'        apex_page.get_url(',
'            p_application => 109,',
'            p_page => 603,',
'            p_items => ''P603_ID_REGION,P603_MODULO'',',
'            p_values =>''15,DMA430''',
unistr('        )||''">''||''PRODUCTOS SIN COSTEO EST\00C1NDAR (07)''||''</a>'' ENLACE, '),
'        ''#27AE60''COLOR, 15 ORDEN ',
'    FROM DUAL WHERE :P600_PRAB_15 >= 0',
'    UNION ALL',
'    SELECT TO_NUMBER(:P600_PRAB_16) CONTADOR,',
'        ''<a href="''||',
'        apex_page.get_url(',
'            p_application => 109,',
'            p_page => 603,',
'            p_items => ''P603_ID_REGION,P603_MODULO'',',
'            p_values =>''16,DMA430''',
'        )||''">''||''MATERIA PRIMA SIN COSTO PROMEDIO (02)''||''</a>'' ENLACE, ',
'        ''#27AE60''COLOR, 16 ORDEN ',
'    FROM DUAL WHERE :P600_PRAB_16 >= 0',
'    UNION ALL',
'    SELECT TO_NUMBER(:P600_PRAB_17) CONTADOR,',
'        ''<a href="''||',
'        apex_page.get_url(',
'            p_application => 109,',
'            p_page => 603,',
'            p_items => ''P603_ID_REGION,P603_MODULO'',',
'            p_values =>''17,DMA430''',
'        )||''">''||''SALDOS DE STOCK CON VALOR 0''||''</a>'' ENLACE, ',
'        ''#27AE60''COLOR, 17 ORDEN ',
'    FROM DUAL WHERE :P600_PRAB_17 >= 0',
'    UNION ALL',
'    SELECT ',
'    -- TO_NUMBER(:P600_PRAB_1) +',
'    TO_NUMBER(:P600_PRAB_2) +',
'    TO_NUMBER(:P600_PRAB_3) +',
'    TO_NUMBER(:P600_PRAB_4) +',
'    TO_NUMBER(:P600_PRAB_5) +',
'    TO_NUMBER(:P600_PRAB_6) +',
'    TO_NUMBER(:P600_PRAB_7) +',
'    TO_NUMBER(:P600_PRAB_8) +',
'    TO_NUMBER(:P600_PRAB_9) +',
'    TO_NUMBER(:P600_PRAB_10) +',
'    TO_NUMBER(:P600_PRAB_11) +',
'    TO_NUMBER(:P600_PRAB_12) +',
'    TO_NUMBER(:P600_PRAB_13) +',
'    TO_NUMBER(:P600_PRAB_14) +',
'    TO_NUMBER(:P600_PRAB_15) +',
'    TO_NUMBER(:P600_PRAB_16) + ',
'    TO_NUMBER(:P600_PRAB_17)',
'     CONTADOR,',
'        ''<a>TOTAL</a>'' ENLACE, ',
'        ''#F95C4C''COLOR, 100 ORDEN ',
'    FROM DUAL',
')',
'ORDER BY ORDEN ASC'))
,p_display_when_condition=>':P600_MODULO_ACTIVO = ''1'' OR INSTR(:P600_MODULO_ACTIVO, ''DMA430'') > 0'
,p_display_when_cond2=>'PLSQL'
,p_display_condition_type=>'EXPRESSION'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(37833900716106539)
,p_query_num_rows=>100
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_show_nulls_as=>'-'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
,p_updated_on=>wwv_flow_imp.dz('20260514212722Z')
,p_updated_by=>'JBALCAZAR'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(244460255004546061)
,p_query_column_id=>1
,p_column_alias=>'CARD_TITLE'
,p_column_display_sequence=>10
,p_column_heading=>'Card Title'
,p_use_as_row_header=>'N'
,p_column_html_expression=>'<span style = "color : #CARD_COLOR#"> #CARD_TITLE#</span>'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(244459891386546060)
,p_query_column_id=>2
,p_column_alias=>'CARD_SUBTITLE'
,p_column_display_sequence=>40
,p_column_heading=>'Card Subtitle'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(244461004929546062)
,p_query_column_id=>3
,p_column_alias=>'CARD_COLOR'
,p_column_display_sequence=>30
,p_column_heading=>'Card Color'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(244460658516546061)
,p_query_column_id=>4
,p_column_alias=>'ORDEN'
,p_column_display_sequence=>20
,p_column_heading=>'Orden'
,p_use_as_row_header=>'N'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(428699554709310451)
,p_name=>'Transformaciones'
,p_parent_plug_id=>wwv_flow_imp.id(428697844435310434)
,p_template=>wwv_flow_imp.id(38289867500120143)
,p_display_sequence=>60
,p_include_in_reg_disp_sel_yn=>'Y'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_component_template_options=>'#DEFAULT#:u-colors:t-Cards--displaySubtitle:t-Cards--basic:t-Cards--5cols:t-Cards--hideBody:t-Cards--animRaiseCard:t-Report--hideNoPagination'
,p_display_point=>'SUB_REGIONS'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT CONTADOR AS CARD_TITLE, ENLACE   CARD_SUBTITLE , COLOR AS CARD_COLOR,  ORDEN  ',
'FROM (',
'    SELECT TO_NUMBER(:P600_PRTR_1) CONTADOR,',
'        ''<a href="''||',
'        apex_page.get_url(',
'            p_application => 109,',
'            p_page => 603,',
'            p_items => ''P603_ID_REGION,P603_MODULO'',',
'            p_values =>''19,TRANS''',
unistr('        )||''">''||''TR CON COSTO UNITARIO DIFERENTE (FROM \2013TO)''||''</a>'' ENLACE, '),
'        ''#27AE60''COLOR, 1 ORDEN ',
'    FROM DUAL WHERE :P600_PRTR_1 >= 0',
'    UNION ALL',
'    SELECT TO_NUMBER(:P600_PRTR_2) CONTADOR,',
'        ''<a href="''||',
'        apex_page.get_url(',
'            p_application => 109,',
'            p_page => 603,',
'            p_items => ''P603_ID_REGION,P603_MODULO'',',
'            p_values =>''20,TRANS''',
unistr('        )||''">''||''TRANSFORMACIONES: TR SIN AFECTACI\00D3N DE ASIENTO''||''</a>'' ENLACE, '),
'        ''#27AE60''COLOR, 2 ORDEN ',
'    FROM DUAL WHERE :P600_PRTR_2 >= 0',
'    UNION ALL',
'    SELECT TO_NUMBER(:P600_PRTR_3) CONTADOR,',
'        ''<a href="''||',
'        apex_page.get_url(',
'            p_application => 109,',
'            p_page => 603,',
'            p_items => ''P603_ID_REGION,P603_MODULO'',',
'            p_values =>''21,TRANS''',
'        )||''">''||''PRODUCTOS SIN COSTO PROMEDIO (02)''||''</a>'' ENLACE, ',
'        ''#27AE60''COLOR, 3 ORDEN ',
'    FROM DUAL WHERE :P600_PRTR_3 >= 0',
'    UNION ALL',
'    SELECT TO_NUMBER(:P600_PRTR_4) CONTADOR,',
'        ''<a href="''||',
'        apex_page.get_url(',
'            p_application => 109,',
'            p_page => 603,',
'            p_items => ''P603_ID_REGION,P603_MODULO'',',
'            p_values =>''22,TRANS''',
'        )||''">''||''TRANSFORMACIONES: DIFERENCIA SUMA COSTO CONSUMO IM-VS REPORTE-IC <span style="color: red;">*</span>''||''</a>'' ENLACE, ',
'        ''#27AE60''COLOR, 4 ORDEN ',
'    FROM DUAL WHERE :P600_PRTR_4 >= 0',
'    UNION ALL',
'    SELECT TO_NUMBER(:P600_PRTR_5) CONTADOR,',
'        ''<a href="''||',
'        apex_page.get_url(',
'            p_application => 109,',
'            p_page => 603,',
'            p_items => ''P603_ID_REGION,P603_MODULO'',',
'            p_values =>''8,TRANS''',
'        )||''">''||''PROCESOS DE INVENTARIOS ABIERTOS <span style="color: red;">*</span>''||''</a>'' ENLACE, ',
'        ''#27AE60''COLOR, 5 ORDEN ',
'    FROM DUAL WHERE :P600_PRTR_5 >= 0',
'    UNION ALL',
'    SELECT TO_NUMBER(:P600_PRTR_6) CONTADOR,',
'        ''<a href="''||',
'        apex_page.get_url(',
'            p_application => 109,',
'            p_page => 603,',
'            p_items => ''P603_ID_REGION,P603_MODULO'',',
'            p_values =>''14,TRANS''',
unistr('        )||''">''||''SALDOS NEGATIVOS EN M\00C1QUINA''||''</a>'' ENLACE, '),
'        ''#27AE60''COLOR, 6 ORDEN ',
'    FROM DUAL WHERE :P600_PRTR_6 >= 0',
'    UNION ALL',
'    SELECT TO_NUMBER(:P600_PRTR_7) CONTADOR,',
'        ''<a href="''||',
'        apex_page.get_url(',
'            p_application => 109,',
'            p_page => 603,',
'            p_items => ''P603_ID_REGION,P603_MODULO'',',
'            p_values =>''17,TRANS''',
'        )||''">''||''SALDOS DE STOCK CON VALOR 0''||''</a>'' ENLACE, ',
'        ''#27AE60''COLOR, 7 ORDEN ',
'    FROM DUAL WHERE :P600_PRTR_7 >= 0',
'    UNION ALL',
'    SELECT TO_NUMBER(:P600_PRTR_8) CONTADOR,',
'        ''<a href="''||',
'        apex_page.get_url(',
'            p_application => 109,',
'            p_page => 603,',
'            p_items => ''P603_ID_REGION,P603_MODULO'',',
'            p_values =>''2,TRANS''',
'        )||''">''||''DOCUMENTOS NO CONTABILIZADOS <span style="color: red;">*</span>''||''</a>'' ENLACE, ',
'        ''#27AE60'' COLOR, 8 ORDEN ',
'    FROM DUAL WHERE :P600_PRTR_8 >= 0',
'',
'    UNION ALL',
'    SELECT TO_NUMBER(:P600_PRTR_9) CONTADOR,',
'        ''<a href="''||',
'        apex_page.get_url(',
'            p_application => 109,',
'            p_page => 603,',
'            p_items => ''P603_ID_REGION,P603_MODULO'',',
'            p_values =>''3,TRANS''',
unistr('        )||''">''||''ETIQUETAS QUE NO EST\00C1N DESCARGADAS CORRECTAMENTE''||''</a>'' ENLACE, '),
'        ''#27AE60'' COLOR, 9 ORDEN ',
'    FROM DUAL WHERE :P600_PRTR_9 >= 0',
'',
'    UNION ALL',
'    SELECT TO_NUMBER(:P600_PRTR_10) CONTADOR,',
'        ''<a href="''||',
'        apex_page.get_url(',
'            p_application => 109,',
'            p_page => 603,',
'            p_items => ''P603_ID_REGION,P603_MODULO'',',
'            p_values =>''4,TRANS''',
'        )||''">''||''ETIQUETAS DUPLICADAS''||''</a>'' ENLACE, ',
'        ''#27AE60'' COLOR, 10 ORDEN ',
'    FROM DUAL WHERE :P600_PRTR_10 >= 0',
'',
'    UNION ALL',
'    SELECT TO_NUMBER(:P600_PRTR_11) CONTADOR,',
'        ''<a href="''||',
'        apex_page.get_url(',
'            p_application => 109,',
'            p_page => 603,',
'            p_items => ''P603_ID_REGION,P603_MODULO'',',
'            p_values =>''7,TRANS''',
unistr('        )||''">''||''\00D3RDENES CON ESTADO <= 30 <span style="color: red;">*</span>''||''</a>'' ENLACE, '),
'        ''#27AE60'' COLOR, 11 ORDEN ',
'    FROM DUAL WHERE :P600_PRTR_11 >= 0',
'',
'    UNION ALL',
'    SELECT TO_NUMBER(:P600_PRTR_12) CONTADOR,',
'        ''<a href="''||',
'        apex_page.get_url(',
'            p_application => 109,',
'            p_page => 603,',
'            p_items => ''P603_ID_REGION,P603_MODULO'',',
'            p_values =>''9,TRANS''',
'        )||''">''||''DUPLICIDAD DE DT-MT, ST-OT''||''</a>'' ENLACE, ',
'        ''#27AE60'' COLOR, 12 ORDEN ',
'    FROM DUAL WHERE :P600_PRTR_12 >= 0',
'',
'    UNION ALL',
'    SELECT TO_NUMBER(:P600_PRTR_13) CONTADOR,',
'        ''<a href="''||',
'        apex_page.get_url(',
'            p_application => 109,',
'            p_page => 603,',
'            p_items => ''P603_ID_REGION,P603_MODULO'',',
'            p_values =>''10,TRANS''',
unistr('        )||''">''||''ESPERA DE CONFIRMACI\00D3N CONTRAPARTIDA DT-MT, ST-OT''||''</a>'' ENLACE, '),
'        ''#27AE60'' COLOR, 13 ORDEN ',
'    FROM DUAL WHERE :P600_PRTR_13 >= 0',
'    UNION ALL',
'    SELECT TO_NUMBER(:P600_PRTR_14) CONTADOR,',
'        ''<a href="''||',
'        apex_page.get_url(',
'            p_application => 109,',
'            p_page => 603,',
'            p_items => ''P603_ID_REGION,P603_MODULO'',',
'            p_values =>''11,TRANS''',
'        )||''">''||''ESTADO MENOR 620 DOCUMENTOS DT-MT, ST-OT''||''</a>'' ENLACE, ',
'        ''#27AE60'' COLOR, 14 ORDEN ',
'    FROM DUAL WHERE :P600_PRTR_14 >= 0',
'    UNION ALL',
'    SELECT ',
'        TO_NUMBER(:P600_PRTR_1) +',
'        TO_NUMBER(:P600_PRTR_2) +',
'        TO_NUMBER(:P600_PRTR_3) +',
'        TO_NUMBER(:P600_PRTR_4) +',
'        TO_NUMBER(:P600_PRTR_5) +',
'        TO_NUMBER(:P600_PRTR_6) +',
'        TO_NUMBER(:P600_PRTR_7) +',
'        TO_NUMBER(:P600_PRTR_8) +',
'        TO_NUMBER(:P600_PRTR_9) +',
'        TO_NUMBER(:P600_PRTR_10) +',
'        TO_NUMBER(:P600_PRTR_11) +',
'        TO_NUMBER(:P600_PRTR_12) +',
'        TO_NUMBER(:P600_PRTR_13) +',
'        TO_NUMBER(:P600_PRTR_14)',
'         CONTADOR,',
'        ''<a>TOTAL</a>'' ENLACE, ',
'        ''#F95C4C''COLOR, 100 ORDEN ',
'    FROM DUAL',
')',
'ORDER BY ORDEN ASC'))
,p_display_when_condition=>':P600_MODULO_ACTIVO = ''1'' OR INSTR(:P600_MODULO_ACTIVO, ''TRANS'') > 0'
,p_display_when_cond2=>'PLSQL'
,p_display_condition_type=>'EXPRESSION'
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(37833900716106539)
,p_query_num_rows=>100
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_show_nulls_as=>'-'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
,p_updated_on=>wwv_flow_imp.dz('20260514212722Z')
,p_updated_by=>'JBALCAZAR'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(244469834659546074)
,p_query_column_id=>1
,p_column_alias=>'CARD_TITLE'
,p_column_display_sequence=>10
,p_column_heading=>'Card Title'
,p_use_as_row_header=>'N'
,p_column_html_expression=>'<span style = "color : #CARD_COLOR#"> #CARD_TITLE#</span>'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(244471024866546076)
,p_query_column_id=>2
,p_column_alias=>'CARD_SUBTITLE'
,p_column_display_sequence=>40
,p_column_heading=>'Card Subtitle'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(244470628619546075)
,p_query_column_id=>3
,p_column_alias=>'CARD_COLOR'
,p_column_display_sequence=>30
,p_column_heading=>'Card Color'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(244470214844546075)
,p_query_column_id=>4
,p_column_alias=>'ORDEN'
,p_column_display_sequence=>20
,p_column_heading=>'Orden'
,p_use_as_row_header=>'N'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(430125286106898434)
,p_name=>unistr('Log\00EDstica PT')
,p_parent_plug_id=>wwv_flow_imp.id(428697844435310434)
,p_template=>wwv_flow_imp.id(38289867500120143)
,p_display_sequence=>90
,p_include_in_reg_disp_sel_yn=>'Y'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_component_template_options=>'#DEFAULT#:u-colors:t-Cards--displaySubtitle:t-Cards--basic:t-Cards--5cols:t-Cards--hideBody:t-Cards--animRaiseCard:t-Report--hideNoPagination'
,p_display_point=>'SUB_REGIONS'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT CONTADOR AS CARD_TITLE, ENLACE   CARD_SUBTITLE , COLOR AS CARD_COLOR,  ORDEN  ',
'FROM (',
'    SELECT TO_NUMBER(:P600_LOPT_1) CONTADOR,',
'        ''<a href="''||',
'        apex_page.get_url(',
'            p_application => 109,',
'            p_page => 603,',
'            p_items => ''P603_ID_REGION,P603_MODULO'',',
'            p_values =>''1,DOP340''',
'        )||''">''||''SALDOS EN CANTIDAD NEGATIVOS''||''</a>'' ENLACE, ',
'        ''#27AE60''COLOR, 1 ORDEN ',
'    FROM DUAL WHERE :P600_LOPT_1 >= 0',
'    UNION ALL',
'    SELECT TO_NUMBER(:P600_LOPT_2) CONTADOR,',
'        ''<a href="''||',
'        apex_page.get_url(',
'            p_application => 109,',
'            p_page => 603,',
'            p_items => ''P603_ID_REGION,P603_MODULO'',',
'            p_values =>''2,DOP340''',
'        )||''">''||''DUPLICIDAD EN TRANSFERENCIA ENTRE BODEGAS''||''</a>'' ENLACE, ',
'        ''#27AE60''COLOR, 2 ORDEN ',
'    FROM DUAL WHERE :P600_LOPT_2 >= 0',
'    UNION ALL',
'    SELECT TO_NUMBER(:P600_LOPT_3) CONTADOR,',
'        ''<a href="''||',
'        apex_page.get_url(',
'            p_application => 109,',
'            p_page => 603,',
'            p_items => ''P603_ID_REGION,P603_MODULO'',',
'            p_values =>''3,DOP340''',
'        )||''">''||''CONFIRMACIONES COSTO 0 DE TRANSFERENCIAS ENTRE BODEGAS''||''</a>'' ENLACE, ',
'        ''#27AE60''COLOR, 3 ORDEN ',
'    FROM DUAL WHERE :P600_LOPT_3 >= 0',
'    UNION ALL',
'    SELECT TO_NUMBER(:P600_LOPT_4) CONTADOR,',
'        ''<a href="''||',
'        apex_page.get_url(',
'            p_application => 109,',
'            p_page => 603,',
'            p_items => ''P603_ID_REGION,P603_MODULO'',',
'            p_values =>''4,DOP340''',
'        )||''">''||''TRANSACCIONES ABIERTAS DE TRANSFERENCIA ENTRE BODEGAS''||''</a>'' ENLACE, ',
'        ''#27AE60''COLOR, 4 ORDEN ',
'    FROM DUAL WHERE :P600_LOPT_4 >= 0',
'    UNION ALL',
'    SELECT TO_NUMBER(:P600_LOPT_5) CONTADOR,',
'        ''<a href="''||',
'        apex_page.get_url(',
'            p_application => 109,',
'            p_page => 603,',
'            p_items => ''P603_ID_REGION,P603_MODULO'',',
'            p_values =>''5,DOP340''',
'        )||''">''||''TRANSACCIONES EN ESTADO SIGUIENTE <999''||''</a>'' ENLACE, ',
'        ''#27AE60''COLOR, 5 ORDEN ',
'    FROM DUAL WHERE :P600_LOPT_5 >= 0',
'    UNION ALL',
'    SELECT TO_NUMBER(:P600_LOPT_6) CONTADOR,',
'        ''<a href="''||',
'        apex_page.get_url(',
'            p_application => 109,',
'            p_page => 603,',
'            p_items => ''P603_ID_REGION,P603_MODULO'',',
'            p_values =>''6,DOP340''',
unistr('        )||''">''||''PRODUCTOS PARAMETRIZADOS QUE NECESITEN LOTE A EXCEPCI\00D3N DE SEMIELABORADOS''||''</a>'' ENLACE, '),
'        ''#27AE60''COLOR, 6 ORDEN ',
'    FROM DUAL WHERE :P600_LOPT_6 >= 0',
'    UNION ALL',
'    SELECT TO_NUMBER(:P600_LOPT_7) CONTADOR,',
'        ''<a href="''||',
'        apex_page.get_url(',
'            p_application => 109,',
'            p_page => 603,',
'            p_items => ''P603_ID_REGION,P603_MODULO'',',
'            p_values =>''7,DOP340''',
unistr('        )||''">''||''PRODUCTOS QUE TENGAN SALDO EN LOTE A EXCEPCI\00D3N DE SEMIELABORADOS''||''</a>'' ENLACE, '),
'        ''#27AE60''COLOR, 7 ORDEN ',
'    FROM DUAL WHERE :P600_LOPT_7 >= 0',
'    UNION ALL',
'    SELECT TO_NUMBER(:P600_LOPT_8) CONTADOR,',
'        ''<a href="''||',
'        apex_page.get_url(',
'            p_application => 109,',
'            p_page => 603,',
'            p_items => ''P603_ID_REGION,P603_MODULO'',',
'            p_values =>''8,DOP340''',
unistr('        )||''">''||''TRANSACCIONES QUE TENGAN DISTINTO LA FECHA TRANSACCI\00D3N A LA FECHA LM''||''</a>'' ENLACE, '),
'        ''#27AE60''COLOR, 8 ORDEN ',
'    FROM DUAL WHERE :P600_LOPT_8 >= 0',
'    UNION ALL',
'    SELECT TO_NUMBER(:P600_LOPT_9) CONTADOR,',
'        ''<a href="''||',
'        apex_page.get_url(',
'            p_application => 109,',
'            p_page => 603,',
'            p_items => ''P603_ID_REGION,P603_MODULO'',',
'            p_values =>''9,DOP340''',
unistr('        )||''">''||''VARIACI\00D3N EN COSTO PROMEDIO VS TRANSACCIONAL''||''</a>'' ENLACE, '),
'        ''#27AE60''COLOR, 9 ORDEN ',
'    FROM DUAL WHERE :P600_LOPT_9 >= 0',
'    UNION ALL',
'    SELECT TO_NUMBER(:P600_LOPT_10) CONTADOR,',
'        ''<a href="''||',
'        apex_page.get_url(',
'            p_application => 109,',
'            p_page => 603,',
'            p_items => ''P603_ID_REGION,P603_MODULO'',',
'            p_values =>''10,DOP340''',
'        )||''">''||''PROCESOS DE INVENTARIOS ABIERTOS <span style="color: red;">*</span>''||''</a>'' ENLACE, ',
'        ''#27AE60''COLOR, 10 ORDEN ',
'    FROM DUAL WHERE :P600_LOPT_10 >= 0',
'    UNION ALL',
'    SELECT TO_NUMBER(:P600_LOPT_11) CONTADOR,',
'        ''<a href="''||',
'        apex_page.get_url(',
'            p_application => 109,',
'            p_page => 603,',
'            p_items => ''P603_ID_REGION,P603_MODULO'',',
'            p_values =>''11,DOP340''',
'        )||''">''||''TRANSACCIONES PENDIENTES DE RECOLECTAR''||''</a>'' ENLACE, ',
'        ''#27AE60''COLOR, 11 ORDEN ',
'    FROM DUAL WHERE :P600_LOPT_11 >= 0',
'    UNION ALL',
'    SELECT TO_NUMBER(:P600_LOPT_12) CONTADOR,',
'        ''<a href="''||',
'        apex_page.get_url(',
'            p_application => 109,',
'            p_page => 603,',
'            p_items => ''P603_ID_REGION,P603_MODULO'',',
'            p_values =>''12,DOP340''',
'        )||''">''||''TRANSACCIONES PENDIENTES DE RECOLECTAR''||''</a>'' ENLACE, ',
'        ''#27AE60''COLOR, 12 ORDEN ',
'    FROM DUAL WHERE :P600_LOPT_12 >= 0',
'    UNION ALL',
'    SELECT TO_NUMBER(:P600_LOPT_12) CONTADOR,',
'        ''<a href="''||',
'        apex_page.get_url(',
'            p_application => 109,',
'            p_page => 603,',
'            p_items => ''P603_ID_REGION,P603_MODULO'',',
'            p_values =>''13,DOP340''',
'        )||''">''||''SALDOS DE STOCK CON VALOR 0''||''</a>'' ENLACE, ',
'        ''#27AE60''COLOR, 13 ORDEN ',
'    FROM DUAL WHERE :P600_LOPT_13 >= 0',
'    UNION ALL',
'    SELECT ',
'        TO_NUMBER(:P600_LOPT_1) +',
'        TO_NUMBER(:P600_LOPT_2) +',
'        TO_NUMBER(:P600_LOPT_3) +',
'        TO_NUMBER(:P600_LOPT_4) +',
'        TO_NUMBER(:P600_LOPT_5) +',
'        TO_NUMBER(:P600_LOPT_6) +',
'        TO_NUMBER(:P600_LOPT_7) +',
'        TO_NUMBER(:P600_LOPT_8) +',
'        TO_NUMBER(:P600_LOPT_9) +',
'        TO_NUMBER(:P600_LOPT_10) +',
'        TO_NUMBER(:P600_LOPT_11) +',
'        TO_NUMBER(:P600_LOPT_12) +',
'        TO_NUMBER(:P600_LOPT_13)',
'    ',
'        CONTADOR,',
'        ''<a>TOTAL</a>'' ENLACE, ',
'        ''#F95C4C''COLOR, 100 ORDEN ',
'    FROM DUAL',
')',
'ORDER BY ORDEN ASC'))
,p_display_when_condition=>':P600_MODULO_ACTIVO = ''1'' OR INSTR(:P600_MODULO_ACTIVO, ''DOP340'') > 0'
,p_display_when_cond2=>'PLSQL'
,p_display_condition_type=>'EXPRESSION'
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(37833900716106539)
,p_query_num_rows=>100
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_show_nulls_as=>'-'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
,p_updated_on=>wwv_flow_imp.dz('20260505152717Z')
,p_updated_by=>'JBALCAZAR'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(244467823532546071)
,p_query_column_id=>1
,p_column_alias=>'CARD_TITLE'
,p_column_display_sequence=>10
,p_column_heading=>'Card Title'
,p_use_as_row_header=>'N'
,p_column_html_expression=>'<span style = "color : #CARD_COLOR#"> #CARD_TITLE#</span>'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(244469077225546072)
,p_query_column_id=>2
,p_column_alias=>'CARD_SUBTITLE'
,p_column_display_sequence=>40
,p_column_heading=>'Card Subtitle'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(244468627297546072)
,p_query_column_id=>3
,p_column_alias=>'CARD_COLOR'
,p_column_display_sequence=>30
,p_column_heading=>'Card Color'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(244468231606546071)
,p_query_column_id=>4
,p_column_alias=>'ORDEN'
,p_column_display_sequence=>20
,p_column_heading=>'Orden'
,p_use_as_row_header=>'N'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(436088743696987447)
,p_name=>'Contabilidad'
,p_parent_plug_id=>wwv_flow_imp.id(428697844435310434)
,p_template=>wwv_flow_imp.id(38289867500120143)
,p_display_sequence=>140
,p_include_in_reg_disp_sel_yn=>'Y'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_component_template_options=>'#DEFAULT#:u-colors:t-Cards--displaySubtitle:t-Cards--basic:t-Cards--5cols:t-Cards--hideBody:t-Cards--animRaiseCard:t-Report--hideNoPagination'
,p_display_point=>'SUB_REGIONS'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT CONTADOR AS CARD_TITLE, ENLACE   CARD_SUBTITLE , COLOR AS CARD_COLOR,  ORDEN  ',
'FROM (',
'    SELECT TO_NUMBER(:P600_CONT_1) CONTADOR,',
'        ''<a href="''||',
'        apex_page.get_url(',
'            p_application => 109,',
'            p_page => 603,',
'            p_items => ''P603_ID_REGION,P603_MODULO'',',
'            p_values =>''1,CONTA''',
'        )||''">''||''ASIENTOS DE HONORARIOS Y PROVISIONES DE COMERCIAL <span style="color: red;">*</span>''||''</a>'' ENLACE, ',
'        ''#27AE60''COLOR, 1 ORDEN ',
'    FROM DUAL WHERE :P600_CONT_1 >= 0',
'    UNION ALL',
'    SELECT TO_NUMBER(:P600_CONT_2) CONTADOR,',
'        ''<a href="''||',
'        apex_page.get_url(',
'            p_application => 109,',
'            p_page => 603,',
'            p_items => ''P603_ID_REGION,P603_MODULO'',',
'            p_values =>''2,CONTA''',
'        )||''">''||''ASIENTOS DE MUESTRAS <span style="color: red;">*</span>''||''</a>'' ENLACE, ',
'        ''#27AE60''COLOR, 2 ORDEN ',
'    FROM DUAL WHERE :P600_CONT_2 >= 0',
'    UNION ALL',
'    SELECT TO_NUMBER(:P600_CONT_3) CONTADOR,',
'        ''<a href="''||',
'        apex_page.get_url(',
'            p_application => 109,',
'            p_page => 603,',
'            p_items => ''P603_ID_REGION,P603_MODULO'',',
'            p_values =>''3,CONTA''',
'        )||''">''||''ASIENTOS DE FLETES <span style="color: red;">*</span>''||''</a>'' ENLACE, ',
'        ''#27AE60''COLOR, 3 ORDEN ',
'    FROM DUAL WHERE :P600_CONT_3 >= 0',
'    UNION ALL',
'    SELECT TO_NUMBER(:P600_CONT_4) CONTADOR,',
'        ''<a href="''||',
'        apex_page.get_url(',
'            p_application => 109,',
'            p_page => 603,',
'            p_items => ''P603_ID_REGION,P603_MODULO'',',
'            p_values =>''4,CONTA''',
'        )||''">''||''ASIENTOS CUENTAS POR COBRAR TRANSPORTE <span style="color: red;">*</span>''||''</a>'' ENLACE, ',
'        ''#27AE60''COLOR, 4 ORDEN ',
'    FROM DUAL WHERE :P600_CONT_4 >= 0',
'    UNION ALL',
'    SELECT TO_NUMBER(:P600_CONT_5) CONTADOR,',
'        ''<a href="''||',
'        apex_page.get_url(',
'            p_application => 109,',
'            p_page => 603,',
'            p_items => ''P603_ID_REGION,P603_MODULO'',',
'            p_values =>''5,CONTA''',
'        )||''">''||''ASIENTOS DE PROVISIONES <span style="color: red;">*</span>''||''</a>'' ENLACE, ',
'        ''#27AE60''COLOR, 5 ORDEN ',
'    FROM DUAL WHERE :P600_CONT_5 >= 0',
'    UNION ALL',
'    SELECT TO_NUMBER(:P600_CONT_6) CONTADOR,',
'        ''<a href="''||',
'        apex_page.get_url(',
'            p_application => 109,',
'            p_page => 603,',
'            p_items => ''P603_ID_REGION,P603_MODULO'',',
'            p_values =>''6,CONTA''',
unistr('        )||''">''||''VARIACI\00D3N ENTRE VENTAS Y CUENTAS POR COBRAR <span style="color: red;">*</span>''||''</a>'' ENLACE, '),
'        ''#27AE60''COLOR, 6 ORDEN ',
'    FROM DUAL WHERE :P600_CONT_6 >= 0',
'    UNION ALL',
'    SELECT TO_NUMBER(:P600_CONT_7) CONTADOR,',
'        ''<a href="''||',
'        apex_page.get_url(',
'            p_application => 109,',
'            p_page => 603,',
'            p_items => ''P603_ID_REGION,P603_MODULO'',',
'            p_values =>''7,CONTA''',
unistr('        )||''">''||''VARIACI\00D3N ENTRE CUENTAS POR COBRAR Y ASIENT0 <span style="color: red;">*</span>''||''</a>'' ENLACE, '),
'        ''#27AE60''COLOR, 7 ORDEN ',
'    FROM DUAL WHERE :P600_CONT_7 >= 0',
'    UNION ALL',
'    SELECT TO_NUMBER(:P600_CONT_8) CONTADOR,',
'        ''<a href="''||',
'        apex_page.get_url(',
'            p_application => 109,',
'            p_page => 603,',
'            p_items => ''P603_ID_REGION,P603_MODULO'',',
'            p_values =>''8,CONTA''',
unistr('        )||''">''||''VALIDACI\00D3N CONTABLE DE LAS CUENTAS DE VENTAS <span style="color: red;">*</span>''||''</a>'' ENLACE, '),
'        ''#27AE60''COLOR, 8 ORDEN ',
'    FROM DUAL WHERE :P600_CONT_8 >= 0',
'    UNION ALL',
'    SELECT TO_NUMBER(:P600_CONT_9) CONTADOR,',
'        ''<a href="''||',
'        apex_page.get_url(',
'            p_application => 109,',
'            p_page => 603,',
'            p_items => ''P603_ID_REGION,P603_MODULO'',',
'            p_values =>''9,CONTA''',
'        )||''">''||''CIERRE CONTABLE DEL MES ANTERIOR <span style="color: red;">*</span>''||''</a>'' ENLACE, ',
'        ''#27AE60''COLOR, 9 ORDEN ',
'    FROM DUAL WHERE :P600_CONT_9 >= 0',
'    UNION ALL',
'    SELECT ',
'        TO_NUMBER(:P600_CONT_1) +',
'        TO_NUMBER(:P600_CONT_2) +',
'        TO_NUMBER(:P600_CONT_3) +',
'        TO_NUMBER(:P600_CONT_4) +',
'        TO_NUMBER(:P600_CONT_5) +',
'        TO_NUMBER(:P600_CONT_6) +',
'        TO_NUMBER(:P600_CONT_7) +',
'        TO_NUMBER(:P600_CONT_8) +',
'        TO_NUMBER(:P600_CONT_9)',
'        CONTADOR,',
'        ''<a>TOTAL</a>'' ENLACE, ',
'        ''#F95C4C''COLOR, 100 ORDEN ',
'    FROM DUAL',
')',
'ORDER BY ORDEN ASC'))
,p_display_when_condition=>':P600_MODULO_ACTIVO = ''1'' OR INSTR(:P600_MODULO_ACTIVO, ''CONTA'') > 0'
,p_display_when_cond2=>'PLSQL'
,p_display_condition_type=>'EXPRESSION'
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(37833900716106539)
,p_query_num_rows=>100
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_show_nulls_as=>'-'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
,p_updated_on=>wwv_flow_imp.dz('20260514165745Z')
,p_updated_by=>'JBALCAZAR'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(244457800540546056)
,p_query_column_id=>1
,p_column_alias=>'CARD_TITLE'
,p_column_display_sequence=>10
,p_column_heading=>'Card Title'
,p_use_as_row_header=>'N'
,p_column_html_expression=>'<span style = "color : #CARD_COLOR#"> #CARD_TITLE#</span>'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(244459077119546058)
,p_query_column_id=>2
,p_column_alias=>'CARD_SUBTITLE'
,p_column_display_sequence=>40
,p_column_heading=>'Card Subtitle'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(244458669097546058)
,p_query_column_id=>3
,p_column_alias=>'CARD_COLOR'
,p_column_display_sequence=>30
,p_column_heading=>'Card Color'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(244458243798546057)
,p_query_column_id=>4
,p_column_alias=>'ORDEN'
,p_column_display_sequence=>20
,p_column_heading=>'Orden'
,p_use_as_row_header=>'N'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(436563150260672136)
,p_name=>'Cuentas x Pagar'
,p_parent_plug_id=>wwv_flow_imp.id(428697844435310434)
,p_template=>wwv_flow_imp.id(38289867500120143)
,p_display_sequence=>150
,p_include_in_reg_disp_sel_yn=>'Y'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_component_template_options=>'#DEFAULT#:u-colors:t-Cards--displaySubtitle:t-Cards--basic:t-Cards--5cols:t-Cards--hideBody:t-Cards--animRaiseCard:t-Report--hideNoPagination'
,p_display_point=>'SUB_REGIONS'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT CONTADOR AS CARD_TITLE, ENLACE   CARD_SUBTITLE , COLOR AS CARD_COLOR,  ORDEN  ',
'FROM (',
'    SELECT TO_NUMBER(:P600_CXPP_1) CONTADOR,',
'        ''<a href="''||',
'        apex_page.get_url(',
'            p_application => 109,',
'            p_page => 603,',
'            p_items => ''P603_ID_REGION,P603_MODULO'',',
'            p_values =>''1,CXPFI''',
unistr('        )||''">''||''\00D3RDENES RECEPCIONADAS PENDIENTES DE COTEJAR''||''</a>'' ENLACE, '),
'        ''#27AE60''COLOR, 1 ORDEN ',
'    FROM DUAL WHERE :P600_CXPP_1 >= 0',
'    UNION ALL',
'    SELECT TO_NUMBER(:P600_CXPP_2) CONTADOR,',
'        ''<a href="''||',
'        apex_page.get_url(',
'            p_application => 109,',
'            p_page => 603,',
'            p_items => ''P603_ID_REGION,P603_MODULO'',',
'            p_values =>''2,CXPFI''',
unistr('        )||''">''||''VARIACI\00D3N  FACTURA PROVEEDOR VS LA ORDEN''||''</a>'' ENLACE, '),
'        ''#27AE60''COLOR, 2 ORDEN ',
'    FROM DUAL WHERE :P600_CXPP_2 >= 0',
'    UNION ALL',
'    SELECT TO_NUMBER(:P600_CXPP_3) CONTADOR,',
'        ''<a href="''||',
'        apex_page.get_url(',
'            p_application => 109,',
'            p_page => 603,',
'            p_items => ''P603_ID_REGION,P603_MODULO'',',
'            p_values =>''3,CXPFI''',
'        )||''">''||''ANTICIPO SIN FACTURA''||''</a>'' ENLACE, ',
'        ''#27AE60''COLOR, 3 ORDEN ',
'    FROM DUAL WHERE :P600_CXPP_3 >= 0',
'    UNION ALL',
'    SELECT TO_NUMBER(:P600_CXPP_4) CONTADOR,',
'        ''<a href="''||',
'        apex_page.get_url(',
'            p_application => 109,',
'            p_page => 603,',
'            p_items => ''P603_ID_REGION,P603_MODULO'',',
'            p_values =>''4,CXPFI''',
unistr('        )||''">''||''FACTURAS SIN ORDEN DE COMPRA Y  CON \00D3RDENES DE COMPRA, (EN ESTADOS: RUTA, IMPRESI\00D3N O RECEPCI\00D3N  - MENOR A 999)''||''</a>'' ENLACE, '),
'        ''#27AE60''COLOR, 4 ORDEN ',
'    FROM DUAL WHERE :P600_CXPP_4 >= 0',
'    UNION ALL',
'    SELECT TO_NUMBER(:P600_CXPP_5) CONTADOR,',
'        ''<a href="''||',
'        apex_page.get_url(',
'            p_application => 109,',
'            p_page => 603,',
'            p_items => ''P603_ID_REGION,P603_MODULO'',',
'            p_values =>''5,CXPFI''',
'        )||''">''||''FACTURA EMITIDA VS FECHA DE REGISTRO >=5 DIAS''||''</a>'' ENLACE, ',
'        ''#27AE60''COLOR, 5 ORDEN ',
'    FROM DUAL WHERE :P600_CXPP_5 >= 0',
'    UNION ALL',
'    SELECT TO_NUMBER(:P600_CXPP_6) CONTADOR,',
'        ''<a href="''||',
'        apex_page.get_url(',
'            p_application => 109,',
'            p_page => 603,',
'            p_items => ''P603_ID_REGION,P603_MODULO'',',
'            p_values =>''6,CXPFI''',
unistr('        )||''">''||''RETENCIONES NO AUTORIZADAS DESPU\00C9S DE GESTIONAR EMISI\00D3N''||''</a>'' ENLACE, '),
'        ''#27AE60''COLOR, 6 ORDEN ',
'    FROM DUAL WHERE :P600_CXPP_6 >= 0',
'    UNION ALL',
'    SELECT TO_NUMBER(:P600_CXPP_7) CONTADOR,',
'        ''<a href="''||',
'        apex_page.get_url(',
'            p_application => 109,',
'            p_page => 603,',
'            p_items => ''P603_ID_REGION,P603_MODULO'',',
'            p_values =>''7,CXPFI''',
unistr('        )||''">''||''OI QUE NO TENGAN JE AFECTANDO LA CUENTA 22502.09 CON UN RANGO DE 30 D\00CDAS (PROVISI\00D3N IMPORTACIONES)''||''</a>'' ENLACE, '),
'        ''#27AE60''COLOR, 7 ORDEN ',
'    FROM DUAL WHERE :P600_CXPP_7 >= 0',
'    UNION ALL',
'    SELECT TO_NUMBER(:P600_CXPP_8) CONTADOR,',
'        ''<a href="''||',
'        apex_page.get_url(',
'            p_application => 109,',
'            p_page => 603,',
'            p_items => ''P603_ID_REGION,P603_MODULO'',',
'            p_values =>''8,CXPFI''',
'        )||''">''||''VALORES DE BANCOS PENDIENTES DE REGISTRAR EN JD''||''</a>'' ENLACE, ',
'        ''#27AE60''COLOR, 8 ORDEN ',
'    FROM DUAL WHERE :P600_CXPP_8 >= 0',
'    UNION ALL',
'    SELECT TO_NUMBER(:P600_CXPP_9) CONTADOR,',
'        ''<a href="''||',
'        apex_page.get_url(',
'            p_application => 109,',
'            p_page => 603,',
'            p_items => ''P603_ID_REGION,P603_MODULO'',',
'            p_values =>''9,CXPFI''',
unistr('        )||''">''||''FACTURAS DE PROVEEDORES SIN RETENCI\00D3N''||''</a>'' ENLACE, '),
'        ''#27AE60''COLOR, 9 ORDEN ',
'    FROM DUAL WHERE :P600_CXPP_9 >= 0',
'    UNION ALL',
'    SELECT ',
'        TO_NUMBER(:P600_CXPP_1) +',
'        TO_NUMBER(:P600_CXPP_2) +',
'        TO_NUMBER(:P600_CXPP_3) +',
'        TO_NUMBER(:P600_CXPP_4) +',
'        TO_NUMBER(:P600_CXPP_5) +',
'        TO_NUMBER(:P600_CXPP_6) + ',
'        TO_NUMBER(:P600_CXPP_7) + ',
'        TO_NUMBER(:P600_CXPP_8) + ',
'        TO_NUMBER(:P600_CXPP_9)',
'         CONTADOR,',
'        ''<a>TOTAL</a>'' ENLACE, ',
'        ''#F95C4C''COLOR, 100 ORDEN ',
'    FROM DUAL',
')',
'ORDER BY ORDEN ASC'))
,p_display_when_condition=>':P600_MODULO_ACTIVO = ''1'' OR INSTR(:P600_MODULO_ACTIVO, ''CXPFI'') > 0'
,p_display_when_cond2=>'PLSQL'
,p_display_condition_type=>'EXPRESSION'
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(37833900716106539)
,p_query_num_rows=>100
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_show_nulls_as=>'-'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
,p_updated_on=>wwv_flow_imp.dz('20260427171300Z')
,p_updated_by=>'JBALCAZAR'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(244450256607546048)
,p_query_column_id=>1
,p_column_alias=>'CARD_TITLE'
,p_column_display_sequence=>10
,p_column_heading=>'Card Title'
,p_use_as_row_header=>'N'
,p_column_html_expression=>'<span style = "color : #CARD_COLOR#"> #CARD_TITLE#</span>'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(244451068837546049)
,p_query_column_id=>2
,p_column_alias=>'CARD_SUBTITLE'
,p_column_display_sequence=>40
,p_column_heading=>'Card Subtitle'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(244450693700546048)
,p_query_column_id=>3
,p_column_alias=>'CARD_COLOR'
,p_column_display_sequence=>30
,p_column_heading=>'Card Color'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(244449899692546048)
,p_query_column_id=>4
,p_column_alias=>'ORDEN'
,p_column_display_sequence=>20
,p_column_heading=>'Orden'
,p_use_as_row_header=>'N'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(436924268962209350)
,p_name=>unistr('Producci\00F3n Envases')
,p_parent_plug_id=>wwv_flow_imp.id(428697844435310434)
,p_template=>wwv_flow_imp.id(38289867500120143)
,p_display_sequence=>70
,p_include_in_reg_disp_sel_yn=>'Y'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_component_template_options=>'#DEFAULT#:u-colors:t-Cards--displaySubtitle:t-Cards--basic:t-Cards--5cols:t-Cards--hideBody:t-Cards--animRaiseCard:t-Report--hideNoPagination'
,p_display_point=>'SUB_REGIONS'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT CONTADOR AS CARD_TITLE, ENLACE   CARD_SUBTITLE , COLOR AS CARD_COLOR,  ORDEN  ',
'FROM (',
'    SELECT TO_NUMBER(:P600_PREN_1) CONTADOR,',
'        ''<a href="''||',
'        apex_page.get_url(',
'            p_application => 109,',
'            p_page => 603,',
'            p_items => ''P603_ID_REGION,P603_MODULO'',',
'            p_values =>''1,DMA510''',
unistr('        )||''">''||''CIERRE DE PRODUCCI\00D3N VS DOCUMENTO <span style="color: red;">*</span>''||''</a>'' ENLACE, '),
'        ''#27AE60''COLOR, 1 ORDEN ',
'    FROM DUAL WHERE :P600_PREN_1 >= 0',
'    UNION ALL',
'    SELECT TO_NUMBER(:P600_PREN_2) CONTADOR,',
'        ''<a href="''||',
'        apex_page.get_url(',
'            p_application => 109,',
'            p_page => 603,',
'            p_items => ''P603_ID_REGION,P603_MODULO'',',
'            p_values =>''2,DMA510''',
'        )||''">''||''DOCUMENTOS NO CONTABILIZADOS <span style="color: red;">*</span>''||''</a>'' ENLACE, ',
'        ''#27AE60''COLOR, 2 ORDEN ',
'    FROM DUAL WHERE :P600_PREN_2 >= 0',
'    UNION ALL',
'    SELECT TO_NUMBER(:P600_PREN_3) CONTADOR,',
'        ''<a href="''||',
'        apex_page.get_url(',
'            p_application => 109,',
'            p_page => 603,',
'            p_items => ''P603_ID_REGION,P603_MODULO'',',
'            p_values =>''3,DMA510''',
unistr('        )||''">''||''ETIQUETAS QUE NO EST\00C1N DESCARGADAS CORRECTAMENTE''||''</a>'' ENLACE, '),
'        ''#27AE60''COLOR, 3 ORDEN ',
'    FROM DUAL WHERE :P600_PREN_3 >= 0',
'    UNION ALL',
'    SELECT TO_NUMBER(:P600_PREN_4) CONTADOR,',
'        ''<a href="''||',
'        apex_page.get_url(',
'            p_application => 109,',
'            p_page => 603,',
'            p_items => ''P603_ID_REGION,P603_MODULO'',',
'            p_values =>''4,DMA510''',
'        )||''">''||''ETIQUETAS DUPLICADAS''||''</a>'' ENLACE, ',
'        ''#27AE60''COLOR, 4 ORDEN ',
'    FROM DUAL WHERE :P600_PREN_4 >= 0',
'    UNION ALL',
'    SELECT TO_NUMBER(:P600_PREN_5) CONTADOR,',
'        ''<a href="''||',
'        apex_page.get_url(',
'            p_application => 109,',
'            p_page => 603,',
'            p_items => ''P603_ID_REGION,P603_MODULO'',',
'            p_values =>''5,DMA510''',
'        )||''">''||''REPORTE-IC SIN CONSUMO-IM <span style="color: red;">*</span>''||''</a>'' ENLACE, ',
'        ''#27AE60''COLOR, 5 ORDEN ',
'    FROM DUAL WHERE :P600_PREN_5 >= 0',
'    UNION ALL',
'    SELECT TO_NUMBER(:P600_PREN_6) CONTADOR,',
'        ''<a href="''||',
'        apex_page.get_url(',
'            p_application => 109,',
'            p_page => 603,',
'            p_items => ''P603_ID_REGION,P603_MODULO'',',
'            p_values =>''6,DMA510''',
'        )||''">''||''DESPERDICIO PM1 EN REPORTE PRIMERA''||''</a>'' ENLACE, ',
'        ''#27AE60''COLOR, 6 ORDEN ',
'    FROM DUAL WHERE :P600_PREN_6 >= 0',
'    UNION ALL',
'    SELECT TO_NUMBER(:P600_PREN_7) CONTADOR,',
'        ''<a href="''||',
'        apex_page.get_url(',
'            p_application => 109,',
'            p_page => 603,',
'            p_items => ''P603_ID_REGION,P603_MODULO'',',
'            p_values =>''7,DMA510''',
unistr('        )||''">''||''\00D3RDENES CON ESTADO <= 30 <span style="color: red;">*</span>''||''</a>'' ENLACE, '),
'        ''#27AE60''COLOR, 7 ORDEN ',
'    FROM DUAL WHERE :P600_PREN_7 >= 0',
'    UNION ALL',
'    SELECT TO_NUMBER(:P600_PREN_8) CONTADOR,',
'        ''<a href="''||',
'        apex_page.get_url(',
'            p_application => 109,',
'            p_page => 603,',
'            p_items => ''P603_ID_REGION,P603_MODULO'',',
'            p_values =>''8,DMA510''',
'        )||''">''||''PROCESOS DE INVENTARIOS ABIERTOS <span style="color: red;">*</span>''||''</a>'' ENLACE, ',
'        ''#27AE60''COLOR, 8 ORDEN ',
'    FROM DUAL WHERE :P600_PREN_8 >= 0',
'    UNION ALL',
'    SELECT TO_NUMBER(:P600_PREN_9) CONTADOR,',
'        ''<a href="''||',
'        apex_page.get_url(',
'            p_application => 109,',
'            p_page => 603,',
'            p_items => ''P603_ID_REGION,P603_MODULO'',',
'            p_values =>''9,DMA510''',
'        )||''">''||''DUPLICIDAD TRANSFERENCIA ENTRE BODEGAS''||''</a>'' ENLACE, ',
'        ''#27AE60''COLOR, 9 ORDEN ',
'    FROM DUAL WHERE :P600_PREN_9 >= 0',
'    UNION ALL',
'    SELECT TO_NUMBER(:P600_PREN_10) CONTADOR,',
'        ''<a href="''||',
'        apex_page.get_url(',
'            p_application => 109,',
'            p_page => 603,',
'            p_items => ''P603_ID_REGION,P603_MODULO'',',
'            p_values =>''10,DMA510''',
unistr('        )||''">''||''ESPERA DE CONFIRMACI\00D3N CONTRAPARTIDA DE TRANSFERENCIA ENTRE BODEGAS''||''</a>'' ENLACE, '),
'        ''#27AE60''COLOR, 10 ORDEN ',
'    FROM DUAL WHERE :P600_PREN_10 >= 0',
'    UNION ALL',
'    SELECT TO_NUMBER(:P600_PREN_11) CONTADOR,',
'        ''<a href="''||',
'        apex_page.get_url(',
'            p_application => 109,',
'            p_page => 603,',
'            p_items => ''P603_ID_REGION,P603_MODULO'',',
'            p_values =>''11,DMA510''',
'        )||''">''||''ESTADO MENOR A 620 DE TRANSFERENCIA ENTRE BODEGAS''||''</a>'' ENLACE, ',
'        ''#27AE60''COLOR, 11 ORDEN ',
'    FROM DUAL WHERE :P600_PREN_11 >= 0',
'    UNION ALL',
'    SELECT TO_NUMBER(:P600_PREN_12) CONTADOR,',
'        ''<a href="''||',
'        apex_page.get_url(',
'            p_application => 109,',
'            p_page => 603,',
'            p_items => ''P603_ID_REGION,P603_MODULO'',',
'            p_values =>''12,DMA510''',
'        )||''">''||''DUPLICIDAD COSTO REPORTE HORAS -IH''||''</a>'' ENLACE, ',
'        ''#27AE60''COLOR, 12 ORDEN ',
'    FROM DUAL WHERE :P600_PREN_12 >= 0',
'    UNION ALL',
'    SELECT TO_NUMBER(:P600_PREN_13) CONTADOR,',
'        ''<a href="''||',
'        apex_page.get_url(',
'            p_application => 109,',
'            p_page => 603,',
'            p_items => ''P603_ID_REGION,P603_MODULO'',',
'            p_values =>''13,DMA510''',
'        )||''">''||''SOBREGIROS COSTO DESPERDICIO- IS''||''</a>'' ENLACE, ',
'        ''#27AE60''COLOR, 13 ORDEN ',
'    FROM DUAL WHERE :P600_PREN_13 >= 0',
'    UNION ALL',
'    SELECT TO_NUMBER(:P600_PREN_14) CONTADOR,',
'        ''<a href="''||',
'        apex_page.get_url(',
'            p_application => 109,',
'            p_page => 603,',
'            p_items => ''P603_ID_REGION,P603_MODULO'',',
'            p_values =>''14,DMA510''',
unistr('        )||''">''||''SALDOS NEGATIVOS EN M\00C1QUINA''||''</a>'' ENLACE, '),
'        ''#27AE60''COLOR, 14 ORDEN ',
'    FROM DUAL WHERE :P600_PREN_14 >= 0',
'    UNION ALL',
'    SELECT TO_NUMBER(:P600_PREN_15) CONTADOR,',
'        ''<a href="''||',
'        apex_page.get_url(',
'            p_application => 109,',
'            p_page => 603,',
'            p_items => ''P603_ID_REGION,P603_MODULO'',',
'            p_values =>''15,DMA510''',
unistr('        )||''">''||''PRODUCTOS SIN COSTEO EST\00C1NDAR (07)''||''</a>'' ENLACE, '),
'        ''#27AE60''COLOR, 15 ORDEN ',
'    FROM DUAL WHERE :P600_PREN_15 >= 0',
'    UNION ALL',
'    SELECT TO_NUMBER(:P600_PREN_16) CONTADOR,',
'        ''<a href="''||',
'        apex_page.get_url(',
'            p_application => 109,',
'            p_page => 603,',
'            p_items => ''P603_ID_REGION,P603_MODULO'',',
'            p_values =>''16,DMA510''',
'        )||''">''||''MATERIA PRIMA SIN COSTO PROMEDIO (02)''||''</a>'' ENLACE, ',
'        ''#27AE60''COLOR, 16 ORDEN ',
'    FROM DUAL WHERE :P600_PREN_16 >= 0',
'    UNION ALL',
'    SELECT TO_NUMBER(:P600_PREN_17) CONTADOR,',
'        ''<a href="''||',
'        apex_page.get_url(',
'            p_application => 109,',
'            p_page => 603,',
'            p_items => ''P603_ID_REGION,P603_MODULO'',',
'            p_values =>''17,DMA510''',
'        )||''">''||''SALDOS DE STOCK CON VALOR 0''||''</a>'' ENLACE, ',
'        ''#27AE60''COLOR, 17 ORDEN ',
'    FROM DUAL WHERE :P600_PREN_17 >= 0',
'    UNION ALL',
'    SELECT TO_NUMBER(:P600_PREN_18) CONTADOR,',
'        ''<a href="''||',
'        apex_page.get_url(',
'            p_application => 109,',
'            p_page => 603,',
'            p_items => ''P603_ID_REGION,P603_MODULO'',',
'            p_values =>''18,DMA510''',
unistr('        )||''">''||''SEMIELABORADOS SIN CATEGOR\00CDA M01''||''</a>'' ENLACE, '),
'        ''#27AE60''COLOR, 18 ORDEN ',
'    FROM DUAL WHERE :P600_PREN_18 >= 0',
'',
'    UNION ALL',
'',
'    SELECT ',
'    -- TO_NUMBER(:P600_PREN_1) +',
'    TO_NUMBER(:P600_PREN_2) +',
'    TO_NUMBER(:P600_PREN_3) +',
'    TO_NUMBER(:P600_PREN_4) +',
'    TO_NUMBER(:P600_PREN_5) +',
'    TO_NUMBER(:P600_PREN_6) +',
'    TO_NUMBER(:P600_PREN_7) +',
'    TO_NUMBER(:P600_PREN_8) +',
'    TO_NUMBER(:P600_PREN_9) +',
'    TO_NUMBER(:P600_PREN_10) +',
'    TO_NUMBER(:P600_PREN_11) +',
'    TO_NUMBER(:P600_PREN_12) +',
'    TO_NUMBER(:P600_PREN_13) +',
'    TO_NUMBER(:P600_PREN_14) +',
'    TO_NUMBER(:P600_PREN_15) +',
'    TO_NUMBER(:P600_PREN_16) +',
'    TO_NUMBER(:P600_PREN_17) +',
'    TO_NUMBER(:P600_PREN_18)',
'     CONTADOR,',
'        ''<a>TOTAL</a>'' ENLACE, ',
'        ''#F95C4C''COLOR, 100 ORDEN ',
'    FROM DUAL',
')',
'ORDER BY ORDEN ASC'))
,p_display_when_condition=>':P600_MODULO_ACTIVO = ''1'' OR INSTR(:P600_MODULO_ACTIVO, ''DMA510'') > 0'
,p_display_when_cond2=>'PLSQL'
,p_display_condition_type=>'EXPRESSION'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(37833900716106539)
,p_query_num_rows=>100
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_show_nulls_as=>'-'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
,p_updated_on=>wwv_flow_imp.dz('20260514212722Z')
,p_updated_by=>'JBALCAZAR'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(244439893812546036)
,p_query_column_id=>1
,p_column_alias=>'CARD_TITLE'
,p_column_display_sequence=>10
,p_column_heading=>'Card Title'
,p_use_as_row_header=>'N'
,p_column_html_expression=>'<span style = "color : #CARD_COLOR#"> #CARD_TITLE#</span>'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(244441065890546037)
,p_query_column_id=>2
,p_column_alias=>'CARD_SUBTITLE'
,p_column_display_sequence=>40
,p_column_heading=>'Card Subtitle'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(244440660009546037)
,p_query_column_id=>3
,p_column_alias=>'CARD_COLOR'
,p_column_display_sequence=>30
,p_column_heading=>'Card Color'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(244440272032546037)
,p_query_column_id=>4
,p_column_alias=>'ORDEN'
,p_column_display_sequence=>20
,p_column_heading=>'Orden'
,p_use_as_row_header=>'N'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(438214166264625052)
,p_name=>unistr('Producci\00F3n Cosm\00E9tica')
,p_parent_plug_id=>wwv_flow_imp.id(428697844435310434)
,p_template=>wwv_flow_imp.id(38289867500120143)
,p_display_sequence=>50
,p_include_in_reg_disp_sel_yn=>'Y'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_component_template_options=>'#DEFAULT#:u-colors:t-Cards--displaySubtitle:t-Cards--basic:t-Cards--5cols:t-Cards--hideBody:t-Cards--animRaiseCard:t-Report--hideNoPagination'
,p_display_point=>'SUB_REGIONS'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT CONTADOR AS CARD_TITLE, ENLACE   CARD_SUBTITLE , COLOR AS CARD_COLOR,  ORDEN  ',
'FROM (',
'    SELECT TO_NUMBER(:P600_PRCS_1) CONTADOR,',
'        ''<a href="''||',
'        apex_page.get_url(',
'            p_application => 109,',
'            p_page => 603,',
'            p_items => ''P603_ID_REGION,P603_MODULO'',',
'            p_values =>''1,COSME''',
unistr('        )||''">''||''CIERRE DE PRODUCCI\00D3N VS DOCUMENTO <span style="color: red;">*</span>''||''</a>'' ENLACE, '),
'        ''#27AE60''COLOR, 1 ORDEN ',
'    FROM DUAL WHERE :P600_PRCS_1 >= 0',
'    UNION ALL',
'    SELECT TO_NUMBER(:P600_PRCS_2) CONTADOR,',
'        ''<a href="''||',
'        apex_page.get_url(',
'            p_application => 109,',
'            p_page => 603,',
'            p_items => ''P603_ID_REGION,P603_MODULO'',',
'            p_values =>''2,COSME''',
'        )||''">''||''DOCUMENTOS NO CONTABILIZADOS <span style="color: red;">*</span>''||''</a>'' ENLACE, ',
'        ''#27AE60''COLOR, 2 ORDEN ',
'    FROM DUAL WHERE :P600_PRCS_2 >= 0',
'    UNION ALL',
'    SELECT TO_NUMBER(:P600_PRCS_3) CONTADOR,',
'        ''<a href="''||',
'        apex_page.get_url(',
'            p_application => 109,',
'            p_page => 603,',
'            p_items => ''P603_ID_REGION,P603_MODULO'',',
'            p_values =>''3,COSME''',
unistr('        )||''">''||''ETIQUETAS QUE NO EST\00C1N DESCARGADAS CORRECTAMENTE''||''</a>'' ENLACE, '),
'        ''#27AE60''COLOR, 3 ORDEN ',
'    FROM DUAL WHERE :P600_PRCS_3 >= 0',
'    UNION ALL',
'    SELECT TO_NUMBER(:P600_PRCS_4) CONTADOR,',
'        ''<a href="''||',
'        apex_page.get_url(',
'            p_application => 109,',
'            p_page => 603,',
'            p_items => ''P603_ID_REGION,P603_MODULO'',',
'            p_values =>''4,COSME''',
'        )||''">''||''ETIQUETAS DUPLICADAS''||''</a>'' ENLACE, ',
'        ''#27AE60''COLOR, 4 ORDEN ',
'    FROM DUAL WHERE :P600_PRCS_4 >= 0',
'    UNION ALL',
'    SELECT TO_NUMBER(:P600_PRCS_5) CONTADOR,',
'        ''<a href="''||',
'        apex_page.get_url(',
'            p_application => 109,',
'            p_page => 603,',
'            p_items => ''P603_ID_REGION,P603_MODULO'',',
'            p_values =>''5,COSME''',
'        )||''">''||''REPORTE-IC SIN CONSUMO-IM <span style="color: red;">*</span>''||''</a>'' ENLACE, ',
'        ''#27AE60''COLOR, 5 ORDEN ',
'    FROM DUAL WHERE :P600_PRCS_5 >= 0',
'    UNION ALL',
'    SELECT TO_NUMBER(:P600_PRCS_6) CONTADOR,',
'        ''<a href="''||',
'        apex_page.get_url(',
'            p_application => 109,',
'            p_page => 603,',
'            p_items => ''P603_ID_REGION,P603_MODULO'',',
'            p_values =>''6,COSME''',
'        )||''">''||''DESPERDICIO PM1 EN REPORTE PRIMERA''||''</a>'' ENLACE, ',
'        ''#27AE60''COLOR, 6 ORDEN ',
'    FROM DUAL WHERE :P600_PRCS_6 >= 0',
'    UNION ALL',
'    SELECT TO_NUMBER(:P600_PRCS_7) CONTADOR,',
'        ''<a href="''||',
'        apex_page.get_url(',
'            p_application => 109,',
'            p_page => 603,',
'            p_items => ''P603_ID_REGION,P603_MODULO'',',
'            p_values =>''7,COSME''',
unistr('        )||''">''||''\00D3RDENES CON ESTADO <= 30 <span style="color: red;">*</span>''||''</a>'' ENLACE, '),
'        ''#27AE60''COLOR, 7 ORDEN ',
'    FROM DUAL WHERE :P600_PRCS_7 >= 0',
'    UNION ALL',
'    SELECT TO_NUMBER(:P600_PRCS_8) CONTADOR,',
'        ''<a href="''||',
'        apex_page.get_url(',
'            p_application => 109,',
'            p_page => 603,',
'            p_items => ''P603_ID_REGION,P603_MODULO'',',
'            p_values =>''8,COSME''',
'        )||''">''||''PROCESOS DE INVENTARIOS ABIERTOS <span style="color: red;">*</span>''||''</a>'' ENLACE, ',
'        ''#27AE60''COLOR, 8 ORDEN ',
'    FROM DUAL WHERE :P600_PRCS_8 >= 0',
'    UNION ALL',
'    SELECT TO_NUMBER(:P600_PRCS_9) CONTADOR,',
'        ''<a href="''||',
'        apex_page.get_url(',
'            p_application => 109,',
'            p_page => 603,',
'            p_items => ''P603_ID_REGION,P603_MODULO'',',
'            p_values =>''9,COSME''',
'        )||''">''||''DUPLICIDAD TRANSFERENCIA ENTRE BODEGAS''||''</a>'' ENLACE, ',
'        ''#27AE60''COLOR, 9 ORDEN ',
'    FROM DUAL WHERE :P600_PRCS_9 >= 0',
'    UNION ALL',
'    SELECT TO_NUMBER(:P600_PRCS_10) CONTADOR,',
'        ''<a href="''||',
'        apex_page.get_url(',
'            p_application => 109,',
'            p_page => 603,',
'            p_items => ''P603_ID_REGION,P603_MODULO'',',
'            p_values =>''10,COSME''',
unistr('        )||''">''||''ESPERA DE CONFIRMACI\00D3N CONTRAPARTIDA DE TRANSFERENCIA ENTRE BODEGAS''||''</a>'' ENLACE, '),
'        ''#27AE60''COLOR, 10 ORDEN ',
'    FROM DUAL WHERE :P600_PRCS_10 >= 0',
'    UNION ALL',
'    SELECT TO_NUMBER(:P600_PRCS_11) CONTADOR,',
'        ''<a href="''||',
'        apex_page.get_url(',
'            p_application => 109,',
'            p_page => 603,',
'            p_items => ''P603_ID_REGION,P603_MODULO'',',
'            p_values =>''11,COSME''',
'        )||''">''||''ESTADO MENOR A 620 DE TRANSFERENCIA ENTRE BODEGAS''||''</a>'' ENLACE, ',
'        ''#27AE60''COLOR, 11 ORDEN ',
'    FROM DUAL WHERE :P600_PRCS_11 >= 0',
'    UNION ALL',
'    SELECT TO_NUMBER(:P600_PRCS_12) CONTADOR,',
'        ''<a href="''||',
'        apex_page.get_url(',
'            p_application => 109,',
'            p_page => 603,',
'            p_items => ''P603_ID_REGION,P603_MODULO'',',
'            p_values =>''12,COSME''',
'        )||''">''||''DUPLICIDAD COSTO REPORTE HORAS -IH''||''</a>'' ENLACE, ',
'        ''#27AE60''COLOR, 12 ORDEN ',
'    FROM DUAL WHERE :P600_PRCS_12 >= 0',
'    UNION ALL',
'    SELECT TO_NUMBER(:P600_PRCS_13) CONTADOR,',
'        ''<a href="''||',
'        apex_page.get_url(',
'            p_application => 109,',
'            p_page => 603,',
'            p_items => ''P603_ID_REGION,P603_MODULO'',',
'            p_values =>''13,COSME''',
'        )||''">''||''SOBREGIROS COSTO DESPERDICIO- IS''||''</a>'' ENLACE, ',
'        ''#27AE60''COLOR, 13 ORDEN ',
'    FROM DUAL WHERE :P600_PRCS_13 >= 0',
'    UNION ALL',
'    SELECT TO_NUMBER(:P600_PRCS_14) CONTADOR,',
'        ''<a href="''||',
'        apex_page.get_url(',
'            p_application => 109,',
'            p_page => 603,',
'            p_items => ''P603_ID_REGION,P603_MODULO'',',
'            p_values =>''14,COSME''',
unistr('        )||''">''||''SALDOS NEGATIVOS EN M\00C1QUINA''||''</a>'' ENLACE, '),
'        ''#27AE60''COLOR, 14 ORDEN ',
'    FROM DUAL WHERE :P600_PRCS_14 >= 0',
'    UNION ALL',
'    SELECT TO_NUMBER(:P600_PRCS_15) CONTADOR,',
'        ''<a href="''||',
'        apex_page.get_url(',
'            p_application => 109,',
'            p_page => 603,',
'            p_items => ''P603_ID_REGION,P603_MODULO'',',
'            p_values =>''15,COSME''',
unistr('        )||''">''||''PRODUCTOS SIN COSTEO EST\00C1NDAR (07)''||''</a>'' ENLACE, '),
'        ''#27AE60''COLOR, 15 ORDEN ',
'    FROM DUAL WHERE :P600_PRCS_15 >= 0',
'    UNION ALL',
'    SELECT TO_NUMBER(:P600_PRCS_16) CONTADOR,',
'        ''<a href="''||',
'        apex_page.get_url(',
'            p_application => 109,',
'            p_page => 603,',
'            p_items => ''P603_ID_REGION,P603_MODULO'',',
'            p_values =>''16,COSME''',
'        )||''">''||''MATERIA PRIMA SIN COSTO PROMEDIO (02)''||''</a>'' ENLACE, ',
'        ''#27AE60''COLOR, 16 ORDEN ',
'    FROM DUAL WHERE :P600_PRCS_16 >= 0',
'    UNION ALL',
'    SELECT TO_NUMBER(:P600_PRCS_17) CONTADOR,',
'        ''<a href="''||',
'        apex_page.get_url(',
'            p_application => 109,',
'            p_page => 603,',
'            p_items => ''P603_ID_REGION,P603_MODULO'',',
'            p_values =>''17,COSME''',
'        )||''">''||''SALDOS DE STOCK CON VALOR 0''||''</a>'' ENLACE, ',
'        ''#27AE60''COLOR, 17 ORDEN ',
'    FROM DUAL WHERE :P600_PRCS_17 >= 0',
'    UNION ALL',
'',
'    SELECT ',
'    -- TO_NUMBER(:P600_PRCS_1) +',
'    TO_NUMBER(:P600_PRCS_2) +',
'    TO_NUMBER(:P600_PRCS_3) +',
'    TO_NUMBER(:P600_PRCS_4) +',
'    TO_NUMBER(:P600_PRCS_5) +',
'    TO_NUMBER(:P600_PRCS_6) +',
'    TO_NUMBER(:P600_PRCS_7) +',
'    TO_NUMBER(:P600_PRCS_8) +',
'    TO_NUMBER(:P600_PRCS_9) +',
'    TO_NUMBER(:P600_PRCS_10) +',
'    TO_NUMBER(:P600_PRCS_11) +',
'    TO_NUMBER(:P600_PRCS_12) +',
'    TO_NUMBER(:P600_PRCS_13) +',
'    TO_NUMBER(:P600_PRCS_14) +',
'    TO_NUMBER(:P600_PRCS_15) +',
'    TO_NUMBER(:P600_PRCS_16) +',
'    TO_NUMBER(:P600_PRCS_17)',
'     CONTADOR,',
'        ''<a>TOTAL</a>'' ENLACE, ',
'        ''#F95C4C''COLOR, 100 ORDEN ',
'    FROM DUAL',
')',
'ORDER BY ORDEN ASC'))
,p_display_when_condition=>':P600_MODULO_ACTIVO = ''1'' OR INSTR(:P600_MODULO_ACTIVO, ''COSME'') > 0'
,p_display_when_cond2=>'PLSQL'
,p_display_condition_type=>'EXPRESSION'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(37833900716106539)
,p_query_num_rows=>100
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_show_nulls_as=>'-'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
,p_updated_on=>wwv_flow_imp.dz('20260514212722Z')
,p_updated_by=>'JBALCAZAR'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(244445892773546042)
,p_query_column_id=>1
,p_column_alias=>'CARD_TITLE'
,p_column_display_sequence=>10
,p_column_heading=>'Card Title'
,p_use_as_row_header=>'N'
,p_column_html_expression=>'<span style = "color : #CARD_COLOR#"> #CARD_TITLE#</span>'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(244447055196546044)
,p_query_column_id=>2
,p_column_alias=>'CARD_SUBTITLE'
,p_column_display_sequence=>40
,p_column_heading=>'Card Subtitle'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(244446608007546044)
,p_query_column_id=>3
,p_column_alias=>'CARD_COLOR'
,p_column_display_sequence=>30
,p_column_heading=>'Card Color'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(244446227713546043)
,p_query_column_id=>4
,p_column_alias=>'ORDEN'
,p_column_display_sequence=>20
,p_column_heading=>'Orden'
,p_use_as_row_header=>'N'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(438782051443061550)
,p_name=>unistr('Log\00EDstica MP')
,p_parent_plug_id=>wwv_flow_imp.id(428697844435310434)
,p_template=>wwv_flow_imp.id(38289867500120143)
,p_display_sequence=>100
,p_include_in_reg_disp_sel_yn=>'Y'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_component_template_options=>'#DEFAULT#:u-colors:t-Cards--displaySubtitle:t-Cards--basic:t-Cards--5cols:t-Cards--hideBody:t-Cards--animRaiseCard:t-Report--hideNoPagination'
,p_display_point=>'SUB_REGIONS'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT CONTADOR AS CARD_TITLE, ENLACE   CARD_SUBTITLE , COLOR AS CARD_COLOR,  ORDEN  ',
'FROM (',
'    SELECT TO_NUMBER(:P600_LOMP_1) CONTADOR,',
'        ''<a href="''||',
'        apex_page.get_url(',
'            p_application => 109,',
'            p_page => 603,',
'            p_items => ''P603_ID_REGION,P603_MODULO'',',
'            p_values =>''1,DOP339''',
'        )||''">''||''SALDOS EN CANTIDAD NEGATIVOS''||''</a>'' ENLACE, ',
'        ''#27AE60''COLOR, 1 ORDEN ',
'    FROM DUAL WHERE :P600_LOMP_1 >= 0',
'    UNION ALL',
'    SELECT TO_NUMBER(:P600_LOMP_2) CONTADOR,',
'        ''<a href="''||',
'        apex_page.get_url(',
'            p_application => 109,',
'            p_page => 603,',
'            p_items => ''P603_ID_REGION,P603_MODULO'',',
'            p_values =>''2,DOP339''',
'        )||''">''||''DUPLICIDAD EN TRANSFERENCIA ENTRE BODEGAS''||''</a>'' ENLACE, ',
'        ''#27AE60''COLOR, 2 ORDEN ',
'    FROM DUAL WHERE :P600_LOMP_2 >= 0',
'    UNION ALL',
'    SELECT TO_NUMBER(:P600_LOMP_3) CONTADOR,',
'        ''<a href="''||',
'        apex_page.get_url(',
'            p_application => 109,',
'            p_page => 603,',
'            p_items => ''P603_ID_REGION,P603_MODULO'',',
'            p_values =>''3,DOP339''',
'        )||''">''||''CONFIRMACIONES COSTO 0 DE TRANSFERENCIAS ENTRE BODEGAS''||''</a>'' ENLACE, ',
'        ''#27AE60''COLOR, 3 ORDEN ',
'    FROM DUAL WHERE :P600_LOMP_3 >= 0',
'    UNION ALL',
'    SELECT TO_NUMBER(:P600_LOMP_4) CONTADOR,',
'        ''<a href="''||',
'        apex_page.get_url(',
'            p_application => 109,',
'            p_page => 603,',
'            p_items => ''P603_ID_REGION,P603_MODULO'',',
'            p_values =>''4,DOP339''',
'        )||''">''||''TRANSACCIONES ABIERTAS DE TRANSFERENCIA ENTRE BODEGAS''||''</a>'' ENLACE, ',
'        ''#27AE60''COLOR, 4 ORDEN ',
'    FROM DUAL WHERE :P600_LOMP_4 >= 0',
'    UNION ALL',
'    SELECT TO_NUMBER(:P600_LOMP_5) CONTADOR,',
'        ''<a href="''||',
'        apex_page.get_url(',
'            p_application => 109,',
'            p_page => 603,',
'            p_items => ''P603_ID_REGION,P603_MODULO'',',
'            p_values =>''5,DOP339''',
'        )||''">''||''TRANSACCIONES EN ESTADO SIGUIENTE <999''||''</a>'' ENLACE, ',
'        ''#27AE60''COLOR, 5 ORDEN ',
'    FROM DUAL WHERE :P600_LOMP_5 >= 0',
'    UNION ALL',
'    SELECT TO_NUMBER(:P600_LOMP_6) CONTADOR,',
'        ''<a href="''||',
'        apex_page.get_url(',
'            p_application => 109,',
'            p_page => 603,',
'            p_items => ''P603_ID_REGION,P603_MODULO'',',
'            p_values =>''6,DOP339''',
unistr('        )||''">''||''PRODUCTOS PARAMETRIZADOS QUE NECESITEN LOTE A EXCEPCI\00D3N DE SEMIELABORADOS''||''</a>'' ENLACE, '),
'        ''#27AE60''COLOR, 6 ORDEN ',
'    FROM DUAL WHERE :P600_LOMP_6 >= 0',
'    UNION ALL',
'    SELECT TO_NUMBER(:P600_LOMP_7) CONTADOR,',
'        ''<a href="''||',
'        apex_page.get_url(',
'            p_application => 109,',
'            p_page => 603,',
'            p_items => ''P603_ID_REGION,P603_MODULO'',',
'            p_values =>''7,DOP339''',
unistr('        )||''">''||''PRODUCTOS QUE TENGAN SALDO EN LOTE A EXCEPCI\00D3N DE SEMIELABORADOS''||''</a>'' ENLACE, '),
'        ''#27AE60''COLOR, 7 ORDEN ',
'    FROM DUAL WHERE :P600_LOMP_7 >= 0',
'    UNION ALL',
'    SELECT TO_NUMBER(:P600_LOMP_8) CONTADOR,',
'        ''<a href="''||',
'        apex_page.get_url(',
'            p_application => 109,',
'            p_page => 603,',
'            p_items => ''P603_ID_REGION,P603_MODULO'',',
'            p_values =>''8,DOP339''',
unistr('        )||''">''||''TRANSACCIONES QUE TENGAN DISTINTO LA FECHA TRANSACCI\00D3N A LA FECHA LM''||''</a>'' ENLACE, '),
'        ''#27AE60''COLOR, 8 ORDEN ',
'    FROM DUAL WHERE :P600_LOMP_8 >= 0',
'    UNION ALL',
'    SELECT TO_NUMBER(:P600_LOMP_9) CONTADOR,',
'        ''<a href="''||',
'        apex_page.get_url(',
'            p_application => 109,',
'            p_page => 603,',
'            p_items => ''P603_ID_REGION,P603_MODULO'',',
'            p_values =>''9,DOP339''',
unistr('        )||''">''||''VARIACI\00D3N EN COSTO PROMEDIO VS TRANSACCIONAL''||''</a>'' ENLACE, '),
'        ''#27AE60''COLOR, 9 ORDEN ',
'    FROM DUAL WHERE :P600_LOMP_9 >= 0',
'    UNION ALL',
'    SELECT TO_NUMBER(:P600_LOMP_10) CONTADOR,',
'        ''<a href="''||',
'        apex_page.get_url(',
'            p_application => 109,',
'            p_page => 603,',
'            p_items => ''P603_ID_REGION,P603_MODULO'',',
'            p_values =>''10,DOP339''',
'        )||''">''||''PROCESOS DE INVENTARIOS ABIERTOS <span style="color: red;">*</span>''||''</a>'' ENLACE, ',
'        ''#27AE60''COLOR, 10 ORDEN ',
'    FROM DUAL WHERE :P600_LOMP_10 >= 0',
'    UNION ALL',
'    SELECT TO_NUMBER(:P600_LOMP_11) CONTADOR,',
'        ''<a href="''||',
'        apex_page.get_url(',
'            p_application => 109,',
'            p_page => 603,',
'            p_items => ''P603_ID_REGION,P603_MODULO'',',
'            p_values =>''11,DOP339''',
'        )||''">''||''ETIQUETAS EN ESTADO INGRESADO DEL MES''||''</a>'' ENLACE, ',
'        ''#27AE60''COLOR, 11 ORDEN ',
'    FROM DUAL WHERE :P600_LOMP_11 >= 0',
'    UNION ALL',
'    SELECT TO_NUMBER(:P600_LOMP_12) CONTADOR,',
'        ''<a href="''||',
'        apex_page.get_url(',
'            p_application => 109,',
'            p_page => 603,',
'            p_items => ''P603_ID_REGION,P603_MODULO'',',
'            p_values =>''12,DOP339''',
'        )||''">''||''TRANSACCIONES PENDIENTES DE RECOLECTAR''||''</a>'' ENLACE, ',
'        ''#27AE60''COLOR, 12 ORDEN ',
'    FROM DUAL WHERE :P600_LOMP_12 >= 0',
'    UNION ALL',
'    SELECT TO_NUMBER(:P600_LOMP_13) CONTADOR,',
'        ''<a href="''||',
'        apex_page.get_url(',
'            p_application => 109,',
'            p_page => 603,',
'            p_items => ''P603_ID_REGION,P603_MODULO'',',
'            p_values =>''13,DOP339''',
'        )||''">''||''SALDOS DE STOCK CON VALOR 0''||''</a>'' ENLACE, ',
'        ''#27AE60''COLOR, 13 ORDEN ',
'    FROM DUAL WHERE :P600_LOMP_13 >= 0',
'    UNION ALL',
'    SELECT ',
'        TO_NUMBER(:P600_LOMP_1) +',
'        TO_NUMBER(:P600_LOMP_2) +',
'        TO_NUMBER(:P600_LOMP_3) +',
'        TO_NUMBER(:P600_LOMP_4) +',
'        TO_NUMBER(:P600_LOMP_5) +',
'        TO_NUMBER(:P600_LOMP_6) +',
'        TO_NUMBER(:P600_LOMP_7) +',
'        TO_NUMBER(:P600_LOMP_8) +',
'        TO_NUMBER(:P600_LOMP_9) +',
'        TO_NUMBER(:P600_LOMP_10) +',
'        TO_NUMBER(:P600_LOMP_11) +',
'        TO_NUMBER(:P600_LOMP_12) +',
'        TO_NUMBER(:P600_LOMP_13)',
'    ',
'        CONTADOR,',
'        ''<a>TOTAL</a>'' ENLACE, ',
'        ''#F95C4C''COLOR, 100 ORDEN ',
'    FROM DUAL',
')',
'ORDER BY ORDEN ASC'))
,p_display_when_condition=>':P600_MODULO_ACTIVO = ''1'' OR INSTR(:P600_MODULO_ACTIVO, ''DOP339'') > 0'
,p_display_when_cond2=>'PLSQL'
,p_display_condition_type=>'EXPRESSION'
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(37833900716106539)
,p_query_num_rows=>100
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_show_nulls_as=>'-'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
,p_updated_on=>wwv_flow_imp.dz('20260505152717Z')
,p_updated_by=>'JBALCAZAR'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(244451850164546050)
,p_query_column_id=>1
,p_column_alias=>'CARD_TITLE'
,p_column_display_sequence=>10
,p_column_heading=>'Card Title'
,p_use_as_row_header=>'N'
,p_column_html_expression=>'<span style = "color : #CARD_COLOR#"> #CARD_TITLE#</span>'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(244453061083546051)
,p_query_column_id=>2
,p_column_alias=>'CARD_SUBTITLE'
,p_column_display_sequence=>40
,p_column_heading=>'Card Subtitle'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(244452605898546051)
,p_query_column_id=>3
,p_column_alias=>'CARD_COLOR'
,p_column_display_sequence=>30
,p_column_heading=>'Card Color'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(244452293180546050)
,p_query_column_id=>4
,p_column_alias=>'ORDEN'
,p_column_display_sequence=>20
,p_column_heading=>'Orden'
,p_use_as_row_header=>'N'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(438782523986061555)
,p_name=>unistr('Log\00EDstica BDG Menores')
,p_parent_plug_id=>wwv_flow_imp.id(428697844435310434)
,p_template=>wwv_flow_imp.id(38289867500120143)
,p_display_sequence=>110
,p_include_in_reg_disp_sel_yn=>'Y'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_component_template_options=>'#DEFAULT#:u-colors:t-Cards--displaySubtitle:t-Cards--basic:t-Cards--5cols:t-Cards--hideBody:t-Cards--animRaiseCard:t-Report--hideNoPagination'
,p_display_point=>'SUB_REGIONS'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT CONTADOR AS CARD_TITLE, ENLACE   CARD_SUBTITLE , COLOR AS CARD_COLOR,  ORDEN  ',
'FROM (',
'    SELECT TO_NUMBER(:P600_LOME_1) CONTADOR,',
'        ''<a href="''||',
'        apex_page.get_url(',
'            p_application => 109,',
'            p_page => 603,',
'            p_items => ''P603_ID_REGION,P603_MODULO'',',
'            p_values =>''1,DOP347''',
'        )||''">''||''SALDOS EN CANTIDAD NEGATIVOS''||''</a>'' ENLACE, ',
'        ''#27AE60''COLOR, 1 ORDEN ',
'    FROM DUAL WHERE :P600_LOME_1 >= 0',
'    UNION ALL',
'    SELECT TO_NUMBER(:P600_LOME_2) CONTADOR,',
'        ''<a href="''||',
'        apex_page.get_url(',
'            p_application => 109,',
'            p_page => 603,',
'            p_items => ''P603_ID_REGION,P603_MODULO'',',
'            p_values =>''2,DOP347''',
'        )||''">''||''DUPLICIDAD EN TRANSFERENCIA ENTRE BODEGAS''||''</a>'' ENLACE, ',
'        ''#27AE60''COLOR, 2 ORDEN ',
'    FROM DUAL WHERE :P600_LOME_2 >= 0',
'    UNION ALL',
'    SELECT TO_NUMBER(:P600_LOME_3) CONTADOR,',
'        ''<a href="''||',
'        apex_page.get_url(',
'            p_application => 109,',
'            p_page => 603,',
'            p_items => ''P603_ID_REGION,P603_MODULO'',',
'            p_values =>''3,DOP347''',
'        )||''">''||''CONFIRMACIONES COSTO 0 DE TRANSFERENCIAS ENTRE BODEGAS''||''</a>'' ENLACE, ',
'        ''#27AE60''COLOR, 3 ORDEN ',
'    FROM DUAL WHERE :P600_LOME_3 >= 0',
'    UNION ALL',
'    SELECT TO_NUMBER(:P600_LOME_4) CONTADOR,',
'        ''<a href="''||',
'        apex_page.get_url(',
'            p_application => 109,',
'            p_page => 603,',
'            p_items => ''P603_ID_REGION,P603_MODULO'',',
'            p_values =>''4,DOP347''',
'        )||''">''||''TRANSACCIONES ABIERTAS DE TRANSFERENCIA ENTRE BODEGAS''||''</a>'' ENLACE, ',
'        ''#27AE60''COLOR, 4 ORDEN ',
'    FROM DUAL WHERE :P600_LOME_4 >= 0',
'    UNION ALL',
'    SELECT TO_NUMBER(:P600_LOME_5) CONTADOR,',
'        ''<a href="''||',
'        apex_page.get_url(',
'            p_application => 109,',
'            p_page => 603,',
'            p_items => ''P603_ID_REGION,P603_MODULO'',',
'            p_values =>''5,DOP347''',
'        )||''">''||''TRANSACCIONES EN ESTADO SIGUIENTE <999''||''</a>'' ENLACE, ',
'        ''#27AE60''COLOR, 5 ORDEN ',
'    FROM DUAL WHERE :P600_LOME_5 >= 0',
'    UNION ALL',
'    SELECT TO_NUMBER(:P600_LOME_6) CONTADOR,',
'        ''<a href="''||',
'        apex_page.get_url(',
'            p_application => 109,',
'            p_page => 603,',
'            p_items => ''P603_ID_REGION,P603_MODULO'',',
'            p_values =>''6,DOP347''',
unistr('        )||''">''||''PRODUCTOS PARAMETRIZADOS QUE NECESITEN LOTE A EXCEPCI\00D3N DE SEMIELABORADOS''||''</a>'' ENLACE, '),
'        ''#27AE60''COLOR, 6 ORDEN ',
'    FROM DUAL WHERE :P600_LOME_6 >= 0',
'    UNION ALL',
'    SELECT TO_NUMBER(:P600_LOME_7) CONTADOR,',
'        ''<a href="''||',
'        apex_page.get_url(',
'            p_application => 109,',
'            p_page => 603,',
'            p_items => ''P603_ID_REGION,P603_MODULO'',',
'            p_values =>''7,DOP347''',
unistr('        )||''">''||''PRODUCTOS QUE TENGAN SALDO EN LOTE A EXCEPCI\00D3N DE SEMIELABORADOS''||''</a>'' ENLACE, '),
'        ''#27AE60''COLOR, 7 ORDEN ',
'    FROM DUAL WHERE :P600_LOME_7 >= 0',
'    UNION ALL',
'    SELECT TO_NUMBER(:P600_LOME_8) CONTADOR,',
'        ''<a href="''||',
'        apex_page.get_url(',
'            p_application => 109,',
'            p_page => 603,',
'            p_items => ''P603_ID_REGION,P603_MODULO'',',
'            p_values =>''8,DOP347''',
unistr('        )||''">''||''TRANSACCIONES QUE TENGAN DISTINTO LA FECHA TRANSACCI\00D3N A LA FECHA LM''||''</a>'' ENLACE, '),
'        ''#27AE60''COLOR, 8 ORDEN ',
'    FROM DUAL WHERE :P600_LOME_8 >= 0',
'    UNION ALL',
'    SELECT TO_NUMBER(:P600_LOME_9) CONTADOR,',
'        ''<a href="''||',
'        apex_page.get_url(',
'            p_application => 109,',
'            p_page => 603,',
'            p_items => ''P603_ID_REGION,P603_MODULO'',',
'            p_values =>''9,DOP347''',
unistr('        )||''">''||''VARIACI\00D3N EN COSTO PROMEDIO VS TRANSACCIONAL''||''</a>'' ENLACE, '),
'        ''#27AE60''COLOR, 9 ORDEN ',
'    FROM DUAL WHERE :P600_LOME_9 >= 0',
'    UNION ALL',
'    SELECT TO_NUMBER(:P600_LOME_10) CONTADOR,',
'        ''<a href="''||',
'        apex_page.get_url(',
'            p_application => 109,',
'            p_page => 603,',
'            p_items => ''P603_ID_REGION,P603_MODULO'',',
'            p_values =>''10,DOP347''',
'        )||''">''||''PROCESOS DE INVENTARIOS ABIERTOS <span style="color: red;">*</span>''||''</a>'' ENLACE, ',
'        ''#27AE60''COLOR, 10 ORDEN ',
'    FROM DUAL WHERE :P600_LOME_10 >= 0',
'    UNION ALL',
'    SELECT TO_NUMBER(:P600_LOME_11) CONTADOR,',
'        ''<a href="''||',
'        apex_page.get_url(',
'            p_application => 109,',
'            p_page => 603,',
'            p_items => ''P603_ID_REGION,P603_MODULO'',',
'            p_values =>''11,DOP347''',
'        )||''">''||''ETIQUETAS EN ESTADO INGRESADO DEL MES''||''</a>'' ENLACE, ',
'        ''#27AE60''COLOR, 11 ORDEN ',
'    FROM DUAL WHERE :P600_LOME_11 >= 0',
'    UNION ALL',
'    SELECT TO_NUMBER(:P600_LOME_12) CONTADOR,',
'        ''<a href="''||',
'        apex_page.get_url(',
'            p_application => 109,',
'            p_page => 603,',
'            p_items => ''P603_ID_REGION,P603_MODULO'',',
'            p_values =>''12,DOP347''',
'        )||''">''||''TRANSACCIONES PENDIENTES DE RECOLECTAR''||''</a>'' ENLACE, ',
'        ''#27AE60''COLOR, 12 ORDEN ',
'    FROM DUAL WHERE :P600_LOME_12 >= 0',
'    UNION ALL',
'    SELECT TO_NUMBER(:P600_LOME_13) CONTADOR,',
'        ''<a href="''||',
'        apex_page.get_url(',
'            p_application => 109,',
'            p_page => 603,',
'            p_items => ''P603_ID_REGION,P603_MODULO'',',
'            p_values =>''13,DOP347''',
'        )||''">''||''SALDOS DE STOCK CON VALOR 0''||''</a>'' ENLACE, ',
'        ''#27AE60''COLOR, 13 ORDEN ',
'    FROM DUAL WHERE :P600_LOME_13 >= 0',
'    UNION ALL',
'    SELECT ',
'        TO_NUMBER(:P600_LOME_1) +',
'        TO_NUMBER(:P600_LOME_2) +',
'        TO_NUMBER(:P600_LOME_3) +',
'        TO_NUMBER(:P600_LOME_4) +',
'        TO_NUMBER(:P600_LOME_5) +',
'        TO_NUMBER(:P600_LOME_6) +',
'        TO_NUMBER(:P600_LOME_7) +',
'        TO_NUMBER(:P600_LOME_8) +',
'        TO_NUMBER(:P600_LOME_9) +',
'        TO_NUMBER(:P600_LOME_10) +',
'        TO_NUMBER(:P600_LOME_11) +',
'        TO_NUMBER(:P600_LOME_12) +',
'        TO_NUMBER(:P600_LOME_13)',
'    ',
'        CONTADOR,',
'        ''<a>TOTAL</a>'' ENLACE, ',
'        ''#F95C4C''COLOR, 100 ORDEN ',
'    FROM DUAL',
')',
'ORDER BY ORDEN ASC'))
,p_display_when_condition=>':P600_MODULO_ACTIVO = ''1'' OR INSTR(:P600_MODULO_ACTIVO, ''DOP347'') > 0'
,p_display_when_cond2=>'PLSQL'
,p_display_condition_type=>'EXPRESSION'
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(37833900716106539)
,p_query_num_rows=>100
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_show_nulls_as=>'-'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
,p_updated_on=>wwv_flow_imp.dz('20260505152717Z')
,p_updated_by=>'JBALCAZAR'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(244455880436546054)
,p_query_column_id=>1
,p_column_alias=>'CARD_TITLE'
,p_column_display_sequence=>10
,p_column_heading=>'Card Title'
,p_use_as_row_header=>'N'
,p_column_html_expression=>'<span style = "color : #CARD_COLOR#"> #CARD_TITLE#</span>'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(244457085034546055)
,p_query_column_id=>2
,p_column_alias=>'CARD_SUBTITLE'
,p_column_display_sequence=>40
,p_column_heading=>'Card Subtitle'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(244456676965546055)
,p_query_column_id=>3
,p_column_alias=>'CARD_COLOR'
,p_column_display_sequence=>30
,p_column_heading=>'Card Color'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(244456239118546054)
,p_query_column_id=>4
,p_column_alias=>'ORDEN'
,p_column_display_sequence=>20
,p_column_heading=>'Orden'
,p_use_as_row_header=>'N'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(440627239981409940)
,p_name=>'Cuentas x Pagar (Colaboradores)'
,p_parent_plug_id=>wwv_flow_imp.id(428697844435310434)
,p_template=>wwv_flow_imp.id(38289867500120143)
,p_display_sequence=>160
,p_include_in_reg_disp_sel_yn=>'Y'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_component_template_options=>'#DEFAULT#:u-colors:t-Cards--displaySubtitle:t-Cards--basic:t-Cards--5cols:t-Cards--hideBody:t-Cards--animRaiseCard:t-Report--hideNoPagination'
,p_display_point=>'SUB_REGIONS'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT CONTADOR AS CARD_TITLE, ENLACE   CARD_SUBTITLE , COLOR AS CARD_COLOR,  ORDEN  ',
'FROM (',
'    SELECT TO_NUMBER(:P600_CXPC_1) CONTADOR,',
'        ''<a href="''||',
'        apex_page.get_url(',
'            p_application => 109,',
'            p_page => 603,',
'            p_items => ''P603_ID_REGION,P603_MODULO'',',
'            p_values =>''1,CXPCF''',
unistr('        )||''">''||''EXISTENCIA DE DOS O M\00C1S VI\00C1TICOS POR PERSONA EN MISMA FECHA''||''</a>'' ENLACE, '),
'        ''#27AE60''COLOR, 1 ORDEN ',
'    FROM DUAL WHERE :P600_CXPC_1 >= 0',
'    UNION ALL',
'    SELECT TO_NUMBER(:P600_CXPC_2) CONTADOR,',
'        ''<a href="''||',
'        apex_page.get_url(',
'            p_application => 109,',
'            p_page => 603,',
'            p_items => ''P603_ID_REGION,P603_MODULO'',',
'            p_values =>''2,CXPCF''',
unistr('        )||''">''||''VI\00C1TICOS PENDIENTES DE LIQUIDAR (PENDIENTE DE SUBIR LOS SOPORTES)''||''</a>'' ENLACE, '),
'        ''#27AE60''COLOR, 2 ORDEN ',
'    FROM DUAL WHERE :P600_CXPC_2 >= 0',
'    UNION ALL',
'    SELECT TO_NUMBER(:P600_CXPC_3) CONTADOR,',
'        ''<a href="''||',
'        apex_page.get_url(',
'            p_application => 109,',
'            p_page => 603,',
'            p_items => ''P603_ID_REGION,P603_MODULO'',',
'            p_values =>''3,CXPCF''',
unistr('        )||''">''||''VI\00C1TICOS SIN LIQUIDAR CON FECHA M\00C1XIMA HASTA EL 1 DEL SIGUIENTE MES  (SEGUNDA QUINCENA)''||''</a>'' ENLACE, '),
'        ''#27AE60''COLOR, 3 ORDEN ',
'    FROM DUAL WHERE :P600_CXPC_3 >= 0',
'    UNION ALL',
'    SELECT TO_NUMBER(:P600_CXPC_4) CONTADOR,',
'        ''<a href="''||',
'        apex_page.get_url(',
'            p_application => 109,',
'            p_page => 603,',
'            p_items => ''P603_ID_REGION,P603_MODULO'',',
'            p_values =>''4,CXPCF''',
unistr('        )||''">''||''VI\00C1TICOS ENVIADOS A CORTE DESPU\00C9S DEL 22 CON FECHA FIN MENOR AL 20''||''</a>'' ENLACE, '),
'        ''#27AE60''COLOR, 4 ORDEN ',
'    FROM DUAL WHERE :P600_CXPC_4 >= 0',
'    UNION ALL',
'    SELECT ',
'        TO_NUMBER(:P600_CXPC_1) +',
'        TO_NUMBER(:P600_CXPC_2) +',
'        TO_NUMBER(:P600_CXPC_3) +',
'        TO_NUMBER(:P600_CXPC_4)',
'         CONTADOR,',
'        ''<a>TOTAL</a>'' ENLACE, ',
'        ''#F95C4C''COLOR, 100 ORDEN ',
'    FROM DUAL',
')',
'ORDER BY ORDEN ASC'))
,p_display_when_condition=>':P600_MODULO_ACTIVO = ''1'' OR INSTR(:P600_MODULO_ACTIVO, ''CXPCF'') > 0'
,p_display_when_cond2=>'PLSQL'
,p_display_condition_type=>'EXPRESSION'
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(37833900716106539)
,p_query_num_rows=>100
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_show_nulls_as=>'-'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
,p_updated_on=>wwv_flow_imp.dz('20260428143608Z')
,p_updated_by=>'JBALCAZAR'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(244437802069546034)
,p_query_column_id=>1
,p_column_alias=>'CARD_TITLE'
,p_column_display_sequence=>10
,p_column_heading=>'Card Title'
,p_use_as_row_header=>'N'
,p_column_html_expression=>'<span style = "color : #CARD_COLOR#"> #CARD_TITLE#</span>'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(244439059143546035)
,p_query_column_id=>2
,p_column_alias=>'CARD_SUBTITLE'
,p_column_display_sequence=>40
,p_column_heading=>'Card Subtitle'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(244438682419546035)
,p_query_column_id=>3
,p_column_alias=>'CARD_COLOR'
,p_column_display_sequence=>30
,p_column_heading=>'Card Color'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(244438273369546035)
,p_query_column_id=>4
,p_column_alias=>'ORDEN'
,p_column_display_sequence=>20
,p_column_heading=>'Orden'
,p_use_as_row_header=>'N'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(444189024952097857)
,p_name=>unistr('Tesorer\00EDa')
,p_parent_plug_id=>wwv_flow_imp.id(428697844435310434)
,p_template=>wwv_flow_imp.id(38289867500120143)
,p_display_sequence=>170
,p_include_in_reg_disp_sel_yn=>'Y'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_component_template_options=>'#DEFAULT#:u-colors:t-Cards--displaySubtitle:t-Cards--basic:t-Cards--5cols:t-Cards--hideBody:t-Cards--animRaiseCard:t-Report--hideNoPagination'
,p_display_point=>'SUB_REGIONS'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT CONTADOR AS CARD_TITLE, ENLACE   CARD_SUBTITLE , COLOR AS CARD_COLOR,  ORDEN  ',
'FROM (',
'    SELECT TO_NUMBER(:P600_TESO_1) CONTADOR,',
'        ''<a href="''||',
'        apex_page.get_url(',
'            p_application => 109,',
'            p_page => 603,',
'            p_items => ''P603_ID_REGION,P603_MODULO'',',
'            p_values =>''1,TESOR''',
'        )||''">''||''EMPLEADOS SIN CUENTA DE BANCO''||''</a>'' ENLACE, ',
'        ''#27AE60''COLOR, 20 ORDEN ',
'    FROM DUAL WHERE :P600_TESO_1 >= 0',
'    UNION ALL',
'    SELECT TO_NUMBER(:P600_TESO_2) CONTADOR,',
'        ''<a href="''||',
'        apex_page.get_url(',
'            p_application => 109,',
'            p_page => 603,',
'            p_items => ''P603_ID_REGION,P603_MODULO'',',
'            p_values =>''2,TESOR''',
unistr('        )||''">''||''CONTROL DE SERVICIOS B\00C1SICOS Y MANTENIMIENTO <span style="color: red;">*</span>''||''</a>'' ENLACE, '),
'        ''#27AE60''COLOR, 21 ORDEN ',
'    FROM DUAL WHERE :P600_TESO_2 >= 0',
'    UNION ALL',
'    SELECT TO_NUMBER(:P600_TESO_3) CONTADOR,',
'        ''<a href="''||',
'        apex_page.get_url(',
'            p_application => 109,',
'            p_page => 603,',
'            p_items => ''P603_ID_REGION,P603_MODULO'',',
'            p_values =>''35,TESOR''',
'        )||''">''||''ASIENTO JE EN CUENTA 71201.04 (intereses ganados)  <span style="color: red;">*</span>''||''</a>'' ENLACE, ',
'        ''#27AE60''COLOR, 22 ORDEN ',
'    FROM DUAL WHERE :P600_TESO_3 >= 0',
'    UNION ALL',
'    SELECT TO_NUMBER(:P600_TESO_4) CONTADOR,',
'        ''<a href="''||',
'        apex_page.get_url(',
'            p_application => 109,',
'            p_page => 603,',
'            p_items => ''P603_ID_REGION,P603_MODULO'',',
'            p_values =>''36,TESOR''',
'        )||''">''||''ASIENTO JE EN CUENTA 16101.65101.03 (COMISIONES BANCOS EXTERIOR) <span style="color: red;">*</span>''||''</a>'' ENLACE, ',
'        ''#27AE60''COLOR, 23 ORDEN ',
'    FROM DUAL WHERE :P600_TESO_4 >= 0',
'    UNION ALL',
'    SELECT TO_NUMBER(:P600_TESO_5) CONTADOR,',
'        ''<a href="''||',
'        apex_page.get_url(',
'            p_application => 109,',
'            p_page => 603,',
'            p_items => ''P603_ID_REGION,P603_MODULO'',',
'            p_values =>''34,TESOR''',
'        )||''">''||''ASIENTOS COMISIONES BANCOS LOCALES <span style="color: red;">*</span>''||''</a>'' ENLACE, ',
'        ''#27AE60''COLOR, 24 ORDEN ',
'    FROM DUAL WHERE :P600_TESO_5 >= 0',
'    UNION ALL',
'    SELECT TO_NUMBER(:P600_TESO_6) CONTADOR,',
'        ''<a href="''||',
'        apex_page.get_url(',
'            p_application => 109,',
'            p_page => 603,',
'            p_items => ''P603_ID_REGION,P603_MODULO'',',
'            p_values =>''37,TESOR''',
'        )||''">''||''CUENTAS DE BANCOS SOBREGIRADAS (SALDOS NEGATIVOS)''||''</a>'' ENLACE, ',
'        ''#27AE60''COLOR, 27 ORDEN ',
'    FROM DUAL WHERE :P600_TESO_6 >= 0',
'    UNION ALL',
'    SELECT ',
'        TO_NUMBER(:P600_TESO_1) +',
'        TO_NUMBER(:P600_TESO_2) +',
'        TO_NUMBER(:P600_TESO_3) +',
'        TO_NUMBER(:P600_TESO_4) +',
'        TO_NUMBER(:P600_TESO_5) +',
'        TO_NUMBER(:P600_TESO_6)',
'         CONTADOR,',
'        ''<a>TOTAL</a>'' ENLACE, ',
'        ''#F95C4C''COLOR, 100 ORDEN ',
'    FROM DUAL',
')',
'ORDER BY ORDEN ASC'))
,p_display_when_condition=>':P600_MODULO_ACTIVO = ''1'' OR INSTR(:P600_MODULO_ACTIVO, ''TESOR'') > 0'
,p_display_when_cond2=>'PLSQL'
,p_display_condition_type=>'EXPRESSION'
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(37833900716106539)
,p_query_num_rows=>100
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_show_nulls_as=>'-'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
,p_updated_on=>wwv_flow_imp.dz('20260506180047Z')
,p_updated_by=>'JBALCAZAR'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(244471829743546077)
,p_query_column_id=>1
,p_column_alias=>'CARD_TITLE'
,p_column_display_sequence=>10
,p_column_heading=>'Card Title'
,p_use_as_row_header=>'N'
,p_column_html_expression=>'<span style = "color : #CARD_COLOR#"> #CARD_TITLE#</span>'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(244473008148546078)
,p_query_column_id=>2
,p_column_alias=>'CARD_SUBTITLE'
,p_column_display_sequence=>40
,p_column_heading=>'Card Subtitle'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(244472653678546077)
,p_query_column_id=>3
,p_column_alias=>'CARD_COLOR'
,p_column_display_sequence=>30
,p_column_heading=>'Card Color'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(244472276534546077)
,p_query_column_id=>4
,p_column_alias=>'ORDEN'
,p_column_display_sequence=>20
,p_column_heading=>'Orden'
,p_use_as_row_header=>'N'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(448953435670315014)
,p_name=>'Cuentas x Cobrar'
,p_parent_plug_id=>wwv_flow_imp.id(428697844435310434)
,p_template=>wwv_flow_imp.id(38289867500120143)
,p_display_sequence=>180
,p_include_in_reg_disp_sel_yn=>'Y'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_component_template_options=>'#DEFAULT#:u-colors:t-Cards--displaySubtitle:t-Cards--basic:t-Cards--5cols:t-Cards--hideBody:t-Cards--animRaiseCard:t-Report--hideNoPagination'
,p_display_point=>'SUB_REGIONS'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT CONTADOR AS CARD_TITLE, ENLACE   CARD_SUBTITLE , COLOR AS CARD_COLOR,  ORDEN  ',
'FROM (',
'    SELECT TO_NUMBER(:P600_CXCP_1) CONTADOR,',
'        ''<a href="''||',
'        apex_page.get_url(',
'            p_application => 109,',
'            p_page => 603,',
'            p_items => ''P603_ID_REGION,P603_MODULO'',',
'            p_values =>''1,CXC''',
unistr('        )||''">''||''CLIENTES SIN ASIGANCI\00D3N DE ASIGNACI\00D3N DE EJECUTIVO VENTAS''||''</a>'' ENLACE, '),
'        ''#27AE60''COLOR, 1 ORDEN ',
'    FROM DUAL WHERE :P600_CXCP_1 >= 0',
'    UNION ALL',
'    SELECT TO_NUMBER(:P600_CXCP_2) CONTADOR,',
'        ''<a href="''||',
'        apex_page.get_url(',
'            p_application => 109,',
'            p_page => 603,',
'            p_items => ''P603_ID_REGION,P603_MODULO'',',
'            p_values =>''2,CXC''',
unistr('        )||''">''||''CLIENTES TIPOS DE RETENCI\00D3N''||''</a>'' ENLACE, '),
'        ''#27AE60''COLOR, 2 ORDEN ',
'    FROM DUAL --WHERE :P600_CXCP_2 >= 0',
'    UNION ALL',
'    SELECT TO_NUMBER(:P600_CXCP_3) CONTADOR,',
'        ''<a href="''||',
'        apex_page.get_url(',
'            p_application => 109,',
'            p_page => 603,',
'            p_items => ''P603_ID_REGION,P603_MODULO'',',
'            p_values =>''3,CXC''',
'        )||''">''||''DONACIONES Y AUTOCONSUMOS SIN CERRARSE''||''</a>'' ENLACE, ',
'        ''#27AE60''COLOR, 3 ORDEN ',
'    FROM DUAL WHERE :P600_CXCP_3 >= 0',
'    UNION ALL',
'    SELECT TO_NUMBER(:P600_CXCP_4) CONTADOR,',
'        ''<a href="''||',
'        apex_page.get_url(',
'            p_application => 109,',
'            p_page => 603,',
'            p_items => ''P603_ID_REGION,P603_MODULO'',',
'            p_values =>''4,CXC''',
unistr('        )||''">''||''FACTURAS SIN RETENCI\00D3N''||''</a>'' ENLACE, '),
'        ''#27AE60''COLOR, 4 ORDEN ',
'    FROM DUAL WHERE :P600_CXCP_4 >= 0',
'    UNION ALL',
'    SELECT TO_NUMBER(:P600_CXCP_5) CONTADOR,',
'        ''<a href="''||',
'        apex_page.get_url(',
'            p_application => 109,',
'            p_page => 603,',
'            p_items => ''P603_ID_REGION,P603_MODULO'',',
'            p_values =>''5,CXC''',
unistr('        )||''">''||''Facturas sin retenci\00F3n, notificaci\00F3n ejecutivos''||''</a>'' ENLACE, '),
'        ''#27AE60''COLOR, 5 ORDEN ',
'    FROM DUAL WHERE :P600_CXCP_5 >= 0',
'    UNION ALL',
'    SELECT TO_NUMBER(:P600_CXCP_6) CONTADOR,',
'        ''<a href="''||',
'        apex_page.get_url(',
'            p_application => 109,',
'            p_page => 603,',
'            p_items => ''P603_ID_REGION,P603_MODULO'',',
'            p_values =>''6,CXC''',
unistr('        )||''">''||''BATCH SIN AFECTACI\00D3N A CUENTAS POR COBRAR''||''</a>'' ENLACE, '),
'        ''#27AE60''COLOR, 6 ORDEN ',
'    FROM DUAL WHERE :P600_CXCP_6 >= 0',
'    UNION ALL',
'    SELECT ',
'        TO_NUMBER(:P600_CXCP_1) +',
'        --TO_NUMBER(:P600_CXCP_2) +',
'        TO_NUMBER(:P600_CXCP_3) +',
'        TO_NUMBER(:P600_CXCP_4) +',
'        TO_NUMBER(:P600_CXCP_5) +',
'        TO_NUMBER(:P600_CXCP_6)',
'         CONTADOR,',
'        ''<a>TOTAL</a>'' ENLACE, ',
'        ''#F95C4C''COLOR, 100 ORDEN ',
'    FROM DUAL',
')',
'ORDER BY ORDEN ASC'))
,p_display_when_condition=>':P600_MODULO_ACTIVO = ''1'' OR INSTR(:P600_MODULO_ACTIVO, ''CXCFI'') > 0'
,p_display_when_cond2=>'PLSQL'
,p_display_condition_type=>'EXPRESSION'
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(37833900716106539)
,p_query_num_rows=>100
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_show_nulls_as=>'-'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
,p_updated_on=>wwv_flow_imp.dz('20260428153724Z')
,p_updated_by=>'JBALCAZAR'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(244454674612546052)
,p_query_column_id=>1
,p_column_alias=>'CARD_TITLE'
,p_column_display_sequence=>10
,p_column_heading=>'Card Title'
,p_use_as_row_header=>'N'
,p_column_html_expression=>'<span style = "color : #CARD_COLOR#"> #CARD_TITLE#</span>'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(244454283600546052)
,p_query_column_id=>2
,p_column_alias=>'CARD_SUBTITLE'
,p_column_display_sequence=>40
,p_column_heading=>'Card Subtitle'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(244453895183546052)
,p_query_column_id=>3
,p_column_alias=>'CARD_COLOR'
,p_column_display_sequence=>30
,p_column_heading=>'Card Color'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(244455067580546053)
,p_query_column_id=>4
,p_column_alias=>'ORDEN'
,p_column_display_sequence=>20
,p_column_heading=>'Orden'
,p_use_as_row_header=>'N'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(448953951151315019)
,p_name=>unistr('Conciliaci\00F3n Bancaria')
,p_parent_plug_id=>wwv_flow_imp.id(428697844435310434)
,p_template=>wwv_flow_imp.id(38289867500120143)
,p_display_sequence=>190
,p_include_in_reg_disp_sel_yn=>'Y'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_component_template_options=>'#DEFAULT#:u-colors:t-Cards--displaySubtitle:t-Cards--basic:t-Cards--5cols:t-Cards--hideBody:t-Cards--animRaiseCard:t-Report--hideNoPagination'
,p_display_point=>'SUB_REGIONS'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT CONTADOR AS CARD_TITLE, ENLACE   CARD_SUBTITLE , COLOR AS CARD_COLOR,  ORDEN  ',
'FROM (',
'    SELECT TO_NUMBER(:P600_COBA_1) CONTADOR,',
'        ''<a href="''||',
'        apex_page.get_url(',
'            p_application => 109,',
'            p_page => 603,',
'            p_items => ''P603_ID_REGION,P603_MODULO'',',
'            p_values =>''1,CONBAN''',
'        )||''">''||''CARGO DE ESTADO DE CUENTA ''||''</a>'' ENLACE, ',
'        ''#27AE60''COLOR, 1 ORDEN ',
'    FROM DUAL WHERE :P600_COBA_1 >= 0',
'    UNION ALL',
'    SELECT TO_NUMBER(:P600_COBA_2) CONTADOR,',
'        ''<a href="''||',
'        apex_page.get_url(',
'            p_application => 109,',
'            p_page => 603,',
'            p_items => ''P603_ID_REGION,P603_MODULO'',',
'            p_values =>''2,CONBAN''',
unistr('        )||''">''||''ESTADO DE CUENTA VS CONCILIACI\00D3N''||''</a>'' ENLACE, '),
'        ''#27AE60''COLOR, 2 ORDEN ',
'    FROM DUAL WHERE :P600_COBA_2 >= 0',
'    UNION ALL',
'    SELECT TO_NUMBER(:P600_COBA_3) CONTADOR,',
'        ''<a href="''||',
'        apex_page.get_url(',
'            p_application => 109,',
'            p_page => 603,',
'            p_items => ''P603_ID_REGION,P603_MODULO'',',
'            p_values =>''3,CONBAN''',
'        )||''">''||''REGISTROS SIN REFERENCIA''||''</a>'' ENLACE, ',
'        ''#27AE60''COLOR, 3 ORDEN ',
'    FROM DUAL WHERE :P600_COBA_3 >= 0',
'    UNION ALL',
'    SELECT TO_NUMBER(:P600_COBA_4) CONTADOR,',
'        ''<a href="''||',
'        apex_page.get_url(',
'            p_application => 109,',
'            p_page => 603,',
'            p_items => ''P603_ID_REGION,P603_MODULO'',',
'            p_values =>''4,CONBAN''',
unistr('        )||''">''||''SALDOS DE CONCILIACI\00D3N DIFERENTE DE 0''||''</a>'' ENLACE, '),
'        ''#27AE60''COLOR, 4 ORDEN ',
'    FROM DUAL WHERE :P600_COBA_4 >= 0',
'    UNION ALL',
'    SELECT TO_NUMBER(:P600_COBA_5) CONTADOR,',
'        ''<a href="''||',
'        apex_page.get_url(',
'            p_application => 109,',
'            p_page => 603,',
'            p_items => ''P603_ID_REGION,P603_MODULO'',',
'            p_values =>''5,CONBAN''',
unistr('        )||''">''||''PARTIDAS NO CONCILIADAS (EXCEPCI\00D3N PRODUBANCO)''||''</a>'' ENLACE, '),
'        ''#27AE60''COLOR, 5 ORDEN ',
'    FROM DUAL WHERE :P600_COBA_5 >= 0',
'    UNION ALL',
'    SELECT ',
'        TO_NUMBER(:P600_COBA_1) +',
'        TO_NUMBER(:P600_COBA_2) +',
'        TO_NUMBER(:P600_COBA_3) +',
'        TO_NUMBER(:P600_COBA_4) +',
'        TO_NUMBER(:P600_COBA_5)',
'         CONTADOR,',
'        ''<a>TOTAL</a>'' ENLACE, ',
'        ''#F95C4C''COLOR, 100 ORDEN ',
'    FROM DUAL',
')',
'ORDER BY ORDEN ASC'))
,p_display_when_condition=>':P600_MODULO_ACTIVO = ''1'' OR INSTR(:P600_MODULO_ACTIVO, ''COBAN'') > 0'
,p_display_when_cond2=>'PLSQL'
,p_display_condition_type=>'EXPRESSION'
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(37833900716106539)
,p_query_num_rows=>100
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_show_nulls_as=>'-'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(244462288474546063)
,p_query_column_id=>1
,p_column_alias=>'CARD_TITLE'
,p_column_display_sequence=>10
,p_column_heading=>'Card Title'
,p_use_as_row_header=>'N'
,p_column_html_expression=>'<span style = "color : #CARD_COLOR#"> #CARD_TITLE#</span>'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(244463082360546064)
,p_query_column_id=>2
,p_column_alias=>'CARD_SUBTITLE'
,p_column_display_sequence=>40
,p_column_heading=>'Card Subtitle'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(244462658173546064)
,p_query_column_id=>3
,p_column_alias=>'CARD_COLOR'
,p_column_display_sequence=>30
,p_column_heading=>'Card Color'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(244461866524546063)
,p_query_column_id=>4
,p_column_alias=>'ORDEN'
,p_column_display_sequence=>20
,p_column_heading=>'Orden'
,p_use_as_row_header=>'N'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(448954389566315024)
,p_name=>'Impuestos'
,p_parent_plug_id=>wwv_flow_imp.id(428697844435310434)
,p_template=>wwv_flow_imp.id(38289867500120143)
,p_display_sequence=>200
,p_include_in_reg_disp_sel_yn=>'Y'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_component_template_options=>'#DEFAULT#:u-colors:t-Cards--displaySubtitle:t-Cards--basic:t-Cards--5cols:t-Cards--hideBody:t-Cards--animRaiseCard:t-Report--hideNoPagination'
,p_display_point=>'SUB_REGIONS'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT CONTADOR AS CARD_TITLE, ENLACE   CARD_SUBTITLE , COLOR AS CARD_COLOR,  ORDEN  ',
'FROM (',
'    SELECT TO_NUMBER(:P600_IMPU_1) CONTADOR,',
'        ''<a href="''||',
'        apex_page.get_url(',
'            p_application => 109,',
'            p_page => 603,',
'            p_items => ''P603_ID_REGION,P603_MODULO'',',
'            p_values =>''1,IMPURE''',
'        )||''">''||''CXC CRUZADA CON EL ESTADO DEL SRI''||''</a>'' ENLACE, ',
'        ''#27AE60''COLOR, 1 ORDEN ',
'    FROM DUAL WHERE :P600_IMPU_1 >= 0',
'    UNION ALL',
'    SELECT TO_NUMBER(:P600_IMPU_2) CONTADOR,',
'        ''<a href="''||',
'        apex_page.get_url(',
'            p_application => 109,',
'            p_page => 603,',
'            p_items => ''P603_ID_REGION,P603_MODULO'',',
'            p_values =>''2,IMPURE''',
'        )||''">''||''PENDIENTES DE CXC''||''</a>'' ENLACE, ',
'        ''#27AE60''COLOR, 2 ORDEN ',
'    FROM DUAL WHERE :P600_IMPU_2 >= 0',
'    UNION ALL',
'    SELECT TO_NUMBER(:P600_IMPU_3) CONTADOR,',
'        ''<a href="''||',
'        apex_page.get_url(',
'            p_application => 109,',
'            p_page => 603,',
'            p_items => ''P603_ID_REGION,P603_MODULO'',',
'            p_values =>''3,IMPURE''',
'        )||''">''||''PENDIENTES DE CXP''||''</a>'' ENLACE, ',
'        ''#27AE60''COLOR, 3 ORDEN ',
'    FROM DUAL WHERE :P600_IMPU_3 >= 0',
'    UNION ALL',
'    SELECT TO_NUMBER(:P600_IMPU_4) CONTADOR,',
'        ''<a href="''||',
'        apex_page.get_url(',
'            p_application => 109,',
'            p_page => 603,',
'            p_items => ''P603_ID_REGION,P603_MODULO'',',
'            p_values =>''4,IMPURE''',
unistr('        )||''">''||''NOTAS DE CR\00C9DITO QUE NO SE HAN CRUZADO CON FACTURAS''||''</a>'' ENLACE, '),
'        ''#27AE60''COLOR, 4 ORDEN ',
'    FROM DUAL WHERE :P600_IMPU_4 >= 0',
'    UNION ALL',
'    SELECT TO_NUMBER(:P600_IMPU_5) CONTADOR,',
'        ''<a href="''||',
'        apex_page.get_url(',
'            p_application => 109,',
'            p_page => 603,',
'            p_items => ''P603_ID_REGION,P603_MODULO'',',
'            p_values =>''5,IMPURE''',
unistr('        )||''">''||''RETENCIONES DE CXP QUE NO EST\00C9N AUTORIZADAS''||''</a>'' ENLACE, '),
'        ''#27AE60''COLOR, 5 ORDEN ',
'    FROM DUAL WHERE :P600_IMPU_5 >= 0',
'    UNION ALL',
'    SELECT TO_NUMBER(:P600_IMPU_6) CONTADOR,',
'        ''<a href="''||',
'        apex_page.get_url(',
'            p_application => 109,',
'            p_page => 603,',
'            p_items => ''P603_ID_REGION,P603_MODULO'',',
'            p_values =>''6,IMPURE''',
unistr('        )||''">''||''RETENCIONES DE CXC QUE NO HAN SIDO GENERADAS EN M\00D3DULO''||''</a>'' ENLACE, '),
'        ''#27AE60''COLOR, 6 ORDEN ',
'    FROM DUAL WHERE :P600_IMPU_6 >= 0',
'    UNION ALL',
'    SELECT TO_NUMBER(:P600_IMPU_7) CONTADOR,',
'        ''<a href="''||',
'        apex_page.get_url(',
'            p_application => 109,',
'            p_page => 603,',
'            p_items => ''P603_ID_REGION,P603_MODULO'',',
'            p_values =>''7,IMPURE''',
unistr('        )||''">''||''\00D3RDENES DE EXPORTACIONES QUE NO HAN SIDO INGRESADA SU INFORMACI\00D3N ADUANERA''||''</a>'' ENLACE, '),
'        ''#27AE60''COLOR, 7 ORDEN ',
'    FROM DUAL WHERE :P600_IMPU_7 >= 0',
'    UNION ALL',
'    SELECT ',
'        TO_NUMBER(:P600_IMPU_1) +',
'        TO_NUMBER(:P600_IMPU_2) +',
'        TO_NUMBER(:P600_IMPU_3) +',
'        TO_NUMBER(:P600_IMPU_4) +',
'        TO_NUMBER(:P600_IMPU_5) +',
'        TO_NUMBER(:P600_IMPU_6) +',
'        TO_NUMBER(:P600_IMPU_7)',
'         CONTADOR,',
'        ''<a>TOTAL</a>'' ENLACE, ',
'        ''#F95C4C''COLOR, 100 ORDEN ',
'    FROM DUAL',
')',
'ORDER BY ORDEN ASC'))
,p_display_when_condition=>':P600_MODULO_ACTIVO = ''1'' OR INSTR(:P600_MODULO_ACTIVO, ''IMPUE'') > 0'
,p_display_when_cond2=>'PLSQL'
,p_display_condition_type=>'EXPRESSION'
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(37833900716106539)
,p_query_num_rows=>100
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_show_nulls_as=>'-'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(244463847297546065)
,p_query_column_id=>1
,p_column_alias=>'CARD_TITLE'
,p_column_display_sequence=>10
,p_column_heading=>'Card Title'
,p_use_as_row_header=>'N'
,p_column_html_expression=>'<span style = "color : #CARD_COLOR#"> #CARD_TITLE#</span>'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(244465009479546066)
,p_query_column_id=>2
,p_column_alias=>'CARD_SUBTITLE'
,p_column_display_sequence=>40
,p_column_heading=>'Card Subtitle'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(244464666862546066)
,p_query_column_id=>3
,p_column_alias=>'CARD_COLOR'
,p_column_display_sequence=>30
,p_column_heading=>'Card Color'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(244464237597546065)
,p_query_column_id=>4
,p_column_alias=>'ORDEN'
,p_column_display_sequence=>20
,p_column_heading=>'Orden'
,p_use_as_row_header=>'N'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(448954898907315029)
,p_name=>'RRHH'
,p_parent_plug_id=>wwv_flow_imp.id(428697844435310434)
,p_template=>wwv_flow_imp.id(38289867500120143)
,p_display_sequence=>210
,p_include_in_reg_disp_sel_yn=>'Y'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_component_template_options=>'#DEFAULT#:u-colors:t-Cards--displaySubtitle:t-Cards--basic:t-Cards--5cols:t-Cards--hideBody:t-Cards--animRaiseCard:t-Report--hideNoPagination'
,p_display_point=>'SUB_REGIONS'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT CONTADOR AS CARD_TITLE, ENLACE   CARD_SUBTITLE , COLOR AS CARD_COLOR,  ORDEN  ',
'FROM (',
'    SELECT TO_NUMBER(:P600_RRHH_1) CONTADOR,',
'        ''<a href="''||',
'        apex_page.get_url(',
'            p_application => 109,',
'            p_page => 603,',
'            p_items => ''P603_ID_REGION,P603_MODULO'',',
'            p_values =>''1,RRHH''',
'        )||''">''||''ASIENTO JN EN CUENTA 22401.01 y 11102.01 (PAGO IESS%) <span style="color: red;">*</span>''||''</a>'' ENLACE, ',
'        ''#27AE60''COLOR, 1 ORDEN ',
'    FROM DUAL WHERE :P600_RRHH_1 >= 0',
'    UNION ALL',
'    SELECT TO_NUMBER(:P600_RRHH_2) CONTADOR,',
'        ''<a href="''||',
'        apex_page.get_url(',
'            p_application => 109,',
'            p_page => 603,',
'            p_items => ''P603_ID_REGION,P603_MODULO'',',
'            p_values =>''2,RRHH''',
unistr('        )||''">''||''ASIENTO JN EN CUENTA 22401.02 y 11102.01 (PROVISI\00D3N FONDOS DE RESERVA) <span style="color: red;">*</span>''||''</a>'' ENLACE, '),
'        ''#27AE60''COLOR, 2 ORDEN ',
'    FROM DUAL WHERE :P600_RRHH_2 >= 0',
'    UNION ALL',
'    SELECT TO_NUMBER(:P600_RRHH_3) CONTADOR,',
'        ''<a href="''||',
'        apex_page.get_url(',
'            p_application => 109,',
'            p_page => 603,',
'            p_items => ''P603_ID_REGION,P603_MODULO'',',
'            p_values =>''3,RRHH''',
unistr('        )||''">''||''ASIENTO JN EN CUENTA 22401.03 y 11102.01 (PR\00C9STAMOS) <span style="color: red;">*</span>''||''</a>'' ENLACE, '),
'        ''#27AE60''COLOR, 3 ORDEN ',
'    FROM DUAL WHERE :P600_RRHH_3 >= 0',
'    UNION ALL',
'    SELECT TO_NUMBER(:P600_RRHH_4) CONTADOR,',
'        ''<a href="''||',
'        apex_page.get_url(',
'            p_application => 109,',
'            p_page => 603,',
'            p_items => ''P603_ID_REGION,P603_MODULO'',',
'            p_values =>''4,RRHH''',
'        )||''">''||''ASIENTO JN EN CUENTA 22403.02 () <span style="color: red;">*</span>''||''</a>'' ENLACE, ',
'        ''#27AE60''COLOR, 4 ORDEN ',
'    FROM DUAL WHERE :P600_RRHH_4 >= 0',
'    UNION ALL',
'    SELECT TO_NUMBER(:P600_RRHH_5) CONTADOR,',
'        ''<a href="''||',
'        apex_page.get_url(',
'            p_application => 109,',
'            p_page => 603,',
'            p_items => ''P603_ID_REGION,P603_MODULO'',',
'            p_values =>''5,RRHH''',
unistr('        )||''">''||''ASIENTO JN EN CUENTA 22501.08 (PROVISI\00D3N BONO ANUAL) <span style="color: red;">*</span>''||''</a>'' ENLACE, '),
'        ''#27AE60''COLOR, 5 ORDEN ',
'    FROM DUAL WHERE :P600_RRHH_5 >= 0',
'    UNION ALL',
'    SELECT TO_NUMBER(:P600_RRHH_6) CONTADOR,',
'        ''<a href="''||',
'        apex_page.get_url(',
'            p_application => 109,',
'            p_page => 603,',
'            p_items => ''P603_ID_REGION,P603_MODULO'',',
'            p_values =>''6,RRHH''',
unistr('        )||''">''||''ASIENTO JN EN CUENTA 22501.04 (PROVISI\00D3N REMUNERACI\00D3N VARIABLE) <span style="color: red;">*</span>''||''</a>'' ENLACE, '),
'        ''#27AE60''COLOR, 6 ORDEN ',
'    FROM DUAL WHERE :P600_RRHH_6 >= 0',
'    UNION ALL',
'    SELECT TO_NUMBER(:P600_RRHH_7) CONTADOR,',
'        ''<a href="''||',
'        apex_page.get_url(',
'            p_application => 109,',
'            p_page => 603,',
'            p_items => ''P603_ID_REGION,P603_MODULO'',',
'            p_values =>''7,RRHH''',
unistr('        )||''">''||''ASIENTO JN EN CUENTA 23301.01 (PROVISI\00D3N JUBILACI\00D3N PATRONAL) <span style="color: red;">*</span>''||''</a>'' ENLACE, '),
'        ''#27AE60''COLOR, 7 ORDEN ',
'    FROM DUAL WHERE :P600_RRHH_7 >= 0',
'    UNION ALL',
'    SELECT TO_NUMBER(:P600_RRHH_8) CONTADOR,',
'        ''<a href="''||',
'        apex_page.get_url(',
'            p_application => 109,',
'            p_page => 603,',
'            p_items => ''P603_ID_REGION,P603_MODULO'',',
'            p_values =>''8,RRHH''',
unistr('        )||''">''||''ASIENTO JN EN CUENTA 23302.02 (PROVISI\00D3N DESAHUCIO) <span style="color: red;">*</span>''||''</a>'' ENLACE, '),
'        ''#27AE60''COLOR, 8 ORDEN ',
'    FROM DUAL WHERE :P600_RRHH_8 >= 0',
'    UNION ALL',
'    SELECT TO_NUMBER(:P600_RRHH_9) CONTADOR,',
'        ''<a href="''||',
'        apex_page.get_url(',
'            p_application => 109,',
'            p_page => 603,',
'            p_items => ''P603_ID_REGION,P603_MODULO'',',
'            p_values =>''9,RRHH''',
'        )||''">''||''ASIENTO JN EN CUENTA 61101.12 y 22503.07 (TRANSPORTE Y TRANSPORTE EXTRA) <span style="color: red;">*</span>''||''</a>'' ENLACE, ',
'        ''#27AE60''COLOR, 9 ORDEN ',
'    FROM DUAL WHERE :P600_RRHH_9 >= 0',
'    UNION ALL',
'    SELECT TO_NUMBER(:P600_RRHH_10) CONTADOR,',
'        ''<a href="''||',
'        apex_page.get_url(',
'            p_application => 109,',
'            p_page => 603,',
'            p_items => ''P603_ID_REGION,P603_MODULO'',',
'            p_values =>''10,RRHH''',
'        )||''">''||''ASIENTO JN EN CUENTA 11703.01 y 11102.01 (SEGUROS HIJOS) <span style="color: red;">*</span>''||''</a>'' ENLACE, ',
'        ''#27AE60''COLOR, 10 ORDEN ',
'    FROM DUAL WHERE :P600_RRHH_10 >= 0',
'    UNION ALL',
'    SELECT TO_NUMBER(:P600_RRHH_11) CONTADOR,',
'        ''<a href="''||',
'        apex_page.get_url(',
'            p_application => 109,',
'            p_page => 603,',
'            p_items => ''P603_ID_REGION,P603_MODULO'',',
'            p_values =>''11,RRHH''',
'        )||''">''||''ASIENTO JN EN CUENTA 61101.10 (PAGO COMEDOR) <span style="color: red;">*</span>''||''</a>'' ENLACE, ',
'        ''#27AE60''COLOR, 11 ORDEN ',
'    FROM DUAL WHERE :P600_RRHH_11 >= 0',
'    UNION ALL',
'    SELECT TO_NUMBER(:P600_RRHH_12) CONTADOR,',
'        ''<a href="''||',
'        apex_page.get_url(',
'            p_application => 109,',
'            p_page => 603,',
'            p_items => ''P603_ID_REGION,P603_MODULO'',',
'            p_values =>''12,RRHH''',
'        )||''">''||''ASIENTO JN EN CUENTA 22503.07 y 61101.19 (PAGO DISPENSARIO Y EXTRAS) <span style="color: red;">*</span>''||''</a>'' ENLACE, ',
'        ''#27AE60''COLOR, 12 ORDEN ',
'    FROM DUAL WHERE :P600_RRHH_12 >= 0',
'    UNION ALL',
'    SELECT TO_NUMBER(:P600_RRHH_13) CONTADOR,',
'        ''<a href="''||',
'        apex_page.get_url(',
'            p_application => 109,',
'            p_page => 603,',
'            p_items => ''P603_ID_REGION,P603_MODULO'',',
'            p_values =>''13,RRHH''',
'        )||''">''||''ASIENTO JN EN CUENTA 22503.07 y 61101.11 (PAGO SEGUROS DE VIDA) <span style="color: red;">*</span>''||''</a>'' ENLACE, ',
'        ''#27AE60''COLOR, 13 ORDEN ',
'    FROM DUAL WHERE :P600_RRHH_13 >= 0',
'    UNION ALL',
'    SELECT TO_NUMBER(:P600_RRHH_14) CONTADOR,',
'        ''<a href="''||',
'        apex_page.get_url(',
'            p_application => 109,',
'            p_page => 603,',
'            p_items => ''P603_ID_REGION,P603_MODULO'',',
'            p_values =>''14,RRHH''',
unistr('        )||''">''||''ASIENTO JN EN CUENTA 22503.07 y 61101.08 (TARJETAS PA\00D1ALES) <span style="color: red;">*</span>''||''</a>'' ENLACE, '),
'        ''#27AE60''COLOR, 14 ORDEN ',
'    FROM DUAL WHERE :P600_RRHH_14 >= 0',
'    UNION ALL',
'    SELECT ',
'    TO_NUMBER(:P600_RRHH_1) +',
'    TO_NUMBER(:P600_RRHH_2) +',
'    TO_NUMBER(:P600_RRHH_3) +',
'    TO_NUMBER(:P600_RRHH_4) +',
'    TO_NUMBER(:P600_RRHH_5) +',
'    TO_NUMBER(:P600_RRHH_6) +',
'    TO_NUMBER(:P600_RRHH_7) +',
'    TO_NUMBER(:P600_RRHH_8) +',
'    TO_NUMBER(:P600_RRHH_9) +',
'    TO_NUMBER(:P600_RRHH_10) +',
'    TO_NUMBER(:P600_RRHH_11) +',
'    TO_NUMBER(:P600_RRHH_12) +',
'    TO_NUMBER(:P600_RRHH_13) +',
'    TO_NUMBER(:P600_RRHH_14)',
'     CONTADOR,',
'        ''<a>TOTAL</a>'' ENLACE, ',
'        ''#F95C4C''COLOR, 100 ORDEN ',
'    FROM DUAL',
')',
'ORDER BY ORDEN ASC'))
,p_display_when_condition=>':P600_MODULO_ACTIVO = ''1'' OR INSTR(:P600_MODULO_ACTIVO, ''RRHH'') > 0'
,p_display_when_cond2=>'PLSQL'
,p_display_condition_type=>'EXPRESSION'
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(37833900716106539)
,p_query_num_rows=>100
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_show_nulls_as=>'-'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
,p_updated_on=>wwv_flow_imp.dz('20260604182011Z')
,p_updated_by=>'JBALCAZAR'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(244465800043546068)
,p_query_column_id=>1
,p_column_alias=>'CARD_TITLE'
,p_column_display_sequence=>10
,p_column_heading=>'Card Title'
,p_use_as_row_header=>'N'
,p_column_html_expression=>'<span style = "color : #CARD_COLOR#"> #CARD_TITLE#</span>'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(244467028268546069)
,p_query_column_id=>2
,p_column_alias=>'CARD_SUBTITLE'
,p_column_display_sequence=>40
,p_column_heading=>'Card Subtitle'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(244466636374546069)
,p_query_column_id=>3
,p_column_alias=>'CARD_COLOR'
,p_column_display_sequence=>30
,p_column_heading=>'Card Color'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(244466248128546068)
,p_query_column_id=>4
,p_column_alias=>'ORDEN'
,p_column_display_sequence=>20
,p_column_heading=>'Orden'
,p_use_as_row_header=>'N'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(461466350365954339)
,p_plug_name=>'Indicador'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(38289867500120143)
,p_plug_display_sequence=>30
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<div class="t-Region t-Region--noPadding t-Region--removeHeader t-Margin-bottom-md">',
'  <div class="t-Region-body" style="padding: 20px;">',
'    ',
'    <div style="display: flex; justify-content: space-between; align-items: flex-end; margin-bottom: 10px;">',
'      <span style="font-weight: bold; color: #555; font-size: 14px; text-transform: uppercase; letter-spacing: 1px;">',
'        Progreso Global de Cierre - &P600_MES_ACTUAL.',
'      </span>',
'      <span id="textoPorcentajeAvance" style="font-weight: 900; color: #1a1a1a; font-size: 36px; line-height: 0.8;">',
'        0%',
'      </span>',
'    </div>',
'',
'    <div style="background-color: #e0e0e0; border-radius: 12px; height: 24px; width: 100%; overflow: hidden; box-shadow: inset 0 2px 4px rgba(0,0,0,0.15);">',
'      <div id="barraAvanceCierre" style="background-color: #2ecc71; width: 0%; height: 100%; transition: width 0.8s cubic-bezier(0.4, 0, 0.2, 1);"></div>',
'    </div>',
'',
'    <div id="textoDetalleTareas" style="text-align: right; font-size: 12px; color: #777; margin-top: 8px; font-weight: 600;">',
'      0 de 0 tareas completadas',
'    </div>',
'',
'  </div>',
'</div>'))
,p_ai_enabled=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(426748200815699132)
,p_name=>'P600_PRAB_12'
,p_item_sequence=>210
,p_item_plug_id=>wwv_flow_imp.id(436643827137448360)
,p_prompt=>'Vtas 4'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(426748299935699133)
,p_name=>'P600_PRAB_11'
,p_item_sequence=>200
,p_item_plug_id=>wwv_flow_imp.id(436643827137448360)
,p_prompt=>'Vtas 4'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(426748354420699134)
,p_name=>'P600_PRAB_10'
,p_item_sequence=>190
,p_item_plug_id=>wwv_flow_imp.id(436643827137448360)
,p_prompt=>'Vtas 4'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(426748440102699135)
,p_name=>'P600_PRAB_9'
,p_item_sequence=>180
,p_item_plug_id=>wwv_flow_imp.id(436643827137448360)
,p_prompt=>'Vtas 4'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(426748598371699136)
,p_name=>'P600_PRAB_13'
,p_item_sequence=>220
,p_item_plug_id=>wwv_flow_imp.id(436643827137448360)
,p_prompt=>'Vtas 4'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(432585677175499635)
,p_name=>'P600_VTAS_1'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(436643424875448356)
,p_prompt=>'Vtas 1'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(432585790548499636)
,p_name=>'P600_VTAS_2'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(436643424875448356)
,p_prompt=>'Vtas 2'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(432585913579499637)
,p_name=>'P600_VTAS_3'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(436643424875448356)
,p_prompt=>'Vtas 3'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(432586007818499638)
,p_name=>'P600_VTAS_4'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(436643424875448356)
,p_prompt=>'Vtas 4'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(432587860104499643)
,p_name=>'P600_COMP_1'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(436643509338448357)
,p_prompt=>'Vtas 4'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(432588056489499644)
,p_name=>'P600_COMP_2'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(436643509338448357)
,p_prompt=>'Vtas 4'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(433588886158354688)
,p_name=>'P600_PRAB_1'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_imp.id(436643827137448360)
,p_prompt=>'Vtas 4'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(433588994824354689)
,p_name=>'P600_PRAB_2'
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_imp.id(436643827137448360)
,p_prompt=>'Vtas 4'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(433589012448354690)
,p_name=>'P600_PRAB_3'
,p_item_sequence=>120
,p_item_plug_id=>wwv_flow_imp.id(436643827137448360)
,p_prompt=>'Vtas 4'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(433589204464354691)
,p_name=>'P600_PRAB_4'
,p_item_sequence=>130
,p_item_plug_id=>wwv_flow_imp.id(436643827137448360)
,p_prompt=>'Vtas 4'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(433589358069354693)
,p_name=>'P600_PRAB_5'
,p_item_sequence=>140
,p_item_plug_id=>wwv_flow_imp.id(436643827137448360)
,p_prompt=>'Vtas 4'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(436147267853987525)
,p_name=>'P600_ACFI_1'
,p_item_sequence=>380
,p_item_plug_id=>wwv_flow_imp.id(436643634440448358)
,p_prompt=>'Vtas 4'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(436147413520987526)
,p_name=>'P600_ACFI_2'
,p_item_sequence=>390
,p_item_plug_id=>wwv_flow_imp.id(436643634440448358)
,p_prompt=>'Vtas 4'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(436147473584987527)
,p_name=>'P600_ACFI_3'
,p_item_sequence=>400
,p_item_plug_id=>wwv_flow_imp.id(436643634440448358)
,p_prompt=>'Vtas 4'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(436147591995987528)
,p_name=>'P600_ACFI_4'
,p_item_sequence=>410
,p_item_plug_id=>wwv_flow_imp.id(436643634440448358)
,p_prompt=>'Vtas 4'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(436147654305987529)
,p_name=>'P600_ACFI_5'
,p_item_sequence=>420
,p_item_plug_id=>wwv_flow_imp.id(436643634440448358)
,p_prompt=>'Vtas 4'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(436147807761987530)
,p_name=>'P600_ACFI_6'
,p_item_sequence=>430
,p_item_plug_id=>wwv_flow_imp.id(436643634440448358)
,p_prompt=>'Vtas 4'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(436687751887448425)
,p_name=>'P600_PRAB_6'
,p_item_sequence=>150
,p_item_plug_id=>wwv_flow_imp.id(436643827137448360)
,p_prompt=>'Vtas 4'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(436687814829448426)
,p_name=>'P600_PRAB_7'
,p_item_sequence=>160
,p_item_plug_id=>wwv_flow_imp.id(436643827137448360)
,p_prompt=>'Vtas 4'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(436687914014448427)
,p_name=>'P600_PRAB_8'
,p_item_sequence=>170
,p_item_plug_id=>wwv_flow_imp.id(436643827137448360)
,p_prompt=>'Vtas 4'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(436709661049448451)
,p_name=>'P600_CONT_1'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(436643892151448361)
,p_prompt=>'Cont 1'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(436961708918209404)
,p_name=>'P600_PREN_1'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(436922573206209333)
,p_prompt=>'Pren 1'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(436961745730209405)
,p_name=>'P600_PREN_10'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_imp.id(436922573206209333)
,p_prompt=>'Pren 1'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(436961909178209406)
,p_name=>'P600_PREN_12'
,p_item_sequence=>120
,p_item_plug_id=>wwv_flow_imp.id(436922573206209333)
,p_prompt=>'Pren 1'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(436961974108209407)
,p_name=>'P600_PREN_13'
,p_item_sequence=>130
,p_item_plug_id=>wwv_flow_imp.id(436922573206209333)
,p_prompt=>'Pren 1'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(436962052000209408)
,p_name=>'P600_PREN_14'
,p_item_sequence=>140
,p_item_plug_id=>wwv_flow_imp.id(436922573206209333)
,p_prompt=>'Pren 1'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(436962181840209409)
,p_name=>'P600_PREN_15'
,p_item_sequence=>150
,p_item_plug_id=>wwv_flow_imp.id(436922573206209333)
,p_prompt=>'Pren 1'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(436962295540209410)
,p_name=>'P600_PREN_9'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(436922573206209333)
,p_prompt=>'Pren 1'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(436962381493209411)
,p_name=>'P600_PREN_8'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(436922573206209333)
,p_prompt=>'Pren 1'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(436962447776209412)
,p_name=>'P600_PREN_7'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(436922573206209333)
,p_prompt=>'Pren 1'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(436962604231209413)
,p_name=>'P600_PREN_6'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(436922573206209333)
,p_prompt=>'Pren 1'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(436962667373209414)
,p_name=>'P600_PREN_5'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(436922573206209333)
,p_prompt=>'Pren 1'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(436962783019209415)
,p_name=>'P600_PREN_4'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(436922573206209333)
,p_prompt=>'Pren 1'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(436962928119209416)
,p_name=>'P600_PREN_3'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(436922573206209333)
,p_prompt=>'Pren 1'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(436962987681209417)
,p_name=>'P600_PREN_2'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(436922573206209333)
,p_prompt=>'Pren 1'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(436963143480209418)
,p_name=>'P600_PREN_16'
,p_item_sequence=>160
,p_item_plug_id=>wwv_flow_imp.id(436922573206209333)
,p_prompt=>'Pren 1'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(436963225843209419)
,p_name=>'P600_PREN_11'
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_imp.id(436922573206209333)
,p_prompt=>'Pren 1'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(436965394098209387)
,p_name=>'P600_PRAB_14'
,p_item_sequence=>230
,p_item_plug_id=>wwv_flow_imp.id(436643827137448360)
,p_prompt=>'Vtas 4'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(436965452224209388)
,p_name=>'P600_PRAB_15'
,p_item_sequence=>240
,p_item_plug_id=>wwv_flow_imp.id(436643827137448360)
,p_prompt=>'Vtas 4'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(436965531436209389)
,p_name=>'P600_PRAB_16'
,p_item_sequence=>250
,p_item_plug_id=>wwv_flow_imp.id(436643827137448360)
,p_prompt=>'Vtas 4'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(436982187327209402)
,p_name=>'P600_LOPT_1'
,p_item_sequence=>260
,p_item_plug_id=>wwv_flow_imp.id(436643750989448359)
,p_prompt=>'Vtas 4'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(436982264326209403)
,p_name=>'P600_LOPT_2'
,p_item_sequence=>280
,p_item_plug_id=>wwv_flow_imp.id(436643750989448359)
,p_prompt=>'Vtas 4'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(436982340976209404)
,p_name=>'P600_LOPT_3'
,p_item_sequence=>300
,p_item_plug_id=>wwv_flow_imp.id(436643750989448359)
,p_prompt=>'Vtas 4'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(436982489072209405)
,p_name=>'P600_LOPT_4'
,p_item_sequence=>320
,p_item_plug_id=>wwv_flow_imp.id(436643750989448359)
,p_prompt=>'Vtas 4'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(436982612694209406)
,p_name=>'P600_LOPT_8'
,p_item_sequence=>400
,p_item_plug_id=>wwv_flow_imp.id(436643750989448359)
,p_prompt=>'Vtas 4'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(436982726640209407)
,p_name=>'P600_LOPT_7'
,p_item_sequence=>380
,p_item_plug_id=>wwv_flow_imp.id(436643750989448359)
,p_prompt=>'Vtas 4'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(436982746805209408)
,p_name=>'P600_LOPT_6'
,p_item_sequence=>360
,p_item_plug_id=>wwv_flow_imp.id(436643750989448359)
,p_prompt=>'Vtas 4'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(436982872477209409)
,p_name=>'P600_LOPT_5'
,p_item_sequence=>340
,p_item_plug_id=>wwv_flow_imp.id(436643750989448359)
,p_prompt=>'Vtas 4'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(436982969872209410)
,p_name=>'P600_LOPT_9'
,p_item_sequence=>420
,p_item_plug_id=>wwv_flow_imp.id(436643750989448359)
,p_prompt=>'Vtas 4'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(436983082150209411)
,p_name=>'P600_LOPT_10'
,p_item_sequence=>440
,p_item_plug_id=>wwv_flow_imp.id(436643750989448359)
,p_prompt=>'Vtas 4'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(436983201891209412)
,p_name=>'P600_LOPT_11'
,p_item_sequence=>460
,p_item_plug_id=>wwv_flow_imp.id(436643750989448359)
,p_prompt=>'Vtas 4'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(436983337010209413)
,p_name=>'P600_LOPT_12'
,p_item_sequence=>480
,p_item_plug_id=>wwv_flow_imp.id(436643750989448359)
,p_prompt=>'Vtas 4'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(437005612441209459)
,p_name=>'P600_TESO_1'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(436924709780209355)
,p_prompt=>'Teso 1'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(437005708205209460)
,p_name=>'P600_TESO_2'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(436924709780209355)
,p_prompt=>'Teso 1'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(437005821875209461)
,p_name=>'P600_TESO_3'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(436924709780209355)
,p_prompt=>'Teso 1'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(437005892945209462)
,p_name=>'P600_TESO_4'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(436924709780209355)
,p_prompt=>'Teso 1'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(437020095869209475)
,p_name=>'P600_RRHH_1'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(436925376103209361)
,p_prompt=>'Rrhh 1'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(438264216404625104)
,p_name=>'P600_CXPP_1'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(438211108536625022)
,p_prompt=>'Cxpp 1'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(438264320354625105)
,p_name=>'P600_CXPP_2'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(438211108536625022)
,p_prompt=>'Cxpp 1'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(438264396587625106)
,p_name=>'P600_CXPP_3'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(438211108536625022)
,p_prompt=>'Cxpp 1'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(438264488889625107)
,p_name=>'P600_CXPP_4'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(438211108536625022)
,p_prompt=>'Cxpp 1'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(438264604138625108)
,p_name=>'P600_CXPP_5'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(438211108536625022)
,p_prompt=>'Cxpp 1'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(438264732568625109)
,p_name=>'P600_CXPP_6'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(438211108536625022)
,p_prompt=>'Cxpp 1'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(438264799103625110)
,p_name=>'P600_CXPP_7'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(438211108536625022)
,p_prompt=>'Cxpp 1'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(438264908164625111)
,p_name=>'P600_CXPP_8'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(438211108536625022)
,p_prompt=>'Cxpp 1'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(438265017358625112)
,p_name=>'P600_CXPP_9'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(438211108536625022)
,p_prompt=>'Cxpp 1'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(438275875405625102)
,p_name=>'P600_CONT_2'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(436643892151448361)
,p_prompt=>'Cont 1'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(438276055739625103)
,p_name=>'P600_CONT_3'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(436643892151448361)
,p_prompt=>'Cont 1'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(438276078202625104)
,p_name=>'P600_CONT_4'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(436643892151448361)
,p_prompt=>'Cont 1'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(438276215024625105)
,p_name=>'P600_CONT_5'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(436643892151448361)
,p_prompt=>'Cont 1'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(438276333726625106)
,p_name=>'P600_CONT_6'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(436643892151448361)
,p_prompt=>'Cont 1'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(438276387876625107)
,p_name=>'P600_CONT_7'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(436643892151448361)
,p_prompt=>'Cont 1'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(438276550336625108)
,p_name=>'P600_CONT_8'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(436643892151448361)
,p_prompt=>'Cont 1'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(438276634903625109)
,p_name=>'P600_CONT_9'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(436643892151448361)
,p_prompt=>'Cont 1'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(438281229217625126)
,p_name=>'P600_PRCS_1'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(438212304384625034)
,p_prompt=>'Prcs 1'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(438281263578625127)
,p_name=>'P600_PRCS_2'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(438212304384625034)
,p_prompt=>'Prcs 1'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(438281391452625128)
,p_name=>'P600_PRCS_3'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(438212304384625034)
,p_prompt=>'Prcs 1'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(438281562687625129)
,p_name=>'P600_PRCS_4'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(438212304384625034)
,p_prompt=>'Prcs 1'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(438281632005625130)
,p_name=>'P600_PRCS_6'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(438212304384625034)
,p_prompt=>'Prcs 1'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(438281720607625131)
,p_name=>'P600_PRCS_7'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(438212304384625034)
,p_prompt=>'Prcs 1'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(438281798638625132)
,p_name=>'P600_PRCS_8'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(438212304384625034)
,p_prompt=>'Prcs 1'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(438281879431625133)
,p_name=>'P600_PRCS_5'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(438212304384625034)
,p_prompt=>'Prcs 1'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(438281968951625134)
,p_name=>'P600_PRCS_9'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_imp.id(438212304384625034)
,p_prompt=>'Prcs 1'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(438282128591625135)
,p_name=>'P600_PRCS_10'
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_imp.id(438212304384625034)
,p_prompt=>'Prcs 1'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(438282363149625137)
,p_name=>'P600_PRCS_11'
,p_item_sequence=>120
,p_item_plug_id=>wwv_flow_imp.id(438212304384625034)
,p_prompt=>'Prcs 1'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(438282421294625138)
,p_name=>'P600_PRCS_12'
,p_item_sequence=>130
,p_item_plug_id=>wwv_flow_imp.id(438212304384625034)
,p_prompt=>'Prcs 1'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(438282518720625139)
,p_name=>'P600_PRCS_13'
,p_item_sequence=>140
,p_item_plug_id=>wwv_flow_imp.id(438212304384625034)
,p_prompt=>'Prcs 1'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(438282595809625140)
,p_name=>'P600_PRCS_14'
,p_item_sequence=>150
,p_item_plug_id=>wwv_flow_imp.id(438212304384625034)
,p_prompt=>'Prcs 1'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(438282705137625141)
,p_name=>'P600_PRCS_15'
,p_item_sequence=>160
,p_item_plug_id=>wwv_flow_imp.id(438212304384625034)
,p_prompt=>'Prcs 1'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(438282814107625142)
,p_name=>'P600_PRCS_16'
,p_item_sequence=>170
,p_item_plug_id=>wwv_flow_imp.id(438212304384625034)
,p_prompt=>'Prcs 1'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(438289041161625157)
,p_name=>'P600_PRTR_1'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(438214713926625058)
,p_prompt=>'Prtr 1'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(438289156955625158)
,p_name=>'P600_PRTR_2'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(438214713926625058)
,p_prompt=>'Prtr 1'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(438289207487625159)
,p_name=>'P600_PRTR_3'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(438214713926625058)
,p_prompt=>'Prtr 1'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(438289375391625160)
,p_name=>'P600_PRTR_4'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(438214713926625058)
,p_prompt=>'Prtr 1'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(438330197064729311)
,p_name=>'P600_PRTR_5'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(438214713926625058)
,p_prompt=>'Prtr 1'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(438330252014729312)
,p_name=>'P600_PRTR_6'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(438214713926625058)
,p_prompt=>'Prtr 1'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(440613341076634324)
,p_name=>'P600_LOMP_1'
,p_item_sequence=>270
,p_item_plug_id=>wwv_flow_imp.id(440529556642634217)
,p_prompt=>'Vtas 4'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(440613372143634325)
,p_name=>'P600_LOMP_2'
,p_item_sequence=>290
,p_item_plug_id=>wwv_flow_imp.id(440529556642634217)
,p_prompt=>'Vtas 4'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(440613503565634326)
,p_name=>'P600_LOMP_3'
,p_item_sequence=>310
,p_item_plug_id=>wwv_flow_imp.id(440529556642634217)
,p_prompt=>'Vtas 4'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(440613650557634327)
,p_name=>'P600_LOMP_4'
,p_item_sequence=>330
,p_item_plug_id=>wwv_flow_imp.id(440529556642634217)
,p_prompt=>'Vtas 4'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(440613688302634328)
,p_name=>'P600_LOMP_5'
,p_item_sequence=>350
,p_item_plug_id=>wwv_flow_imp.id(440529556642634217)
,p_prompt=>'Vtas 4'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(440613809962634329)
,p_name=>'P600_LOMP_6'
,p_item_sequence=>370
,p_item_plug_id=>wwv_flow_imp.id(440529556642634217)
,p_prompt=>'Vtas 4'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(440613884581634330)
,p_name=>'P600_LOMP_7'
,p_item_sequence=>390
,p_item_plug_id=>wwv_flow_imp.id(440529556642634217)
,p_prompt=>'Vtas 4'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(440613956004634331)
,p_name=>'P600_LOMP_8'
,p_item_sequence=>410
,p_item_plug_id=>wwv_flow_imp.id(440529556642634217)
,p_prompt=>'Vtas 4'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(440614110483634332)
,p_name=>'P600_LOMP_9'
,p_item_sequence=>430
,p_item_plug_id=>wwv_flow_imp.id(440529556642634217)
,p_prompt=>'Vtas 4'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(440614232330634333)
,p_name=>'P600_LOMP_10'
,p_item_sequence=>450
,p_item_plug_id=>wwv_flow_imp.id(440529556642634217)
,p_prompt=>'Vtas 4'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(440614277297634334)
,p_name=>'P600_LOMP_11'
,p_item_sequence=>470
,p_item_plug_id=>wwv_flow_imp.id(440529556642634217)
,p_prompt=>'Vtas 4'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(440614430826634335)
,p_name=>'P600_LOMP_12'
,p_item_sequence=>490
,p_item_plug_id=>wwv_flow_imp.id(440529556642634217)
,p_prompt=>'Vtas 4'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(440620038714634352)
,p_name=>'P600_LOME_1'
,p_item_sequence=>280
,p_item_plug_id=>wwv_flow_imp.id(440529673311634218)
,p_prompt=>'Vtas 4'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(440620226106634353)
,p_name=>'P600_LOME_2'
,p_item_sequence=>300
,p_item_plug_id=>wwv_flow_imp.id(440529673311634218)
,p_prompt=>'Vtas 4'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(440620257449634354)
,p_name=>'P600_LOME_3'
,p_item_sequence=>320
,p_item_plug_id=>wwv_flow_imp.id(440529673311634218)
,p_prompt=>'Vtas 4'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(440620396316634355)
,p_name=>'P600_LOME_4'
,p_item_sequence=>340
,p_item_plug_id=>wwv_flow_imp.id(440529673311634218)
,p_prompt=>'Vtas 4'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(440620498699634356)
,p_name=>'P600_LOME_5'
,p_item_sequence=>360
,p_item_plug_id=>wwv_flow_imp.id(440529673311634218)
,p_prompt=>'Vtas 4'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(440620578291634357)
,p_name=>'P600_LOME_6'
,p_item_sequence=>380
,p_item_plug_id=>wwv_flow_imp.id(440529673311634218)
,p_prompt=>'Vtas 4'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(440620726844634358)
,p_name=>'P600_LOME_7'
,p_item_sequence=>400
,p_item_plug_id=>wwv_flow_imp.id(440529673311634218)
,p_prompt=>'Vtas 4'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(440620788679634359)
,p_name=>'P600_LOME_8'
,p_item_sequence=>420
,p_item_plug_id=>wwv_flow_imp.id(440529673311634218)
,p_prompt=>'Vtas 4'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(440620874152634360)
,p_name=>'P600_LOME_9'
,p_item_sequence=>440
,p_item_plug_id=>wwv_flow_imp.id(440529673311634218)
,p_prompt=>'Vtas 4'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(440620998444634361)
,p_name=>'P600_LOME_10'
,p_item_sequence=>460
,p_item_plug_id=>wwv_flow_imp.id(440529673311634218)
,p_prompt=>'Vtas 4'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(440621111146634362)
,p_name=>'P600_LOME_11'
,p_item_sequence=>480
,p_item_plug_id=>wwv_flow_imp.id(440529673311634218)
,p_prompt=>'Vtas 4'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(440621140162634363)
,p_name=>'P600_LOME_12'
,p_item_sequence=>500
,p_item_plug_id=>wwv_flow_imp.id(440529673311634218)
,p_prompt=>'Vtas 4'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(443787614952602418)
,p_name=>'P600_CXPP_10'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_imp.id(438211108536625022)
,p_prompt=>'Cxpp 1'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(443787679167602419)
,p_name=>'P600_CXPP_11'
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_imp.id(438211108536625022)
,p_prompt=>'Cxpp 1'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(443832875627602443)
,p_name=>'P600_CXPC_1'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(443733498808602326)
,p_prompt=>'Cxpc 1'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(443832975419602444)
,p_name=>'P600_CXPC_2'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(443733498808602326)
,p_prompt=>'Cxpc 1'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(443833110968602445)
,p_name=>'P600_CXPC_3'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(443733498808602326)
,p_prompt=>'Cxpc 1'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(443833207636602446)
,p_name=>'P600_CXPC_4'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(443733498808602326)
,p_prompt=>'Cxpc 1'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(448995097273315110)
,p_name=>'P600_PREN_17'
,p_item_sequence=>170
,p_item_plug_id=>wwv_flow_imp.id(436922573206209333)
,p_prompt=>'Pren 1'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(448995237337315111)
,p_name=>'P600_PREN_18'
,p_item_sequence=>180
,p_item_plug_id=>wwv_flow_imp.id(436922573206209333)
,p_prompt=>'Pren 1'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(449000672873315112)
,p_name=>'P600_PRAB_17'
,p_item_sequence=>260
,p_item_plug_id=>wwv_flow_imp.id(436643827137448360)
,p_prompt=>'Vtas 4'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(449024713485315130)
,p_name=>'P600_PRCS_17'
,p_item_sequence=>180
,p_item_plug_id=>wwv_flow_imp.id(438212304384625034)
,p_prompt=>'Prcs 1'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(449034071664315116)
,p_name=>'P600_TESO_5'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(436924709780209355)
,p_prompt=>'Teso 1'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(449036251333315137)
,p_name=>'P600_TESO_6'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(436924709780209355)
,p_prompt=>'Teso 1'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(449036359882315138)
,p_name=>'P600_TESO_7'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(436924709780209355)
,p_prompt=>'Teso 1'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(449036398972315139)
,p_name=>'P600_TESO_8'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(436924709780209355)
,p_prompt=>'Teso 1'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(451019733957935202)
,p_name=>'P600_LOPT_13'
,p_item_sequence=>490
,p_item_plug_id=>wwv_flow_imp.id(436643750989448359)
,p_prompt=>'Vtas 4'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(451034969263935238)
,p_name=>'P600_PRTR_7'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(438214713926625058)
,p_prompt=>'Prtr 1'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(451041977240935222)
,p_name=>'P600_LOMP_13'
,p_item_sequence=>500
,p_item_plug_id=>wwv_flow_imp.id(440529556642634217)
,p_prompt=>'Vtas 4'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(451046330615935226)
,p_name=>'P600_LOME_13'
,p_item_sequence=>510
,p_item_plug_id=>wwv_flow_imp.id(440529673311634218)
,p_prompt=>'Vtas 4'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(451552924279883726)
,p_name=>'P600_RRHH_2'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(436925376103209361)
,p_prompt=>'Rrhh 1'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(451553010570883727)
,p_name=>'P600_RRHH_3'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(436925376103209361)
,p_prompt=>'Rrhh 1'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(451553088555883728)
,p_name=>'P600_RRHH_4'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(436925376103209361)
,p_prompt=>'Rrhh 1'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(451553199136883729)
,p_name=>'P600_RRHH_5'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(436925376103209361)
,p_prompt=>'Rrhh 1'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(451553257162883730)
,p_name=>'P600_RRHH_6'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(436925376103209361)
,p_prompt=>'Rrhh 1'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(451553393288883731)
,p_name=>'P600_RRHH_7'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(436925376103209361)
,p_prompt=>'Rrhh 1'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(451553497934883732)
,p_name=>'P600_RRHH_8'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(436925376103209361)
,p_prompt=>'Rrhh 1'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(451553644083883733)
,p_name=>'P600_RRHH_9'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(436925376103209361)
,p_prompt=>'Rrhh 1'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(451553689337883734)
,p_name=>'P600_RRHH_10'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_imp.id(436925376103209361)
,p_prompt=>'Rrhh 1'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(451553766625883735)
,p_name=>'P600_RRHH_11'
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_imp.id(436925376103209361)
,p_prompt=>'Rrhh 1'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(451553916474883736)
,p_name=>'P600_RRHH_12'
,p_item_sequence=>120
,p_item_plug_id=>wwv_flow_imp.id(436925376103209361)
,p_prompt=>'Rrhh 1'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(451553981707883737)
,p_name=>'P600_RRHH_13'
,p_item_sequence=>130
,p_item_plug_id=>wwv_flow_imp.id(436925376103209361)
,p_prompt=>'Rrhh 1'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(451554048921883738)
,p_name=>'P600_RRHH_14'
,p_item_sequence=>140
,p_item_plug_id=>wwv_flow_imp.id(436925376103209361)
,p_prompt=>'Rrhh 1'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(452433261035713056)
,p_name=>'P600_CXCP_1'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(452340916867712944)
,p_prompt=>'Cxcp 1'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(452433320363713057)
,p_name=>'P600_CXCP_2'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(452340916867712944)
,p_prompt=>'Cxcp 1'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(452433455787713058)
,p_name=>'P600_CXCP_3'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(452340916867712944)
,p_prompt=>'Cxcp 1'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(452433476073713059)
,p_name=>'P600_CXCP_4'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(452340916867712944)
,p_prompt=>'Cxcp 1'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(452433642344713060)
,p_name=>'P600_CXCP_5'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(452340916867712944)
,p_prompt=>'Cxcp 1'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(452433728315713061)
,p_name=>'P600_CXCP_6'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(452340916867712944)
,p_prompt=>'Cxcp 1'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(452433777667713062)
,p_name=>'P600_CXCP_7'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(452340916867712944)
,p_prompt=>'Cxcp 1'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(452957501375778233)
,p_name=>'P600_COBA_1'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(452878500315778131)
,p_prompt=>'Coba 1'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(452957641704778234)
,p_name=>'P600_COBA_2'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(452878500315778131)
,p_prompt=>'Coba 1'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(452957667613778235)
,p_name=>'P600_COBA_3'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(452878500315778131)
,p_prompt=>'Coba 1'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(452957768810778236)
,p_name=>'P600_COBA_4'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(452878500315778131)
,p_prompt=>'Coba 1'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(452957944315778237)
,p_name=>'P600_COBA_5'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(452878500315778131)
,p_prompt=>'Coba 1'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(459414071665930708)
,p_name=>'P600_IMPU_1'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(459363599763930629)
,p_prompt=>'Impu 1'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(459414197339930709)
,p_name=>'P600_IMPU_2'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(459363599763930629)
,p_prompt=>'Impu 1'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(459414266215930710)
,p_name=>'P600_IMPU_3'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(459363599763930629)
,p_prompt=>'Impu 1'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(459414364661930711)
,p_name=>'P600_IMPU_4'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(459363599763930629)
,p_prompt=>'Impu 1'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(459414418181930712)
,p_name=>'P600_IMPU_5'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(459363599763930629)
,p_prompt=>'Impu 1'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(459414571807930713)
,p_name=>'P600_IMPU_6'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(459363599763930629)
,p_prompt=>'Impu 1'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(459414639274930714)
,p_name=>'P600_IMPU_7'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(459363599763930629)
,p_prompt=>'Impu 1'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(466922257437885712)
,p_name=>'P600_MODULO_ACTIVO'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(424841437095598556)
,p_prompt=>'Modulo Activo'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(466922341150885713)
,p_name=>'P600_MES_ACTUAL'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(424841437095598556)
,p_prompt=>'Mes Actual'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(488231735539893911)
,p_name=>'P600_PRTR_8'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(438214713926625058)
,p_prompt=>'Prtr 1'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(488231818459893912)
,p_name=>'P600_PRTR_9'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(438214713926625058)
,p_prompt=>'Prtr 1'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(488231924266893913)
,p_name=>'P600_PRTR_10'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_imp.id(438214713926625058)
,p_prompt=>'Prtr 1'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(488232077977893914)
,p_name=>'P600_PRTR_11'
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_imp.id(438214713926625058)
,p_prompt=>'Prtr 1'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(488232202804893915)
,p_name=>'P600_PRTR_12'
,p_item_sequence=>120
,p_item_plug_id=>wwv_flow_imp.id(438214713926625058)
,p_prompt=>'Prtr 1'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(488232215442893916)
,p_name=>'P600_PRTR_13'
,p_item_sequence=>130
,p_item_plug_id=>wwv_flow_imp.id(438214713926625058)
,p_prompt=>'Prtr 1'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(488232380042893917)
,p_name=>'P600_PRTR_14'
,p_item_sequence=>140
,p_item_plug_id=>wwv_flow_imp.id(438214713926625058)
,p_prompt=>'Prtr 1'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(244545079902546140)
,p_name=>'Colorear'
,p_event_sequence=>10
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'ready'
,p_updated_on=>wwv_flow_imp.dz('20260428155340Z')
,p_updated_by=>'JBALCAZAR'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(244545511490546141)
,p_event_id=>wwv_flow_imp.id(244545079902546140)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'const configTabs = [',
'    { label: "Ventas", prefix: "P600_VTAS_", cantidad: 4, codmod: "DCO250" },',
'    { label: "Compras", prefix: "P600_COMP_", cantidad: 2, codmod: "DOP356" },',
unistr('    { label: "Producci\00F3n Absorbente", prefix: "P600_PRAB_", cantidad: 16, codmod: "DMA430" },'),
unistr('    { label: "Producci\00F3n Cosm\00E9tica", prefix: "P600_PRCS_", cantidad: 16, codmod: "COSME" },'),
'    { label: "Transformaciones", prefix: "P600_PRTR_", cantidad: 6, codmod: "TRANS" },',
unistr('    { label: "Producci\00F3n Envases", prefix: "P600_PREN_", cantidad: 16, codmod: "DMA510" },'),
unistr('    { label: "Log\00EDstica PT", prefix: "P600_LOPT_", cantidad: 12, codmod: "DOP340" },'),
unistr('    { label: "Log\00EDstica MP", prefix: "P600_LOMP_", cantidad: 12, codmod: "DOP339" },'),
unistr('    { label: "Log\00EDstica BDG Menores", prefix: "P600_LOME_", cantidad: 12, codmod: "DOP347" },'),
'    { label: "Activos Fijos", prefix: "P600_ACFI_", cantidad: 6, codmod: "ACTFI" },',
'    { label: "Contabilidad", prefix: "P600_CONT_", cantidad: 9, codmod: "CONTA" },',
'    { label: "Cuentas x Pagar", prefix: "P600_CXPP_", cantidad: 9, codmod: "CXPFI" },',
'    { label: "Cuentas x Pagar (Colaboradores)", prefix: "P600_CXPC_", cantidad: 4, codmod: "CXPCF" },',
unistr('    { label: "Tesorer\00EDa", prefix: "P600_TESO_", cantidad: 6, codmod: "TESOR" },'),
'    { label: "Cuentas x Cobrar", prefix: "P600_CXCP_", cantidad: 6, codmod: "CXCFI" },',
unistr('    { label: "Conciliaci\00F3n Bancaria", prefix: "P600_COBA_", cantidad: 5, codmod: "COBAN" },'),
'    { label: "Impuestos", prefix: "P600_IMPU_", cantidad: 7, codmod: "IMPUE" },',
'    { label: "RRHH", prefix: "P600_RRHH_", cantidad: 14, codmod: "RRHH" },',
'];',
'',
'function obtenerClaseAlerta(conteo, total) {',
'    if (conteo === 0) return ''tab-success'';',
'    let pct = (conteo / total) * 100;',
'    return (pct <= 40) ? ''tab-warning'' : ''tab-danger'';',
'}',
'',
'let totalContadoresSistema = 0;',
'let totalContadoresCerrados = 0;',
'console.log($v(''P600_MODULO_ACTIVO''))',
'configTabs.forEach(tab => {',
'',
'    if ($v(''P600_MODULO_ACTIVO'').includes(tab.codmod) || $v(''P600_MODULO_ACTIVO'') >= 1){',
'        let alertasEncontradas = 0;',
'',
'        totalContadoresSistema += tab.cantidad;',
'',
'        for (let i = 1; i <= tab.cantidad; i++) {',
'            if (tab.label == ''Cuentas x Cobrar'' && i == 2){',
'                totalContadoresSistema -= 1;',
'                continue;',
'            }',
'            let itemId = tab.prefix + i;',
unistr('            let valor = parseFloat($v(itemId)) || 0; // Leemos el valor del \00EDtem de APEX'),
'            ',
'            if (valor > 0) {',
'                alertasEncontradas++;',
'            } else {',
unistr('                // Si el valor es 0, esa tarea de cierre ya est\00E1 completada'),
'                totalContadoresCerrados++;',
'            }',
'        }',
'',
'        let claseFinal = obtenerClaseAlerta(alertasEncontradas, tab.cantidad);',
'',
'        $(".apex-rds-item").each(function() {',
'            if ($(this).find(".a-RDS-label").text().trim() === tab.label) {',
'                $(this).removeClass("tab-success tab-warning tab-danger").addClass(claseFinal);',
'            }',
'    });',
'    }',
'',
'});',
'',
'// Calculamos el porcentaje general de avance',
'let porcentajeAvance = 0;',
'if (totalContadoresSistema > 0) {',
'    porcentajeAvance = Math.round((totalContadoresCerrados / totalContadoresSistema) * 100);',
'}',
'',
'// 1. Llenamos el porcentaje gigante',
'$("#textoPorcentajeAvance").text(porcentajeAvance + "%");',
'',
'// 2. Llenamos el texto chiquito de abajo',
'$("#textoDetalleTareas").text(totalContadoresCerrados + " de " + totalContadoresSistema + " tareas completadas");',
'',
'// 3. Animamos la barra',
'$("#barraAvanceCierre").css("width", porcentajeAvance + "%");',
'',
'if (porcentajeAvance >= 90) {',
'    $("#barraAvanceCierre").css("background-color", "#2ecc71"); // Verde Zaimella',
'    $("#textoPorcentajeAvance").css("color", "#2ecc71");',
'} else if (porcentajeAvance > 50) {',
'    $("#barraAvanceCierre").css("background-color", "#f39c12"); // Amarillo/Naranja',
'    $("#textoPorcentajeAvance").css("color", "#f39c12");',
'} else {',
'    $("#barraAvanceCierre").css("background-color", "#e74c3c"); // Rojo',
'    $("#textoPorcentajeAvance").css("color", "#e74c3c");',
'}'))
,p_updated_on=>wwv_flow_imp.dz('20260428155340Z')
,p_updated_by=>'JBALCAZAR'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(244544603200546140)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Validar Usuario'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE ',
'    V_D_HAB_TRANS NUMBER := 0;',
'    V_ULTIMO_DIA_H DATE;',
'BEGIN',
'    WITH FERIADOS AS (',
'        SELECT TO_DATE(LPAD(TRIM(VALOR), 2, ''0'') || ''/'' || LPAD(TRIM(VALOR2), 2, ''0'') || ''/'' || TO_CHAR(SYSDATE, ''YYYY''), ''DD/MM/YYYY'') AS FECHA',
'        FROM DATA.T_CORP_UDC',
'        WHERE ID_CABECERA = ''ADT_FERIAD'' AND CODIGOCOMPANIA = ''00001'' AND ACTIVO = 1',
'    ),',
'    CALENDARIO AS (',
'        SELECT TRUNC(SYSDATE, ''MM'') + LEVEL - 1 AS FECHA_EVAL',
'        FROM DUAL CONNECT BY TRUNC(SYSDATE, ''MM'') + LEVEL - 1 <= TRUNC(SYSDATE)',
'    ),',
'    ULTIMO_DIA_H AS (',
'        SELECT MAX(FECHA_EVAL) AS FECHA',
'        FROM (SELECT TRUNC(LAST_DAY(SYSDATE)) - LEVEL + 1 AS FECHA_EVAL FROM DUAL CONNECT BY LEVEL <= 31)',
'        WHERE TO_CHAR(FECHA_EVAL,''DY'',''NLS_DATE_LANGUAGE=ENGLISH'') NOT IN (''SAT'',''SUN'')',
'        AND FECHA_EVAL NOT IN (SELECT FECHA FROM FERIADOS)',
'    )',
'    SELECT',
'        (SELECT COUNT(*) FROM CALENDARIO WHERE TO_CHAR(FECHA_EVAL, ''DY'', ''NLS_DATE_LANGUAGE=ENGLISH'') NOT IN (''SAT'', ''SUN'') AND FECHA_EVAL NOT IN (SELECT FECHA FROM FERIADOS)),',
'        (SELECT FECHA FROM ULTIMO_DIA_H)',
'    INTO V_D_HAB_TRANS, V_ULTIMO_DIA_H',
'    FROM DUAL;',
'',
'    IF V_D_HAB_TRANS <= 5 THEN',
'        SELECT UPPER(TO_CHAR(ADD_MONTHS(SYSDATE,-1), ''Month'', ''NLS_DATE_LANGUAGE=SPANISH'')) INTO :P600_MES_ACTUAL',
'        FROM DUAL;',
'    ELSE',
'        SELECT UPPER(TO_CHAR(SYSDATE, ''Month'', ''NLS_DATE_LANGUAGE=SPANISH'')) INTO :P600_MES_ACTUAL',
'        FROM DUAL;',
'    END IF;',
'',
'    -- SELECT UPPER(TO_CHAR(SYSDATE, ''Month'', ''NLS_DATE_LANGUAGE=SPANISH'')) INTO :P600_MES_ACTUAL',
'    -- FROM DUAL;',
'',
'    SELECT COUNT(*) INTO :P600_MODULO_ACTIVO',
'    FROM DATA.T_CORP_UDC WHERE ID_CABECERA = ''FINZ_CIUAD''',
'    AND VALOR = (SELECT EMAIL FROM DATA.VT_CORP_USUARIO',
'                 WHERE NOMBREUSUARIO = :APP_USER AND COMPANIA = :G_COMPANIA',
'                 AND ESTADO = 1)',
'    AND ACTIVO = 1 AND CODIGOCOMPANIA = :G_COMPANIA;',
'',
'    IF :P600_MODULO_ACTIVO < 1 THEN',
'        BEGIN',
'            SELECT LISTAGG(NVL(SUBMODULO, CODIGO_MODULO),'','') INTO :P600_MODULO_ACTIVO',
'            FROM DATA.T_FINZ_RESPONSABLECIERRE R',
'            WHERE R.ACTIVO = ''S''',
'            AND ',
'            (INSTR(CORREO_RESPONSABLE, (SELECT EMAIL',
'                FROM DATA.VT_CORP_USUARIO',
'                WHERE NOMBREUSUARIO = :APP_USER AND COMPANIA = :G_COMPANIA',
'                --AND ESTADO = 1',
'                )) > 0',
'             OR',
'             INSTR(CORREO_REVISOR, (SELECT EMAIL',
'                FROM DATA.VT_CORP_USUARIO',
'                WHERE NOMBREUSUARIO = :APP_USER AND COMPANIA = :G_COMPANIA',
'                --AND ESTADO = 1',
'                )) > 0',
'            );',
'        EXCEPTION',
'            WHEN OTHERS THEN ',
'                :P600_MODULO_ACTIVO := NULL;',
'        END;',
'    END IF;',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>244544603200546140
,p_updated_on=>wwv_flow_imp.dz('20260505145625Z')
,p_updated_by=>'JBALCAZAR'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(244537417239546135)
,p_process_sequence=>20
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Ventas'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE ',
'    V_RESPUESTA VARCHAR(4000);',
'    V_OBJ        JSON_OBJECT_T;',
'BEGIN',
'V_RESPUESTA := PK_FINZ_CIERRE_MES.F_CONTADORES_VENTAS;',
'V_OBJ := JSON_OBJECT_T.parse(V_RESPUESTA);',
':P600_VTAS_1 := V_OBJ.get_Number(''V_CONT_1'');',
':P600_VTAS_2 := V_OBJ.get_Number(''V_CONT_2'');',
':P600_VTAS_3 := V_OBJ.get_Number(''V_CONT_3'');',
':P600_VTAS_4 := V_OBJ.get_Number(''V_CONT_4'');',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_process_when=>':P600_MODULO_ACTIVO = ''1'' OR INSTR(:P600_MODULO_ACTIVO, ''DCO250'') > 0 '
,p_process_when_type=>'EXPRESSION'
,p_process_when2=>'PLSQL'
,p_internal_uid=>244537417239546135
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(244537882952546136)
,p_process_sequence=>30
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Compras'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE ',
'    V_RESPUESTA VARCHAR(4000);',
'    V_OBJ        JSON_OBJECT_T;',
'BEGIN',
'V_RESPUESTA := PK_FINZ_CIERRE_MES.F_CONTADORES_COMPRAS;',
'V_OBJ := JSON_OBJECT_T.parse(V_RESPUESTA);',
':P600_COMP_1 := V_OBJ.get_Number(''V_CONT_1'');',
':P600_COMP_2 := V_OBJ.get_Number(''V_CONT_2'');',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_process_when=>':P600_MODULO_ACTIVO = ''1'' OR INSTR(:P600_MODULO_ACTIVO, ''DOP356'') > 0 '
,p_process_when_type=>'EXPRESSION'
,p_process_when2=>'PLSQL'
,p_internal_uid=>244537882952546136
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(244538239631546136)
,p_process_sequence=>50
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>unistr('Producci\00F3n Absorbente')
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE ',
'    V_RESPUESTA VARCHAR(4000);',
'    V_OBJ        JSON_OBJECT_T;',
'BEGIN',
'-- RETURN;',
'V_RESPUESTA := PK_FINZ_CIERRE_MES.F_CONTADORES_PRODUCCION_ABS;',
'V_OBJ := JSON_OBJECT_T.parse(V_RESPUESTA);',
':P600_PRAB_1 := V_OBJ.get_Number(''V_CONT_1'');',
':P600_PRAB_2 := V_OBJ.get_Number(''V_CONT_2'');',
':P600_PRAB_3 := V_OBJ.get_Number(''V_CONT_3'');',
':P600_PRAB_4 := V_OBJ.get_Number(''V_CONT_4'');',
':P600_PRAB_5 := V_OBJ.get_Number(''V_CONT_5'');',
':P600_PRAB_6 := V_OBJ.get_Number(''V_CONT_6'');',
':P600_PRAB_7 := V_OBJ.get_Number(''V_CONT_7'');',
':P600_PRAB_8 := V_OBJ.get_Number(''V_CONT_8'');',
':P600_PRAB_9 := V_OBJ.get_Number(''V_CONT_9'');',
':P600_PRAB_10 := V_OBJ.get_Number(''V_CONT_10'');',
':P600_PRAB_11 := V_OBJ.get_Number(''V_CONT_11'');',
':P600_PRAB_12 := V_OBJ.get_Number(''V_CONT_12'');',
':P600_PRAB_13 := V_OBJ.get_Number(''V_CONT_13'');',
':P600_PRAB_14 := V_OBJ.get_Number(''V_CONT_14'');',
':P600_PRAB_15 := V_OBJ.get_Number(''V_CONT_15'');',
':P600_PRAB_16 := V_OBJ.get_Number(''V_CONT_16'');',
':P600_PRAB_17 := V_OBJ.get_Number(''V_CONT_17'');',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_process_when=>':P600_MODULO_ACTIVO = ''1'' OR INSTR(:P600_MODULO_ACTIVO, ''DMA430'') > 0 '
,p_process_when_type=>'EXPRESSION'
,p_process_when2=>'PLSQL'
,p_internal_uid=>244538239631546136
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(244541000715546138)
,p_process_sequence=>60
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>unistr('Producci\00F3n Cosm\00E9tica')
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE ',
'    V_RESPUESTA VARCHAR(4000);',
'    V_OBJ        JSON_OBJECT_T;',
'BEGIN',
'-- RETURN;',
'V_RESPUESTA := PK_FINZ_CIERRE_MES.F_CONTADORES_PRODUCCION_COSM;',
'V_OBJ := JSON_OBJECT_T.parse(V_RESPUESTA);',
':P600_PRCS_1 := V_OBJ.get_Number(''V_CONT_1'');',
':P600_PRCS_2 := V_OBJ.get_Number(''V_CONT_2'');',
':P600_PRCS_3 := V_OBJ.get_Number(''V_CONT_3'');',
':P600_PRCS_4 := V_OBJ.get_Number(''V_CONT_4'');',
':P600_PRCS_5 := V_OBJ.get_Number(''V_CONT_5'');',
':P600_PRCS_6 := V_OBJ.get_Number(''V_CONT_6'');',
':P600_PRCS_7 := V_OBJ.get_Number(''V_CONT_7'');',
':P600_PRCS_8 := V_OBJ.get_Number(''V_CONT_8'');',
':P600_PRCS_9 := V_OBJ.get_Number(''V_CONT_9'');',
':P600_PRCS_10 := V_OBJ.get_Number(''V_CONT_10'');',
':P600_PRCS_11 := V_OBJ.get_Number(''V_CONT_11'');',
':P600_PRCS_12 := V_OBJ.get_Number(''V_CONT_12'');',
':P600_PRCS_13 := V_OBJ.get_Number(''V_CONT_13'');',
':P600_PRCS_14 := V_OBJ.get_Number(''V_CONT_14'');',
':P600_PRCS_15 := V_OBJ.get_Number(''V_CONT_15'');',
':P600_PRCS_16 := V_OBJ.get_Number(''V_CONT_16'');',
':P600_PRCS_17 := V_OBJ.get_Number(''V_CONT_17'');',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_process_when=>':P600_MODULO_ACTIVO = ''1'' OR INSTR(:P600_MODULO_ACTIVO, ''COSME'') > 0 '
,p_process_when_type=>'EXPRESSION'
,p_process_when2=>'PLSQL'
,p_internal_uid=>244541000715546138
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(244541458918546138)
,p_process_sequence=>70
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Transformaciones'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE ',
'    V_RESPUESTA VARCHAR(4000);',
'    V_OBJ        JSON_OBJECT_T;',
'BEGIN',
'V_RESPUESTA := PK_FINZ_CIERRE_MES.F_CONTADORES_PRODUCCION_TRANS;',
'V_OBJ := JSON_OBJECT_T.parse(V_RESPUESTA);',
':P600_PRTR_1 := V_OBJ.get_Number(''V_CONT_1'');',
':P600_PRTR_2 := V_OBJ.get_Number(''V_CONT_2'');',
':P600_PRTR_3 := V_OBJ.get_Number(''V_CONT_3'');',
':P600_PRTR_4 := V_OBJ.get_Number(''V_CONT_4'');',
':P600_PRTR_5 := V_OBJ.get_Number(''V_CONT_5'');',
':P600_PRTR_6 := V_OBJ.get_Number(''V_CONT_6'');',
':P600_PRTR_7 := V_OBJ.get_Number(''V_CONT_7'');',
':P600_PRTR_8 := V_OBJ.get_Number(''V_CONT_8'');',
':P600_PRTR_9 := V_OBJ.get_Number(''V_CONT_9'');',
':P600_PRTR_10 := V_OBJ.get_Number(''V_CONT_10'');',
':P600_PRTR_11 := V_OBJ.get_Number(''V_CONT_11'');',
':P600_PRTR_12 := V_OBJ.get_Number(''V_CONT_12'');',
':P600_PRTR_13 := V_OBJ.get_Number(''V_CONT_13'');',
':P600_PRTR_14 := V_OBJ.get_Number(''V_CONT_14'');',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_process_when=>':P600_MODULO_ACTIVO = ''1'' OR INSTR(:P600_MODULO_ACTIVO, ''TRANS'') > 0 '
,p_process_when_type=>'EXPRESSION'
,p_process_when2=>'PLSQL'
,p_internal_uid=>244541458918546138
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(244539863662546137)
,p_process_sequence=>80
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>unistr('Producci\00F3n Envases')
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE ',
'    V_RESPUESTA VARCHAR(4000);',
'    V_OBJ        JSON_OBJECT_T;',
'BEGIN',
'-- RETURN;',
'V_RESPUESTA := PK_FINZ_CIERRE_MES.F_CONTADORES_PRODUCCION_ENV;',
'V_OBJ := JSON_OBJECT_T.parse(V_RESPUESTA);',
':P600_PREN_1 := V_OBJ.get_Number(''V_CONT_1'');',
':P600_PREN_2 := V_OBJ.get_Number(''V_CONT_2'');',
':P600_PREN_3 := V_OBJ.get_Number(''V_CONT_3'');',
':P600_PREN_4 := V_OBJ.get_Number(''V_CONT_4'');',
':P600_PREN_5 := V_OBJ.get_Number(''V_CONT_5'');',
':P600_PREN_6 := V_OBJ.get_Number(''V_CONT_6'');',
':P600_PREN_7 := V_OBJ.get_Number(''V_CONT_7'');',
':P600_PREN_8 := V_OBJ.get_Number(''V_CONT_8'');',
':P600_PREN_9 := V_OBJ.get_Number(''V_CONT_9'');',
':P600_PREN_10 := V_OBJ.get_Number(''V_CONT_10'');',
':P600_PREN_11 := V_OBJ.get_Number(''V_CONT_11'');',
':P600_PREN_12 := V_OBJ.get_Number(''V_CONT_12'');',
':P600_PREN_13 := V_OBJ.get_Number(''V_CONT_13'');',
':P600_PREN_14 := V_OBJ.get_Number(''V_CONT_14'');',
':P600_PREN_15 := V_OBJ.get_Number(''V_CONT_15'');',
':P600_PREN_16 := V_OBJ.get_Number(''V_CONT_16'');',
':P600_PREN_17 := V_OBJ.get_Number(''V_CONT_17'');',
':P600_PREN_18 := V_OBJ.get_Number(''V_CONT_18'');',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_process_when=>':P600_MODULO_ACTIVO = ''1'' OR INSTR(:P600_MODULO_ACTIVO, ''DMA510'') > 0 '
,p_process_when_type=>'EXPRESSION'
,p_process_when2=>'PLSQL'
,p_internal_uid=>244539863662546137
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(244539418442546137)
,p_process_sequence=>90
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>unistr('Log\00EDstica PT')
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE ',
'    V_RESPUESTA VARCHAR(4000);',
'    V_OBJ        JSON_OBJECT_T;',
'BEGIN',
'V_RESPUESTA := PK_FINZ_CIERRE_MES.F_CONTADORES_LOGISTICA_PT;',
'V_OBJ := JSON_OBJECT_T.parse(V_RESPUESTA);',
':P600_LOPT_1 := V_OBJ.get_Number(''V_CONT_1'');',
':P600_LOPT_2 := V_OBJ.get_Number(''V_CONT_2'');',
':P600_LOPT_3 := V_OBJ.get_Number(''V_CONT_3'');',
':P600_LOPT_4 := V_OBJ.get_Number(''V_CONT_4'');',
':P600_LOPT_5 := V_OBJ.get_Number(''V_CONT_5'');',
':P600_LOPT_6 := V_OBJ.get_Number(''V_CONT_6'');',
':P600_LOPT_7 := V_OBJ.get_Number(''V_CONT_7'');',
':P600_LOPT_8 := V_OBJ.get_Number(''V_CONT_8'');',
':P600_LOPT_9 := V_OBJ.get_Number(''V_CONT_9'');',
':P600_LOPT_10 := V_OBJ.get_Number(''V_CONT_10'');',
':P600_LOPT_11 := V_OBJ.get_Number(''V_CONT_11'');',
':P600_LOPT_12 := V_OBJ.get_Number(''V_CONT_12'');',
':P600_LOPT_13 := V_OBJ.get_Number(''V_CONT_13'');',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_process_when=>':P600_MODULO_ACTIVO = ''1'' OR INSTR(:P600_MODULO_ACTIVO, ''DOP340'') > 0 '
,p_process_when_type=>'EXPRESSION'
,p_process_when2=>'PLSQL'
,p_internal_uid=>244539418442546137
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(244541844007546138)
,p_process_sequence=>100
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>unistr('Log\00EDstica MP')
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE ',
'    V_RESPUESTA VARCHAR(4000);',
'    V_OBJ        JSON_OBJECT_T;',
'BEGIN',
'-- RETURN;',
'V_RESPUESTA := PK_FINZ_CIERRE_MES.F_CONTADORES_LOGISTICA_MP;',
'V_OBJ := JSON_OBJECT_T.parse(V_RESPUESTA);',
':P600_LOMP_1 := V_OBJ.get_Number(''V_CONT_1'');',
':P600_LOMP_2 := V_OBJ.get_Number(''V_CONT_2'');',
':P600_LOMP_3 := V_OBJ.get_Number(''V_CONT_3'');',
':P600_LOMP_4 := V_OBJ.get_Number(''V_CONT_4'');',
':P600_LOMP_5 := V_OBJ.get_Number(''V_CONT_5'');',
':P600_LOMP_6 := V_OBJ.get_Number(''V_CONT_6'');',
':P600_LOMP_7 := V_OBJ.get_Number(''V_CONT_7'');',
':P600_LOMP_8 := V_OBJ.get_Number(''V_CONT_8'');',
':P600_LOMP_9 := V_OBJ.get_Number(''V_CONT_9'');',
':P600_LOMP_10 := V_OBJ.get_Number(''V_CONT_10'');',
':P600_LOMP_11 := V_OBJ.get_Number(''V_CONT_11'');',
':P600_LOMP_12 := V_OBJ.get_Number(''V_CONT_12'');',
':P600_LOMP_13 := V_OBJ.get_Number(''V_CONT_13'');',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_process_when=>':P600_MODULO_ACTIVO = ''1'' OR INSTR(:P600_MODULO_ACTIVO, ''DOP339'') > 0 '
,p_process_when_type=>'EXPRESSION'
,p_process_when2=>'PLSQL'
,p_internal_uid=>244541844007546138
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(244542240349546138)
,p_process_sequence=>110
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>unistr('Log\00EDstica BDG Menores')
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE ',
'    V_RESPUESTA VARCHAR(4000);',
'    V_OBJ        JSON_OBJECT_T;',
'BEGIN',
'-- RETURN;',
'V_RESPUESTA := PK_FINZ_CIERRE_MES.F_CONTADORES_LOGISTICA_BDGMEN;',
'V_OBJ := JSON_OBJECT_T.parse(V_RESPUESTA);',
':P600_LOME_1 := V_OBJ.get_Number(''V_CONT_1'');',
':P600_LOME_2 := V_OBJ.get_Number(''V_CONT_2'');',
':P600_LOME_3 := V_OBJ.get_Number(''V_CONT_3'');',
':P600_LOME_4 := V_OBJ.get_Number(''V_CONT_4'');',
':P600_LOME_5 := V_OBJ.get_Number(''V_CONT_5'');',
':P600_LOME_6 := V_OBJ.get_Number(''V_CONT_6'');',
':P600_LOME_7 := V_OBJ.get_Number(''V_CONT_7'');',
':P600_LOME_8 := V_OBJ.get_Number(''V_CONT_8'');',
':P600_LOME_9 := V_OBJ.get_Number(''V_CONT_9'');',
':P600_LOME_10 := V_OBJ.get_Number(''V_CONT_10'');',
':P600_LOME_11 := V_OBJ.get_Number(''V_CONT_11'');',
':P600_LOME_12 := V_OBJ.get_Number(''V_CONT_12'');',
':P600_LOME_13 := V_OBJ.get_Number(''V_CONT_13'');',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_process_when=>':P600_MODULO_ACTIVO = ''1'' OR INSTR(:P600_MODULO_ACTIVO, ''DOP347'') > 0 '
,p_process_when_type=>'EXPRESSION'
,p_process_when2=>'PLSQL'
,p_internal_uid=>244542240349546138
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(244538656391546136)
,p_process_sequence=>120
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Activos Fijos'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE ',
'    V_RESPUESTA VARCHAR(4000);',
'    V_OBJ        JSON_OBJECT_T;',
'BEGIN',
'V_RESPUESTA := PK_FINZ_CIERRE_MES.F_CONTADORES_ACTIVOS_FIJOS;',
'V_OBJ := JSON_OBJECT_T.parse(V_RESPUESTA);',
':P600_ACFI_1 := V_OBJ.get_Number(''V_CONT_1'');',
':P600_ACFI_2 := V_OBJ.get_Number(''V_CONT_2'');',
':P600_ACFI_3 := V_OBJ.get_Number(''V_CONT_3'');',
':P600_ACFI_4 := V_OBJ.get_Number(''V_CONT_4'');',
':P600_ACFI_5 := V_OBJ.get_Number(''V_CONT_5'');',
':P600_ACFI_6 := V_OBJ.get_Number(''V_CONT_6'');',
'RETURN;',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_process_when=>':P600_MODULO_ACTIVO = ''1'' OR INSTR(:P600_MODULO_ACTIVO, ''ACTFI'') > 0 '
,p_process_when_type=>'EXPRESSION'
,p_process_when2=>'PLSQL'
,p_internal_uid=>244538656391546136
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(244539053789546136)
,p_process_sequence=>130
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Contabilidad'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE ',
'    V_RESPUESTA VARCHAR(4000);',
'    V_OBJ        JSON_OBJECT_T;',
'BEGIN',
'V_RESPUESTA := PK_FINZ_CIERRE_MES.F_CONTADORES_CONTABILIDAD;',
'V_OBJ := JSON_OBJECT_T.parse(V_RESPUESTA);',
':P600_CONT_1 := V_OBJ.get_Number(''V_CONT_1'');',
':P600_CONT_2 := V_OBJ.get_Number(''V_CONT_2'');',
':P600_CONT_3 := V_OBJ.get_Number(''V_CONT_3'');',
':P600_CONT_4 := V_OBJ.get_Number(''V_CONT_4'');',
':P600_CONT_5 := V_OBJ.get_Number(''V_CONT_5'');',
':P600_CONT_6 := V_OBJ.get_Number(''V_CONT_6'');',
':P600_CONT_7 := V_OBJ.get_Number(''V_CONT_7'');',
':P600_CONT_8 := V_OBJ.get_Number(''V_CONT_8'');',
':P600_CONT_9 := V_OBJ.get_Number(''V_CONT_9'');',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_process_when=>':P600_MODULO_ACTIVO = ''1'' OR INSTR(:P600_MODULO_ACTIVO, ''CONTA'') > 0 '
,p_process_when_type=>'EXPRESSION'
,p_process_when2=>'PLSQL'
,p_internal_uid=>244539053789546136
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(244540647066546137)
,p_process_sequence=>140
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Cuentas x Pagar'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE ',
'    V_RESPUESTA VARCHAR(4000);',
'    V_OBJ        JSON_OBJECT_T;',
'BEGIN',
'V_RESPUESTA := PK_FINZ_CIERRE_MES.F_CONTADORES_CXP;',
'V_OBJ := JSON_OBJECT_T.parse(V_RESPUESTA);',
'    :P600_CXPP_1 := V_OBJ.get_Number(''V_CONT_1'');',
'    :P600_CXPP_2 := V_OBJ.get_Number(''V_CONT_2'');',
'    :P600_CXPP_3 := V_OBJ.get_Number(''V_CONT_3'');',
'    :P600_CXPP_4 := V_OBJ.get_Number(''V_CONT_4'');',
'    :P600_CXPP_5 := V_OBJ.get_Number(''V_CONT_5'');',
'    :P600_CXPP_6 := V_OBJ.get_Number(''V_CONT_6'');',
'    :P600_CXPP_7 := V_OBJ.get_Number(''V_CONT_7'');',
'    :P600_CXPP_8 := V_OBJ.get_Number(''V_CONT_8'');',
'    :P600_CXPP_9 := V_OBJ.get_Number(''V_CONT_9'');',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_process_when=>':P600_MODULO_ACTIVO = ''1'' OR INSTR(:P600_MODULO_ACTIVO, ''CXPFI'') > 0 '
,p_process_when_type=>'EXPRESSION'
,p_process_when2=>'PLSQL'
,p_internal_uid=>244540647066546137
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(244542671383546139)
,p_process_sequence=>150
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Cuentas x Pagar Colaboradores'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE ',
'    V_RESPUESTA VARCHAR(4000);',
'    V_OBJ        JSON_OBJECT_T;',
'BEGIN',
'V_RESPUESTA := PK_FINZ_CIERRE_MES.F_CONTADORES_CXPC;',
'V_OBJ := JSON_OBJECT_T.parse(V_RESPUESTA);',
':P600_CXPC_1 := V_OBJ.get_Number(''V_CONT_1'');',
':P600_CXPC_2 := V_OBJ.get_Number(''V_CONT_2'');',
':P600_CXPC_3 := V_OBJ.get_Number(''V_CONT_3'');',
':P600_CXPC_4 := V_OBJ.get_Number(''V_CONT_4'');',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_process_when=>':P600_MODULO_ACTIVO = ''1'' OR INSTR(:P600_MODULO_ACTIVO, ''CXPCF'') > 0 '
,p_process_when_type=>'EXPRESSION'
,p_process_when2=>'PLSQL'
,p_internal_uid=>244542671383546139
,p_updated_on=>wwv_flow_imp.dz('20260428143229Z')
,p_updated_by=>'JBALCAZAR'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(244540291410546137)
,p_process_sequence=>160
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>unistr('Tesorer\00EDa')
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE ',
'    V_RESPUESTA VARCHAR(4000);',
'    V_OBJ        JSON_OBJECT_T;',
'BEGIN',
'    V_RESPUESTA := PK_FINZ_CIERRE_MES.F_CONTADORES_TESORERIA;',
'    V_OBJ := JSON_OBJECT_T.parse(V_RESPUESTA);',
'    :P600_TESO_1 := V_OBJ.get_Number(''V_CONT_1'');',
'    :P600_TESO_2 := V_OBJ.get_Number(''V_CONT_2'');',
'    :P600_TESO_3 := V_OBJ.get_Number(''V_CONT_3'');',
'    :P600_TESO_4 := V_OBJ.get_Number(''V_CONT_4'');',
'    :P600_TESO_5 := V_OBJ.get_Number(''V_CONT_5'');',
'    :P600_TESO_6 := V_OBJ.get_Number(''V_CONT_6'');',
'    :P600_TESO_7 := V_OBJ.get_Number(''V_CONT_7'');',
'    :P600_TESO_8 := V_OBJ.get_Number(''V_CONT_8'');',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_process_when=>':P600_MODULO_ACTIVO = ''1'' OR INSTR(:P600_MODULO_ACTIVO, ''TESOR'') > 0 '
,p_process_when_type=>'EXPRESSION'
,p_process_when2=>'PLSQL'
,p_internal_uid=>244540291410546137
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(244543460807546139)
,p_process_sequence=>170
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Cuentas x Cobrar'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE ',
'    V_RESPUESTA VARCHAR(4000);',
'    V_OBJ        JSON_OBJECT_T;',
'BEGIN',
'    V_RESPUESTA := PK_FINZ_CIERRE_MES.F_CONTADORES_CXC;',
'    V_OBJ := JSON_OBJECT_T.parse(V_RESPUESTA);',
'    :P600_CXCP_1 := V_OBJ.get_Number(''V_CONT_1'');',
'    :P600_CXCP_2 := V_OBJ.get_Number(''V_CONT_2'');',
'    :P600_CXCP_3 := V_OBJ.get_Number(''V_CONT_3'');',
'    :P600_CXCP_4 := V_OBJ.get_Number(''V_CONT_4'');',
'    :P600_CXCP_5 := V_OBJ.get_Number(''V_CONT_5'');',
'    :P600_CXCP_6 := V_OBJ.get_Number(''V_CONT_6'');',
'    :P600_CXCP_7 := V_OBJ.get_Number(''V_CONT_7'');',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_process_when=>':P600_MODULO_ACTIVO = ''1'' OR INSTR(:P600_MODULO_ACTIVO, ''CXCFI'') > 0 '
,p_process_when_type=>'EXPRESSION'
,p_process_when2=>'PLSQL'
,p_internal_uid=>244543460807546139
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(244543888399546139)
,p_process_sequence=>180
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>unistr('Conciliaci\00F3n Bancaria')
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE ',
'    V_RESPUESTA VARCHAR(4000);',
'    V_OBJ        JSON_OBJECT_T;',
'BEGIN',
'    V_RESPUESTA := PK_FINZ_CIERRE_MES.F_CONTADORES_CONCILIACION_BAN;',
'    V_OBJ := JSON_OBJECT_T.parse(V_RESPUESTA);',
'    :P600_COBA_1 := V_OBJ.get_Number(''V_CONT_1'');',
'    :P600_COBA_2 := V_OBJ.get_Number(''V_CONT_2'');',
'    :P600_COBA_3 := V_OBJ.get_Number(''V_CONT_3'');',
'    :P600_COBA_4 := V_OBJ.get_Number(''V_CONT_4'');',
'    :P600_COBA_5 := V_OBJ.get_Number(''V_CONT_5'');',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_process_when=>':P600_MODULO_ACTIVO = ''1'' OR INSTR(:P600_MODULO_ACTIVO, ''COBAN'') > 0 '
,p_process_when_type=>'EXPRESSION'
,p_process_when2=>'PLSQL'
,p_internal_uid=>244543888399546139
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(244544248615546139)
,p_process_sequence=>190
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Impuestos'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE ',
'    V_RESPUESTA VARCHAR(4000);',
'    V_OBJ        JSON_OBJECT_T;',
'BEGIN',
'    V_RESPUESTA := PK_FINZ_CIERRE_MES.F_CONTADORES_IMPUESTOS;',
'    V_OBJ := JSON_OBJECT_T.parse(V_RESPUESTA);',
'    :P600_IMPU_1 := V_OBJ.get_Number(''V_CONT_1'');',
'    :P600_IMPU_2 := V_OBJ.get_Number(''V_CONT_2'');',
'    :P600_IMPU_3 := V_OBJ.get_Number(''V_CONT_3'');',
'    :P600_IMPU_4 := V_OBJ.get_Number(''V_CONT_4'');',
'    :P600_IMPU_5 := V_OBJ.get_Number(''V_CONT_5'');',
'    :P600_IMPU_6 := V_OBJ.get_Number(''V_CONT_6'');',
'    :P600_IMPU_7 := V_OBJ.get_Number(''V_CONT_7'');',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_process_when=>':P600_MODULO_ACTIVO = ''1'' OR INSTR(:P600_MODULO_ACTIVO, ''IMPUE'') > 0 '
,p_process_when_type=>'EXPRESSION'
,p_process_when2=>'PLSQL'
,p_internal_uid=>244544248615546139
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(244543043836546139)
,p_process_sequence=>200
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'RRHH'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE ',
'    V_RESPUESTA VARCHAR(4000);',
'    V_OBJ        JSON_OBJECT_T;',
'BEGIN',
'-- RETURN;',
'V_RESPUESTA := PK_FINZ_CIERRE_MES.F_CONTADORES_RRHH;',
'V_OBJ := JSON_OBJECT_T.parse(V_RESPUESTA);',
':P600_RRHH_1 := V_OBJ.get_Number(''V_CONT_1'');',
':P600_RRHH_2 := V_OBJ.get_Number(''V_CONT_2'');',
':P600_RRHH_3 := V_OBJ.get_Number(''V_CONT_3'');',
':P600_RRHH_4 := V_OBJ.get_Number(''V_CONT_4'');',
':P600_RRHH_5 := V_OBJ.get_Number(''V_CONT_5'');',
':P600_RRHH_6 := V_OBJ.get_Number(''V_CONT_6'');',
':P600_RRHH_7 := V_OBJ.get_Number(''V_CONT_7'');',
':P600_RRHH_8 := V_OBJ.get_Number(''V_CONT_8'');',
':P600_RRHH_9 := V_OBJ.get_Number(''V_CONT_9'');',
':P600_RRHH_10 := V_OBJ.get_Number(''V_CONT_10'');',
':P600_RRHH_11 := V_OBJ.get_Number(''V_CONT_11'');',
':P600_RRHH_12 := V_OBJ.get_Number(''V_CONT_12'');',
':P600_RRHH_13 := V_OBJ.get_Number(''V_CONT_13'');',
':P600_RRHH_14 := V_OBJ.get_Number(''V_CONT_14'');',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_process_when=>':P600_MODULO_ACTIVO = ''1'' OR INSTR(:P600_MODULO_ACTIVO, ''RRHH'') > 0 '
,p_process_when_type=>'EXPRESSION'
,p_process_when2=>'PLSQL'
,p_internal_uid=>244543043836546139
);
wwv_flow_imp.component_end;
end;
/
