prompt --application/pages/page_00105
begin
--   Manifest
--     PAGE: 00105
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>109
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_page.create_page(
 p_id=>105
,p_name=>'PyG Envases Autorizaciones de Valores - Gestion'
,p_step_title=>'PyG Envases Autorizaciones de Valores - Gestion'
,p_autocomplete_on_off=>'OFF'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.a-IRR-controls-item--controlBreak {',
'     display: none;',
'}',
'.a-IRR-reportSummary-item--controlBreak{',
'     display: none;',
'}'))
,p_page_template_options=>'#DEFAULT#'
,p_page_component_map=>'18'
,p_created_on=>wwv_flow_imp.dz('20230705164634Z')
,p_last_updated_on=>wwv_flow_imp.dz('20240801182109Z')
,p_last_updated_by=>'MALBAN'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(105940365725866938)
,p_plug_name=>'PyG Envases Autorizaciones de Valores - Mesa deTrabajo'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(38290610465120145)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(37761271469106475)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(37860983999106559)
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(105940437081866939)
,p_plug_name=>'Barra de acciones'
,p_region_template_options=>'#DEFAULT#:t-Form--stretchInputs'
,p_plug_template=>wwv_flow_imp.id(38289497777120142)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'REGION_POSITION_01'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(105940857250866943)
,p_plug_name=>'PendienteAtutorizar'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(37806762584106520)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT',
'        pk_finanzas.fn_traeniveles(parametro.n2_id, 1,''ENV'')                  n1,',
'        pk_finanzas.fn_traeniveles(parametro.n2_id, 2,''ENV'')                  n2,',
'        parametro.txt01                                                 asociacion,',
'        valor.valor                                                     valor,',
'        valor.CODIFICACION                                              CODIFICACION,',
'        valor.fechaini                                                  fechaini,',
'        valor.fechafin                                                  fechafin,',
'        valor.estado                                                    etapa,',
'        valor.token',
'    FROM',
'             t_finz_param_formulas parametro',
'        INNER JOIN T_FINZ_PYGENV_FRM   valor ON parametro.id = valor.parn2id',
'        INNER JOIN t_flujo_aprobacion_cab flujo ON valor.compania = flujo.cia',
'                                                   AND valor.token = flujo.entidad_id',
'    WHERE',
'            flujo.codmodulo = ''FINZ'' AND parametro.tipo=''ENV''',
'        AND flujo.entidad_clase = ''Pyg_ZP_Valores''        ',
'        AND valor.token= :P105_TOKEN',
'        order by valor.id',
'    '))
,p_plug_source_type=>'NATIVE_IR'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>210
,p_prn_height=>297
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_updated_on=>wwv_flow_imp.dz('20240801182109Z')
,p_updated_by=>'MALBAN'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(105940959218866944)
,p_max_row_count=>'1000000'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_show_search_bar=>'N'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_enable_mail_download=>'Y'
,p_owner=>'EMASABANDA'
,p_internal_uid=>105940959218866944
,p_updated_on=>wwv_flow_imp.dz('20240801182109Z')
,p_updated_by=>'MALBAN'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(105941022113866945)
,p_db_column_name=>'N1'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'N1'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(105941138662866946)
,p_db_column_name=>'N2'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'N2'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(105941200070866947)
,p_db_column_name=>'ASOCIACION'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Parametrizacion'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(106003540288394206)
,p_db_column_name=>'FECHAINI'
,p_display_order=>120
,p_column_identifier=>'L'
,p_column_label=>'F. Desde'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(106003622722394207)
,p_db_column_name=>'FECHAFIN'
,p_display_order=>130
,p_column_identifier=>'M'
,p_column_label=>'F. Hasta'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(106003765460394208)
,p_db_column_name=>'ETAPA'
,p_display_order=>140
,p_column_identifier=>'N'
,p_column_label=>'Estado'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(106003885696394209)
,p_db_column_name=>'TOKEN'
,p_display_order=>150
,p_column_identifier=>'O'
,p_column_label=>'Id Proceso'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(107416032430497231)
,p_db_column_name=>'VALOR'
,p_display_order=>160
,p_column_identifier=>'P'
,p_column_label=>'Valor'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(107416118247497232)
,p_db_column_name=>'CODIFICACION'
,p_display_order=>170
,p_column_identifier=>'Q'
,p_column_label=>'Codificacion'
,p_column_type=>'STRING'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_rpt_named_lov=>wwv_flow_imp.id(107613280412709733)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(106017723905395784)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'1060178'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'N1:N2:ASOCIACIONCOSTOLOG:PORCECOSTOLOGMARGENGAN:PORCEMARGENGANCOSTOCAP:PORCECOSTOCAPFEE:FECHAINI:FECHAFIN:ETAPA::VALOR:CODIFICACION'
,p_sort_column_1=>'FECHAINI'
,p_sort_direction_1=>'ASC'
,p_sort_column_2=>'0'
,p_sort_direction_2=>'ASC'
,p_sort_column_3=>'0'
,p_sort_direction_3=>'ASC'
,p_sort_column_4=>'0'
,p_sort_direction_4=>'ASC'
,p_sort_column_5=>'0'
,p_sort_direction_5=>'ASC'
,p_sort_column_6=>'0'
,p_sort_direction_6=>'ASC'
,p_break_on=>'N1:N2:0:0:0:0'
,p_break_enabled_on=>'N1:N2:0:0:0:0'
,p_created_on=>wwv_flow_imp.dz('20230705164634Z')
,p_updated_on=>wwv_flow_imp.dz('20230705164634Z')
,p_created_by=>'CVACA'
,p_updated_by=>'CVACA'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(105940586418866940)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(105940437081866939)
,p_button_name=>'Regresar'
,p_button_static_id=>'btnRegresar'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860056812106557)
,p_button_image_alt=>'Regresar'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'LEFT'
,p_button_redirect_url=>'f?p=&APP_ID.:104:&SESSION.::&DEBUG.:RP::'
,p_icon_css_classes=>'fa-arrow-left'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(106005838503394229)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(105940437081866939)
,p_button_name=>'Aprobar'
,p_button_static_id=>'btnAprobar'
,p_button_action=>'REDIRECT_APP'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860056812106557)
,p_button_image_alt=>'Aprobar'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=100:102:&SESSION.::&DEBUG.:RP:G_COMPANIA,G_MODULO,G_USUARIO,G_OBJETO,G_OBJETO_ID:&G_COMPANIA.,&APP_MODULO.,&APP_USER.,Pyg_ZP_Valores,&P105_TOKEN.'
,p_icon_css_classes=>'fa-thumbs-up'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(106005954056394230)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(105940437081866939)
,p_button_name=>'Rechazar'
,p_button_static_id=>'btnRechazar'
,p_button_action=>'REDIRECT_APP'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860056812106557)
,p_button_image_alt=>'Rechazar'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=100:103:&SESSION.::&DEBUG.:RP:G_COMPANIA,G_MODULO,G_USUARIO,G_OBJETO,G_OBJETO_ID,G_USUARIO_FLUJO:&G_COMPANIA.,&APP_MODULO.,&APP_USER.,Pyg_ZP_Valores,&P105_TOKEN.,'
,p_icon_css_classes=>'fa-thumbs-down '
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(106006059733394231)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(105940437081866939)
,p_button_name=>'Ver_Ruta'
,p_button_action=>'REDIRECT_APP'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860056812106557)
,p_button_image_alt=>'Ver Ruta'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=100:104:&SESSION.::&DEBUG.:RP:G_OBJETO,G_OBJETO_ID,G_TODO:Pyg_ZP_Valores,&P105_TOKEN.,true'
,p_icon_css_classes=>'fa-road'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(105940765762866942)
,p_name=>'P105_TOKEN'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(105940857250866943)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(106006398402394234)
,p_name=>'P105_TERMINA_FLUJO'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(105940857250866943)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(106006669230394237)
,p_name=>'P105_ENVIO_EXITO'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(105940857250866943)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(106103714777260201)
,p_name=>'P105_MENSAJE'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(105940857250866943)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(106006160077394232)
,p_name=>unistr('Cierre di\00E1logo: aprobar')
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(106005838503394229)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(106006279100394233)
,p_event_id=>wwv_flow_imp.id(106006160077394232)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'apex.item( "P105_TERMINA_FLUJO" ).setValue("");',
'apex.item( "P105_ENVIO_EXITO" ).setValue("");',
'',
'var trama = JSON.parse(this.data.G_RESULTADO);',
'var isTerminoFlujo= trama.resultado.terminoFlujo;',
'var isExitoso = this.data.G_EXITO;',
'apex.item( "P105_TERMINA_FLUJO" ).setValue(isTerminoFlujo);',
'apex.item( "P105_ENVIO_EXITO" ).setValue(isExitoso);',
'if ($v("P105_TERMINA_FLUJO")=="true")',
'{',
'    mensaje(''exito'', this.data.G_MENSAJE);',
'    apex.item( "P105_ENVIO_EXITO" ).setValue(1);',
'    if(isTerminoFlujo){',
'        apex.item( "P105_TERMINA_FLUJO" ).setValue(1);',
'    }',
'    $(''#btnAprobar'').hide();',
'    $(''#btnRechazar'').hide();',
'}',
'else{',
'     apex.item( "P105_TERMINA_FLUJO" ).setValue(0);',
'    mensaje(''error'', this.data.G_MENSAJE);',
'}'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(106006411032394235)
,p_name=>unistr('Cierre di\00E1logo: aprobar exito')
,p_event_sequence=>20
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(106005838503394229)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(106006573966394236)
,p_event_id=>wwv_flow_imp.id(106006411032394235)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'v_valida number;',
'begin',
'    :P105_MENSAJE:=''P105_MENSAJE ANTES DE '';       ',
'    IF nvl(:P105_TERMINA_FLUJO, 0) = 1 THEN',
'        UPDATE T_FINZ_PYGENV_FRM',
'        SET ESTADO = ''APROBADO'', APROBADOR = :APP_USER',
'        WHERE token = :P105_TOKEN;',
'        ',
'        COMMIT;',
'    ELSE',
'        UPDATE T_FINZ_PYGENV_FRM',
'        SET ESTADO = ''EN_PROCESO''',
'        WHERE token = :P105_TOKEN;',
'        commit;',
'    END IF;',
'    commit;',
'    --:P105_MENSAJE:=''P105_MENSAJE DESPUES DE '';       ',
'end;',
'',
'declare v_aprobador varchar2(20);',
'begin',
'    begin',
'        select APROBADOR into v_aprobador from vt_finz_mesatrabajo_pygenvases where token=:P105_TOKEN;',
'    exception when others then',
'        v_aprobador:=null;',
'    end;',
'    if (v_aprobador is not null) then',
'        update T_FINZ_PYGENV_FRM',
'        set Aprobador = v_aprobador',
'        where  token=:P105_TOKEN;',
'        commit;',
'    end if;',
'end;'))
,p_attribute_02=>'P105_TERMINA_FLUJO,P105_ENVIO_EXITO,P105_TOKEN,P105_MENSAJE'
,p_attribute_03=>'P105_MENSAJE'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(106007154497394242)
,p_event_id=>wwv_flow_imp.id(106006411032394235)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'$(''#btnAprobar'').hide();',
'$(''#btnRechazar'').hide();',
'$(''#btnRegresar'').trigger("click");'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(106007249220394243)
,p_name=>unistr('Cierre di\00E1logo: rechazar')
,p_event_sequence=>30
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(106005954056394230)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(106007311461394244)
,p_event_id=>wwv_flow_imp.id(106007249220394243)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'var trama = JSON.parse(this.data.G_RESULTADO);',
'var isTerminoFlujo= trama.resultado.terminoFlujo;',
'apex.item( "P105_TERMINA_FLUJO" ).setValue(0);',
'apex.item( "P105_ENVIO_EXITO" ).setValue(0);',
'',
'if(this.data.G_EXITO==''true''){',
'    mensaje(''exito'', this.data.G_MENSAJE);',
'     apex.item( "P105_ENVIO_EXITO" ).setValue(1);',
'    if(isTerminoFlujo){',
'        apex.item( "P105_TERMINA_FLUJO" ).setValue(1);',
'    }',
'    $(''#btnAprobar'').hide();',
'    $(''#btnRechazar'').hide();',
'}',
'else{',
'    mensaje(''error'', this.data.G_MENSAJE);',
'}'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(106007425063394245)
,p_name=>unistr('Cierre di\00E1logo: rechazar exito')
,p_event_sequence=>40
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(106005954056394230)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(106007577803394246)
,p_event_id=>wwv_flow_imp.id(106007425063394245)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'v_valida number;',
'begin',
'    UPDATE T_FINZ_PYGENV_FRM',
'    SET ESTADO = '''', APROBADOR = :APP_USER',
'    WHERE token = :P105_TOKEN;',
'    COMMIT;',
'end;',
'',
''))
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(106007680453394247)
,p_event_id=>wwv_flow_imp.id(106007425063394245)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'$(''#btnAprobar'').hide();',
'$(''#btnRechazar'').hide();',
'$(''#btnRegresar'').trigger("click");'))
);
wwv_flow_imp.component_end;
end;
/
