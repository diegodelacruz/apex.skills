prompt --application/pages/page_02008
begin
--   Manifest
--     PAGE: 02008
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>109
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_page.create_page(
 p_id=>2008
,p_name=>unistr('Reporte de Adquisici\00F3n de Bienes Inventariables')
,p_step_title=>unistr('Reporte de Adquisici\00F3n de Bienes Inventariables')
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_page_component_map=>'18'
,p_created_on=>wwv_flow_imp.dz('20230705164635Z')
,p_last_updated_on=>wwv_flow_imp.dz('20220906142414Z')
,p_last_updated_by=>'JALTAMIRANO'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(74218114479695601)
,p_plug_name=>'Filtros'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(38289867500120143)
,p_plug_display_sequence=>30
,p_include_in_reg_disp_sel_yn=>'Y'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(83285147971518205)
,p_plug_name=>'Acciones'
,p_region_template_options=>'#DEFAULT#:t-Form--stretchInputs'
,p_plug_template=>wwv_flow_imp.id(38289497777120142)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(83520388185941217)
,p_plug_name=>'Reporte OC Gastos Adicionales'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(37806762584106520)
,p_plug_display_sequence=>40
,p_include_in_reg_disp_sel_yn=>'Y'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT TXT18 CASILLERO',
', TXT16 TIPOPRODUCTO',
', TXT16 CATEGORIA',
', NUM01 OC',
', TXT01 TIPOOC',
', NUM03 CODIGOPROVEEDOR',
', TXT13 NOMBREPROVEEDOR',
', TXT09 NOMBREPROVEEDORASIENTO',
', TRIM(TXT10) PROVEEDORJE',
', TXT14 RUC',
', TXT06 CUENTACONTABLE',
', NUM02 NUMEROORDENCONTABLE',
', NUM06 BATHCONTABLE',
', TXT02 TIPODOCUMENTO',
', TXT11 NUMEROSECUENCIAL',
', NUM05 FECHA',
', NUM04 CODIGOPRODUCTOCORTO',
', NUM12 CODIGOPRODUCTOLARGO',
', TXT15 NOMBREPRODUCTO',
', NUM09/10000 CANTIDADPRODUCTOKARDEX',
', NUM13/10000 CANTIDADPRODUCTOORDEN',
', NUM10/10000 COSTOUNITARIOKARDEX',
', NUM14/10000 COSTOUNITARIOORDEN',
', NUM15/100 VALORPAGADOORDEN',
', NUM16/100 VALORACUERDOORDEN',
', NUM11/100 VALORPAGADOKARDEX',
', NUM08/100 VALORASIENTOCONTABLE',
', NUM17/100 VARIACIONORDEN',
', TXT07 MONEDA',
', TXT20 UNIDADMEDIDA',
', TXT04 CODIGOCOMPANIA',
', NUM07 LINEAOC',
', TXT03',
', TXT05',
', TXT08',
', TXT12 TIPOIMPUESTO',
', TXT17',
', TXT19',
', TXT21 BODEGA',
', TXT22 NOMBREIMPUESTO',
', NUM18/1000 VALORIMPUESTO',
', TXT23 FACTORIMPUESTO',
', TXT24 APLICAIMPUESTO',
', CASE WHEN NUM18 = 0 AND NUM04<>0 THEN NUM09/10000 * NUM14/10000 ',
'       WHEN NUM18 = 0 AND NUM04=0 THEN NUM08/100',
'       ELSE 0 END BASEIMPONIBLE0',
', CASE WHEN NUM18 <> 0 AND NUM04<>0 THEN (NUM09/10000 * NUM14/10000) ',
'       WHEN NUM18 <> 0 AND NUM04=0 THEN NUM08/100 ',
'       ELSE 0 END BASEIMPONIBLE12 ',
', CASE WHEN NUM18 <> 0 AND NUM04<>0 THEN (NUM09/10000 * NUM14/10000) * NUM18/100000 ',
'       WHEN NUM18 <> 0 AND NUM04=0 THEN NUM08/100 * NUM18/100000',
'       ELSE 0 END IVA',
', CASE WHEN NUM18 = 0 AND NUM04<>0 THEN NUM09/10000 * NUM14/10000 ',
'       WHEN NUM18 = 0 AND NUM04=0 THEN NUM08/100',
'       WHEN NUM18 <> 0 AND NUM04<>0 THEN (NUM09/10000 * NUM14/10000) ',
'       WHEN NUM18 <> 0 AND NUM04=0 THEN NUM08/100',
'       ELSE 0 END TOTALBASEIMPONIBLE',
', CASE WHEN NUM18 = 0 AND NUM04<>0 THEN NUM09/10000 * NUM14/10000 ',
'       WHEN NUM18 = 0 AND NUM04=0 THEN NUM08/100',
'       WHEN NUM18 <> 0 AND NUM04<>0 THEN (NUM09/10000 * NUM14/10000) * (1 + NUM18/100000) ',
'       WHEN NUM18 <> 0 AND NUM04=0 THEN NUM08/100 * (1 + NUM18/100000)',
'       ELSE 0 END TOTAL      ',
'FROM t_apex_temporal',
'where flag=''F09112''',
''))
,p_plug_source_type=>'NATIVE_IR'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>210
,p_prn_height=>297
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(83609254326045410)
,p_max_row_count=>'1000000'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'HTML:CSV'
,p_enable_mail_download=>'N'
,p_owner=>'JALTAMIRANO'
,p_internal_uid=>83609254326045410
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(83610140410045419)
,p_db_column_name=>'TXT03'
,p_display_order=>90
,p_column_identifier=>'I'
,p_column_label=>'Txt03'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(83610338914045421)
,p_db_column_name=>'TXT05'
,p_display_order=>110
,p_column_identifier=>'K'
,p_column_label=>'Txt05'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(83610651131045424)
,p_db_column_name=>'TXT08'
,p_display_order=>140
,p_column_identifier=>'N'
,p_column_label=>'Txt08'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(83611540341045433)
,p_db_column_name=>'TXT17'
,p_display_order=>230
,p_column_identifier=>'W'
,p_column_label=>'Txt17'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(83611781101045435)
,p_db_column_name=>'TXT19'
,p_display_order=>250
,p_column_identifier=>'Y'
,p_column_label=>'Txt19'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(83705195414050402)
,p_db_column_name=>'CASILLERO'
,p_display_order=>260
,p_column_identifier=>'BP'
,p_column_label=>'Casillero'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(83705234637050403)
,p_db_column_name=>'TIPOPRODUCTO'
,p_display_order=>270
,p_column_identifier=>'BQ'
,p_column_label=>'Tipoproducto'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(83705328044050404)
,p_db_column_name=>'CATEGORIA'
,p_display_order=>280
,p_column_identifier=>'BR'
,p_column_label=>unistr('Categor\00EDa')
,p_column_type=>'STRING'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_rpt_named_lov=>wwv_flow_imp.id(83945546001268044)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(83705481011050405)
,p_db_column_name=>'OC'
,p_display_order=>290
,p_column_identifier=>'BS'
,p_column_label=>'OC'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(83705534153050406)
,p_db_column_name=>'TIPOOC'
,p_display_order=>300
,p_column_identifier=>'BT'
,p_column_label=>'Tipo OC'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(83705690795050407)
,p_db_column_name=>'CODIGOPROVEEDOR'
,p_display_order=>310
,p_column_identifier=>'BU'
,p_column_label=>unistr('C\00F3digo proveedor')
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(83705719786050408)
,p_db_column_name=>'NOMBREPROVEEDOR'
,p_display_order=>320
,p_column_identifier=>'BV'
,p_column_label=>'Nombre proveedor'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(83709373597050444)
,p_db_column_name=>'PROVEEDORJE'
,p_display_order=>330
,p_column_identifier=>'DF'
,p_column_label=>'Proveedor JE'
,p_column_type=>'STRING'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_rpt_named_lov=>wwv_flow_imp.id(84294601321551800)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(83705819217050409)
,p_db_column_name=>'RUC'
,p_display_order=>340
,p_column_identifier=>'BW'
,p_column_label=>'RUC'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(83705984851050410)
,p_db_column_name=>'CUENTACONTABLE'
,p_display_order=>350
,p_column_identifier=>'BX'
,p_column_label=>'Cuenta contable'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(83706096280050411)
,p_db_column_name=>'NUMEROORDENCONTABLE'
,p_display_order=>360
,p_column_identifier=>'BY'
,p_column_label=>'Numero orden contable'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(83706181712050412)
,p_db_column_name=>'BATHCONTABLE'
,p_display_order=>370
,p_column_identifier=>'BZ'
,p_column_label=>'Bath contable'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(83706235474050413)
,p_db_column_name=>'TIPODOCUMENTO'
,p_display_order=>380
,p_column_identifier=>'CA'
,p_column_label=>'Tipo documento'
,p_column_type=>'STRING'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_rpt_named_lov=>wwv_flow_imp.id(83961973077696144)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(83706380728050414)
,p_db_column_name=>'NUMEROSECUENCIAL'
,p_display_order=>390
,p_column_identifier=>'CB'
,p_column_label=>unistr('N\00FAmero Secuencial')
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(83706422145050415)
,p_db_column_name=>'FECHA'
,p_display_order=>400
,p_column_identifier=>'CC'
,p_column_label=>'Fecha'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(83706695458050417)
,p_db_column_name=>'NOMBREPRODUCTO'
,p_display_order=>410
,p_column_identifier=>'CE'
,p_column_label=>'Nombre producto'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(83707114509050422)
,p_db_column_name=>'MONEDA'
,p_display_order=>420
,p_column_identifier=>'CJ'
,p_column_label=>'Moneda'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(83707247376050423)
,p_db_column_name=>'UNIDADMEDIDA'
,p_display_order=>430
,p_column_identifier=>'CK'
,p_column_label=>'Unidad medida'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(83707324477050424)
,p_db_column_name=>'CODIGOCOMPANIA'
,p_display_order=>440
,p_column_identifier=>'CL'
,p_column_label=>unistr('C\00F3digo compa\00F1\00EDa')
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(83707417269050425)
,p_db_column_name=>'LINEAOC'
,p_display_order=>450
,p_column_identifier=>'CM'
,p_column_label=>'Lineal OC'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(83708160261050432)
,p_db_column_name=>'CODIGOPRODUCTOCORTO'
,p_display_order=>460
,p_column_identifier=>'CT'
,p_column_label=>unistr('C\00F3digo producto corto')
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(83708340723050434)
,p_db_column_name=>'CANTIDADPRODUCTOORDEN'
,p_display_order=>470
,p_column_identifier=>'CV'
,p_column_label=>'Cantidad producto orden'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(83708446135050435)
,p_db_column_name=>'CANTIDADPRODUCTOKARDEX'
,p_display_order=>480
,p_column_identifier=>'CW'
,p_column_label=>'Cantidad producto kardex'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(83708511527050436)
,p_db_column_name=>'COSTOUNITARIOORDEN'
,p_display_order=>490
,p_column_identifier=>'CX'
,p_column_label=>'Costo unitario orden'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G990D00'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(83708684221050437)
,p_db_column_name=>'COSTOUNITARIOKARDEX'
,p_display_order=>500
,p_column_identifier=>'CY'
,p_column_label=>'Costo unitario kardex'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G990D00'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(83708770172050438)
,p_db_column_name=>'VALORPAGADOORDEN'
,p_display_order=>510
,p_column_identifier=>'CZ'
,p_column_label=>'Valor pagado orden'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G990D00'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(83708804832050439)
,p_db_column_name=>'VALORACUERDOORDEN'
,p_display_order=>520
,p_column_identifier=>'DA'
,p_column_label=>'Valor acuerdo orden'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G990D00'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(83708934183050440)
,p_db_column_name=>'VALORPAGADOKARDEX'
,p_display_order=>530
,p_column_identifier=>'DB'
,p_column_label=>'Valor pagado kardex'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G990D00'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(83709074968050441)
,p_db_column_name=>'VARIACIONORDEN'
,p_display_order=>540
,p_column_identifier=>'DC'
,p_column_label=>unistr('Variaci\00F3n orden')
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G990D00'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(83709105697050442)
,p_db_column_name=>'VALORASIENTOCONTABLE'
,p_display_order=>550
,p_column_identifier=>'DD'
,p_column_label=>'Valor asiento contable'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G990D00'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(83709299537050443)
,p_db_column_name=>'CODIGOPRODUCTOLARGO'
,p_display_order=>560
,p_column_identifier=>'DE'
,p_column_label=>unistr('C\00F3digo producto largo')
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(85398663797000801)
,p_db_column_name=>'NOMBREPROVEEDORASIENTO'
,p_display_order=>570
,p_column_identifier=>'DM'
,p_column_label=>'Nombre proveedor asiento'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(85398736312000802)
,p_db_column_name=>'TIPOIMPUESTO'
,p_display_order=>580
,p_column_identifier=>'DN'
,p_column_label=>'Tipo impuesto'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(85398849953000803)
,p_db_column_name=>'BODEGA'
,p_display_order=>590
,p_column_identifier=>'DO'
,p_column_label=>'Bodega'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(85398923349000804)
,p_db_column_name=>'NOMBREIMPUESTO'
,p_display_order=>600
,p_column_identifier=>'DP'
,p_column_label=>'Nombre impuesto'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(85399004801000805)
,p_db_column_name=>'VALORIMPUESTO'
,p_display_order=>610
,p_column_identifier=>'DQ'
,p_column_label=>'Valor impuesto'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(85399145957000806)
,p_db_column_name=>'FACTORIMPUESTO'
,p_display_order=>620
,p_column_identifier=>'DR'
,p_column_label=>'Factor impuesto'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(85399299035000807)
,p_db_column_name=>'APLICAIMPUESTO'
,p_display_order=>630
,p_column_identifier=>'DS'
,p_column_label=>'Aplica impuesto'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(85399340034000808)
,p_db_column_name=>'BASEIMPONIBLE0'
,p_display_order=>640
,p_column_identifier=>'DT'
,p_column_label=>'Base imponible0'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G990D00'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(85399431088000809)
,p_db_column_name=>'BASEIMPONIBLE12'
,p_display_order=>650
,p_column_identifier=>'DU'
,p_column_label=>'Base imponible12'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G990D00'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(85399520580000810)
,p_db_column_name=>'IVA'
,p_display_order=>660
,p_column_identifier=>'DV'
,p_column_label=>'IVA'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G990D00'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(85399648310000811)
,p_db_column_name=>'TOTALBASEIMPONIBLE'
,p_display_order=>670
,p_column_identifier=>'DW'
,p_column_label=>'Total base imponible'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G990D00'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(85399712756000812)
,p_db_column_name=>'TOTAL'
,p_display_order=>680
,p_column_identifier=>'DX'
,p_column_label=>'Total'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G990D00'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(83871272619052432)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'838713'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'CASILLERO:TIPOPRODUCTO:CATEGORIA:OC:TIPOOC:CODIGOPROVEEDOR:NOMBREPROVEEDOR:PROVEEDORJE:TIPODOCUMENTO:RUC:CUENTACONTABLE:NUMEROORDENCONTABLE:BATHCONTABLE:NUMEROSECUENCIAL:FECHA:NOMBREPRODUCTO:CODIGOPRODUCTOCORTO:CODIGOPRODUCTOLARGO:CANTIDADPRODUCTOKAR'
||'DEX:CANTIDADPRODUCTOORDEN:COSTOUNITARIOKARDEX:COSTOUNITARIOORDEN:VALORPAGADOKARDEX:VALORPAGADOORDEN:VALORACUERDOORDEN:VALORASIENTOCONTABLE:VARIACIONORDEN:MONEDA:UNIDADMEDIDA:CODIGOCOMPANIA:LINEAOC:NOMBREPROVEEDORASIENTO:TIPOIMPUESTO:BODEGA:NOMBREIMPU'
||'ESTO:VALORIMPUESTO:FACTORIMPUESTO:APLICAIMPUESTO:BASEIMPONIBLE0:BASEIMPONIBLE12:IVA:TOTALBASEIMPONIBLE:TOTAL:TXT03:TXT05:TXT08:TXT17:TXT19:'
,p_sort_column_1=>'OC'
,p_sort_direction_1=>'DESC'
,p_sort_column_2=>'TIPODOCUMENTO'
,p_sort_direction_2=>'DESC'
,p_sort_column_3=>'CODIGOPRODUCTOCORTO'
,p_sort_direction_3=>'ASC'
,p_sort_column_4=>'CODIGOPROVEEDOR'
,p_sort_direction_4=>'ASC'
,p_sort_column_5=>'0'
,p_sort_direction_5=>'ASC'
,p_sort_column_6=>'0'
,p_sort_direction_6=>'ASC'
,p_created_on=>wwv_flow_imp.dz('20230705164635Z')
,p_updated_on=>wwv_flow_imp.dz('20230705164635Z')
,p_created_by=>'CVACA'
,p_updated_by=>'CVACA'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(151011485743119702)
,p_plug_name=>unistr('Reporte de Adquisici\00F3n de Bienes Inventariables')
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(38290610465120145)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_menu_id=>wwv_flow_imp.id(37761271469106475)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(37860983999106559)
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(83285299419518206)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(83285147971518205)
,p_button_name=>'BUSCAR'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860056812106557)
,p_button_image_alt=>'Buscar'
,p_button_alignment=>'RIGHT'
,p_icon_css_classes=>'fa-search'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(74218239535695602)
,p_name=>'P2008_DESDE'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(74218114479695601)
,p_item_default=>'trunc(add_months(sysdate,-1),''month'')'
,p_item_default_type=>'EXPRESSION'
,p_item_default_language=>'PLSQL'
,p_prompt=>'Desde'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(74218378393695603)
,p_name=>'P2008_HASTA'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(74218114479695601)
,p_item_default=>'sysdate'
,p_item_default_type=>'EXPRESSION'
,p_item_default_language=>'PLSQL'
,p_prompt=>'Hasta'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(74220079301695620)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'CARGAR_DATOS'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
'   pk_finanzas.sp_reporteadquisicionbienes(:P2008_DESDE,:p2008_hasta);		',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(83285299419518206)
,p_internal_uid=>74220079301695620
);
wwv_flow_imp.component_end;
end;
/
