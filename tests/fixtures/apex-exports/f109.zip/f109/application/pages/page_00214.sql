prompt --application/pages/page_00214
begin
--   Manifest
--     PAGE: 00214
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>109
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_page.create_page(
 p_id=>214
,p_name=>'Reporte Estado de Cuenta Cargado'
,p_step_title=>'Reporte Estado de Cuenta Cargado'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_page_component_map=>'03'
,p_created_on=>wwv_flow_imp.dz('20230705164635Z')
,p_last_updated_on=>wwv_flow_imp.dz('20211213220527Z')
,p_last_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(989711677494234595)
,p_plug_name=>'Filtros'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(38289867500120143)
,p_plug_display_sequence=>10
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(989715208800234631)
,p_plug_name=>'Selector de Reporte'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(38289867500120143)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_source_type=>'NATIVE_DISPLAY_SELECTOR'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'display_region_icons', 'N',
  'include_show_all', 'N',
  'rds_mode', 'STANDARD',
  'remember_selection', 'SESSION')).to_clob
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(976221901013110326)
,p_name=>'Estado de Cuenta '
,p_parent_plug_id=>wwv_flow_imp.id(989715208800234631)
,p_template=>wwv_flow_imp.id(38289867500120143)
,p_display_sequence=>40
,p_include_in_reg_disp_sel_yn=>'Y'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_display_point=>'SUB_REGIONS'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select to_date(MPDGJ + 1900000,''yyyyddd'') FECDOC, trim(GMDL01) nombrebanco, MPCKNU referenciabancaria, MPAA/100 monto, trim(MPEXR) || '' | '' || TRIM(mpdl01) explicacion ,',
'MPEDLN/1000 Linea, MPEDUS UsuarioCarga, MPEV02, MPEV01, MPEDBT Batch,',
' TRIM(mpdl02) lugar',
'from F5509505@JDEDTADL a, f0901@JDEDTADL b',
'WHERE a.MPAID = b.GMAID',
'and  ((TRIM(a.MPCKNU) = :P214_REFERENCIA) OR (:P214_REFERENCIA IS NULL))',
'and ((trim(a.MPAID) = :P214_BANCO) or (:P214_BANCO IS NULL))',
'and ((:P214_TIPO = 0 AND MPAA > 0) or (:P214_TIPO = 1 AND MPAA < 0) OR (:P214_TIPO IS NULL))',
'and ((MPDGJ BETWEEN TO_CHAR(TO_DATE(:P214_F_DESDE,''DD/MM/YYYY'') ,''YYYYDDD'') - 1900000 AND TO_CHAR(TO_DATE(:P214_F_HASTA,''DD/MM/YYYY'') ,''YYYYDDD'') - 1900000) or (:P214_F_HASTA is null and :P214_F_DESDE is null))',
'--order by MPEDLN, MPDGJ, GMDL01, MPCKNU'))
,p_ajax_enabled=>'Y'
,p_ajax_items_to_submit=>'P214_F_DESDE,P214_F_HASTA,P214_REFERENCIA,P214_BANCO'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(37830327650106535)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_show_nulls_as=>'-'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'Y'
,p_csv_output_link_text=>'Download'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(496165645318092960)
,p_query_column_id=>1
,p_column_alias=>'FECDOC'
,p_column_display_sequence=>1
,p_column_heading=>'Fec Doc'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(496166079971092962)
,p_query_column_id=>2
,p_column_alias=>'NOMBREBANCO'
,p_column_display_sequence=>2
,p_column_heading=>'Banco'
,p_use_as_row_header=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(496166482313092964)
,p_query_column_id=>3
,p_column_alias=>'REFERENCIABANCARIA'
,p_column_display_sequence=>3
,p_column_heading=>'Referencia Bancaria'
,p_use_as_row_header=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(496166812335092964)
,p_query_column_id=>4
,p_column_alias=>'MONTO'
,p_column_display_sequence=>4
,p_column_heading=>'Monto'
,p_use_as_row_header=>'N'
,p_column_format=>'FML999G999G999G999G990D00'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(496167276618092964)
,p_query_column_id=>5
,p_column_alias=>'EXPLICACION'
,p_column_display_sequence=>5
,p_column_heading=>unistr('Explicaci\00F3n')
,p_use_as_row_header=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(494471450271158814)
,p_query_column_id=>6
,p_column_alias=>'LINEA'
,p_column_display_sequence=>6
,p_column_heading=>'Linea'
,p_use_as_row_header=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(494471551728158815)
,p_query_column_id=>7
,p_column_alias=>'USUARIOCARGA'
,p_column_display_sequence=>7
,p_column_heading=>'Usuariocarga'
,p_use_as_row_header=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(494471622078158816)
,p_query_column_id=>8
,p_column_alias=>'MPEV02'
,p_column_display_sequence=>8
,p_column_heading=>'Mpev02'
,p_use_as_row_header=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(494471705079158817)
,p_query_column_id=>9
,p_column_alias=>'MPEV01'
,p_column_display_sequence=>9
,p_column_heading=>'Mpev01'
,p_use_as_row_header=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(170407833563675548)
,p_query_column_id=>10
,p_column_alias=>'BATCH'
,p_column_display_sequence=>10
,p_column_heading=>'Batch'
,p_use_as_row_header=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(40375126570094939)
,p_query_column_id=>11
,p_column_alias=>'LUGAR'
,p_column_display_sequence=>11
,p_column_heading=>'Lugar'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1470179797382523558)
,p_plug_name=>'Reportes Estado de Cuenta Cargado'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(37817215439106526)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(37761271469106475)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(37860983999106559)
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(4240089131194365878)
,p_plug_name=>'Barra de acciones'
,p_region_template_options=>'#DEFAULT#:t-Form--stretchInputs'
,p_plug_template=>wwv_flow_imp.id(38289497777120142)
,p_plug_display_sequence=>20
,p_plug_display_point=>'REGION_POSITION_01'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(496156150299092917)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(4240089131194365878)
,p_button_name=>'BTN_BUSCAR'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860056812106557)
,p_button_image_alt=>'Buscar'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_icon_css_classes=>'fa-search'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(494471807400158818)
,p_name=>'P214_TIPO'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(989711677494234595)
,p_prompt=>'Tipo: '
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'STATIC:CREDITO;0,DEBITO;1'
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_colspan=>7
,p_grid_column=>1
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(496153608125092823)
,p_name=>'P214_F_DESDE'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(989711677494234595)
,p_item_default=>'LAST_DAY(add_months(sysdate, -1)) +1'
,p_item_default_type=>'EXPRESSION'
,p_item_default_language=>'PLSQL'
,p_prompt=>unistr('Fecha Dep\00F3sito Desde: ')
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_colspan=>5
,p_grid_column=>1
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(496153909886092912)
,p_name=>'P214_F_HASTA'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(989711677494234595)
,p_item_default=>'LAST_DAY(sysdate) '
,p_item_default_type=>'EXPRESSION'
,p_item_default_language=>'PLSQL'
,p_prompt=>unistr('Fecha Dep\00F3sito Hasta: ')
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_colspan=>6
,p_grid_column=>7
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(496154356381092912)
,p_name=>'P214_REFERENCIA'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(989711677494234595)
,p_prompt=>unistr('Referencia Dep\00F3sito:')
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_colspan=>7
,p_grid_column=>1
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(496199029520133285)
,p_name=>'P214_BANCO'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(989711677494234595)
,p_prompt=>'Seleccione Banco:'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select trim(ayaid) || '' - '' || trim(upper(aydl01)) d, trim(ayaid) r from f0030@jdedtadl where trim(aycbnk) is not null and trim(aydl01) is not null',
'/*SELECT VALOR ||'' - ''||DESCRIPCION NOMBREBANCO, VALOR CUENTAIDBANCO',
'FROM DATA.T_CORP_UDC WHERE ID_CABECERA = ''COBROBANCO'' AND VALOR2 IN (''N'',''V'',''E'')',
'--N->NACIONAL',
'--V->NACIONAL Y EXTERIOR',
'--E->EXTERIOR',
'AND ACTIVO = ''1''',
'ORDER BY ID_TABLA;',
'*/',
'',
''))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_tag_attributes=>'style="max-width:250px;"'
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'NONE'
);
wwv_flow_imp.component_end;
end;
/
