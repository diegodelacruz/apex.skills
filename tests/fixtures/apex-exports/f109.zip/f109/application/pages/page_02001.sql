prompt --application/pages/page_02001
begin
--   Manifest
--     PAGE: 02001
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>109
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_page.create_page(
 p_id=>2001
,p_name=>unistr('Revisi\00F3n de Requisiciones')
,p_step_title=>unistr('Revisi\00F3n de Requisiciones')
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_page_component_map=>'18'
,p_created_on=>wwv_flow_imp.dz('20230705164635Z')
,p_last_updated_on=>wwv_flow_imp.dz('20201014050000Z')
,p_last_updated_by=>'MCOELLO'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(343692932555323770)
,p_plug_name=>unistr('Revisi\00F3n de Requisiciones')
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(37817215439106526)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(37761271469106475)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(37860983999106559)
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(343693554200323771)
,p_plug_name=>unistr('Revisi\00F3n de Requisiciones')
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(37806762584106520)
,p_plug_display_sequence=>20
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select flag',
', control01',
', control02',
', txt01',
', txt02',
', fecha01',
', txt03',
', num01',
', txt04',
', txt05',
', num02',
', txt06',
', txt07',
', txt08',
', num03',
', num04',
', num05',
', num06',
', txt09',
', txt10',
', txt11',
', txt12',
', txt13',
', txt14',
', txt15',
', txt16',
', txt17',
', txt18',
', txt19',
', txt20',
', txt21',
', txt22',
', txt23',
', txt24',
', txt25',
'from t_apex_temporal where flag = :app_modulo and control01 = ''pk_finanzas.sp_revisionrequisiciones'' and control02 = :app_user;'))
,p_plug_source_type=>'NATIVE_IR'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(343693628112323771)
,p_name=>unistr('Revisi\00F3n de Requisiciones')
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_download_formats=>'CSV:XLSX:PDF'
,p_enable_mail_download=>'N'
,p_owner=>'DDELACRUZ'
,p_internal_uid=>343693628112323771
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(344517675485036202)
,p_db_column_name=>'FLAG'
,p_display_order=>10
,p_column_identifier=>'AH'
,p_column_label=>'Flag'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(344517709802036203)
,p_db_column_name=>'CONTROL01'
,p_display_order=>20
,p_column_identifier=>'AI'
,p_column_label=>'Control01'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(344517883790036204)
,p_db_column_name=>'CONTROL02'
,p_display_order=>30
,p_column_identifier=>'AJ'
,p_column_label=>'Control02'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(344517907932036205)
,p_db_column_name=>'TXT01'
,p_display_order=>40
,p_column_identifier=>'AK'
,p_column_label=>'Txt01'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(344518022255036206)
,p_db_column_name=>'TXT02'
,p_display_order=>50
,p_column_identifier=>'AL'
,p_column_label=>'Txt02'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(344518162418036207)
,p_db_column_name=>'FECHA01'
,p_display_order=>60
,p_column_identifier=>'AM'
,p_column_label=>'Fecha01'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(344518282879036208)
,p_db_column_name=>'TXT03'
,p_display_order=>70
,p_column_identifier=>'AN'
,p_column_label=>'Txt03'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(344518353311036209)
,p_db_column_name=>'NUM01'
,p_display_order=>80
,p_column_identifier=>'AO'
,p_column_label=>'Num01'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(344518477101036210)
,p_db_column_name=>'TXT04'
,p_display_order=>90
,p_column_identifier=>'AP'
,p_column_label=>'Txt04'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(344518561401036211)
,p_db_column_name=>'TXT05'
,p_display_order=>100
,p_column_identifier=>'AQ'
,p_column_label=>'Txt05'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(344518690114036212)
,p_db_column_name=>'NUM02'
,p_display_order=>110
,p_column_identifier=>'AR'
,p_column_label=>'Num02'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(344518733046036213)
,p_db_column_name=>'TXT06'
,p_display_order=>120
,p_column_identifier=>'AS'
,p_column_label=>'Txt06'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(344518854161036214)
,p_db_column_name=>'TXT07'
,p_display_order=>130
,p_column_identifier=>'AT'
,p_column_label=>'Txt07'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(344518933501036215)
,p_db_column_name=>'TXT08'
,p_display_order=>140
,p_column_identifier=>'AU'
,p_column_label=>'Txt08'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(344519078920036216)
,p_db_column_name=>'NUM03'
,p_display_order=>150
,p_column_identifier=>'AV'
,p_column_label=>'Num03'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(344519147449036217)
,p_db_column_name=>'NUM04'
,p_display_order=>160
,p_column_identifier=>'AW'
,p_column_label=>'Num04'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(344519295442036218)
,p_db_column_name=>'NUM05'
,p_display_order=>170
,p_column_identifier=>'AX'
,p_column_label=>'Num05'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(344519329762036219)
,p_db_column_name=>'NUM06'
,p_display_order=>180
,p_column_identifier=>'AY'
,p_column_label=>'Num06'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(344519438824036220)
,p_db_column_name=>'TXT09'
,p_display_order=>190
,p_column_identifier=>'AZ'
,p_column_label=>'Txt09'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(344519506328036221)
,p_db_column_name=>'TXT10'
,p_display_order=>200
,p_column_identifier=>'BA'
,p_column_label=>'Txt10'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(344519665393036222)
,p_db_column_name=>'TXT11'
,p_display_order=>210
,p_column_identifier=>'BB'
,p_column_label=>'Txt11'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(344519755847036223)
,p_db_column_name=>'TXT12'
,p_display_order=>220
,p_column_identifier=>'BC'
,p_column_label=>'Txt12'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(344519810717036224)
,p_db_column_name=>'TXT13'
,p_display_order=>230
,p_column_identifier=>'BD'
,p_column_label=>'Txt13'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(344519934202036225)
,p_db_column_name=>'TXT14'
,p_display_order=>240
,p_column_identifier=>'BE'
,p_column_label=>'Txt14'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(344520042979036226)
,p_db_column_name=>'TXT15'
,p_display_order=>250
,p_column_identifier=>'BF'
,p_column_label=>'Txt15'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(344520171936036227)
,p_db_column_name=>'TXT16'
,p_display_order=>260
,p_column_identifier=>'BG'
,p_column_label=>'Txt16'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(344520249730036228)
,p_db_column_name=>'TXT17'
,p_display_order=>270
,p_column_identifier=>'BH'
,p_column_label=>'Txt17'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(344520338336036229)
,p_db_column_name=>'TXT18'
,p_display_order=>280
,p_column_identifier=>'BI'
,p_column_label=>'Txt18'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(344520489956036230)
,p_db_column_name=>'TXT19'
,p_display_order=>290
,p_column_identifier=>'BJ'
,p_column_label=>'Txt19'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(344520500326036231)
,p_db_column_name=>'TXT20'
,p_display_order=>300
,p_column_identifier=>'BK'
,p_column_label=>'Txt20'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(344520652950036232)
,p_db_column_name=>'TXT21'
,p_display_order=>310
,p_column_identifier=>'BL'
,p_column_label=>'Txt21'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(344520747838036233)
,p_db_column_name=>'TXT22'
,p_display_order=>320
,p_column_identifier=>'BM'
,p_column_label=>'Txt22'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(344520846765036234)
,p_db_column_name=>'TXT23'
,p_display_order=>330
,p_column_identifier=>'BN'
,p_column_label=>'Txt23'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(344520915505036235)
,p_db_column_name=>'TXT24'
,p_display_order=>340
,p_column_identifier=>'BO'
,p_column_label=>'Txt24'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(344521096545036236)
,p_db_column_name=>'TXT25'
,p_display_order=>350
,p_column_identifier=>'BP'
,p_column_label=>'Txt25'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(343712893028331282)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'3437129'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'FLAG:CONTROL01:CONTROL02:TXT01:TXT02:FECHA01:TXT03:NUM01:TXT04:TXT05:NUM02:TXT06:TXT07:TXT08:NUM03:NUM04:NUM05:NUM06:TXT09:TXT10:TXT11:TXT12:TXT13:TXT14:TXT15:TXT16:TXT17:TXT18:TXT19:TXT20:TXT21:TXT22:TXT23:TXT24:TXT25'
,p_created_on=>wwv_flow_imp.dz('20230705164635Z')
,p_updated_on=>wwv_flow_imp.dz('20230705164635Z')
,p_created_by=>'CVACA'
,p_updated_by=>'CVACA'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(343706815430325601)
,p_plug_name=>unistr('Par\00E1metros')
,p_plug_display_sequence=>10
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(343707318533325606)
,p_plug_name=>'Barra de Acciones'
,p_region_template_options=>'#DEFAULT#:t-Form--stretchInputs'
,p_plug_template=>wwv_flow_imp.id(38289497777120142)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'REGION_POSITION_01'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(343707422127325607)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(343707318533325606)
,p_button_name=>'BUSCAR'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860056812106557)
,p_button_image_alt=>'Buscar'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_icon_css_classes=>'fa-search'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(343707060210325603)
,p_name=>'P2001_DESDE'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(343706815430325601)
,p_prompt=>'Desde'
,p_format_mask=>'dd/mm/yyyy'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859675292106557)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(343707137136325604)
,p_name=>'P2001_HASTA'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(343706815430325601)
,p_prompt=>'Hasta'
,p_format_mask=>'dd/mm/yyyy'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(37859675292106557)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(344517516541036201)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'GENERAREPORTE'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'    pk_finanzas.sp_revisionrequisiciones(:g_compania,:app_user,:p2001_desde,:p2001_hasta);',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(343707422127325607)
,p_process_success_message=>'Datos Generados'
,p_internal_uid=>344517516541036201
);
wwv_flow_imp.component_end;
end;
/
