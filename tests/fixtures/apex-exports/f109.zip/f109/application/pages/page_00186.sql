prompt --application/pages/page_00186
begin
--   Manifest
--     PAGE: 00186
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>109
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_page.create_page(
 p_id=>186
,p_name=>'GESTION TRIBUTARIA - PARAMETRIZACION PARAMETROS'
,p_alias=>'GESTION-TRIBUTARIA-PARAMETRIZACION-PARAMETROS'
,p_page_mode=>'MODAL'
,p_step_title=>unistr('Confoguraci\00F3n de Parametros')
,p_autocomplete_on_off=>'OFF'
,p_javascript_code_onload=>'$(secItems).hide();'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'21'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(543458109507406610)
,p_plug_name=>'BOTONES'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(38290276266120143)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'REGION_POSITION_03'
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1086665861428727973)
,p_plug_name=>'items'
,p_region_name=>'secItems'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(38289867500120143)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1086773920788780963)
,p_plug_name=>'GESTION TRIBUTARIA - PARAMETROS 2.0'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(37806762584106520)
,p_plug_display_sequence=>20
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
unistr('    SEQ_ID,  -- ID \00FAnico de la colecci\00F3n'),
'    C001,',
'    C002,',
'    C003',
'FROM APEX_COLLECTIONS ',
'WHERE COLLECTION_NAME = ''COLECCION_PARAMETROS'''))
,p_plug_source_type=>'NATIVE_IG'
,p_plug_read_only_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_plug_read_only_when=>'P186_READONLY'
,p_plug_read_only_when2=>'1'
,p_prn_page_header=>'GESTION TRIBUTARIA - PARAMETROS 2.0'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(1086665602441727970)
,p_name=>'APEX$ROW_ACTION'
,p_session_state_data_type=>'VARCHAR2'
,p_item_type=>'NATIVE_ROW_ACTION'
,p_display_sequence=>20
,p_use_as_row_header=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(1086665680365727971)
,p_name=>'APEX$ROW_SELECTOR'
,p_session_state_data_type=>'VARCHAR2'
,p_item_type=>'NATIVE_ROW_SELECTOR'
,p_display_sequence=>10
,p_attribute_01=>'Y'
,p_attribute_02=>'Y'
,p_attribute_03=>'N'
,p_use_as_row_header=>false
,p_display_condition_type=>'VAL_OF_ITEM_IN_COND_NOT_EQ_COND2'
,p_display_condition=>'P186_READONLY'
,p_display_condition2=>'1'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(1086666441828727979)
,p_name=>'C001'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'C001'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>unistr('Par\00E1metro')
,p_heading_alignment=>'CENTER'
,p_display_sequence=>40
,p_value_alignment=>'CENTER'
,p_attribute_05=>'BOTH'
,p_is_required=>false
,p_max_length=>4000
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(1086666573112727980)
,p_name=>'C003'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'C003'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>'Valor 2'
,p_heading_alignment=>'CENTER'
,p_display_sequence=>60
,p_value_alignment=>'CENTER'
,p_attribute_05=>'BOTH'
,p_is_required=>false
,p_max_length=>4000
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(1086666744023727982)
,p_name=>'C002'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'C002'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>'Valor 1'
,p_heading_alignment=>'CENTER'
,p_display_sequence=>50
,p_value_alignment=>'CENTER'
,p_attribute_05=>'BOTH'
,p_is_required=>false
,p_max_length=>4000
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(1086775154678780967)
,p_name=>'SEQ_ID'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'SEQ_ID'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_DISPLAY_ONLY'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>30
,p_value_alignment=>'LEFT'
,p_attribute_02=>'VALUE'
,p_attribute_05=>'PLAIN'
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_enable_hide=>true
,p_enable_pivot=>false
,p_is_primary_key=>true
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_interactive_grid(
 p_id=>wwv_flow_imp.id(1086774405994780964)
,p_internal_uid=>1086774405994780964
,p_is_editable=>true
,p_edit_operations=>'i:u:d'
,p_lost_update_check_type=>'VALUES'
,p_add_row_if_empty=>false
,p_submit_checked_rows=>false
,p_lazy_loading=>false
,p_requires_filter=>false
,p_select_first_row=>true
,p_fixed_row_height=>true
,p_pagination_type=>'SCROLL'
,p_show_total_row_count=>true
,p_show_toolbar=>true
,p_toolbar_buttons=>'SEARCH_COLUMN:SEARCH_FIELD:ACTIONS_MENU:SAVE'
,p_enable_save_public_report=>false
,p_enable_subscriptions=>true
,p_enable_flashback=>false
,p_define_chart_view=>false
,p_enable_download=>false
,p_download_formats=>null
,p_enable_mail_download=>true
,p_fixed_header=>'REGION'
,p_fixed_header_max_height=>300
,p_show_icon_view=>false
,p_show_detail_view=>false
,p_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'function (config) {',
'	return cargarToolbar(config);',
'}'))
);
wwv_flow_imp_page.create_ig_report(
 p_id=>wwv_flow_imp.id(1086774745654780965)
,p_interactive_grid_id=>wwv_flow_imp.id(1086774405994780964)
,p_static_id=>'5433428'
,p_type=>'PRIMARY'
,p_default_view=>'GRID'
,p_show_row_number=>false
,p_settings_area_expanded=>true
);
wwv_flow_imp_page.create_ig_report_view(
 p_id=>wwv_flow_imp.id(1086775021685780965)
,p_report_id=>wwv_flow_imp.id(1086774745654780965)
,p_view_type=>'GRID'
,p_stretch_columns=>true
,p_srv_exclude_null_values=>false
,p_srv_only_display_columns=>true
,p_edit_mode=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(1086775535793780968)
,p_view_id=>wwv_flow_imp.id(1086775021685780965)
,p_display_seq=>2
,p_column_id=>wwv_flow_imp.id(1086775154678780967)
,p_is_visible=>false
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(1086780139808784295)
,p_view_id=>wwv_flow_imp.id(1086775021685780965)
,p_display_seq=>1
,p_column_id=>wwv_flow_imp.id(1086665602441727970)
,p_is_visible=>false
,p_is_frozen=>true
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(1086829172063900142)
,p_view_id=>wwv_flow_imp.id(1086775021685780965)
,p_display_seq=>3
,p_column_id=>wwv_flow_imp.id(1086666441828727979)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(1086830098244900149)
,p_view_id=>wwv_flow_imp.id(1086775021685780965)
,p_display_seq=>5
,p_column_id=>wwv_flow_imp.id(1086666573112727980)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(1086835033838907607)
,p_view_id=>wwv_flow_imp.id(1086775021685780965)
,p_display_seq=>4
,p_column_id=>wwv_flow_imp.id(1086666744023727982)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(543458251642406611)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(543458109507406610)
,p_button_name=>'Cerrar'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860181880106559)
,p_button_image_alt=>'Cerrar'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(543439552768682795)
,p_branch_action=>'186'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'BRANCH_TO_STEP'
,p_branch_sequence=>10
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(545176967654787441)
,p_name=>'P186_READONLY'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(1086665861428727973)
,p_prompt=>'Readonly'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(543438009014682792)
,p_name=>'Actualiza Grid'
,p_event_sequence=>10
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(1086773920788780963)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'NATIVE_IG|REGION TYPE|interactivegridsave'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(543439002872682794)
,p_event_id=>wwv_flow_imp.id(543438009014682792)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    v_datos VARCHAR2(4000);',
'BEGIN',
'    v_datos := '''';',
'    execute immediate ''',
'       SELECT ',
'          JSON_ARRAYAGG(JSON_OBJECT(*) RETURNING CLOB)',
'           FROM (',
'               SELECT seq_id ID',
'                    ,C001 PARAMETRO',
'                    ,C002 VALOR1',
'                    ,C003 VALOR2',
'                FROM APEX_COLLECTIONS WHERE COLLECTION_NAME = ''''COLECCION_PARAMETROS'''' ORDER BY seq_id',
'           )',
'    '' into v_datos;',
'',
'    :G_GT_PARAMETROS:=upper(v_datos);',
'END;'))
,p_attribute_03=>'G_GT_PARAMETROS'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(543438531376682794)
,p_event_id=>wwv_flow_imp.id(543438009014682792)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(1086773920788780963)
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(543437644145682792)
,p_process_sequence=>10
,p_process_point=>'AFTER_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'SetupPage'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'IF APEX_COLLECTION.COLLECTION_EXISTS(''COLECCION_PARAMETROS'') THEN',
' APEX_COLLECTION.TRUNCATE_COLLECTION(''COLECCION_PARAMETROS'');',
'END IF;',
'IF(:G_GT_PARAMETROS IS NOT NULL)THEN',
'',
'    FOR COLS IN (',
'        SELECT  PARAMETRO CAMPO1,VALOR1 CAMPO2,VALOR2  CAMPO3  ',
'            FROM JSON_TABLE(',
'                :G_GT_PARAMETROS, -- tu variable o columna con el JSON',
'                ''$[*]'' -- indica que es un arreglo',
'                COLUMNS (',
'                      PARAMETRO VARCHAR2(3999) PATH ''$.PARAMETRO''',
'                    , VALOR1     VARCHAR2(399) PATH ''$.VALOR1''',
'                    , VALOR2     VARCHAR2(399) PATH ''$.VALOR2''',
'                )',
'            )',
'    )LOOP',
'        APEX_COLLECTION.ADD_MEMBER(',
'            p_collection_name => ''COLECCION_PARAMETROS'',',
'            p_c001 => COLS.CAMPO1,',
'            p_c002 => COLS.CAMPO2,',
'            p_c003 => COLS.CAMPO3',
'        );',
'    END LOOP;',
'END IF;',
'',
'',
'    ',
'',
''))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>543437644145682792
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(543435797180682786)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_region_id=>wwv_flow_imp.id(1086773920788780963)
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'GESTION TRIBUTARIA - PARAMETROS 2.0 - Save Interactive Grid Data'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare ',
'    v_NOMBRE varchar2(3999);',
'    v_VALOR1 varchar2(3999);',
'    v_VALOR2 varchar2(3999);',
'     ',
'    v_cont  number;',
' ',
'BEGIN',
'    v_NOMBRE :=upper(:c001);',
'    v_VALOR1 :=upper(:c002);',
'    v_VALOR2 :=upper(:c003);',
'     v_NOMBRE := REGEXP_REPLACE(upper(v_NOMBRE), ''[^A-Za-z0-9]+'', ''_'');',
'',
'    case :APEX$ROW_STATUS  ',
'     WHEN ''C''THEN',
'            APEX_COLLECTION.ADD_MEMBER(p_collection_name => ''COLECCION_PARAMETROS'',p_c001=> v_NOMBRE,p_c002=> v_VALOR1,p_c003=> v_VALOR2);',
'     WHEN ''U'' THEN',
'        APEX_COLLECTION.UPDATE_MEMBER(p_collection_name => ''COLECCION_PARAMETROS'',p_seq => :seq_id,p_c001=> v_NOMBRE,p_c002=> v_VALOR1,p_c003=> v_VALOR2);',
'    WHEN ''D'' THEN',
'        APEX_COLLECTION.DELETE_MEMBER(p_collection_name => ''COLECCION_PARAMETROS'',p_seq => :seq_id);',
'    END CASE;',
' ',
'EXCEPTION WHEN OTHERS THEN ',
'    apex_error.add_error (',
'    p_message          => ''ERROR::''||:APEX$ROW_STATUS||'' ''||SQLERRM  ,',
'    p_display_location =>apex_error.c_inline_in_notification );',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>543435797180682786
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(543458300501406612)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_CLOSE_WINDOW'
,p_process_name=>'Close Dialog '
,p_attribute_01=>'G_GT_CONDICIONES,G_GT_PARAMETROS'
,p_attribute_02=>'N'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>543458300501406612
);
wwv_flow_imp.component_end;
end;
/
