prompt --application/pages/page_02015
begin
--   Manifest
--     PAGE: 02015
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>109
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_page.create_page(
 p_id=>2015
,p_name=>'DOCUMENTOS ELECTRONICOS - PAG - Resumen Autoconsumos'
,p_alias=>'RESUMEN-AUTOCONSUMOS'
,p_step_title=>'Resumen Autoconsumos'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_page_component_map=>'18'
,p_created_on=>wwv_flow_imp.dz('20240520133704Z')
,p_last_updated_on=>wwv_flow_imp.dz('20240515213056Z')
,p_last_updated_by=>'EMASABANDA'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(197068581195512423)
,p_plug_name=>'Barra de Acciones'
,p_region_template_options=>'#DEFAULT#:t-Form--stretchInputs'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(38289497777120142)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(37761271469106475)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(37860983999106559)
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(197068627803512424)
,p_plug_name=>'Detalle'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(37806762584106520)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'WITH W42119 AS',
'(',
'    select   sddoco,sddcto,sdlnid,sdzon,sdpoe,sdpran8,sdostp',
'            ,sdlitm,sditm,sdaexp/100 sdaexp,sdshan,sddgl,sdtax1',
'            ,trim(sddct)||''-001001''||lpad(sddoc,9,0)documento    ',
'    from f42119@jdedtadl---Tabla de Ventas Contabilizadas',
'    where 1=1',
'        AND :P2015_BANDERA=1',
'        AND (sddcto = ''VA'' AND SDNXTR=SDNXTR AND SDLNTY=SDLNTY)',
'        AND (sddgl BETWEEN pk_commons.f_g2jde(''01/''||:P2015_MES||''/''||:P2015_ANIO) AND pk_commons.f_g2jde(last_day((''01/''||:P2015_MES||''/''||:P2015_ANIO))))',
') ',
'SELECT ',
'    sddoco,sddcto,sdlnid,abmcu,mlobj,mlsub,sdzon,sdpoe,sdpran8,sdostp,sdlitm,sditm, round((1+(tatxr2/100000))*sdaexp,2)*100 val, documento',
'FROM W42119 s',
'inner join f0101@jdedtadl a on sdshan = aban8---Libro de Direcciones, para obtener la UN del Destino',
'inner join f4101@jdedtadl i on sditm = imitm---Maestro de productos para obtener el tipo de inventario (GLPT)',
'inner join f4095@jdedtadl m on sddcto = mldct and imglpt = mlglpt ---Tabla de ICAs',
unistr('inner join f4008@jdedtadl on sdtax1 = taitm and sddgl between taeftj and taefdj--Impuesto, preguntar si se debe aplicar alguna condici\00F3n adicional'),
';'))
,p_plug_source_type=>'NATIVE_IR'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'Detalle'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(197068865096512426)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'EMASABANDA'
,p_internal_uid=>197068865096512426
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(197069981734512437)
,p_db_column_name=>'SDDOCO'
,p_display_order=>10
,p_column_identifier=>'K'
,p_column_label=>'Sddoco'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(197070078243512438)
,p_db_column_name=>'SDDCTO'
,p_display_order=>20
,p_column_identifier=>'L'
,p_column_label=>'Sddcto'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(197070150008512439)
,p_db_column_name=>'SDLNID'
,p_display_order=>30
,p_column_identifier=>'M'
,p_column_label=>'Sdlnid'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(197070251473512440)
,p_db_column_name=>'ABMCU'
,p_display_order=>40
,p_column_identifier=>'N'
,p_column_label=>'Und. Negocio'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(197070370430512441)
,p_db_column_name=>'MLOBJ'
,p_display_order=>50
,p_column_identifier=>'O'
,p_column_label=>'Cta. Objeto'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(197070447566512442)
,p_db_column_name=>'MLSUB'
,p_display_order=>60
,p_column_identifier=>'P'
,p_column_label=>'Aux.'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(197070566914512443)
,p_db_column_name=>'SDZON'
,p_display_order=>70
,p_column_identifier=>'Q'
,p_column_label=>'Marca'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(197070673554512444)
,p_db_column_name=>'SDPOE'
,p_display_order=>80
,p_column_identifier=>'R'
,p_column_label=>unistr('L\00EDn. Negocio')
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(197070729449512445)
,p_db_column_name=>'SDPRAN8'
,p_display_order=>90
,p_column_identifier=>'S'
,p_column_label=>'Cliente'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(197070818759512446)
,p_db_column_name=>'SDOSTP'
,p_display_order=>100
,p_column_identifier=>'T'
,p_column_label=>'Canal'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(197070979342512447)
,p_db_column_name=>'SDLITM'
,p_display_order=>110
,p_column_identifier=>'U'
,p_column_label=>'Sdlitm'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(197071002104512448)
,p_db_column_name=>'SDITM'
,p_display_order=>120
,p_column_identifier=>'V'
,p_column_label=>'Sditm'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(197071128714512449)
,p_db_column_name=>'VAL'
,p_display_order=>130
,p_column_identifier=>'W'
,p_column_label=>'Monto'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(197071291089512450)
,p_db_column_name=>'DOCUMENTO'
,p_display_order=>140
,p_column_identifier=>'X'
,p_column_label=>'Factura'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(198218577623101583)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'1982186'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'SDDOCO:SDDCTO:SDLNID:ABMCU:MLOBJ:MLSUB:SDZON:SDPOE:SDPRAN8:SDOSTP:SDLITM:SDITM:VAL:DOCUMENTO'
,p_created_on=>wwv_flow_imp.dz('20240520133704Z')
,p_updated_on=>wwv_flow_imp.dz('20240520133704Z')
,p_created_by=>'ATOPON'
,p_updated_by=>'ATOPON'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(198204178776087901)
,p_plug_name=>'Filtros'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(38289867500120143)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(197068757724512425)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(197068581195512423)
,p_button_name=>'Buscar'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860056812106557)
,p_button_image_alt=>'Buscar'
,p_button_alignment=>'RIGHT'
,p_icon_css_classes=>'fa-search'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(198204205504087902)
,p_name=>'P2015_ANIO'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(198204178776087901)
,p_prompt=>'Anio'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT year D, year R FROM (',
'select',
'to_char(sysdate, ''yyyy'') - (select trunc(months_between (sysdate, ADD_MONTHS(SYSDATE, (-12 * 4) ))/12)+1 anios  from dual) + level year',
'from',
'dual',
'connect by',
'level <= (select trunc(months_between (sysdate, ADD_MONTHS(SYSDATE, (-12 * 4) ) )/12)+1 anios  from dual)  ',
') A;'))
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(198204310755087903)
,p_name=>'P2015_MES'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(198204178776087901)
,p_prompt=>'Mes'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT',
'    to_char(to_date(level, ''MM''), ''Month'') d,',
'    level                                  r',
'FROM',
'    dual',
'CONNECT BY',
'    level <= (CASE  WHEN :P2014_ANIO = to_char(to_date(sysdate), ''YYYY'') THEN to_number(to_char(to_date(sysdate), ''MM'')) ELSE 12 END)',
''))
,p_lov_cascade_parent_items=>'P2015_ANIO'
,p_ajax_items_to_submit=>'P2015_ANIO'
,p_ajax_optimize_refresh=>'Y'
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(201722729821546818)
,p_name=>'P2015_BANDERA'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(198204178776087901)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(201722661431546817)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'New'
,p_process_sql_clob=>':P2015_BANDERA:=1;'
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>201722661431546817
);
wwv_flow_imp.component_end;
end;
/
