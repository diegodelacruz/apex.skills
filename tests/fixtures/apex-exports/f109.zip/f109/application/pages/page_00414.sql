prompt --application/pages/page_00414
begin
--   Manifest
--     PAGE: 00414
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>109
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_page.create_page(
 p_id=>414
,p_name=>'DOCUMENTOS ELECTRONICOS - DLG - CONFIGURACION FIRMA'
,p_alias=>'DOCUMENTOS-ELECTRONICOS-DLG-CONFIGURACION-FIRMA'
,p_page_mode=>'MODAL'
,p_step_title=>'DOCUMENTOS ELECTRONICOS - DLG - CONFIGURACION FIRMA'
,p_autocomplete_on_off=>'OFF'
,p_javascript_code_onload=>'$(secItems).hide();'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.apex-item-file {',
'    opacity: 1 !important;',
'    border: 1px solid #ccced1;',
'}'))
,p_step_template=>wwv_flow_imp.id(37774372912106498)
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'18'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(168143974519781730)
,p_plug_name=>'Detalle'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(38289867500120143)
,p_plug_display_sequence=>10
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(168144511390781736)
,p_plug_name=>'Items'
,p_region_name=>'secItems'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(38289867500120143)
,p_plug_display_sequence=>40
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(168145387701781744)
,p_plug_name=>'Archivos'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(37806762584106520)
,p_plug_display_sequence=>30
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'    select  ',
'        numeroarchivo ID, numeroarchivo , FILENAME, dbms_lob.getlength(BLOBCONTENT) BLOBCONTENT, MIMETYPE,to_char(FECHA,''DD/MM/YYYY'') FECHA,NOMBREUSUARIO USUARIO,',
unistr('        case TIPO  when ''ARCH_P12'' then ''Archivo p12 firma electr\00F3nica Ecuador''END TIPO, case to_number(estado) when 1 then ''Activo'' when 0 then ''Inactivo'' end estado'),
'        ,OBSERVACION CLAVE',
'        ,PK_COMMONS.F_DECRYPT(OBSERVACION) CLAVEDSC',
'    FROM  FILES.T_APEX_ARCHIVOS',
'    WHERE  TABLA=''FIRMA_ELECTRONICA''AND ID_TABLA = ''FINZ_DCFIR'' ',
'    order by estado , TO_DATE(fecha) desc'))
,p_plug_source_type=>'NATIVE_IR'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(168145408390781745)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'EMASABANDA'
,p_internal_uid=>168145408390781745
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(168145563421781746)
,p_db_column_name=>'ID'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Id'
,p_column_link=>'javascript:$s(''P414_NUMEROARCHIVO'',''''); $s(''P414_NUMEROARCHIVO'',''#NUMEROARCHIVO#'');'
,p_column_linktext=>'<span title="Eliminar" class="fa fa-trash"/>'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(168145676340781747)
,p_db_column_name=>'NUMEROARCHIVO'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Numero'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(168145777988781748)
,p_db_column_name=>'FILENAME'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Filename'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(168145891212781749)
,p_db_column_name=>'BLOBCONTENT'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Archivo'
,p_column_type=>'NUMBER'
,p_column_alignment=>'CENTER'
,p_format_mask=>'DOWNLOAD:T_APEX_ARCHIVOS:BLOBCONTENT:NUMEROARCHIVO::MIMETYPE:FILENAME:::attachment:#FILENAME#:FILES'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(168145905811781750)
,p_db_column_name=>'MIMETYPE'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Extension/Tipo'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(169893781466290002)
,p_db_column_name=>'USUARIO'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>'Usuario'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(169893800774290003)
,p_db_column_name=>'TIPO'
,p_display_order=>80
,p_column_identifier=>'H'
,p_column_label=>'Tipo'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(169894001767290005)
,p_db_column_name=>'FECHA'
,p_display_order=>90
,p_column_identifier=>'J'
,p_column_label=>unistr('Fecha Expiraci\00F3n')
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(169894124979290006)
,p_db_column_name=>'ESTADO'
,p_display_order=>100
,p_column_identifier=>'K'
,p_column_label=>'Estado'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(169894295118290007)
,p_db_column_name=>'CLAVE'
,p_display_order=>110
,p_column_identifier=>'L'
,p_column_label=>'Clave'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(169894305233290008)
,p_db_column_name=>'CLAVEDSC'
,p_display_order=>120
,p_column_identifier=>'M'
,p_column_label=>'Clavedsc'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_display_condition=>'APP_USER'
,p_display_condition2=>'EMASABANDA'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(169904147807383258)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'1699042'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'ID:NUMEROARCHIVO:BLOBCONTENT:MIMETYPE:USUARIO:TIPO:ESTADO:FECHA:CLAVEDSC:'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(169895169717290016)
,p_plug_name=>'Barra de Acciones'
,p_region_template_options=>'#DEFAULT#:t-Form--stretchInputs'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(38289497777120142)
,p_plug_display_sequence=>20
,p_plug_display_point=>'REGION_POSITION_01'
,p_location=>null
,p_menu_id=>wwv_flow_imp.id(37761271469106475)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(37860983999106559)
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(169895846196290023)
,p_plug_name=>'Botones'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(38290276266120143)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_03'
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(169895292197290017)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(169895169717290016)
,p_button_name=>'Buscar'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860056812106557)
,p_button_image_alt=>'Buscar'
,p_icon_css_classes=>'fa-search'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(169895986799290024)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(169895846196290023)
,p_button_name=>'Cerrar'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860181880106559)
,p_button_image_alt=>'Cerrar'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(169895396961290018)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(169895169717290016)
,p_button_name=>'Guardar'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860056812106557)
,p_button_image_alt=>'Guardar'
,p_icon_css_classes=>'fa-save'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(168144006067781731)
,p_name=>'P414_RUTA_CERTIFICADO'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(168143974519781730)
,p_prompt=>'Ruta Certificado'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(168144188591781732)
,p_name=>'P414_RUTA_LOGO'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(168143974519781730)
,p_prompt=>'Ruta Logo'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(168144263681781733)
,p_name=>'P414_COMPANIA'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(168144511390781736)
,p_prompt=>'Compania'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(168144643282781737)
,p_name=>'P414_CLAVE_CERTIFICADO'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(168143974519781730)
,p_prompt=>'Clave Certificado'
,p_display_as=>'NATIVE_PASSWORD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(168144775592781738)
,p_name=>'P414_CERTIFICADO'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(168143974519781730)
,p_prompt=>'Certificado'
,p_display_as=>'NATIVE_FILE'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'APEX_APPLICATION_TEMP_FILES'
,p_attribute_09=>'REQUEST'
,p_attribute_10=>'N'
,p_attribute_11=>'.p12'
,p_attribute_12=>'INLINE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(168144827403781739)
,p_name=>'P414_NOMBRE_CERTIFICADO'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(168143974519781730)
,p_prompt=>'Certificado(Activo)'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(168145254422781743)
,p_name=>'P414_EXPIRA_CERTIFICADO'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(168143974519781730)
,p_prompt=>'Expira Certificado'
,p_display_as=>'NATIVE_DATE_PICKER_APEX'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'POPUP'
,p_attribute_03=>'STATIC'
,p_attribute_04=>'+180d'
,p_attribute_06=>'NONE'
,p_attribute_09=>'N'
,p_attribute_11=>'N'
,p_attribute_12=>'MONTH-PICKER:YEAR-PICKER:TODAY-BUTTON'
,p_attribute_13=>'HIDDEN'
,p_attribute_15=>'FOCUS'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(169894671511290011)
,p_name=>'P414_NUMEROARCHIVO'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(168144511390781736)
,p_prompt=>'Numeroarchivo'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(169895523033290020)
,p_name=>'P414_VALIDA_CLAVE'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(168143974519781730)
,p_prompt=>'Valida Clave'
,p_display_as=>'NATIVE_PASSWORD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(169895655054290021)
,p_validation_name=>'New'
,p_validation_sequence=>10
,p_validation=>':P414_CLAVE_CERTIFICADO=:P414_VALIDA_CLAVE'
,p_validation2=>'PLSQL'
,p_validation_type=>'EXPRESSION'
,p_error_message=>unistr('Las contrase\00F1as no coinciden.')
,p_always_execute=>'Y'
,p_associated_item=>wwv_flow_imp.id(169895523033290020)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(169894703437290012)
,p_name=>'Eliminar'
,p_event_sequence=>10
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P414_NUMEROARCHIVO'
,p_condition_element=>'P414_NUMEROARCHIVO'
,p_triggering_condition_type=>'NOT_NULL'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(169894965859290014)
,p_event_id=>wwv_flow_imp.id(169894703437290012)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_CONFIRM'
,p_attribute_01=>unistr('\00BFEsta seguro de eliminar?')
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(169894816711290013)
,p_event_id=>wwv_flow_imp.id(169894703437290012)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin ',
'    DELETE  files.t_apex_archivos WHERE NUMEROARCHIVO=:P414_NUMEROARCHIVO;',
'    UPDATE files.t_apex_archivos  ',
'        SET estado=-11 ',
'    WHERE NUMEROARCHIVO !=:P414_NUMEROARCHIVO ',
'    and fecha = (select max(fecha ) from FILES.t_apex_archivos WHERE NUMEROARCHIVO!=:P414_NUMEROARCHIVO and  TABLA=''FIRMA_ELECTRONICA''AND ID_TABLA = ''FINZ_DCFIR'' );',
'end;'))
,p_attribute_02=>'P414_NUMEROARCHIVO'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(169895077236290015)
,p_event_id=>wwv_flow_imp.id(169894703437290012)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(168145387701781744)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(169896072213290025)
,p_name=>'Cerrar'
,p_event_sequence=>20
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(169895986799290024)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(169896186611290026)
,p_event_id=>wwv_flow_imp.id(169896072213290025)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CLOSE'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(168144342941781734)
,p_process_sequence=>10
,p_process_point=>'AFTER_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Setup Interface'
,p_process_sql_clob=>':P414_COMPANIA:=:G_COMPANIA;'
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>168144342941781734
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(169895498984290019)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Buscar'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'     select PK_COMMONS.F_DECRYPT(VALOR), codigocompania,VIGENCIAHASTA,VALOR2,VALOR3',
'     INTO :P414_CLAVE_CERTIFICADO',
'    ,:P414_COMPANIA',
'    ,:P414_EXPIRA_CERTIFICADO',
'    ,:P414_RUTA_CERTIFICADO:',
'    ,:P414_RUTA_LOGO',
'     from t_corp_udc where ID_CABECERA= ''FINZ_DCFIR'' AND ID_TABLA= ''FINZ_DCFIR'' ;',
'exception when others then',
'    null;',
'end;',
'',
'begin',
'    select NUMEROARCHIVO, FILENAME ',
'    INTO :P414_NUMEROARCHIVO,:P414_NOMBRE_CERTIFICADO',
'    from files.t_apex_archivos where tabla= ''FIRMA_ELECTRONICA'' and id_tabla=''FINZ_DCFIR'' and tipo=''ARCH_P12'' AND ESTADO=''1'';',
'exception when others then',
'    null;',
'',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(169895292197290017)
,p_internal_uid=>169895498984290019
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(168145132600781742)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'GUARDAR'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare ',
'    V_NOMBREARCHIVO varchar2(3999);',
'    v_fileContent   blob;',
'    p_numeroarchivo number;',
'    P_MIMETYPE VARCHAR2(399);',
'     v_contador number;',
'    V_CLAVE_CERTIFICADO VARCHAR2(399);',
'    v_tiene_error number:=0;',
' BEGIN',
'    if (trim(:P414_CLAVE_CERTIFICADO) is   null)then',
'        v_tiene_error:=1;',
'        apex_error.add_error (',
'            p_message          => ''Clave Certificado, debe tener un valor'',',
'            p_display_location =>apex_error.c_inline_with_field_and_notif ,',
'            p_page_item_name   => ''P414_CLAVE_CERTIFICADO''',
'        );',
'    end if;',
'    if (trim(:P414_CERTIFICADO) is   null)then',
'        v_tiene_error:=1;',
'        apex_error.add_error (',
'            p_message          => ''Certificado, debe seleccionar un archivo (.p12)'',',
'            p_display_location =>apex_error.c_inline_with_field_and_notif ,',
'            p_page_item_name   => ''P414_CERTIFICADO''',
'        );',
'    end if;',
'    if (trim(:P414_EXPIRA_CERTIFICADO) is   null)then',
'        v_tiene_error:=1;',
'        apex_error.add_error (',
unistr('            p_message          => ''Expira Certificado, debe indicar la expiraci\00F3n del certificado'','),
'            p_display_location =>apex_error.c_inline_with_field_and_notif ,',
'            p_page_item_name   => ''P414_EXPIRA_CERTIFICADO''',
'        );',
'    end if;',
'',
'    if (trim(:P414_RUTA_CERTIFICADO) is   null)then',
'        v_tiene_error:=1;',
'        apex_error.add_error (',
unistr('            p_message          => ''Ruta Certificado, debe indicar la ubicaci\00F3n f\00EDsica en el servidor'','),
'            p_display_location =>apex_error.c_inline_with_field_and_notif ,',
'            p_page_item_name   => ''P414_RUTA_CERTIFICADO''',
'        );',
'    end if;',
'    if (trim(:P414_RUTA_LOGO) is   null)then',
'        v_tiene_error:=1;',
'        apex_error.add_error (',
unistr('            p_message          => ''Ruta Logo, debe indicar la ubicaci\00F3n f\00EDsica en el servidor'','),
'            p_display_location =>apex_error.c_inline_with_field_and_notif ,',
'            p_page_item_name   => ''P414_RUTA_LOGO''',
'        );',
'    end if;',
'',
'',
'',
'',
'',
'',
'    if (v_tiene_error=0)then',
'        V_CLAVE_CERTIFICADO:=PK_COMMONS.F_ENCRYPT(:P414_CLAVE_CERTIFICADO) ;',
'    	FOR RFILE IN (SELECT * FROM APEX_APPLICATION_TEMP_FILES order by created_on desc)',
'    	LOOP',
'    		V_NOMBREARCHIVO:= RFILE.FILENAME;',
'            P_MIMETYPE:=RFILE.MIME_TYPE;',
'            :P414_NOMBRE_CERTIFICADO:=V_NOMBREARCHIVO;',
'            v_fileContent:=RFILE.BLOB_CONTENT;',
'',
'        END LOOP;',
'',
'        begin',
'            select count(distinct 1) into v_contador  from t_corp_udc where ID_CABECERA= ''FINZ_DCFIR'' AND ID_TABLA= ''FINZ_DCFIR'' ;',
'            if (v_contador=0 )then ',
'                Insert into t_corp_udc (ID_CABECERA,    ID_TABLA,                         DESCRIPCION,                  VALOR,                VALOR2,         VALOR3, ACTIVO, CODIGOCOMPANIA,VIGENCIADESDE,           VIGENCIAHASTA,DESCRIPCION3) ',
unistr('                values                (''FINZ_DCFIR'',''FINZ_DCFIR'',''FIRMA ELECTONICA DE DOCUMENTOS XML'',V_CLAVE_CERTIFICADO,:P414_RUTA_CERTIFICADO,:P414_RUTA_LOGO,    ''1'', :P414_COMPANIA, SYSTIMESTAMP,:P414_EXPIRA_CERTIFICADO,''Facturaci\00F3n Electronica -')
||' firma electonica'');',
'            else ',
'                upDAte t_corp_udc ',
'                SET (                     VALOR,                VALOR2,         VALOR3,VIGENCIADESDE,           VIGENCIAHASTA)=',
'                (SELECT V_CLAVE_CERTIFICADO,:P414_RUTA_CERTIFICADO,:P414_RUTA_LOGO, SYSTIMESTAMP,:P414_EXPIRA_CERTIFICADO FROM DUAL)',
'                where ID_CABECERA= ''FINZ_DCFIR'' AND ID_TABLA= ''FINZ_DCFIR'' ;',
'            end if;',
'',
'        end;',
'',
'        BEGIN',
'            pk_commons.sp_secuencia(''T_APEX_ARCHIVOS'', p_numeroarchivo);',
'            INSERT into files.t_apex_archivos (  numeroarchivo,              tabla,    id_tabla,      tipo,  blobcontent,       filename,  mimetype,  ride,          observacion,estado,nombreusuario,fecha) ',
'            values                            (p_numeroarchivo,''FIRMA_ELECTRONICA'',''FINZ_DCFIR'',''ARCH_P12'',v_fileContent,V_NOMBREARCHIVO,P_MIMETYPE,null,V_CLAVE_CERTIFICADO,     1,    :app_user,:P414_EXPIRA_CERTIFICADO);',
'            UPDATE files.t_apex_archivos  SET estado=0 WHERE NUMEROARCHIVO !=p_numeroarchivo;',
'        END;',
'        COMMIT;',
'    end if; ',
'',
'    --pk_finz_sri_autorizacion.SP_BLOB2ARCBHVO(p_numeroarchivo,:P414_RUTA_CERTIFICADO||V_NOMBREARCHIVO);',
'END;    ',
''))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(169895396961290018)
,p_internal_uid=>168145132600781742
);
wwv_flow_imp.component_end;
end;
/
