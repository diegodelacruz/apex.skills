prompt --application/pages/page_00196
begin
--   Manifest
--     PAGE: 00196
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>109
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_page.create_page(
 p_id=>196
,p_name=>'GESTION TRIBUTARIA -AUTO RET'
,p_alias=>'GESTION-TRIBUTARIA-AUTO-RET'
,p_page_mode=>'MODAL'
,p_step_title=>'GESTION TRIBUTARIA -AUTO RET'
,p_autocomplete_on_off=>'OFF'
,p_javascript_file_urls=>'https://cdnjs.cloudflare.com/ajax/libs/xlsx/0.18.5/xlsx.full.min.js'
,p_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'function f_render_auto_retencion_ir(p_data) {',
'  let json = JSON.parse(JSON.stringify(p_data || {}));',
'  const contenedor = document.getElementById(''reporte-auto-ir'');',
'  if (!contenedor) return;',
'',
'  function redondear2(val) {',
'    return Math.round(parseFloat(val || 0) * 100) / 100;',
'  }',
'',
'  function parseNumero(valor) {',
'    if (typeof valor === ''string'') {',
'      valor = valor.replace(/\./g, '''').replace('','', ''.'').replace(''%'', '''').trim();',
'    }',
'    let num = parseFloat(valor);',
'    return isNaN(num) ? 0 : num;',
'  }',
'',
'  function render() {',
unistr('    // Forzar valores num\00E9ricos v\00E1lidos'),
'    json.VENTAS_NETAS_BASE_IMP = parseNumero(json.VENTAS_NETAS_BASE_IMP);',
'    json.OTROS_INGRESOS_BASE_IMP = parseNumero(json.OTROS_INGRESOS_BASE_IMP);',
'    json.VENTAS_NETAS_IMP_PAGAR = parseNumero(json.VENTAS_NETAS_IMP_PAGAR);',
'    json.OTROS_INGRESOS_IMP_PAGAR = parseNumero(json.OTROS_INGRESOS_IMP_PAGAR);',
'    json.PORCENTAJE_IR = parseNumero(json.PORCENTAJE_IR);',
'    json.bc = parseNumero(json.bc);',
'',
'    json.TOTAL_INGRESOS_BASE_IMP = redondear2(json.VENTAS_NETAS_BASE_IMP + json.OTROS_INGRESOS_BASE_IMP);',
'    json.TOTAL_INGRESOS_IMP_PAGAR = redondear2(json.VENTAS_NETAS_IMP_PAGAR + json.OTROS_INGRESOS_IMP_PAGAR);',
'    json.TOTAL_IMPUESTO_RENTA = redondear2((json.PORCENTAJE_IR / 100) * json.TOTAL_INGRESOS_BASE_IMP);',
'    json.diferencia = redondear2(json.TOTAL_IMPUESTO_RENTA - json.bc);',
'',
'    let html = `',
'      <style>',
'        table { border-collapse: collapse; width: 100%; font-size: 13px; }',
'        th, td { border: 0.5px dotted #888; padding: 4px 6px; text-align: left; }',
'        th { background-color: #f2f2f2; }',
'        .editable { background-color: #eaffea; }',
'        td[contenteditable="true"] { min-width: 80px; }',
'        .text-right { text-align: right; }',
'        .seccion { margin-top: 12px; }',
'      </style>',
'',
'     <div><strong>CUENTA: ` + $v("P196_CUENTADESCRIPCION") + ` - </strong> ',
'        <span class="text-left" data-clave="CUENTA">${json.CUENTA}</span>',
'      </div>',
'    ',
'      <div class="seccion">',
'        <i><u>Ingresos:</u></i>',
'        <table>',
'          <thead>',
'            <tr style="text-align: center;">',
'              <th>CONCEPTO</th>',
'              <th>BASE IMPONIBLE</th>',
'              <th>IMPUESTO</th>',
'            </tr>',
'          </thead>',
'          <tbody>',
'            <tr>',
'              <td>VENTAS NETAS</td>',
'              <td contenteditable="true" class="editable text-right" data-campo="VENTAS_NETAS_BASE_IMP">${json.VENTAS_NETAS_BASE_IMP.toLocaleString(''es-EC'')}</td>',
'              <td contenteditable="true" class="editable text-right" data-campo="VENTAS_NETAS_IMP_PAGAR">${json.VENTAS_NETAS_IMP_PAGAR.toLocaleString(''es-EC'')}</td>',
'            </tr>',
'            <tr>',
'              <td>OTROS INGRESOS</td>',
'              <td contenteditable="true" class="editable text-right" data-campo="OTROS_INGRESOS_BASE_IMP">${json.OTROS_INGRESOS_BASE_IMP.toLocaleString(''es-EC'')}</td>',
'              <td contenteditable="true" class="editable text-right" data-campo="OTROS_INGRESOS_IMP_PAGAR">${json.OTROS_INGRESOS_IMP_PAGAR.toLocaleString(''es-EC'')}</td>',
'            </tr>',
'            <tr>',
'              <td><strong>TOTAL INGRESOS</strong></td>',
'              <td class="text-right"><strong>${json.TOTAL_INGRESOS_BASE_IMP.toLocaleString(''es-EC'')}</strong></td>',
'              <td class="text-right"><strong>${json.TOTAL_INGRESOS_IMP_PAGAR.toLocaleString(''es-EC'')}</strong></td>',
'            </tr>',
'            <tr>',
'              <td class="text-right"><strong>% IR</strong></td>',
'              <td contenteditable="true" class="editable text-right" data-campo="PORCENTAJE_IR">${json.PORCENTAJE_IR}%</td>',
'              <td class="text-right"><strong>${json.TOTAL_IMPUESTO_RENTA.toLocaleString(''es-EC'')}</strong></td>',
'            </tr>',
'            <tr>',
'               ',
'              <td colspan="2" class="text-right" style="border:none;"><strong>BC:</strong></td>',
'              <td class="text-right" data-campo="bc">${(json.bc || 0).toLocaleString(''es-EC'')}</td>',
'            </tr>',
'            <tr>',
'               ',
'              <td colspan="2" class="text-right" style="border:none;"><strong>DIFERENCIA:</strong></td>',
'              <td class="text-right"><strong>${json.diferencia.toLocaleString(''es-EC'')}</strong></td>',
'            </tr>',
'          </tbody>',
'        </table>',
'      </div>',
'    `;',
'',
'    contenedor.innerHTML = html;',
'',
unistr('    // Eventos de edici\00F3n'),
'    contenedor.querySelectorAll(''.editable'').forEach(cell => {',
'      cell.addEventListener(''blur'', function () {',
'        const campo = this.dataset.campo;',
'        const texto = this.textContent.trim();',
'        json[campo] = parseNumero(texto);',
'        $s(''P196_JSON'', JSON.stringify(json));',
unistr('        render(); // Re-renderizar con c\00E1lculos actualizados'),
'      });',
'    });',
'',
'    // Guardar JSON en el item',
'    $s(''P196_JSON'', JSON.stringify(json));',
'  }',
'',
'  render();',
'}'))
,p_javascript_code_onload=>wwv_flow_string.join(wwv_flow_t_varchar2(
'$(secItems).hide();',
'let data = JSON.parse($v(''P196_JSON''));',
'f_render_auto_retencion_ir(data);',
''))
,p_step_template=>wwv_flow_imp.id(37774372912106498)
,p_page_template_options=>'#DEFAULT#'
,p_dialog_chained=>'N'
,p_protection_level=>'C'
,p_page_component_map=>'16'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(109267054835787731)
,p_plug_name=>'BARRA DE BOTONES'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(38290276266120143)
,p_plug_display_sequence=>60
,p_location=>null
,p_ai_enabled=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(109267534215787736)
,p_plug_name=>'items'
,p_region_name=>'secItems'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(38289867500120143)
,p_plug_display_sequence=>80
,p_location=>null
,p_ai_enabled=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(127603870092632110)
,p_plug_name=>'ReporteRenta'
,p_region_name=>'reporte-auto-ir'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(38289867500120143)
,p_plug_display_sequence=>20
,p_location=>null
,p_ai_enabled=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(67103989592457211)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(109267054835787731)
,p_button_name=>'CLOSE'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860181880106559)
,p_button_image_alt=>'Cerrar'
,p_warn_on_unsaved_changes=>null
,p_grid_new_row=>'N'
,p_grid_new_column=>'N'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(67104303751457211)
,p_button_sequence=>50
,p_button_plug_id=>wwv_flow_imp.id(109267054835787731)
,p_button_name=>'SAVE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860181880106559)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Guadar'
,p_grid_new_row=>'N'
,p_grid_new_column=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(109269717649787752)
,p_name=>'P196_IDDAT'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(109267534215787736)
,p_prompt=>'Iddat'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(127604852615632114)
,p_name=>'P196_JSON'
,p_data_type=>'CLOB'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(109267534215787736)
,p_prompt=>'Json'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>30
,p_cHeight=>5
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(127605237851632118)
,p_name=>'P196_BCCTACONTABLE'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(109267534215787736)
,p_prompt=>'Bcctacontable'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_grid_label_column_span=>3
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(127605397182632120)
,p_name=>'P196_BCAUTORET'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(109267534215787736)
,p_prompt=>'Bcautoret'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(127605494951632121)
,p_name=>'P196_PERIODO'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(109267534215787736)
,p_prompt=>'Periodo'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(127605619818632122)
,p_name=>'P196_CUENTANUMERO'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(109267534215787736)
,p_prompt=>'Cuentanumero'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(127605749961632123)
,p_name=>'P196_CUENTADESCRIPCION'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(109267534215787736)
,p_prompt=>'Cuentadescripcion'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(67108019676457218)
,p_name=>'Cerrar'
,p_event_sequence=>50
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(67103989592457211)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(67108582377457219)
,p_event_id=>wwv_flow_imp.id(67108019676457218)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CLOSE'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(67105740839457215)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Process Create - PRUEBA DEPARTAMENTAL'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
'    update  data.t_finz_gestiontributariadatos dat set DATOSMOD= :P196_JSON, DATOSFIN= :P196_JSON where dat.id=:P196_IDDAT;',
'EXCEPTION WHEN OTHERS THEN ',
'    apex_error.add_error (',
'    p_message          => ''ERROR::''||SQLERRM  ,',
'    p_display_location =>apex_error.c_inline_in_notification );',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>67105740839457215
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(67105327747457215)
,p_process_sequence=>20
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Initialize'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
'',
'    :P196_IDDAT:=nvl(:P196_IDDAT,:G_VALOR1);',
'     BEGIN',
'         select ',
'            dat.datosmod,GTB.PERIODO INTO :P196_JSON,:P196_PERIODO',
'        from data.t_finz_gestiontributaria gtb',
'        inner join data.t_finz_gestiontributariadet det ON gtb.id=det.idgtb',
'        inner join data.t_finz_gestiontributariadatos dat on det.id=dat.iddet',
'        WHERE dat.id =:P196_IDDAT;',
'     EXCEPTION WHEN OTHERS THEN ',
'        :P196_JSON:=NULL;:P196_PERIODO:=1;',
'     END;',
'',
'    select ',
'        --ID, PERIODO,  BUSQ,',
'        DESCRIP_BALANCE, CTA_BALANCE,',
'        PK_FINZ_GESTIONTRIBUTARIA.f_trer_valorbalance (PERIODO,BUSQ,TIPO_BUSQ_BC) BC',
'        into :P196_CUENTADESCRIPCION,:P196_CUENTANUMERO,:P196_BCAUTORET',
'    from ( ',
'        SELECT ',
'            ROWNUM ID , --ID, TIPO_RESUMEN, TIPO_BUSQ_BC, PERIODO, VENTA_BRUTA, VENTA_NETA, IVA_VENTAS',
'            PK_FINZ_GESTIONTRIBUTARIA.f_trae_descripcioncuenta(''BC_RET_AUT'',''P'',''D'') DESCRIP_BALANCE,',
'            PK_FINZ_GESTIONTRIBUTARIA.f_trae_descripcioncuenta(''BC_RET_AUT'',''P'',''C'') CTA_BALANCE,',
'            PK_FINZ_GESTIONTRIBUTARIA.f_trae_descripcioncuenta(''BC_RET_AUT'',''P'',''C'') BUSQ',
'            , ''C'' TIPO_BUSQ_BC',
'            , :P196_PERIODO PERIODO',
'        FROM DUAL D',
'    );',
'    :P196_BCAUTORET:=nvl(:P196_BCAUTORET,0);',
'    :P196_BCAUTORET:=replace(:P196_BCAUTORET,'','',''.'');',
'    IF (:P196_JSON IS NULL)THEN ',
'--        :P196_JSON:=''{"CUENTA":"''||:P196_CUENTANUMERO||''","VENTAS_NETAS_BASE_IMP":8436572.55,"OTROS_INGRESOS_BASE_IMP":230095.86,"VENTAS_NETAS_IMP_PAGAR":0.00,"OTROS_INGRESOS_IMP_PAGAR":0.00,"TOTAL_INGRESOS_BASE_IMP":8666668.41,"TOTAL_INGRESOS_IMP_'
||'PAGAR":260000.05,"PORCENTAJE_IR":3.00,"TOTAL_IMPUESTO_RENTA":260000.05}'';',
'        :P196_JSON:=''{"CUENTA":"''||:P196_CUENTANUMERO||''","VENTAS_NETAS_BASE_IMP":0.00,"OTROS_INGRESOS_BASE_IMP":0.00,"VENTAS_NETAS_IMP_PAGAR":0.00,"OTROS_INGRESOS_IMP_PAGAR":0.00,"TOTAL_INGRESOS_BASE_IMP":0.00,"TOTAL_INGRESOS_IMP_PAGAR":0.00,"PORCEN'
||'TAJE_IR":0.00,"TOTAL_IMPUESTO_RENTA":0.00,"bc":''||:P196_BCAUTORET||'',"diferencia":0.00}'';',
'        --:P196_JSON:=''{"CUENTA":"11000.11602.16","VENTAS_NETAS_BASE":8436572.55,"OTROS_INGRESOS_BASE":230095.86,"VENTAS_NETAS_IMP":0,"OTROS_INGRESOS_IMP":0,"PORCENTAJE_IR":3,"TOTAL_IMPUESTO_RENTA":260000.05}'';',
'    END IF;',
'    ',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>67105327747457215
);
wwv_flow_imp.component_end;
end;
/
