prompt --application/pages/page_00464
begin
--   Manifest
--     PAGE: 00464
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>109
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_page.create_page(
 p_id=>464
,p_name=>'Activos Fijos - Bajas'
,p_alias=>'BAJA-ACTIVOS'
,p_step_title=>'Bajas'
,p_autocomplete_on_off=>'OFF'
,p_javascript_code_onload=>'$(regOcultos).hide();'
,p_page_template_options=>'#DEFAULT#'
,p_page_component_map=>'18'
,p_last_updated_on=>wwv_flow_imp.dz('20260326142223Z')
,p_last_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(102171997695365850)
,p_plug_name=>'Filtros'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(38289867500120143)
,p_plug_display_sequence=>10
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(102865827570569560)
,p_plug_name=>'Barra de acciones'
,p_region_template_options=>'#DEFAULT#:t-Form--stretchInputs'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(38289497777120142)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_location=>null
,p_menu_id=>wwv_flow_imp.id(37761271469106475)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(37860983999106559)
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(102874374945640606)
,p_plug_name=>'Activos Seleccionables'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(95503811913299190)
,p_plug_display_sequence=>20
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT APEX_ITEM.CHECKBOX(1,ID,CASE WHEN :P464_TODOS=1 THEN ''CHECKED'' ELSE ''UNCHECKED'' END || '' class="chkF01"'') seleccion',
'	, APEX_ITEM.RADIOGROUP(',
'		p_idx            => 2,',
'		p_value          => id,',
'		p_selected_value => :P464_SELECCIONADO,             -- el que se marca por defecto',
'		p_display        => null,',
'		p_attributes     =>  ''class="chkF02" data-id="''||ID||''"''',
'       ) seleccion2',
'	, CODERP',
'	, CODACTIVO',
'	, DESCRIPCION1',
'	, DESCRIPCION2',
'	, DESCRIPCION3',
'	, CODTIPO',
'	, CODCATEGORIA',
'	, CODSUBCATEGORIA',
'	, ESTADO',
'	, CODUBICACION',
'	, centrocosto',
'	, CODCUSTODIO',
'FROM data.T_FINZ_ACTIVOSFIJOS',
'WHERE 1 = 1',
'	and (coderp is not null or codactivo is not null)',
'	and COMPANIA = :G_COMPANIA',
'	AND (CODTIPO = :P464_TIPO OR :P464_TIPO = ''999'')',
'	AND (CODCATEGORIA = :P464_CATEGORIA OR :P464_CATEGORIA = ''999'')',
'	AND (CODSUBCATEGORIA = :P464_SUBCATEGORIA OR :P464_SUBCATEGORIA = ''999'')',
'	-- AND ((ESTADO = :P464_ESTADO OR :P464_ESTADO IS NULL) AND ESTADO NOT LIKE ''BAJA%'')',
'	AND ESTADO = ''ENVIADO''',
''))
,p_plug_source_type=>'NATIVE_IR'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
,p_updated_on=>wwv_flow_imp.dz('20260211063652Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(102874536476640608)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'MALBAN'
,p_internal_uid=>102874536476640608
,p_updated_on=>wwv_flow_imp.dz('20260211063652Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(102875682595640619)
,p_db_column_name=>'SELECCION'
,p_display_order=>10
,p_column_identifier=>'J'
,p_column_label=>'-'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(102874644312640609)
,p_db_column_name=>'CODERP'
,p_display_order=>30
,p_column_identifier=>'A'
,p_column_label=>unistr('C\00F3d. ERP')
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(102874771775640610)
,p_db_column_name=>'CODACTIVO'
,p_display_order=>40
,p_column_identifier=>'B'
,p_column_label=>unistr('C\00F3d. Activo')
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(102874867214640611)
,p_db_column_name=>'DESCRIPCION1'
,p_display_order=>50
,p_column_identifier=>'C'
,p_column_label=>unistr('Descripci\00F3n 1')
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(102874937092640612)
,p_db_column_name=>'CODTIPO'
,p_display_order=>60
,p_column_identifier=>'D'
,p_column_label=>'Tipo'
,p_column_type=>'STRING'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_rpt_named_lov=>wwv_flow_imp.id(98576969558658537)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(102875090276640613)
,p_db_column_name=>'CODCATEGORIA'
,p_display_order=>70
,p_column_identifier=>'E'
,p_column_label=>unistr('Categor\00EDa')
,p_column_type=>'STRING'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_rpt_named_lov=>wwv_flow_imp.id(98577560814666584)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(102875131017640614)
,p_db_column_name=>'CODSUBCATEGORIA'
,p_display_order=>80
,p_column_identifier=>'F'
,p_column_label=>unistr('Subcategor\00EDa')
,p_column_type=>'STRING'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_rpt_named_lov=>wwv_flow_imp.id(98577774561669941)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
,p_updated_on=>wwv_flow_imp.dz('20260210054520Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(102875238594640615)
,p_db_column_name=>'ESTADO'
,p_display_order=>90
,p_column_identifier=>'G'
,p_column_label=>'Estado'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(102875355601640616)
,p_db_column_name=>'CODUBICACION'
,p_display_order=>100
,p_column_identifier=>'H'
,p_column_label=>unistr('Ubicaci\00F3n')
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(102875488160640617)
,p_db_column_name=>'CODCUSTODIO'
,p_display_order=>110
,p_column_identifier=>'I'
,p_column_label=>'Custodio'
,p_column_type=>'STRING'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_rpt_named_lov=>wwv_flow_imp.id(336564499940306120)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
,p_updated_on=>wwv_flow_imp.dz('20260210054520Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(104335170914987307)
,p_db_column_name=>'SELECCION2'
,p_display_order=>120
,p_column_identifier=>'L'
,p_column_label=>'.'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
,p_updated_on=>wwv_flow_imp.dz('20260210054044Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(349933964931846534)
,p_db_column_name=>'DESCRIPCION2'
,p_display_order=>130
,p_column_identifier=>'M'
,p_column_label=>'Descripcion 2'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20260210054252Z')
,p_updated_on=>wwv_flow_imp.dz('20260210054252Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(349934020514846535)
,p_db_column_name=>'DESCRIPCION3'
,p_display_order=>140
,p_column_identifier=>'N'
,p_column_label=>'Descripcion 3'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20260210054252Z')
,p_updated_on=>wwv_flow_imp.dz('20260210054252Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(351293795768162513)
,p_db_column_name=>'CENTROCOSTO'
,p_display_order=>150
,p_column_identifier=>'O'
,p_column_label=>'Centro de Costo'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20260211063652Z')
,p_updated_on=>wwv_flow_imp.dz('20260211063652Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(103062426713753600)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'1030625'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_display_rows=>25
,p_report_columns=>'SELECCION2:CODTIPO:CODCATEGORIA:CODSUBCATEGORIA:CODERP:CODACTIVO:DESCRIPCION3:CODCUSTODIO:'
,p_sort_column_1=>'CODTIPO'
,p_sort_direction_1=>'ASC'
,p_sort_column_2=>'CODCATEGORIA'
,p_sort_direction_2=>'ASC'
,p_sort_column_3=>'CODSUBCATEGORIA'
,p_sort_direction_3=>'ASC'
,p_sort_column_4=>'CODERP'
,p_sort_direction_4=>'DESC'
,p_sort_column_5=>'0'
,p_sort_direction_5=>'ASC'
,p_sort_column_6=>'0'
,p_sort_direction_6=>'ASC'
,p_updated_on=>wwv_flow_imp.dz('20260211052330Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(102877046307640633)
,p_plug_name=>'Adjuntos'
,p_region_template_options=>'#DEFAULT#:is-collapsed:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(37796755046106514)
,p_plug_display_sequence=>40
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(102877319682640636)
,p_plug_name=>'Carga'
,p_parent_plug_id=>wwv_flow_imp.id(102877046307640633)
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(38289867500120143)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(102877441419640637)
,p_plug_name=>'ReporteAdjuntos'
,p_parent_plug_id=>wwv_flow_imp.id(102877046307640633)
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(37806762584106520)
,p_plug_display_sequence=>20
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT NUMEROARCHIVO,',
'       dbms_lob.getlength(BLOBCONTENT) BLOBCONTENT,',
'       FILENAME,',
'       MIMETYPE,',
'       TABLA,',
'       ID_TABLA,',
'       TIPO,',
'       OBSERVACION,',
'       ESTADO,',
'       FECHA,',
'       NOMBREUSUARIO,',
'       RIDE,',
'       ''<span class="fa fa-eye" title="Previsualizar" aria-hidden="true" style="color: #800080;"></span>'' ver,',
'       pk_commons.f_googledocview(numeroarchivo,mimetype) enlacearchivo,',
'       NUMEROARCHIVO AS BORRAR',
'FROM FILES.T_APEX_ARCHIVOS',
'WHERE TABLA=''T_FINZ_ACTIVOSFIJOS'' AND TIPO=''BAJA_ACTIVO''',
'AND ID_TABLA=:P464_SELECCIONADO'))
,p_plug_source_type=>'NATIVE_IR'
,p_ajax_items_to_submit=>'P464_SELECCIONADO'
,p_plug_display_condition_type=>'EXPRESSION'
,p_plug_display_when_condition=>'1=2'
,p_plug_display_when_cond2=>'PLSQL'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(102877715098640640)
,p_max_row_count=>'1000000'
,p_no_data_found_message=>'no existen datos'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'MALBAN'
,p_internal_uid=>102877715098640640
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(102877856606640641)
,p_db_column_name=>'NUMEROARCHIVO'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Numeroarchivo'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(102877988333640642)
,p_db_column_name=>'BLOBCONTENT'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Blobcontent'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(102878084509640643)
,p_db_column_name=>'FILENAME'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Filename'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(102878107187640644)
,p_db_column_name=>'MIMETYPE'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Mimetype'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(102878299181640645)
,p_db_column_name=>'TABLA'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Tabla'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(102878321244640646)
,p_db_column_name=>'ID_TABLA'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'Id Tabla'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(102878456132640647)
,p_db_column_name=>'TIPO'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>'Tipo'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(102878542891640648)
,p_db_column_name=>'OBSERVACION'
,p_display_order=>80
,p_column_identifier=>'H'
,p_column_label=>'Observacion'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(102878686815640649)
,p_db_column_name=>'ESTADO'
,p_display_order=>90
,p_column_identifier=>'I'
,p_column_label=>'Estado'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(102878718274640650)
,p_db_column_name=>'FECHA'
,p_display_order=>100
,p_column_identifier=>'J'
,p_column_label=>'Fecha'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(104334592552987301)
,p_db_column_name=>'NOMBREUSUARIO'
,p_display_order=>110
,p_column_identifier=>'K'
,p_column_label=>'Nombreusuario'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(104334621012987302)
,p_db_column_name=>'RIDE'
,p_display_order=>120
,p_column_identifier=>'L'
,p_column_label=>'Ride'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(104334777675987303)
,p_db_column_name=>'VER'
,p_display_order=>130
,p_column_identifier=>'M'
,p_column_label=>'Ver Documento'
,p_column_link=>'#ENLACEARCHIVO#'
,p_column_linktext=>'#VER#'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(104334876017987304)
,p_db_column_name=>'ENLACEARCHIVO'
,p_display_order=>140
,p_column_identifier=>'N'
,p_column_label=>'Enlacearchivo'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(104334956512987305)
,p_db_column_name=>'BORRAR'
,p_display_order=>150
,p_column_identifier=>'O'
,p_column_label=>'Borrar'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(104354775744220210)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'1043548'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'NUMEROARCHIVO:BLOBCONTENT:FILENAME:MIMETYPE:TABLA:ID_TABLA:TIPO:OBSERVACION:ESTADO:FECHA:NOMBREUSUARIO:RIDE:VER:ENLACEARCHIVO:BORRAR'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(102877170514640634)
,p_plug_name=>'Bajas en Proceso'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(95503811913299190)
,p_plug_display_sequence=>50
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(104975266990980201)
,p_plug_name=>'Bajas en Proceso'
,p_parent_plug_id=>wwv_flow_imp.id(102877170514640634)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(37806762584106520)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select id',
'	, coderp',
'	, codactivo',
'	, descripcion3',
'	, codtipo',
'	, codcategoria',
'	, codsubcategoria',
'	, estado',
'	, codubicacion',
'	, codcustodio',
'	, bj_fechasol',
'	, bj_motivo',
'from t_finz_activosfijos',
'where 1 = 1',
'	and compania = :g_compania',
'	and estado = ''BAJASOLICITADA''',
'	and bj_usuario = :app_user',
'	and idflujo is null'))
,p_plug_source_type=>'NATIVE_IG'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
,p_updated_on=>wwv_flow_imp.dz('20260211054058Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(105519432130239512)
,p_name=>'ID'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'ID'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>30
,p_attribute_01=>'Y'
,p_filter_is_required=>false
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_is_primary_key=>true
,p_duplicate_value=>true
,p_include_in_export=>false
,p_updated_on=>wwv_flow_imp.dz('20260211053939Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(105519541796239513)
,p_name=>'CODERP'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'CODERP'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>unistr('C\00F3d. ERP')
,p_heading_alignment=>'CENTER'
,p_display_sequence=>40
,p_value_alignment=>'CENTER'
,p_attribute_05=>'BOTH'
,p_is_required=>false
,p_max_length=>30
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(105519669265239514)
,p_name=>'CODACTIVO'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'CODACTIVO'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>unistr('C\00F3d. Activo')
,p_heading_alignment=>'CENTER'
,p_display_sequence=>50
,p_value_alignment=>'CENTER'
,p_attribute_05=>'BOTH'
,p_is_required=>false
,p_max_length=>30
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(105519871554239516)
,p_name=>'CODTIPO'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'CODTIPO'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_POPUP_LOV'
,p_heading=>'Tipo'
,p_heading_alignment=>'CENTER'
,p_display_sequence=>70
,p_value_alignment=>'LEFT'
,p_attribute_01=>'POPUP'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_04=>'N'
,p_attribute_05=>'N'
,p_is_required=>false
,p_max_length=>10
,p_lov_type=>'SHARED'
,p_lov_id=>wwv_flow_imp.id(98576969558658537)
,p_lov_display_extra=>false
,p_lov_display_null=>false
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'LOV'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(105519911403239517)
,p_name=>'CODCATEGORIA'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'CODCATEGORIA'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_POPUP_LOV'
,p_heading=>unistr('Categor\00EDa')
,p_heading_alignment=>'CENTER'
,p_display_sequence=>80
,p_value_alignment=>'LEFT'
,p_attribute_01=>'POPUP'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_04=>'N'
,p_attribute_05=>'N'
,p_is_required=>false
,p_max_length=>10
,p_lov_type=>'SHARED'
,p_lov_id=>wwv_flow_imp.id(98577560814666584)
,p_lov_display_extra=>true
,p_lov_display_null=>true
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'LOV'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(105520000229239518)
,p_name=>'CODSUBCATEGORIA'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'CODSUBCATEGORIA'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_POPUP_LOV'
,p_heading=>unistr('Subcategor\00EDa')
,p_heading_alignment=>'CENTER'
,p_display_sequence=>90
,p_value_alignment=>'LEFT'
,p_attribute_01=>'POPUP'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_04=>'N'
,p_attribute_05=>'N'
,p_is_required=>false
,p_max_length=>10
,p_lov_type=>'SHARED'
,p_lov_id=>wwv_flow_imp.id(98577774561669941)
,p_lov_display_extra=>true
,p_lov_display_null=>true
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'LOV'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(105520189345239519)
,p_name=>'ESTADO'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'ESTADO'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>110
,p_attribute_01=>'Y'
,p_filter_is_required=>false
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>false
,p_updated_on=>wwv_flow_imp.dz('20260211054058Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(105520262843239520)
,p_name=>'CODUBICACION'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'CODUBICACION'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>120
,p_attribute_01=>'Y'
,p_filter_is_required=>false
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>false
,p_updated_on=>wwv_flow_imp.dz('20260211054058Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(105520323724239521)
,p_name=>'CODCUSTODIO'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'CODCUSTODIO'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>130
,p_attribute_01=>'Y'
,p_filter_is_required=>false
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>false
,p_updated_on=>wwv_flow_imp.dz('20260211054058Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(105520631460239524)
,p_name=>'APEX$ROW_ACTION'
,p_session_state_data_type=>'VARCHAR2'
,p_item_type=>'NATIVE_ROW_ACTION'
,p_display_sequence=>20
,p_use_as_row_header=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(105520706860239525)
,p_name=>'APEX$ROW_SELECTOR'
,p_session_state_data_type=>'VARCHAR2'
,p_item_type=>'NATIVE_ROW_SELECTOR'
,p_display_sequence=>10
,p_attribute_01=>'Y'
,p_attribute_02=>'Y'
,p_attribute_03=>'N'
,p_use_as_row_header=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(340403788244329202)
,p_name=>'BJ_FECHASOL'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'BJ_FECHASOL'
,p_data_type=>'DATE'
,p_is_query_only=>false
,p_item_type=>'NATIVE_DATE_PICKER_APEX'
,p_heading=>'Fecha Sol.'
,p_heading_alignment=>'CENTER'
,p_display_sequence=>140
,p_value_alignment=>'CENTER'
,p_attribute_01=>'N'
,p_attribute_02=>'POPUP'
,p_attribute_03=>'NONE'
,p_attribute_06=>'NONE'
,p_attribute_09=>'N'
,p_attribute_11=>'Y'
,p_is_required=>false
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_date_ranges=>'ALL'
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
,p_updated_on=>wwv_flow_imp.dz('20260211054058Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(340403883918329203)
,p_name=>'BJ_MOTIVO'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'BJ_MOTIVO'
,p_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_SELECT_LIST'
,p_heading=>'Motivo'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>150
,p_value_alignment=>'LEFT'
,p_is_required=>false
,p_lov_type=>'SHARED'
,p_lov_id=>wwv_flow_imp.id(336839242037362526)
,p_lov_display_extra=>false
,p_lov_display_null=>false
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'LOV'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
,p_updated_on=>wwv_flow_imp.dz('20260211054058Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(351293442892162510)
,p_name=>'DESCRIPCION3'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'DESCRIPCION3'
,p_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>unistr('Descripci\00F3n')
,p_heading_alignment=>'LEFT'
,p_display_sequence=>100
,p_value_alignment=>'LEFT'
,p_attribute_05=>'BOTH'
,p_is_required=>true
,p_max_length=>30
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
,p_updated_on=>wwv_flow_imp.dz('20260211054058Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_interactive_grid(
 p_id=>wwv_flow_imp.id(105519366485239511)
,p_internal_uid=>105519366485239511
,p_is_editable=>true
,p_edit_operations=>'d'
,p_lost_update_check_type=>'VALUES'
,p_submit_checked_rows=>false
,p_lazy_loading=>false
,p_requires_filter=>false
,p_select_first_row=>true
,p_fixed_row_height=>true
,p_pagination_type=>'SCROLL'
,p_show_total_row_count=>true
,p_show_toolbar=>true
,p_toolbar_buttons=>'SEARCH_COLUMN:SEARCH_FIELD:ACTIONS_MENU:SAVE'
,p_enable_save_public_report=>false
,p_enable_subscriptions=>true
,p_enable_flashback=>true
,p_define_chart_view=>true
,p_enable_download=>true
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>true
,p_fixed_header=>'PAGE'
,p_show_icon_view=>false
,p_show_detail_view=>false
,p_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'function (config) {',
'    return cargarToolbar(config);',
'}'))
,p_updated_on=>wwv_flow_imp.dz('20260211054058Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_ig_report(
 p_id=>wwv_flow_imp.id(105551761678828478)
,p_interactive_grid_id=>wwv_flow_imp.id(105519366485239511)
,p_static_id=>'1055518'
,p_type=>'PRIMARY'
,p_default_view=>'GRID'
,p_show_row_number=>false
,p_settings_area_expanded=>true
,p_updated_on=>wwv_flow_imp.dz('20260211054058Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_ig_report_view(
 p_id=>wwv_flow_imp.id(105551946699828484)
,p_report_id=>wwv_flow_imp.id(105551761678828478)
,p_view_type=>'GRID'
,p_srv_exclude_null_values=>false
,p_srv_only_display_columns=>true
,p_edit_mode=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(105552311826828501)
,p_view_id=>wwv_flow_imp.id(105551946699828484)
,p_display_seq=>1
,p_column_id=>wwv_flow_imp.id(105519432130239512)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(105553285856828510)
,p_view_id=>wwv_flow_imp.id(105551946699828484)
,p_display_seq=>2
,p_column_id=>wwv_flow_imp.id(105519541796239513)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(105554179945828515)
,p_view_id=>wwv_flow_imp.id(105551946699828484)
,p_display_seq=>3
,p_column_id=>wwv_flow_imp.id(105519669265239514)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(105555977355828522)
,p_view_id=>wwv_flow_imp.id(105551946699828484)
,p_display_seq=>5
,p_column_id=>wwv_flow_imp.id(105519871554239516)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(105556892909828526)
,p_view_id=>wwv_flow_imp.id(105551946699828484)
,p_display_seq=>6
,p_column_id=>wwv_flow_imp.id(105519911403239517)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(105557790469828530)
,p_view_id=>wwv_flow_imp.id(105551946699828484)
,p_display_seq=>7
,p_column_id=>wwv_flow_imp.id(105520000229239518)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(105558685531828534)
,p_view_id=>wwv_flow_imp.id(105551946699828484)
,p_display_seq=>8
,p_column_id=>wwv_flow_imp.id(105520189345239519)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(105559588703828537)
,p_view_id=>wwv_flow_imp.id(105551946699828484)
,p_display_seq=>9
,p_column_id=>wwv_flow_imp.id(105520262843239520)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(105560462176828542)
,p_view_id=>wwv_flow_imp.id(105551946699828484)
,p_display_seq=>10
,p_column_id=>wwv_flow_imp.id(105520323724239521)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(105564239502831498)
,p_view_id=>wwv_flow_imp.id(105551946699828484)
,p_display_seq=>0
,p_column_id=>wwv_flow_imp.id(105520631460239524)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(340753929942375946)
,p_view_id=>wwv_flow_imp.id(105551946699828484)
,p_display_seq=>13
,p_column_id=>wwv_flow_imp.id(340403788244329202)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(340754827473375956)
,p_view_id=>wwv_flow_imp.id(105551946699828484)
,p_display_seq=>14
,p_column_id=>wwv_flow_imp.id(340403883918329203)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(351402315396001325)
,p_view_id=>wwv_flow_imp.id(105551946699828484)
,p_display_seq=>15
,p_column_id=>wwv_flow_imp.id(351293442892162510)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(104337715422987333)
,p_plug_name=>'Ocultos'
,p_region_name=>'regOcultos'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(38289867500120143)
,p_plug_display_sequence=>1
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(104338637354987342)
,p_plug_name=>'Detalle de Baja'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(95503811913299190)
,p_plug_display_sequence=>25
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(102876931994640632)
,p_name=>'Baja seleccionada'
,p_parent_plug_id=>wwv_flow_imp.id(104338637354987342)
,p_template=>wwv_flow_imp.id(38289867500120143)
,p_display_sequence=>30
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_display_point=>'SUB_REGIONS'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select id',
'	, coderp',
'	, codactivo',
'	, descripcion1',
'	, descripcion2',
'	, descripcion3',
'	, codtipo',
'	, codcategoria',
'	, codsubcategoria',
'	, estado',
'	, codubicacion',
'	, codcustodio',
'from data.t_finz_activosfijos',
'where 1 = 1',
'	and compania = :g_compania',
'	and id = :p464_seleccionado'))
,p_ajax_enabled=>'Y'
,p_ajax_items_to_submit=>'P464_SELECCIONADO'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(37830327650106535)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
,p_updated_on=>wwv_flow_imp.dz('20260211052657Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(104335428809987310)
,p_query_column_id=>1
,p_column_alias=>'ID'
,p_column_display_sequence=>10
,p_use_as_row_header=>'N'
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(104335552465987311)
,p_query_column_id=>2
,p_column_alias=>'CODERP'
,p_column_display_sequence=>20
,p_column_heading=>unistr('C\00F3d. ERP')
,p_use_as_row_header=>'N'
,p_column_alignment=>'CENTER'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(104335678000987312)
,p_query_column_id=>3
,p_column_alias=>'CODACTIVO'
,p_column_display_sequence=>30
,p_column_heading=>unistr('C\00F3d. Activo')
,p_use_as_row_header=>'N'
,p_column_alignment=>'CENTER'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(104335794480987313)
,p_query_column_id=>4
,p_column_alias=>'DESCRIPCION1'
,p_column_display_sequence=>70
,p_column_heading=>unistr('Descripci\00F3n 1')
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20260211052657Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(351293263802162508)
,p_query_column_id=>5
,p_column_alias=>'DESCRIPCION2'
,p_column_display_sequence=>80
,p_column_heading=>'Descripcion 2'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20260211052657Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(351293369228162509)
,p_query_column_id=>6
,p_column_alias=>'DESCRIPCION3'
,p_column_display_sequence=>90
,p_column_heading=>'Descripcion 3'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20260211052657Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(104335853248987314)
,p_query_column_id=>7
,p_column_alias=>'CODTIPO'
,p_column_display_sequence=>40
,p_column_heading=>'Tipo'
,p_use_as_row_header=>'N'
,p_column_alignment=>'CENTER'
,p_disable_sort_column=>'N'
,p_display_as=>'TEXT_FROM_LOV_ESC'
,p_named_lov=>wwv_flow_imp.id(98576969558658537)
,p_derived_column=>'N'
,p_include_in_export=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20260211052657Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(104335937790987315)
,p_query_column_id=>8
,p_column_alias=>'CODCATEGORIA'
,p_column_display_sequence=>50
,p_column_heading=>unistr('Categor\00EDa')
,p_use_as_row_header=>'N'
,p_column_alignment=>'CENTER'
,p_disable_sort_column=>'N'
,p_display_as=>'TEXT_FROM_LOV_ESC'
,p_named_lov=>wwv_flow_imp.id(98577560814666584)
,p_derived_column=>'N'
,p_include_in_export=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20260211052657Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(104336088275987316)
,p_query_column_id=>9
,p_column_alias=>'CODSUBCATEGORIA'
,p_column_display_sequence=>60
,p_column_heading=>unistr('Subcategor\00EDa')
,p_use_as_row_header=>'N'
,p_column_alignment=>'CENTER'
,p_disable_sort_column=>'N'
,p_display_as=>'TEXT_FROM_LOV_ESC'
,p_named_lov=>wwv_flow_imp.id(98577774561669941)
,p_derived_column=>'N'
,p_include_in_export=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20260211052657Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(104336160254987317)
,p_query_column_id=>10
,p_column_alias=>'ESTADO'
,p_column_display_sequence=>110
,p_hidden_column=>'Y'
,p_derived_column=>'N'
,p_updated_on=>wwv_flow_imp.dz('20260211052657Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(104336255136987318)
,p_query_column_id=>11
,p_column_alias=>'CODUBICACION'
,p_column_display_sequence=>120
,p_hidden_column=>'Y'
,p_derived_column=>'N'
,p_updated_on=>wwv_flow_imp.dz('20260211052657Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(104336395735987319)
,p_query_column_id=>12
,p_column_alias=>'CODCUSTODIO'
,p_column_display_sequence=>130
,p_hidden_column=>'Y'
,p_derived_column=>'N'
,p_updated_on=>wwv_flow_imp.dz('20260211052657Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(104338745562987343)
,p_plug_name=>'Campos baja'
,p_parent_plug_id=>wwv_flow_imp.id(104338637354987342)
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(38289867500120143)
,p_plug_display_sequence=>40
,p_plug_display_point=>'SUB_REGIONS'
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(102171583661365846)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(102865827570569560)
,p_button_name=>'Cancelar'
,p_button_static_id=>'btnRetornar'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860056812106557)
,p_button_image_alt=>'Cancelar'
,p_button_position=>'ABOVE_BOX'
,p_button_alignment=>'LEFT'
,p_button_redirect_url=>'f?p=&APP_ID.:460:&SESSION.::&DEBUG.:::'
,p_icon_css_classes=>'fa-long-arrow-left'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(102171646086365847)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(102865827570569560)
,p_button_name=>'NuevaBaja'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860056812106557)
,p_button_image_alt=>'Nueva baja'
,p_button_position=>'ABOVE_BOX'
,p_button_alignment=>'RIGHT'
,p_icon_css_classes=>'fa-arrow-circle-o-down'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(102171769662365848)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(102865827570569560)
,p_button_name=>'Guardar'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860056812106557)
,p_button_image_alt=>'Guabar Baja'
,p_button_position=>'ABOVE_BOX'
,p_button_alignment=>'RIGHT'
,p_button_condition=>'1=2'
,p_button_condition2=>'PLSQL'
,p_button_condition_type=>'EXPRESSION'
,p_icon_css_classes=>'fa-save'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(102171845127365849)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(102865827570569560)
,p_button_name=>'Generar'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860056812106557)
,p_button_image_alt=>'Generar Acta'
,p_button_position=>'ABOVE_BOX'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
,p_button_condition=>'1=2'
,p_button_condition2=>'PLSQL'
,p_button_condition_type=>'EXPRESSION'
,p_icon_css_classes=>'fa-file-pdf-o'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(102875578413640618)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(102865827570569560)
,p_button_name=>'Buscar'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860056812106557)
,p_button_image_alt=>'Buscar'
,p_button_position=>'ABOVE_BOX'
,p_button_alignment=>'RIGHT'
,p_icon_css_classes=>'fa-search'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(102876147137640624)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(102865827570569560)
,p_button_name=>'Seleccionar'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860056812106557)
,p_button_image_alt=>'Seleccionar'
,p_button_position=>'ABOVE_BOX'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
,p_button_condition=>'1=2'
,p_button_condition2=>'PLSQL'
,p_button_condition_type=>'EXPRESSION'
,p_icon_css_classes=>'fa-check-square-o'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(104976695889980215)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(102865827570569560)
,p_button_name=>'Enviar'
,p_button_action=>'REDIRECT_APP'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860056812106557)
,p_button_image_alt=>'Enviar a ruta'
,p_button_position=>'ABOVE_BOX'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=100:101:&SESSION.::&DEBUG.::G_MODULO,G_COMPANIA,G_TIPO1,G_OBJETO_ID,G_USUARIO,G_OBJETO:&APP_MODULO.,&G_COMPANIA.,BAJAS,&P464_MAXGRUPOBAJA.,&APP_USER.,BAJAS'
,p_button_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select 1',
'from t_finz_activosfijos',
'where 1 = 1',
'	and compania = :g_compania',
'	and estado = ''BAJASOLICITADA''',
'	and bj_usuario = :app_user',
'	and idflujo is null',
'	and :P464_CENTROCOSTO is not null'))
,p_button_condition_type=>'EXISTS'
,p_icon_css_classes=>'fa-paper-plane'
,p_updated_on=>wwv_flow_imp.dz('20260227174545Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(104339084203987346)
,p_button_sequence=>50
,p_button_plug_id=>wwv_flow_imp.id(104338745562987343)
,p_button_name=>'GrabarBaja'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860056812106557)
,p_button_image_alt=>'Grabar Baja'
,p_button_position=>'ABOVE_BOX'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-save'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(104336689209987322)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(102877046307640633)
,p_button_name=>'Cargar'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860056812106557)
,p_button_image_alt=>'Cargar'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_icon_css_classes=>'fa-file-arrow-up'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(104337223447987328)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(102877046307640633)
,p_button_name=>'VerDocumentos'
,p_button_action=>'REDIRECT_APP'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860056812106557)
,p_button_image_alt=>'Ver Documentos'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=100:401:&SESSION.::&DEBUG.:401:P401_TABLA,P401_TIPO,P401_ESTADO,P401_ID:T_FINZ_ACTIVOSFIJOS,BAJA_ACTIVO,1,&G_VALOR1.'
,p_icon_css_classes=>'fa-eye'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(102873807562640601)
,p_name=>'P464_COMPANIA'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(102171997695365850)
,p_item_default=>':G_COMPANIA'
,p_item_default_type=>'EXPRESSION'
,p_item_default_language=>'PLSQL'
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(102873966074640602)
,p_name=>'P464_TIPO'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(102171997695365850)
,p_prompt=>'Tipo: '
,p_source=>'999'
,p_source_type=>'STATIC'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'LOV_AFI_TIPO'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select DRDL01 D, DRKY R',
'from vt_jde_udcjde where drsy = ''12'' and drrt = ''21''',
'and DRKY is not null',
'order by 2;'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'Seleccione'
,p_lov_null_value=>'999'
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(102874043822640603)
,p_name=>'P464_CATEGORIA'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(102171997695365850)
,p_prompt=>unistr('Categor\00EDa: ')
,p_source=>'999'
,p_source_type=>'STATIC'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select DRKY||''-''||DRDL01 D, DRKY R',
'from vt_jde_udcjde where drsy = ''12'' and drrt = ''22''',
'and substr(DRKY,1,1)=:P464_TIPO',
'order by 2;'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'Seleccione'
,p_lov_null_value=>'999'
,p_lov_cascade_parent_items=>'P464_TIPO'
,p_ajax_optimize_refresh=>'Y'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(102874145532640604)
,p_name=>'P464_SUBCATEGORIA'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(102171997695365850)
,p_prompt=>unistr('Subcategor\00EDa: ')
,p_source=>'999'
,p_source_type=>'STATIC'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select DRKY||''-''||DRDL01 D, DRKY R',
'from vt_jde_udcjde where drsy = ''12'' and drrt = ''23''',
'and substr(DRKY,1,4)=:P464_CATEGORIA',
'order by 2;'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'Seleccione'
,p_lov_null_value=>'999'
,p_lov_cascade_parent_items=>'P464_CATEGORIA'
,p_ajax_optimize_refresh=>'Y'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(102874234518640605)
,p_name=>'P464_ESTADO'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(102171997695365850)
,p_prompt=>'Estado: '
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'LOV_AFI_ESTADOS'
,p_lov=>'.'||wwv_flow_imp.id(103056739471701431)||'.'
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_colspan=>4
,p_display_when_type=>'NEVER'
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'SUBMIT'
,p_attribute_03=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20260210055248Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(102875769491640620)
,p_name=>'P464_TODOS'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(102171997695365850)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(102875856594640621)
,p_name=>'P464_SINSELECCION'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(102171997695365850)
,p_item_default=>'1'
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(102876587715640628)
,p_name=>'P464_SELECCIONADOS'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(102171997695365850)
,p_item_default=>'1'
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(102877538279640638)
,p_name=>'P464_ARCHIVO'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(102877319682640636)
,p_prompt=>'Archivo'
,p_display_as=>'NATIVE_FILE'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'APEX_APPLICATION_TEMP_FILES'
,p_attribute_09=>'SESSION'
,p_attribute_10=>'N'
,p_attribute_12=>'INLINE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(102877657536640639)
,p_name=>'P464_OBSERVACION'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(102877319682640636)
,p_prompt=>unistr('Observaci\00F3n: ')
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(104336561793987321)
,p_name=>'P464_SELECCIONADO'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(102171997695365850)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(104337451604987330)
,p_name=>'P464_IDREGISTRO'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(102171997695365850)
,p_item_default=>'P464_SELECCIONADO'
,p_item_default_type=>'ITEM'
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(104338386200987339)
,p_name=>'P464_MOTIVOBAJA'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(104338745562987343)
,p_prompt=>'Motivo Baja: '
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'LOV_AFI_CODESTADO'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select drky codigo, drky||'' - ''||drdl01 descripcion',
'from data.vt_jde_udcjde where drsy = ''12'' and drrt = ''ES'' and drky is not null'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'Seleccione'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'NONE'
,p_updated_on=>wwv_flow_imp.dz('20260210054912Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(104338401353987340)
,p_name=>'P464_FECHABAJA'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(104338745562987343)
,p_prompt=>'Fecha: '
,p_display_as=>'NATIVE_DATE_PICKER_APEX'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'POPUP'
,p_attribute_03=>'ITEM'
,p_attribute_05=>'P464_FECHAMIN'
,p_attribute_06=>'ITEM'
,p_attribute_08=>'P464_FECHAMAX'
,p_attribute_09=>'N'
,p_attribute_11=>'N'
,p_attribute_12=>'TODAY-BUTTON'
,p_attribute_13=>'VISIBLE'
,p_attribute_15=>'FOCUS'
,p_updated_on=>wwv_flow_imp.dz('20260227050325Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(104338521145987341)
,p_name=>'P464_OBSERVACIONBAJA'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(104338745562987343)
,p_prompt=>unistr('Observaci\00F3n: ')
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_updated_on=>wwv_flow_imp.dz('20260211052923Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(104338815053987344)
,p_name=>'P464_BANDERAADJUNTOS'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_imp.id(102171997695365850)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(104338909709987345)
,p_name=>'P464_MAXGRUPOBAJA'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(104337715422987333)
,p_prompt=>'New'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_updated_on=>wwv_flow_imp.dz('20260227045930Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(104976757143980216)
,p_name=>'P464_ENVIO_EXITO'
,p_item_sequence=>120
,p_item_plug_id=>wwv_flow_imp.id(102171997695365850)
,p_item_default=>'1'
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(104976898981980217)
,p_name=>'P464_TERMINA_FLUJO'
,p_item_sequence=>130
,p_item_plug_id=>wwv_flow_imp.id(102171997695365850)
,p_item_default=>'1'
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(104977503997980224)
,p_name=>'P464_ID_FLUJO'
,p_item_sequence=>140
,p_item_plug_id=>wwv_flow_imp.id(102171997695365850)
,p_item_default=>'1'
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(108679136147627624)
,p_name=>'P464_FECHAMIN'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(104337715422987333)
,p_prompt=>'Fechamin'
,p_display_as=>'NATIVE_DATE_PICKER_APEX'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'POPUP'
,p_attribute_03=>'NONE'
,p_attribute_06=>'NONE'
,p_attribute_09=>'N'
,p_attribute_11=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20260227045930Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(108679310991627626)
,p_name=>'P464_CONTADORBAJAS'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(104337715422987333)
,p_prompt=>'Contadorbajas'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_03=>'left'
,p_attribute_04=>'decimal'
,p_updated_on=>wwv_flow_imp.dz('20260227045930Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(108680461081627637)
,p_name=>'P464_JASPER_URL'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(104337715422987333)
,p_prompt=>'Jasper Url'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT DESCRIPCION',
'FROM T_CORP_UDC WHERE ID_CABECERA=''RRHH'' AND ID_TABLA=''URL_BAJAACTIVOS'';'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_updated_on=>wwv_flow_imp.dz('20260227045930Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(351293624644162512)
,p_name=>'P464_CENTROCOSTO'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(104337715422987333)
,p_prompt=>'Centrocosto'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_created_on=>wwv_flow_imp.dz('20260211063420Z')
,p_updated_on=>wwv_flow_imp.dz('20260227045930Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(371139523151976401)
,p_name=>'P464_FECHAMAX'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(104337715422987333)
,p_prompt=>'Fechamax'
,p_display_as=>'NATIVE_DATE_PICKER_APEX'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'POPUP'
,p_attribute_03=>'NONE'
,p_attribute_06=>'NONE'
,p_attribute_09=>'N'
,p_attribute_11=>'Y'
,p_created_on=>wwv_flow_imp.dz('20260227045930Z')
,p_updated_on=>wwv_flow_imp.dz('20260227045930Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(102875957700640622)
,p_name=>unistr('Selecci\00F3n')
,p_event_sequence=>10
,p_triggering_element_type=>'JQUERY_SELECTOR'
,p_triggering_element=>'.chkF01'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(102876004365640623)
,p_event_id=>wwv_flow_imp.id(102875957700640622)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P464_SINSELECCION'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'var lineas ="";',
'document.querySelectorAll(''.chkF01'').forEach(function(seleccion) {',
'    if(seleccion.checked){',
'        var linea = seleccion.value',
'        if(lineas==""){',
'            lineas = linea;',
'        }else{',
'            lineas = lineas+'',''+linea;',
'        }      ',
'    }',
'',
'});',
'console.log(''lineas selecionadas: ''+lineas);',
'apex.item("P464_SINSELECCION").setValue(lineas);'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(104335289248987308)
,p_name=>unistr('seleccionconBot\00F3n')
,p_event_sequence=>20
,p_triggering_element_type=>'JQUERY_SELECTOR'
,p_triggering_element=>'.chkF02'
,p_bind_type=>'live'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(104335380266987309)
,p_event_id=>wwv_flow_imp.id(104335289248987308)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P464_SELECCIONADO'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'var lineas ="";',
'document.querySelectorAll(''.chkF02'').forEach(function(seleccion) {',
'    if(seleccion.checked){',
'        var linea = seleccion.value',
'        if(lineas==""){',
'            lineas = linea;',
'        }else{',
'            //lineas = lineas+'',''+linea;',
'            lineas = linea;',
'        }      ',
'    }',
'',
'});',
'console.log(''linea selecionada: ''+lineas);',
'apex.item("P464_SELECCIONADO").setValue(lineas);'))
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(104337674135987332)
,p_event_id=>wwv_flow_imp.id(104335289248987308)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>':G_VALOR1:=:P464_SELECCIONADO;'
,p_attribute_02=>'P464_SELECCIONADO'
,p_attribute_03=>'G_VALOR1'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(104337974472987335)
,p_event_id=>wwv_flow_imp.id(104335289248987308)
,p_event_result=>'TRUE'
,p_action_sequence=>50
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_02=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(102876251327640625)
,p_name=>'Marcar'
,p_event_sequence=>30
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(102876147137640624)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(102876361353640626)
,p_event_id=>wwv_flow_imp.id(102876251327640625)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'IF(NVL(:P464_TODOS,0)=1) THEN',
'    :P464_TODOS:=0;',
'ELSE ',
'    :P464_TODOS:=1;',
'END IF;'))
,p_attribute_02=>'P464_TODOS'
,p_attribute_03=>'P464_TODOS'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(102876433634640627)
,p_event_id=>wwv_flow_imp.id(102876251327640625)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P464_SELECCIONADOS'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'var lineas =""; ',
'document.querySelectorAll(''.chkF01'').forEach(function(seleccion) {',
'    if(seleccion.checked){',
'        var linea = seleccion.value',
'        if(lineas==""){',
'            lineas = linea;',
'        }else{',
'            lineas = lineas+'',''+linea;',
'        }      ',
'    }',
'    ',
'});',
'console.log(''lineas seleccionadas masivamente: ''+lineas);',
'apex.item("P464_SELECCIONADOS").setValue(lineas);'))
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(102876646351640629)
,p_event_id=>wwv_flow_imp.id(102876251327640625)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(102874374945640606)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(104336775179987323)
,p_name=>'Cargardocumento'
,p_event_sequence=>40
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(104336689209987322)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
,p_display_when_type=>'EXPRESSION'
,p_display_when_cond=>'1=2'
,p_display_when_cond2=>'PLSQL'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(104336813005987324)
,p_event_id=>wwv_flow_imp.id(104336775179987323)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'-- cargo archivo a la tabla definitiva',
'declare v_valor number;',
'begin',
'	data.pk_apex_archivos.sp_creararchivo(',
'		:P464_ARCHIVO',
'		, ''T_FINZ_ACTIVOSFIJOS''',
'		, :P464_SELECCIONADO',
'		, ''BAJA_ACTIVO''',
'		, :P464_OBSERVACION',
'		, :app_user',
'		, v_valor',
'	);',
'',
'	update files.t_apex_archivos set estado = 1 where numeroarchivo = v_valor;',
'end;',
''))
,p_attribute_02=>'P464_SELECCIONADO,P464_ARCHIVO,P464_OBSERVACION'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(104336962899987325)
,p_event_id=>wwv_flow_imp.id(104336775179987323)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(102877046307640633)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(104339103824987347)
,p_name=>'GrabaBaja'
,p_event_sequence=>50
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(104339084203987346)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
,p_updated_on=>wwv_flow_imp.dz('20260211063420Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(104339279861987348)
,p_event_id=>wwv_flow_imp.id(104339103824987347)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'	v_grupo number := 0;',
'begin',
'	if nvl(:p464_banderaadjuntos, 0) = 0 then',
unistr('		-- obtengo el m\00E1ximo n\00FAmero de grupo'),
'		select nvl(max(bj_codigo), 0) + 1',
'		into v_grupo',
'		from t_finz_activosfijos;',
'	else',
'		v_grupo := :p464_maxgrupobaja;',
'	end if;',
'	-- genero LOG',
'	pk_finz_activosfijos.sp_log(:g_compania, ''T_FINZ_ACTIVOSFIJOS'', :p464_seleccionado, '''', '''', ''BEFORE_BAJA'', :app_page_id, '''', ''GRABA BAJA ACTIVO FIJO'');',
'	update t_finz_activosfijos',
'	set bj_codigo = v_grupo',
'		, bj_usuario = :app_user',
'		, bj_fechasol = :p464_fechabaja',
'		, bj_motivo = :p464_motivobaja',
'		, estado = ''BAJASOLICITADA''',
'		, notas = :p464_observacionbaja',
'	where 1 = 1',
'		and id = :p464_seleccionado;',
'	-- genero LOG',
'	pk_finz_activosfijos.sp_log(:g_compania, ''T_FINZ_ACTIVOSFIJOS'', :p464_seleccionado, '''', '''', ''AFTER_BAJA'', :app_page_id, '''', ''GRABA BAJA ACTIVO FIJO'');',
'	if nvl(:p464_banderaadjuntos, 0) = 0 then',
'		:p464_maxgrupobaja := v_grupo;',
'		:p464_banderaadjuntos := 1;',
'	end if;',
'	:p464_fechabaja := '''';',
'	:p464_motivobaja := '''';',
'	:p464_observacionbaja := '''';',
'end;'))
,p_attribute_02=>'P464_SELECCIONADO,P464_FECHABAJA,P464_OBSERVACIONBAJA,P464_BANDERAADJUNTOS,P464_MAXGRUPOBAJA,P464_MOTIVOBAJA'
,p_attribute_03=>'P464_MAXGRUPOBAJA,P464_BANDERAADJUNTOS,P464_FECHABAJA,P464_MOTIVOBAJA,P464_OBSERVACIONBAJA'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20260211063420Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(104976523731980214)
,p_event_id=>wwv_flow_imp.id(104339103824987347)
,p_event_result=>'TRUE'
,p_action_sequence=>50
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_02=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(104976996201980218)
,p_name=>unistr('Cierre di\00E1logo: envio a flujo')
,p_event_sequence=>60
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(104976695889980215)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(104977040690980219)
,p_event_id=>wwv_flow_imp.id(104976996201980218)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P464_ENVIO_EXITO,P464_ID_FLUJO'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'var trama = JSON.parse(this.data.G_RESULTADO);     ',
'var flujo = trama.resultado.flujo;',
'',
'console.log(this.data)',
'if(this.data.G_EXITO==''true''){',
'      mensaje(''exito'', this.data.G_MENSAJE);',
'',
'     apex.item( "P464_ENVIO_EXITO" ).setValue(1);',
'     apex.item("P464_ID_FLUJO").setValue(flujo.flujoId);',
'}',
'else{ ',
'   mensaje(''error'', this.data.G_MENSAJE);',
'     apex.item( "P464_ENVIO_EXITO" ).setValue(0);',
'}'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(104977144443980220)
,p_name=>unistr('Cierre di\00E1logo: envio exito')
,p_event_sequence=>70
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(104976695889980215)
,p_condition_element=>'P464_ENVIO_EXITO'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'1'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
,p_updated_on=>wwv_flow_imp.dz('20260227180519Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(104977251821980221)
,p_event_id=>wwv_flow_imp.id(104977144443980220)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'mostrarBarra();'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(104977385213980222)
,p_event_id=>wwv_flow_imp.id(104977144443980220)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
unistr('-- obtengo el ID del flujo de aprobaci\00F3n'),
'SELECT ID INTO :P464_ID_FLUJO',
'FROM T_FLUJO_APROBACION_CAB',
'WHERE CODMODULO = ''FINZ''',
'	AND ENTIDAD_CLASE = ''BAJAS''',
'	AND ENTIDAD_ID = :P464_MAXGRUPOBAJA',
'	AND ESTADO = ''EN_PROCESO'';',
'',
'UPDATE T_FINZ_ACTIVOSFIJOS SET IDFLUJO = :P464_ID_FLUJO, estado = ''BAJAAPROBACION'' WHERE bj_codigo=:P464_MAXGRUPOBAJA;'))
,p_attribute_02=>'P464_ID_FLUJO,P464_MAXGRUPOBAJA'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20260227180519Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(104977431091980223)
,p_event_id=>wwv_flow_imp.id(104977144443980220)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'ocultarBarra();',
'$(''#btnRetornar'').trigger("click");'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(105520910283239527)
,p_name=>'Refrescar'
,p_event_sequence=>80
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(104975266990980201)
,p_bind_type=>'live'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'NATIVE_IG|REGION TYPE|interactivegridsave'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(105521017936239528)
,p_event_id=>wwv_flow_imp.id(105520910283239527)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_02=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(108680507643627638)
,p_name=>'Generar acta'
,p_event_sequence=>90
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(102171845127365849)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(108680614405627639)
,p_event_id=>wwv_flow_imp.id(108680507643627638)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>':P464_JASPER_URL:=:P464_JASPER_URL||''/ActaBajaActivos''||''&decorate=no&j_username=jasperadmin&j_password=jasperadmin&output=pdf&P_USUARIO=&APP_USER.&P_GRUPOBAJA=&P464_MAXGRUPOBAJA.'';'
,p_attribute_02=>'P464_JASPER_URL,P464_MAXGRUPOBAJA'
,p_attribute_03=>'P464_JASPER_URL'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(108680794497627640)
,p_event_id=>wwv_flow_imp.id(108680507643627638)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P464_JASPER_URL'
,p_attribute_01=>'javascript:window.open($v( "P464_JASPER_URL" ),''_blank'');'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(102876815200640631)
,p_process_sequence=>10
,p_process_point=>'AFTER_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'SetUp'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'v_grupo1 number := 0;',
'begin',
'	:p464_fechamin := trunc(add_months(sysdate,-1),''month'');',
'	:p464_fechamax := trunc(sysdate);',
'',
'	begin',
'		select max(bj_codigo)',
'		into v_grupo1',
'		from data.t_finz_activosfijos',
'		where 1 = 1',
'			and bj_usuario = :app_user',
'			and estado = ''BAJASOLICITADA'';',
'',
'		exception when no_data_found then v_grupo1 := 0;',
'	end;',
'',
'	begin',
'		select centrocosto into :p464_centrocosto',
'		from data.t_finz_activosfijos',
'		where 1 = 1',
'			and bj_codigo = v_grupo1',
'			and rownum = 1;',
'',
'		exception when others then :p464_centrocosto := null;',
'	end;',
'',
'	if nvl(v_grupo1, 0) > 0 then',
'		:p464_maxgrupobaja := v_grupo1;',
'		:p464_banderaadjuntos := 1;',
'	else',
'		:p464_banderaadjuntos := 0;',
'		:p464_maxgrupobaja := '''';',
'	end if;',
'',
'	select count(*)',
'	into :p464_contadorbajas',
'	from t_finz_activosfijos',
'	where 1 = 1',
'		and compania = :g_compania',
'		and estado = ''BAJASOLICITADA''',
'		and bj_usuario = :app_user',
'		and idflujo is null;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>102876815200640631
,p_updated_on=>wwv_flow_imp.dz('20260227050106Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(104337025305987326)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Cargar Documentos'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'-- cargo archivo a la tabla definitiva',
'declare v_valor number;',
'begin',
'	data.pk_apex_archivos.sp_creararchivo(',
'		:P464_ARCHIVO',
'		, ''T_FINZ_ACTIVOSFIJOS''',
'		, :P464_SELECCIONADO',
'		, ''BAJA_ACTIVO''',
'		, :P464_OBSERVACION',
'		, :app_user',
'		, v_valor',
'	);',
'',
'	update files.t_apex_archivos set estado = 1 where numeroarchivo = v_valor;',
'end;',
''))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(104336689209987322)
,p_internal_uid=>104337025305987326
,p_updated_on=>wwv_flow_imp.dz('20260211054729Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(104338279663987338)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Grabar _baja'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'	v_grupo number := 0;',
'begin',
'	if nvl(:p464_banderaadjuntos, 0) = 0 then',
unistr('		-- obtengo el m\00E1ximo n\00FAmero de grupo'),
'		select nvl(max(bj_codigo), 0) + 1',
'		into v_grupo',
'		from t_finz_activosfijos;',
'	else',
'		v_grupo := :p464_maxgrupobaja;',
'	end if;',
'',
'	update t_finz_activosfijos',
'	set bj_codigo = v_grupo',
'		, bj_usuario = :app_user',
'		, bj_fechasol = sysdate',
'		, bj_motivo = :p464_motivobaja',
'		, estado = ''BAJASOLICITADA''',
'		, notas = :p464_observacionbaja',
'	where 1 = 1',
'		and id = :p464_seleccionado;',
'',
'	if nvl(:p464_banderaadjuntos, 0) = 0 then',
'		:p464_maxgrupobaja := v_grupo;',
'		:p464_banderaadjuntos := 1;',
'	end if;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(102171769662365848)
,p_internal_uid=>104338279663987338
,p_updated_on=>wwv_flow_imp.dz('20260211054729Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(105520863117239526)
,p_process_sequence=>30
,p_process_point=>'AFTER_SUBMIT'
,p_region_id=>wwv_flow_imp.id(104975266990980201)
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Bajas en Proceso - Save Interactive Grid Data'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'case :apex$row_status',
'	when ''D'' then',
'		update t_finz_activosfijos',
'		set estado = ''ENVIADO''',
'			, bj_codigo = null',
'			, bj_usuario = null',
'			, bj_fechasol = null',
'			, bj_motivo = null',
'			, notas = null',
'		where 1 = 1',
'			and id = :id;',
'end case;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>105520863117239526
,p_updated_on=>wwv_flow_imp.dz('20260211055601Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp.component_end;
end;
/
