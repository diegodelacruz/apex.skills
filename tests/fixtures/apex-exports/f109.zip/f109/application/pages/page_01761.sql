prompt --application/pages/page_01761
begin
--   Manifest
--     PAGE: 01761
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>109
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_page.create_page(
 p_id=>1761
,p_name=>unistr('Detalle Costo Orden Producci\00F3n')
,p_alias=>unistr('DETALLE-COSTO-ORDEN-PRODUCCI\00D3N')
,p_step_title=>unistr('Detalle Costo Orden Producci\00F3n')
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_page_component_map=>'16'
,p_created_on=>wwv_flow_imp.dz('20250621214736Z')
,p_last_updated_on=>wwv_flow_imp.dz('20250623133815Z')
,p_created_by=>'DBURBANO'
,p_last_updated_by=>'DBURBANO'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(74394780006550431)
,p_plug_name=>'Cabecera'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(38289867500120143)
,p_plug_display_sequence=>10
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
,p_created_on=>wwv_flow_imp.dz('20250621215519Z')
,p_updated_on=>wwv_flow_imp.dz('20250621215520Z')
,p_created_by=>'DBURBANO'
,p_updated_by=>'DBURBANO'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(74395821571550442)
,p_plug_name=>'BarraAcciones'
,p_region_template_options=>'#DEFAULT#:t-Form--stretchInputs'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(38289497777120142)
,p_plug_display_sequence=>20
,p_plug_display_point=>'REGION_POSITION_01'
,p_location=>null
,p_menu_id=>wwv_flow_imp.id(37761271469106475)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(37860983999106559)
,p_created_on=>wwv_flow_imp.dz('20250621222108Z')
,p_updated_on=>wwv_flow_imp.dz('20250621222108Z')
,p_created_by=>'DBURBANO'
,p_updated_by=>'DBURBANO'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(78068151992370778)
,p_plug_name=>'Breadcrumb'
,p_title=>unistr('Detalle Orden Producci\00F3n')
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(37817215439106526)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_location=>null
,p_menu_id=>wwv_flow_imp.id(37761271469106475)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(37860983999106559)
,p_created_on=>wwv_flow_imp.dz('20250621214736Z')
,p_updated_on=>wwv_flow_imp.dz('20250621215048Z')
,p_created_by=>'DBURBANO'
,p_updated_by=>'DBURBANO'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(74395990630550443)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(74395821571550442)
,p_button_name=>'Regresa'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860056812106557)
,p_button_image_alt=>'Regresa'
,p_button_redirect_url=>'f?p=&APP_ID.:176:&SESSION.::&DEBUG.:::'
,p_icon_css_classes=>'fa-box-arrow-in-west'
,p_created_on=>wwv_flow_imp.dz('20250621222108Z')
,p_updated_on=>wwv_flow_imp.dz('20250621222108Z')
,p_created_by=>'DBURBANO'
,p_updated_by=>'DBURBANO'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(74396367636550447)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(74395821571550442)
,p_button_name=>'Graba'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860056812106557)
,p_button_image_alt=>'Graba'
,p_icon_css_classes=>'fa-save'
,p_created_on=>wwv_flow_imp.dz('20250622214302Z')
,p_updated_on=>wwv_flow_imp.dz('20250622214302Z')
,p_created_by=>'DBURBANO'
,p_updated_by=>'DBURBANO'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(74394881756550432)
,p_name=>'P1761_ORDEN'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(74394780006550431)
,p_prompt=>'ORDEN:'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
,p_created_on=>wwv_flow_imp.dz('20250621215519Z')
,p_updated_on=>wwv_flow_imp.dz('20250622221215Z')
,p_created_by=>'DBURBANO'
,p_updated_by=>'DBURBANO'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(74394916091550433)
,p_name=>'P1761_TIPOOT'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(74394780006550431)
,p_prompt=>'TIPO OT:'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
,p_created_on=>wwv_flow_imp.dz('20250621215519Z')
,p_updated_on=>wwv_flow_imp.dz('20250622221216Z')
,p_created_by=>'DBURBANO'
,p_updated_by=>'DBURBANO'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(74395027060550434)
,p_name=>'P1761_ITEM'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(74394780006550431)
,p_prompt=>'ITEM:'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
,p_created_on=>wwv_flow_imp.dz('20250621215520Z')
,p_updated_on=>wwv_flow_imp.dz('20250622221216Z')
,p_created_by=>'DBURBANO'
,p_updated_by=>'DBURBANO'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(74395247722550436)
,p_name=>'P1761_CANTIDAD'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(74394780006550431)
,p_prompt=>'CANTIDAD:'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
,p_created_on=>wwv_flow_imp.dz('20250621215520Z')
,p_updated_on=>wwv_flow_imp.dz('20250622221216Z')
,p_created_by=>'DBURBANO'
,p_updated_by=>'DBURBANO'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(74395375147550437)
,p_name=>'P1761_ORDENP'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(74394780006550431)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
,p_created_on=>wwv_flow_imp.dz('20250621215813Z')
,p_updated_on=>wwv_flow_imp.dz('20250622192159Z')
,p_created_by=>'DBURBANO'
,p_updated_by=>'DBURBANO'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(74395436241550438)
,p_name=>'P1761_TIPOCOSTO'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(74394780006550431)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
,p_created_on=>wwv_flow_imp.dz('20250621220127Z')
,p_updated_on=>wwv_flow_imp.dz('20250622192159Z')
,p_created_by=>'DBURBANO'
,p_updated_by=>'DBURBANO'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(74395533287550439)
,p_name=>'P1761_COSTOREAL'
,p_item_sequence=>120
,p_item_plug_id=>wwv_flow_imp.id(74394780006550431)
,p_prompt=>'COSTO REAL:'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_03=>'left'
,p_attribute_04=>'decimal'
,p_created_on=>wwv_flow_imp.dz('20250621220127Z')
,p_updated_on=>wwv_flow_imp.dz('20250622222043Z')
,p_created_by=>'DBURBANO'
,p_updated_by=>'DBURBANO'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(74395646293550440)
,p_name=>'P1761_HORASREAL'
,p_item_sequence=>130
,p_item_plug_id=>wwv_flow_imp.id(74394780006550431)
,p_prompt=>'HORAS REAL:'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_03=>'left'
,p_attribute_04=>'decimal'
,p_created_on=>wwv_flow_imp.dz('20250621220127Z')
,p_updated_on=>wwv_flow_imp.dz('20250622222043Z')
,p_created_by=>'DBURBANO'
,p_updated_by=>'DBURBANO'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(74396134315550445)
,p_name=>'P1761_IGMCU'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(74394780006550431)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
,p_created_on=>wwv_flow_imp.dz('20250622170604Z')
,p_updated_on=>wwv_flow_imp.dz('20250622192159Z')
,p_created_by=>'DBURBANO'
,p_updated_by=>'DBURBANO'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(74396247200550446)
,p_name=>'P1761_COSTO'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_imp.id(74394780006550431)
,p_prompt=>'Costo'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
,p_created_on=>wwv_flow_imp.dz('20250622192917Z')
,p_updated_on=>wwv_flow_imp.dz('20250622222043Z')
,p_created_by=>'DBURBANO'
,p_updated_by=>'DBURBANO'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(74396553690550449)
,p_name=>'P1761_ITM'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(74394780006550431)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
,p_created_on=>wwv_flow_imp.dz('20250622221215Z')
,p_updated_on=>wwv_flow_imp.dz('20250622221215Z')
,p_created_by=>'DBURBANO'
,p_updated_by=>'DBURBANO'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(74396636886550450)
,p_name=>'P1761_TRANS'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(74394780006550431)
,p_prompt=>unistr('TRANSACCI\00D3N:')
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
,p_created_on=>wwv_flow_imp.dz('20250622221409Z')
,p_updated_on=>wwv_flow_imp.dz('20250622222043Z')
,p_created_by=>'DBURBANO'
,p_updated_by=>'DBURBANO'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(74396459387550448)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Graba'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'aux NUMBER;',
'BEGIN',
'--SELECT count(*) INTO aux',
'--c.igclat/10000 CostoReal, c.igopat/10000 CostoEstandar, c.igcpat/10000 CostoFinalizado, c.igclun/10000 HorasReal, c.igcccu/10000 HorasEstandar',
'SELECT count(*) INTO aux',
'  FROM f3102@jdedtadl',
' WHERE igdoco = :P1761_ORDENP',
'   AND TRIM(igcost) = TRIM(:P1761_TIPOCOSTO)',
'   AND igitm = :P1761_ITM',
'   AND igmcu = :P1761_IGMCU',
';',
'',
'IF aux = 1 THEN',
'    UPDATE f3102@jdedtadl',
'       SET igclat = :P1761_COSTOREAL*10000,',
'           igclun = :P1761_HORASREAL*10000',
'     WHERE igdoco = :P1761_ORDENP',
'       AND TRIM(igcost) = TRIM(:P1761_TIPOCOSTO)',
'       AND igitm = :P1761_ITM',
'       AND igmcu = :P1761_IGMCU;',
'    COMMIT;',
'    apex_application.g_print_success_message := ''Acmbio Aplicado. '';',
'ELSE',
'    APEX_ERROR.ADD_ERROR(p_message => ''Error al aplicar cambio, informe a sistemas'', p_display_location => APEX_ERROR.C_INLINE_IN_NOTIFICATION);',
'END IF;',
'',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(74396367636550447)
,p_internal_uid=>74396459387550448
,p_created_on=>wwv_flow_imp.dz('20250622214353Z')
,p_updated_on=>wwv_flow_imp.dz('20250623131435Z')
,p_created_by=>'DBURBANO'
,p_updated_by=>'DBURBANO'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(74394630234550430)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Inicio'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
unistr('    SELECT IGDCTO || ''-'' || IGDOCO || '' ESTADO: '' || wasrst || '' BODEGA: '' || bodega || '' M\00C1QUINA: '' || maquina || '' '' || NomMaquina'),
'         , ''('' || TIPOOP || '') RUTA: '' || RUTA || '' LISTA MATERIALES: '' || LISTA || '' FECHA SOLICITUD: '' || FECHASOLICITUD',
'         , item || ''-'' || descripitm || '' UNIDAD: '' || wauom  ',
'         , ''CANTIDAD PEDIDA: '' || cntpedida || ''  '' || ''CANTIDAD ENTREGADA: '' || cntentregada',
'         , ''TIPO:'' || igcost || '' COSTO REAL:'' || COSTOREAL || '' COSTO ESTANDAR:'' ||  COSTOFINALIZADO || '' HORAS REAL:'' ||  HORASREAL || '' HORAS ESTANDAR:'' ||  HORASESTANDAR',
'         , igitm ',
'         , '' # BACH: '' || (SELECT MAX(k.glicu) FROM f0911@jdedtadl k WHERE k.glsbl = doccont AND k.gldct = ''IH'') ||',
'           '' # DOCUMENTO: '' || (SELECT MAX(k.gldoc) FROM f0911@jdedtadl k WHERE k.glsbl = doccont AND k.gldct = ''IH'')',
'          INTO :P1761_ORDEN, :P1761_TIPOOT, :P1761_ITEM, :P1761_CANTIDAD, :P1761_COSTO, :P1761_ITM, :P1761_TRANS',
'     FROM',
'    (',
'    SELECT c.igcost, c.igdcto, c.igdoco, c.igclat/10000 CostoReal, c.igopat/10000 CostoEstandar, c.igcpat/10000 CostoFinalizado, c.igclun/10000 HorasReal, c.igcccu/10000 HorasEstandar',
'         , TO_DATE(o.wadrqj + 1900000,''yyyyddd'') FechaSolicitud, TRIM(c.igmcu) Maquina, TRIM(o.wammcu) Bodega',
'         , (SELECT TRIM(m.iwlocn) FROM f30006@jdedtadl m WHERE m.iwmcu = c.igmcu) NomMaquina',
'         , o.watbm Lista, watrt ruta, watyps tipoop, ''0'' || IGDOCO doccont',
'         , TRIM(walitm) item, TRIM(i.imdsc1) || '' '' || TRIM(i.imdsc2) descripitm, wauom',
'         , wauorg/10000 cntpedida, wasoqs/10000 cntentregada, wasrst, igitm',
'     FROM f3102@jdedtadl c, f4801@jdedtadl o, f4101@jdedtadl i ',
'    WHERE c.igdoco = o.wadoco -- numero de orden',
'      AND c.igitm = o.waitm -- Item',
'      AND i.imitm = o.waitm',
'      AND c.igmcu = :P1761_IGMCU',
'      AND TRIM(c.igcost) = TRIM(:P1761_TIPOCOSTO)',
'      AND c.igdoco = :P1761_ORDENP --1425262 --:P1761_ORDENP',
'     ) d1;',
'EXCEPTION',
'  WHEN NO_DATA_FOUND THEN',
'    APEX_ERROR.ADD_ERROR(p_message => ''Error: No se encontraron Datos'', p_display_location => APEX_ERROR.C_INLINE_IN_NOTIFICATION);',
'  WHEN TOO_MANY_ROWS THEN',
unistr('    APEX_ERROR.ADD_ERROR(p_message => ''Error: Se encontraron m\00FAltiples Datos'', p_display_location => APEX_ERROR.C_INLINE_IN_NOTIFICATION);'),
'  WHEN OTHERS THEN',
'    APEX_ERROR.ADD_ERROR(p_message => ''Error: No controlado'', p_display_location => APEX_ERROR.C_INLINE_IN_NOTIFICATION);',
'END;',
''))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>74394630234550430
,p_created_on=>wwv_flow_imp.dz('20250621215048Z')
,p_updated_on=>wwv_flow_imp.dz('20250623131000Z')
,p_created_by=>'DBURBANO'
,p_updated_by=>'DBURBANO'
);
wwv_flow_imp.component_end;
end;
/
