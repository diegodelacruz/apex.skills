prompt --application/pages/page_00449
begin
--   Manifest
--     PAGE: 00449
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>109
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_page.create_page(
 p_id=>449
,p_name=>'PYG INDUSTRIALES - PAG - DISTRIBUCION'
,p_alias=>'PYG-INDUSTRIALES-PAG-DISTRIBUCION'
,p_step_title=>unistr('DISTRIBUCI\00D3N')
,p_autocomplete_on_off=>'OFF'
,p_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'function f_ejecutarSQL(p_sql) {',
'    mostrarBarra(); // Bloqueamos pantalla',
'',
'    f_llamarProceso(p_sql)',
'        .then((resul) => {',
'            if (resul.resultado == 1) {',
'                mensajeExito(resul.texto);',
'                apex.region("rg_log_instancias").refresh();',
'                apex.region("regDetalle").refresh();',
'            } else {',
'                mensajeError(resul.texto);',
'            }',
'        })',
'        .catch((error) => {',
unistr('            console.error("Error cr\00EDtico:", error);'),
unistr('            mensajeError("Ocurri\00F3 un error inesperado.");'),
'        })',
'        .finally(() => {',
'            ocultarBarra(); // Desbloqueamos pantalla siempre',
'        });',
' ',
'}',
'',
'  ',
'function f_llamarProceso (v_parametro1){',
'    var result = null;',
'    return new Promise((resolve, reject) => {',
'    apex.server.process(',
'        ''LLAMAR_EJECUTARDISTRIBUCION'', // Nombre del proceso',
'        {',
'            x01:v_parametro1,',
'        }, // variables del proceso',
'        {',
'            dataType: "json",',
'            success: function(pData)',
'            {',
'                //result = pData.result;',
'                resolve(pData);  // Resuelve la promesa con los datos del servidor',
'',
'            }',
'            ,error: function(err) {',
'                console.error("Error LLAMAR_EJECUTARDISTRIBUCION:", err);',
'                 reject(err);  // Rechaza la promesa en caso de error',
'            }',
'        }',
'    );',
'    });',
'}',
' ',
'',
' function f_cargaOpciones (p_item){',
'	(function () {',
'		function setCol($els, n){',
'			$els.each(function(){',
'				const el = this;',
'				const toRemove = [];',
'				el.classList.forEach(cls => {',
'					if (cls === "col" || cls.indexOf("col-") === 0) toRemove.push(cls);',
'				});',
'				toRemove.forEach(c => el.classList.remove(c));',
'				el.classList.add("col-" + n);',
'			});',
'		}',
'',
'		function apply(){',
'			const $c = $("#"+p_item);',
'			if (!$c.length) return;',
'			setCol($c.find(".t-Form-labelContainer"), 0);',
'			setCol($c.find(".t-Form-inputContainer"), 12);',
'		}',
'',
'		// inicial y tras eventos APEX comunes',
'		$(apply);',
'		$(document).on("apexafterrefresh apexafterclosedialog apexafterpagesubmit", apply);',
'	})();',
'',
'}'))
,p_javascript_code_onload=>wwv_flow_string.join(wwv_flow_t_varchar2(
'$(secItems).hide();',
'$(document).on(''click'',''.exp-btn'',function(){',
'    var inst = $(this).data(''instancia'');',
'    var btn  = $(this);',
'',
'    var rows = $(''tr'').filter(function(){',
'        return $(this).text().includes(inst) && $(this).find(''span.D'').length > 0;',
'    });',
'',
'    if (btn.text()===''+'') {',
'        rows.show();',
'        btn.text(''-'');',
'    } else {',
'        rows.hide();',
'        btn.text(''+'');',
'    }',
'});',
'f_cargaOpciones("P149_PERIODO_CONTAINER");',
'',
'',
'document.addEventListener("click", function(e){',
'',
'  const headerLeft = e.target.closest(".js-inst-toggle");',
'  if (headerLeft) {',
'    const header = headerLeft.closest(".inst-header");',
'    const body = header.nextElementSibling;',
'    const icon = header.querySelector(".inst-icon");',
'',
'    if (body.style.display === "none" || body.style.display === "") {',
'      body.style.display = "block";',
'      icon.classList.remove("fa-chevron-right");',
'      icon.classList.add("fa-chevron-down");',
'    } else {',
'      body.style.display = "none";',
'      icon.classList.remove("fa-chevron-down");',
'      icon.classList.add("fa-chevron-right");',
'    }',
'  }',
'',
'  const refreshBtn = e.target.closest(".js-btn-refresh");',
'  if (refreshBtn) {',
'    apex.region("rg_log_instancias").refresh();',
'    return;',
'  }',
'',
'  const btn = e.target.closest(".js-btn-ejecutar");',
'  if (btn) {',
'    const target = btn.getAttribute("data-target");',
'    const instancia = btn.getAttribute("data-inst");',
'    const vQuery = document.getElementById(target).value;',
'console.log(vQuery);',
'    var vMensaje = "Instancia: " + instancia + "\n\n" +',
unistr('        "Est\00E1 a punto de ejecutar un proceso que modificar\00E1 la base de datos.\005Cn\005Cn" +'),
unistr('        "IMPORTANTE: Se eliminar\00E1n los datos generados anteriormente y ser\00E1n reemplazados por el nuevo c\00E1lculo.\005Cn\005Cn" +'),
unistr('        "\00BFEst\00E1 seguro de que desea continuar?";'),
'',
'    apex.message.confirm(vMensaje, function(okPressed) {',
'        if (okPressed) {',
'            if (vQuery) {',
'                apex.item("P449_QUERY").setValue(vQuery);',
'                f_ejecutarSQL(vQuery);',
'            } else {',
'                apex.message.alert("No hay consulta SQL asociada a la instancia " + instancia + ".");',
'            }',
'        }',
'    });',
'  }',
'',
'});'))
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'tr:has(span.D) {',
'  display: none;',
'}',
' ',
'.exp-btn{',
'  background: none;',
'  border: none;',
'  cursor: pointer;',
'  font-size: 14px;',
'    font-weight: bold;',
'  user-select: none;',
'}',
'',
'Button.t-Button--icon, Button.t-Button--icon:active:focus, Button.t-Button--icon:hover, Button.t-Button--icon:active {',
'    background: transparent !important;',
'   ',
'}',
'/*colapsable */',
'.log-wrap .inst-block{',
'  border: 1px solid #d9d9d9;',
'  border-radius: 6px;',
'  margin-bottom: 10px;',
'  overflow: hidden;',
'}',
'',
'.log-wrap .inst-header{',
'  background: #f7f7f7;',
'  padding: 10px 12px;',
'  cursor: pointer;',
'  display: flex;',
'  align-items: center;',
'  gap: 10px;',
'  font-weight: 600;',
'}',
'',
'.log-wrap .inst-title{',
'  flex: 1;',
'}',
'',
'.log-wrap .inst-total{',
'  font-weight: 500;',
'  color: #555;',
'}',
'',
'.log-wrap .inst-body{',
'  padding: 10px;',
'  background: #fff;',
'}',
'',
'/* Encabezado */',
'.t-Report-report th {',
'    border-top: 1px solid #d9d9d9;',
'    border-bottom: 1px solid #d9d9d9;',
'    border-left: none;',
'    border-right: none;',
'}',
'',
'/* Filas */',
'.t-Report-report td {',
'    border-bottom: 1px solid #e0e0e0;',
'    border-top: none;',
'    border-left: none;',
'    border-right: none;',
'}',
'',
'/* Opcional: quitar borde externo de la tabla */',
'.t-Report-report {',
'    border: none;',
'}',
'',
'.total-header{',
'    display:flex;',
'    align-items:center;',
'    gap:16px;',
'    width:100%;',
'}',
'',
'.total-left{',
'    flex:0 0 auto;',
'    display:flex;',
'    align-items:center;',
'}',
'',
'.total-middle{',
'    flex:1 1 auto;',
'    display:flex;',
'    justify-content:flex-start;',
'    align-items:center;',
'}',
'',
'.total-actions{',
'    flex:0 0 auto;',
'    display:flex;',
'    align-items:center;',
'    gap:8px;',
'    margin-left:auto;',
'}',
'',
'.inst-head-right{',
'    display:flex;',
'    align-items:center;',
'    gap:8px;',
'    margin-left:auto;',
'}',
'',
'.inst-head-left{',
'    display:flex;',
'    align-items:center;',
'    gap:8px;',
'    cursor:pointer;',
'}'))
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'25'
,p_last_updated_on=>wwv_flow_imp.dz('20260420163525Z')
,p_last_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(153647917840741734)
,p_plug_name=>'Items'
,p_region_name=>'secItems'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(38289867500120143)
,p_plug_display_sequence=>60
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
,p_updated_on=>wwv_flow_imp.dz('20260311191702Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(153648415575741739)
,p_plug_name=>unistr('DETALLE DE DISTRIBUCI\00D3N')
,p_region_name=>'regDetalle'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(37806762584106520)
,p_plug_display_sequence=>20
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT c.*',
',case when TOTAL =0 then '' '' else ''<span class="fa fa-tasks-alt" aria-hidden="true"></span>'' end DETALLE',
' FROM vt_finz_distribucioncab c',
'WHERE',
'        c.compania = :p449_compania',
'    AND c.glfy = :p449_anio',
'    AND c.glpn = :p449_mes'))
,p_plug_source_type=>'NATIVE_IR'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
,p_updated_on=>wwv_flow_imp.dz('20260219171551Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(153648501799741740)
,p_max_row_count=>'1000000'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'EMASABANDA'
,p_internal_uid=>153648501799741740
,p_updated_on=>wwv_flow_imp.dz('20260219165547Z')
,p_updated_by=>'EMASABANDA'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(153648622402741741)
,p_db_column_name=>'ID'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Id'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(153648795044741742)
,p_db_column_name=>'FECHCREA'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Fecha'
,p_column_type=>'DATE'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(153648813175741743)
,p_db_column_name=>'COMPANIA'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Compania'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(153648902765741744)
,p_db_column_name=>'ANIO'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Anio'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(153649062726741745)
,p_db_column_name=>'MES'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Mes'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(153649142437741746)
,p_db_column_name=>'APROBADO'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'Aprobado'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(153649282744741747)
,p_db_column_name=>'GLLV1'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>'Nivel 1'
,p_column_type=>'NUMBER'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_rpt_named_lov=>wwv_flow_imp.id(119193859528059131)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(153649304777741748)
,p_db_column_name=>'GLLV2'
,p_display_order=>80
,p_column_identifier=>'H'
,p_column_label=>'Nivel 2'
,p_column_type=>'NUMBER'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_rpt_named_lov=>wwv_flow_imp.id(119194387269080626)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(153649496421741749)
,p_db_column_name=>'GLAA'
,p_display_order=>90
,p_column_identifier=>'I'
,p_column_label=>'Valor'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
,p_use_as_row_header=>'N'
,p_updated_on=>wwv_flow_imp.dz('20260219163903Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(153649546465741750)
,p_db_column_name=>'GLGDCL'
,p_display_order=>100
,p_column_identifier=>'J'
,p_column_label=>'Dist. Cliente'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
,p_use_as_row_header=>'N'
,p_updated_on=>wwv_flow_imp.dz('20260219163821Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(153932689794255101)
,p_db_column_name=>'GLGDPR'
,p_display_order=>110
,p_column_identifier=>'K'
,p_column_label=>'Dist. Producto'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
,p_use_as_row_header=>'N'
,p_updated_on=>wwv_flow_imp.dz('20260219163821Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(153932700377255102)
,p_db_column_name=>'GLGDCP'
,p_display_order=>120
,p_column_identifier=>'L'
,p_column_label=>'Dist. Cliente/Producto'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
,p_use_as_row_header=>'N'
,p_updated_on=>wwv_flow_imp.dz('20260219163821Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(153932858290255103)
,p_db_column_name=>'GLGDST'
,p_display_order=>130
,p_column_identifier=>'M'
,p_column_label=>'Dist. General'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
,p_use_as_row_header=>'N'
,p_updated_on=>wwv_flow_imp.dz('20260219163821Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(153934231407255117)
,p_db_column_name=>'LVL1'
,p_display_order=>140
,p_column_identifier=>'N'
,p_column_label=>'Lvl1'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(153934303225255118)
,p_db_column_name=>'LVL2'
,p_display_order=>150
,p_column_identifier=>'O'
,p_column_label=>'Lvl2'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(153934473435255119)
,p_db_column_name=>'TOTAL'
,p_display_order=>160
,p_column_identifier=>'P'
,p_column_label=>'Total'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
,p_use_as_row_header=>'N'
,p_updated_on=>wwv_flow_imp.dz('20260219163821Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(153934721031255122)
,p_db_column_name=>'GLFY'
,p_display_order=>170
,p_column_identifier=>'Q'
,p_column_label=>'Glfy'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(153934870264255123)
,p_db_column_name=>'GLPN'
,p_display_order=>180
,p_column_identifier=>'R'
,p_column_label=>'Glpn'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(168142469826781715)
,p_db_column_name=>'DETALLE'
,p_display_order=>190
,p_column_identifier=>'S'
,p_column_label=>'-'
,p_column_link=>'f?p=&APP_ID.:450:&SESSION.::&DEBUG.:RR,450:P450_ANIO,P450_MES,P450_LVL1,P450_LVL2:#GLFY#,#GLPN#,#LVL1#,#LVL2#'
,p_column_linktext=>'#DETALLE#'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(153943268669256475)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'1539433'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'DETALLE:GLLV1:GLLV2:GLAA:GLGDCL:GLGDPR:GLGDCP:GLGDST:TOTAL:'
,p_sort_column_1=>'LVL1'
,p_sort_direction_1=>'ASC'
,p_sort_column_2=>'LVL2'
,p_sort_direction_2=>'ASC'
,p_sort_column_3=>'0'
,p_sort_direction_3=>'ASC'
,p_sort_column_4=>'0'
,p_sort_direction_4=>'ASC'
,p_sort_column_5=>'0'
,p_sort_direction_5=>'ASC'
,p_sort_column_6=>'0'
,p_sort_direction_6=>'ASC'
,p_sum_columns_on_break=>'GLGDCL:GLGDPR:GLGDCP:GLGDST:TOTAL:GLAA'
,p_updated_on=>wwv_flow_imp.dz('20260219165547Z')
,p_updated_by=>'EMASABANDA'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(153933127919255106)
,p_plug_name=>'Barra de Acciones'
,p_region_template_options=>'#DEFAULT#:t-Form--stretchInputs'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(38289497777120142)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_location=>null
,p_menu_id=>wwv_flow_imp.id(37761271469106475)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(37860983999106559)
,p_updated_on=>wwv_flow_imp.dz('20260219164601Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(168142910438781720)
,p_plug_name=>'Encabezado'
,p_title=>'&P449_PERIODO.'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(38289867500120143)
,p_plug_display_sequence=>10
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
,p_updated_on=>wwv_flow_imp.dz('20260219164713Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(386068547712380845)
,p_plug_name=>'logs'
,p_region_name=>'rg_log_instancias'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(38289867500120143)
,p_plug_display_sequence=>50
,p_location=>null
,p_function_body_language=>'PLSQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_html              clob;',
'    l_instancia_ant     varchar2(4000);',
'    l_open_table        boolean := false;',
'    l_idx               number := 0;',
'    l_color             varchar2(30);',
'    l_query_inst        varchar2(32767);',
'    l_total_general     varchar2(100);',
'    l_sql_total         varchar2(32767);',
'',
'    procedure add(p_txt in clob) is',
'    begin',
'        dbms_lob.append(l_html, p_txt);',
'    end;',
'',
'begin',
'    dbms_lob.createtemporary(l_html, true);',
'',
'    l_sql_total :=',
'        ''pk_finz_distribucion.sp_ejecucion(''||',
'        ''p_cia => ''''''||:P449_COMPANIA||'''''',''||',
'        '' p_anno => ''||:P449_ANIO||'',''||',
'        '' p_mes => ''||:P449_MES||'');'';',
'',
'    with orderinst as (',
'        select idx as orden,',
'               nombre as instancia',
'          from table(pk_finz_distribucion.f_trae_instanciaslog(:P449_COMPANIA,:P449_ANIO,:P449_MES))',
'    ),',
'    all_logs as (',
'        select',
'            o.instancia,',
'            nvl(l.codexcepcion,0) codexcepcion,',
'            l.mensaje,',
'            l.descripcion',
'        from t_apex_log l',
'        inner join orderinst o',
'            on l.instancia = o.instancia',
'        where l.aplicacion = ''data.pk.finz.distribucion''',
'          and l.mensaje not like ''%p_reg:=%''',
'          and case',
'                when instr(l.descripcion,''|'',1,1) > 0',
'                then substr(l.descripcion,1, instr(l.descripcion,''|'',1,1)-1)',
'              end =',
'                pk_finz_distribucion.f_auxpartper_nd(:P449_ANIO,4) ||',
'                pk_finz_distribucion.f_auxpartper_nd(:P449_MES,2)',
'          and not regexp_like (upper(nvl(l.mensaje,'' '')) ,''TERMINADO CORRECTAMENTE|FIN REGISTRO DE DATOS DEL PERIODO'')',
'    )',
'    select pk_finz_distribucion.f_auxseg_ftime(nvl(sum(codexcepcion),0))',
'      into l_total_general',
'      from all_logs;',
'',
'    add(''<div class="log-wrap">'');',
'',
'    add(',
'        ''<div class="inst-block total-block">''||',
'            ''<div class="inst-header total-header" style="background:#d9edf7;">''||',
'                ''<div class="total-left">''||',
'                    ''<span class="inst-title">PERIODO</span>''||',
'                ''</div>''||',
'                ''<div class="total-middle">''||',
unistr('                    ''<span class="inst-total">Duraci\00F3n de la ejecuci\00F3n: ''||'),
'                        apex_escape.html(nvl(l_total_general,''0:00''))||''</span>''||',
'                ''</div>''||',
'                ''<div class="total-actions">''||',
'                    ''<button type="button" ''||',
'                            ''class="t-Button t-Button--noLabel t-Button--icon js-btn-refresh inst-refresh-btn" ''||',
'                            ''title="Refrescar">''||',
'                        ''<span class="fa fa-refresh"></span>''||',
'                    ''</button>''||',
'                    ''<button type="button" ''||',
'                            ''class="t-Button t-Button--noLabel t-Button--icon js-btn-ejecutar inst-run-btn" ''||',
'                            ''data-inst="EJECUCION TOTAL" ''||',
'                            ''data-target="qry_total" ''||',
'                            ''title="Ejecutar">''||',
'                        ''<span class="fa fa-play"></span>''||',
'                    ''</button>''||',
'                    ''<textarea id="qry_total" style="display:none;">''||',
'                        apex_escape.html(l_sql_total)||',
'                    ''</textarea>''||',
'                ''</div>''||',
'            ''</div>''||',
'        ''</div>''',
'    );',
'',
'    for r in (',
'        with orderinst as (',
'            select idx as orden,',
'                   nombre as instancia',
'              from table(pk_finz_distribucion.f_trae_instanciaslog(:P449_COMPANIA,:P449_ANIO,:P449_MES))',
'        ),',
'        all_logs as (',
'            select',
'                o.orden,',
'                o.instancia,',
'                l.paso,',
'                l.fecha,',
'                case',
'                    when instr(l.descripcion,''|'',1,1) > 0',
'                    then substr(l.descripcion,1, instr(l.descripcion,''|'',1,1)-1)',
'                end as periodo,',
'                case',
'                    when instr(l.descripcion,''|'',1,2) > 0',
'                    then replace(substr(l.descripcion,instr(l.descripcion,''|'',1,2)+1),''PK_FINZ_DISTRIBUCION.'','''')',
'                end as procedimiento,',
'                case',
'                    when instr(l.descripcion,''|'',1,2) > 0',
'                     and instr(l.descripcion,''|'',1,1) > 0',
'                    then substr(',
'                            l.descripcion,',
'                            instr(l.descripcion,''|'',1,1)+1,',
'                            instr(l.descripcion,''|'',1,2)-instr(l.descripcion,''|'',1,1)-1',
'                         )',
'                end as detalle_error,',
'                nvl(l.codexcepcion,0) as duracion_seg,',
'                pk_finz_distribucion.f_auxseg_ftime(nvl(l.codexcepcion,0)) as duracion,',
'                l.query,',
'                l.observacion,',
'                l.mensaje',
'            from t_apex_log l',
'            inner join orderinst o',
'                on l.instancia = o.instancia',
'            where l.aplicacion = ''data.pk.finz.distribucion''',
'              and l.mensaje not like ''%p_reg:=%''',
'              and case',
'                    when instr(l.descripcion,''|'',1,1) > 0',
'                    then substr(l.descripcion,1, instr(l.descripcion,''|'',1,1)-1)',
'                  end =',
'                    pk_finz_distribucion.f_auxpartper_nd(:P449_ANIO,4) ||',
'                    pk_finz_distribucion.f_auxpartper_nd(:P449_MES,2)',
'        ),',
'        inst_stats as (',
'            select',
'                orden,',
'                instancia,',
'                pk_finz_distribucion.f_auxseg_ftime(',
'                    sum(case',
'						when regexp_like (upper(nvl(mensaje,'' '')) ,''TERMINADO CORRECTAMENTE|FIN REGISTRO DE DATOS DEL PERIODO'') then 0',
'                        else duracion_seg',
'                    end)',
'                ) as total_duracion_instancia,',
'                max(case when regexp_like (upper(nvl(mensaje,'' '')) ,''TERMINADO CORRECTAMENTE|FIN REGISTRO DE DATOS DEL PERIODO'') then 1 else 0 end) as flag_ok,',
'                max(case when upper(nvl(mensaje,'' '')) like ''%TERMINADO CON ERROR%'' then 1 else 0 end) as flag_error,',
'                max(case when query is not null then dbms_lob.substr(query,32767,1) end) as query_instancia',
'            from all_logs',
'            group by orden, instancia',
'        ),',
'        visibles as (',
'            select *',
'              from all_logs',
'             where not regexp_like (upper(nvl(mensaje,'' '')) ,''TERMINADO CORRECTAMENTE|FIN REGISTRO DE DATOS DEL PERIODO'')',
'        )',
'        select',
'            s.orden,',
'            s.instancia,',
'            s.total_duracion_instancia,',
'            s.flag_ok,',
'            s.flag_error,',
'            s.query_instancia,',
'            v.fecha,',
'            v.periodo,',
'            v.procedimiento,',
'            v.detalle_error,',
'            v.duracion,',
'            v.mensaje',
'        from inst_stats s',
'        left join visibles v',
'               on s.instancia = v.instancia',
'        order by s.orden, s.instancia, v.fecha',
'    ) loop',
'',
'        l_idx := l_idx + 1;',
'',
'        if l_instancia_ant is null or l_instancia_ant <> r.instancia then',
'',
'            if l_open_table then',
'                add(''</tbody></table></div></div>'');',
'            end if;',
'',
'            if r.flag_error = 1 then',
'                l_color := ''#ea000061'';',
'            elsif r.flag_ok = 1 then',
'                l_color := ''#90ee904d'';',
'            else',
'                l_color := ''#ff8c0069'';',
'            end if;',
'',
'            l_query_inst := r.query_instancia;',
'',
'            add(',
'                ''<div class="inst-block">''||',
'                    ''<div class="inst-header" style="background:''||l_color||'';">''||',
'                        ''<div class="inst-head-left js-inst-toggle">''||',
'                            ''<span class="inst-icon fa fa-chevron-right"></span>''||',
'                            ''<span class="inst-title">''||apex_escape.html(r.instancia)||''</span>''||',
'                        ''</div>''||',
'                        ''<div class="inst-head-right">''||',
unistr('                            ''<span class="inst-total">Duraci\00F3n total: ''||'),
'                                apex_escape.html(r.total_duracion_instancia)||''</span>''',
'            );',
'',
'            -- if l_query_inst is not null then',
'            --     add(',
'            --         ''<button type="button" ''||',
'            --                 ''class="t-Button t-Button--noLabel t-Button--icon js-btn-ejecutar inst-run-btn" ''||',
'            --                 ''data-inst="''||apex_escape.html_attribute(r.instancia)||''" ''||',
'            --                 ''data-target="qry_''||l_idx||''">''||',
'            --             ''<span class="fa fa-play"></span>''||',
'            --         ''</button>''||',
'            --         ''<textarea id="qry_''||l_idx||''" style="display:none;">''||',
'            --             apex_escape.html(l_query_inst)||',
'            --         ''</textarea>''',
'            --     );',
'            -- end if;',
'',
'            add(',
'                        ''</div>''||',
'                    ''</div>''||',
'                    ''<div class="inst-body" style="display:none;">''||',
'                        ''<table class="t-Report-report">''||',
'                            ''<thead>''||',
'                                ''<tr>''||',
'                                    ''<th>Fecha</th>''||',
'                                    ''<th>Periodo</th>''||',
'                                    ''<th>Procedimiento</th>''||',
'                                    ''<th>Detalle</th>''||',
unistr('                                    ''<th>Duraci\00F3n</th>''||'),
'                                    ''<th>Mensaje</th>''||',
'                                ''</tr>''||',
'                            ''</thead>''||',
'                            ''<tbody>''',
'            );',
'',
'            l_instancia_ant := r.instancia;',
'            l_open_table := true;',
'        end if;',
'',
'        if r.fecha is not null then',
'            add(''<tr>'');',
'            add(''<td>''||apex_escape.html(to_char(r.fecha,''dd/mm/yyyy hh24:mi:ss''))||''</td>'');',
'            add(''<td>''||apex_escape.html(r.periodo)||''</td>'');',
'            add(''<td>''||apex_escape.html(r.procedimiento)||''</td>'');',
'            add(''<td>''||apex_escape.html(r.detalle_error)||''</td>'');',
'            add(''<td>''||apex_escape.html(r.duracion)||''</td>'');',
'            add(''<td>''||apex_escape.html(r.mensaje)||''</td>'');',
'            add(''</tr>'');',
'        end if;',
'',
'    end loop;',
'',
'    if l_open_table then',
'        add(''</tbody></table></div></div>'');',
'    end if;',
'',
'    add(''</div>'');',
'',
'    return l_html;',
'end;'))
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_DYNAMIC_CONTENT'
,p_created_on=>wwv_flow_imp.dz('20260316151307Z')
,p_updated_on=>wwv_flow_imp.dz('20260420163525Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(153933365959255108)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(153933127919255106)
,p_button_name=>'ATRAS'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860056812106557)
,p_button_image_alt=>'Atras'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'LEFT'
,p_button_redirect_url=>'f?p=&APP_ID.:440:&SESSION.::&DEBUG.::P440_COMPANIA:&P449_COMPANIA.'
,p_icon_css_classes=>'fa-arrow-left'
,p_updated_on=>wwv_flow_imp.dz('20260219161739Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(292380781544702243)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(153933127919255106)
,p_button_name=>'APROBAR'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860056812106557)
,p_button_image_alt=>'Aprobar'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
,p_confirm_message=>wwv_flow_string.join(wwv_flow_t_varchar2(
unistr('<stronge style="color:red;">IMPORTANTE</stronge>:<br />Est\00E1 a punto de aprobar el periodo &P449_PERIODO..<br /><br />'),
unistr('\00BFEst\00E1 seguro de que desea continuar?')))
,p_confirm_style=>'information'
,p_icon_css_classes=>'fa-check'
,p_created_on=>wwv_flow_imp.dz('20260219171142Z')
,p_updated_on=>wwv_flow_imp.dz('20260219172429Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(292378431010702220)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(153648415575741739)
,p_button_name=>'Detallado_Todo'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860056812106557)
,p_button_image_alt=>'Detallado Todo'
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
,p_button_redirect_url=>'f?p=&APP_ID.:450:&SESSION.::&DEBUG.:450:P450_ANIO,P450_MES:&P449_ANIO.,&P449_MES.'
,p_button_condition_type=>'NEVER'
,p_icon_css_classes=>'fa-tasks-alt'
,p_created_on=>wwv_flow_imp.dz('20260219135345Z')
,p_updated_on=>wwv_flow_imp.dz('20260219164219Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(153648002506741735)
,p_name=>'P449_ANIO'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(153647917840741734)
,p_prompt=>'Anio'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_updated_on=>wwv_flow_imp.dz('20260219165430Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(153648190975741736)
,p_name=>'P449_MES'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(153647917840741734)
,p_prompt=>'Mes'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_updated_on=>wwv_flow_imp.dz('20260219165430Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(153932948325255104)
,p_name=>'P449_COMPANIA'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(153647917840741734)
,p_prompt=>'Compania'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_updated_on=>wwv_flow_imp.dz('20260219165430Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(168143087954781721)
,p_name=>'P449_PERIODO'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(153647917840741734)
,p_prompt=>'Periodo'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
,p_updated_on=>wwv_flow_imp.dz('20260219165430Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(292380317442702239)
,p_name=>'P449_ENCABEZADOMES'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(168142910438781720)
,p_prompt=>'Mes'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
,p_created_on=>wwv_flow_imp.dz('20260219164907Z')
,p_updated_on=>wwv_flow_imp.dz('20260219165448Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(292380403347702240)
,p_name=>'P449_ENCABEZADOANIO'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(168142910438781720)
,p_prompt=>unistr('A\00F1o')
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
,p_created_on=>wwv_flow_imp.dz('20260219164944Z')
,p_updated_on=>wwv_flow_imp.dz('20260219165448Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(292380569547702241)
,p_name=>'P449_ENCABEZADOAPROBADO'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(168142910438781720)
,p_prompt=>'Aprobado'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
,p_created_on=>wwv_flow_imp.dz('20260219165044Z')
,p_updated_on=>wwv_flow_imp.dz('20260219165430Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(292380609308702242)
,p_name=>'P449_ENCABEZADOCOMPANIA'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(168142910438781720)
,p_prompt=>'Compania'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_named_lov=>'LOV_FINZ_PGI_COMPANIA'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'      SELECT DESCRIPCION, ID_TABLA IDCOMPANIA',
'FROM t_corp_udc ',
'where id_cabecera=''COMP_CGZCM'' ',
'and ID_TABLA!=''00000'' ',
'/*and ACTIVO=''1''*/',
'order by ID_TABLA;'))
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'Y'
,p_attribute_02=>'LOV'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
,p_created_on=>wwv_flow_imp.dz('20260219165044Z')
,p_updated_on=>wwv_flow_imp.dz('20260219165431Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(292381221549702248)
,p_name=>'P449_USUARIOCIERRE'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(168142910438781720)
,p_prompt=>'Usuario Aprueba'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
,p_created_on=>wwv_flow_imp.dz('20260219172627Z')
,p_updated_on=>wwv_flow_imp.dz('20260219173544Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(292381378411702249)
,p_name=>'P449_FECHACIERRE'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(168142910438781720)
,p_prompt=>'Fecha Aprueba'
,p_format_mask=>'DD/MM/YYYY HH24:MI:SS'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
,p_created_on=>wwv_flow_imp.dz('20260219172627Z')
,p_updated_on=>wwv_flow_imp.dz('20260219173544Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(386068671514380846)
,p_name=>'P449_QUERY'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(153647917840741734)
,p_prompt=>'Query'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_created_on=>wwv_flow_imp.dz('20260316151346Z')
,p_updated_on=>wwv_flow_imp.dz('20260316151346Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(153935085591255125)
,p_name=>'Ejecutar Query Grid'
,p_event_sequence=>10
,p_triggering_element_type=>'JQUERY_SELECTOR'
,p_triggering_element=>'.js-btn-ejecutar'
,p_bind_type=>'live'
,p_bind_delegate_to_selector=>'#regLog'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(153935117209255126)
,p_event_id=>wwv_flow_imp.id(153935085591255125)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'var $btn = $(this.triggeringElement);',
'console.log( $btn);',
'var vQuery = $btn.data(''query'') || '''';',
'var vInstancia = $btn.data(''instancia'')|| '''';  ',
'var vMensaje = vInstancia+"\n\n" +',
unistr('        "Est\00E1 a punto de ejecutar un proceso que modificar\00E1 la base de datos.\005Cn\005Cn" +'),
unistr('        "IMPORTANTE: Se eliminar\00E1n los datos generados anteriormente y ser\00E1n reemplazados por el nuevo c\00E1lculo.\005Cn\005Cn" +'),
unistr('        "\00BFEst\00E1 seguro de que desea continuar?";'),
'',
unistr('    // La funci\00F3n confirm nativa de APEX'),
'    apex.message.confirm(vMensaje, function(okPressed) {',
'        if (okPressed) {',
'            if (vQuery) {',
'                f_ejecutarSQL(vQuery); ',
'            } else {',
unistr('                console.error("Error: El atributo data-query est\00E1 vac\00EDo.");'),
'                apex.message.alert("No hay consulta SQL asociada a este registro.");',
'            }',
'        }',
'    });',
'',
''))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(292381071867702246)
,p_name=>'New'
,p_event_sequence=>30
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(292380781544702243)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
,p_created_on=>wwv_flow_imp.dz('20260219172430Z')
,p_updated_on=>wwv_flow_imp.dz('20260221135730Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(360415626634361404)
,p_event_id=>wwv_flow_imp.id(292381071867702246)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'mostrarBarra();'
,p_created_on=>wwv_flow_imp.dz('20260219173232Z')
,p_updated_on=>wwv_flow_imp.dz('20260219173232Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(292381147655702247)
,p_event_id=>wwv_flow_imp.id(292381071867702246)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'update t_finz_distribucioncab set APROBADO =''SI'' where COMPANIA=:P449_COMPANIA and ANIO=:P449_ANIO and  MES=:P449_MES;',
'SELECT USERMODI, TO_CHAR(FECHCIER,''DD/MM/YYYY HH24:MI:SS'')FECHCIER,APROBADO INTO :P449_USUARIOCIERRE,:P449_FECHACIERRE,:P449_ENCABEZADOAPROBADO  FROM t_finz_distribucioncab where COMPANIA=:P449_COMPANIA and ANIO=:P449_ANIO and  MES=:P449_MES;'))
,p_attribute_02=>'P449_COMPANIA,P449_ANIO,P449_MES'
,p_attribute_03=>'P449_USUARIOCIERRE,P449_FECHACIERRE,P449_ENCABEZADOAPROBADO'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
,p_created_on=>wwv_flow_imp.dz('20260219172430Z')
,p_updated_on=>wwv_flow_imp.dz('20260221135730Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(360415759630361405)
,p_event_id=>wwv_flow_imp.id(292381071867702246)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'ocultarBarra();'
,p_created_on=>wwv_flow_imp.dz('20260219173232Z')
,p_updated_on=>wwv_flow_imp.dz('20260219173232Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(360415360335361401)
,p_name=>'New_1'
,p_event_sequence=>40
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P449_ENCABEZADOAPROBADO'
,p_condition_element=>'P449_ENCABEZADOAPROBADO'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'SI'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
,p_created_on=>wwv_flow_imp.dz('20260219172757Z')
,p_updated_on=>wwv_flow_imp.dz('20260219173117Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(360415427164361402)
,p_event_id=>wwv_flow_imp.id(360415360335361401)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P449_USUARIOCIERRE,P449_FECHACIERRE'
,p_created_on=>wwv_flow_imp.dz('20260219172757Z')
,p_updated_on=>wwv_flow_imp.dz('20260219172757Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(360415597877361403)
,p_event_id=>wwv_flow_imp.id(360415360335361401)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P449_USUARIOCIERRE,P449_FECHACIERRE'
,p_created_on=>wwv_flow_imp.dz('20260219173117Z')
,p_updated_on=>wwv_flow_imp.dz('20260219173117Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(153933005043255105)
,p_process_sequence=>10
,p_process_point=>'AFTER_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Setup Interface'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
':P449_COMPANIA:=:G_COMPANIADIST;',
':P449_PERIODO:=replace(TO_CHAR(to_date(:P449_ANIO||to_char(:P449_MES,''00''),''YYMM''),''Month-yyyy''),'' '','''');',
'SELECT  COMPANIA,TO_CHAR(TO_DATE(ANIO,''YY''),''YYYY''), TO_CHAR(TO_DATE(MES,''MM''),''Month''), APROBADO,USERMODI, TO_CHAR(FECHCIER,''DD/MM/YYYY HH24:MI:SS'')FECHCIER',
'     into:P449_ENCABEZADOCOMPANIA,:P449_ENCABEZADOANIO,:P449_ENCABEZADOMES,:P449_ENCABEZADOAPROBADO ,:P449_USUARIOCIERRE,:P449_FECHACIERRE',
' FROM t_finz_distribucioncab c',
' WHERE',
'         c.compania = :p449_compania',
'     AND c.ANIO = :p449_anio',
'     AND c.MES = :p449_mes',
'     and rownum=1;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>153933005043255105
,p_updated_on=>wwv_flow_imp.dz('20260302165533Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(153935399644255128)
,p_process_sequence=>10
,p_process_point=>'ON_DEMAND'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'LLAMAR_EJECUTARDISTRIBUCION'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'v_sql CLOB;',
'begin',
'    apex_json.open_object;',
'    v_sql:=apex_application.g_x01;',
'    BEGIN',
'        v_sql := ''BEGIN ''||v_sql||'' END;'';',
'        EXECUTE IMMEDIATE v_sql;',
'        apex_json.write( p_name => ''resultado'', p_value =>1);',
'        apex_json.write( p_name => ''texto'', p_value =>''Proceso ejecutado correctamente'');',
'    exception when others then ',
'        apex_json.write( p_name => ''resultado'', p_value =>0);',
'        apex_json.write( p_name => ''texto'', p_value =>sqlerrm);',
'    END;',
'    apex_json.close_object;',
'end;',
''))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>153935399644255128
);
wwv_flow_imp.component_end;
end;
/
