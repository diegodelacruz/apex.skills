prompt --application/pages/page_00462
begin
--   Manifest
--     PAGE: 00462
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>109
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_page.create_page(
 p_id=>462
,p_name=>unistr('Activos Fijos - Levantamiento F\00EDsico')
,p_alias=>unistr('LEVANTAMIENTO-F\00CDSICO')
,p_step_title=>unistr('Levantamiento F\00EDsico')
,p_autocomplete_on_off=>'OFF'
,p_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'function borrarArchivo( numeroArchivo ){',
'    ',
'    apex.item("P462_NUMEROARCHIVO_BORRAR").setValue(numeroArchivo);',
'    ',
'}',
'',
''))
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'18'
,p_last_updated_on=>wwv_flow_imp.dz('20260522165734Z')
,p_last_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(134002978763051436)
,p_plug_name=>'Adjuntos'
,p_region_template_options=>'#DEFAULT#:is-collapsed:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(37796755046106514)
,p_plug_display_sequence=>50
,p_location=>null
,p_plug_display_condition_type=>'EXPRESSION'
,p_plug_display_when_condition=>'1=2'
,p_plug_display_when_cond2=>'PLSQL'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
,p_updated_on=>wwv_flow_imp.dz('20260518035408Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(134003098426051437)
,p_plug_name=>'Carga'
,p_parent_plug_id=>wwv_flow_imp.id(134002978763051436)
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(38289867500120143)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(134003153785051438)
,p_plug_name=>'Reporte'
,p_parent_plug_id=>wwv_flow_imp.id(134002978763051436)
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(38289867500120143)
,p_plug_display_sequence=>20
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select NUMEROARCHIVO,',
'       dbms_lob.getlength(BLOBCONTENT) BLOBCONTENT,',
'       FILENAME,',
'       MIMETYPE,',
'       TABLA,',
'       ID_TABLA,',
'       TIPO,',
'       OBSERVACION,',
'       ESTADO,',
'       FECHA,',
'       NOMBREUSUARIO,',
'       RIDE,',
'       ''<span class="fa fa-eye" title="Previsualizar" aria-hidden="true" style="color: #800080;"></span>'' ver,',
'       pk_commons.f_googledocview(numeroarchivo,mimetype) enlacearchivo,',
'       NUMEROARCHIVO AS BORRAR',
'  from FILES.T_APEX_ARCHIVOS',
' where TABLA=''T_FINZ_ACTIVOSFIJOS'' AND id_tabla=:P462_ID AND TIPO=''LEVANTAMIANTO_FISICO'''))
,p_plug_source_type=>'NATIVE_IR'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(134003253355051439)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'MALBAN'
,p_internal_uid=>134003253355051439
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(134003328260051440)
,p_db_column_name=>'NUMEROARCHIVO'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Numeroarchivo'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(134003461161051441)
,p_db_column_name=>'BLOBCONTENT'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Documento'
,p_column_type=>'NUMBER'
,p_column_alignment=>'CENTER'
,p_format_mask=>'DOWNLOAD:T_APEX_ARCHIVOS:BLOBCONTENT:NUMEROARCHIVO::MIMETYPE:FILENAME:FECHA::attachment::FILES'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(134003520334051442)
,p_db_column_name=>'FILENAME'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Nombre Archivo'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(134003629710051443)
,p_db_column_name=>'MIMETYPE'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Tipo'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(134003742041051444)
,p_db_column_name=>'TABLA'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Tabla'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(134003848862051445)
,p_db_column_name=>'ID_TABLA'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>unistr('C\00F3digo')
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(134003975513051446)
,p_db_column_name=>'TIPO'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>'Tipo'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(134004086683051447)
,p_db_column_name=>'OBSERVACION'
,p_display_order=>80
,p_column_identifier=>'H'
,p_column_label=>unistr('Observaci\00F3n')
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(134004193260051448)
,p_db_column_name=>'ESTADO'
,p_display_order=>90
,p_column_identifier=>'I'
,p_column_label=>'Estado'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(134004297714051449)
,p_db_column_name=>'FECHA'
,p_display_order=>100
,p_column_identifier=>'J'
,p_column_label=>'Fecha Crea'
,p_column_type=>'DATE'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(134004304910051450)
,p_db_column_name=>'NOMBREUSUARIO'
,p_display_order=>110
,p_column_identifier=>'K'
,p_column_label=>'Usuario Crea'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(134216425772902001)
,p_db_column_name=>'RIDE'
,p_display_order=>120
,p_column_identifier=>'L'
,p_column_label=>'Ride'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(134216519527902002)
,p_db_column_name=>'VER'
,p_display_order=>130
,p_column_identifier=>'M'
,p_column_label=>'Ver Documento'
,p_column_link=>'#ENLACEARCHIVO#'
,p_column_linktext=>'#VER#'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(134216637471902003)
,p_db_column_name=>'ENLACEARCHIVO'
,p_display_order=>140
,p_column_identifier=>'N'
,p_column_label=>'Enlacearchivo'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(134216739327902004)
,p_db_column_name=>'BORRAR'
,p_display_order=>150
,p_column_identifier=>'O'
,p_column_label=>'Borrar'
,p_column_link=>'javascript:borrarArchivo(#BORRAR#)'
,p_column_linktext=>'<span title="Eliminar" class="fa fa-trash"/>'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(134235995619936539)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'1342360'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'FILENAME:OBSERVACION:FECHA:NOMBREUSUARIO:VER:BLOBCONTENT:BORRAR:'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(134110025123100876)
,p_plug_name=>'Barra de acciones'
,p_region_template_options=>'#DEFAULT#:t-Form--stretchInputs'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(38289497777120142)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_location=>null
,p_menu_id=>wwv_flow_imp.id(37761271469106475)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(37860983999106559)
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(465821992352129015)
,p_plug_name=>'Pendientes'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(37806762584106520)
,p_plug_display_sequence=>60
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select x.id idact',
'	, y.id idlev',
'	, lpad(to_number(x.coderp),8,''0'') coderpfrm',
'	, x.codactivo',
'	, y.codusuario',
'	, descripcion1',
'	, descripcion2',
'	, descripcion3',
'	, codtipo',
'	, codcategoria',
'	, codsubcategoria',
'	, codcustodio',
'	, y.estado',
'	, y.origen',
unistr('	, decode(y.revisado,''S'',''S\00CD'',''N'',''NO'',null) encontrado'),
unistr('	, case when y.revisado is null then ''NO'' else ''S\00CD'' end revisado'),
'	, y.descripcionrevision',
'	, y.codgrupoaud',
'	, data.pk_finz_activosfijos.f_validacambiolev(x.compania,x.coderp) banderajde',
'from data.t_finz_activosfijos x,data.t_finz_activosfijoslev y',
'where 1 = 1',
'and x.coderp = y.coderp',
'and y.estado = ''PENDIENTE''',
'and (y.codusuario = :app_user or y.USERCREA = :app_user or :app_user = ''DDELACRUZ'')'))
,p_plug_source_type=>'NATIVE_IR'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
,p_created_on=>wwv_flow_imp.dz('20260518035851Z')
,p_updated_on=>wwv_flow_imp.dz('20260522165734Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(465822083816129016)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'C'
,p_show_computation=>'N'
,p_show_aggregate=>'N'
,p_show_chart=>'N'
,p_show_group_by=>'N'
,p_show_flashback=>'N'
,p_show_help=>'N'
,p_download_formats=>'XLSX:PDF'
,p_enable_mail_download=>'N'
,p_detail_link=>'f?p=&APP_ID.:471:&SESSION.::&DEBUG.:471:P471_IDACT,P471_IDLEV:#IDACT#,#IDLEV#'
,p_detail_link_text=>'<span aria-hidden="true" class="fa fa-wrench"></span>'
,p_owner=>'DDELACRUZ'
,p_internal_uid=>465822083816129016
,p_created_on=>wwv_flow_imp.dz('20260518035851Z')
,p_updated_on=>wwv_flow_imp.dz('20260522165734Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(465822224329129018)
,p_db_column_name=>'IDACT'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Idact'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20260518035851Z')
,p_updated_on=>wwv_flow_imp.dz('20260518035851Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(465914000425431805)
,p_db_column_name=>'CODERPFRM'
,p_display_order=>30
,p_column_identifier=>'N'
,p_column_label=>unistr('C\00F3d. ERP')
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20260518050802Z')
,p_updated_on=>wwv_flow_imp.dz('20260518052058Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(465822411283129020)
,p_db_column_name=>'CODACTIVO'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>unistr('C\00F3d. Activo')
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20260518035851Z')
,p_updated_on=>wwv_flow_imp.dz('20260518052057Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(465822553141129021)
,p_db_column_name=>'DESCRIPCION1'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>unistr('Descripci\00F3n 1')
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20260518035851Z')
,p_updated_on=>wwv_flow_imp.dz('20260518052057Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(465822652867129022)
,p_db_column_name=>'DESCRIPCION2'
,p_display_order=>70
,p_column_identifier=>'F'
,p_column_label=>unistr('Descripci\00F3n 2')
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20260518035851Z')
,p_updated_on=>wwv_flow_imp.dz('20260518052057Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(465822791193129023)
,p_db_column_name=>'DESCRIPCION3'
,p_display_order=>80
,p_column_identifier=>'G'
,p_column_label=>unistr('Descripci\00F3n')
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20260518035851Z')
,p_updated_on=>wwv_flow_imp.dz('20260518052057Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(465822865686129024)
,p_db_column_name=>'CODTIPO'
,p_display_order=>90
,p_column_identifier=>'H'
,p_column_label=>'Tipo'
,p_column_type=>'STRING'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_heading_alignment=>'LEFT'
,p_rpt_named_lov=>wwv_flow_imp.id(98576969558658537)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20260518035851Z')
,p_updated_on=>wwv_flow_imp.dz('20260518054452Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(465822917333129025)
,p_db_column_name=>'CODCATEGORIA'
,p_display_order=>100
,p_column_identifier=>'I'
,p_column_label=>unistr('Categor\00EDa')
,p_column_type=>'STRING'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_heading_alignment=>'LEFT'
,p_rpt_named_lov=>wwv_flow_imp.id(98577560814666584)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20260518035851Z')
,p_updated_on=>wwv_flow_imp.dz('20260518054452Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(465823037833129026)
,p_db_column_name=>'CODSUBCATEGORIA'
,p_display_order=>110
,p_column_identifier=>'J'
,p_column_label=>unistr('Subcategor\00EDa')
,p_column_type=>'STRING'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_heading_alignment=>'LEFT'
,p_rpt_named_lov=>wwv_flow_imp.id(98577774561669941)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20260518035851Z')
,p_updated_on=>wwv_flow_imp.dz('20260518054452Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(465823180408129027)
,p_db_column_name=>'CODCUSTODIO'
,p_display_order=>120
,p_column_identifier=>'K'
,p_column_label=>'Custodio'
,p_column_type=>'STRING'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_heading_alignment=>'LEFT'
,p_rpt_named_lov=>wwv_flow_imp.id(336564499940306120)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20260518035851Z')
,p_updated_on=>wwv_flow_imp.dz('20260518055021Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(465823231242129028)
,p_db_column_name=>'ESTADO'
,p_display_order=>130
,p_column_identifier=>'L'
,p_column_label=>'Estado'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20260518035851Z')
,p_updated_on=>wwv_flow_imp.dz('20260518052058Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(465823354342129029)
,p_db_column_name=>'BANDERAJDE'
,p_display_order=>140
,p_column_identifier=>'M'
,p_column_label=>'JDE'
,p_column_type=>'NUMBER'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20260518035851Z')
,p_updated_on=>wwv_flow_imp.dz('20260518052058Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(472291599760936001)
,p_db_column_name=>'CODUSUARIO'
,p_display_order=>150
,p_column_identifier=>'O'
,p_column_label=>'Usr. Asignado'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20260522070335Z')
,p_updated_on=>wwv_flow_imp.dz('20260522070335Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(472292216098936008)
,p_db_column_name=>'IDLEV'
,p_display_order=>160
,p_column_identifier=>'P'
,p_column_label=>'Idlev'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_created_on=>wwv_flow_imp.dz('20260522071323Z')
,p_updated_on=>wwv_flow_imp.dz('20260522071323Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(472292432691936010)
,p_db_column_name=>'REVISADO'
,p_display_order=>170
,p_column_identifier=>'Q'
,p_column_label=>'Revisado'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20260522071528Z')
,p_updated_on=>wwv_flow_imp.dz('20260522165425Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(472292579903936011)
,p_db_column_name=>'DESCRIPCIONREVISION'
,p_display_order=>180
,p_column_identifier=>'R'
,p_column_label=>unistr('Desc. Revisi\00F3n')
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20260522071528Z')
,p_updated_on=>wwv_flow_imp.dz('20260522071528Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(469083113809075110)
,p_db_column_name=>'ORIGEN'
,p_display_order=>190
,p_column_identifier=>'S'
,p_column_label=>'Origen'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20260522162338Z')
,p_updated_on=>wwv_flow_imp.dz('20260522162338Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(469083272834075111)
,p_db_column_name=>'CODGRUPOAUD'
,p_display_order=>200
,p_column_identifier=>'T'
,p_column_label=>'Proceso'
,p_column_type=>'NUMBER'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20260522163411Z')
,p_updated_on=>wwv_flow_imp.dz('20260522163411Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(469083346347075112)
,p_db_column_name=>'ENCONTRADO'
,p_display_order=>210
,p_column_identifier=>'U'
,p_column_label=>'Encontrado'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20260522165336Z')
,p_updated_on=>wwv_flow_imp.dz('20260522165425Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(465910755046318627)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'4659108'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_view_mode=>'REPORT'
,p_report_columns=>'ORIGEN:CODGRUPOAUD:CODERPFRM:CODACTIVO:DESCRIPCION3:CODTIPO:CODCATEGORIA:CODCUSTODIO:CODUSUARIO:ENCONTRADO:REVISADO:'
,p_sort_column_1=>'CODUSUARIO'
,p_sort_direction_1=>'ASC'
,p_sort_column_2=>'CODERPFRM'
,p_sort_direction_2=>'DESC'
,p_sort_column_3=>'0'
,p_sort_direction_3=>'ASC'
,p_sort_column_4=>'0'
,p_sort_direction_4=>'ASC'
,p_sort_column_5=>'0'
,p_sort_direction_5=>'ASC'
,p_sort_column_6=>'0'
,p_sort_direction_6=>'ASC'
,p_break_on=>'ORIGEN'
,p_break_enabled_on=>'ORIGEN'
,p_created_on=>wwv_flow_imp.dz('20260518040700Z')
,p_updated_on=>wwv_flow_imp.dz('20260522165734Z')
,p_created_by=>'GCACHIPUENDO'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(134217561926902012)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(134002978763051436)
,p_button_name=>'CARGAR_ARCHIVO'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860056812106557)
,p_button_image_alt=>'Cargar Archivo'
,p_icon_css_classes=>'fa-file-arrow-up'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(134153695996101098)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(134110025123100876)
,p_button_name=>'CANCEL'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860056812106557)
,p_button_image_alt=>'Cancel'
,p_button_position=>'TOP'
,p_button_alignment=>'LEFT'
,p_button_redirect_url=>'f?p=&APP_ID.:460:&APP_SESSION.::&DEBUG.:::'
,p_icon_css_classes=>'fa-arrow-left'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(349044983053138623)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(134110025123100876)
,p_button_name=>'ACTUALIZAJDE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860056812106557)
,p_button_image_alt=>'Actualiza JDE'
,p_button_position=>'TOP'
,p_button_alignment=>'RIGHT'
,p_button_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ''x''',
'from data.t_finz_activosfijos x,data.t_finz_activosfijoslev y',
'where 1 = 1',
'and x.coderp = y.coderp',
'and y.estado = ''PENDIENTE''',
'and (y.codusuario = :app_user or y.USERCREA = :app_user)',
'and data.pk_finz_activosfijos.f_validacambiolev(x.compania,x.coderp) = 1'))
,p_button_condition_type=>'EXISTS'
,p_icon_css_classes=>'fa-send-o'
,p_updated_on=>wwv_flow_imp.dz('20260521181229Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(134217733087902014)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(134110025123100876)
,p_button_name=>'FINAUDITORIA'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860056812106557)
,p_button_image_alt=>unistr('Culminar Auditor\00EDa')
,p_button_position=>'TOP'
,p_button_alignment=>'RIGHT'
,p_button_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT 1 FROM T_FINZ_ACTIVOSFIJOSLEV',
'WHERE ESTADO = ''PENDIENTE'' AND CODUSUARIO=:APP_USER and 1 = 2;'))
,p_button_condition_type=>'EXISTS'
,p_icon_css_classes=>'fa-save-as'
,p_updated_on=>wwv_flow_imp.dz('20260522073215Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(134155381203101100)
,p_branch_name=>'Go To Page 462'
,p_branch_action=>'f?p=&APP_ID.:462:&SESSION.::&DEBUG.:::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_sequence=>1
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(134216893575902005)
,p_name=>'P462_NUMEROARCHIVO_BORRAR'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(134003153785051438)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(134217421457902011)
,p_name=>'P462_ARCHIVO'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(134003098426051437)
,p_prompt=>'Archivo'
,p_display_as=>'NATIVE_FILE'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'APEX_APPLICATION_TEMP_FILES'
,p_attribute_09=>'SESSION'
,p_attribute_10=>'N'
,p_attribute_12=>'INLINE'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(134002326994051430)
,p_name=>'seleccionconboton'
,p_event_sequence=>10
,p_triggering_element_type=>'JQUERY_SELECTOR'
,p_triggering_element=>'.chkF02'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
,p_updated_on=>wwv_flow_imp.dz('20260518035408Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(134002414439051431)
,p_event_id=>wwv_flow_imp.id(134002326994051430)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P462_SELECCIONADO'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'var lineas ="";',
'document.querySelectorAll(''.chkF02'').forEach(function(seleccion) {',
'    if(seleccion.checked){',
'        var linea = seleccion.value',
'        if(lineas==""){',
'            lineas = linea;',
'        }else{',
'            //lineas = lineas+'',''+linea;',
'            lineas = linea;',
'        }      ',
'    }',
'',
'});',
'console.log(''linea selecionada: ''+lineas);',
'apex.item("P462_SELECCIONADO").setValue(lineas);'))
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(134002526316051432)
,p_event_id=>wwv_flow_imp.id(134002326994051430)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'	:G_VALOR1:=:P462_SELECCIONADO;',
'',
'	SELECT JSON_OBJECT(* RETURNING CLOB) INTO :P462_ORIG_JSON',
'                      FROM T_FINZ_ACTIVOSFIJOS',
'                      WHERE id = :G_VALOR1;',
'',
'	exception when others then :P462_ORIG_JSON := null;',
'end;'))
,p_attribute_03=>'G_VALOR1'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20260518035408Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(134002667165051433)
,p_event_id=>wwv_flow_imp.id(134002326994051430)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_02=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(134216905936902006)
,p_name=>'EjecutarBorradoArchivo'
,p_event_sequence=>20
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P462_NUMEROARCHIVO_BORRAR'
,p_condition_element=>'P462_NUMEROARCHIVO_BORRAR'
,p_triggering_condition_type=>'NOT_NULL'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(134217098845902007)
,p_event_id=>wwv_flow_imp.id(134216905936902006)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_CONFIRM'
,p_attribute_01=>unistr('\00BFEsta seguro de eliminar el arhivo?')
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(134217119820902008)
,p_event_id=>wwv_flow_imp.id(134216905936902006)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DELETE FROM FILES.T_APEX_ARCHIVOS ',
'WHERE NUMEROARCHIVO = :P462_NUMEROARCHIVO_BORRAR;'))
,p_attribute_02=>'P462_NUMEROARCHIVO_BORRAR'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(134217268455902009)
,p_event_id=>wwv_flow_imp.id(134216905936902006)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(134003153785051438)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(134217346428902010)
,p_event_id=>wwv_flow_imp.id(134216905936902006)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P462_NUMEROARCHIVO_BORRAR'
,p_attribute_01=>'FUNCTION_BODY'
,p_attribute_06=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
'    :P462_NUMEROARCHIVO_BORRAR := NULL;',
'END;'))
,p_attribute_08=>'Y'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(134217969442902016)
,p_process_sequence=>30
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'log update after'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'  v_new_json CLOB;',
'  v_old_hash RAW(32);',
'  v_new_hash RAW(32);',
'  l_changed  BOOLEAN := FALSE;',
'',
'   -- reemplazo para ORA_HASH',
'  FUNCTION calc_hash(p_text CLOB) RETURN RAW IS',
'  BEGIN',
'    IF p_text IS NULL THEN',
'      RETURN NULL;',
'    END IF;',
'',
'    RETURN DBMS_CRYPTO.HASH(',
'             UTL_RAW.CAST_TO_RAW(p_text),',
'             DBMS_CRYPTO.HASH_SH256',
'           );',
'  END;',
'',
'BEGIN',
'  -- si es INSERT no lo consideramos UPDATE',
'  IF :P462_ID IS NULL THEN',
'    RETURN;',
'  END IF;',
'',
'  SELECT JSON_OBJECT(* RETURNING CLOB) INTO v_new_json',
'                      FROM T_FINZ_ACTIVOSFIJOS',
'                      WHERE id = :P462_ID;',
'',
unistr('  -- hashes y comparaci\00F3n'),
'  IF :P462_ORIG_JSON IS NOT NULL THEN',
'    v_old_hash := calc_hash(:P462_ORIG_JSON);',
'  END IF;',
'  v_new_hash := calc_hash(v_new_json);',
'',
'  IF v_old_hash IS NULL OR v_old_hash != v_new_hash THEN',
'    IF :P462_ORIG_JSON IS NULL OR :P462_ORIG_JSON != v_new_json THEN',
'      l_changed := TRUE;',
'    END IF;',
'  END IF;',
'',
'  IF l_changed THEN',
'    --PK_FINZ_ACTIVOSFIJOS.SP_LOG(:G_COMPANIA,''T_FINZ_ACTIVOSFIJOS'',:P462_ID,'''','''',''AFTER_MODIFICAR'',:APP_PAGE_ID,'''',''LEVANTAMIENTO FISICO'');',
'    INSERT INTO T_FINZ_ACTIVOSFIJOSLOG (COMPANIA,IDACT,CODERP, CODACTIVO,TABLA,ACCION,PAGINA,EVENTO,MENSAJE,DETALLE)',
'          VALUES (:G_COMPANIA,:P462_ID,:P462_CODERP,:P462_CODACTIVO,''T_FINZ_ACTIVOSFIJOS'',''BEFORE_MODIFICAR'',:APP_PAGE_ID,'''',''LEVANTAMIENTO FISICO'',:P462_ORIG_JSON);',
'',
'    INSERT INTO T_FINZ_ACTIVOSFIJOSLOG (COMPANIA,IDACT,CODERP, CODACTIVO,TABLA,ACCION,PAGINA,EVENTO,MENSAJE,DETALLE)',
'          VALUES (:G_COMPANIA,:P462_ID,:P462_CODERP,:P462_CODACTIVO,''T_FINZ_ACTIVOSFIJOS'',''AFTER_MODIFICAR'',:APP_PAGE_ID,'''',''LEVANTAMIENTO FISICO'',v_new_json);',
'',
'    -- actualizo la tabla de levantamiento',
'    UPDATE T_FINZ_ACTIVOSFIJOSLEV SET FECHALEV=SYSDATE,USUARIOLEV=DECODE(CODUSUARIO,:APP_USER,'''',:APP_USER),ESTADO=''ENPROCESO''',
'    WHERE IDACT=:P462_ID;',
'',
'    :P462_ORIG_JSON := v_new_json;',
'    :P462_ORIG_HASH := v_new_hash;',
'  END IF;',
'',
'EXCEPTION',
'  WHEN OTHERS THEN',
'    RAISE;',
'END;',
''))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>134217969442902016
,p_updated_on=>wwv_flow_imp.dz('20260518055333Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(134002885313051435)
,p_process_sequence=>40
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Descripcion1'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'  DESC1 VARCHAR2(100) := '''';',
'  DESC2 VARCHAR2(100) := '''';',
'  V_CONTADOR   NUMBER  :=0;',
'BEGIN',
'/*',
'  BEGIN',
'    SELECT TRIM(DRDL01) INTO DESC1',
'    FROM VT_JDE_UDC',
'    WHERE DRSY=''12'' AND DRRT=''22'' AND TRIM(DRKY)=:P462_CODCATEGORIA;',
'  EXCEPTION WHEN NO_DATA_FOUND THEN',
'    DESC1 := ''SIN CATEGORIA'';',
'  END;',
'',
'  BEGIN',
'    SELECT TRIM(DRDL01) INTO DESC2',
'    FROM VT_JDE_UDC',
'    WHERE DRSY=''12'' AND DRRT=''23'' AND TRIM(DRKY)=:P462_CODSUBCATEGORIA;',
'  EXCEPTION WHEN NO_DATA_FOUND THEN',
'    DESC2 := ''SIN SUBCATEGORIA'';',
'  END;',
'',
'  IF DESC1 <> DESC2 THEN',
'    :P462_DESCRIPCION1 := SUBSTR(DESC1 || '' '' || DESC2,1,30);',
'  ELSE',
'    :P462_DESCRIPCION1 := SUBSTR(DESC1,1,30);',
'  END IF;',
'*/',
'	null;',
'END;',
''))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>134002885313051435
,p_updated_on=>wwv_flow_imp.dz('20260521180940Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(134217610349902013)
,p_process_sequence=>50
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Cargar_Archvio'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'-- cargo archivo a la tabla definitiva',
'declare v_valor number;',
'begin',
'	data.pk_apex_archivos.sp_creararchivo(',
'		:P462_ARCHIVO',
'		, ''T_FINZ_ACTIVOSFIJOS''',
'		, :P462_ID',
'		, ''LEVANTAMIANTO_FISICO''',
'		, ''''',
'		, :app_user',
'		, v_valor',
'	);',
'',
'	update files.t_apex_archivos set estado = 1 where numeroarchivo = v_valor;',
'end;',
''))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(134217561926902012)
,p_internal_uid=>134217610349902013
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(134218528646902022)
,p_process_sequence=>60
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'CERRAR'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'UPDATE T_FINZ_ACTIVOSFIJOSLEV SET FECHACIERRE=SYSDATE,ESTADO=''CERRADO''',
'WHERE 1 = 2 and ESTADO=''ENPROCESO'' AND CODUSUARIO=:APP_USER AND FECHACIERRE IS NULL;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>134218528646902022
,p_updated_on=>wwv_flow_imp.dz('20260518063613Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(349044838478138622)
,p_process_sequence=>70
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Actualiza Datos'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'	data.pk_finz_activosfijos.sp_actualizadatoslev(:g_compania,:app_user);',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(349044983053138623)
,p_internal_uid=>349044838478138622
,p_updated_on=>wwv_flow_imp.dz('20260518063614Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(134002718844051434)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Recupera'
,p_process_sql_clob=>'null;'
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>134002718844051434
,p_updated_on=>wwv_flow_imp.dz('20260518035925Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp.component_end;
end;
/
