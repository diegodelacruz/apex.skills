prompt --application/pages/page_01103
begin
--   Manifest
--     PAGE: 01103
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>109
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_page.create_page(
 p_id=>1103
,p_name=>'Copiar Registros'
,p_page_mode=>'MODAL'
,p_step_title=>'Copiar Registros'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_page_component_map=>'16'
,p_created_on=>wwv_flow_imp.dz('20230705164635Z')
,p_last_updated_on=>wwv_flow_imp.dz('20210323050000Z')
,p_last_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(350309103975572432)
,p_plug_name=>'Copiar de'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(38289867500120143)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(350309490134572435)
,p_button_sequence=>60
,p_button_plug_id=>wwv_flow_imp.id(350309103975572432)
,p_button_name=>'COPY'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860181880106559)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Copiar'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(495890644204604306)
,p_button_sequence=>70
,p_button_plug_id=>wwv_flow_imp.id(350309103975572432)
,p_button_name=>'CANCEL'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860181880106559)
,p_button_image_alt=>'Cancel'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'LEFT'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(350309251932572433)
,p_name=>'P1103_PERIODO'
,p_is_required=>true
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(350309103975572432)
,p_prompt=>'Periodo'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select distinct',
'	  to_char(to_date(anno||mes,''yyyymm''),''mm/yyyy'') d',
'    , to_char(to_date(anno||mes,''yyyymm''),''mm/yyyy'') r',
'from t_finz_costeocab order by to_char(to_date(anno||mes,''yyyymm''),''mm/yyyy'') desc'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'Seleccione'
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(350309389123572434)
,p_name=>'P1103_VERSION'
,p_is_required=>true
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(350309103975572432)
,p_prompt=>unistr('Versi\00F3n')
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select distinct numeroversion d',
'	, numeroversion r',
'from t_finz_costeocab where to_char(to_date(anno||mes,''yyyymm''),''mm/yyyy'') = :p1103_periodo order by numeroversion desc'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'Seleccione'
,p_lov_cascade_parent_items=>'P1103_PERIODO'
,p_ajax_items_to_submit=>'P1103_PERIODO'
,p_ajax_optimize_refresh=>'Y'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'NONE'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(495869742773498207)
,p_name=>'Cancel Dialog'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(495890644204604306)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(495869871381498208)
,p_event_id=>wwv_flow_imp.id(495869742773498207)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CANCEL'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(350309681484572437)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'copiar'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare v_aux_num number;',
'begin',
unistr('    /*-- Esta acci\00F3n reemplaza los valores ya ingresados. --*/'),
'    select max(id) into v_aux_num from t_finz_costeocab where to_char(to_date(anno||mes,''yyyymm''),''mm/yyyy'') = :p1103_periodo and numeroversion= :p1103_version;',
'    ',
'    -- Borro los registros.',
'    delete from t_finz_costeodet where idcab = :g_variable;',
'    ',
'    -- Inserto los registros nuevos-copiados.',
'    insert into t_finz_costeodet (idcab,codigodivision,codigomaquina,horasmes,horasturno,turnosmes,unidadesminuto,personasturno,kiloshora,porcentajeefectividad,porcentajesegunda,porcentajedesperdicio,costodesperdicio,turnosdia)',
'    select :g_variable,codigodivision,codigomaquina,horasmes,horasturno,turnosmes,unidadesminuto,personasturno,kiloshora,porcentajeefectividad,porcentajesegunda,porcentajedesperdicio,costodesperdicio,turnosdia',
'    from t_finz_costeodet where idcab = v_aux_num;',
'    commit;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_process_error_message=>'No se pudo copiar.'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_success_message=>'Registros copiados.'
,p_internal_uid=>350309681484572437
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(495869996272498209)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_CLOSE_WINDOW'
,p_process_name=>'Close'
,p_attribute_02=>'N'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(350309490134572435)
,p_internal_uid=>495869996272498209
);
wwv_flow_imp.component_end;
end;
/
