prompt --application/pages/page_00110
begin
--   Manifest
--     PAGE: 00110
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>109
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_page.create_page(
 p_id=>110
,p_name=>'Jde Detalle de Movimientos Kardex'
,p_page_mode=>'MODAL'
,p_step_title=>'Jde Detalle de Movimientos Kardex'
,p_autocomplete_on_off=>'OFF'
,p_javascript_code_onload=>wwv_flow_string.join(wwv_flow_t_varchar2(
'$(secItems).hide();',
''))
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.a-IRR-controls-item--controlBreak {',
'     display: block;',
'}',
'.a-IRR-reportSummary-item--controlBreak{',
'     display: block;',
'}',
'.a-IRR-controls-item--highlight{',
'     display: block;',
'}',
'#R230856873136219535_control_panel{',
'    display: none;',
'}',
'.a-IRR-button.a-IRR-button--controls {',
'    display: block;',
'    background-color: transparent;',
'}',
'.a-IRR-aggregate-value{',
'    font-weight: bolder;',
'}',
'',
''))
,p_page_template_options=>'#DEFAULT#'
,p_dialog_height=>'550'
,p_dialog_width=>'1200'
,p_dialog_max_width=>'1200'
,p_page_component_map=>'18'
,p_created_on=>wwv_flow_imp.dz('20230705164634Z')
,p_last_updated_on=>wwv_flow_imp.dz('20230508160445Z')
,p_last_updated_by=>'EMASABANDA'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(115378530597112141)
,p_plug_name=>'Barra de acciones'
,p_region_template_options=>'#DEFAULT#:t-Form--stretchInputs'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(38289497777120142)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(37761271469106475)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(37860983999106559)
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(230403778190518952)
,p_plug_name=>'regitems'
,p_region_name=>'secItems'
,p_region_template_options=>'#DEFAULT#:t-Form--noPadding:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(38289867500120143)
,p_plug_display_sequence=>30
,p_include_in_reg_disp_sel_yn=>'Y'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(230404614249518960)
,p_plug_name=>'Cabecera'
,p_region_template_options=>'#DEFAULT#:t-Form--noPadding:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(38289867500120143)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'htp.p(''<div id="coloresLista">'');',
'        FOR codigoColores IN (SELECT VALOR, VALOR2 FROM T_CORP_UDC WHERE ID_CABECERA = ''INVE_COLOR'' AND VALOR3 =2 order by ID_TABLA)',
'        LOOP',
'         htp.p(''<span style="margin-left : 15px;">''|| codigoColores.VALOR || ''<span class="fa fa-square" style="color: '' || codigoColores.VALOR2 ||''; margin-left: 5px;" >',
'                                                  <spam class="visuallyhidden">Verificado</spam>',
'                                              </span>''||   ''</span>'');',
'        END LOOP;',
'   htp.p(''</div>'');'))
,p_plug_source_type=>'NATIVE_PLSQL'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(230856873136219535)
,p_plug_name=>'Detalle Kardex'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(37806762584106520)
,p_plug_display_sequence=>40
,p_include_in_reg_disp_sel_yn=>'Y'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select',
'        bodega,',
'        aniocontable anio,',
'        mescontable mes,',
'        mescontable mes_valor,',
'        ubicacion,',
'        lote,',
'        glclass glcls,',
'        codigojde producto,',
'        codigojde codproducto,',
'        orden,',
'        tipoorden,',
'        documento,',
'        tipodocumento,',
'        asof_sino,',
'        sum(catidadconversion)/10000 kardex_cantidad,',
'        sum(costo)/100 kardex_costo',
'        ,decode (asof_sino,''Y'',1,''X'',2,3) color',
'    from',
'        t_inv_movimientoskardex    where --aniocontable,bodega,asof_sino,codigojde',
'           1=1',
'            and aniocontable = :p110_anio_filtro',
'            and trim(bodega) = nvl(:p110_bodega_filtro, trim(bodega))',
'            and asof_sino=asof_sino',
'            and codigojde = nvl(:p110_producto_filtro, codigojde)',
'            and mescontable = nvl(:p110_mes_filtro, mescontable)',
'            and glclass = nvl(:p110_glcls_filtro, glclass)',
'            and nvl(trim(ubicacion), '' '') = nvl(:p110_ubicacion_filtro,'' '')',
'            and nvl(trim(lote), '' '') = nvl(:p110_lote_filtro,  '' '')',
'    group by bodega,aniocontable,mescontable,ubicacion,lote,glclass,codigojde,orden,tipoorden,documento,tipodocumento,asof_sino;'))
,p_plug_source_type=>'NATIVE_IR'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>210
,p_prn_height=>297
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(230856982612219536)
,p_max_row_count=>'1000000'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_show_display_row_count=>'Y'
,p_show_search_textbox=>'N'
,p_report_list_mode=>'NONE'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_select_columns=>'N'
,p_show_filter=>'N'
,p_show_sort=>'N'
,p_show_control_break=>'N'
,p_show_highlight=>'N'
,p_show_computation=>'N'
,p_show_aggregate=>'N'
,p_show_chart=>'N'
,p_show_group_by=>'N'
,p_show_pivot=>'N'
,p_show_notify=>'Y'
,p_show_flashback=>'N'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'EMASABANDA'
,p_internal_uid=>230856982612219536
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(115492442883107424)
,p_db_column_name=>'ORDEN'
,p_display_order=>100
,p_column_identifier=>'J'
,p_column_label=>'Orden'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(115492828326107425)
,p_db_column_name=>'TIPOORDEN'
,p_display_order=>110
,p_column_identifier=>'K'
,p_column_label=>'Tipoorden'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(115493206099107425)
,p_db_column_name=>'DOCUMENTO'
,p_display_order=>120
,p_column_identifier=>'L'
,p_column_label=>'Documento'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(115493611119107425)
,p_db_column_name=>'TIPODOCUMENTO'
,p_display_order=>130
,p_column_identifier=>'M'
,p_column_label=>'Tipodocumento'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(115494066894107427)
,p_db_column_name=>'KARDEX_CANTIDAD'
,p_display_order=>140
,p_column_identifier=>'N'
,p_column_label=>'Kardex Cantidad'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D0000'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(115494405268107427)
,p_db_column_name=>'KARDEX_COSTO'
,p_display_order=>150
,p_column_identifier=>'O'
,p_column_label=>'Kardex Costo'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G990D00'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(118841260782907511)
,p_db_column_name=>'COLOR'
,p_display_order=>170
,p_column_identifier=>'Q'
,p_column_label=>'Color'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(115488830653107424)
,p_db_column_name=>'BODEGA'
,p_display_order=>180
,p_column_identifier=>'A'
,p_column_label=>'Bodega'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(115489217350107424)
,p_db_column_name=>'ANIO'
,p_display_order=>190
,p_column_identifier=>'B'
,p_column_label=>'Anio'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(115489685315107424)
,p_db_column_name=>'MES'
,p_display_order=>200
,p_column_identifier=>'C'
,p_column_label=>'Mes'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(115490049260107424)
,p_db_column_name=>'MES_VALOR'
,p_display_order=>210
,p_column_identifier=>'D'
,p_column_label=>'Mes Valor'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(115490468110107424)
,p_db_column_name=>'UBICACION'
,p_display_order=>220
,p_column_identifier=>'E'
,p_column_label=>'Ubicacion'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(115490848810107424)
,p_db_column_name=>'LOTE'
,p_display_order=>230
,p_column_identifier=>'F'
,p_column_label=>'Lote'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(115491253226107424)
,p_db_column_name=>'GLCLS'
,p_display_order=>240
,p_column_identifier=>'G'
,p_column_label=>'Glcls'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(115491653840107424)
,p_db_column_name=>'CODPRODUCTO'
,p_display_order=>250
,p_column_identifier=>'H'
,p_column_label=>'Codproducto'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(115492049714107424)
,p_db_column_name=>'PRODUCTO'
,p_display_order=>260
,p_column_identifier=>'I'
,p_column_label=>'Producto'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(118841138076907510)
,p_db_column_name=>'ASOF_SINO'
,p_display_order=>270
,p_column_identifier=>'P'
,p_column_label=>'Asof Sino'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(230900766942254125)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'1154948'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'ORDEN:TIPOORDEN:DOCUMENTO:TIPODOCUMENTO:KARDEX_CANTIDAD:KARDEX_COSTO:'
,p_sum_columns_on_break=>'KARDEX_CANTIDAD:KARDEX_COSTO'
,p_created_on=>wwv_flow_imp.dz('20230705164634Z')
,p_updated_on=>wwv_flow_imp.dz('20230705164634Z')
,p_created_by=>'CVACA'
,p_updated_by=>'CVACA'
);
wwv_flow_imp_page.create_worksheet_condition(
 p_id=>wwv_flow_imp.id(118912111015543322)
,p_report_id=>wwv_flow_imp.id(230900766942254125)
,p_name=>'Contabilizado'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'COLOR'
,p_operator=>'='
,p_expr=>'1'
,p_condition_sql=>' (case when ("COLOR" = to_number(#APXWS_EXPR#)) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_row_bg_color=>'#87D973'
,p_created_on=>wwv_flow_imp.dz('20230705164634Z')
,p_updated_on=>wwv_flow_imp.dz('20230705164634Z')
,p_created_by=>'CVACA'
,p_updated_by=>'CVACA'
);
wwv_flow_imp_page.create_worksheet_condition(
 p_id=>wwv_flow_imp.id(118912530980543322)
,p_report_id=>wwv_flow_imp.id(230900766942254125)
,p_name=>'No se toma en cuenta en el ASOF'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'COLOR'
,p_operator=>'='
,p_expr=>'2'
,p_condition_sql=>' (case when ("COLOR" = to_number(#APXWS_EXPR#)) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_row_bg_color=>'#FF8282'
,p_created_on=>wwv_flow_imp.dz('20230705164634Z')
,p_updated_on=>wwv_flow_imp.dz('20230705164634Z')
,p_created_by=>'CVACA'
,p_updated_by=>'CVACA'
);
wwv_flow_imp_page.create_worksheet_condition(
 p_id=>wwv_flow_imp.id(118912905254543322)
,p_report_id=>wwv_flow_imp.id(230900766942254125)
,p_name=>'Pendiente de Contabilizar'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'COLOR'
,p_operator=>'='
,p_expr=>'3'
,p_condition_sql=>' (case when ("COLOR" = to_number(#APXWS_EXPR#)) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_row_bg_color=>'#A3ABFF'
,p_created_on=>wwv_flow_imp.dz('20230705164634Z')
,p_updated_on=>wwv_flow_imp.dz('20230705164634Z')
,p_created_by=>'CVACA'
,p_updated_by=>'CVACA'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(230859009301219556)
,p_plug_name=>'Botones'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(38289867500120143)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'REGION_POSITION_03'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(115481512547107419)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(115378530597112141)
,p_button_name=>'Procesar'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860056812106557)
,p_button_image_alt=>'Procesar'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_button_condition=>'P110_CONTADOR'
,p_button_condition_type=>'ITEM_NOT_NULL_OR_ZERO'
,p_icon_css_classes=>'fa fa-cogs'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(115495586794107432)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(230859009301219556)
,p_button_name=>'Cerrar'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860181880106559)
,p_button_image_alt=>'Cerrar'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(129199039869469915)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(115378530597112141)
,p_button_name=>'Inserta'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860056812106557)
,p_button_image_alt=>'Inserta'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_button_condition=>'P110_CONTADOR'
,p_button_condition_type=>'ITEM_IS_NULL_OR_ZERO'
,p_icon_css_classes=>'fa-server-edit'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(115497819158107433)
,p_branch_name=>'Goto 109'
,p_branch_action=>'f?p=&APP_ID.:109:&SESSION.::&DEBUG.:RP::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_imp.id(115481512547107419)
,p_branch_sequence=>10
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(115482203382107421)
,p_name=>'P110_PERIODO'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(230404614249518960)
,p_prompt=>'Periodo:'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(115482651791107421)
,p_name=>'P110_BODEGA'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(230404614249518960)
,p_prompt=>'Bodega:'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_named_lov=>'LOV_JDE_BODEGAS'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select CODUNIDAD ||'' - ''||DESCRIPCION , CODUNIDAD from vt_jde_bodegas',
'order by 1'))
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'LOV'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(115483038766107421)
,p_name=>'P110_UBICACION'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(230404614249518960)
,p_prompt=>unistr('Ubicaci\00F3n:')
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(115483468793107421)
,p_name=>'P110_LOTE'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(230404614249518960)
,p_prompt=>'Lote:'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_warn_on_unsaved_changes=>'I'
,p_is_persistent=>'U'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(115483818950107421)
,p_name=>'P110_GLCLS'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(230404614249518960)
,p_prompt=>'Gl Clss:'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_named_lov=>'LOV_JDE_GLCLASS'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select TRIM(DRKY) || '' - '' || DRDL01, DRKY ',
'from  vt_jde_udcjde where drsy=''41'' and drrt=''9'' AND DRSPHD=''ZAIMELLA  ''',
'order by 1'))
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'LOV'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(115484288356107421)
,p_name=>'P110_CODPRODUCTO'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(230404614249518960)
,p_prompt=>'Cod. Corto:'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(115484691097107421)
,p_name=>'P110_PRODUCTO'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(230404614249518960)
,p_prompt=>'Producto:'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_named_lov=>'LOV_JDE_PRODUCTO_CODPRD_CODOCORTO'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select  (nombreproducto) || ''  (''|| trim (CODIGOPRODUCTO) ||'') - '' ||codigocorto d, codigocorto r ',
'from vt_jde_productos',
'where  trim(nombreproducto) is not null',
'order by 1'))
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'LOV'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(115485327386107422)
,p_name=>'P110_ANIO_FILTRO'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(230403778190518952)
,p_prompt=>'Anio Filtro'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(115485766264107422)
,p_name=>'P110_MES_FILTRO'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(230403778190518952)
,p_prompt=>'Mes Filtro'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(115486160256107422)
,p_name=>'P110_NOMBRE_MES'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(230403778190518952)
,p_prompt=>'Nombre Mes'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(115486502667107422)
,p_name=>'P110_BODEGA_FILTRO'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(230403778190518952)
,p_prompt=>'Bodega:'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(115486962616107422)
,p_name=>'P110_UBICACION_FILTRO'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(230403778190518952)
,p_prompt=>'Ubicacion:'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(115487335462107422)
,p_name=>'P110_LOTE_FILTRO'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(230403778190518952)
,p_prompt=>'Lote:'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(115487767456107422)
,p_name=>'P110_GLCLS_FILTRO'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(230403778190518952)
,p_prompt=>'Gl Clss:'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(115488183544107422)
,p_name=>'P110_PRODUCTO_FILTRO'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(230403778190518952)
,p_prompt=>'Producto:'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(115606658139890550)
,p_name=>'P110_TOTALCANTIDAD'
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_imp.id(230403778190518952)
,p_prompt=>'Total Cantidad'
,p_format_mask=>'999G999G999G999G990D0000'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(118442044438804601)
,p_name=>'P110_TOTALCOSTO'
,p_item_sequence=>120
,p_item_plug_id=>wwv_flow_imp.id(230403778190518952)
,p_prompt=>'Total Costo'
,p_format_mask=>'FML999G999G999G999G990D00'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(118840416506907503)
,p_name=>'P110_USUARIO'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_imp.id(230403778190518952)
,p_prompt=>'Usuario'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(127364834140346928)
,p_name=>'P110_TIPO'
,p_item_sequence=>130
,p_item_plug_id=>wwv_flow_imp.id(230403778190518952)
,p_prompt=>'Tipo'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(129199389536469918)
,p_name=>'P110_CONTADOR'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(230403778190518952)
,p_prompt=>'Contador'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(129199804696469923)
,p_name=>'Carga de Pagina'
,p_event_sequence=>10
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'ready'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(129199990601469924)
,p_event_id=>wwv_flow_imp.id(129199804696469923)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
' declare v_contador number;',
'begin',
'    select pk_jde_inventario.f_validaexisteasof ( p_initm=>:p110_producto_filtro',
'               ,p_inmcu=>:p110_bodega_filtro',
'               ,p_inlocn=>:p110_ubicacion_filtro',
'               ,p_inlotn=>:p110_lote_filtro',
'               ,p_inglpt=>:p110_glcls_filtro',
'               ,p_infy=>(:p110_anio_filtro-2000)) ',
'    into :P110_CONTADOR',
'    from dual;',
'    :P110_LOTE:=:P110_LOTE_FILTRO;',
'    if (trim(:P110_LOTE_FILTRO)is null) then',
'        :P110_LOTE:=''N/A'';',
'    end if;',
'end;'))
,p_attribute_02=>'P110_BODEGA_FILTRO,P110_UBICACION_FILTRO,P110_LOTE_FILTRO,P110_GLCLS_FILTRO,P110_ANIO_FILTRO,P110_CONTADOR,P110_LOTE'
,p_attribute_03=>'P110_CONTADOR,P110_LOTE'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(129200052398469925)
,p_event_id=>wwv_flow_imp.id(129199804696469923)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P110_CONTADOR,P110_LOTE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'$s(''P110_LOTE'',$v(''P110_LOTE_FILTRO''));',
'if($v(''P110_CONTADOR'')==0){',
'   apex.message.alert(''Previo al proceso de actualizar debe generar registro en el AsOf.'');',
'    }',
'if($v(''P110_LOTE'')==''''){',
'    $s(''P110_LOTE'',''N/A'');',
'}'))
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(115496534533107432)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Procesar Actualizacion'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
' ',
'    PK_JDE_INVENTARIO.SP_JDE_ACTUALIZADATAASOF (',
'         P_anio=>:p110_anio_filtro',
'        ,P_mes=>:p110_mes_filtro',
'        ,P_bodega=>:p110_bodega_filtro',
'        ,P_usuario=>:app_user',
'        ,P_glcls=>:p110_glcls_filtro',
'        ,P_producto=>:p110_producto_filtro',
'        ,P_ubicacion=>:p110_ubicacion_filtro',
'        ,P_lote=>:p110_lote_filtro',
'    ); ',
'    ',
'    COMMIT;',
unistr('    	apex_application.g_print_success_message :=''Actualizaci\00F3n correcta , dentro el AsOf'';'),
'   exception when others then ',
'   apex_error.add_error (',
'       p_message          => ''No se ha podido actualizar la infrmacion de AsOf'',',
'       p_display_location =>apex_error.c_inline_in_notification ',
'   ',
'   );',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(115481512547107419)
,p_internal_uid=>115496534533107432
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(115497336190107432)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_CLOSE_WINDOW'
,p_process_name=>'Cerrar Dialogo'
,p_attribute_02=>'N'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(115495586794107432)
,p_internal_uid=>115497336190107432
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(129199167602469916)
,p_process_sequence=>30
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Procesar Insercion'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare ',
'    v_infy   NUMBER;',
'    v_inmcu  NCHAR(12);',
'    v_inlocn NCHAR(20);',
'    v_inlotn NCHAR(30);',
'    v_inglpt NCHAR(4);',
'    v_initm  NUMBER;',
'    v_mensaje varchar2(999);',
'begin',
'    v_infy   := :p110_anio_filtro;',
'    v_inmcu  := trim(:p110_bodega_filtro);',
'    v_inlocn := trim(:p110_ubicacion_filtro);',
'    v_inlotn := trim(:p110_lote_filtro);',
'    v_inglpt := trim(:p110_glcls_filtro);',
'    v_initm  := :p110_producto_filtro;',
'    PK_JDE_INVENTARIO.sp_insertaAsof(v_infy,v_inmcu,v_inlocn,v_inlotn,v_inglpt,v_initm,:app_user,v_mensaje);',
'end;',
''))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(129199039869469915)
,p_internal_uid=>129199167602469916
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(115496999042107432)
,p_process_sequence=>10
,p_process_point=>'BEFORE_BOX_BODY'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Setup Interface'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
':P110_LOTE:=''ojo'';',
'',
':P110_BODEGA     :=:P110_BODEGA_FILTRO;',
':P110_UBICACION  :=:P110_UBICACION_FILTRO;',
':P110_LOTE       :=:P110_LOTE_FILTRO;',
':P110_GLCLS      :=:P110_GLCLS_FILTRO;',
':P110_CODPRODUCTO:=:P110_PRODUCTO_FILTRO;',
':P110_PRODUCTO   :=:P110_PRODUCTO_FILTRO;',
':P110_USUARIO    :=:APP_USER;',
':P110_LOTE       :=:P110_LOTE_FILTRO;',
'SELECT  ',
'     TRIM(to_char(to_date(:P110_MES_FILTRO,''MM''),''Month''))  || '' / '' || :P110_ANIO_FILTRO  ',
'into',
'     :P110_PERIODO',
'from dual  ;',
'',
':P110_LOTE :=:P110_LOTE_FILTRO;  ',
'if (trim(:P110_UBICACION_FILTRO)is null  ) then',
':P110_UBICACION:=''N/A'';',
'end if;',
'if (trim(:P110_LOTE_FILTRO)is null) then',
':P110_LOTE:=''N/A'';',
'end if;',
'',
'',
'',
''))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>115496999042107432
);
wwv_flow_imp.component_end;
end;
/
