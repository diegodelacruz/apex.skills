prompt --application/pages/page_01108
begin
--   Manifest
--     PAGE: 01108
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>109
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_page.create_page(
 p_id=>1108
,p_name=>unistr('Reporte Est\00E1ndar vs Real')
,p_step_title=>unistr('Reporte Est\00E1ndar vs Real')
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_page_component_map=>'04'
,p_created_on=>wwv_flow_imp.dz('20230705164635Z')
,p_last_updated_on=>wwv_flow_imp.dz('20210323050000Z')
,p_last_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(480772694406542802)
,p_plug_name=>'UND Mes'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(38289867500120143)
,p_plug_display_sequence=>30
,p_include_in_reg_disp_sel_yn=>'Y'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(480772764229542803)
,p_plug_name=>'UND Mes'
,p_parent_plug_id=>wwv_flow_imp.id(480772694406542802)
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(38289867500120143)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'with',
'fuente as (',
'	select fechaoperacion,to_number(to_char(fechaoperacion,''yyyy'')) anno, to_number(to_char(fechaoperacion,''mm'')) mes, codigomaquina, codigoturno,',
'	count(codigoturno) qtyturno, sum(cantidadprimera) qtypri,sum(cantidadsegunda) qtyseg,sum(cantidaddesperdicio) qtydes from t_finz_reporteproduccion',
'	group by fechaoperacion,to_number(to_char(fechaoperacion,''yyyy'')),to_number(to_char(fechaoperacion,''mm'')),codigomaquina,codigoturno),',
'mnfr as (',
'	select to_number(to_char(fecha,''yyyy'')) anno, to_number(to_char(fecha,''mm'')) mes,trim(maquina) codigomaquina,turno codigoturno, count(*) cantidadturnos, sum(horas) horas ',
'	from dp.pmf_turnos where estado = ''H'' group by to_number(to_char(fecha,''yyyy'')),to_number(to_char(fecha,''mm'')),trim(maquina),turno',
'	),',
'efec as (',
'	select anno,mes,codigomaquina,sum(qtypri) qtypri,0 horas,0 undhorapri from fuente group by anno,mes,codigomaquina,0',
'	union',
'	select anno,mes,codigomaquina,0 qtypri,sum(horas) horas,0 undhorapri from mnfr group by anno,mes,codigomaquina,0',
'	union',
'	select anno,mes,codigomaquina,0 qtypri,0 horas,unidadesminuto*60 undhorapri from vt_finz_costeo',
'	),',
'stdr as (',
'	select 1 criterio,anno,mes,codigodivision,codigomaquina,descripcionmaquina,undmes valorstdr from vt_finz_costeo',
'	union',
'	select 2 criterio,anno,mes,codigodivision,codigomaquina,descripcionmaquina,undmesseg valorstdr from vt_finz_costeo',
'	union',
'	select 3 criterio,anno,mes,codigodivision,codigomaquina,descripcionmaquina,unidadesdesperdicio valorstdr from vt_finz_costeo',
'	union',
'	select 4 criterio,anno,mes,codigodivision,codigomaquina,descripcionmaquina,turnosmes valorstdr from vt_finz_costeo',
'	union',
'	select 5 criterio,anno,mes,codigodivision,codigomaquina,descripcionmaquina,horasmes valorstdr from vt_finz_costeo',
'	union',
'	select 6 criterio,anno,mes,codigodivision,codigomaquina,descripcionmaquina,porcentajeefectividad valorstdr from vt_finz_costeo',
'	),',
'mftr as (',
'	select 1 criterio,anno,mes,codigomaquina,sum(qtypri+qtyseg) valorreal from fuente group by 1,anno,mes,codigomaquina',
'	union',
'	select 2 criterio,anno,mes,codigomaquina,sum(qtyseg) valorreal from fuente group by 2,anno,mes,codigomaquina',
'	union',
'	select 3 criterio,anno,mes,codigomaquina,sum(qtydes) valorreal from fuente group by 3,anno,mes,codigomaquina',
'	union',
'	select 4 criterio,anno,mes,codigomaquina,count(qtypri) valorreal from fuente where trim(codigoturno) is not null group by 4,anno,mes,codigomaquina',
'	union',
'	select 5 criterio,anno,mes,codigomaquina,sum(horas) valorreal from mnfr group by 5,anno,mes,codigomaquina',
'	union',
'	select 6 criterio,anno,mes,codigomaquina,case when sum(undhorapri) = 0 or sum(horas) = 0 then 0 else (sum(qtypri)/sum(horas)/sum(undhorapri))*100 end valorreal from efec group by 6,anno,mes,codigomaquina',
'	)',
'select a.*,to_char(to_date(a.anno||a.mes,''yyyymm''),''yyyy-mm'') periodo,nvl(b.valorreal,0) valorreal from stdr a',
'left join mftr b on a.criterio = b.criterio and a.anno = b.anno and a.mes = b.mes and a.codigomaquina = b.codigomaquina',
'where b.criterio = :p1108_criterio and a.codigodivision = :p1108_division and a.codigomaquina = :p1108_maquina',
'and to_date(a.anno||a.mes,''yyyymm'') between :p1108_fechadesde and :p1108_fechahasta;'))
,p_plug_source_type=>'NATIVE_JET_CHART'
,p_ajax_items_to_submit=>'P1108_CRITERIO,P1108_FECHADESDE,P1108_FECHAHASTA,P1108_DIVISION,P1108_MAQUINA'
,p_plug_query_num_rows=>15
);
wwv_flow_imp_page.create_jet_chart(
 p_id=>wwv_flow_imp.id(480772847308542804)
,p_region_id=>wwv_flow_imp.id(480772764229542803)
,p_chart_type=>'line'
,p_animation_on_display=>'auto'
,p_animation_on_data_change=>'auto'
,p_orientation=>'vertical'
,p_data_cursor=>'auto'
,p_data_cursor_behavior=>'auto'
,p_hide_and_show_behavior=>'none'
,p_hover_behavior=>'none'
,p_stack=>'off'
,p_stack_label=>'off'
,p_connect_nulls=>'Y'
,p_value_position=>'auto'
,p_sorting=>'label-asc'
,p_fill_multi_series_gaps=>true
,p_zoom_and_scroll=>'off'
,p_tooltip_rendered=>'Y'
,p_show_series_name=>true
,p_show_group_name=>true
,p_show_value=>true
,p_show_label=>true
,p_show_row=>true
,p_show_start=>true
,p_show_end=>true
,p_show_progress=>true
,p_show_baseline=>true
,p_legend_rendered=>'on'
,p_legend_position=>'auto'
,p_overview_rendered=>'off'
,p_horizontal_grid=>'auto'
,p_vertical_grid=>'auto'
,p_gauge_orientation=>'circular'
,p_gauge_plot_area=>'on'
,p_show_gauge_value=>true
);
wwv_flow_imp_page.create_jet_chart_series(
 p_id=>wwv_flow_imp.id(480772991531542805)
,p_chart_id=>wwv_flow_imp.id(480772847308542804)
,p_seq=>10
,p_name=>unistr('Est\00E1ndar')
,p_data_source_type=>'SQL'
,p_data_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'with',
'fuente as (',
'	select fechaoperacion,to_number(to_char(fechaoperacion,''yyyy'')) anno, to_number(to_char(fechaoperacion,''mm'')) mes, codigomaquina, codigoturno,',
'	count(codigoturno) qtyturno, sum(cantidadprimera) qtypri,sum(cantidadsegunda) qtyseg,sum(cantidaddesperdicio) qtydes from t_finz_reporteproduccion',
'	group by fechaoperacion,to_number(to_char(fechaoperacion,''yyyy'')),to_number(to_char(fechaoperacion,''mm'')),codigomaquina,codigoturno),',
'mnfr as (',
'	select to_number(to_char(fecha,''yyyy'')) anno, to_number(to_char(fecha,''mm'')) mes,trim(maquina) codigomaquina,turno codigoturno, count(*) cantidadturnos, sum(horas) horas ',
'	from dp.pmf_turnos where estado = ''H'' group by to_number(to_char(fecha,''yyyy'')),to_number(to_char(fecha,''mm'')),trim(maquina),turno',
'	),',
'efec as (',
'	select anno,mes,codigomaquina,sum(qtypri) qtypri,0 horas,0 undhorapri from fuente group by anno,mes,codigomaquina,0',
'	union',
'	select anno,mes,codigomaquina,0 qtypri,sum(horas) horas,0 undhorapri from mnfr group by anno,mes,codigomaquina,0',
'	union',
'	select anno,mes,codigomaquina,0 qtypri,0 horas,unidadesminuto*60 undhorapri from vt_finz_costeo',
'	),',
'stdr as (',
'	select 1 criterio,anno,mes,codigodivision,codigomaquina,descripcionmaquina,undmes valorstdr from vt_finz_costeo',
'	union',
'	select 2 criterio,anno,mes,codigodivision,codigomaquina,descripcionmaquina,undmesseg valorstdr from vt_finz_costeo',
'	union',
'	select 3 criterio,anno,mes,codigodivision,codigomaquina,descripcionmaquina,unidadesdesperdicio valorstdr from vt_finz_costeo',
'	union',
'	select 4 criterio,anno,mes,codigodivision,codigomaquina,descripcionmaquina,turnosmes valorstdr from vt_finz_costeo',
'	union',
'	select 5 criterio,anno,mes,codigodivision,codigomaquina,descripcionmaquina,horasmes valorstdr from vt_finz_costeo',
'	union',
'	select 6 criterio,anno,mes,codigodivision,codigomaquina,descripcionmaquina,porcentajeefectividad valorstdr from vt_finz_costeo',
'	),',
'mftr as (',
'	select 1 criterio,anno,mes,codigomaquina,sum(qtypri+qtyseg) valorreal from fuente group by 1,anno,mes,codigomaquina',
'	union',
'	select 2 criterio,anno,mes,codigomaquina,sum(qtyseg) valorreal from fuente group by 2,anno,mes,codigomaquina',
'	union',
'	select 3 criterio,anno,mes,codigomaquina,sum(qtydes) valorreal from fuente group by 3,anno,mes,codigomaquina',
'	union',
'	select 4 criterio,anno,mes,codigomaquina,count(qtypri) valorreal from fuente where trim(codigoturno) is not null group by 4,anno,mes,codigomaquina',
'	union',
'	select 5 criterio,anno,mes,codigomaquina,sum(horas) valorreal from mnfr group by 5,anno,mes,codigomaquina',
'	union',
'	select 6 criterio,anno,mes,codigomaquina,case when sum(undhorapri) = 0 or sum(horas) = 0 then 0 else (sum(qtypri)/sum(horas)/sum(undhorapri))*100 end valorreal from efec group by 6,anno,mes,codigomaquina',
'	)',
'select a.*,to_char(to_date(a.anno||a.mes,''yyyymm''),''yyyy-mm'') periodo,nvl(b.valorreal,0) valorreal from stdr a',
'left join mftr b on a.criterio = b.criterio and a.anno = b.anno and a.mes = b.mes and a.codigomaquina = b.codigomaquina',
'where b.criterio = :p1108_criterio and a.codigodivision = :p1108_division and a.codigomaquina = :p1108_maquina',
'and to_date(a.anno||a.mes,''yyyymm'') between :p1108_fechadesde and :p1108_fechahasta;'))
,p_ajax_items_to_submit=>'P1108_CRITERIO,P1108_FECHADESDE,P1108_FECHAHASTA,P1108_DIVISION,P1108_MAQUINA'
,p_items_value_column_name=>'VALORSTDR'
,p_items_label_column_name=>'PERIODO'
,p_color=>'#34AADC'
,p_line_style=>'dotted'
,p_line_width=>1
,p_line_type=>'curved'
,p_marker_rendered=>'on'
,p_marker_shape=>'circle'
,p_assigned_to_y2=>'off'
,p_items_label_rendered=>true
,p_items_label_position=>'auto'
,p_items_label_display_as=>'PERCENT'
,p_threshold_display=>'onIndicator'
);
wwv_flow_imp_page.create_jet_chart_series(
 p_id=>wwv_flow_imp.id(480773236374542808)
,p_chart_id=>wwv_flow_imp.id(480772847308542804)
,p_seq=>20
,p_name=>'Real'
,p_data_source_type=>'SQL'
,p_data_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'with',
'fuente as (',
'	select fechaoperacion,to_number(to_char(fechaoperacion,''yyyy'')) anno, to_number(to_char(fechaoperacion,''mm'')) mes, codigomaquina, codigoturno,',
'	count(codigoturno) qtyturno, sum(cantidadprimera) qtypri,sum(cantidadsegunda) qtyseg,sum(cantidaddesperdicio) qtydes from t_finz_reporteproduccion',
'	group by fechaoperacion,to_number(to_char(fechaoperacion,''yyyy'')),to_number(to_char(fechaoperacion,''mm'')),codigomaquina,codigoturno),',
'mnfr as (',
'	select to_number(to_char(fecha,''yyyy'')) anno, to_number(to_char(fecha,''mm'')) mes,trim(maquina) codigomaquina,turno codigoturno, count(*) cantidadturnos, sum(horas) horas ',
'	from dp.pmf_turnos where estado = ''H'' group by to_number(to_char(fecha,''yyyy'')),to_number(to_char(fecha,''mm'')),trim(maquina),turno',
'	),',
'efec as (',
'	select anno,mes,codigomaquina,sum(qtypri) qtypri,0 horas,0 undhorapri from fuente group by anno,mes,codigomaquina,0',
'	union',
'	select anno,mes,codigomaquina,0 qtypri,sum(horas) horas,0 undhorapri from mnfr group by anno,mes,codigomaquina,0',
'	union',
'	select anno,mes,codigomaquina,0 qtypri,0 horas,unidadesminuto*60 undhorapri from vt_finz_costeo',
'	),',
'stdr as (',
'	select 1 criterio,anno,mes,codigodivision,codigomaquina,descripcionmaquina,undmes valorstdr from vt_finz_costeo',
'	union',
'	select 2 criterio,anno,mes,codigodivision,codigomaquina,descripcionmaquina,undmesseg valorstdr from vt_finz_costeo',
'	union',
'	select 3 criterio,anno,mes,codigodivision,codigomaquina,descripcionmaquina,unidadesdesperdicio valorstdr from vt_finz_costeo',
'	union',
'	select 4 criterio,anno,mes,codigodivision,codigomaquina,descripcionmaquina,turnosmes valorstdr from vt_finz_costeo',
'	union',
'	select 5 criterio,anno,mes,codigodivision,codigomaquina,descripcionmaquina,horasmes valorstdr from vt_finz_costeo',
'	union',
'	select 6 criterio,anno,mes,codigodivision,codigomaquina,descripcionmaquina,porcentajeefectividad valorstdr from vt_finz_costeo',
'	),',
'mftr as (',
'	select 1 criterio,anno,mes,codigomaquina,sum(qtypri+qtyseg) valorreal from fuente group by 1,anno,mes,codigomaquina',
'	union',
'	select 2 criterio,anno,mes,codigomaquina,sum(qtyseg) valorreal from fuente group by 2,anno,mes,codigomaquina',
'	union',
'	select 3 criterio,anno,mes,codigomaquina,sum(qtydes) valorreal from fuente group by 3,anno,mes,codigomaquina',
'	union',
'	select 4 criterio,anno,mes,codigomaquina,count(qtypri) valorreal from fuente where trim(codigoturno) is not null group by 4,anno,mes,codigomaquina',
'	union',
'	select 5 criterio,anno,mes,codigomaquina,sum(horas) valorreal from mnfr group by 5,anno,mes,codigomaquina',
'	union',
'	select 6 criterio,anno,mes,codigomaquina,case when sum(undhorapri) = 0 or sum(horas) = 0 then 0 else (sum(qtypri)/sum(horas)/sum(undhorapri))*100 end valorreal from efec group by 6,anno,mes,codigomaquina',
'	)',
'select a.*,to_char(to_date(a.anno||a.mes,''yyyymm''),''yyyy-mm'') periodo,nvl(b.valorreal,0) valorreal from stdr a',
'left join mftr b on a.criterio = b.criterio and a.anno = b.anno and a.mes = b.mes and a.codigomaquina = b.codigomaquina',
'where b.criterio = :p1108_criterio and a.codigodivision = :p1108_division and a.codigomaquina = :p1108_maquina',
'and to_date(a.anno||a.mes,''yyyymm'') between :p1108_fechadesde and :p1108_fechahasta;'))
,p_ajax_items_to_submit=>'P1108_CRITERIO,P1108_FECHADESDE,P1108_FECHAHASTA,P1108_DIVISION,P1108_MAQUINA'
,p_items_value_column_name=>'VALORREAL'
,p_items_label_column_name=>'PERIODO'
,p_color=>'#FF9500'
,p_line_style=>'solid'
,p_line_width=>2
,p_line_type=>'curved'
,p_marker_rendered=>'on'
,p_marker_shape=>'circle'
,p_assigned_to_y2=>'off'
,p_items_label_rendered=>true
,p_items_label_position=>'auto'
,p_items_label_display_as=>'PERCENT'
,p_threshold_display=>'onIndicator'
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(480773131260542807)
,p_chart_id=>wwv_flow_imp.id(480772847308542804)
,p_axis=>'y'
,p_is_rendered=>'on'
,p_title=>'Unidades'
,p_format_scaling=>'auto'
,p_scaling=>'linear'
,p_baseline_scaling=>'min'
,p_position=>'auto'
,p_major_tick_rendered=>'on'
,p_minor_tick_rendered=>'off'
,p_tick_label_rendered=>'on'
,p_zoom_order_seconds=>false
,p_zoom_order_minutes=>false
,p_zoom_order_hours=>false
,p_zoom_order_days=>false
,p_zoom_order_weeks=>false
,p_zoom_order_months=>false
,p_zoom_order_quarters=>false
,p_zoom_order_years=>false
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(480773048968542806)
,p_chart_id=>wwv_flow_imp.id(480772847308542804)
,p_axis=>'x'
,p_is_rendered=>'on'
,p_title=>'Periodo'
,p_format_scaling=>'auto'
,p_scaling=>'linear'
,p_baseline_scaling=>'min'
,p_major_tick_rendered=>'on'
,p_minor_tick_rendered=>'off'
,p_tick_label_rendered=>'on'
,p_tick_label_rotation=>'auto'
,p_tick_label_position=>'outside'
,p_zoom_order_seconds=>false
,p_zoom_order_minutes=>false
,p_zoom_order_hours=>false
,p_zoom_order_days=>false
,p_zoom_order_weeks=>false
,p_zoom_order_months=>false
,p_zoom_order_quarters=>false
,p_zoom_order_years=>false
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(831011558453605804)
,p_plug_name=>unistr('Reporte Est\00E1ndar vs Real')
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(38290610465120145)
,p_plug_display_sequence=>5
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(37761271469106475)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(37860983999106559)
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(831018672693641601)
,p_plug_name=>'Barra de Acciones'
,p_region_template_options=>'#DEFAULT#:t-Form--stretchInputs'
,p_plug_template=>wwv_flow_imp.id(38289497777120142)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'REGION_POSITION_01'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(845282346360669617)
,p_plug_name=>'Filtros'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(38289867500120143)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(480713303099069229)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(831018672693641601)
,p_button_name=>'BUSCAR'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860056812106557)
,p_button_image_alt=>'Buscar'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_icon_css_classes=>'fa-search'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(480717498198089479)
,p_name=>'P1108_FECHADESDE'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(845282346360669617)
,p_item_default=>'trunc(add_months(sysdate,-3),''month'')'
,p_item_default_type=>'EXPRESSION'
,p_item_default_language=>'PLSQL'
,p_prompt=>'Desde'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(480717813385089496)
,p_name=>'P1108_FECHAHASTA'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(845282346360669617)
,p_item_default=>'trunc(sysdate,''month'')'
,p_item_default_type=>'EXPRESSION'
,p_item_default_language=>'PLSQL'
,p_prompt=>'Hasta'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(480721272803116801)
,p_name=>'P1108_DIVISION'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(845282346360669617)
,p_prompt=>unistr('Divisi\00F3n')
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'LOV_UNPADRE'
,p_lov=>'select drdl01,drky from vt_jde_udcjde where DRSY = ''00'' and DRRT = ''50'' and drky is not null order by drdl01'
,p_lov_display_null=>'YES'
,p_lov_null_text=>'Seleccione'
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(480721306555116802)
,p_name=>'P1108_MAQUINA'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(845282346360669617)
,p_prompt=>unistr('M\00E1quina')
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select trim(mcmcu)||'' - ''||trim(mcdc) d, trim(mcmcu) r from f0006@jdedtadl',
'where trim(mcrp50) is not null and (:p1108_division is null or mcrp50 = rpad(:p1108_division,10,'' '')) order by 1'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'Seleccione'
,p_lov_cascade_parent_items=>'P1108_DIVISION'
,p_ajax_optimize_refresh=>'Y'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(480772592870542801)
,p_name=>'P1108_CRITERIO'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(845282346360669617)
,p_prompt=>'Criterio'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'LOV_COSTEO_STDVSREAL'
,p_lov=>'.'||wwv_flow_imp.id(480770113451537162)||'.'
,p_lov_display_null=>'YES'
,p_lov_null_text=>'Seleccione'
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'NONE'
);
wwv_flow_imp.component_end;
end;
/
