prompt --application/pages/page_00160
begin
--   Manifest
--     PAGE: 00160
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>109
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_page.create_page(
 p_id=>160
,p_name=>'Rutas Alternas Envases'
,p_alias=>'RUTAS-ALTERNAS-ENVASES'
,p_step_title=>'Rutas Alternas Envases'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_page_component_map=>'03'
,p_created_on=>wwv_flow_imp.dz('20240528213607Z')
,p_last_updated_on=>wwv_flow_imp.dz('20240621213410Z')
,p_last_updated_by=>'MALBAN'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(194486775909013008)
,p_plug_name=>'Barra de acciones'
,p_region_template_options=>'#DEFAULT#:t-Form--stretchInputs'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(38289497777120142)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(37761271469106475)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(37860983999106559)
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(194486984689013010)
,p_name=>unistr('Rutas Fabricaci\00F3n')
,p_template=>wwv_flow_imp.id(37806762584106520)
,p_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT IRKITA CODIGO,NOMBREPRODUCTO ||'' ''|| CODIGOALTERNO,IRRUNM/100 CARGAFABRIL, IRRUNL/100 MANODEOBRA, IRSETC/10 EQUIPO',
'FROM  vt_jde_rutaslistamateriales,  vt_jde_productos',
'WHERE IRMMCU=''       17016'' AND IRTRT=''M  ''',
'AND IREFFT>=TO_CHAR(SYSDATE,''YYYYDDD'')-1900000',
'AND CODIGOCORTO=IRKIT'))
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(37830327650106535)
,p_query_num_rows=>200
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(194487195316013012)
,p_query_column_id=>1
,p_column_alias=>'CODIGO'
,p_column_display_sequence=>10
,p_column_heading=>unistr('C\00F3digo')
,p_use_as_row_header=>'N'
,p_column_alignment=>'CENTER'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(194487233992013013)
,p_query_column_id=>2
,p_column_alias=>'NOMBREPRODUCTO||''''||CODIGOALTERNO'
,p_column_display_sequence=>20
,p_column_heading=>unistr('Descripci\00F3n')
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(194487367394013014)
,p_query_column_id=>3
,p_column_alias=>'CARGAFABRIL'
,p_column_display_sequence=>30
,p_column_heading=>'Carga Fabril'
,p_use_as_row_header=>'N'
,p_column_alignment=>'RIGHT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(194487473415013015)
,p_query_column_id=>4
,p_column_alias=>'MANODEOBRA'
,p_column_display_sequence=>40
,p_column_heading=>'Mano de Obra'
,p_use_as_row_header=>'N'
,p_column_alignment=>'RIGHT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(194487531703013016)
,p_query_column_id=>5
,p_column_alias=>'EQUIPO'
,p_column_display_sequence=>50
,p_column_heading=>'Equipo'
,p_use_as_row_header=>'N'
,p_column_alignment=>'RIGHT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(205772742612151179)
,p_plug_name=>unistr('Actualizaci\00F3n Rutas Alternas Envases')
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(37817215439106526)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(37761271469106475)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(37860983999106559)
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(194486853982013009)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(194486775909013008)
,p_button_name=>'Actualizar'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860056812106557)
,p_button_image_alt=>'Actualizar'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-file-check'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(194487859919013019)
,p_name=>'Confirmacion'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(194486853982013009)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
,p_updated_on=>wwv_flow_imp.dz('20240621213410Z')
,p_updated_by=>'MALBAN'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(194487950229013020)
,p_event_id=>wwv_flow_imp.id(194487859919013019)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_CONFIRM'
,p_attribute_01=>unistr('Rutas de Fabricaci\00F3n alternas van a ser actualizadas, desea continuar?')
,p_attribute_02=>unistr('Rutas de Fabricaci\00F3n')
,p_attribute_03=>'danger'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(194488167809013022)
,p_event_id=>wwv_flow_imp.id(194487859919013019)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'mostrarBarra();'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(194488022389013021)
,p_event_id=>wwv_flow_imp.id(194487859919013019)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'',
' CURSOR ITEMS IS',
'      SELECT IRKIT CODIGOCORTO,IRKITA PRODUCTO,IRRUNM CARGAFABRIL, IRRUNL MANODEOBRA, IRSETC EQUIPO,IRTIMB BASETIEMPO',
'      FROM vt_jde_rutaslistamateriales',
'      WHERE IRMMCU=''       17016'' AND IRTRT=''M  ''',
'      AND IREFFT>=TO_CHAR(SYSDATE,''YYYYDDD'')-1900000;',
'  ',
'BEGIN',
'',
'-- saco un respaldo de la tabla F3003 antes de actualizar',
'  DELETE FROM F3003MA@JDEDTADL;',
'',
'  INSERT INTO F3003MA@JDEDTADL',
'  SELECT * FROM F3003@JDEDTADL;',
'',
unistr('-- por cada item que se recupera, actualizo las listas alternas con los datos de la lista est\00E1ndar'),
'FOR C1 IN ITEMS LOOP',
'',
'    UPDATE F3003@JDEDTADL SET IRRUNM=C1.CARGAFABRIL, IRRUNL=C1.MANODEOBRA, IRSETC=C1.EQUIPO,IRTIMB=C1.BASETIEMPO',
'    WHERE IRMMCU=''       17016''    ',
'    AND IRKIT = C1.CODIGOCORTO',
'    AND IRTRT<>''M  '' ',
'    AND IREFFT>=TO_CHAR(SYSDATE,''YYYYDDD'')-1900000 ',
'    --and 1066167=IRKIT ',
'    ;',
'',
'END LOOP;',
'',
'END;'))
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20240621213410Z')
,p_updated_by=>'MALBAN'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(194488232578013023)
,p_event_id=>wwv_flow_imp.id(194487859919013019)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'ocultarBarra();'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(194487711428013018)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Actualiza_rutas'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'',
' CURSOR ITEMS IS',
'      SELECT IRKIT CODIGOCORTO,IRKITA PRODUCTO,IRRUNM CARGAFABRIL, IRRUNL MANODEOBRA, IRSETC EQUIPO',
'      FROM vt_jde_rutaslistamateriales',
'      WHERE IRMMCU=''       17016'' AND IRTRT=''M  ''',
'      AND IREFFT>=TO_CHAR(SYSDATE,''YYYYDDD'')-1900000;',
'  ',
'BEGIN',
'',
unistr('-- por cada item que se recupera, actualizo las listas alternas con los datos de la lista est\00E1ndar'),
'FOR C1 IN ITEMS LOOP',
'',
'    UPDATE F3003@JDEDTADL SET IRRUNM=C1.CARGAFABRIL, IRRUNL=C1.MANODEOBRA, IRSETC=C1.EQUIPO',
'    WHERE IRMMCU=''       17016''    ',
'    AND IRKIT = C1.CODIGOCORTO',
'    AND IRTRT<>''M  '' ',
'    AND IREFFT>=TO_CHAR(SYSDATE,''YYYYDDD'')-1900000 and 1125905=IRKIT ;',
'',
'END LOOP;',
'',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>'1=2'
,p_process_when_type=>'EXPRESSION'
,p_process_when2=>'PLSQL'
,p_internal_uid=>194487711428013018
,p_updated_on=>wwv_flow_imp.dz('20240528213816Z')
,p_updated_by=>'MALBAN'
);
wwv_flow_imp.component_end;
end;
/
