prompt --application/pages/page_00112
begin
--   Manifest
--     PAGE: 00112
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>109
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_page.create_page(
 p_id=>112
,p_name=>'Solicitud Desbloqueo de Pagos'
,p_step_title=>'Solicitud Desbloqueo de Pagos'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_page_component_map=>'18'
,p_created_on=>wwv_flow_imp.dz('20240105162612Z')
,p_last_updated_on=>wwv_flow_imp.dz('20240105154014Z')
,p_last_updated_by=>'EMASABANDA'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(980132029801912150)
,p_plug_name=>'Pagos Bloqueados'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(37806762584106520)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select APEX_ITEM.CHECKBOX(1, rid,''class="chkF01"'') seleccion, ',
'rid,',
'trim(NUMEROFACTURA)||LINEA id,',
'COMPANIA, ',
'NUMERODOCUMENTO, ',
'TIPODOCUMENTO, ',
'PROVEEDOR,',
'FECHABLOQUEO,',
'FECHAESTIMADA,',
'NUMEROFACTURA, ',
'LINEA ,',
'TIPOORDENCOMPRA, ',
'FECHAVENCIMIENTOFACTURA,',
'MONTOTOTAL, MONTOPENDIENTE, MONTOBLOQUEO,',
'MOTIVO, ORDENDECOMPRA,',
'trunc(sysdate) - TRUNC(FECHABLOQUEO) DIASBLOQUEO,',
'(select NOMBRE from t_flujo_aprobacion_cab a inner join t_admi_ruta b on a.codruta = b.ID_RUTA',
' where entidad_id=to_char(ID_PROCESO_BLQ) and CODIGOMODULO=''FINZ'' and ENTIDAD_CLASE=''RETENCION_DE_PAGO'' and rownum=1)nombreruta,',
'id_proceso,',
'id_proceso_BLQ',
'from VT_FINZ_RETENCIONPAGOS_REPORTE',
'WHERE ESTADO = ''BLOQUEADO''',
'AND ((FECHAVENCIMIENTOFACTURA BETWEEN :P112_FECHAINICIO AND :P112_FECHAFIN) or (:P112_FECHAINICIO is null and :P112_FECHAFIN is null))',
'AND (trim(NUMEROFACTURA) = :P112_FACTURA or :P112_FACTURA is null)',
'AND (CODIGOPROVEEDOR = :P112_PROVEEDOR or :P112_PROVEEDOR is null) ',
'AND (ORDENDECOMPRA = :P112_NUM_OC or :P112_NUM_OC is null)',
'AND id NOT IN (SELECT ID FROM T_FINZ_RETENCIONPAGOS WHERE ESTADO IN (''EN_PROCESO''))',
''))
,p_plug_source_type=>'NATIVE_IR'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>210
,p_prn_height=>297
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(1014164859535820627)
,p_max_row_count=>'100000'
,p_max_rows_per_page=>'50'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'CVACA'
,p_internal_uid=>1014164859535820627
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(339942811990256301)
,p_db_column_name=>'COMPANIA'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>unistr('Compa\00F1\00EDa')
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(339943278760256303)
,p_db_column_name=>'NUMERODOCUMENTO'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'# Documento'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(339943688326256303)
,p_db_column_name=>'TIPODOCUMENTO'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Tipo Doc'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(339945240612256304)
,p_db_column_name=>'TIPOORDENCOMPRA'
,p_display_order=>80
,p_column_identifier=>'H'
,p_column_label=>'Tipo OC'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(339945664528256304)
,p_db_column_name=>'MONTOTOTAL'
,p_display_order=>100
,p_column_identifier=>'J'
,p_column_label=>'Total'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G990D00'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(339946019768256306)
,p_db_column_name=>'MONTOPENDIENTE'
,p_display_order=>110
,p_column_identifier=>'K'
,p_column_label=>'Pendiente'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G990D00'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(339946421457256306)
,p_db_column_name=>'SELECCION'
,p_display_order=>120
,p_column_identifier=>'L'
,p_column_label=>'_'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(339941649863256300)
,p_db_column_name=>'ID'
,p_display_order=>140
,p_column_identifier=>'N'
,p_column_label=>'Id'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(339864046860312508)
,p_db_column_name=>'PROVEEDOR'
,p_display_order=>150
,p_column_identifier=>'R'
,p_column_label=>'Proveedor'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(339864133699312509)
,p_db_column_name=>'FECHABLOQUEO'
,p_display_order=>160
,p_column_identifier=>'S'
,p_column_label=>'Fechabloqueo'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(339864277410312510)
,p_db_column_name=>'FECHAESTIMADA'
,p_display_order=>170
,p_column_identifier=>'T'
,p_column_label=>'Fechaestimada'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(339864366474312511)
,p_db_column_name=>'NUMEROFACTURA'
,p_display_order=>180
,p_column_identifier=>'U'
,p_column_label=>'Numerofactura'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(339864408588312512)
,p_db_column_name=>'FECHAVENCIMIENTOFACTURA'
,p_display_order=>190
,p_column_identifier=>'V'
,p_column_label=>'Fechavencimientofactura'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(339864580067312513)
,p_db_column_name=>'MONTOBLOQUEO'
,p_display_order=>200
,p_column_identifier=>'W'
,p_column_label=>'Montobloqueo'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G990D00'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(339864629596312514)
,p_db_column_name=>'MOTIVO'
,p_display_order=>210
,p_column_identifier=>'X'
,p_column_label=>'Motivo'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(339864774362312515)
,p_db_column_name=>'ORDENDECOMPRA'
,p_display_order=>220
,p_column_identifier=>'Y'
,p_column_label=>'Ordendecompra'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(103628308645029830)
,p_db_column_name=>'DIASBLOQUEO'
,p_display_order=>240
,p_column_identifier=>'AA'
,p_column_label=>'Diasbloqueo'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(103628434597029831)
,p_db_column_name=>'NOMBRERUTA'
,p_display_order=>250
,p_column_identifier=>'AB'
,p_column_label=>'Ruta de Solicitud de bloqueo'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(103630201200029849)
,p_db_column_name=>'LINEA'
,p_display_order=>260
,p_column_identifier=>'AC'
,p_column_label=>'Linea'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(103630388932029850)
,p_db_column_name=>'ID_PROCESO'
,p_display_order=>270
,p_column_identifier=>'AD'
,p_column_label=>'Id Proceso'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(104697388315256301)
,p_db_column_name=>'ID_PROCESO_BLQ'
,p_display_order=>280
,p_column_identifier=>'AE'
,p_column_label=>'Id Proceso Blq'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(148145607521932343)
,p_db_column_name=>'RID'
,p_display_order=>290
,p_column_identifier=>'AF'
,p_column_label=>'Rid'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'OTHER'
,p_rpt_show_filter_lov=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(1014325660563642716)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'3399472'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_display_rows=>10
,p_report_columns=>'NOMBRERUTA:SELECCION:PROVEEDOR:ORDENDECOMPRA:FECHABLOQUEO:FECHAESTIMADA:NUMEROFACTURA:FECHAVENCIMIENTOFACTURA:MOTIVO:MONTOTOTAL:MONTOPENDIENTE:MONTOBLOQUEO:'
,p_sort_column_1=>'PROVEEDOR'
,p_sort_direction_1=>'ASC'
,p_sort_column_2=>'ID_PROCESO'
,p_sort_direction_2=>'ASC'
,p_sort_column_3=>'0'
,p_sort_direction_3=>'ASC'
,p_sort_column_4=>'0'
,p_sort_direction_4=>'ASC'
,p_sort_column_5=>'0'
,p_sort_direction_5=>'ASC'
,p_sort_column_6=>'0'
,p_sort_direction_6=>'ASC'
,p_break_on=>'NOMBRERUTA:0:0:0:0:0'
,p_break_enabled_on=>'NOMBRERUTA:0:0:0:0:0'
,p_created_on=>wwv_flow_imp.dz('20240105162612Z')
,p_updated_on=>wwv_flow_imp.dz('20240105162612Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1014406581947868932)
,p_plug_name=>'Filtros'
,p_region_template_options=>'#DEFAULT#:is-collapsed:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(37796755046106514)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1014627161537430957)
,p_plug_name=>'Solicitud de Desbloqueo de Pagos'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(95503811913299190)
,p_plug_display_sequence=>30
,p_include_in_reg_disp_sel_yn=>'Y'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ',
' a.ID,a.COMPANIA,a.CODIGOPROVEEDOR,a.ORDENDECOMPRA,a.NUMEROFACTURA,a.FECHASOLICITUD,a.FECHAESTIMADA FECHA_ESTIMADA_DESBLOQUEO,',
'A.FECHADESBLOQUEO,',
'a.SOLICITANTE,a.ESTADO,a.TIPOORDENCOMPRA,',
'A.MOTIVO,',
'a.ID_PROCESO,',
'a.MONTOTOTAL,a.MONTOPENDIENTE,a.MONTOBLOQUEO, a.APROBADOR',
'from t_finz_retencionpagos a ',
'where 1=1 and a.ESTADO = ''INGRESADO''',
'AND a.ID_PROCESO =  :P112_ID_PROCESO ;'))
,p_plug_source_type=>'NATIVE_IG'
,p_ajax_items_to_submit=>'P112_ID_PROCESO'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(340067217099719144)
,p_name=>'APEX$ROW_ACTION'
,p_session_state_data_type=>'VARCHAR2'
,p_item_type=>'NATIVE_ROW_ACTION'
,p_display_sequence=>20
,p_use_as_row_header=>false
,p_enable_hide=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(340067343237719145)
,p_name=>'APEX$ROW_SELECTOR'
,p_session_state_data_type=>'VARCHAR2'
,p_item_type=>'NATIVE_ROW_SELECTOR'
,p_display_sequence=>10
,p_attribute_01=>'Y'
,p_attribute_02=>'Y'
,p_attribute_03=>'N'
,p_use_as_row_header=>false
,p_enable_hide=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(1014627306733430959)
,p_name=>'ID'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'ID'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>true
,p_item_type=>'NATIVE_DISPLAY_ONLY'
,p_heading=>'Id'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>30
,p_value_alignment=>'LEFT'
,p_attribute_02=>'VALUE'
,p_attribute_05=>'PLAIN'
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(1014627446081430960)
,p_name=>'COMPANIA'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'COMPANIA'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>true
,p_item_type=>'NATIVE_DISPLAY_ONLY'
,p_heading=>'Compania'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>40
,p_value_alignment=>'LEFT'
,p_attribute_02=>'VALUE'
,p_attribute_05=>'PLAIN'
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(1014627505088430961)
,p_name=>'CODIGOPROVEEDOR'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'CODIGOPROVEEDOR'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>true
,p_item_type=>'NATIVE_DISPLAY_ONLY'
,p_heading=>'Codigoproveedor'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>50
,p_value_alignment=>'LEFT'
,p_attribute_02=>'VALUE'
,p_attribute_05=>'PLAIN'
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(1014627700431430962)
,p_name=>'ORDENDECOMPRA'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'ORDENDECOMPRA'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>true
,p_item_type=>'NATIVE_DISPLAY_ONLY'
,p_heading=>'# OC'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>60
,p_value_alignment=>'LEFT'
,p_attribute_02=>'VALUE'
,p_attribute_05=>'PLAIN'
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(1014627793194430963)
,p_name=>'NUMEROFACTURA'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'NUMEROFACTURA'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>true
,p_item_type=>'NATIVE_DISPLAY_ONLY'
,p_heading=>'# Factura'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>70
,p_value_alignment=>'LEFT'
,p_attribute_02=>'VALUE'
,p_attribute_05=>'PLAIN'
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(1014627842501430964)
,p_name=>'FECHASOLICITUD'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'FECHASOLICITUD'
,p_data_type=>'DATE'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>true
,p_item_type=>'NATIVE_DISPLAY_ONLY'
,p_heading=>'Fechasolicitud'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>80
,p_value_alignment=>'LEFT'
,p_attribute_02=>'VALUE'
,p_attribute_05=>'PLAIN'
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_date_ranges=>'ALL'
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(1014628023001430966)
,p_name=>'FECHADESBLOQUEO'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'FECHADESBLOQUEO'
,p_data_type=>'DATE'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>true
,p_item_type=>'NATIVE_DISPLAY_ONLY'
,p_heading=>'Fechadesbloqueo'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>90
,p_value_alignment=>'LEFT'
,p_attribute_02=>'VALUE'
,p_attribute_05=>'PLAIN'
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_date_ranges=>'ALL'
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(1014628244601430968)
,p_name=>'APROBADOR'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'APROBADOR'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>true
,p_item_type=>'NATIVE_DISPLAY_ONLY'
,p_heading=>'Aprobador'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>110
,p_value_alignment=>'LEFT'
,p_attribute_02=>'VALUE'
,p_attribute_05=>'PLAIN'
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(1014628383976430969)
,p_name=>'SOLICITANTE'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'SOLICITANTE'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>true
,p_item_type=>'NATIVE_DISPLAY_ONLY'
,p_heading=>'Solicitante'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>120
,p_value_alignment=>'LEFT'
,p_attribute_02=>'VALUE'
,p_attribute_05=>'PLAIN'
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(1014628435477430970)
,p_name=>'ESTADO'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'ESTADO'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>true
,p_item_type=>'NATIVE_DISPLAY_ONLY'
,p_heading=>'Estado'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>130
,p_value_alignment=>'LEFT'
,p_attribute_02=>'VALUE'
,p_attribute_05=>'PLAIN'
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(1014628507371430971)
,p_name=>'TIPOORDENCOMPRA'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'TIPOORDENCOMPRA'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>true
,p_item_type=>'NATIVE_DISPLAY_ONLY'
,p_heading=>'Tipo OC'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>140
,p_value_alignment=>'LEFT'
,p_attribute_02=>'VALUE'
,p_attribute_05=>'PLAIN'
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(1015000091111407822)
,p_name=>'MOTIVO'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'MOTIVO'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXTAREA'
,p_heading=>'Motivo'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>150
,p_value_alignment=>'LEFT'
,p_attribute_01=>'Y'
,p_attribute_02=>'Y'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
,p_is_required=>false
,p_max_length=>2000
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_enable_control_break=>false
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(1015000185428407823)
,p_name=>'ID_PROCESO'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'ID_PROCESO'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>true
,p_item_type=>'NATIVE_DISPLAY_ONLY'
,p_heading=>'Id Proceso'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>160
,p_value_alignment=>'LEFT'
,p_attribute_02=>'VALUE'
,p_attribute_05=>'PLAIN'
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(1015000641685407828)
,p_name=>'MONTOTOTAL'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'MONTOTOTAL'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_DISPLAY_ONLY'
,p_heading=>'$ Total'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>170
,p_value_alignment=>'LEFT'
,p_attribute_02=>'VALUE'
,p_attribute_05=>'PLAIN'
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(1015000769221407829)
,p_name=>'MONTOPENDIENTE'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'MONTOPENDIENTE'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_DISPLAY_ONLY'
,p_heading=>'$ Pendiente'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>180
,p_value_alignment=>'LEFT'
,p_attribute_02=>'VALUE'
,p_attribute_05=>'PLAIN'
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(1015000831011407830)
,p_name=>'MONTOBLOQUEO'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'MONTOBLOQUEO'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_DISPLAY_ONLY'
,p_heading=>'$ Bloqueo'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>190
,p_value_alignment=>'LEFT'
,p_attribute_02=>'VALUE'
,p_attribute_05=>'PLAIN'
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(1015001658943407838)
,p_name=>'FECHA_ESTIMADA_DESBLOQUEO'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'FECHA_ESTIMADA_DESBLOQUEO'
,p_data_type=>'DATE'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_DISPLAY_ONLY'
,p_heading=>'Fecha Estimada Desbloqueo'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>200
,p_value_alignment=>'LEFT'
,p_attribute_02=>'VALUE'
,p_attribute_05=>'PLAIN'
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_date_ranges=>'ALL'
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_interactive_grid(
 p_id=>wwv_flow_imp.id(1014627277064430958)
,p_internal_uid=>1014627277064430958
,p_is_editable=>true
,p_edit_operations=>'u:d'
,p_lost_update_check_type=>'VALUES'
,p_submit_checked_rows=>false
,p_lazy_loading=>false
,p_requires_filter=>false
,p_max_row_count=>100000
,p_show_nulls_as=>'-'
,p_select_first_row=>true
,p_fixed_row_height=>true
,p_pagination_type=>'SCROLL'
,p_show_total_row_count=>true
,p_show_toolbar=>true
,p_toolbar_buttons=>'SEARCH_COLUMN:SEARCH_FIELD:ACTIONS_MENU:SAVE'
,p_enable_save_public_report=>false
,p_enable_subscriptions=>true
,p_enable_flashback=>true
,p_define_chart_view=>true
,p_enable_download=>true
,p_enable_mail_download=>true
,p_fixed_header=>'PAGE'
,p_show_icon_view=>false
,p_show_detail_view=>false
);
wwv_flow_imp_page.create_ig_report(
 p_id=>wwv_flow_imp.id(1015005908662415835)
,p_interactive_grid_id=>wwv_flow_imp.id(1014627277064430958)
,p_static_id=>'186572'
,p_type=>'PRIMARY'
,p_default_view=>'GRID'
,p_show_row_number=>false
,p_settings_area_expanded=>true
);
wwv_flow_imp_page.create_ig_report_view(
 p_id=>wwv_flow_imp.id(1015006096239415836)
,p_report_id=>wwv_flow_imp.id(1015005908662415835)
,p_view_type=>'GRID'
,p_stretch_columns=>false
,p_srv_exclude_null_values=>false
,p_srv_only_display_columns=>true
,p_edit_mode=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(340920762313857943)
,p_view_id=>wwv_flow_imp.id(1015006096239415836)
,p_display_seq=>0
,p_column_id=>wwv_flow_imp.id(340067217099719144)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(1015006585392415841)
,p_view_id=>wwv_flow_imp.id(1015006096239415836)
,p_display_seq=>1
,p_column_id=>wwv_flow_imp.id(1014627306733430959)
,p_is_visible=>false
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(1015007015564415846)
,p_view_id=>wwv_flow_imp.id(1015006096239415836)
,p_display_seq=>2
,p_column_id=>wwv_flow_imp.id(1014627446081430960)
,p_is_visible=>false
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(1015007504661415849)
,p_view_id=>wwv_flow_imp.id(1015006096239415836)
,p_display_seq=>3
,p_column_id=>wwv_flow_imp.id(1014627505088430961)
,p_is_visible=>false
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(1015008038377415852)
,p_view_id=>wwv_flow_imp.id(1015006096239415836)
,p_display_seq=>4
,p_column_id=>wwv_flow_imp.id(1014627700431430962)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(1015008517318415853)
,p_view_id=>wwv_flow_imp.id(1015006096239415836)
,p_display_seq=>6
,p_column_id=>wwv_flow_imp.id(1014627793194430963)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>132
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(1015009041376415856)
,p_view_id=>wwv_flow_imp.id(1015006096239415836)
,p_display_seq=>7
,p_column_id=>wwv_flow_imp.id(1014627842501430964)
,p_is_visible=>false
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(1015009911071415863)
,p_view_id=>wwv_flow_imp.id(1015006096239415836)
,p_display_seq=>8
,p_column_id=>wwv_flow_imp.id(1014628023001430966)
,p_is_visible=>false
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(1015010930939415869)
,p_view_id=>wwv_flow_imp.id(1015006096239415836)
,p_display_seq=>10
,p_column_id=>wwv_flow_imp.id(1014628244601430968)
,p_is_visible=>false
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(1015011454967415872)
,p_view_id=>wwv_flow_imp.id(1015006096239415836)
,p_display_seq=>11
,p_column_id=>wwv_flow_imp.id(1014628383976430969)
,p_is_visible=>false
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(1015011932708415875)
,p_view_id=>wwv_flow_imp.id(1015006096239415836)
,p_display_seq=>12
,p_column_id=>wwv_flow_imp.id(1014628435477430970)
,p_is_visible=>false
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(1015012451438415878)
,p_view_id=>wwv_flow_imp.id(1015006096239415836)
,p_display_seq=>5
,p_column_id=>wwv_flow_imp.id(1014628507371430971)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>86
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(1015012928283415881)
,p_view_id=>wwv_flow_imp.id(1015006096239415836)
,p_display_seq=>18
,p_column_id=>wwv_flow_imp.id(1015000091111407822)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>253
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(1015013448775415885)
,p_view_id=>wwv_flow_imp.id(1015006096239415836)
,p_display_seq=>13
,p_column_id=>wwv_flow_imp.id(1015000185428407823)
,p_is_visible=>false
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(1015017379418467224)
,p_view_id=>wwv_flow_imp.id(1015006096239415836)
,p_display_seq=>14
,p_column_id=>wwv_flow_imp.id(1015000641685407828)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(1015017872557467227)
,p_view_id=>wwv_flow_imp.id(1015006096239415836)
,p_display_seq=>15
,p_column_id=>wwv_flow_imp.id(1015000769221407829)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(1015018355694467228)
,p_view_id=>wwv_flow_imp.id(1015006096239415836)
,p_display_seq=>16
,p_column_id=>wwv_flow_imp.id(1015000831011407830)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(1015026168159046167)
,p_view_id=>wwv_flow_imp.id(1015006096239415836)
,p_display_seq=>17
,p_column_id=>wwv_flow_imp.id(1015001658943407838)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>117
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1052292232833686490)
,p_plug_name=>'Ingreso de Solicitud Desbloqueo de Pagos &P112_ID_PROCESO.'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(38290610465120145)
,p_plug_display_sequence=>20
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(37761271469106475)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(37860983999106559)
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1939266298692615973)
,p_plug_name=>'Barra de acciones'
,p_region_template_options=>'#DEFAULT#:t-Form--stretchInputs'
,p_plug_template=>wwv_flow_imp.id(38289497777120142)
,p_plug_display_sequence=>40
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'REGION_POSITION_01'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(339940532561256290)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(1939266298692615973)
,p_button_name=>'BUSCAR'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860056812106557)
,p_button_image_alt=>'Buscar'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-search'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(339939728119256289)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(1939266298692615973)
,p_button_name=>'AGREGAR'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860056812106557)
,p_button_image_alt=>'Agregar'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-plus'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(339940199357256289)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(1939266298692615973)
,p_button_name=>'ENVIAR_APROBAR'
,p_button_action=>'REDIRECT_APP'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860056812106557)
,p_button_image_alt=>'Enviar Aprobar'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=100:101:&SESSION.::&DEBUG.:RP:G_MODULO,G_OBJETO,G_OBJETO_ID,G_USUARIO,G_TIPO1,G_PAGINA:&APP_MODULO.,RETENCION_DE_PAGO,&P112_ID_PROCESO.,&APP_USER.,&P112_AUX_TIPO_OC.,FINZP0116'
,p_button_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select DISTINCT 1 FROM T_FINZ_RETENCIONPAGOS',
'WHERE 1=1 AND ESTADO = ''INGRESADO'' and ID_PROCESO = :P112_ID_PROCESO and motivo IS not NULL;'))
,p_button_condition_type=>'EXISTS'
,p_icon_css_classes=>'fa-check-circle-o'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(340512447450360767)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(1939266298692615973)
,p_button_name=>'Regresar'
,p_button_static_id=>'btnRegresar'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860056812106557)
,p_button_image_alt=>'Regresar'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'LEFT'
,p_button_redirect_url=>'f?p=&APP_ID.:100:&SESSION.::&DEBUG.:RP::'
,p_icon_css_classes=>'fa-arrow-left'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(340063685281719108)
,p_branch_name=>'A mesa de trabajo'
,p_branch_action=>'f?p=&APP_ID.:100:&SESSION.::&DEBUG.:RP::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_imp.id(339940199357256289)
,p_branch_sequence=>10
,p_branch_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_branch_condition=>'P112_ENVIO_EXITO'
,p_branch_condition_text=>'1'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(339958319056256332)
,p_name=>'P112_AUX'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(1014406581947868932)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(339958715520256332)
,p_name=>'P112_ID_PROCESO'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(1014406581947868932)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(339959150574256332)
,p_name=>'P112_SELECCION'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(1014406581947868932)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(339959517478256334)
,p_name=>'P112_VALIDA1'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(1014406581947868932)
,p_use_cache_before_default=>'NO'
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(339959937245256334)
,p_name=>'P112_PROVEEDOR'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(1014406581947868932)
,p_prompt=>'Proveedor'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'LOV_MAESTRO_PROVEEDORES'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select DESCRIPCION as d,',
'       CODIGOPROVEEDOR as r',
'  from VT_JDE_MAESTROPROVEEDOR',
' order by 1'))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_grid_column=>1
,p_grid_label_column_span=>1
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(339960351183256334)
,p_name=>'P112_FACTURA'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(1014406581947868932)
,p_prompt=>'Factura'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_grid_column=>1
,p_grid_label_column_span=>1
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(339960753509256335)
,p_name=>'P112_NUM_OC'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(1014406581947868932)
,p_prompt=>'# Orden Compra'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_grid_column=>1
,p_grid_label_column_span=>1
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(339961156833256335)
,p_name=>'P112_FECHAINICIO'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(1014406581947868932)
,p_prompt=>'Fecha Inicio'
,p_format_mask=>'DD/MM/YYYY'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>23
,p_grid_column=>1
,p_grid_label_column_span=>1
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(339961598739256335)
,p_name=>'P112_FECHAFIN'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_imp.id(1014406581947868932)
,p_prompt=>'Fecha Fin'
,p_format_mask=>'DD/MM/YYYY'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>23
,p_begin_on_new_line=>'N'
,p_grid_column=>5
,p_grid_label_column_span=>1
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(339961915216256335)
,p_name=>'P112_AREA_SOLICITANTE'
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_imp.id(1014406581947868932)
,p_source=>'SELECT DEPARTAMENTO FROM VT_CORP_USUARIO WHERE NOMBREUSUARIO = :APP_USER;'
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(339962305489256337)
,p_name=>'P112_ENVIO_EXITO'
,p_item_sequence=>120
,p_item_plug_id=>wwv_flow_imp.id(1014406581947868932)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(339962725391256337)
,p_name=>'P112_TERMINA_FLUJO'
,p_item_sequence=>130
,p_item_plug_id=>wwv_flow_imp.id(1014406581947868932)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(340502270691278032)
,p_name=>'P112_AUX_TIPO_OC'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(1014406581947868932)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(339963501994256339)
,p_computation_sequence=>10
,p_computation_item=>'P112_AUX'
,p_computation_point=>'BEFORE_BOX_BODY'
,p_computation_type=>'QUERY'
,p_computation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT PK_COMMONS.F_SECUENCIA(''T_FINZ_RETENCIONPAGOS'') ',
'FROM DUAL;'))
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(339963907595256340)
,p_computation_sequence=>20
,p_computation_item=>'P112_ID_PROCESO'
,p_computation_point=>'BEFORE_BOX_BODY'
,p_computation_type=>'ITEM_VALUE'
,p_computation=>'P112_AUX'
,p_compute_when=>'P112_ID_PROCESO'
,p_compute_when_type=>'ITEM_IS_NULL'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(339965654678256342)
,p_name=>'Seleccionados'
,p_event_sequence=>10
,p_triggering_element_type=>'JQUERY_SELECTOR'
,p_triggering_element=>'.chkF01'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(339966126868256342)
,p_event_id=>wwv_flow_imp.id(339965654678256342)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P112_SELECCION'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'var lineas =""; ',
'document.querySelectorAll(''.chkF01'').forEach(function(seleccion) {',
'    if(seleccion.checked){',
'        var linea = seleccion.value',
'        if(lineas==""){',
'            lineas = linea;',
'        }else{',
'            ',
'            lineas = lineas+'',''+linea;',
'        }      ',
'    }else{',
'        ',
'    }',
'    ',
'});',
'',
'apex.item("P112_SELECCION").setValue(lineas);',
''))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(339966538635256342)
,p_name=>'Buscar'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(339940532561256290)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(339967030824256343)
,p_event_id=>wwv_flow_imp.id(339966538635256342)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_02=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(339967452643256343)
,p_name=>unistr('A\00F1adir Seleccionados')
,p_event_sequence=>50
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(339939728119256289)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(339968409699256343)
,p_event_id=>wwv_flow_imp.id(339967452643256343)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE v_Id_proceso varchar2(10):=null;',
'        v_ruta  varchar2(20):=null;   ',
'begin',
'    ',
'    IF :P112_ID_PROCESO IS NULL THEN',
'        SELECT :P112_AUX INTO :P112_ID_PROCESO FROM DUAL;',
'    END IF;',
'    DELETE T_FINZ_RETENCIONPAGOS  WHERE ID_PROCESO != :P112_ID_PROCESO and SOLICITANTE = :APP_USER AND ESTADO = ''INGRESADO'' AND fechadesbloqueo is null;',
'    COMMIT;  ',
'    DBMS_OUTPUT.PUT_LINE(''1.- :P112_ID_PROCESO:''||:P112_ID_PROCESO);',
'    FOR Facturas in (',
'  ',
'   WITH DTAFAC AS  (',
'                        SELECT ',
'                            regexp_substr(:P112_SELECCION,''[^,]+'', 1, level)  P112_SELECCION ',
'                        FROM DUAL connect by regexp_substr(:P112_SELECCION, ''[^,]+'', 1, level) is not null ',
'                    ),',
'    DTARETPAG AS    (',
'                        SELECT ',
'                           RID, trim(NUMEROFACTURA)||LINEA referencia, COMPANIA, NUMERODOCUMENTO, TIPODOCUMENTO, PROVEEDOR, FECHABLOQUEO, FECHAESTIMADA, NUMEROFACTURA, TIPOORDENCOMPRA, FECHAVENCIMIENTOFACTURA,',
'                            MONTOTOTAL, MONTOPENDIENTE, MONTOBLOQUEO, MOTIVO, ORDENDECOMPRA, LINEA, CODIGOPROVEEDOR, ID_PROCESO, id_proceso_blq',
'                        from VT_FINZ_RETENCIONPAGOS_REPORTE',
'                        WHERE ESTADO = ''BLOQUEADO''',
'                        AND ID NOT IN (SELECT ID FROM T_FINZ_RETENCIONPAGOS WHERE ESTADO IN (''EN_PROCESO'',''INGRESADO''))',
'                        AND RID IN (SELECT P112_SELECCION FROM DTAFAC)',
'                    )',
'        SELECT * FROM DTARETPAG',
'        ',
') loop',
'    DBMS_OUTPUT.PUT_LINE('':P112_ID_PROCESO:''||:P112_ID_PROCESO);',
'    INSERT INTO T_FINZ_RETENCIONPAGOS (referencia, COMPANIA,CODIGOPROVEEDOR,ORDENDECOMPRA,NUMEROFACTURA,FECHASOLICITUD,FECHAESTIMADA,FECHADESBLOQUEO,APROBADOR,SOLICITANTE,ESTADO,',
'                                       TIPOORDENCOMPRA, ',
'                                       ID_PROCESO, MONTOTOTAL,MONTOPENDIENTE, MONTOBLOQUEO, LINEA, NUMERODOCUMENTOJDE, TIPODOCUMENTOJDE,id_proceso_blq,MOTIVO)',
'    values (',
'        Facturas.REFERENCIA,',
'        Facturas.COMPANIA,',
'        Facturas.CODIGOPROVEEDOR,',
'        Facturas.ORDENDECOMPRA,',
'        Facturas.NUMEROFACTURA,',
'        TO_DATE(SYSDATE, ''dd/mm/yyyy''),',
'        Facturas.FECHAESTIMADA,',
'        TO_DATE(SYSDATE, ''dd/mm/yyyy''),',
'        0,',
'        :APP_USER,',
'        ''INGRESADO'',',
'        Facturas.TIPOORDENCOMPRA,',
'        :P112_ID_PROCESO,',
'        Facturas.MONTOTOTAL,',
'        Facturas.MONTOPENDIENTE,',
'        Facturas.MONTOBLOQUEO,',
'        Facturas.LINEA,',
'        Facturas.NUMERODOCUMENTO,',
'        Facturas.TIPODOCUMENTO,',
'        Facturas.ID_PROCESO_BLQ,',
'        Facturas.MOTIVO);',
'        if (trim(v_Id_proceso) is null) then',
'            v_Id_proceso:=Facturas.ID_PROCESO_BLQ;',
'            DBMS_OUTPUT.PUT_LINE(''v_Id_proceso:''||v_Id_proceso);',
'        end if;',
'        update T_FINZ_RETENCIONPAGOS',
'        set estado = ''INGRESO_DESBLOQUE''',
'        where id_proceso=Facturas.ID_PROCESO_BLQ and trim(REFERENCIA)= trim(Facturas.referencia);',
'end LOOP;',
'    if (trim(v_Id_proceso) is not null) then',
'        select TIPO1 into v_ruta from t_flujo_aprobacion_cab a inner join t_admi_ruta b on a.codruta = b.ID_RUTA',
'        where entidad_id=v_Id_proceso and CODIGOMODULO=''FINZ'' and ENTIDAD_CLASE=''RETENCION_DE_PAGO'' and rownum=1;',
'        DBMS_OUTPUT.PUT_LINE(''v_ruta:''||v_ruta);',
'        :P112_AUX_TIPO_OC :=v_ruta;',
'    end if;',
'COMMIT;',
'EXCEPTION WHEN OTHERS THEN ',
'     DBMS_OUTPUT.PUT_LINE(''ERROR ''||'' SQLCODE: ''||SQLCODE||'' SQLERRM: ''||SQLERRM||'' TRACE: ''||DBMS_UTILITY.format_error_backtrace);',
'ROLLBACK;',
'END;',
''))
,p_attribute_02=>'P112_SELECCION,P112_ID_PROCESO'
,p_attribute_03=>'P112_AUX,P112_AUX_TIPO_OC'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(339967943360256343)
,p_event_id=>wwv_flow_imp.id(339967452643256343)
,p_event_result=>'TRUE'
,p_action_sequence=>50
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_02=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(340066931686719141)
,p_event_id=>wwv_flow_imp.id(339967452643256343)
,p_event_result=>'TRUE'
,p_action_sequence=>60
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(339940199357256289)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(339964200465256340)
,p_name=>unistr('Cierre di\00E1logo: env\00EDo flujo')
,p_event_sequence=>60
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(339940199357256289)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(339964788282256340)
,p_event_id=>wwv_flow_imp.id(339964200465256340)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'var trama = JSON.parse(this.data.G_RESULTADO);',
'var isTerminoFlujo= trama.resultado.terminoFlujo;',
'apex.item( "P112_TERMINA_FLUJO" ).setValue(0);',
'apex.item( "P112_ENVIO_EXITO" ).setValue(0);',
'',
'if(this.data.G_EXITO==''true''){',
'     mensaje(''exito'', this.data.G_MENSAJE);',
'     apex.item( "P112_ENVIO_EXITO" ).setValue(1);',
'    if(isTerminoFlujo){',
'        apex.item( "P112_TERMINA_FLUJO" ).setValue(1);',
'    }',
'}',
'else{ ',
'     mensaje(''error'', this.data.G_MENSAJE);',
'}',
''))
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(339971204166256346)
,p_event_id=>wwv_flow_imp.id(339964200465256340)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'v_valida number;',
'begin',
'',
'if :P112_TERMINA_FLUJO = 1 THEN',
'    UPDATE T_FINZ_RETENCIONPAGOS',
'    SET ESTADO = ''DESBLOQUEADO'', APROBADOR = :APP_USER',
'    WHERE ID_PROCESO = :P112_ID_PROCESO;',
'    begin',
'        SELECT id_proceso_BLQ INTO v_valida FROM T_FINZ_RETENCIONPAGOS',
'        WHERE id_proceso>=:P112_ID_PROCESO AND ROWNUM=1;',
'',
'        UPDATE T_FINZ_RETENCIONPAGOS',
'        SET ESTADO = ''DESBLOQUEADO_FINAL''',
'        WHERE ID_PROCESO = v_valida AND ',
'        rid in (SELECT ',
'                            regexp_substr(:P112_SELECCION,''[^,]+'', 1, level)  P112_SELECCION ',
'                        FROM DUAL connect by regexp_substr(:P112_SELECCION, ''[^,]+'', 1, level) is not null )',
'        ;',
'        SELECT PK_COMMONS.F_SECUENCIA(''T_FINZ_RETENCIONPAGOS'') into :P112_ID_PROCESO FROM DUAL ;',
'    END;',
'    ',
'    COMMIT;',
'    PK_FINZ_RETENCIONPAGOS.SP_PROCESA_DESBLOQUEO_APROBADO(:P112_ID_PROCESO);',
'    PK_FINZ_RETENCIONPAGOS.SP_NOTIF_DESBLOQUEO_APROBADO(:P112_ID_PROCESO);',
'ELSE',
'    UPDATE T_FINZ_RETENCIONPAGOS',
'    SET ESTADO = ''EN_PROCESO'', APROBADOR = :APP_USER',
'    WHERE ID_PROCESO = :P112_ID_PROCESO;',
'    COMMIT;',
'    ',
'    begin',
'        SELECT id_proceso_BLQ INTO v_valida FROM T_FINZ_RETENCIONPAGOS',
'        WHERE id_proceso=:P112_ID_PROCESO AND ROWNUM=1;',
'',
'        UPDATE T_FINZ_RETENCIONPAGOS',
'        SET ESTADO = ''EN_PROCESO_DESBLOQUE''',
'        WHERE ID_PROCESO = v_valida',
'        AND ESTADO=''INGRESO_DESBLOQUE'';',
'    END;',
'',
'    delete T_FINZ_RETENCIONPAGOS where ESTADO = ''INGRESADO'' and SOLICITANTE = :APP_USER;',
'',
'    SELECT PK_COMMONS.F_SECUENCIA(''T_FINZ_RETENCIONPAGOS'') into :P112_AUX FROM DUAL ;',
'',
'    SELECT :P112_AUX  into :P112_ID_PROCESO FROM DUAL ;',
'END IF;',
'commit;',
'end;'))
,p_attribute_02=>'P112_ID_PROCESO,P112_TERMINA_FLUJO'
,p_attribute_03=>'P112_AUX,P112_ID_PROCESO'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(340066028766719132)
,p_event_id=>wwv_flow_imp.id(339964200465256340)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(339940199357256289)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(340066105543719133)
,p_event_id=>wwv_flow_imp.id(339964200465256340)
,p_event_result=>'TRUE'
,p_action_sequence=>50
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(1939266298692615973)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(339965239979256342)
,p_event_id=>wwv_flow_imp.id(339964200465256340)
,p_event_result=>'TRUE'
,p_action_sequence=>60
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_CLEAR'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(1014627161537430957)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(340066251259719134)
,p_event_id=>wwv_flow_imp.id(339964200465256340)
,p_event_result=>'TRUE'
,p_action_sequence=>70
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>' $(''#btnRegresar'').trigger("click");'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(339867114454312539)
,p_name=>unistr('Cierre di\00E1logo: envio flujo - termina flujo')
,p_event_sequence=>110
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(1939266298692615973)
,p_condition_element=>'P112_TERMINA_FLUJO'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'100'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
,p_display_when_type=>'NEVER'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(339867458401312542)
,p_event_id=>wwv_flow_imp.id(339867114454312539)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'v_valida number;',
'begin',
'',
'UPDATE T_FINZ_RETENCIONPAGOS',
'SET ESTADO = ''DESBLOQUEADO'', APROBADOR = :APP_USER',
'WHERE ID_PROCESO = :P112_DOCUMENTO;',
'',
'commit;',
'PK_FINZ_RETENCIONPAGOS.SP_PROCESA_DESBLOQUEO_APROBADO(:P112_DOCUMENTO);',
'',
'PK_FINZ_RETENCIONPAGOS.SP_NOTIF_DESBLOQUEO_APROBADO(:P112_DOCUMENTO);',
'',
'delete T_FINZ_RETENCIONPAGOS where ESTADO = ''INGRESADO'' and SOLICITANTE = :APP_USER;',
'',
'SELECT PK_COMMONS.F_SECUENCIA(''T_FINZ_RETENCIONPAGOS'') into :P112_AUX FROM DUAL ;',
'SELECT PK_COMMONS.F_SECUENCIA(''T_FINZ_RETENCIONPAGOS'') into :P112_ID_PROCESO FROM DUAL ;',
'',
'commit;',
'end;'))
,p_attribute_02=>'P112_ID_PROCESO'
,p_attribute_03=>'P112_AUX,P112_ID_PROCESO'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(340066482432719136)
,p_event_id=>wwv_flow_imp.id(339867114454312539)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P112_ID_PROCESO'
,p_attribute_01=>'SQL_STATEMENT'
,p_attribute_03=>'SELECT PK_COMMONS.F_SECUENCIA(''T_FINZ_RETENCIONPAGOS'') FROM DUAL ;'
,p_attribute_08=>'Y'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(340066524441719137)
,p_event_id=>wwv_flow_imp.id(339867114454312539)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_CLEAR'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(1014627161537430957)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(340066634291719138)
,p_event_id=>wwv_flow_imp.id(339867114454312539)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(339940199357256289)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(340066728552719139)
,p_event_id=>wwv_flow_imp.id(339867114454312539)
,p_event_result=>'TRUE'
,p_action_sequence=>50
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(1939266298692615973)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(340066836963719140)
,p_event_id=>wwv_flow_imp.id(339867114454312539)
,p_event_result=>'TRUE'
,p_action_sequence=>60
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>' $(''#btnRegresar'').trigger("click");'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(104697494108256302)
,p_name=>'Save_Activa Flujo Boton'
,p_event_sequence=>120
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(1014627161537430957)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'NATIVE_IG|REGION TYPE|interactivegridsave'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(104697572601256303)
,p_event_id=>wwv_flow_imp.id(104697494108256302)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_02=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(104697615270256304)
,p_name=>'New'
,p_event_sequence=>130
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(1014627161537430957)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'NATIVE_IG|REGION TYPE|interactivegridsave'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(104697768987256305)
,p_event_id=>wwv_flow_imp.id(104697615270256304)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_FOCUS'
,p_affected_elements_type=>'COLUMN'
,p_affected_elements=>'MOTIVO'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(340067491046719146)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_region_id=>wwv_flow_imp.id(1014627161537430957)
,p_process_type=>'NATIVE_IG_DML'
,p_process_name=>'Solicitud de Desbloqueo de Pagos - Save Interactive Grid Data'
,p_attribute_01=>'REGION_SOURCE'
,p_attribute_05=>'Y'
,p_attribute_06=>'Y'
,p_attribute_08=>'Y'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>340067491046719146
);
wwv_flow_imp.component_end;
end;
/
