prompt --application/pages/page_01005
begin
--   Manifest
--     PAGE: 01005
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>109
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_page.create_page(
 p_id=>1005
,p_name=>'Conteo Activo Fijo'
,p_alias=>'CONTEO-ACTIVO-FIJO'
,p_step_title=>'Conteo Activo Fijo'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_page_component_map=>'03'
,p_created_on=>wwv_flow_imp.dz('20231211194042Z')
,p_last_updated_on=>wwv_flow_imp.dz('20260408202516Z')
,p_created_by=>'MALBAN'
,p_last_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(167003165208029142)
,p_name=>'Conteo'
,p_template=>wwv_flow_imp.id(38289867500120143)
,p_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select NVL(TIPO,''NO ACTIVO FIJO'') TIPO, CATEGORIA, SUBCATEGORIA,CODIGO_TIPO, CODIGO_CATEGORIA, CODIGO_SUBCATEGORIA,count(*), ',
'( select count(*)',
'  FROM  data.t_finz_activosfijos_old Y',
'  where TRIM(Y.CODIGO_TIPO)=TRIM(X.CODIGO_TIPO) AND TRIM(Y.CODIGO_CATEGORIA)=TRIM(X.CODIGO_CATEGORIA) ',
'  AND TRIM(Y.CODIGO_SUBCATEGORIA)=TRIM(X.CODIGO_SUBCATEGORIA)',
'  GROUP BY Y.CODIGO_TIPO, Y.CODIGO_CATEGORIA, Y.CODIGO_SUBCATEGORIA) CONTEO',
'from t_finz_base2023actfijos X',
'group by TIPO, CATEGORIA, SUBCATEGORIA,CODIGO_TIPO, CODIGO_CATEGORIA, CODIGO_SUBCATEGORIA',
'order by 4',
';'))
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(37830327650106535)
,p_query_num_rows=>500
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
,p_created_on=>wwv_flow_imp.dz('20231211194436Z')
,p_updated_on=>wwv_flow_imp.dz('20260408202516Z')
,p_created_by=>'MALBAN'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(167003289360029143)
,p_query_column_id=>1
,p_column_alias=>'TIPO'
,p_column_display_sequence=>10
,p_column_heading=>'Tipo'
,p_use_as_row_header=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20231211194436Z')
,p_updated_by=>'MALBAN'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(167003357472029144)
,p_query_column_id=>2
,p_column_alias=>'CATEGORIA'
,p_column_display_sequence=>20
,p_column_heading=>'Categoria'
,p_use_as_row_header=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20231211194436Z')
,p_updated_by=>'MALBAN'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(167003425668029145)
,p_query_column_id=>3
,p_column_alias=>'SUBCATEGORIA'
,p_column_display_sequence=>30
,p_column_heading=>'Subcategoria'
,p_use_as_row_header=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20231211194436Z')
,p_updated_by=>'MALBAN'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(167003695438029147)
,p_query_column_id=>4
,p_column_alias=>'CODIGO_TIPO'
,p_column_display_sequence=>50
,p_hidden_column=>'Y'
,p_derived_column=>'N'
,p_updated_on=>wwv_flow_imp.dz('20231211202346Z')
,p_updated_by=>'MALBAN'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(167003738881029148)
,p_query_column_id=>5
,p_column_alias=>'CODIGO_CATEGORIA'
,p_column_display_sequence=>60
,p_hidden_column=>'Y'
,p_derived_column=>'N'
,p_updated_on=>wwv_flow_imp.dz('20231211202346Z')
,p_updated_by=>'MALBAN'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(167003884125029149)
,p_query_column_id=>6
,p_column_alias=>'CODIGO_SUBCATEGORIA'
,p_column_display_sequence=>70
,p_hidden_column=>'Y'
,p_derived_column=>'N'
,p_updated_on=>wwv_flow_imp.dz('20231211202346Z')
,p_updated_by=>'MALBAN'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(167003525511029146)
,p_query_column_id=>7
,p_column_alias=>'COUNT(*)'
,p_column_display_sequence=>40
,p_column_heading=>'Cantidad'
,p_use_as_row_header=>'N'
,p_column_alignment=>'RIGHT'
,p_sum_column=>'Y'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20231211210334Z')
,p_updated_by=>'MALBAN'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(167003970298029150)
,p_query_column_id=>8
,p_column_alias=>'CONTEO'
,p_column_display_sequence=>80
,p_column_heading=>'Conteo'
,p_use_as_row_header=>'N'
,p_column_alignment=>'RIGHT'
,p_sum_column=>'Y'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20231211210334Z')
,p_updated_by=>'MALBAN'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(169269251959318674)
,p_plug_name=>unistr('Conteo Activo F\00EDsico')
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(37817215439106526)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_location=>null
,p_menu_id=>wwv_flow_imp.id(37761271469106475)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(37860983999106559)
,p_created_on=>wwv_flow_imp.dz('20231211194042Z')
,p_updated_on=>wwv_flow_imp.dz('20231211194436Z')
,p_created_by=>'MALBAN'
,p_updated_by=>'MALBAN'
);
wwv_flow_imp.component_end;
end;
/
