prompt --application/pages/page_00107
begin
--   Manifest
--     PAGE: 00107
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>109
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_page.create_page(
 p_id=>107
,p_name=>'Ajustes de Liquidaciones'
,p_step_title=>'Ajustes de Liquidaciones'
,p_autocomplete_on_off=>'OFF'
,p_javascript_code_onload=>wwv_flow_string.join(wwv_flow_t_varchar2(
'$(''.apex-rds'').data(''onRegionChange'', function(mode, activeTab) {',
'    apex.item( "P107_TIPO" ).setValue(activeTab.href);',
'});',
'$(secItems).hide();',
'$(".t-Button.t-Button--icon.t-Button--header.t-Button--headerTree.is-active").click();'))
,p_page_template_options=>'#DEFAULT#'
,p_page_component_map=>'18'
,p_created_on=>wwv_flow_imp.dz('20230705164634Z')
,p_last_updated_on=>wwv_flow_imp.dz('20260313170847Z')
,p_last_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(87313050236148690)
,p_plug_name=>unistr('Barra de Acci\00F3n')
,p_region_template_options=>'#DEFAULT#:t-Form--stretchInputs'
,p_plug_template=>wwv_flow_imp.id(38289497777120142)
,p_plug_display_sequence=>20
,p_plug_display_point=>'REGION_POSITION_01'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(87313169172148691)
,p_plug_name=>'Filtros'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(38289867500120143)
,p_plug_display_sequence=>10
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(109201059134542347)
,p_plug_name=>'Items'
,p_region_name=>'secItems'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(38289867500120143)
,p_plug_display_sequence=>30
,p_include_in_reg_disp_sel_yn=>'Y'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(161530776077168645)
,p_plug_name=>'OrdenesCompra'
,p_region_name=>'tbLiquidacionOrden'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(38289867500120143)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ORIGEN',
'	, to_char(NUMERO) NUMERO',
'	, TIPO',
'	, NUMERO||''-''||TIPO NUMERO_TIPO',
'	, UNIDADNEGOCIO',
'	, SOLICITANTE',
'	, ABAT1',
'	, PROVEEDOR',
'	, COMPRADOR',
'	, VALOR',
'	, FECHAORDEN',
'	, FECHAENTREGA',
'	, COMPANIA',
'	, DESCRIPCION',
'	, SELECCION',
'	, GLIQ',
'	, RIMPE',
'FROM VT_FINZ_GLIQ_ORDENESCOMPRA_EXT',
'WHERE 1 = 1',
'	AND compania = :G_COMPANIA',
'	AND  FECHAORDEN between to_date(:P107_FECHA_INICIO) and to_date(:P107_FECHA_FIN)',
'	and ABAT1 = NVL(:P107_TIPO_PROVEEDOR,ABAT1)',
'	and :P107_BANDERA = 1'))
,p_plug_source_type=>'NATIVE_IR'
,p_ajax_items_to_submit=>'P107_FECHA_INICIO,P107_FECHA_FIN'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>210
,p_prn_height=>297
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_updated_on=>wwv_flow_imp.dz('20251126221306Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(161530929138168647)
,p_max_row_count=>'1000000'
,p_allow_save_rpt_public=>'Y'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'TOP_AND_BOTTOM_RIGHT'
,p_show_finder_drop_down=>'N'
,p_report_list_mode=>'NONE'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_rows_per_page=>'N'
,p_show_control_break=>'N'
,p_show_highlight=>'N'
,p_show_computation=>'N'
,p_show_chart=>'N'
,p_show_group_by=>'N'
,p_show_pivot=>'N'
,p_show_flashback=>'N'
,p_show_help=>'N'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'EMASABANDA'
,p_internal_uid=>161530929138168647
,p_updated_on=>wwv_flow_imp.dz('20251126221306Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(81541455888088506)
,p_db_column_name=>'SELECCION'
,p_display_order=>10
,p_column_identifier=>'T'
,p_column_label=>'-'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(82558503647515540)
,p_db_column_name=>'GLIQ'
,p_display_order=>20
,p_column_identifier=>'BP'
,p_column_label=>'-'
,p_column_link=>'f?p=&APP_ID.:120:&SESSION.::&DEBUG.:RP,107,120:P120_NUMERO_ORDEN_COMPRA,P120_TIPO_ORDEN_COMPRA:#NUMERO#,#TIPO#'
,p_column_linktext=>'#GLIQ#'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
,p_updated_on=>wwv_flow_imp.dz('20230711212836Z')
,p_updated_by=>'EMASABANDA'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(82556901192515524)
,p_db_column_name=>'TIPO'
,p_display_order=>40
,p_column_identifier=>'BB'
,p_column_label=>'Tipo'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(82557102598515526)
,p_db_column_name=>'UNIDADNEGOCIO'
,p_display_order=>50
,p_column_identifier=>'BD'
,p_column_label=>'UN'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(82557025792515525)
,p_db_column_name=>'SOLICITANTE'
,p_display_order=>60
,p_column_identifier=>'BC'
,p_column_label=>'Solicitante'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(82557477512515529)
,p_db_column_name=>'COMPRADOR'
,p_display_order=>70
,p_column_identifier=>'BG'
,p_column_label=>'Comprador'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(82557260564515527)
,p_db_column_name=>'PROVEEDOR'
,p_display_order=>80
,p_column_identifier=>'BE'
,p_column_label=>'Proveedor'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(82557600304515531)
,p_db_column_name=>'VALOR'
,p_display_order=>90
,p_column_identifier=>'BI'
,p_column_label=>'Valor'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G990D00'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(82557801188515533)
,p_db_column_name=>'FECHAORDEN'
,p_display_order=>100
,p_column_identifier=>'BK'
,p_column_label=>'F. Orden'
,p_column_type=>'DATE'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(82557955197515534)
,p_db_column_name=>'FECHAENTREGA'
,p_display_order=>110
,p_column_identifier=>'BL'
,p_column_label=>'F. Entrega'
,p_column_type=>'DATE'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(82558028549515535)
,p_db_column_name=>'COMPANIA'
,p_display_order=>120
,p_column_identifier=>'BM'
,p_column_label=>'Compania'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(82558238414515537)
,p_db_column_name=>'DESCRIPCION'
,p_display_order=>130
,p_column_identifier=>'BO'
,p_column_label=>unistr('Descripci\00F3n')
,p_column_html_expression=>'<span style="width=50px;word-wrap: normal; ">#DESCRIPCION#</span>'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(83264087929238742)
,p_db_column_name=>'ORIGEN'
,p_display_order=>140
,p_column_identifier=>'BQ'
,p_column_label=>unistr('Pa\00EDs')
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(83264114414238743)
,p_db_column_name=>'ABAT1'
,p_display_order=>150
,p_column_identifier=>'BR'
,p_column_label=>'Origen'
,p_column_type=>'STRING'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_rpt_named_lov=>wwv_flow_imp.id(107474199533629316)
,p_rpt_show_filter_lov=>'1'
,p_display_condition_type=>'ITEM_IS_NULL'
,p_display_condition=>'P107_TIPO_PROVEEDOR'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(107417084607497241)
,p_db_column_name=>'NUMERO_TIPO'
,p_display_order=>160
,p_column_identifier=>'BS'
,p_column_label=>'Orden'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(107417125003497242)
,p_db_column_name=>'RIMPE'
,p_display_order=>170
,p_column_identifier=>'BT'
,p_column_label=>'Rimpe'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(266496634213507003)
,p_db_column_name=>'NUMERO'
,p_display_order=>180
,p_column_identifier=>'BU'
,p_column_label=>'Numero'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20251126221306Z')
,p_updated_on=>wwv_flow_imp.dz('20251126221306Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(161605774394680276)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'815474'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'SELECCION:GLIQ:NUMERO_TIPO:PROVEEDOR:RIMPE:ABAT1:ORIGEN:FECHAORDEN:FECHAENTREGA:DESCRIPCION:VALOR'
,p_sort_column_1=>'FECHAORDEN'
,p_sort_direction_1=>'DESC'
,p_sort_column_2=>'NUMERO_TIPO'
,p_sort_direction_2=>'DESC'
,p_sort_column_3=>'0'
,p_sort_direction_3=>'ASC'
,p_sort_column_4=>'0'
,p_sort_direction_4=>'ASC'
,p_sort_column_5=>'0'
,p_sort_direction_5=>'ASC'
,p_sort_column_6=>'0'
,p_sort_direction_6=>'ASC'
,p_sum_columns_on_break=>'VALOR'
,p_created_on=>wwv_flow_imp.dz('20230705164634Z')
,p_updated_on=>wwv_flow_imp.dz('20251126221306Z')
,p_created_by=>'CVACA'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(81486463153088441)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(87313050236148690)
,p_button_name=>'Buscar'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860056812106557)
,p_button_image_alt=>'Buscar'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-search'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(81491122569088445)
,p_name=>'P107_FECHA_INICIO'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_imp.id(87313169172148691)
,p_prompt=>'Fecha Inicio'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select TRUNC(ADD_MONTHS(SYSDATE,-VALOR), ''YEAR'') fecha from t_corp_udc',
'where id_cabecera=''721'' and ID_TABLA=''2'';'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(81491583771088447)
,p_name=>'P107_FECHA_FIN'
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_imp.id(87313169172148691)
,p_prompt=>'Fecha fin'
,p_source=>'SELECT  SYSDATE FROM DUAL'
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
,p_updated_on=>wwv_flow_imp.dz('20250627170805Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(81922065418378632)
,p_name=>'P107_CADENA'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(109201059134542347)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(81922135566378633)
,p_name=>'P107_NUMERO'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(109201059134542347)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(81922269232378634)
,p_name=>'P107_VALOR'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(109201059134542347)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(81922386252378635)
,p_name=>'P107_ISCHECKED'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(109201059134542347)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(81922598600378637)
,p_name=>'P107_ISCONFIRM'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(109201059134542347)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(81922766621378639)
,p_name=>'P107_MENSAJE2'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(109201059134542347)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(82555062189515505)
,p_name=>'P107_TIPO'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(109201059134542347)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(107414118355497212)
,p_name=>'P107_BUSCAR'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_imp.id(109201059134542347)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(107414849777497219)
,p_name=>'P107_TPROV'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(109201059134542347)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(107416630343497237)
,p_name=>'P107_TIPO_PROVEEDOR'
,p_item_sequence=>120
,p_item_plug_id=>wwv_flow_imp.id(87313169172148691)
,p_prompt=>'Origen Proveedor'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'LOV_TIPOPROVEEDOR'
,p_lov=>'.'||wwv_flow_imp.id(107474199533629316)||'.'
,p_lov_display_null=>'YES'
,p_lov_null_text=>'Todos'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'NONE'
,p_updated_on=>wwv_flow_imp.dz('20250627170804Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(109201101661542348)
,p_name=>'P107_BANDERA'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(109201059134542347)
,p_prompt=>'Bandera'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(81921016767378622)
,p_name=>'Columa Selecionar: Generar Liquidaciones'
,p_event_sequence=>93
,p_triggering_element_type=>'JQUERY_SELECTOR'
,p_triggering_element=>'.chkF01'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(81921154513378623)
,p_event_id=>wwv_flow_imp.id(81921016767378622)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'var obj= $(this.triggeringElement);',
'var cadena        = obj.val();',
'var numero        = cadena.split(''|'')[0];',
'var valor         = cadena.split(''|'')[1];',
'var tipo          = cadena.split(''|'')[2];',
'var tprov         = cadena.split(''|'')[3];',
'var ischecked     = obj[0].checked',
'var mensaje       = "";',
'var isconfirm     = null;',
' ',
'console.clear();',
'',
'if (!ischecked){',
unistr('    mensaje="\00BFEsta seguro(a) de elimnar los detalles de las liquidaciones?";'),
'    isconfirm = confirm(mensaje);',
'    if (!isconfirm)',
'        {',
'            obj[0].checked=true;',
'        }',
'} ',
'console.log("P107_CADENA: "	+cadena);',
'console.log("P107_NUMERO: "	+numero);',
'console.log("P107_VALOR: "		+valor);',
'console.log("P107_ISCHECKED: "	+ischecked?1:0);',
'console.log("P107_MENSAJE2: "	+mensaje);',
'console.log("P107_ISCONFIRM: "	+isconfirm?1:0);',
'console.log("P107_TIPO: "		+tipo);',
'console.log("P107_TPROV: "		+tprov);',
'',
'$s("P107_CADENA"	,cadena);',
'$s("P107_NUMERO"	,numero);',
'$s("P107_VALOR"		,valor);',
'$s("P107_ISCHECKED"	,ischecked?1:0);',
'$s("P107_MENSAJE2"	,mensaje);',
'$s("P107_ISCONFIRM"	,isconfirm?1:0);',
'$s("P107_TIPO"	    ,tipo);',
'$s("P107_TPROV"	    ,tprov);',
''))
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(81923143387378643)
,p_event_id=>wwv_flow_imp.id(81921016767378622)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare v_periodo date;',
' v_valor0 number;',
' v_valor12 number;',
'v_desc varchar2(3999);',
'BEGIN',
'    v_valor12:=null;',
'    v_valor0:=0;',
'    v_periodo:=SYSDATE;',
'    v_desc:=''p_ischecked:''||:P107_ischecked||'',p_isconfirm:''||:P107_isconfirm||'',p_periodo:''||v_periodo||'',p_numero:''||:P107_numero||'',p_tipo:''||:P107_TIPO||'',p_valor12:''||v_valor12||'',p_valor0:''||v_valor0||'',p_usuario:''||:app_user||'',p_maximo:''||v_v'
||'alor12||'',p_pagina:''||''principal''||'',p_mensaje:''||:P107_mensaje2 ||'',tipoproveedor:''||:P107_TPROV ;',
'    pk_commons.sp_apex_log (  ''APEX.dinamicos'',1, ''tipoproveedor:''||:P107_TPROV  ,''PRE procedimento sp_gliq_dinamincas_insert'',null,null);COMMIT;',
'    ',
'    ',
'    PK_FINZ_GLIQ_DINAMICAS.sp_gliq_dinamincas_insert (',
'                  :p107_ischecked      ',
'                , :p107_isconfirm  ',
'                , v_periodo',
'                , :p107_numero         ',
'                , :P107_TIPO          ',
'                , v_valor12',
'                , v_valor0          ',
'                , :app_user        ',
'                , v_valor12',
'                , :P107_TPROV',
'                , ''principal''',
'                , :p107_mensaje2 ',
'                ) ;',
'    ',
' end;'))
,p_attribute_02=>'P107_ISCHECKED,P107_ISCONFIRM,P107_VALOR,P107_NUMERO,P107_TIPO,P107_TPROV'
,p_attribute_03=>'P107_MENSAJE2'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(82554915380515504)
,p_event_id=>wwv_flow_imp.id(81921016767378622)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'var msj= $v("P107_MENSAJE2");',
'var isCheked= $v("P107_ISCHECKED");',
'if (msj != ''''){',
'    mensajeError(msj);',
'}else{',
'    if (isCheked==true){',
unistr('        mensajeExito(''<span class="fa fa-thumbs-up"   style="font-size: small;" >Transacci\00F3n de ingreso de liquidaciones ejecutada correctamente.</span> '');'),
'    } ',
'        ',
'',
'}',
' '))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(85400224637000817)
,p_name=>'Columa GLIQ: Cerrar cuadro dialogo en columna'
,p_event_sequence=>113
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(161530776077168645)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(87556527476834025)
,p_event_id=>wwv_flow_imp.id(85400224637000817)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_02=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(89722006465402744)
,p_name=>'Cambia Fecha Inicio'
,p_event_sequence=>123
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P107_FECHA_INICIO'
,p_condition_element=>'P107_FECHA_INICIO'
,p_triggering_condition_type=>'NOT_NULL'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(89722165079402745)
,p_event_id=>wwv_flow_imp.id(89722006465402744)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_02=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(89722256691402746)
,p_name=>'Cambia Fecha Fin'
,p_event_sequence=>133
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P107_FECHA_FIN'
,p_condition_element=>'P107_FECHA_FIN'
,p_triggering_condition_type=>'NOT_NULL'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(89722394895402747)
,p_event_id=>wwv_flow_imp.id(89722256691402746)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_02=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(107414216296497213)
,p_name=>'Boton Buscar: Buscar Datos'
,p_event_sequence=>143
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(81486463153088441)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(109201225730542349)
,p_event_id=>wwv_flow_imp.id(107414216296497213)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P107_BANDERA'
,p_attribute_01=>'STATIC_ASSIGNMENT'
,p_attribute_02=>'1'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(107414437001497215)
,p_event_id=>wwv_flow_imp.id(107414216296497213)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_01=>'Buscar'
,p_attribute_02=>'Y'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(107414792581497218)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Ejecutar Buscar'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'    :P107_BUSCAR:=1;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>107414792581497218
);
wwv_flow_imp.component_end;
end;
/
