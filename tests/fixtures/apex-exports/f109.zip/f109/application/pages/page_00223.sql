prompt --application/pages/page_00223
begin
--   Manifest
--     PAGE: 00223
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>109
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_page.create_page(
 p_id=>223
,p_name=>'Bill of Materials Variation'
,p_step_title=>'Bill of Materials Variation'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_page_component_map=>'18'
,p_created_on=>wwv_flow_imp.dz('20230705164635Z')
,p_last_updated_on=>wwv_flow_imp.dz('20220706171133Z')
,p_last_updated_by=>'EZAMBRANO'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(96297339070404212)
,p_plug_name=>'Barra de acciones'
,p_region_template_options=>'#DEFAULT#:t-Form--stretchInputs'
,p_plug_template=>wwv_flow_imp.id(38289497777120142)
,p_plug_display_sequence=>1
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'REGION_POSITION_01'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(124472096515603663)
,p_plug_name=>'Busqueda'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(38289867500120143)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(124505851163618886)
,p_plug_name=>unistr('Reporte de Costos Producci\00F3n ')
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(95503811913299190)
,p_plug_display_sequence=>30
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT Y.CODIGOPADRE, MAX( Y.CODIGOPADRE||''-''||Y.DESCRIPCION) NOMBRE , Y.TIPOPROD, ',
unistr(' DECODE (Y.U_ANIO, 9999,''VARIACI\00D3N %'',Y.U_ANIO)  ANIO ,DECODE ( Y.U_MES,13,'' '',Y.U_MES)  MES,'),
' SUM(Y.u_PRECIO) COSTO,(select sum(X.u_PRECIO) from SBO_ZM_US_PROD.VT_SAP_HISTORICOBOM@HANA X WHERE  X.CODIGOPADRE= Y.CODIGOPADRE ',
' and y.u_anio = x.u_anio and y.u_mes= x.u_mes and X.tipo =Y.TIPO GROUP BY X.CODIGOPADRE ) TOTAL , Y.TIPO ',
' FROM SBO_ZM_US_PROD.VT_SAP_HISTORICOBOM@HANA Y',
' WHERE ',
' Y.U_ANIO= :P223_DESDE',
' AND  Y.U_MES= :P223_MES_AC',
' AND (Y.CODIGOPADRE =:P223_ITEM  OR :P223_ITEM IS NULL)',
' AND TIPO =''A''',
' GROUP BY Y.CODIGOPADRE,Y.TIPOPROD,   Y.U_ANIO, Y.U_MES, Y.TIPO',
'UNION ALL',
'SELECT X.CODIGOPADRE, MAX( X.CODIGOPADRE||''-''||X.DESCRIPCION)  NOMBRE , X.TIPOPROD, ',
unistr(' DECODE (X.U_ANIO, 9999,''VARIACI\00D3N %'',X.U_ANIO) ANIO,DECODE ( X.U_MES,13,'' '',X.U_MES) MES,'),
' SUM(X.U_PRECIO) COSTO,(select sum(Z.u_PRECIO) from SBO_ZM_US_PROD.VT_SAP_HISTORICOBOM@HANA Z WHERE  Z.CODIGOPADRE= X.CODIGOPADRE ',
' and Z.u_anio = x.u_anio and Z.u_mes= x.u_mes and X.tipo =Z.TIPO GROUP BY Z.CODIGOPADRE ) TOTAL ,X.TIPO ',
' FROM SBO_ZM_US_PROD.VT_SAP_HISTORICOBOM@HANA X',
' WHERE ',
' X.U_ANIO= :P223_HASTA',
' AND  X.U_MES= :P223_MES_COM',
' AND (X.CODIGOPADRE =:P223_ITEM  OR :P223_ITEM IS NULL)',
' AND X.TIPO =''H''',
' GROUP BY X.CODIGOPADRE,X.TIPOPROD,   X.U_ANIO, X.U_MES, X.TIPO ',
'UNION ALL',
'SELECT X.CODIGOPADRE,MAX( X.CODIGOPADRE||''-''||X.DESCRIPCION) NOMBRE , X.TIPOPROD,',
unistr('DECODE (9999, 9999,''3.VARIACI\00D3N %'',0) ANIO, DECODE ( 13,13,'' '',0) MES,'),
' (ROUND((SUM(X.U_PRECIO)- (SELECT SUM (Y.U_PRECIO ) FROM SBO_ZM_US_PROD.VT_SAP_HISTORICOBOM@HANA Y',
' WHERE  Y.U_ANIO= :P223_DESDE  AND  Y.U_MES= :P223_MES_AC AND (Y.CODIGOPADRE =:P223_ITEM  OR :P223_ITEM IS NULL)',
'  AND  X.CODIGOPADRE = Y.CODIGOPADRE AND X.TIPOPROD = Y.TIPOPROD  AND TIPO = ''A''                  ',
' GROUP BY Y.CODIGOPADRE,Y.TIPOPROD,  Y.U_ANIO, Y.U_MES))/',
' (SELECT SUM (Y.U_PRECIO ) FROM SBO_ZM_US_PROD.VT_SAP_HISTORICOBOM@HANA Y',
' WHERE  Y.U_ANIO= :P223_DESDE  AND  Y.U_MES= :P223_MES_AC AND (Y.CODIGOPADRE =:P223_ITEM  OR :P223_ITEM IS NULL)',
'  AND  X.CODIGOPADRE = Y.CODIGOPADRE AND X.TIPOPROD = Y.TIPOPROD AND TIPO = ''A''',
' GROUP BY Y.CODIGOPADRE,Y.TIPOPROD,  Y.U_ANIO, Y.U_MES),2) *100) *-1 VARIACION, 0,''V''',
' FROM SBO_ZM_US_PROD.VT_SAP_HISTORICOBOM@HANA X',
' WHERE ',
' X.U_ANIO= :P223_HASTA',
' AND  X.U_MES= :P223_MES_COM',
' AND (X.CODIGOPADRE=:P223_ITEM   OR :P223_ITEM IS NULL)',
' AND TIPO = ''H''',
' GROUP BY X.CODIGOPADRE,X.TIPOPROD,   X.U_ANIO, X.U_MES',
''))
,p_plug_source_type=>'NATIVE_IR'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(124505951792618886)
,p_name=>unistr('Reporte de Costos Producci\00F3n ')
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'EZAMBRANO'
,p_internal_uid=>124505951792618886
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(63100039964693448)
,p_db_column_name=>'NOMBRE'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Nombre'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(63101254162693448)
,p_db_column_name=>'COSTO'
,p_display_order=>230
,p_column_identifier=>'AD'
,p_column_label=>'Costo'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(63101691757693448)
,p_db_column_name=>'CODIGOPADRE'
,p_display_order=>240
,p_column_identifier=>'AE'
,p_column_label=>'Codigopadre'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(63102076639693448)
,p_db_column_name=>'TIPOPROD'
,p_display_order=>250
,p_column_identifier=>'AF'
,p_column_label=>'Tipoprod'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(63102473835693449)
,p_db_column_name=>'TIPO'
,p_display_order=>260
,p_column_identifier=>'AG'
,p_column_label=>'Tipo'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(96298461339404223)
,p_db_column_name=>'TOTAL'
,p_display_order=>270
,p_column_identifier=>'AH'
,p_column_label=>'Total'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(96298534488404224)
,p_db_column_name=>'ANIO'
,p_display_order=>280
,p_column_identifier=>'AI'
,p_column_label=>'Anio'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(96298640268404225)
,p_db_column_name=>'MES'
,p_display_order=>290
,p_column_identifier=>'AJ'
,p_column_label=>'Mes'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(124506657663619598)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_type=>'PIVOT'
,p_report_alias=>'631028'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_view_mode=>'REPORT'
,p_report_columns=>'CODIGOPADRE:NOMBRE:COSTO:TIPO:TOTAL:ANIO:'
,p_sort_column_1=>'ANIO'
,p_sort_direction_1=>'DESC'
,p_created_on=>wwv_flow_imp.dz('20230705164635Z')
,p_updated_on=>wwv_flow_imp.dz('20230705164635Z')
,p_created_by=>'CVACA'
,p_updated_by=>'CVACA'
);
wwv_flow_imp_page.create_worksheet_pivot(
 p_id=>wwv_flow_imp.id(136909308295829992)
,p_report_id=>wwv_flow_imp.id(124506657663619598)
,p_pivot_columns=>'ANIO:MES:TIPOPROD'
,p_row_columns=>'NOMBRE'
,p_created_on=>wwv_flow_imp.dz('20230705164635Z')
,p_updated_on=>wwv_flow_imp.dz('20230705164635Z')
,p_created_by=>'CVACA'
,p_updated_by=>'CVACA'
);
wwv_flow_imp_page.create_worksheet_pivot_agg(
 p_id=>wwv_flow_imp.id(136909792007829992)
,p_pivot_id=>wwv_flow_imp.id(136909308295829992)
,p_display_seq=>1
,p_function_name=>'SUM'
,p_column_name=>'COSTO'
,p_db_column_name=>'PFC1'
,p_column_label=>' '
,p_format_mask=>'999G999G999G999G990D0000'
,p_display_sum=>'N'
,p_created_on=>wwv_flow_imp.dz('20230705164635Z')
,p_updated_on=>wwv_flow_imp.dz('20230705164635Z')
,p_created_by=>'CVACA'
,p_updated_by=>'CVACA'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(63104290518693449)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(96297339070404212)
,p_button_name=>'Buscar'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860056812106557)
,p_button_image_alt=>'Buscar'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-search'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(63104905974693452)
,p_name=>'P223_DESDE'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(124472096515603663)
,p_prompt=>unistr('Per\00EDodo Act:')
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'STATIC:2020;2020,2021;2021,2022;2022,2023;2023,2024;2024,2025;2025,2026;2026,2027;2027,2028;2028,2029;2029,2030;2030'
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(63105398229693452)
,p_name=>'P223_MES_AC'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(124472096515603663)
,p_prompt=>'Mes Actual:'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'STATIC:1;1,2;2,3;3,4;4,5;5,6;6,7;7,8;8,9;9,10;10,11;11,12;12'
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(63105707215693452)
,p_name=>'P223_HASTA'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(124472096515603663)
,p_prompt=>unistr('Per\00EDodo Com:')
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'STATIC:2020;2020,2021;2021,2022;2022,2023;2023,2024;2024,2025;2025,2026;2026,2027;2027,2028;2028,2029;2029,2030;2030'
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(63106162956693452)
,p_name=>'P223_MES_COM'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(124472096515603663)
,p_prompt=>'Mes Comparar:'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'STATIC:1;1,2;2,3;3,4;4,5;5,6;6,7;7,8;8,9;9,10;10,11;11,12;12'
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(63106573403693454)
,p_name=>'P223_MACHINE'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(124472096515603663)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(63106941990693454)
,p_name=>'P223_ITEM'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(124472096515603663)
,p_prompt=>'Item:'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select T0."ItemCode" || ''-'' || T0."ItemName" a, T0."ItemCode" b FROM SBO_ZM_US_PROD.OITM@HANA T0',
'WHERE T0."ItmsGrpCod"  IN (''100'',''101'')',
''))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'Todos'
,p_lov_null_value=>'Todos'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'DIALOG'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_04=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(63107915309693454)
,p_name=>'BUSCAR'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(63104290518693449)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(63108484674693454)
,p_event_id=>wwv_flow_imp.id(63107915309693454)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_02=>'Y'
);
wwv_flow_imp.component_end;
end;
/
