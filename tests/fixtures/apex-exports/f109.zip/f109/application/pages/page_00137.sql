prompt --application/pages/page_00137
begin
--   Manifest
--     PAGE: 00137
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>109
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_page.create_page(
 p_id=>137
,p_name=>'ISD/FH - Parametros ISD form'
,p_alias=>'ISD-FH-PARAMETROS-ISD-FORM'
,p_page_mode=>'MODAL'
,p_step_title=>unistr('Par\00E1metros ISD')
,p_autocomplete_on_off=>'OFF'
,p_javascript_code_onload=>'$(secItems).hide();'
,p_page_template_options=>'#DEFAULT#'
,p_dialog_width=>'60%'
,p_dialog_chained=>'N'
,p_protection_level=>'C'
,p_page_component_map=>'02'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(228903350230347526)
,p_plug_name=>'New'
,p_region_template_options=>'#DEFAULT#:t-Alert--colorBG:t-Alert--horizontal:t-Alert--defaultIcons:t-Alert--danger:t-Alert--removeHeading'
,p_region_attributes=>'style=''color:red'''
,p_plug_template=>wwv_flow_imp.id(37782629797106503)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_location=>null
,p_plug_source=>unistr('<span style=''color:red''>El c\00F3digo de ISD ya tiene partidas arancelarias asociadas.</span>')
,p_plug_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_plug_display_when_condition=>'P137_CONTARPRT'
,p_plug_display_when_cond2=>'1'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(620280818876478203)
,p_plug_name=>'Items'
,p_region_name=>'secItems'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(38289867500120143)
,p_plug_display_sequence=>20
,p_location=>null
,p_ai_enabled=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(633362536361708192)
,p_plug_name=>'ISD/FH - Parametros ISD'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(38289867500120143)
,p_plug_display_sequence=>10
,p_query_type=>'TABLE'
,p_query_table=>'T_CORP_UDC'
,p_include_rowid_column=>false
,p_is_editable=>true
,p_edit_operations=>'i:u:d'
,p_lost_update_check_type=>'VALUES'
,p_plug_source_type=>'NATIVE_FORM'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(633372028109708215)
,p_plug_name=>'Buttons'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(37787379178106507)
,p_plug_display_sequence=>20
,p_plug_display_point=>'REGION_POSITION_03'
,p_ai_enabled=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'TEXT',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(214641410454904388)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(633372028109708215)
,p_button_name=>'Cerrar'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860181880106559)
,p_button_image_alt=>'Cerrar'
,p_button_position=>'CLOSE'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(214641810468904389)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(633372028109708215)
,p_button_name=>'Eliminar'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860181880106559)
,p_button_image_alt=>'Eliminar'
,p_button_position=>'DELETE'
,p_button_execute_validations=>'N'
,p_confirm_message=>'&APP_TEXT$DELETE_MSG!RAW.'
,p_confirm_style=>'danger'
,p_button_condition=>':P137_ID IS NOT NULL AND  :P137_CONTARPRT=0'
,p_button_condition2=>'PLSQL'
,p_button_condition_type=>'EXPRESSION'
,p_database_action=>'DELETE'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(214642237601904390)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(633372028109708215)
,p_button_name=>'SAVE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860181880106559)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Guardar'
,p_button_position=>'NEXT'
,p_button_condition=>'P137_ID'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_database_action=>'UPDATE'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(214642693564904390)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(633372028109708215)
,p_button_name=>'CREATE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860181880106559)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Guardar'
,p_button_position=>'NEXT'
,p_button_condition=>'P137_ID'
,p_button_condition_type=>'ITEM_IS_NULL'
,p_database_action=>'INSERT'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(228902959957347522)
,p_name=>'P137_CONTARPRT'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(620280818876478203)
,p_item_default=>unistr('Existen Partidas Arancelarias atadas a este C\00F3digo de Impuesto ISD')
,p_prompt=>'Contarprt'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--stretchInputs:t-Form-fieldContainer--xlarge:t-Form-fieldContainer--radioButtonGroup'
,p_warn_on_unsaved_changes=>'I'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(228903752353347530)
,p_name=>'P137_DESHABILITAR'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_imp.id(620280818876478203)
,p_prompt=>'Deshabilitar'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(228903979616347532)
,p_name=>'P137_CONTARDET'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(620280818876478203)
,p_prompt=>'Contardet'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(633364092856708269)
,p_name=>'P137_ID'
,p_source_data_type=>'NUMBER'
,p_is_primary_key=>true
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(620280818876478203)
,p_item_source_plug_id=>wwv_flow_imp.id(633362536361708192)
,p_source=>'ID'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_protection_level=>'S'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(633364903838708274)
,p_name=>'P137_ID_CABECERA'
,p_source_data_type=>'VARCHAR2'
,p_is_required=>true
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(620280818876478203)
,p_item_source_plug_id=>wwv_flow_imp.id(633362536361708192)
,p_item_default=>'FINZ_VISD'
,p_prompt=>'Id Cabecera'
,p_source=>'ID_CABECERA'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>32
,p_cMaxlength=>10
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(633366113430708284)
,p_name=>'P137_VALOR2'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(620280818876478203)
,p_item_source_plug_id=>wwv_flow_imp.id(633362536361708192)
,p_prompt=>'Valor2'
,p_source=>'VALOR2'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>60
,p_cMaxlength=>2000
,p_cHeight=>4
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(633366903641708284)
,p_name=>'P137_DESCRIPCION2'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(620280818876478203)
,p_item_source_plug_id=>wwv_flow_imp.id(633362536361708192)
,p_item_default=>'SEPARADOR DE DECIMALES: coma (,)'
,p_prompt=>'Descripcion2'
,p_source=>'DESCRIPCION2'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>60
,p_cMaxlength=>500
,p_cHeight=>4
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(633367287204708285)
,p_name=>'P137_CODIGOCOMPANIA'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(620280818876478203)
,p_item_source_plug_id=>wwv_flow_imp.id(633362536361708192)
,p_item_default=>'G_COMPANIA'
,p_item_default_type=>'ITEM'
,p_prompt=>'Codigocompania'
,p_source=>'CODIGOCOMPANIA'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>32
,p_cMaxlength=>5
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(633368444946708286)
,p_name=>'P137_DESCRIPCION3'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(620280818876478203)
,p_item_source_plug_id=>wwv_flow_imp.id(633362536361708192)
,p_item_default=>'VALOR Y VIGENCIA DEL IMPUESTO A LA SALIDA DE DIVISAS (ISD)'
,p_prompt=>'Descripcion3'
,p_source=>'DESCRIPCION3'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>60
,p_cMaxlength=>500
,p_cHeight=>4
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(633368909911708286)
,p_name=>'P137_VALOR3'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(620280818876478203)
,p_item_source_plug_id=>wwv_flow_imp.id(633362536361708192)
,p_item_default=>'-'
,p_prompt=>'Valor3'
,p_source=>'VALOR3'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>60
,p_cMaxlength=>500
,p_cHeight=>4
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(633371134987708308)
,p_name=>'P137_ACTIVO'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(633362536361708192)
,p_item_source_plug_id=>wwv_flow_imp.id(633362536361708192)
,p_item_default=>'1'
,p_prompt=>'Estado'
,p_source=>'ACTIVO'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_YES_NO'
,p_begin_on_new_line=>'N'
,p_read_only_when=>'P137_CONTARDET'
,p_read_only_when2=>'1'
,p_read_only_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'1'
,p_attribute_03=>'Activo'
,p_attribute_04=>'0'
,p_attribute_05=>'Inactivo'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(633374348407708322)
,p_name=>'P137_ID_TABLA'
,p_source_data_type=>'VARCHAR2'
,p_is_primary_key=>true
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(633362536361708192)
,p_item_source_plug_id=>wwv_flow_imp.id(633362536361708192)
,p_prompt=>unistr('C\00F3digo ISD')
,p_source=>'ID_TABLA'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>10
,p_cMaxlength=>10
,p_tag_attributes=>'onkeypress="return /^[a-zA-Z0-9]$/.test(event.key)" '''
,p_read_only_when=>'P137_ID'
,p_read_only_when_type=>'ITEM_IS_NOT_NULL'
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_attribute_06=>'UPPER'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(633375172296708324)
,p_name=>'P137_DESCRIPCION'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(633362536361708192)
,p_item_source_plug_id=>wwv_flow_imp.id(633362536361708192)
,p_prompt=>unistr('Descripci\00F3n')
,p_source=>'DESCRIPCION'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>60
,p_cMaxlength=>200
,p_tag_attributes=>'onkeypress="return /^[a-zA-Z0-9 ]$/.test(event.key)" '''
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(633375538665708333)
,p_name=>'P137_VALOR'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(633362536361708192)
,p_item_source_plug_id=>wwv_flow_imp.id(633362536361708192)
,p_prompt=>'Porcentaje'
,p_format_mask=>'990D00'
,p_source=>'VALOR'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>5
,p_cMaxlength=>5
,p_tag_attributes=>'style="width: 90%;"  oninput="this.value = this.value   .replace(/[^0-9.,]/g,'''')   .replace(/([.,].*)[.,]/g,''$1'')"'
,p_begin_on_new_line=>'N'
,p_read_only_when=>'P137_ID'
,p_read_only_when_type=>'ITEM_IS_NOT_NULL'
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(633377604757708334)
,p_name=>'P137_VIGENCIADESDE'
,p_source_data_type=>'DATE'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(633362536361708192)
,p_item_source_plug_id=>wwv_flow_imp.id(633362536361708192)
,p_prompt=>'Vigencia Desde'
,p_placeholder=>'DD/MM/YYYY'
,p_source=>'VIGENCIADESDE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DATE_PICKER_APEX'
,p_cSize=>10
,p_cMaxlength=>255
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--radioButtonGroup'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'POPUP'
,p_attribute_03=>'NONE'
,p_attribute_06=>'NONE'
,p_attribute_09=>'N'
,p_attribute_11=>'N'
,p_attribute_12=>'TODAY-BUTTON'
,p_attribute_13=>'VISIBLE'
,p_attribute_15=>'FOCUS'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(633377997324708335)
,p_name=>'P137_VIGENCIAHASTA'
,p_source_data_type=>'DATE'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(633362536361708192)
,p_item_source_plug_id=>wwv_flow_imp.id(633362536361708192)
,p_prompt=>'Vigencia Hasta'
,p_placeholder=>'DD/MM/YYYY'
,p_source=>'VIGENCIAHASTA'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DATE_PICKER_APEX'
,p_cSize=>10
,p_cMaxlength=>255
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--radioButtonGroup'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'POPUP'
,p_attribute_03=>'NONE'
,p_attribute_06=>'NONE'
,p_attribute_09=>'N'
,p_attribute_11=>'N'
,p_attribute_12=>'TODAY-BUTTON'
,p_attribute_13=>'VISIBLE'
,p_attribute_15=>'FOCUS'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(214643331858904402)
,p_validation_name=>'Codigo Unico'
,p_validation_sequence=>10
,p_validation=>'select * from data.t_corp_udc where ID_CABECERA=''FINZ_VISD'' and ID_TABLA not in (''S'',''N'') and ID_TABLA=:P137_ID_TABLA'
,p_validation_type=>'NOT_EXISTS'
,p_error_message=>unistr('#LABEL#: C\00F3digo ingresado ya existe.')
,p_when_button_pressed=>wwv_flow_imp.id(214642693564904390)
,p_associated_item=>wwv_flow_imp.id(633374348407708322)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(214644169389904403)
,p_validation_name=>'idtabla novacio'
,p_validation_sequence=>20
,p_validation=>'P137_ID_TABLA'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>'#LABEL# debe tener un valor.'
,p_associated_item=>wwv_flow_imp.id(633374348407708322)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(214644580709904403)
,p_validation_name=>'valor novacio'
,p_validation_sequence=>30
,p_validation=>'P137_VALOR'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>'#LABEL# debe tener un valor.'
,p_associated_item=>wwv_flow_imp.id(633375538665708333)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(196203843774030741)
,p_validation_name=>'valor solo numeros'
,p_validation_sequence=>40
,p_validation=>'return pk_commons.f_esnumero(:P137_VALOR)=1;'
,p_validation2=>'PLSQL'
,p_validation_type=>'FUNC_BODY_RETURNING_BOOLEAN'
,p_error_message=>unistr('#LABEL# debe contener solo n\00FAmeros.')
,p_associated_item=>wwv_flow_imp.id(633375538665708333)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(196204079083030743)
,p_validation_name=>'valor no puede ser negativo ni mayor a 100'
,p_validation_sequence=>50
,p_validation=>'return pk_commons.safe_to_number(:P137_VALOR) between 0 and 100;'
,p_validation2=>'PLSQL'
,p_validation_type=>'FUNC_BODY_RETURNING_BOOLEAN'
,p_error_message=>'#LABEL# debe ser un valor entre 0 y 100.'
,p_associated_item=>wwv_flow_imp.id(633375538665708333)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(214644999218904404)
,p_validation_name=>unistr('descripci\00F3n novacio')
,p_validation_sequence=>60
,p_validation=>'P137_DESCRIPCION'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>'#LABEL# debe tener un valor.'
,p_associated_item=>wwv_flow_imp.id(633375172296708324)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(214645335742904404)
,p_validation_name=>'novacio fechadesde'
,p_validation_sequence=>70
,p_validation=>'P137_VIGENCIADESDE'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>'#LABEL# debe tener un valor.'
,p_associated_item=>wwv_flow_imp.id(633377604757708334)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(214645786826904404)
,p_validation_name=>'novacio fechahasta'
,p_validation_sequence=>80
,p_validation=>'P137_VIGENCIAHASTA'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>'#LABEL# debe tener un valor.'
,p_associated_item=>wwv_flow_imp.id(633377997324708335)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(214643757537904403)
,p_validation_name=>'No solapar Fechas'
,p_validation_sequence=>100
,p_validation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select * from data.t_corp_udc where ID_CABECERA=''FINZ_VISD'' ',
'and id_tabla=:P137_ID_TABLA --2601',
'AND (:P137_ACTIVO=1',
'and (:P137_VIGENCIADESDE <= VIGENCIAHASTA',
'AND :P137_VIGENCIAHASTA >= VIGENCIADESDE)',
')',
'and (id!=:P137_ID OR :P137_ID IS NULL) ',
'',
';'))
,p_validation_type=>'NOT_EXISTS'
,p_error_message=>unistr('El rango de vigencia ingresado se solapa con un o m\00E1s registros existentes.')
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(245338908251657142)
,p_validation_name=>'fecha ini no menor a fecha fin'
,p_validation_sequence=>110
,p_validation=>':P137_VIGENCIADESDE <= :P137_VIGENCIAHASTA'
,p_validation2=>'PLSQL'
,p_validation_type=>'EXPRESSION'
,p_error_message=>'#LABEL# no puede ser menor que la de inicio'
,p_associated_item=>wwv_flow_imp.id(633377997324708335)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(214646454502904405)
,p_name=>'Cancel Dialog'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(214641410454904388)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(214646949372904407)
,p_event_id=>wwv_flow_imp.id(214646454502904405)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CLOSE'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(228903498186347527)
,p_name=>'New'
,p_event_sequence=>20
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P137_ACTIVO'
,p_condition_element=>'P137_ACTIVO'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'0'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(228903595214347528)
,p_event_id=>wwv_flow_imp.id(228903498186347527)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_CONFIRM'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
unistr('Al inhabilitar el c\00F3digo ISD, se desactivar\00E1 la relaci\00F3n con las partidas arancelarias asociadas. '),
unistr('\00BFDesea continuar?')))
,p_attribute_02=>unistr('Inhabilitaci\00F3n de C\00F3digo ISD')
,p_attribute_03=>'warning'
,p_attribute_04=>'fa-warning'
,p_attribute_06=>unistr('S\00CD')
,p_attribute_07=>'NO'
,p_client_condition_type=>'EQUALS'
,p_client_condition_element=>'P137_CONTARPRT'
,p_client_condition_expression=>'1'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(228903603783347529)
,p_event_id=>wwv_flow_imp.id(228903498186347527)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>':P137_DESHABILITAR:=1;'
,p_attribute_03=>'P137_DESHABILITAR'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(196203954453030742)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'New'
,p_process_sql_clob=>':P137_VALOR:=to_char(pk_commons.safe_to_number(:P137_VALOR),''999G999G999G999G990D00'');'
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>196203954453030742
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(214640769455904388)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_region_id=>wwv_flow_imp.id(633362536361708192)
,p_process_type=>'NATIVE_FORM_DML'
,p_process_name=>'Process form ISD/FH - Parametros ISD form'
,p_attribute_01=>'REGION_SOURCE'
,p_attribute_05=>'Y'
,p_attribute_06=>'Y'
,p_attribute_08=>'Y'
,p_process_error_message=>'Error al almacenar datos.'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_success_message=>'Datos almacenados.'
,p_internal_uid=>214640769455904388
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(228903807667347531)
,p_process_sequence=>30
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Process form ISD/FH - Parametros ISD form_1'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'if (:P137_DESHABILITAR=1)then',
'    update t_finz_calculoisdprt ',
'    set activo=0 ',
'    where  CODISD= :P137_ID_TABLA and activo=1;',
'    :P137_DESHABILITAR:=0;',
'end if;'))
,p_process_clob_language=>'PLSQL'
,p_process_error_message=>'Error al almacenar datos.'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_success_message=>'Datos almacenados.'
,p_internal_uid=>228903807667347531
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(214646055199904404)
,p_process_sequence=>40
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_CLOSE_WINDOW'
,p_process_name=>'Cerrar'
,p_attribute_02=>'Y'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(214641810468904389)
,p_internal_uid=>214646055199904404
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(214640373876904384)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_region_id=>wwv_flow_imp.id(633362536361708192)
,p_process_type=>'NATIVE_FORM_INIT'
,p_process_name=>'Initialize form ISD/FH - Parametros ISD form'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>214640373876904384
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(228903167420347524)
,p_process_sequence=>20
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Alerta'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE ',
'    V_CONTADOR1 NUMBER;',
'    V_CONTADOR2 NUMBER;',
'BEGIN',
'    :P137_CONTARPRT:=0;',
'    SELECT COUNT(DISTINCT 1) INTO V_CONTADOR1 FROM DATA.t_finz_calculoisdprt where  CODISD=:P137_ID_TABLA and activo=1;',
'    SELECT COUNT(DISTINCT 1) INTO V_CONTADOR2 FROM DATA.t_finz_calculoisddet where TIPOISD=:P137_ID_TABLA;',
'    V_CONTADOR1:=CASE WHEN (V_CONTADOR1+V_CONTADOR2)>0 THEN 1 ELSE 0 END;',
'    :P137_CONTARPRT:=V_CONTADOR1;',
'    :P137_CONTARDET:=V_CONTADOR2;',
'END;',
''))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>228903167420347524
);
wwv_flow_imp.component_end;
end;
/
