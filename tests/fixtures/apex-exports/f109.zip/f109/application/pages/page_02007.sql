prompt --application/pages/page_02007
begin
--   Manifest
--     PAGE: 02007
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>109
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_page.create_page(
 p_id=>2007
,p_name=>unistr('Vi\00E1ticos')
,p_step_title=>unistr('Vi\00E1ticos')
,p_autocomplete_on_off=>'OFF'
,p_javascript_code_onload=>'$(".t-Button.t-Button--icon.t-Button--header.t-Button--headerTree.is-active").click();'
,p_page_template_options=>'#DEFAULT#'
,p_page_component_map=>'18'
,p_created_on=>wwv_flow_imp.dz('20230705164635Z')
,p_last_updated_on=>wwv_flow_imp.dz('20250925160216Z')
,p_last_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(62294756474561034)
,p_plug_name=>'Acciones'
,p_region_template_options=>'#DEFAULT#:t-Form--stretchInputs'
,p_plug_template=>wwv_flow_imp.id(38289497777120142)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(62294874141561035)
,p_plug_name=>'Filtros'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(38289867500120143)
,p_plug_display_sequence=>30
,p_include_in_reg_disp_sel_yn=>'Y'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(68911970632578207)
,p_plug_name=>unistr('Vi\00E1ticos')
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(37806762584106520)
,p_plug_display_sequence=>40
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'with',
'tviatico as (',
'	select compania,codigomodulo,numeroliquidacion numeroviatico,sum(valortotal) valorliquidado',
'	from vt_corp_datoscomprobantes where origen is not null group by compania,codigomodulo,numeroliquidacion',
'), cviatico as (',
'	select compania,numeroviatico,sum(subtotal) valoracreditado from t_gvia_costoviaticos group by compania,numeroviatico',
'), rviatico as (',
'	select a.cia compania, b.idflujo, a.codpagina, a.estado, a.usuarioactual, to_number(a.entidad_id) numeroviatico',
'	from data.t_flujo_aprobacion_cab a inner join (',
'		select max(id) idflujo, to_number(entidad_id) numeroviatico, codmodulo',
'		from data.t_flujo_aprobacion_cab',
'		where codmodulo = ''GVIA''',
'		group by to_number(entidad_id), codmodulo',
'	) b on a.id = b.idflujo',
'), dviatico as (',
'	select a.compania',
'	, a.codmodulo',
'	, a.numeroviatico',
'	, a.codigo',
'	, a.numeroidentificacion',
'	, a.usuariocrea',
'	, a.solicitante',
'	, a.centrocostos',
'	, a.unidadnegociodes',
'	, a.tipoviatico',
'	, a.estado',
'	, a.estadoaprobacion',
'	, a.idflujo',
'	, a.usuarioflujo',
'	, a.fechasolicitud',
'	, a.fechaaprobacion',
'	, a.fechainicio',
'	, a.fechafin',
'	, a.fechapago',
'	, a.fechaliquidacion',
'	from vt_gvia_datosviatico a',
') select ''<span class="fa fa-file-pdf-o" style="color: #FF0000;" aria-hidden="true"></span>'' documentos',
'	, ''<span class="fa fa-road" style="color: #000000;" aria-hidden="true"></span>'' verruta',
'	, dviatico.*',
'	, decode(nvl(rviatico.codpagina,''NA''),''NA'',''NO APLICA'',''GVIAMOD07'',''SOLICITUD'',''GVIAMOD09'',''LIQUIDACION'',null) etapa',
'	, rviatico.estado estadoetapa',
'	, rviatico.usuarioactual usuarioetapa',
'	, nvl(cviatico.valoracreditado,0) valoracreditado ',
'	, nvl(tviatico.valorliquidado,0) valorliquidado ',
'	, case when nvl(tviatico.valorliquidado,0) > nvl(cviatico.valoracreditado,0) then nvl(tviatico.valorliquidado,0) - nvl(cviatico.valoracreditado,0) else 0 end valorpagar',
'	, case when nvl(tviatico.valorliquidado,0) < nvl(cviatico.valoracreditado,0) then nvl(cviatico.valoracreditado,0) - nvl(tviatico.valorliquidado,0) else 0 end valordescontar',
'from dviatico',
'left join tviatico on tviatico.compania = dviatico.compania and tviatico.numeroviatico = dviatico.numeroviatico',
'left join cviatico on dviatico.compania = cviatico.compania and dviatico.numeroviatico = cviatico.numeroviatico',
'left join rviatico on dviatico.compania = rviatico.compania and dviatico.numeroviatico = rviatico.numeroviatico and dviatico.idflujo = rviatico.idflujo',
'where 1 = 1',
'	and dviatico.fechasolicitud between :p2007_fechainicio and :p2007_fechafin'))
,p_plug_source_type=>'NATIVE_IR'
,p_ajax_items_to_submit=>'P2007_FECHAINICIO,P2007_FECHAFIN'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>unistr('Vi\00E1ticos')
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
,p_updated_on=>wwv_flow_imp.dz('20250925160216Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(68912082913578207)
,p_name=>unistr('REPORTE DE VI\00C1TICOS')
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'TOP_AND_BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_computation=>'N'
,p_show_aggregate=>'N'
,p_show_chart=>'N'
,p_show_group_by=>'N'
,p_show_pivot=>'N'
,p_show_flashback=>'N'
,p_show_help=>'N'
,p_download_formats=>'XLSX'
,p_enable_mail_download=>'N'
,p_owner=>'JALTAMIRANO'
,p_internal_uid=>68912082913578207
,p_updated_on=>wwv_flow_imp.dz('20250925160216Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(68912407855578213)
,p_db_column_name=>'COMPANIA'
,p_display_order=>1
,p_column_identifier=>'A'
,p_column_label=>unistr('Compa\00F1\00EDa')
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(68912820986578215)
,p_db_column_name=>'NUMEROVIATICO'
,p_display_order=>2
,p_column_identifier=>'B'
,p_column_label=>unistr('N\00FAmero Vi\00E1tico')
,p_column_type=>'NUMBER'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
,p_updated_on=>wwv_flow_imp.dz('20231005180643Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(68913241725578215)
,p_db_column_name=>'CODIGO'
,p_display_order=>3
,p_column_identifier=>'C'
,p_column_label=>unistr('C\00F3digo')
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
,p_updated_on=>wwv_flow_imp.dz('20231005180643Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(68913622449578215)
,p_db_column_name=>'NUMEROIDENTIFICACION'
,p_display_order=>4
,p_column_identifier=>'D'
,p_column_label=>unistr('Identificaci\00F3n')
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(68914054532578215)
,p_db_column_name=>'USUARIOCREA'
,p_display_order=>5
,p_column_identifier=>'E'
,p_column_label=>'Usuario Solicitante'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(68914405056578215)
,p_db_column_name=>'SOLICITANTE'
,p_display_order=>6
,p_column_identifier=>'F'
,p_column_label=>'Solicitante'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(68914864712578215)
,p_db_column_name=>'CENTROCOSTOS'
,p_display_order=>7
,p_column_identifier=>'G'
,p_column_label=>'Centro Costos'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(68915220344578215)
,p_db_column_name=>'UNIDADNEGOCIODES'
,p_display_order=>8
,p_column_identifier=>'H'
,p_column_label=>'Unidad Negocio'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(68915646488578215)
,p_db_column_name=>'TIPOVIATICO'
,p_display_order=>9
,p_column_identifier=>'I'
,p_column_label=>unistr('Tipo Vi\00E1tico')
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(68916073102578215)
,p_db_column_name=>'ESTADO'
,p_display_order=>10
,p_column_identifier=>'J'
,p_column_label=>'Estado'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(68916413071578216)
,p_db_column_name=>'ESTADOAPROBACION'
,p_display_order=>11
,p_column_identifier=>'K'
,p_column_label=>unistr('Estado Aprobaci\00F3n')
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(68916838778578216)
,p_db_column_name=>'USUARIOFLUJO'
,p_display_order=>12
,p_column_identifier=>'L'
,p_column_label=>unistr('Flujo de Aprobaci\00F3n')
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(68917225758578216)
,p_db_column_name=>'FECHASOLICITUD'
,p_display_order=>13
,p_column_identifier=>'M'
,p_column_label=>'Fecha Solicitud'
,p_column_type=>'DATE'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(68917628367578216)
,p_db_column_name=>'FECHAAPROBACION'
,p_display_order=>14
,p_column_identifier=>'N'
,p_column_label=>unistr('Fecha Aprobaci\00F3n')
,p_column_type=>'DATE'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(68918047070578216)
,p_db_column_name=>'FECHAINICIO'
,p_display_order=>15
,p_column_identifier=>'O'
,p_column_label=>'Fecha Inicio'
,p_column_type=>'DATE'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(68918411907578216)
,p_db_column_name=>'FECHAFIN'
,p_display_order=>16
,p_column_identifier=>'P'
,p_column_label=>'Fecha Fin'
,p_column_type=>'DATE'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(68918889497578216)
,p_db_column_name=>'FECHAPAGO'
,p_display_order=>17
,p_column_identifier=>'Q'
,p_column_label=>'Fecha Pago'
,p_column_type=>'DATE'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(68919255359578218)
,p_db_column_name=>'FECHALIQUIDACION'
,p_display_order=>18
,p_column_identifier=>'R'
,p_column_label=>unistr('Fecha Liquidaci\00F3n')
,p_column_type=>'DATE'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(68919619782578218)
,p_db_column_name=>'VALORACREDITADO'
,p_display_order=>19
,p_column_identifier=>'S'
,p_column_label=>'Valor Acreditado'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G990D00'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(68920034914578218)
,p_db_column_name=>'VALORLIQUIDADO'
,p_display_order=>20
,p_column_identifier=>'T'
,p_column_label=>'Valor Liquidado'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G990D00'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(68920432161578218)
,p_db_column_name=>'VALORPAGAR'
,p_display_order=>21
,p_column_identifier=>'U'
,p_column_label=>'Valor Pagar'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G990D00'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(68920856834578218)
,p_db_column_name=>'VALORDESCONTAR'
,p_display_order=>22
,p_column_identifier=>'V'
,p_column_label=>'Valor Descontar'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G990D00'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(85320516294939431)
,p_db_column_name=>'IDFLUJO'
,p_display_order=>32
,p_column_identifier=>'W'
,p_column_label=>'ID Flujo'
,p_column_type=>'NUMBER'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20231005175944Z')
,p_updated_on=>wwv_flow_imp.dz('20231005175944Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(85320645944939432)
,p_db_column_name=>'ETAPA'
,p_display_order=>42
,p_column_identifier=>'X'
,p_column_label=>'Etapa'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20231005175944Z')
,p_updated_on=>wwv_flow_imp.dz('20231005175944Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(85320760160939433)
,p_db_column_name=>'ESTADOETAPA'
,p_display_order=>52
,p_column_identifier=>'Y'
,p_column_label=>'Estado Etapa'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20231005175944Z')
,p_updated_on=>wwv_flow_imp.dz('20231005175944Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(85320818355939434)
,p_db_column_name=>'USUARIOETAPA'
,p_display_order=>62
,p_column_identifier=>'Z'
,p_column_label=>'Usuario Etapa'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20231005175944Z')
,p_updated_on=>wwv_flow_imp.dz('20231005175944Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(177215510863881401)
,p_db_column_name=>'DOCUMENTOS'
,p_display_order=>72
,p_column_identifier=>'AA'
,p_column_label=>'-'
,p_column_link=>'f?p=&APP_ID.:2017:&SESSION.::&DEBUG.::P2017_IDPROCESO,P2017_USUARIO,P2017_MODULO,P2017_COMPANIA:#NUMEROVIATICO#,&APP_USER.,#CODMODULO#,#COMPANIA#'
,p_column_linktext=>'#DOCUMENTOS#'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_column_alignment=>'CENTER'
,p_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_display_condition=>'APP_USER'
,p_display_condition2=>'DDELACRUZ'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20250915140132Z')
,p_updated_on=>wwv_flow_imp.dz('20250925154417Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(177216372496881409)
,p_db_column_name=>'CODMODULO'
,p_display_order=>82
,p_column_identifier=>'AB'
,p_column_label=>'Codmodulo'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_created_on=>wwv_flow_imp.dz('20250915143159Z')
,p_updated_on=>wwv_flow_imp.dz('20250915143159Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(191356411619627505)
,p_db_column_name=>'VERRUTA'
,p_display_order=>92
,p_column_identifier=>'AC'
,p_column_label=>'-'
,p_column_link=>'f?p=100:104:&SESSION.::&DEBUG.::G_OBJETO,G_OBJETO_ID,G_TODO:Viaticos,#NUMEROVIATICO#,TRUE'
,p_column_linktext=>'#VERRUTA#'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_column_alignment=>'CENTER'
,p_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_display_condition=>'APP_USER'
,p_display_condition2=>'DDELACRUZ'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20250925150009Z')
,p_updated_on=>wwv_flow_imp.dz('20250925151808Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(68924172451614716)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'689242'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_display_rows=>100
,p_report_columns=>'ETAPA:DOCUMENTOS:VERRUTA:NUMEROVIATICO:ESTADOAPROBACION:NUMEROIDENTIFICACION:SOLICITANTE:CENTROCOSTOS:UNIDADNEGOCIODES:USUARIOFLUJO:FECHASOLICITUD:FECHAAPROBACION:FECHAINICIO:FECHAFIN:FECHAPAGO:FECHALIQUIDACION:VALORACREDITADO:VALORLIQUIDADO:VALORPAG'
||'AR:VALORDESCONTAR:ESTADOETAPA:USUARIOETAPA:'
,p_sort_column_1=>'NUMEROVIATICO'
,p_sort_direction_1=>'DESC'
,p_sort_column_2=>'0'
,p_sort_direction_2=>'ASC'
,p_sort_column_3=>'0'
,p_sort_direction_3=>'ASC'
,p_sort_column_4=>'0'
,p_sort_direction_4=>'ASC'
,p_sort_column_5=>'0'
,p_sort_direction_5=>'ASC'
,p_sort_column_6=>'0'
,p_sort_direction_6=>'ASC'
,p_break_on=>'ETAPA:0:0:0:0:0'
,p_break_enabled_on=>'ETAPA:0:0:0:0:0'
,p_created_on=>wwv_flow_imp.dz('20230705164635Z')
,p_updated_on=>wwv_flow_imp.dz('20250925150218Z')
,p_created_by=>'CVACA'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_condition(
 p_id=>wwv_flow_imp.id(192653160977650076)
,p_report_id=>wwv_flow_imp.id(68924172451614716)
,p_name=>'ESTADO ETAPA'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'ESTADOETAPA'
,p_operator=>'='
,p_expr=>'EN_PROCESO'
,p_condition_sql=>' (case when ("ESTADOETAPA" = #APXWS_EXPR#) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# = ''EN_PROCESO''  '
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_row_bg_color=>'#a3f3f3'
,p_created_on=>wwv_flow_imp.dz('20250925150218Z')
,p_updated_on=>wwv_flow_imp.dz('20250925150218Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(250129611806278332)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(62294756474561034)
,p_button_name=>'REPARAR'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860056812106557)
,p_button_image_alt=>'Reparar'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:119:&SESSION.::&DEBUG.:RP,119::'
,p_icon_css_classes=>'fa-clipboard-wrench'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(62295175146561038)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(62294756474561034)
,p_button_name=>'BUSCAR'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860056812106557)
,p_button_image_alt=>'Buscar'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_icon_css_classes=>'fa-search'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(62294969898561036)
,p_name=>'P2007_FECHAINICIO'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(62294874141561035)
,p_prompt=>'Fecha inicio'
,p_source=>'trunc(add_months(sysdate,-1),''month'')'
,p_source_type=>'EXPRESSION'
,p_source_language=>'PLSQL'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
,p_updated_on=>wwv_flow_imp.dz('20231005181248Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(62295080204561037)
,p_name=>'P2007_FECHAFIN'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(62294874141561035)
,p_prompt=>'Fecha fin'
,p_source=>'select SYSDATE from dual'
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_imp.component_end;
end;
/
