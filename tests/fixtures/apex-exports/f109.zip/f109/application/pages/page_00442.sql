prompt --application/pages/page_00442
begin
--   Manifest
--     PAGE: 00442
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>109
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_page.create_page(
 p_id=>442
,p_name=>'PYG INDUSTRIALES - PAG - FUENTES DE DATOS (CRUD)'
,p_alias=>'PYG-INDUSTRIALES-CRUD-FUENTES-DE-DATOS'
,p_step_title=>'MANTENIMIENTO - FUENTES DE DATOS'
,p_autocomplete_on_off=>'OFF'
,p_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'function f_cargaItemsNolabel (p_item){',
'	(function () {',
'		function setCol($els, n){',
'			$els.each(function(){',
'				const el = this;',
'				const toRemove = [];',
'				el.classList.forEach(cls => {',
'					if (cls === "col" || cls.indexOf("col-") === 0) toRemove.push(cls);',
'				});',
'				toRemove.forEach(c => el.classList.remove(c));',
'				el.classList.add("col-" + n);',
'			});',
'		}',
'',
'		function apply(){',
'			const $c = $("#"+p_item);',
'			if (!$c.length) return;',
'			setCol($c.find(".t-Form-labelContainer"), 0);',
'			setCol($c.find(".t-Form-inputContainer"), 12);',
'		}',
'',
'		// inicial y tras eventos APEX comunes',
'		$(apply);',
'		$(document).on("apexafterrefresh apexafterclosedialog apexafterpagesubmit", apply);',
'	})();',
'',
'}',
'function f_setpopup(p_idform){',
'    switch(p_idform){',
'            case 0 : $(''#btnColumnas'').trigger("click");break;',
'            case 1 : $(''#btnCondiciones'').trigger("click");break;',
'            case 2 : $(''#btnParametros'').trigger("click");break;',
'            case 3 : $(''#btnValidaciones'').trigger("click");break;',
'            case 4 : $(''#btnMetodosDist'').trigger("click");break;',
'    }',
'}',
'$(document).ready(function () {',
'    $(".ui-dialog-titlebar-close").remove();',
'});'))
,p_javascript_code_onload=>wwv_flow_string.join(wwv_flow_t_varchar2(
' $(".ui-dialog-titlebar-close").remove();',
'$(secItems).hide();',
''))
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'#R98558614374460718_control_panel{',
'    display: none;',
'}',
'',
'#R98558614374460718_ir{',
'    width: 350px;',
'}',
''))
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'02'
,p_last_updated_on=>wwv_flow_imp.dz('20260227135733Z')
,p_last_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(99271786513732432)
,p_plug_name=>'Barra de Acciones'
,p_region_template_options=>'#DEFAULT#:t-Form--stretchInputs'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(38289497777120142)
,p_plug_display_sequence=>70
,p_plug_display_point=>'REGION_POSITION_01'
,p_location=>null
,p_menu_id=>wwv_flow_imp.id(37761271469106475)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(37860983999106559)
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(198405861270430201)
,p_plug_name=>'Items'
,p_region_name=>'secItems'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(38289867500120143)
,p_plug_display_sequence=>60
,p_location=>null
,p_ai_enabled=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(198500162580043547)
,p_plug_name=>'FORMULARIO'
,p_title=>unistr('Informaci\00F3n General')
,p_region_name=>'secFormulario'
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:js-useLocalStorage:is-expanded:t-Region--hiddenOverflow'
,p_plug_template=>wwv_flow_imp.id(37796755046106514)
,p_plug_display_sequence=>40
,p_query_type=>'TABLE'
,p_query_table=>'T_FINZ_DISTRIBUCIONCFG'
,p_include_rowid_column=>false
,p_is_editable=>true
,p_edit_operations=>'i:u:d'
,p_lost_update_check_type=>'VALUES'
,p_plug_source_type=>'NATIVE_FORM'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(199115271601701879)
,p_plug_name=>'ADICIONALES'
,p_region_name=>'secAdicionales'
,p_region_template_options=>'#DEFAULT#:js-useLocalStorage:t-TabsRegion-mod--fillLabels:t-TabsRegion-mod--pill:t-TabsRegion-mod--large'
,p_plug_template=>wwv_flow_imp.id(37814656137106525)
,p_plug_display_sequence=>50
,p_plug_item_display_point=>'BELOW'
,p_location=>null
,p_plug_display_condition_type=>'ITEM_NOT_NULL_OR_ZERO'
,p_plug_display_when_condition=>'P442_ID'
,p_ai_enabled=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(114519046207768744)
,p_name=>unistr('Metodos Distribuci\00F3n')
,p_title=>unistr('Metodos Distribuci\00F3n<button type=''button'' id=''btnRegMetodosDist'' onclick=''f_setpopup(4);'' class=''t-Button t-Button--noLabel t-Button--icon js-ignoreChange''><span class=''fa fa-ai-sparkle-generate-list fam-information fam-is-info''></span></button></lab')
||'el>'
,p_region_name=>'rgMetodosDist'
,p_parent_plug_id=>wwv_flow_imp.id(199115271601701879)
,p_template=>wwv_flow_imp.id(38289867500120143)
,p_display_sequence=>60
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_display_point=>'SUB_REGIONS'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'WITH mtd AS (',
'    SELECT',
'        m.id,',
'        m.idref referencia,',
'        ''V''||TRIM(to_char(m.version, ''00000'')) version,',
'        m.tipo,',
'        m.idref,',
'        m.idcfg,',
'        m.estado,',
'        m.criterio,',
'        b.descripcion,',
'        b.tablaproceso proceso,',
'        b.tablaproceso||''/''|| b.descripcion||''/''||TRIM(''V''||TRIM(to_char(m.version,''00000''))) retdescripcion,',
'        regexp_replace(regexp_replace(regexp_replace(pk_finz_distribucion.f_trae_dimensiones2varchar(b.compania, m.dimensiones),''(<br\s*/?>)+$'',''''),''\|\d+$'',''''),''((<br\s*/?>)|,)+$'','''') dimensiones',
'    FROM t_finz_distribucionmtd m',
'    INNER JOIN t_finz_distribucioncfg b ON m.idcfg = b.id AND tablaproceso = ''t_finz_distribucionasc''',
')--SELECT * FROM mtd;',
'SELECT',
'    a.id,',
'    a.retdescripcion AS descripcion,',
'    a.proceso,',
'    b.retdescripcion AS referencia,',
'    a.version,',
'    a.tipo,',
'    regexp_replace(regexp_replace(a.dimensiones,''\|\d+$'',''''),''((<br\s*/?>)|,)+$'','''') dimensiones,',
unistr('    CASE WHEN a.criterio IS NULL THEN ''NO'' ELSE ''S\00CD'' END  criterio,'),
'    a.estado',
'FROM mtd a LEFT JOIN mtd b ON a.idref = b.id;'))
,p_display_when_condition=>'P442_TABLAPROCESO'
,p_display_when_cond2=>'t_finz_distribucionasc'
,p_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_ajax_enabled=>'Y'
,p_ajax_items_to_submit=>'G_VALORCFG'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(37830327650106535)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
,p_updated_on=>wwv_flow_imp.dz('20260219133842Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(114519127711768745)
,p_query_column_id=>1
,p_column_alias=>'ID'
,p_column_display_sequence=>10
,p_column_heading=>'Id'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(125756253760082721)
,p_query_column_id=>2
,p_column_alias=>'DESCRIPCION'
,p_column_display_sequence=>120
,p_use_as_row_header=>'N'
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(125756361859082722)
,p_query_column_id=>3
,p_column_alias=>'PROCESO'
,p_column_display_sequence=>90
,p_use_as_row_header=>'N'
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(125756488404082723)
,p_query_column_id=>4
,p_column_alias=>'REFERENCIA'
,p_column_display_sequence=>100
,p_column_heading=>'Referencia'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(114519267836768746)
,p_query_column_id=>5
,p_column_alias=>'VERSION'
,p_column_display_sequence=>20
,p_column_heading=>'Version'
,p_use_as_row_header=>'N'
,p_column_format=>'999G999G999G999G990D00PR'
,p_column_link=>'f?p=&APP_ID.:444:&SESSION.::&DEBUG.:RR,444:G_VALORMTD:#ID#'
,p_column_linktext=>'#VERSION#'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_default_sort_column_sequence=>1
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(114519478180768748)
,p_query_column_id=>6
,p_column_alias=>'TIPO'
,p_column_display_sequence=>40
,p_column_heading=>'Tipo'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(114519596739768749)
,p_query_column_id=>7
,p_column_alias=>'DIMENSIONES'
,p_column_display_sequence=>50
,p_column_heading=>'Dimensiones'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(114519633572768750)
,p_query_column_id=>8
,p_column_alias=>'CRITERIO'
,p_column_display_sequence=>60
,p_column_heading=>'Tiene Criterio Dist?'
,p_use_as_row_header=>'N'
,p_column_alignment=>'CENTER'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(125756603014082725)
,p_query_column_id=>9
,p_column_alias=>'ESTADO'
,p_column_display_sequence=>110
,p_column_heading=>'Estado'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(739697853285226704)
,p_plug_name=>'Columnas'
,p_title=>'Columnas<button type=''button'' id=''btnRegColumnas'' onclick=''f_setpopup(0);'' class=''t-Button t-Button--noLabel t-Button--icon js-ignoreChange''><span class=''fa fa-pencil-square-o fam-information fam-is-info''></span></button></label>'
,p_region_name=>'rgColumnas'
,p_parent_plug_id=>wwv_flow_imp.id(199115271601701879)
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(38289867500120143)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
unistr('    SEQ_ID,  -- ID \00FAnico de la colecci\00F3n'),
'    C001, ',
'    C002, ',
'    C003, ',
'    CASE C004 ',
'    WHEN ''T'' then ''Texto''',
'    WHEN ''N'' then ''Numero''',
'    WHEN ''D'' then ''Decimal''',
'    WHEN ''M'' then ''Moneda''',
'    WHEN ''F'' then ''Fecha''',
'    end C004',
'FROM APEX_COLLECTIONS ',
'WHERE COLLECTION_NAME = ''COLECCION_COLUMNAS''',
' order by SEQ_ID'))
,p_plug_source_type=>'NATIVE_IR'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'Columnas'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(743005465874516592)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_fixed_header=>'NONE'
,p_lazy_loading=>true
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'EMASABANDA'
,p_internal_uid=>743005465874516592
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(743005578296516593)
,p_db_column_name=>'SEQ_ID'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Seq Id'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(754140012828251569)
,p_db_column_name=>'C001'
,p_display_order=>20
,p_column_identifier=>'D'
,p_column_label=>'Columna/Campo'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(754140109090251570)
,p_db_column_name=>'C002'
,p_display_order=>30
,p_column_identifier=>'E'
,p_column_label=>'Alias'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(781408637486184708)
,p_db_column_name=>'C004'
,p_display_order=>40
,p_column_identifier=>'G'
,p_column_label=>'Tipo Dato'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(781408530376184707)
,p_db_column_name=>'C003'
,p_display_order=>50
,p_column_identifier=>'F'
,p_column_label=>'Descripcion Columna'
,p_alternative_label=>'Visualizar'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(744364918857707617)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'5448195'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_display_rows=>100000
,p_report_columns=>'C001:C002:C004:C003'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(739704121894232222)
,p_plug_name=>'Condiciones'
,p_title=>'Condiciones<button type=''button'' id=''btnRegCondiciones'' onclick=''f_setpopup(1);'' class=''t-Button t-Button--noLabel t-Button--icon js-ignoreChange''><span class=''fa fa-pencil-square-o fam-information fam-is-info''></span></button></label>'
,p_region_name=>'rgCondicionesVis'
,p_parent_plug_id=>wwv_flow_imp.id(199115271601701879)
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(38289867500120143)
,p_plug_display_sequence=>50
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
unistr('    SEQ_ID,  -- ID \00FAnico de la colecci\00F3n'),
'    C001 ,',
'    C002 ,',
'    C003 ,',
'    C004     ',
'FROM APEX_COLLECTIONS ',
'WHERE COLLECTION_NAME = ''COLECCION_CONDICIONES'''))
,p_plug_source_type=>'NATIVE_IR'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'Condiciones'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(743012049962522113)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_show_search_bar=>'N'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_enable_mail_download=>'Y'
,p_owner=>'EMASABANDA'
,p_internal_uid=>743012049962522113
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(743012150403522114)
,p_db_column_name=>'SEQ_ID'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Seq Id'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(749206356157060182)
,p_db_column_name=>'C001'
,p_display_order=>20
,p_column_identifier=>'J'
,p_column_label=>unistr('Operador L\00F3gico')
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_column_alignment=>'CENTER'
,p_rpt_named_lov=>wwv_flow_imp.id(542425739667048154)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(749206434521060183)
,p_db_column_name=>'C002'
,p_display_order=>30
,p_column_identifier=>'K'
,p_column_label=>'Columna'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(749206594134060184)
,p_db_column_name=>'C003'
,p_display_order=>40
,p_column_identifier=>'L'
,p_column_label=>'Operador Relacional'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_rpt_named_lov=>wwv_flow_imp.id(542425179350034424)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(749206614480060185)
,p_db_column_name=>'C004'
,p_display_order=>50
,p_column_identifier=>'M'
,p_column_label=>'Valor'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(744384960078767196)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'5448334'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'C001:C002:C003:C004'
,p_sort_column_1=>'SEQ_ID'
,p_sort_direction_1=>'ASC'
,p_sort_column_2=>'0'
,p_sort_direction_2=>'ASC'
,p_sort_column_3=>'0'
,p_sort_direction_3=>'ASC'
,p_sort_column_4=>'0'
,p_sort_direction_4=>'ASC'
,p_sort_column_5=>'0'
,p_sort_direction_5=>'ASC'
,p_sort_column_6=>'0'
,p_sort_direction_6=>'ASC'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(744723327700899824)
,p_plug_name=>unistr('Par\00E1metros')
,p_title=>'Paramentros<button type=''button'' id=''btnRegParametros'' onclick=''f_setpopup(2);'' class=''t-Button t-Button--noLabel t-Button--icon js-ignoreChange''><span class=''fa fa-pencil-square-o fam-information fam-is-info''></span></button></label>'
,p_region_name=>'rgParametros'
,p_parent_plug_id=>wwv_flow_imp.id(199115271601701879)
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(38289867500120143)
,p_plug_display_sequence=>40
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
unistr('    SEQ_ID,  -- ID \00FAnico de la colecci\00F3n'),
'    C001,',
'    C002,',
'    C003',
'FROM APEX_COLLECTIONS ',
'WHERE COLLECTION_NAME = ''COLECCION_PARAMETROS'''))
,p_plug_source_type=>'NATIVE_IR'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'Parametros'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(744723354392899825)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_show_search_bar=>'N'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_enable_mail_download=>'Y'
,p_owner=>'EMASABANDA'
,p_internal_uid=>744723354392899825
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(744723492528899826)
,p_db_column_name=>'SEQ_ID'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Seq Id'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(744724330292899834)
,p_db_column_name=>'C001'
,p_display_order=>20
,p_column_identifier=>'I'
,p_column_label=>unistr('Nombre Par\00E1metro')
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(744724398453899835)
,p_db_column_name=>'C002'
,p_display_order=>30
,p_column_identifier=>'J'
,p_column_label=>'Valor 1'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(744724539839899836)
,p_db_column_name=>'C003'
,p_display_order=>40
,p_column_identifier=>'K'
,p_column_label=>'Valor 2'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(745145690616230679)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'5455966'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'C001:C002:C003:'
,p_sort_column_1=>'SEQ_ID'
,p_sort_direction_1=>'ASC'
,p_sort_column_2=>'0'
,p_sort_direction_2=>'ASC'
,p_sort_column_3=>'0'
,p_sort_direction_3=>'ASC'
,p_sort_column_4=>'0'
,p_sort_direction_4=>'ASC'
,p_sort_column_5=>'0'
,p_sort_direction_5=>'ASC'
,p_sort_column_6=>'0'
,p_sort_direction_6=>'ASC'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(99845836376969468)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(99271786513732432)
,p_button_name=>'Atras'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860056812106557)
,p_button_image_alt=>'Atras'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'LEFT'
,p_button_redirect_url=>'f?p=&APP_ID.:440:&SESSION.::&DEBUG.:RR,440::'
,p_icon_css_classes=>'fa-arrow-left'
,p_updated_on=>wwv_flow_imp.dz('20260227135733Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(114516725884768721)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(99271786513732432)
,p_button_name=>'Anterior'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860056812106557)
,p_button_image_alt=>'&P442_DESCANTERIOR.'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_show_processing=>'Y'
,p_button_condition=>'P442_ID'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_icon_css_classes=>'fa-step-backward'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(114516481114768718)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(99271786513732432)
,p_button_name=>'Siguiente'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860056812106557)
,p_button_image_alt=>'&P442_DESCSIGUIENTE.'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_show_processing=>'Y'
,p_button_condition=>'P442_ID'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_icon_css_classes=>'fa-step-forward'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(99847445723969469)
,p_button_sequence=>50
,p_button_plug_id=>wwv_flow_imp.id(99271786513732432)
,p_button_name=>'ADD'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860056812106557)
,p_button_image_alt=>'Agregar'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
,p_confirm_message=>unistr('Esta seguro que desea crear una nueva configuraci\00F3n?')
,p_confirm_style=>'warning'
,p_button_condition_type=>'NEVER'
,p_icon_css_classes=>'fa-plus'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(99846254524969468)
,p_button_sequence=>60
,p_button_plug_id=>wwv_flow_imp.id(99271786513732432)
,p_button_name=>'DELETE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860056812106557)
,p_button_image_alt=>'Delete'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_button_execute_validations=>'N'
,p_confirm_message=>'&APP_TEXT$DELETE_MSG!RAW.'
,p_confirm_style=>'danger'
,p_button_condition=>'P442_ID'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_icon_css_classes=>'fa-trash-o'
,p_database_action=>'DELETE'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(99846609720969469)
,p_button_sequence=>70
,p_button_plug_id=>wwv_flow_imp.id(99271786513732432)
,p_button_name=>'SAVE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860056812106557)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Apply Changes'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_button_condition=>'P442_ID'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_icon_css_classes=>'fa-save'
,p_database_action=>'UPDATE'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(99847031523969469)
,p_button_sequence=>80
,p_button_plug_id=>wwv_flow_imp.id(99271786513732432)
,p_button_name=>'CREATE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860056812106557)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Create'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_button_condition=>'P442_ID'
,p_button_condition_type=>'ITEM_IS_NULL'
,p_icon_css_classes=>'fa-save-as'
,p_database_action=>'INSERT'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(99848236486969470)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(198405861270430201)
,p_button_name=>'ADD_PARAMS'
,p_button_static_id=>'btnParametros'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860056812106557)
,p_button_image_alt=>'Agregar/Editar Parametros'
,p_button_redirect_url=>'f?p=&APP_ID.:186:&SESSION.::&DEBUG.:RR,186::'
,p_icon_css_classes=>'fa-pencil-square-o'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(99848680822969470)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(198405861270430201)
,p_button_name=>'ADD_CONDS'
,p_button_static_id=>'btnCondiciones'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860056812106557)
,p_button_image_alt=>'Agregar/Editar Condiciones'
,p_button_redirect_url=>'f?p=&APP_ID.:185:&SESSION.::&DEBUG.:RR,185::'
,p_icon_css_classes=>'fa-pencil-square-o'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(99849072991969471)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(198405861270430201)
,p_button_name=>'ADD_COLS'
,p_button_static_id=>'btnColumnas'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860056812106557)
,p_button_image_alt=>'Agregar/Editar Columnas'
,p_button_redirect_url=>'f?p=&APP_ID.:443:&SESSION.::&DEBUG.:RR,443:P443_TABLAPROCESO:&P442_TABLAPROCESO.'
,p_icon_css_classes=>'fa-pencil-square-o'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(118412069659294001)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(198405861270430201)
,p_button_name=>'ADD_METDIST'
,p_button_static_id=>'btnMetodosDist'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860181880106559)
,p_button_image_alt=>'Add Metdist'
,p_button_redirect_url=>'f?p=&APP_ID.:444:&SESSION.::&DEBUG.:RR,444:G_VALORMTD:'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(99884517249969520)
,p_branch_name=>'goto 441'
,p_branch_action=>'f?p=&APP_ID.:441:&SESSION.::&DEBUG.:RR,440::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_imp.id(99846254524969468)
,p_branch_sequence=>10
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(136717042996753420)
,p_branch_name=>'GOTO442'
,p_branch_action=>'f?p=&APP_ID.:442:&SESSION.::&DEBUG.:RR,442:P442_ID:&P442_IDANTERIOR.&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'BEFORE_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_imp.id(114516725884768721)
,p_branch_sequence=>10
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(136717195297753421)
,p_branch_name=>'GOTO442'
,p_branch_action=>'f?p=&APP_ID.:442:&SESSION.::&DEBUG.:RR,442:P442_ID:&P442_IDSIGUIENTE.&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'BEFORE_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_imp.id(114516481114768718)
,p_branch_sequence=>20
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(99272852309732443)
,p_name=>'P442_IDENTIFICADOR'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(198500162580043547)
,p_prompt=>'Identificador'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(99963592819702817)
,p_name=>'P442_ESQUEMA'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_imp.id(198500162580043547)
,p_item_source_plug_id=>wwv_flow_imp.id(198500162580043547)
,p_prompt=>'Esquema'
,p_source=>'ESQUEMA'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT DESCRIPCION,ID_TABLA ',
'FROM "DATA"."T_CORP_UDC" ',
'WHERE ID_CABECERA=''FINZ_GT04'' AND ID_TABLA!=''000''  AND ACTIVO=''1''  AND VALOR2=:P442_ERP',
'order by to_number(ID_TABLA);'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'Seleccione'
,p_lov_cascade_parent_items=>'P442_ERP'
,p_ajax_items_to_submit=>'P442_ERP'
,p_ajax_optimize_refresh=>'Y'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(114516522062768719)
,p_name=>'P442_IDANTERIOR'
,p_item_sequence=>180
,p_item_plug_id=>wwv_flow_imp.id(198405861270430201)
,p_prompt=>'Idanterior'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(114516662963768720)
,p_name=>'P442_IDSIGUIENTE'
,p_item_sequence=>200
,p_item_plug_id=>wwv_flow_imp.id(198405861270430201)
,p_prompt=>'Idsiguiente'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(118976225909025050)
,p_name=>'P442_LIMPIAGLOBALES'
,p_item_sequence=>220
,p_item_plug_id=>wwv_flow_imp.id(198405861270430201)
,p_prompt=>'Limpiaglobales'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(136716849985753418)
,p_name=>'P442_DESCANTERIOR'
,p_item_sequence=>190
,p_item_plug_id=>wwv_flow_imp.id(198405861270430201)
,p_prompt=>'Descanterior'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(136716970036753419)
,p_name=>'P442_DESCSIGUIENTE'
,p_item_sequence=>210
,p_item_plug_id=>wwv_flow_imp.id(198405861270430201)
,p_prompt=>'Descsiguiente'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(198410066177430209)
,p_name=>'P442_ERP_SEL'
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_imp.id(198405861270430201)
,p_prompt=>'Erp Sel'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(198410153079430210)
,p_name=>'P442_ESQUEMA_SEL'
,p_item_sequence=>120
,p_item_plug_id=>wwv_flow_imp.id(198405861270430201)
,p_prompt=>'Esquema Sel'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(198410426378430213)
,p_name=>'P442_CONEXION_SEL'
,p_item_sequence=>130
,p_item_plug_id=>wwv_flow_imp.id(198405861270430201)
,p_prompt=>'Conexion Sel'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(198417201090430227)
,p_name=>'P442_EMPTY'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(198500162580043547)
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(37859379436106556)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(198417441419430229)
,p_name=>'P442_TABLAPROCESO'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(198500162580043547)
,p_item_source_plug_id=>wwv_flow_imp.id(198500162580043547)
,p_prompt=>'Proceso'
,p_source=>'TABLAPROCESO'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'STATIC2:ASIENTOS CONTABLES;t_finz_distribucionasc,VENTAS;t_finz_distribucionvta'
,p_lov_display_null=>'YES'
,p_lov_null_text=>'Seleccione'
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--radioButtonGroup'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(198504670918043556)
,p_name=>'P442_ID'
,p_source_data_type=>'NUMBER'
,p_is_primary_key=>true
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(198405861270430201)
,p_item_source_plug_id=>wwv_flow_imp.id(198500162580043547)
,p_prompt=>'ID'
,p_source=>'ID'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(198505047094043561)
,p_name=>'P442_USERCREA'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(198405861270430201)
,p_item_source_plug_id=>wwv_flow_imp.id(198500162580043547)
,p_prompt=>'Usercrea'
,p_source=>'USERCREA'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>32
,p_cMaxlength=>25
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(198505381600043564)
,p_name=>'P442_FECHCREA'
,p_source_data_type=>'TIMESTAMP'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(198405861270430201)
,p_item_source_plug_id=>wwv_flow_imp.id(198500162580043547)
,p_prompt=>'Fechcrea'
,p_source=>'FECHCREA'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DATE_PICKER_APEX'
,p_cSize=>32
,p_cMaxlength=>255
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'POPUP'
,p_attribute_03=>'NONE'
,p_attribute_06=>'NONE'
,p_attribute_09=>'N'
,p_attribute_11=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(198506163254043576)
,p_name=>'P442_USERMODI'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(198405861270430201)
,p_item_source_plug_id=>wwv_flow_imp.id(198500162580043547)
,p_prompt=>'Usermodi'
,p_source=>'USERMODI'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>32
,p_cMaxlength=>25
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(198506569298043577)
,p_name=>'P442_FECHMODI'
,p_source_data_type=>'TIMESTAMP'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_imp.id(198405861270430201)
,p_item_source_plug_id=>wwv_flow_imp.id(198500162580043547)
,p_prompt=>'Fechmodi'
,p_source=>'FECHMODI'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DATE_PICKER_APEX'
,p_cSize=>32
,p_cMaxlength=>255
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'POPUP'
,p_attribute_03=>'NONE'
,p_attribute_06=>'NONE'
,p_attribute_09=>'N'
,p_attribute_11=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(198510120386043579)
,p_name=>'P442_COLUMNAS'
,p_data_type=>'CLOB'
,p_source_data_type=>'CLOB'
,p_item_sequence=>140
,p_item_plug_id=>wwv_flow_imp.id(198405861270430201)
,p_item_source_plug_id=>wwv_flow_imp.id(198500162580043547)
,p_prompt=>'Columnas'
,p_source=>'COLUMNAS'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>60
,p_cHeight=>4
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(198510592023043579)
,p_name=>'P442_CONDICIONES'
,p_data_type=>'CLOB'
,p_source_data_type=>'CLOB'
,p_item_sequence=>150
,p_item_plug_id=>wwv_flow_imp.id(198405861270430201)
,p_item_source_plug_id=>wwv_flow_imp.id(198500162580043547)
,p_prompt=>'Condiciones'
,p_source=>'CONDICIONES'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>60
,p_cHeight=>4
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(198510936326043579)
,p_name=>'P442_PARAMETROS'
,p_data_type=>'CLOB'
,p_source_data_type=>'CLOB'
,p_item_sequence=>160
,p_item_plug_id=>wwv_flow_imp.id(198405861270430201)
,p_item_source_plug_id=>wwv_flow_imp.id(198500162580043547)
,p_prompt=>'Parametros'
,p_source=>'PARAMETROS'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>60
,p_cHeight=>4
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(198511321552043579)
,p_name=>'P442_VALIDACIONES'
,p_data_type=>'CLOB'
,p_source_data_type=>'CLOB'
,p_item_sequence=>170
,p_item_plug_id=>wwv_flow_imp.id(198405861270430201)
,p_item_source_plug_id=>wwv_flow_imp.id(198500162580043547)
,p_prompt=>'Validaciones'
,p_source=>'VALIDACIONES'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>60
,p_cHeight=>4
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(198514465333043590)
,p_name=>'P442_DESCRIPCION'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(198500162580043547)
,p_item_source_plug_id=>wwv_flow_imp.id(198500162580043547)
,p_prompt=>'Descripcion'
,p_source=>'DESCRIPCION'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>60
,p_cMaxlength=>500
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(198514803690043591)
,p_name=>'P442_ESTADO'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(198500162580043547)
,p_item_source_plug_id=>wwv_flow_imp.id(198500162580043547)
,p_prompt=>'Estado'
,p_source=>'ESTADO'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_YES_NO'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'ACTIVO'
,p_attribute_03=>'Activo'
,p_attribute_04=>'INACTIVO'
,p_attribute_05=>'Inactivo'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(198515230840043591)
,p_name=>'P442_ERP'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(198500162580043547)
,p_item_source_plug_id=>wwv_flow_imp.id(198500162580043547)
,p_prompt=>'Erp'
,p_source=>'ERP'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'LOV_FINZ_GTERP'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT DESCRIPCION,ID_TABLA FROM "DATA"."T_CORP_UDC" ',
'WHERE ID_CABECERA=''FINZ_GT03'' AND ID_TABLA!=''000'' AND ACTIVO=''1''  order by to_number(ID_TABLA);',
''))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'Seleccione'
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(198516028722043591)
,p_name=>'P442_TIPOOBJETO'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(198500162580043547)
,p_item_source_plug_id=>wwv_flow_imp.id(198500162580043547)
,p_prompt=>'Tipoobjeto'
,p_source=>'TIPOOBJETO'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT DESCRIPCION,ID_TABLA  FROM "DATA"."T_CORP_UDC" ',
'WHERE ID_CABECERA=''FINZ_GT02'' AND ID_TABLA  in(''001'')  AND ACTIVO=''1''  ;'))
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(198516492698043591)
,p_name=>'P442_OBJETO'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_imp.id(198500162580043547)
,p_item_source_plug_id=>wwv_flow_imp.id(198500162580043547)
,p_prompt=>'Objeto'
,p_source=>'OBJETO'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SHUTTLE'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT * FROM ',
'(',
'    select DISTINCT upper(TABLE_NAME) d, upper(TABLE_NAME) r  from ALL_TABLES@jdedtadl WHERE OWNER=:P442_ESQUEMA_SEL AND :P442_ERP_SEL=''JDE'' UNION ALL',
'    select DISTINCT upper(VIEW_NAME ) d, upper(VIEW_NAME ) r  from ALL_VIEWS@jdedtadl  WHERE OWNER=:P442_ESQUEMA_SEL AND :P442_ERP_SEL=''JDE''UNION ALL',
'    select DISTINCT upper(TABLE_NAME) d, upper(TABLE_NAME) r  from ALL_TABLES          WHERE OWNER=:P442_ESQUEMA_SEL AND :P442_ERP_SEL=''APEX'' UNION ALL',
'    select DISTINCT upper(VIEW_NAME ) d, upper(VIEW_NAME ) r  from ALL_VIEWS           WHERE OWNER=:P442_ESQUEMA_SEL AND :P442_ERP_SEL=''APEX''',
')',
'ORDER BY 1'))
,p_lov_cascade_parent_items=>'P442_ESQUEMA_SEL'
,p_ajax_items_to_submit=>'P442_ESQUEMA_SEL,P442_ERP_SEL'
,p_ajax_optimize_refresh=>'Y'
,p_cHeight=>5
,p_display_when=>'P442_ID'
,p_display_when_type=>'ITEM_IS_NOT_NULL'
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'ALL'
,p_multi_value_type=>'SEPARATED'
,p_multi_value_separator=>':'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(198858638644135326)
,p_name=>'P442_COMPANIA'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(198500162580043547)
,p_item_source_plug_id=>wwv_flow_imp.id(198500162580043547)
,p_prompt=>'Compania'
,p_source=>'COMPANIA'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT DESCRIPCION, ID_TABLA ',
'FROM t_corp_udc ',
'where id_cabecera=''COMP_CGZCM'' ',
'and ID_TABLA!=''00000'' ',
'/*and ACTIVO=''1''*/',
'order by ID_TABLA;'))
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--stretchInputs:t-Form-fieldContainer--large:t-Form-fieldContainer--preTextBlock:t-Form-fieldContainer--postTextBlock:t-Form-fieldContainer--radioButtonGroup'
,p_is_persistent=>'N'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'Y'
,p_attribute_02=>'LOV'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(99880086523969517)
,p_validation_name=>'ProcesoNoVAcio'
,p_validation_sequence=>50
,p_validation=>'P442_TABLAPROCESO'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>'Se requiere un valor para #LABEL#.'
,p_associated_item=>wwv_flow_imp.id(198417441419430229)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(99272169833732436)
,p_validation_name=>'DescripcionNoVAcio'
,p_validation_sequence=>60
,p_validation=>'P442_DESCRIPCION'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>'Se requiere un valor para #LABEL#.'
,p_associated_item=>wwv_flow_imp.id(198514465333043590)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(99882686835969519)
,p_name=>'CAMBIO ESQUEMA'
,p_event_sequence=>10
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P442_ESQUEMA'
,p_condition_element=>'P442_ESQUEMA'
,p_triggering_condition_type=>'NOT_NULL'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(99963423127702816)
,p_event_id=>wwv_flow_imp.id(99882686835969519)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'console.log($v("P442_ESQUEMA"))'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(99883148466969519)
,p_event_id=>wwv_flow_imp.id(99882686835969519)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    pk_finz_distribucion.f_trae_valorudc(P_ID_CABECERA =>''FINZ_GT03'', p_id_tabla=>:P442_ERP,    p_cia =>NULL,P_tipo=>''DESCRIPCION'',p_VALOR  =>'''',p_ACTIVO=>''1'')ERP,',
'    pk_finz_distribucion.f_trae_valorudc(P_ID_CABECERA =>''FINZ_GT04'', p_id_tabla=>:P442_ESQUEMA,p_cia =>NULL,P_tipo=>''DESCRIPCION'',p_VALOR  =>'''',p_ACTIVO=>''1'')ESQUEMA,',
'    pk_finz_distribucion.f_trae_valorudc(P_ID_CABECERA =>''FINZ_GT04'', p_id_tabla=>:P442_ESQUEMA,p_cia =>NULL,P_tipo=>''VALOR'',p_VALOR  =>'''',p_ACTIVO=>''1'')CONEXION ',
'    INTO :P442_ERP_SEL,:P442_ESQUEMA_SEL,:P442_CONEXION_SEL',
'FROM DUAL;',
''))
,p_attribute_02=>'P442_ERP,P442_ESQUEMA'
,p_attribute_03=>'P442_ERP_SEL,P442_ESQUEMA_SEL,P442_CONEXION_SEL'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(99963276012702814)
,p_name=>'Cambio Objeto'
,p_event_sequence=>20
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P442_OBJETO'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(99963304261702815)
,p_event_id=>wwv_flow_imp.id(99963276012702814)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>':G_GT_OBJETOS:=:P442_OBJETO;'
,p_attribute_02=>'P442_OBJETO'
,p_attribute_03=>'G_GT_OBJETOS'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(99963659790702818)
,p_name=>'Cambia esquema'
,p_event_sequence=>30
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P442_ESQUEMA'
,p_condition_element=>'P442_ESQUEMA'
,p_triggering_condition_type=>'NOT_NULL'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(99963794640702819)
,p_event_id=>wwv_flow_imp.id(99963659790702818)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    pk_finz_distribucion.f_trae_valorudc(P_ID_CABECERA =>''FINZ_GT03'', p_id_tabla=>:P442_ERP,    P_tipo=>''DESCRIPCION'',p_VALOR  =>'''',p_ACTIVO=>''1'')ERP,',
'    pk_finz_distribucion.f_trae_valorudc(P_ID_CABECERA =>''FINZ_GT04'', p_id_tabla=>:P442_ESQUEMA,P_tipo=>''DESCRIPCION'',p_VALOR  =>'''',p_ACTIVO=>''1'')ESQUEMA,',
'    pk_finz_distribucion.f_trae_valorudc(P_ID_CABECERA =>''FINZ_GT04'', p_id_tabla=>:P442_ESQUEMA,P_tipo=>''VALOR'',p_VALOR  =>'''',p_ACTIVO=>''1'')CONEXION ',
'INTO :P442_ERP_SEL,:P442_ESQUEMA_SEL,:P442_CONEXION_SEL',
'FROM DUAL;'))
,p_attribute_02=>'P442_ERP,P442_ESQUEMA'
,p_attribute_03=>'P442_ERP_SEL,P442_ESQUEMA_SEL,P442_CONEXION_SEL'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(99963816324702820)
,p_event_id=>wwv_flow_imp.id(99963659790702818)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P442_OBJETO'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(99963928706702821)
,p_name=>'CerrarDlgColumnas'
,p_event_sequence=>40
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(99849072991969471)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(99964041327702822)
,p_event_id=>wwv_flow_imp.id(99963928706702821)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(739697853285226704)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(99964176303702823)
,p_event_id=>wwv_flow_imp.id(99963928706702821)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>':P442_COLUMNAS := :G_GT_COLUMNAS'
,p_attribute_02=>'G_GT_COLUMNAS'
,p_attribute_03=>'P442_COLUMNAS'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(118412171260294002)
,p_name=>'CerrarDlgMetodosDist'
,p_event_sequence=>50
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(118412069659294001)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosecanceldialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(118412284916294003)
,p_event_id=>wwv_flow_imp.id(118412171260294002)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(114519046207768744)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(99964387510702825)
,p_name=>'CerrarDlgParamentros'
,p_event_sequence=>60
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(99848236486969470)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(99964402154702826)
,p_event_id=>wwv_flow_imp.id(99964387510702825)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(744723327700899824)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(99964593584702827)
,p_event_id=>wwv_flow_imp.id(99964387510702825)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>':P442_PARAMETROS:= :G_GT_PARAMETROS;'
,p_attribute_02=>'G_GT_PARAMETROS'
,p_attribute_03=>'P442_PARAMETROS'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(99964661051702828)
,p_name=>'CerrarDlgCondiciones'
,p_event_sequence=>70
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(99848680822969470)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(99964714813702829)
,p_event_id=>wwv_flow_imp.id(99964661051702828)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(739704121894232222)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(99964855891702830)
,p_event_id=>wwv_flow_imp.id(99964661051702828)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>':P442_CONDICIONES:= :G_GT_CONDICIONES;'
,p_attribute_02=>'G_GT_CONDICIONES'
,p_attribute_03=>'P442_CONDICIONES'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(114516839037768722)
,p_name=>'BotonSiguiente'
,p_event_sequence=>80
,p_condition_element=>'P442_IDSIGUIENTE'
,p_triggering_condition_type=>'NOT_NULL'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'ready'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(114516943475768723)
,p_event_id=>wwv_flow_imp.id(114516839037768722)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_name=>'Enable'
,p_action=>'NATIVE_ENABLE'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(114516481114768718)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(114517014504768724)
,p_event_id=>wwv_flow_imp.id(114516839037768722)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_name=>'Disable'
,p_action=>'NATIVE_DISABLE'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(114516481114768718)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(114517133979768725)
,p_name=>'BotonAnterior'
,p_event_sequence=>90
,p_condition_element=>'P442_IDANTERIOR'
,p_triggering_condition_type=>'NOT_NULL'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'ready'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(114517223825768726)
,p_event_id=>wwv_flow_imp.id(114517133979768725)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_name=>'Enable'
,p_action=>'NATIVE_ENABLE'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(114516725884768721)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(114517332943768727)
,p_event_id=>wwv_flow_imp.id(114517133979768725)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_name=>'Disable '
,p_action=>'NATIVE_DISABLE'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(114516725884768721)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(118415475704294035)
,p_name=>'CerrarDlgMetodosDist_Grid'
,p_event_sequence=>100
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(114519046207768744)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosecanceldialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(118415568640294036)
,p_event_id=>wwv_flow_imp.id(118415475704294035)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(114519046207768744)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(128917411527329338)
,p_event_id=>wwv_flow_imp.id(118415475704294035)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
':G_CRITERIOSDIST:=NULL;',
':G_DIMENSIONDIST:=NULL;'))
,p_attribute_03=>'G_DIMENSIONDIST,G_CRITERIOSDIST'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(118976664140029325)
,p_name=>'limpiar Globales'
,p_event_sequence=>110
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P442_LIMPIAGLOBALES'
,p_condition_element=>'P442_LIMPIAGLOBALES'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'1'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(136716579361753415)
,p_name=>'CambiaTablaProceso'
,p_event_sequence=>120
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P442_TABLAPROCESO'
,p_condition_element=>'P442_TABLAPROCESO'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'t_finz_distribucionasc'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
,p_display_when_type=>'NEVER'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(136716643846753416)
,p_event_id=>wwv_flow_imp.id(136716579361753415)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(114519046207768744)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(136716791956753417)
,p_event_id=>wwv_flow_imp.id(136716579361753415)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(114519046207768744)
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(99864044500969496)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_region_id=>wwv_flow_imp.id(198500162580043547)
,p_process_type=>'NATIVE_FORM_DML'
,p_process_name=>'Process form PYG INDUSTRIALES - FUENTES DE DATOS'
,p_attribute_01=>'REGION_SOURCE'
,p_attribute_05=>'Y'
,p_attribute_06=>'Y'
,p_attribute_08=>'Y'
,p_process_error_message=>unistr('Ocurri\00F3 un error al procesar la informaci\00F3n.')
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_success_message=>'Los datos se han actualizado correctamente.'
,p_internal_uid=>99864044500969496
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(99272770020732442)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'SetupIniPage'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
':G_GT_COLUMNAS:=null;',
':G_GT_CONDICIONES:=null;',
':G_GT_PARAMETROS:=null;',
':G_GT_OBJETOS:=null;',
':G_GT_VALIDACIONES:=null;',
':G_VARIABLE:=null;',
'',
'IF APEX_COLLECTION.COLLECTION_EXISTS(''COLECCION_COLUMNAS'') THEN',
'    APEX_COLLECTION.DELETE_COLLECTION(''COLECCION_COLUMNAS'');',
'END IF;',
'IF APEX_COLLECTION.COLLECTION_EXISTS(''COLECCION_CONDICIONES'') THEN',
'    APEX_COLLECTION.DELETE_COLLECTION(''COLECCION_CONDICIONES'');',
'END IF;',
'IF APEX_COLLECTION.COLLECTION_EXISTS(''COLECCION_PARAMETROS'') THEN',
'    APEX_COLLECTION.DELETE_COLLECTION(''COLECCION_PARAMETROS'');',
'END IF;',
'IF APEX_COLLECTION.COLLECTION_EXISTS(''COLECCION_VALIDACIONES'') THEN',
'    APEX_COLLECTION.DELETE_COLLECTION(''COLECCION_VALIDACIONES'');',
'END IF;',
'IF APEX_COLLECTION.COLLECTION_EXISTS(''COLECCION_CRITERIOSDIST'') THEN',
'    APEX_COLLECTION.DELETE_COLLECTION(''COLECCION_CRITERIOSDIST'');',
'END IF;',
'',
'if (:P442_id is null)then ',
'    :P442_ESTADO:=0;',
'    :P442_ERP_SEL:=null;',
'    :P442_ESQUEMA_SEL:=null;',
'    :P442_CONEXION_SEL:=null;',
'end if;',
':P442_IDENTIFICADOR:=''CFG''||TRIM(to_char(nvl(:P442_ID,''0''),''0000000''));',
''))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>99272770020732442
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(99863607791969496)
,p_process_sequence=>20
,p_process_point=>'BEFORE_HEADER'
,p_region_id=>wwv_flow_imp.id(198500162580043547)
,p_process_type=>'NATIVE_FORM_INIT'
,p_process_name=>'Initialize form PYG INDUSTRIALES - FUENTES DE DATOS'
,p_internal_uid=>99863607791969496
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(99962977809702811)
,p_process_sequence=>30
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'SetupProcess'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'',
'    :G_VALORCFG:=:P442_ID;/*seteo el id en variable global para los posteriiores procesos anidados a esta configuracion*/',
'',
'    :P442_COMPANIA:=nvl(:P442_COMPANIA,:G_COMPANIADIST);',
'    if (:P442_ERP is not null and :P442_ESQUEMA is not null )then',
'        SELECT ',
'            pk_finz_distribucion.f_trae_valorudc(P_ID_CABECERA =>''FINZ_GT03'', p_id_tabla=>:P442_ERP    ,P_tipo=>''DESCRIPCION'',p_VALOR  =>'''',p_ACTIVO=>''1'')ERP,',
'            pk_finz_distribucion.f_trae_valorudc(P_ID_CABECERA =>''FINZ_GT04'', p_id_tabla=>:P442_ESQUEMA,P_tipo=>''DESCRIPCION'',p_VALOR  =>'''',p_ACTIVO=>''1'')ESQUEMA,',
'            pk_finz_distribucion.f_trae_valorudc(P_ID_CABECERA =>''FINZ_GT04'', p_id_tabla=>:P442_ESQUEMA,P_tipo=>''VALOR''      ,p_VALOR  =>'''',p_ACTIVO=>''1'')CONEXION ',
'        INTO :P442_ERP_SEL,:P442_ESQUEMA_SEL,:P442_CONEXION_SEL',
'        FROM DUAL;',
'    end if;',
'    DBMS_OUTPUT.PUT_LINE(''P442_ERP_SEL:''||:P442_ERP_SEL);',
'    DBMS_OUTPUT.PUT_LINE(''P442_ESQUEMA_SEL:''||:P442_ESQUEMA_SEL);',
'    DBMS_OUTPUT.PUT_LINE(''P442_CONEXION_SEL:''||:P442_CONEXION_SEL);',
'end;',
'',
'DECLARE ',
'    V_CONTADOR NUMBER;',
'    v_json_array   JSON_ARRAY_T;',
'    v_nuevo_objeto JSON_OBJECT_T;',
'    v_clob clob;',
'BEGIN',
'    IF NOT APEX_COLLECTION.COLLECTION_EXISTS(''COLECCION_COLUMNAS'') THEN',
'     APEX_COLLECTION.CREATE_COLLECTION(''COLECCION_COLUMNAS'');',
'    END IF;',
'    IF NOT APEX_COLLECTION.COLLECTION_EXISTS(''COLECCION_CONDICIONES'') THEN',
'     APEX_COLLECTION.CREATE_COLLECTION(''COLECCION_CONDICIONES'');',
'    END IF;',
'    IF NOT APEX_COLLECTION.COLLECTION_EXISTS(''COLECCION_PARAMETROS'') THEN',
'     APEX_COLLECTION.CREATE_COLLECTION(''COLECCION_PARAMETROS'');',
'    END IF;',
'    IF NOT APEX_COLLECTION.COLLECTION_EXISTS(''COLECCION_VALIDACIONES'') THEN',
'     APEX_COLLECTION.CREATE_COLLECTION(''COLECCION_VALIDACIONES'');',
'    END IF;',
'    IF NOT APEX_COLLECTION.COLLECTION_EXISTS(''COLECCION_CRITERIOSDIST'') THEN',
'     APEX_COLLECTION.CREATE_COLLECTION(''COLECCION_CRITERIOSDIST'');',
'    END IF;',
'',
'    IF APEX_COLLECTION.COLLECTION_EXISTS(''COLECCION_COLUMNAS'') THEN',
'     APEX_COLLECTION.TRUNCATE_COLLECTION(''COLECCION_COLUMNAS'');',
'    END IF;',
'    IF APEX_COLLECTION.COLLECTION_EXISTS(''COLECCION_CONDICIONES'') THEN',
'     APEX_COLLECTION.TRUNCATE_COLLECTION(''COLECCION_CONDICIONES'');',
'    END IF;',
'    IF APEX_COLLECTION.COLLECTION_EXISTS(''COLECCION_PARAMETROS'') THEN',
'     APEX_COLLECTION.TRUNCATE_COLLECTION(''COLECCION_PARAMETROS'');',
'    END IF;',
'    IF APEX_COLLECTION.COLLECTION_EXISTS(''COLECCION_VALIDACIONES'') THEN',
'     APEX_COLLECTION.TRUNCATE_COLLECTION(''COLECCION_VALIDACIONES'');',
'    END IF;',
'    IF APEX_COLLECTION.COLLECTION_EXISTS(''COLECCION_CRITERIOSDIST'') THEN',
'     APEX_COLLECTION.TRUNCATE_COLLECTION(''COLECCION_CRITERIOSDIST'');',
'    END IF;',
'',
'',
'    :G_GT_OBJETOS:=:P442_OBJETO;',
'    :G_GT_COLUMNAS:=:P442_COLUMNAS;',
'    :G_GT_CONDICIONES:=:P442_CONDICIONES;',
'    :G_GT_PARAMETROS:=:P442_PARAMETROS;',
'    :G_GT_VALIDACIONES:=:P442_VALIDACIONES;',
'    v_clob :=:P442_COLUMNAS;',
'    :P442_COLUMNAS:=v_clob;',
'    ',
'    ',
'    begin--columnas',
'        IF(:G_GT_COLUMNAS IS NOT NULL)THEN',
'            FOR COLS IN ( ',
'                SELECT COLUMNA,ALIAS,TIPO_DATO,COMENTARIO_COLUMNA',
'                FROM JSON_TABLE(',
'                    :G_GT_COLUMNAS, -- tu variable o columna con el JSON',
'                    ''$[*]'' -- indica que es un arreglo',
'                    COLUMNS (',
'                        ID   VARCHAR2(3999) PATH ''$.ID'',',
'                        COLUMNA   VARCHAR2(3999) PATH ''$.COLUMNA'',',
'                        ALIAS     VARCHAR2(3999) PATH ''$.ALIAS'',',
'                        TIPO_DATO  VARCHAR2(100)  PATH ''$.TIPO_DATO'',',
'                        COMENTARIO_COLUMNA VARCHAR2(3999)   PATH ''$.COMENTARIO_COLUMNA''',
'                    )',
'                )',
'            )',
'            LOOP',
'                APEX_COLLECTION.ADD_MEMBER(',
'                    p_collection_name =>''COLECCION_COLUMNAS'',',
'                    p_c001 => COLS.COLUMNA,',
'                    p_c002 => COLS.alias,',
'                    p_c003 => COLS.COMENTARIO_COLUMNA,',
'                    p_c004 => COLS.TIPO_DATO',
'                );',
'            END LOOP;',
'        END IF;',
'    end;--fin columnas',
'    begin--parametros',
'',
'        SELECT COUNT(distinct 1)  into V_CONTADOR ',
'        FROM JSON_TABLE(:G_GT_PARAMETROS,''$[*]'' COLUMNS (PARAMETRO VARCHAR2(3999) PATH ''$.PARAMETRO'')) ',
'        where PARAMETRO=''PERIODO'';',
'        IF (V_CONTADOR=0)THEN ',
'            if(:G_GT_PARAMETROS is null)then',
'                :G_GT_PARAMETROS   :=''[{"ID":1,"PARAMETRO":"PERIODO","VALOR1":"PERIODO","VALOR2":"PERIODO"}]''; ',
'                :P442_PARAMETROS:=:G_GT_PARAMETROS;',
'             else',
'               SELECT JSON_ARRAYAGG(JSON_OBJECT(*) RETURNING CLOB)  INTO :G_GT_PARAMETROS',
'               FROM (               ',
'                   select 1 ID,''PERIODO''PARAMETRO,''PERIODO''VALOR1,''PERIODO''VALOR2 FROM DUAL UNION ALL',
'                   SELECT ROWNUM+1 ID,PARAMETRO  ,VALOR1  ,VALOR2  ',
'                   FROM JSON_TABLE(:G_GT_PARAMETROS,''$[*]''COLUMNS (PARAMETRO VARCHAR2(3999) PATH ''$.PARAMETRO'',VALOR1  VARCHAR2(399) PATH ''$.VALOR1'',VALOR2 VARCHAR2(399) PATH ''$.VALOR2'') )',
'               );',
'               :P442_PARAMETROS:=:G_GT_PARAMETROS;',
'            end if;',
'            begin',
'                update t_finz_distribucioncfg set PARAMETROS=:P442_PARAMETROS where id = :G_VALORCFG;',
'                commit;',
'            end;',
'        END IF;        ',
'',
'        IF(:G_GT_PARAMETROS IS NOT NULL)THEN',
'            FOR COLS IN (',
'             SELECT PARAMETRO,VALOR1,VALOR2',
'                FROM JSON_TABLE(',
'                    :G_GT_PARAMETROS, -- tu variable o columna con el JSON',
'                    ''$[*]'' -- indica que es un arreglo',
'                    COLUMNS (',
'                        PARAMETRO VARCHAR2(3999) PATH ''$.PARAMETRO'',',
'                        VALOR1    VARCHAR2(3999) PATH ''$.VALOR1'',',
'                        VALOR2    VARCHAR2(3999) PATH ''$.VALOR2''',
'                    )',
'                )',
'            )LOOP',
'                APEX_COLLECTION.ADD_MEMBER(',
'                    p_collection_name => ''COLECCION_PARAMETROS'',',
'                    p_c001 => COLS.PARAMETRO,',
'                    p_c002 => COLS.VALOR1,',
'                    p_c003 => COLS.VALOR2',
'                );',
'            END LOOP;',
'        END IF;',
'null;',
'    end;--fin parametros',
'',
'    begin--condiciones',
'        IF (:P442_TIPOOBJETO=''001'')then',
'            IF(:G_GT_CONDICIONES IS NOT NULL)THEN',
'                    FOR COLS IN (',
'                    SELECT OLOGICO CAMPO1,COLUMNA CAMPO2,ORELACIONAL CAMPO3,VALOR CAMPO4',
'                    FROM JSON_TABLE(',
'                        :G_GT_CONDICIONES, -- tu variable o columna con el JSON',
'                        ''$[*]'' -- indica que es un arreglo',
'                        COLUMNS (',
'                            OLOGICO   VARCHAR2(3999) PATH ''$.OLOGICO'',',
'                            COLUMNA     VARCHAR2(399) PATH ''$.COLUMNA'',',
'                            ORELACIONAL   VARCHAR2(399)   PATH ''$.ORELACIONAL'',',
'                            VALOR  VARCHAR2(399)  PATH ''$.VALOR''',
'                        )',
'                    )',
'                )',
'                LOOP',
'                    APEX_COLLECTION.ADD_MEMBER(',
'                        p_collection_name => ''COLECCION_CONDICIONES'',',
'                        p_c001 => COLS.CAMPO1,',
'                        p_c002 => COLS.CAMPO2,',
'                        p_c003 => COLS.CAMPO3,',
'                        p_c004 => COLS.CAMPO4',
'                    );',
'                END LOOP;',
'            END IF;',
'        END IF;',
'        IF (:P442_TIPOOBJETO>=''900'')then',
'            IF(:G_GT_CONDICIONES IS NOT NULL)THEN',
'                    FOR COLS IN (',
'                    SELECT OLOGICO CAMPO1,CONFIGURACION_A CAMPO2,CAMPO_A CAMPO3,ORELACIONAL CAMPO4,CONFIGURACION_B CAMPO5,CAMPO_B CAMPO6 ',
'                    FROM JSON_TABLE(',
'                        :G_GT_CONDICIONES, -- tu variable o columna con el JSON',
'                        ''$[*]'' -- indica que es un arreglo',
'                        COLUMNS (',
'                            OLOGICO   VARCHAR2(3999) PATH ''$.OLOGICO'',',
'                            CONFIGURACION_A     VARCHAR2(399) PATH ''$.CONFIGURACION_A'',',
'                            CAMPO_A   VARCHAR2(399)   PATH ''$.CAMPO_A'',',
'                            ORELACIONAL  VARCHAR2(399)  PATH ''$.ORELACIONAL'',',
'                            CONFIGURACION_B  VARCHAR2(100)  PATH ''$.CONFIGURACION_B'',',
'                            CAMPO_B  VARCHAR2(100)  PATH ''$.CAMPO_B''',
'                        )',
'                    )',
'                )',
'                LOOP',
'                    APEX_COLLECTION.ADD_MEMBER(',
'                        p_collection_name => ''COLECCION_CONDICIONES'',',
'                        p_c001 => COLS.CAMPO1,',
'                        p_c002 => COLS.CAMPO2,',
'                        p_c003 => COLS.CAMPO3,',
'                        p_c004 => COLS.CAMPO4,',
'                        p_c005 => COLS.CAMPO5,',
'                        p_c006 => COLS.CAMPO6',
'                    );',
'                END LOOP;',
'            END IF;',
'        END IF;',
'    end;--fin condiciones',
'    begin--validaciones',
'        IF (:P442_TIPOOBJETO=''001'')then',
'            IF(:G_GT_VALIDACIONES IS NOT NULL)THEN',
'                FOR COLS IN (',
'                    SELECT OLOGICO CAMPO1,COLUMNA CAMPO2,ORELACIONAL CAMPO3,VALOR CAMPO4,MSJ_ERROR CAMPO5,MSJ_ADVERTECNIA CAMPO6',
'                    FROM JSON_TABLE(',
'                        :G_GT_VALIDACIONES, -- tu variable o columna con el JSON',
'                        ''$[*]'' -- indica que es un arreglo',
'                        COLUMNS (',
'                            OLOGICO   VARCHAR2(3999) PATH ''$.OLOGICO'',',
'                            COLUMNA     VARCHAR2(399) PATH ''$.COLUMNA'',',
'                            ORELACIONAL   VARCHAR2(399)   PATH ''$.ORELACIONAL'',',
'                            VALOR  VARCHAR2(399)  PATH ''$.VALOR'',',
'                            MSJ_ERROR  VARCHAR2(100)  PATH ''$.MSJ_ERROR'',',
'                            MSJ_ADVERTECNIA  VARCHAR2(100)  PATH ''$.MSJ_ADVERTECNIA''',
'                        )',
'                    )',
'                )LOOP',
'                    APEX_COLLECTION.ADD_MEMBER(',
'                        p_collection_name => ''COLECCION_VALIDACIONES'',',
'                        p_c001 => COLS.CAMPO1,',
'                        p_c002 => COLS.CAMPO2,',
'                        p_c003 => COLS.CAMPO3,',
'                        p_c004 => COLS.CAMPO4,',
'                        p_c005 => COLS.CAMPO5,',
'                        p_c006 => COLS.CAMPO6',
'                    );',
'                END LOOP;',
'            END IF;',
'        END IF;',
'        IF (:P442_TIPOOBJETO>=''900'')then',
'            IF(:G_GT_VALIDACIONES IS NOT NULL)THEN',
'                FOR COLS IN (',
'                        SELECT OLOGICO CAMPO1,CONFIGURACION_A CAMPO2,CAMPO_A CAMPO3,ORELACIONAL CAMPO4,CONFIGURACION_B CAMPO5,CAMPO_B CAMPO6,MSJ_ERROR CAMPO7,MSJ_ADVERTECNIA CAMPO8',
'                        FROM JSON_TABLE(',
'                            :G_GT_VALIDACIONES, -- tu variable o columna con el JSON',
'                            ''$[*]'' -- indica que es un arreglo',
'                            COLUMNS (',
'                                OLOGICO   VARCHAR2(3999) PATH ''$.OLOGICO'',',
'                                CONFIGURACION_A     VARCHAR2(399) PATH ''$.CONFIGURACION_A'',',
'                                CAMPO_A   VARCHAR2(399)   PATH ''$.CAMPO_A'',',
'                                ORELACIONAL  VARCHAR2(399)  PATH ''$.ORELACIONAL'',',
'                                CONFIGURACION_B  VARCHAR2(100)  PATH ''$.CONFIGURACION_B'',',
'                                CAMPO_B  VARCHAR2(100)  PATH ''$.CAMPO_B'',',
'                                MSJ_ERROR  VARCHAR2(100)  PATH ''$.MSJ_ERROR'',',
'                                MSJ_ADVERTECNIA  VARCHAR2(100)  PATH ''$.MSJ_ADVERTECNIA''',
'                            )',
'                        )',
'                )LOOP',
'                    APEX_COLLECTION.ADD_MEMBER(',
'                        p_collection_name => ''COLECCION_VALIDACIONES'',',
'                        p_c001 => COLS.CAMPO1,',
'                        p_c002 => COLS.CAMPO2,',
'                        p_c003 => COLS.CAMPO3,',
'                        p_c004 => COLS.CAMPO4,',
'                        p_c005 => COLS.CAMPO5,',
'                        p_c006 => COLS.CAMPO6,',
'                        p_c007 => COLS.CAMPO7,',
'                        p_c008 => COLS.CAMPO8',
'                    );',
'                END LOOP;',
'            END IF;',
'        END IF;',
'',
'    end;--fin validaciones',
'   ',
' END;',
'',
'declare ',
'v_ant number:=0;',
'v_act number:=0;',
'v_sig number:=0;',
'begin',
'    IF (:G_VALORCFG IS NOT NULL)THEN',
'        EXECUTE IMMEDIATE ''DELETE FROM T_TMP_B'';',
'        INSERT INTO T_TMP_B(NUM01,NUM02,TXT01,TXT02)',
'            SELECT ROW_NUMBER() OVER ( ORDER BY compania,DESCRIPCION,TABLAPROCESO desc) rn, cfg.ID, cfg.TABLAPROCESO ,DESCRIPCION',
'            FROM T_FINZ_DISTRIBUCIONCFG cfg where compania=:G_COMPANIADIST ORDER BY ID,DESCRIPCION;',
'        SELECT NUM01 into v_act FROM T_TMP_B where NUM02 =:G_VALORCFG;        ',
'        v_ant:=v_act-1; v_sig:=v_act+1;',
'        DBMS_OUTPUT.PUT_LINE(''v_ant:''||v_ant);',
'        DBMS_OUTPUT.PUT_LINE(''v_act:''||v_act);',
'        DBMS_OUTPUT.PUT_LINE(''v_sig:''||v_sig);',
'        begin  SELECT NUM02 ID into :P442_IDANTERIOR  FROM T_TMP_B where NUM01 =v_ant;EXCEPTION when OTHERS THEN :P442_IDANTERIOR:=null; end;',
'        begin  SELECT NUM02 ID into :P442_IDSIGUIENTE FROM T_TMP_B where NUM01 =v_sig;EXCEPTION when OTHERS THEN :P442_IDSIGUIENTE:=null; end;',
'',
'        begin  SELECT TXT02 DESCRIPCION into :P442_DESCANTERIOR  FROM T_TMP_B where NUM01 =v_ant;EXCEPTION when OTHERS THEN :P442_DESCANTERIOR:=null; end;',
'        begin  SELECT TXT02 DESCRIPCION into :P442_DESCSIGUIENTE FROM T_TMP_B where NUM01 =v_sig;EXCEPTION when OTHERS THEN :P442_DESCSIGUIENTE:=null; end;',
'',
'        DBMS_OUTPUT.PUT_LINE(''P442_IDANTERIOR:''||:P442_IDANTERIOR);',
'        DBMS_OUTPUT.PUT_LINE(''P442_DESCANTERIOR:''||:P442_DESCANTERIOR);',
'        DBMS_OUTPUT.PUT_LINE(''G_VALORCFG:''||:G_VALORCFG);',
'        DBMS_OUTPUT.PUT_LINE(''P442_IDSIGUIENTE:''||:P442_IDSIGUIENTE);',
'        DBMS_OUTPUT.PUT_LINE(''P442_DESCSIGUIENTE:''||:P442_DESCSIGUIENTE);',
'    END IF;',
'end;',
''))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>99962977809702811
);
wwv_flow_imp.component_end;
end;
/
