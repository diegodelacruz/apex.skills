prompt --application/pages/page_02013
begin
--   Manifest
--     PAGE: 02013
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>109
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_page.create_page(
 p_id=>2013
,p_name=>'Archivos COMEX'
,p_step_title=>'Archivos COMEX'
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'OFF'
,p_javascript_code_onload=>'$(regOcultos).hide();'
,p_page_template_options=>'#DEFAULT#'
,p_page_component_map=>'18'
,p_created_on=>wwv_flow_imp.dz('20230705164635Z')
,p_last_updated_on=>wwv_flow_imp.dz('20260721210542Z')
,p_last_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(579344049736064511)
,p_plug_name=>'Archivos'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(37806762584106520)
,p_plug_display_sequence=>30
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select numeroarchivo',
'	, dbms_lob.getlength(blobcontent) blobcontent',
'	, filename',
'	, observacion',
'	, tipo',
'	, ''<span class="fa fa-eye" title="Previsualizar" aria-hidden="true" style="color: #800080;"></span>'' ver',
'	, pk_commons.f_googledocview(numeroarchivo,mimetype) enlacearchivo',
'from files.t_apex_archivos',
'where 1 = 1',
'	and (',
'		(tabla = ''T_CMEX_MESATRABAJO'' and id_tabla = :p2013_id_tabla) or ',
'		(tabla = ''T_CMEX_MUESTRAS'' and id_tabla = :p2013_id_muestra))',
'	and tipo = tipo',
'	-- and nvl(estado,1) = 1',
'order by tipo,numeroarchivo'))
,p_plug_source_type=>'NATIVE_IR'
,p_ajax_items_to_submit=>'P2013_ID_TABLA,P2013_ID_MUESTRA'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'Archivos'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
,p_created_on=>wwv_flow_imp.dz('20250125033713Z')
,p_updated_on=>wwv_flow_imp.dz('20260721210542Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(579344751159064518)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_show_search_bar=>'N'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_enable_mail_download=>'Y'
,p_owner=>'DDELACRUZ'
,p_internal_uid=>579344751159064518
,p_created_on=>wwv_flow_imp.dz('20250125033713Z')
,p_updated_on=>wwv_flow_imp.dz('20260721210542Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(579344865958064519)
,p_db_column_name=>'NUMEROARCHIVO'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Numeroarchivo'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20250125033713Z')
,p_updated_on=>wwv_flow_imp.dz('20250125203047Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(579344982847064520)
,p_db_column_name=>'BLOBCONTENT'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Archivo'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'NUMBER'
,p_format_mask=>'DOWNLOAD:T_APEX_ARCHIVOS:BLOBCONTENT:NUMEROARCHIVO::MIMETYPE:FILENAME:FECHA::attachment:#FILENAME#:FILES'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20250125033713Z')
,p_updated_on=>wwv_flow_imp.dz('20250125203047Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(579345078094064521)
,p_db_column_name=>'FILENAME'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Filename'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20250125033713Z')
,p_updated_on=>wwv_flow_imp.dz('20250125203047Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(579345177954064522)
,p_db_column_name=>'OBSERVACION'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>unistr('Observaci\00F3n')
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20250125033713Z')
,p_updated_on=>wwv_flow_imp.dz('20250125203047Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(579345201262064523)
,p_db_column_name=>'TIPO'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Tipo'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_rpt_named_lov=>wwv_flow_imp.id(579798104154684694)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20250125033713Z')
,p_updated_on=>wwv_flow_imp.dz('20250126033349Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(579345320289064524)
,p_db_column_name=>'VER'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'-'
,p_column_link=>'#ENLACEARCHIVO#'
,p_column_linktext=>'#VER#'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20250125033713Z')
,p_updated_on=>wwv_flow_imp.dz('20250127140216Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(579535278756017202)
,p_db_column_name=>'ENLACEARCHIVO'
,p_display_order=>70
,p_column_identifier=>'H'
,p_column_label=>'Enlacearchivo'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20250125202218Z')
,p_updated_on=>wwv_flow_imp.dz('20250125203047Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(579350742649069352)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'5793508'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'VER:TIPO:BLOBCONTENT:OBSERVACION:'
,p_created_on=>wwv_flow_imp.dz('20250125033716Z')
,p_updated_on=>wwv_flow_imp.dz('20250125202925Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(579346493753064535)
,p_plug_name=>'Ocultos'
,p_region_name=>'regOcultos'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(38289867500120143)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
,p_created_on=>wwv_flow_imp.dz('20250125045323Z')
,p_updated_on=>wwv_flow_imp.dz('20250125083646Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1811109684710243646)
,p_plug_name=>'Barra de acciones'
,p_region_template_options=>'#DEFAULT#:t-Form--stretchInputs'
,p_plug_template=>wwv_flow_imp.id(38289497777120142)
,p_plug_display_sequence=>20
,p_plug_display_point=>'REGION_POSITION_01'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(210982040376024545)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(1811109684710243646)
,p_button_name=>'REGRESAR'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860056812106557)
,p_button_image_alt=>'Regresar'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'LEFT'
,p_button_redirect_url=>'f?p=&APP_ID.:2002:&SESSION.::&DEBUG.:::'
,p_icon_css_classes=>'fa-arrow-left'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(211051972683181179)
,p_name=>'P2013_ID_TABLA'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(579346493753064535)
,p_prompt=>'ID Tabla'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_updated_on=>wwv_flow_imp.dz('20250125045722Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(404088990322906612)
,p_name=>'P2013_ID_MUESTRA'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(579346493753064535)
,p_prompt=>'ID Muestra'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_created_on=>wwv_flow_imp.dz('20240902211613Z')
,p_updated_on=>wwv_flow_imp.dz('20250125045722Z')
,p_created_by=>'EMASABANDA'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(579345542129064526)
,p_name=>'P2013_IDARCHIVO'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(579346493753064535)
,p_prompt=>'ID Archivo'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
,p_created_on=>wwv_flow_imp.dz('20250125035442Z')
,p_updated_on=>wwv_flow_imp.dz('20250125060707Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(579346206374064533)
,p_name=>'P2013_URL'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(579346493753064535)
,p_prompt=>'URL'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_created_on=>wwv_flow_imp.dz('20250125041338Z')
,p_updated_on=>wwv_flow_imp.dz('20250125045646Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(211052351719181183)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Actualiza'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'	-- Borra archivos duplicados',
'	delete from files.t_apex_archivos a',
'	where',
'		rowid >',
'		(',
'			select min(rowid) from files.t_apex_archivos b',
'			where b.tabla = a.tabla',
'			and b.id_tabla = a.id_tabla',
'			and nvl(b.tipo,''XX'') = nvl(a.tipo,''XX'')',
'			and b.filename = a.filename',
'			and b.mimetype = a.mimetype',
'			and nvl(b.estado,''XX'') = nvl(a.estado,''XX'')',
'		)',
'	and a.tabla = ''T_CMEX_MESATRABAJO'' and a.id_tabla = :p2013_id_tabla and a.tipo = a.tipo;',
'',
'	-- Normaliza los nombres con espacios innesarios.',
'	update files.t_apex_archivos x set x.filename = trim(replace(x.filename,''  '','' ''))',
'	where tabla = ''T_CMEX_MESATRABAJO'' and id_tabla = :p2013_id_tabla and tipo = tipo and nvl(estado,1) = ''1'';',
'	commit;',
'     SELECT ID_MUESTRA INTO :P2013_ID_MUESTRA FROM DATA.vt_cmex_mesatrabajo WHERE ID= :P2013_ID_TABLA;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>211052351719181183
,p_updated_on=>wwv_flow_imp.dz('20240902211613Z')
,p_updated_by=>'EMASABANDA'
);
wwv_flow_imp.component_end;
end;
/
