prompt --application/pages/page_00192
begin
--   Manifest
--     PAGE: 00192
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>109
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_page.create_page(
 p_id=>192
,p_name=>'GESTION TRIBUTARIA - PARAMETRIZACION VALIDACIONES JSON'
,p_alias=>'GESTION-TRIBUTARIA-PARAMETRIZACION-VALIDACIONES-JSON'
,p_page_mode=>'MODAL'
,p_step_title=>'GESTION TRIBUTARIA - PARAMETRIZACION VALIDACIONES JSON'
,p_autocomplete_on_off=>'OFF'
,p_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'function removeFreezeColumnOption() {',
'    $(".a-IG-headerMenu-item:contains(''Freeze Column'')").hide();',
'}',
''))
,p_javascript_code_onload=>wwv_flow_string.join(wwv_flow_t_varchar2(
'$(secItems).hide();',
'moverToolbar();',
'removeFreezeColumnOption();'))
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.ui-dialog .ui-dialog-titlebar-close {',
'    position: absolute;',
'    right: 12px;',
'    top: 12px;',
'    width: 24px;',
'    margin: 0;',
'    padding: 0;',
'    height: 24px;',
'    border-radius: 100%;',
'    display: none;',
'}'))
,p_step_template=>wwv_flow_imp.id(37774372912106498)
,p_page_template_options=>'#DEFAULT#:ui-dialog--stretch'
,p_protection_level=>'C'
,p_page_component_map=>'21'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(576091392142971056)
,p_plug_name=>'Validciones v2'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(37806762584106520)
,p_plug_display_sequence=>20
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
unistr('    SEQ_ID,  -- ID \00FAnico de la colecci\00F3n'),
'    C001, ',
'    C002, ',
'    C003, ',
'    C004, ',
'    C005, ',
'    C006, ',
'    C007, ',
'    C008',
'FROM APEX_COLLECTIONS ',
'WHERE COLLECTION_NAME = ''COLECCION_VALIDACIONES'''))
,p_plug_source_type=>'NATIVE_IG'
,p_plug_read_only_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_plug_read_only_when=>'P192_READONLY'
,p_plug_read_only_when2=>'1'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'Condiciones v2'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(13870810743746217)
,p_name=>'C007'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'C007'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_SELECT_LIST'
,p_heading=>'Error'
,p_heading_alignment=>'CENTER'
,p_display_sequence=>100
,p_value_alignment=>'LEFT'
,p_is_required=>false
,p_lov_type=>'SQL_QUERY'
,p_lov_source=>'SELECT ID_TABLA ||'' - ''||DESCRIPCION DESCRIPCION , ID_TABLA FROM "DATA"."T_CORP_UDC" WHERE ID_CABECERA=''FINZ_GT06'' AND ID_TABLA liKE ''E%'' ORDER BY 1;'
,p_lov_display_extra=>true
,p_lov_display_null=>true
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'LOV'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(13870962151746218)
,p_name=>'C008'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'C008'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_SELECT_LIST'
,p_heading=>'Advertencia'
,p_heading_alignment=>'CENTER'
,p_display_sequence=>110
,p_value_alignment=>'LEFT'
,p_is_required=>false
,p_lov_type=>'SQL_QUERY'
,p_lov_source=>'SELECT ID_TABLA ||'' - ''||DESCRIPCION DESCRIPCION , ID_TABLA FROM "DATA"."T_CORP_UDC" WHERE ID_CABECERA=''FINZ_GT06'' AND ID_TABLA liKE ''W%'' ORDER BY 1;'
,p_lov_display_extra=>true
,p_lov_display_null=>true
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'LOV'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(29269016034260444)
,p_name=>'C005'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'C005'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_SELECT_LIST'
,p_heading=>'Configuracion A'
,p_heading_alignment=>'CENTER'
,p_display_sequence=>80
,p_value_alignment=>'LEFT'
,p_is_required=>false
,p_lov_type=>'SQL_QUERY'
,p_lov_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'with ',
'      tob as ( SELECT id_tabla tob_id, descripcion tob_descripcion FROM DATA.T_CORP_UDC WHERE activo=''1'' and id_cabecera = ''FINZ_GT02'' AND id_tabla != ''000'' )',
'    , tpr as ( SELECT id_tabla tpr_id, descripcion tpr_descripcion FROM DATA.T_CORP_UDC WHERE activo=''1'' and id_cabecera = ''FINZ_GT01'' AND id_tabla != ''000''  )',
'    , obj as ( select item cfg_id from table(pk_commons.f_dividirtexto(:G_GT_OBJETOS,'':'')))',
'SELECT ',
'    tpr_descripcion ||'' - ''||cfg.descripcion ||'' (''||PK_FINZ_GESTIONTRIBUTARIA.F_OBTENER_ALIAS_JSON(cfg.ID) ||'')'' cfg_descripcion,cfg.id ',
'FROM t_finz_gestiontributariacfg cfg',
'INNER JOIN tob ON tob_id = cfg.tipoobjeto',
'INNER JOIN tpr ON tpr_id = cfg.idproceso',
'inner join obj on cfg_id = cfg.id',
'WHERE 1=1'))
,p_lov_display_extra=>true
,p_lov_display_null=>true
,p_lov_cascade_parent_items=>'P192_IDPROCESO'
,p_ajax_items_to_submit=>'P192_IDPROCESO'
,p_ajax_optimize_refresh=>true
,p_filter_is_required=>false
,p_use_as_row_header=>false
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(29269185611260445)
,p_name=>'C006'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'C006'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_POPUP_LOV'
,p_heading=>'Campo'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>90
,p_value_alignment=>'LEFT'
,p_attribute_01=>'POPUP'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_04=>'Y'
,p_attribute_05=>'N'
,p_is_required=>false
,p_lov_type=>'SQL_QUERY'
,p_lov_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    PK_FINZ_GESTIONTRIBUTARIA.F_OBTENER_ALIAS_JSON(cfg.ID)  ||''.''||replace(jt.alias,''.'',''_'') D,',
'    PK_FINZ_GESTIONTRIBUTARIA.F_OBTENER_ALIAS_JSON(cfg.ID)  ||''.''||replace(jt.alias,''.'',''_'')  R',
'FROM t_finz_gestiontributariacfg cfg,',
'     JSON_TABLE(',
'       cfg.columnas,',
'       ''$[*]'' COLUMNS (',
'         ID        NUMBER  PATH ''$.ID'',',
'         COLUMNA   VARCHAR2(100) PATH ''$.COLUMNA'',',
'         ALIAS     VARCHAR2(100) PATH ''$.ALIAS'',',
'         VISIBLE   VARCHAR2(10)  PATH ''$.VISIBLE''',
'       )',
'     ) jt',
'where cfg.id =TO_NUMBER(:C005);'))
,p_lov_display_extra=>true
,p_lov_display_null=>true
,p_lov_cascade_parent_items=>'C005'
,p_ajax_optimize_refresh=>true
,p_filter_is_required=>false
,p_use_as_row_header=>false
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(576091547723971058)
,p_name=>'SEQ_ID'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'SEQ_ID'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_DISPLAY_ONLY'
,p_heading=>'Seq Id'
,p_heading_alignment=>'CENTER'
,p_display_sequence=>30
,p_value_alignment=>'LEFT'
,p_attribute_02=>'VALUE'
,p_attribute_05=>'PLAIN'
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>true
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(576091683612971059)
,p_name=>'C001'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'C001'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_RADIOGROUP'
,p_heading=>unistr('Operador L\00F3gico')
,p_heading_alignment=>'CENTER'
,p_display_sequence=>40
,p_value_alignment=>'LEFT'
,p_attribute_01=>'2'
,p_is_required=>false
,p_lov_type=>'SHARED'
,p_lov_id=>wwv_flow_imp.id(542425739667048154)
,p_lov_display_extra=>false
,p_lov_display_null=>false
,p_lov_cascade_parent_items=>'P191_IDPROCESO'
,p_ajax_items_to_submit=>'P192_IDPROCESO'
,p_ajax_optimize_refresh=>true
,p_filter_is_required=>false
,p_use_as_row_header=>false
,p_enable_hide=>false
,p_is_primary_key=>false
,p_default_type=>'STATIC'
,p_default_expression=>'AND'
,p_duplicate_value=>true
,p_include_in_export=>false
,p_escape_on_http_output=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(576091805217971060)
,p_name=>'C002'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'C002'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_SELECT_LIST'
,p_heading=>'Configuracion A'
,p_heading_alignment=>'CENTER'
,p_display_sequence=>50
,p_value_alignment=>'LEFT'
,p_is_required=>false
,p_lov_type=>'SQL_QUERY'
,p_lov_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'with ',
'      tob as ( SELECT id_tabla tob_id, descripcion tob_descripcion FROM DATA.T_CORP_UDC WHERE activo=''1'' and id_cabecera = ''FINZ_GT02'' AND id_tabla != ''000'' )',
'    , tpr as ( SELECT id_tabla tpr_id, descripcion tpr_descripcion FROM DATA.T_CORP_UDC WHERE activo=''1'' and id_cabecera = ''FINZ_GT01'' AND id_tabla != ''000'')',
'    , obj as ( select item cfg_id from table(pk_commons.f_dividirtexto(:G_GT_OBJETOS,'':'')))',
'SELECT ',
'    tpr_descripcion ||'' - ''||cfg.descripcion ||'' (''||PK_FINZ_GESTIONTRIBUTARIA.F_OBTENER_ALIAS_JSON(cfg.ID) ||'')'' cfg_descripcion,cfg.id ',
'FROM t_finz_gestiontributariacfg cfg',
'INNER JOIN tob ON tob_id = cfg.tipoobjeto',
'INNER JOIN tpr ON tpr_id = cfg.idproceso',
'inner join obj on cfg_id = cfg.id',
'WHERE 1=1'))
,p_lov_display_extra=>true
,p_lov_display_null=>true
,p_lov_null_text=>'Seleccione'
,p_lov_cascade_parent_items=>'P192_IDPROCESO'
,p_ajax_items_to_submit=>'P192_IDPROCESO'
,p_ajax_optimize_refresh=>true
,p_filter_is_required=>false
,p_use_as_row_header=>false
,p_enable_hide=>false
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(576091845114971061)
,p_name=>'C003'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'C003'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_POPUP_LOV'
,p_heading=>'Campo'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>60
,p_value_alignment=>'LEFT'
,p_attribute_01=>'POPUP'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_04=>'Y'
,p_attribute_05=>'N'
,p_is_required=>false
,p_lov_type=>'SQL_QUERY'
,p_lov_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    PK_FINZ_GESTIONTRIBUTARIA.F_OBTENER_ALIAS_JSON(cfg.ID)  ||''.''||replace(jt.alias,''.'',''_'') D,',
'    PK_FINZ_GESTIONTRIBUTARIA.F_OBTENER_ALIAS_JSON(cfg.ID)  ||''.''||replace(jt.alias,''.'',''_'')  R',
'FROM t_finz_gestiontributariacfg cfg,',
'     JSON_TABLE(',
'       cfg.columnas,',
'       ''$[*]'' COLUMNS (',
'         ID        NUMBER  PATH ''$.ID'',',
'         COLUMNA   VARCHAR2(100) PATH ''$.COLUMNA'',',
'         ALIAS     VARCHAR2(100) PATH ''$.ALIAS'',',
'         VISIBLE   VARCHAR2(10)  PATH ''$.VISIBLE''',
'       )',
'     ) jt',
'where cfg.id =TO_NUMBER(:C002);'))
,p_lov_display_extra=>true
,p_lov_display_null=>true
,p_lov_null_text=>'Seleccione'
,p_lov_cascade_parent_items=>'C002'
,p_ajax_optimize_refresh=>true
,p_filter_is_required=>false
,p_use_as_row_header=>false
,p_enable_hide=>false
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(576091954008971062)
,p_name=>'C004'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'C004'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_SELECT_LIST'
,p_heading=>'Operador Relacional'
,p_heading_alignment=>'CENTER'
,p_display_sequence=>70
,p_value_alignment=>'LEFT'
,p_is_required=>false
,p_lov_type=>'SQL_QUERY'
,p_lov_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT d,r FROM (SELECT CASE WHEN ID<=6 THEN CAMPO1 ||'' '' ELSE '''' END ||CAMPO2 d,campo1 r',
'FROM TABLE(PK_COMMONS.f_split2table(''=:IGUAL|<:MENOR|>:MAYOR|<=:MENOR IGUAL|>=:MAYOR IGUAL|<>:DIFERENTE|IS_NULL:ES NULO|IS_NOT_NULL:NO ES NULO|IN:DENTRO (SEPARADO POR COMAS)|NOT_IN:NO DENTRO (SEPARADO POR COMAS)|BETWEEN:ENTRE|NOT_BETWEEN:NO ENTRE|LIK'
||'E:CONTIENE|NOT_LIKE:NO CONTIENE'','':'',''|'') ) A order by id);	'))
,p_lov_display_extra=>true
,p_lov_display_null=>true
,p_lov_null_text=>'Seleccione'
,p_lov_cascade_parent_items=>'P191_IDPROCESO'
,p_ajax_items_to_submit=>'P192_IDPROCESO'
,p_ajax_optimize_refresh=>true
,p_filter_is_required=>false
,p_use_as_row_header=>false
,p_enable_hide=>false
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(576092608612971068)
,p_name=>'APEX$ROW_ACTION'
,p_session_state_data_type=>'VARCHAR2'
,p_item_type=>'NATIVE_ROW_ACTION'
,p_display_sequence=>20
,p_use_as_row_header=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(576092655231971069)
,p_name=>'APEX$ROW_SELECTOR'
,p_session_state_data_type=>'VARCHAR2'
,p_item_type=>'NATIVE_ROW_SELECTOR'
,p_display_sequence=>10
,p_attribute_01=>'Y'
,p_attribute_02=>'Y'
,p_attribute_03=>'N'
,p_use_as_row_header=>false
);
wwv_flow_imp_page.create_interactive_grid(
 p_id=>wwv_flow_imp.id(576091536143971057)
,p_internal_uid=>576091536143971057
,p_is_editable=>true
,p_edit_operations=>'i:u:d'
,p_lost_update_check_type=>'VALUES'
,p_add_row_if_empty=>false
,p_submit_checked_rows=>false
,p_lazy_loading=>false
,p_requires_filter=>false
,p_select_first_row=>true
,p_fixed_row_height=>true
,p_pagination_type=>'SET'
,p_show_total_row_count=>false
,p_show_toolbar=>true
,p_enable_save_public_report=>false
,p_enable_subscriptions=>true
,p_enable_flashback=>false
,p_define_chart_view=>false
,p_enable_download=>false
,p_download_formats=>null
,p_enable_mail_download=>true
,p_fixed_header=>'PAGE'
,p_show_icon_view=>false
,p_show_detail_view=>false
,p_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'function (config) {',
'    setTimeout(removeFreezeColumnOption, 1000);',
'	return cargarToolbar(config);',
'}',
'',
' '))
);
wwv_flow_imp_page.create_ig_report(
 p_id=>wwv_flow_imp.id(577387560260496528)
,p_interactive_grid_id=>wwv_flow_imp.id(576091536143971057)
,p_static_id=>'5480922'
,p_type=>'PRIMARY'
,p_default_view=>'GRID'
,p_show_row_number=>false
,p_settings_area_expanded=>true
);
wwv_flow_imp_page.create_ig_report_view(
 p_id=>wwv_flow_imp.id(577387773586496529)
,p_report_id=>wwv_flow_imp.id(577387560260496528)
,p_view_type=>'GRID'
,p_stretch_columns=>true
,p_srv_exclude_null_values=>false
,p_srv_only_display_columns=>true
,p_edit_mode=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(16115224707287435)
,p_view_id=>wwv_flow_imp.id(577387773586496529)
,p_display_seq=>9
,p_column_id=>wwv_flow_imp.id(13870810743746217)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(16116027660287444)
,p_view_id=>wwv_flow_imp.id(577387773586496529)
,p_display_seq=>10
,p_column_id=>wwv_flow_imp.id(13870962151746218)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(29313260238505906)
,p_view_id=>wwv_flow_imp.id(577387773586496529)
,p_display_seq=>7
,p_column_id=>wwv_flow_imp.id(29269016034260444)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(29314119491505911)
,p_view_id=>wwv_flow_imp.id(577387773586496529)
,p_display_seq=>8
,p_column_id=>wwv_flow_imp.id(29269185611260445)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(577388283335496535)
,p_view_id=>wwv_flow_imp.id(577387773586496529)
,p_display_seq=>2
,p_column_id=>wwv_flow_imp.id(576091547723971058)
,p_is_visible=>false
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(577389183189496540)
,p_view_id=>wwv_flow_imp.id(577387773586496529)
,p_display_seq=>3
,p_column_id=>wwv_flow_imp.id(576091683612971059)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>113
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(577390117514496542)
,p_view_id=>wwv_flow_imp.id(577387773586496529)
,p_display_seq=>4
,p_column_id=>wwv_flow_imp.id(576091805217971060)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>171
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(577390986295496545)
,p_view_id=>wwv_flow_imp.id(577387773586496529)
,p_display_seq=>5
,p_column_id=>wwv_flow_imp.id(576091845114971061)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>174
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(577391918896496547)
,p_view_id=>wwv_flow_imp.id(577387773586496529)
,p_display_seq=>6
,p_column_id=>wwv_flow_imp.id(576091954008971062)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>247
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(577400392527501022)
,p_view_id=>wwv_flow_imp.id(577387773586496529)
,p_display_seq=>1
,p_column_id=>wwv_flow_imp.id(576092608612971068)
,p_is_visible=>false
,p_is_frozen=>true
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1652370272415210222)
,p_plug_name=>'items'
,p_region_name=>'secItems'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(38289867500120143)
,p_plug_display_sequence=>40
,p_include_in_reg_disp_sel_yn=>'Y'
,p_location=>null
,p_ai_enabled=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1652372217848210241)
,p_plug_name=>'Botones'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(38290276266120143)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'REGION_POSITION_03'
,p_location=>null
,p_ai_enabled=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(16103435373258447)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(1652372217848210241)
,p_button_name=>'Cerrar'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860181880106559)
,p_button_image_alt=>'Cerrar'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(16112667586274743)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(576091392142971056)
,p_button_name=>'Cancelar'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860056812106557)
,p_button_image_alt=>'Cancelar'
,p_button_position=>'RIGHT_OF_TITLE'
,p_confirm_message=>unistr('\00BFEst\00E1 seguro de que quiere revertir los cambios generados?')
,p_confirm_style=>'warning'
,p_button_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT distinct',
'1',
'FROM APEX_COLLECTIONS ',
'WHERE COLLECTION_NAME = ''COLECCION_VALIDACIONES'''))
,p_button_condition_type=>'EXISTS'
,p_button_css_classes=>'btnAccion'
,p_icon_css_classes=>'fa-undo-alt'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(16112936717274744)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(576091392142971056)
,p_button_name=>'Limpiar'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860056812106557)
,p_button_image_alt=>'Limpiar'
,p_button_position=>'RIGHT_OF_TITLE'
,p_confirm_message=>unistr('\00BFEst\00E1 seguro de que quiere limpiar todas las condiciones generadas?')
,p_confirm_style=>'warning'
,p_button_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT distinct',
'1',
'FROM APEX_COLLECTIONS ',
'WHERE COLLECTION_NAME = ''COLECCION_VALIDACIONES'''))
,p_button_condition_type=>'EXISTS'
,p_button_css_classes=>'btnAccion'
,p_icon_css_classes=>'fa-window-ban'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(13871079186746219)
,p_name=>'P192_IDPROCESO'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(1652370272415210222)
,p_prompt=>'Idproceso'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(570732540313526090)
,p_name=>'P192_OBJETO'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(1652370272415210222)
,p_prompt=>'Objeto'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(570732873474526090)
,p_name=>'P192_READONLY'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(1652370272415210222)
,p_prompt=>'Readonly'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(570733267449526090)
,p_name=>'P192_LOADPAGE'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(1652370272415210222)
,p_prompt=>'Loadpage'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(16106619100258464)
,p_name=>'Carga Collection'
,p_event_sequence=>120
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(576091392142971056)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'NATIVE_IG|REGION TYPE|interactivegridsave'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(16107155133258465)
,p_event_id=>wwv_flow_imp.id(16106619100258464)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    v_datos VARCHAR2(4000);',
'    v_contador number;',
'BEGIN',
'    v_datos := '''';',
' execute immediate ''',
'       SELECT ',
'          JSON_ARRAYAGG(JSON_OBJECT(*) RETURNING CLOB)',
'           FROM (',
'               SELECT seq_id ID',
'                    ,C001 OLOGICO',
'                    ,C002 CONFIGURACION_A',
'                    ,C003 CAMPO_A',
'                    ,C004 ORELACIONAL',
'                    ,C005 CONFIGURACION_B',
'                    ,C006 CAMPO_B',
'                    ,C007 MSJ_ERROR',
'                    ,C008 MSJ_ADVERTECNIA',
'                FROM APEX_COLLECTIONS WHERE COLLECTION_NAME = ''''COLECCION_VALIDACIONES'''' ORDER BY seq_id',
'           )',
'    '' into v_datos;',
'',
'    :G_GT_VALIDACIONES:=upper(v_datos);',
'END;',
' '))
,p_attribute_02=>'G_GT_CONDICIONES'
,p_attribute_03=>'G_GT_CONDICIONES'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(16107676891258465)
,p_event_id=>wwv_flow_imp.id(16106619100258464)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_02=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(58698667321752204)
,p_name=>'New'
,p_event_sequence=>140
,p_triggering_condition_type=>'JAVASCRIPT_EXPRESSION'
,p_triggering_expression=>'$v("P192_LOADPAGE")!=="1"'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'ready'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(58698835819752206)
,p_event_id=>wwv_flow_imp.id(58698667321752204)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'console.log("P192_LOADPAGE:"+$v("P192_LOADPAGE"));'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(58699061544752208)
,p_event_id=>wwv_flow_imp.id(58698667321752204)
,p_event_result=>'TRUE'
,p_action_sequence=>50
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_01=>'cargar_pagina'
,p_attribute_02=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(58698929168752207)
,p_event_id=>wwv_flow_imp.id(58698667321752204)
,p_event_result=>'TRUE'
,p_action_sequence=>60
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'console.log("P192_LOADPAGE:"+$v("P192_LOADPAGE"));'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(16102786857258442)
,p_process_sequence=>30
,p_process_point=>'AFTER_SUBMIT'
,p_region_id=>wwv_flow_imp.id(576091392142971056)
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Validaciones - Save Interactive Grid Data'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare ',
'    v_alias varchar2(399);',
'    v_columna varchar2(399);',
'BEGIN',
'    case :APEX$ROW_STATUS  ',
'     WHEN ''C'' THEN',
'        APEX_COLLECTION.ADD_MEMBER(',
'                p_collection_name =>''COLECCION_VALIDACIONES'',',
'                p_c001 =>:C001,',
'                p_c002 =>:C002,',
'                p_c003 =>:C003,',
'                p_c004 =>:C004,',
'                p_c005 =>:C005,',
'                p_c006 =>:C006,',
'                p_c007 =>:C007,',
'                p_c008 =>:C008',
'        );',
'     WHEN ''U'' THEN       ',
'        APEX_COLLECTION.UPDATE_MEMBER(',
'                 p_collection_name =>''COLECCION_VALIDACIONES''',
'                ,p_seq => :seq_id,',
'                p_c001 =>:C001,',
'                p_c002 =>:C002,',
'                p_c003 =>:C003,',
'                p_c004 =>:C004,',
'                p_c005 =>:C005,',
'                p_c006 =>:C006,',
'                p_c007 =>:C007,',
'                p_c008 =>:C008',
'        );',
'    WHEN ''D'' THEN',
'        APEX_COLLECTION.DELETE_MEMBER(p_collection_name =>''COLECCION_VALIDACIONES'',p_seq => :seq_id);',
'    END CASE;',
'EXCEPTION WHEN OTHERS THEN ',
'    apex_error.add_error (',
'    p_message          => ''ERROR::''||:APEX$ROW_STATUS||'' ''||SQLERRM  ,',
'    p_display_location =>apex_error.c_inline_in_notification );',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>16102786857258442
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(16104435870258461)
,p_process_sequence=>40
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_CLOSE_WINDOW'
,p_process_name=>'Close Dialog '
,p_attribute_02=>'N'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(16103435373258447)
,p_internal_uid=>16104435870258461
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(58698567569752203)
,p_process_sequence=>50
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Limpiar_1'
,p_process_sql_clob=>':P192_LOADPAGE:=1;'
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>'cargar_pagina'
,p_process_when_type=>'REQUEST_EQUALS_CONDITION'
,p_internal_uid=>58698567569752203
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(16104852829258461)
,p_process_sequence=>60
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Limpiar'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'IF APEX_COLLECTION.COLLECTION_EXISTS(''COLECCION_VALIDACIONES'') THEN',
'    APEX_COLLECTION.TRUNCATE_COLLECTION(''COLECCION_VALIDACIONES'');',
'END IF;',
':G_GT_VALIDACIONES:=null;',
':P192_LOADPAGE:=null;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(16112936717274744)
,p_internal_uid=>16104852829258461
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(16104013465258460)
,p_process_sequence=>20
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'SetupPage'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'IF NOT APEX_COLLECTION.COLLECTION_EXISTS(''COLECCION_VALIDACIONES'') THEN',
'    APEX_COLLECTION.CREATE_COLLECTION(''COLECCION_VALIDACIONES'');',
'END IF;',
'IF APEX_COLLECTION.COLLECTION_EXISTS(''COLECCION_VALIDACIONES'') THEN',
'    APEX_COLLECTION.TRUNCATE_COLLECTION(''COLECCION_VALIDACIONES'');',
'END IF;',
'            ',
'IF(:G_GT_OBJETOS IS NOT NULL)THEN',
'   :P192_OBJETO:= :G_GT_OBJETOS ;',
'END IF;',
'IF(:G_GT_VALIDACIONES IS NOT NULL)THEN',
'    FOR COLS IN (',
'        SELECT OLOGICO CAMPO1,CONFIGURACION_A CAMPO2,CAMPO_A CAMPO3,ORELACIONAL CAMPO4,CONFIGURACION_B campo5,CAMPO_B campo6,MSJ_ERROR CAMPO7,MSJ_ADVERTECNIA CAMPO8',
'        FROM JSON_TABLE(',
'            :G_GT_VALIDACIONES, -- tu variable o columna con el JSON',
'            ''$[*]'' -- indica que es un arreglo',
'            COLUMNS (',
'                OLOGICO   VARCHAR2(3999) PATH ''$.OLOGICO'',',
'                CONFIGURACION_A     VARCHAR2(399) PATH ''$.CONFIGURACION_A'',',
'                CAMPO_A   VARCHAR2(399)   PATH ''$.CAMPO_A'',',
'                ORELACIONAL  VARCHAR2(399)  PATH ''$.ORELACIONAL'',',
'                CONFIGURACION_B  VARCHAR2(100)  PATH ''$.CONFIGURACION_B'',',
'                CAMPO_B  VARCHAR2(100)  PATH ''$.CAMPO_B'',',
'                MSJ_ERROR  VARCHAR2(100)  PATH ''$.MSJ_ERROR'',',
'                MSJ_ADVERTECNIA  VARCHAR2(100)  PATH ''$.MSJ_ADVERTECNIA''',
'            )',
'        )',
'    )',
'    LOOP',
'     APEX_COLLECTION.ADD_MEMBER(',
'                    p_collection_name => ''COLECCION_VALIDACIONES'',',
'                    p_c001 => COLS.CAMPO1,',
'                    p_c002 => COLS.CAMPO2,',
'                    p_c003 => COLS.CAMPO3,',
'                    p_c004 => COLS.CAMPO4,',
'                    p_c005 => COLS.CAMPO5,',
'                    p_c006 => COLS.CAMPO6,',
'                    p_c007 => COLS.CAMPO7,',
'                    p_c008 => COLS.CAMPO8',
'                );',
'    END LOOP;',
'END IF;',
' ',
'    ',
''))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>16104013465258460
);
wwv_flow_imp.component_end;
end;
/
