prompt --application/pages/page_00446
begin
--   Manifest
--     PAGE: 00446
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>109
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_page.create_page(
 p_id=>446
,p_name=>'PYG INDUSTRIALES - PAG - REGLAS DE DISTRIBUCION (CRUD)'
,p_alias=>'PYG-INDUSTRIALES-CRUD-REGLAS-DE-DISTRIBUCION'
,p_step_title=>'PYG INDUSTRIALES - CRUD - REGLAS DE DISTRIBUCION'
,p_autocomplete_on_off=>'OFF'
,p_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'function f_setpopup(p_idform){',
'mostrarBarra();',
'    switch(p_idform){',
'            case 1 : ',
'            case 2 : ',
'            case 3 : ',
'            case 4 : ',
'            case 5 :  ',
'                      $s("P446_REGLANUMERO",p_idform);',
'                      break;',
'            default : mensajeError("No existe un formulario para esta regla");',
'    }',
'}'))
,p_javascript_code_onload=>'$(secItems).hide();'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'02'
,p_last_updated_on=>wwv_flow_imp.dz('20260327033706Z')
,p_last_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(118989833895315741)
,p_plug_name=>'Items'
,p_region_name=>'secItems'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(38289867500120143)
,p_plug_display_sequence=>10
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
,p_updated_on=>wwv_flow_imp.dz('20260327033628Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(138925580513596833)
,p_plug_name=>'CostoVenta'
,p_title=>'Costo de Venta <button type=''button'' id=''btnReglas3'' onclick=''f_setpopup(3);'' class=''t-Button t-Button--noLabel t-Button--icon js-ignoreChange''><span class=''fa fa-pencil-square-o fam-information fam-is-info''></span></button></label>'
,p_region_name=>'tbDistCostoVenta'
,p_parent_plug_id=>wwv_flow_imp.id(118989833895315741)
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(37806762584106520)
,p_plug_display_sequence=>20
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT SEQ_ID,  ',
'    C001, ',
'    C002, ',
'    C003, ',
'    C004, ',
'    C005, ',
'    C006,',
'    C007,',
'    C008,',
'    C009,',
'    C010,',
'    C011,',
'    C012,',
'    C013,',
'    C014,',
'    C020,',
'case when c007=''DATA.T_FINZ_DISTRIBUCIONASC'' and (CLOB001 is null or dbms_lob.getlength(CLOB001)=0)then 0 else 1 end BaseDistribucion',
'FROM APEX_COLLECTIONS ',
'WHERE COLLECTION_NAME = ''COLECCION_REGLAS3DIST''',
' order by SEQ_ID'))
,p_plug_source_type=>'NATIVE_IR'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'Costo de Venta <button type=''button'' id=''btnReglas3'' onclick=''f_setpopup(3);'' class=''t-Button t-Button--noLabel t-Button--icon js-ignoreChange''><span class=''fa fa-pencil-square-o fam-information fam-is-info''></span></button></label>'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
,p_updated_on=>wwv_flow_imp.dz('20260311170710Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(138925650299596834)
,p_max_row_count=>'1000000'
,p_allow_report_saving=>'N'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_show_finder_drop_down=>'N'
,p_report_list_mode=>'NONE'
,p_fixed_header=>'NONE'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_select_columns=>'N'
,p_show_rows_per_page=>'N'
,p_show_control_break=>'N'
,p_show_highlight=>'N'
,p_show_computation=>'N'
,p_show_aggregate=>'N'
,p_show_chart=>'N'
,p_show_group_by=>'N'
,p_show_pivot=>'N'
,p_show_notify=>'Y'
,p_show_flashback=>'N'
,p_show_reset=>'N'
,p_show_help=>'N'
,p_download_formats=>'XLSX'
,p_enable_mail_download=>'N'
,p_owner=>'EMASABANDA'
,p_internal_uid=>138925650299596834
,p_updated_on=>wwv_flow_imp.dz('20260311165108Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_col_group(
 p_id=>wwv_flow_imp.id(366723985717321614)
,p_name=>'Destino'
,p_display_sequence=>10
,p_created_on=>wwv_flow_imp.dz('20260224183726Z')
,p_updated_on=>wwv_flow_imp.dz('20260224183726Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_col_group(
 p_id=>wwv_flow_imp.id(366724037160321615)
,p_name=>'Niveles'
,p_display_sequence=>20
,p_created_on=>wwv_flow_imp.dz('20260224183726Z')
,p_updated_on=>wwv_flow_imp.dz('20260224183726Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_col_group(
 p_id=>wwv_flow_imp.id(366724136354321616)
,p_name=>'Origen'
,p_display_sequence=>30
,p_created_on=>wwv_flow_imp.dz('20260224183726Z')
,p_updated_on=>wwv_flow_imp.dz('20260224183726Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_col_group(
 p_id=>wwv_flow_imp.id(366724267615321617)
,p_name=>'Condicionantes'
,p_display_sequence=>40
,p_created_on=>wwv_flow_imp.dz('20260224183726Z')
,p_updated_on=>wwv_flow_imp.dz('20260224183726Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(138925734526596835)
,p_db_column_name=>'SEQ_ID'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Seq Id'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(138925899630596836)
,p_db_column_name=>'C001'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Tipo Venta'
,p_column_type=>'STRING'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_heading_alignment=>'LEFT'
,p_rpt_named_lov=>wwv_flow_imp.id(121710145807591205)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(138925943567596837)
,p_db_column_name=>'C002'
,p_display_order=>30
,p_group_id=>wwv_flow_imp.id(366724037160321615)
,p_column_identifier=>'C'
,p_column_label=>'Nivel 01'
,p_column_type=>'STRING'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_heading_alignment=>'LEFT'
,p_rpt_named_lov=>wwv_flow_imp.id(119193859528059131)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
,p_updated_on=>wwv_flow_imp.dz('20260224183807Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(138926059863596838)
,p_db_column_name=>'C003'
,p_display_order=>40
,p_group_id=>wwv_flow_imp.id(366724037160321615)
,p_column_identifier=>'D'
,p_column_label=>'Nivel 02'
,p_column_type=>'STRING'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_heading_alignment=>'LEFT'
,p_rpt_named_lov=>wwv_flow_imp.id(119194387269080626)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
,p_updated_on=>wwv_flow_imp.dz('20260224183807Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(138926112563596839)
,p_db_column_name=>'C004'
,p_display_order=>50
,p_group_id=>wwv_flow_imp.id(366724267615321617)
,p_column_identifier=>'E'
,p_column_label=>'Cta. Contable'
,p_column_type=>'STRING'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_heading_alignment=>'LEFT'
,p_rpt_named_lov=>wwv_flow_imp.id(124865455833884289)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
,p_updated_on=>wwv_flow_imp.dz('20260224183807Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(138926261240596840)
,p_db_column_name=>'C005'
,p_display_order=>60
,p_group_id=>wwv_flow_imp.id(366724267615321617)
,p_column_identifier=>'F'
,p_column_label=>'Tipo Orden'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
,p_updated_on=>wwv_flow_imp.dz('20260224183807Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(138926368615596841)
,p_db_column_name=>'C006'
,p_display_order=>70
,p_group_id=>wwv_flow_imp.id(366724267615321617)
,p_column_identifier=>'G'
,p_column_label=>'Tipo Documento'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
,p_updated_on=>wwv_flow_imp.dz('20260224183807Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(138926401583596842)
,p_db_column_name=>'C007'
,p_display_order=>80
,p_group_id=>wwv_flow_imp.id(366724136354321616)
,p_column_identifier=>'H'
,p_column_label=>'Objeto BDD'
,p_column_type=>'STRING'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_heading_alignment=>'LEFT'
,p_rpt_named_lov=>wwv_flow_imp.id(142729312902456972)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
,p_updated_on=>wwv_flow_imp.dz('20260224183807Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(138926598926596843)
,p_db_column_name=>'C008'
,p_display_order=>90
,p_group_id=>wwv_flow_imp.id(366724136354321616)
,p_column_identifier=>'I'
,p_column_label=>'Columnas'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
,p_updated_on=>wwv_flow_imp.dz('20260224183807Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(138926605526596844)
,p_db_column_name=>'C009'
,p_display_order=>100
,p_group_id=>wwv_flow_imp.id(366723985717321614)
,p_column_identifier=>'J'
,p_column_label=>'Objeto BDD'
,p_column_type=>'STRING'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_heading_alignment=>'LEFT'
,p_rpt_named_lov=>wwv_flow_imp.id(142729312902456972)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
,p_updated_on=>wwv_flow_imp.dz('20260224183808Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(366722968946321604)
,p_db_column_name=>'C010'
,p_display_order=>110
,p_group_id=>wwv_flow_imp.id(366723985717321614)
,p_column_identifier=>'L'
,p_column_label=>'Columnas'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20260224174324Z')
,p_updated_on=>wwv_flow_imp.dz('20260224183808Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(366723066678321605)
,p_db_column_name=>'C011'
,p_display_order=>140
,p_column_identifier=>'M'
,p_column_label=>'C011'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20260224174324Z')
,p_updated_on=>wwv_flow_imp.dz('20260224174520Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(366723156993321606)
,p_db_column_name=>'C012'
,p_display_order=>150
,p_column_identifier=>'N'
,p_column_label=>'C012'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20260224174324Z')
,p_updated_on=>wwv_flow_imp.dz('20260224174520Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(366723251192321607)
,p_db_column_name=>'C013'
,p_display_order=>160
,p_column_identifier=>'O'
,p_column_label=>'C013'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20260224174324Z')
,p_updated_on=>wwv_flow_imp.dz('20260224174520Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(366723321803321608)
,p_db_column_name=>'C014'
,p_display_order=>170
,p_column_identifier=>'P'
,p_column_label=>'C014'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20260224174324Z')
,p_updated_on=>wwv_flow_imp.dz('20260224174520Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(138926713776596845)
,p_db_column_name=>'C020'
,p_display_order=>180
,p_column_identifier=>'K'
,p_column_label=>'Comentarios'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
,p_updated_on=>wwv_flow_imp.dz('20260224174520Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(386064443049380804)
,p_db_column_name=>'BASEDISTRIBUCION'
,p_display_order=>190
,p_column_identifier=>'Q'
,p_column_label=>'Basedistribucion'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20260310164457Z')
,p_updated_on=>wwv_flow_imp.dz('20260310164457Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(142506679776416770)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'1425067'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'SEQ_ID:C001:C002:C003:C004:C005:C006:C007:C020:'
,p_updated_on=>wwv_flow_imp.dz('20260310174256Z')
,p_updated_by=>'EMASABANDA'
);
wwv_flow_imp_page.create_worksheet_condition(
 p_id=>wwv_flow_imp.id(386246142391855719)
,p_report_id=>wwv_flow_imp.id(142506679776416770)
,p_name=>'Sin Base de Distribucion'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'BASEDISTRIBUCION'
,p_operator=>'='
,p_expr=>'0'
,p_condition_sql=>' (case when ("BASEDISTRIBUCION" = to_number(#APXWS_EXPR#)) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_row_bg_color=>'#ff9e9e'
,p_row_font_color=>'#ffffff'
,p_created_on=>wwv_flow_imp.dz('20260310174256Z')
,p_updated_on=>wwv_flow_imp.dz('20260310174256Z')
,p_created_by=>'EMASABANDA'
,p_updated_by=>'EMASABANDA'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(118989930449315742)
,p_plug_name=>'Barra de Acciones'
,p_region_template_options=>'#DEFAULT#:t-Form--stretchInputs'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(38289497777120142)
,p_plug_display_sequence=>30
,p_plug_display_point=>'REGION_POSITION_01'
,p_location=>null
,p_menu_id=>wwv_flow_imp.id(37761271469106475)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(37860983999106559)
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(118990471327315747)
,p_plug_name=>'ADICIONALES'
,p_region_name=>'secAdicionales'
,p_region_template_options=>'#DEFAULT#:js-useLocalStorage:t-TabsRegion-mod--fillLabels:t-TabsRegion-mod--simple:t-Form--labelsAbove:margin-top-none:margin-bottom-none:margin-left-none:margin-right-none'
,p_plug_template=>wwv_flow_imp.id(37814656137106525)
,p_plug_display_sequence=>30
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
,p_updated_on=>wwv_flow_imp.dz('20260327033628Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(118990535811315748)
,p_plug_name=>'GastosFlete'
,p_title=>'Gastos de Flete <button type=''button'' id=''btnReglas1'' onclick=''f_setpopup(1);'' class=''t-Button t-Button--noLabel t-Button--icon js-ignoreChange''><span class=''fa fa-pencil-square-o fam-information fam-is-info''></span></button></label>'
,p_region_name=>'tbDistGastosFlete'
,p_parent_plug_id=>wwv_flow_imp.id(118990471327315747)
,p_region_template_options=>'#DEFAULT#:t-Form--noPadding:t-Form--labelsAbove:margin-top-none:margin-bottom-none:margin-left-none:margin-right-none'
,p_plug_template=>wwv_flow_imp.id(37806762584106520)
,p_plug_display_sequence=>40
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
unistr('    SEQ_ID,  -- ID \00FAnico de la colecci\00F3n'),
'    C001, ',
'    C002, ',
'    C003, ',
'    C004, ',
'    C005, ',
'    C006, ',
'    C007, ',
'    C008, ',
'    C009, ',
'    C020,',
'case when c006=''DATA.T_FINZ_DISTRIBUCIONASC'' and (CLOB001 is null or dbms_lob.getlength(CLOB001)=0)then 0 else 1 end BaseDistribucion',
'FROM APEX_COLLECTIONS ',
'WHERE COLLECTION_NAME = ''COLECCION_REGLAS1DIST''',
' order by SEQ_ID'))
,p_plug_source_type=>'NATIVE_IR'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'Gastos de Flete <button type=''button'' id=''btnReglas1'' onclick=''f_setpopup(1);'' class=''t-Button t-Button--noLabel t-Button--icon js-ignoreChange''><span class=''fa fa-pencil-square-o fam-information fam-is-info''></span></button></label>'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
,p_updated_on=>wwv_flow_imp.dz('20260327021446Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(121157738351653807)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_show_finder_drop_down=>'N'
,p_report_list_mode=>'NONE'
,p_fixed_header=>'NONE'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'EMASABANDA'
,p_internal_uid=>121157738351653807
,p_updated_on=>wwv_flow_imp.dz('20260326023720Z')
,p_updated_by=>'EMASABANDA'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(121158225149653812)
,p_db_column_name=>'SEQ_ID'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Seq Id'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(121158333938653813)
,p_db_column_name=>'C001'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Tipo Venta'
,p_column_type=>'STRING'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_rpt_named_lov=>wwv_flow_imp.id(121710145807591205)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
,p_updated_on=>wwv_flow_imp.dz('20260219190057Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(121158483398653814)
,p_db_column_name=>'C002'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Nivel 01'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_rpt_named_lov=>wwv_flow_imp.id(119193859528059131)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
,p_updated_on=>wwv_flow_imp.dz('20260219190057Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(121158547395653815)
,p_db_column_name=>'C003'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Nivel 02'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_rpt_named_lov=>wwv_flow_imp.id(119194387269080626)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
,p_updated_on=>wwv_flow_imp.dz('20260219194206Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(121158602349653816)
,p_db_column_name=>'C004'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Cta. Contable'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
,p_updated_on=>wwv_flow_imp.dz('20260219190019Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(360415828262361406)
,p_db_column_name=>'C005'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'Condicion 1'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20260219185849Z')
,p_updated_on=>wwv_flow_imp.dz('20260219203146Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(360415994216361407)
,p_db_column_name=>'C006'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>'Obj. Origen'
,p_column_type=>'STRING'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_rpt_named_lov=>wwv_flow_imp.id(142729312902456972)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20260219185849Z')
,p_updated_on=>wwv_flow_imp.dz('20260225145129Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(360416012721361408)
,p_db_column_name=>'C007'
,p_display_order=>80
,p_column_identifier=>'H'
,p_column_label=>'Cols. Origen'
,p_column_type=>'STRING'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_rpt_named_lov=>wwv_flow_imp.id(360692744238225505)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20260219185849Z')
,p_updated_on=>wwv_flow_imp.dz('20260225145129Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(360416184940361409)
,p_db_column_name=>'C008'
,p_display_order=>90
,p_column_identifier=>'I'
,p_column_label=>'Obj. Destino'
,p_column_type=>'STRING'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_rpt_named_lov=>wwv_flow_imp.id(360692744238225505)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20260219185849Z')
,p_updated_on=>wwv_flow_imp.dz('20260225145129Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(360416219888361410)
,p_db_column_name=>'C009'
,p_display_order=>100
,p_column_identifier=>'J'
,p_column_label=>'Cols. Destino'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20260219185849Z')
,p_updated_on=>wwv_flow_imp.dz('20260225145129Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(360416327801361411)
,p_db_column_name=>'C020'
,p_display_order=>110
,p_column_identifier=>'K'
,p_column_label=>'Comentarios'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20260219185849Z')
,p_updated_on=>wwv_flow_imp.dz('20260219190058Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(386064607601380806)
,p_db_column_name=>'BASEDISTRIBUCION'
,p_display_order=>120
,p_column_identifier=>'L'
,p_column_label=>'Basedistribucion'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20260310164719Z')
,p_updated_on=>wwv_flow_imp.dz('20260310164719Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(121196287585751184)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'1211963'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'SEQ_ID:C001:C002:C003:C004:C006:C020:'
,p_updated_on=>wwv_flow_imp.dz('20260326023720Z')
,p_updated_by=>'EMASABANDA'
);
wwv_flow_imp_page.create_worksheet_condition(
 p_id=>wwv_flow_imp.id(405143962398662100)
,p_report_id=>wwv_flow_imp.id(121196287585751184)
,p_name=>'Sin Base de Distribucion'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'BASEDISTRIBUCION'
,p_operator=>'='
,p_expr=>'0'
,p_condition_sql=>' (case when ("BASEDISTRIBUCION" = to_number(#APXWS_EXPR#)) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_row_bg_color=>'#ff9e9e'
,p_row_font_color=>'#ffffff'
,p_created_on=>wwv_flow_imp.dz('20260326023720Z')
,p_updated_on=>wwv_flow_imp.dz('20260326023720Z')
,p_created_by=>'EMASABANDA'
,p_updated_by=>'EMASABANDA'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(121157190072653801)
,p_plug_name=>'VentaNeta'
,p_title=>'Venta Neta <button type=''button'' id=''btnReglas2'' onclick=''f_setpopup(2);'' class=''t-Button t-Button--noLabel t-Button--icon js-ignoreChange''><span class=''fa fa-pencil-square-o fam-information fam-is-info''></span></button></label>'
,p_region_name=>'tbDistVentaNeta'
,p_parent_plug_id=>wwv_flow_imp.id(118990471327315747)
,p_region_template_options=>'#DEFAULT#:t-Form--noPadding:t-Form--labelsAbove:margin-top-none:margin-bottom-none:margin-left-none:margin-right-none:t-IRR-region--noBorders'
,p_plug_template=>wwv_flow_imp.id(37806762584106520)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select     SEQ_ID,  ',
'    C001, ',
'    C002, ',
'    C003, ',
'    C004, ',
'    C005, ',
'    C006,',
'    C007,',
'    C008,',
'    C009,',
'    C010,',
'    C011,',
'    C012,',
'    C013,',
'    C014,',
'    C020,',
'case when c009=''DATA.T_FINZ_DISTRIBUCIONASC'' and (CLOB001 is null or dbms_lob.getlength(CLOB001)=0)then 0 else 1 end BaseDistribucion',
'FROM APEX_COLLECTIONS ',
'WHERE COLLECTION_NAME = ''COLECCION_REGLAS2DIST''',
'order by SEQ_ID'))
,p_plug_source_type=>'NATIVE_IR'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'Venta Neta <button type=''button'' id=''btnReglas2'' onclick=''f_setpopup(2);'' class=''t-Button t-Button--noLabel t-Button--icon js-ignoreChange''><span class=''fa fa-pencil-square-o fam-information fam-is-info''></span></button></label>'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
,p_updated_on=>wwv_flow_imp.dz('20260327021446Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(121157836516653808)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_show_finder_drop_down=>'N'
,p_report_list_mode=>'NONE'
,p_fixed_header=>'NONE'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'EMASABANDA'
,p_internal_uid=>121157836516653808
,p_updated_on=>wwv_flow_imp.dz('20260326023505Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_col_group(
 p_id=>wwv_flow_imp.id(365343490580657448)
,p_name=>'Origen'
,p_display_sequence=>10
,p_created_on=>wwv_flow_imp.dz('20260224162318Z')
,p_updated_on=>wwv_flow_imp.dz('20260224162318Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_col_group(
 p_id=>wwv_flow_imp.id(365343554215657449)
,p_name=>'Destino'
,p_display_sequence=>20
,p_created_on=>wwv_flow_imp.dz('20260224162424Z')
,p_updated_on=>wwv_flow_imp.dz('20260224162424Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(121158718460653817)
,p_db_column_name=>'SEQ_ID'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Seq Id'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(121158863695653818)
,p_db_column_name=>'C001'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Tipo Venta'
,p_column_type=>'STRING'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_heading_alignment=>'LEFT'
,p_rpt_named_lov=>wwv_flow_imp.id(121710145807591205)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(121158901608653819)
,p_db_column_name=>'C002'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Nivel 01'
,p_column_type=>'STRING'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_heading_alignment=>'LEFT'
,p_rpt_named_lov=>wwv_flow_imp.id(119193859528059131)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(121159031137653820)
,p_db_column_name=>'C003'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Nivel 02'
,p_column_type=>'STRING'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_heading_alignment=>'LEFT'
,p_rpt_named_lov=>wwv_flow_imp.id(119194387269080626)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(121159176528653821)
,p_db_column_name=>'C004'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Cta. Contable'
,p_column_type=>'STRING'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_heading_alignment=>'LEFT'
,p_rpt_named_lov=>wwv_flow_imp.id(124865455833884289)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(121828784527311019)
,p_db_column_name=>'C005'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'Motivo'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(123071299353026610)
,p_db_column_name=>'C006'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>'Tipo Orden'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(123071306720026611)
,p_db_column_name=>'C007'
,p_display_order=>80
,p_column_identifier=>'H'
,p_column_label=>'Tipo Documento'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(123071403589026612)
,p_db_column_name=>'C008'
,p_display_order=>90
,p_column_identifier=>'I'
,p_column_label=>'Precios Ajustes'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(123071587001026613)
,p_db_column_name=>'C009'
,p_display_order=>100
,p_group_id=>wwv_flow_imp.id(365343490580657448)
,p_column_identifier=>'J'
,p_column_label=>'Objeto BDD'
,p_column_type=>'STRING'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_heading_alignment=>'LEFT'
,p_rpt_named_lov=>wwv_flow_imp.id(142729312902456972)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
,p_updated_on=>wwv_flow_imp.dz('20260224162318Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(365342962642657443)
,p_db_column_name=>'C010'
,p_display_order=>120
,p_group_id=>wwv_flow_imp.id(365343490580657448)
,p_column_identifier=>'L'
,p_column_label=>'Columnas'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20260224162104Z')
,p_updated_on=>wwv_flow_imp.dz('20260224162424Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(365343095013657444)
,p_db_column_name=>'C011'
,p_display_order=>130
,p_group_id=>wwv_flow_imp.id(365343554215657449)
,p_column_identifier=>'M'
,p_column_label=>'Objeto BDD'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20260224162104Z')
,p_updated_on=>wwv_flow_imp.dz('20260224162424Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(365343161558657445)
,p_db_column_name=>'C012'
,p_display_order=>140
,p_group_id=>wwv_flow_imp.id(365343554215657449)
,p_column_identifier=>'N'
,p_column_label=>'Columnas'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20260224162104Z')
,p_updated_on=>wwv_flow_imp.dz('20260224162424Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(365343200857657446)
,p_db_column_name=>'C013'
,p_display_order=>150
,p_column_identifier=>'O'
,p_column_label=>'C013'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20260224162104Z')
,p_updated_on=>wwv_flow_imp.dz('20260224162104Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(365343353262657447)
,p_db_column_name=>'C014'
,p_display_order=>160
,p_column_identifier=>'P'
,p_column_label=>'C014'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20260224162104Z')
,p_updated_on=>wwv_flow_imp.dz('20260224162104Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(123071648086026614)
,p_db_column_name=>'C020'
,p_display_order=>170
,p_column_identifier=>'K'
,p_column_label=>'Comentarios'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
,p_updated_on=>wwv_flow_imp.dz('20260224162318Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(386064369967380803)
,p_db_column_name=>'BASEDISTRIBUCION'
,p_display_order=>180
,p_column_identifier=>'Q'
,p_column_label=>'Basedistribucion'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20260310164242Z')
,p_updated_on=>wwv_flow_imp.dz('20260310164242Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(121196891103751207)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'1211969'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'SEQ_ID:C001:C009:C002:C003:C004:C005:C006:C007:C008:C020:'
,p_sort_column_1=>'SEQ_ID'
,p_sort_direction_1=>'ASC'
,p_updated_on=>wwv_flow_imp.dz('20260311171813Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_condition(
 p_id=>wwv_flow_imp.id(387699374577347433)
,p_report_id=>wwv_flow_imp.id(121196891103751207)
,p_name=>'Sin Base de Distribucion'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'BASEDISTRIBUCION'
,p_operator=>'='
,p_expr=>'0'
,p_condition_sql=>' (case when ("BASEDISTRIBUCION" = to_number(#APXWS_EXPR#)) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_row_bg_color=>'#ff9e9e'
,p_row_font_color=>'#ffffff'
,p_created_on=>wwv_flow_imp.dz('20260311171813Z')
,p_updated_on=>wwv_flow_imp.dz('20260311171813Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(121157436851653804)
,p_plug_name=>'CostoFlete'
,p_title=>'Costo de Flete <button type=''button'' id=''btnReglas4'' onclick=''f_setpopup(4);'' class=''t-Button t-Button--noLabel t-Button--icon js-ignoreChange''><span class=''fa fa-pencil-square-o fam-information fam-is-info''></span></button></label>'
,p_region_name=>'tbDistCostoFlete'
,p_parent_plug_id=>wwv_flow_imp.id(118990471327315747)
,p_region_template_options=>'#DEFAULT#:t-Form--noPadding:t-Form--labelsAbove:margin-top-none:margin-bottom-none:margin-left-none:margin-right-none'
,p_plug_template=>wwv_flow_imp.id(37806762584106520)
,p_plug_display_sequence=>30
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
unistr('    SEQ_ID,  -- ID \00FAnico de la colecci\00F3n'),
'    C001, ',
'    C002, ',
'    C003, ',
'    C004, ',
'    C005, ',
'    C006, ',
'    C007, ',
'    C008, ',
'    C009, ',
'    C010,',
'    C011,',
'    C012,',
'    C013,',
'    C014,',
'    C020,',
'case when c007=''DATA.T_FINZ_DISTRIBUCIONASC'' and (CLOB001 is null or dbms_lob.getlength(CLOB001)=0)then 0 else 1 end BaseDistribucion',
'FROM APEX_COLLECTIONS ',
'WHERE COLLECTION_NAME = ''COLECCION_REGLAS4DIST''',
' order by SEQ_ID'))
,p_plug_source_type=>'NATIVE_IR'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'Costo de Flete <button type=''button'' id=''btnReglas4'' onclick=''f_setpopup(4);'' class=''t-Button t-Button--noLabel t-Button--icon js-ignoreChange''><span class=''fa fa-pencil-square-o fam-information fam-is-info''></span></button></label>'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
,p_updated_on=>wwv_flow_imp.dz('20260327021446Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(121158074265653810)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_show_finder_drop_down=>'N'
,p_report_list_mode=>'NONE'
,p_fixed_header=>'NONE'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'EMASABANDA'
,p_internal_uid=>121158074265653810
,p_updated_on=>wwv_flow_imp.dz('20260326023647Z')
,p_updated_by=>'EMASABANDA'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(121159790802653827)
,p_db_column_name=>'SEQ_ID'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Seq Id'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(121159895096653828)
,p_db_column_name=>'C001'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Tipo Venta'
,p_column_type=>'STRING'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_heading_alignment=>'LEFT'
,p_rpt_named_lov=>wwv_flow_imp.id(121710145807591205)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(121159986845653829)
,p_db_column_name=>'C002'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Nivel 01'
,p_column_type=>'STRING'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_heading_alignment=>'LEFT'
,p_rpt_named_lov=>wwv_flow_imp.id(119193859528059131)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(121160006165653830)
,p_db_column_name=>'C003'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Nivel 02'
,p_column_type=>'STRING'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_heading_alignment=>'LEFT'
,p_rpt_named_lov=>wwv_flow_imp.id(119194387269080626)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(121160116340653831)
,p_db_column_name=>'C004'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Cta. Contable'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(142693006111105406)
,p_db_column_name=>'C005'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'Obj. Costo 1'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(142693184176105407)
,p_db_column_name=>'C006'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>'Obj. Costo 2'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(142693220455105408)
,p_db_column_name=>'C007'
,p_display_order=>80
,p_column_identifier=>'H'
,p_column_label=>'Obj. Origen'
,p_column_type=>'STRING'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_heading_alignment=>'LEFT'
,p_rpt_named_lov=>wwv_flow_imp.id(142729312902456972)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(142693355072105409)
,p_db_column_name=>'C008'
,p_display_order=>90
,p_column_identifier=>'I'
,p_column_label=>'Columnas'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
,p_updated_on=>wwv_flow_imp.dz('20260224201018Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(142693402957105410)
,p_db_column_name=>'C009'
,p_display_order=>100
,p_column_identifier=>'J'
,p_column_label=>'Obj. Destino'
,p_column_type=>'STRING'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_heading_alignment=>'LEFT'
,p_rpt_named_lov=>wwv_flow_imp.id(142729312902456972)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
,p_updated_on=>wwv_flow_imp.dz('20260224201134Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(367064355969202242)
,p_db_column_name=>'C010'
,p_display_order=>120
,p_column_identifier=>'L'
,p_column_label=>'Columnas'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20260224201045Z')
,p_updated_on=>wwv_flow_imp.dz('20260224201134Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(367064443631202243)
,p_db_column_name=>'C011'
,p_display_order=>130
,p_column_identifier=>'M'
,p_column_label=>'Condicion Aux 1'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20260224201045Z')
,p_updated_on=>wwv_flow_imp.dz('20260224201134Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(367064567145202244)
,p_db_column_name=>'C012'
,p_display_order=>140
,p_column_identifier=>'N'
,p_column_label=>'Condicion Aux 2'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20260224201045Z')
,p_updated_on=>wwv_flow_imp.dz('20260224201134Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(367064655857202245)
,p_db_column_name=>'C013'
,p_display_order=>150
,p_column_identifier=>'O'
,p_column_label=>'Cta. Contable 2'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20260224201045Z')
,p_updated_on=>wwv_flow_imp.dz('20260306154921Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(367064702372202246)
,p_db_column_name=>'C014'
,p_display_order=>160
,p_column_identifier=>'P'
,p_column_label=>'C014'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20260224201045Z')
,p_updated_on=>wwv_flow_imp.dz('20260224201045Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(142693531654105411)
,p_db_column_name=>'C020'
,p_display_order=>170
,p_column_identifier=>'K'
,p_column_label=>'Comentarios'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
,p_updated_on=>wwv_flow_imp.dz('20260224201053Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(386064557202380805)
,p_db_column_name=>'BASEDISTRIBUCION'
,p_display_order=>180
,p_column_identifier=>'Q'
,p_column_label=>'Basedistribucion'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20260310164528Z')
,p_updated_on=>wwv_flow_imp.dz('20260310164528Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(121198296553751216)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'1211983'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'SEQ_ID:C001:C007:C002:C003:C004:C005:C013:C006:C020:'
,p_updated_on=>wwv_flow_imp.dz('20260326023647Z')
,p_updated_by=>'EMASABANDA'
);
wwv_flow_imp_page.create_worksheet_condition(
 p_id=>wwv_flow_imp.id(405143322670658755)
,p_report_id=>wwv_flow_imp.id(121198296553751216)
,p_name=>'Sin Base de Distribucion'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'BASEDISTRIBUCION'
,p_operator=>'='
,p_expr=>'0'
,p_condition_sql=>' (case when ("BASEDISTRIBUCION" = to_number(#APXWS_EXPR#)) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_row_bg_color=>'#ff9e9e'
,p_row_font_color=>'#ffffff'
,p_created_on=>wwv_flow_imp.dz('20260326023647Z')
,p_updated_on=>wwv_flow_imp.dz('20260326023647Z')
,p_created_by=>'EMASABANDA'
,p_updated_by=>'EMASABANDA'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(121157585138653805)
,p_plug_name=>'OtrosGatos'
,p_title=>'Otros Gatos <button type=''button'' id=''btnReglas5'' onclick=''f_setpopup(5);'' class=''t-Button t-Button--noLabel t-Button--icon js-ignoreChange''><span class=''fa fa-pencil-square-o fam-information fam-is-info''></span></button></label>'
,p_region_name=>'tbDistOtrosGastos'
,p_parent_plug_id=>wwv_flow_imp.id(118990471327315747)
,p_region_template_options=>'#DEFAULT#:t-Form--noPadding:t-Form--labelsAbove:margin-top-none:margin-bottom-none:margin-left-none:margin-right-none'
,p_plug_template=>wwv_flow_imp.id(37806762584106520)
,p_plug_display_sequence=>50
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_item_display_point=>'BELOW'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'with  ',
' wfLv1   as (SELECT distinct TRIM(DRKY) ||'' - ''|| trim(DRDL01)DESLVL,TRIM(DRKY)CODLVL FROM VT_JDE_UDC  WHERE DRSY=''09'' AND DRRT IN (''41'') AND TRIM(DRKY) IS NOT NULL)--SELECT * FROM wfLvl;',
',wfLv2   as (SELECT distinct TRIM(DRKY) ||'' - ''|| trim(DRDL01)DESLVL,TRIM(DRKY)CODLVL FROM VT_JDE_UDC  WHERE DRSY=''09'' AND DRRT IN (''42'') AND TRIM(DRKY) IS NOT NULL)--SELECT * FROM wfLvl;',
',t_datos as (SELECT   SEQ_ID,C001,C002,C003,C004,C020,c021,CLOB001 FROM APEX_COLLECTIONS c WHERE COLLECTION_NAME = ''COLECCION_REGLAS5DIST'')',
'SELECT  ',
'	SEQ_ID,  ',
'	C001,',
unistr('    (SELECT  ''''||LISTAGG(DISTINCT ''\2022    ''||trim(DESLVL), '''')WITHIN GROUP (ORDER BY to_number(CODLVL)) FROM wfLv1 L1 inner join table(pk_commons.f_dividirtexto(c002,'','')) l01 on CODLVL=item)c002,	'),
unistr('    (SELECT  ''''||LISTAGG(DISTINCT ''\2022    ''||trim(DESLVL), '''')WITHIN GROUP (ORDER BY to_number(CODLVL)) FROM wfLv2 L2 inner join table(pk_commons.f_dividirtexto(C003,'','')) l02 on CODLVL=item)C003,	'),
'	c004,',
'	C020,',
'	C021,',
'	CLOB001,',
'case when c004=''DATA.T_FINZ_DISTRIBUCIONASC'' and (trim(dbms_lob.substr(clob001, 4000, 1)) = ''null'' or CLOB001 is null or dbms_lob.getlength(CLOB001)=0)then 0 else 1 end BaseDistribucion,',
'case when c004=''DATA.T_FINZ_DISTRIBUCIONASC'' and (trim(dbms_lob.substr(C021, 4000, 1)) = ''null'' or C021 is null or length(C021)=0)then 0 else 1 end CondDistribucion,',
'case when c004=''DATA.T_FINZ_DISTRIBUCIONASC'' and ',
'	((trim(dbms_lob.substr(clob001, 4000, 1)) = ''null'' or CLOB001 is null or dbms_lob.getlength(CLOB001)=0) and (trim(dbms_lob.substr(C021, 4000, 1)) = ''null'' or C021 is null or length(C021)=0))',
'	then 0 ',
'	else 1 ',
'end BaseCondDistribucion',
'FROM t_datos  '))
,p_plug_source_type=>'NATIVE_IR'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'Otros Gatos <button type=''button'' id=''btnReglas5'' onclick=''f_setpopup(5);'' class=''t-Button t-Button--noLabel t-Button--icon js-ignoreChange''><span class=''fa fa-pencil-square-o fam-information fam-is-info''></span></button></label>'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
,p_updated_on=>wwv_flow_imp.dz('20260327021446Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(121158147371653811)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_show_finder_drop_down=>'N'
,p_report_list_mode=>'NONE'
,p_fixed_header=>'NONE'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'EMASABANDA'
,p_internal_uid=>121158147371653811
,p_updated_on=>wwv_flow_imp.dz('20260326023505Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(121160219627653832)
,p_db_column_name=>'SEQ_ID'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Seq Id'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(121160341606653833)
,p_db_column_name=>'C001'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Tipo Venta'
,p_column_type=>'STRING'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_rpt_named_lov=>wwv_flow_imp.id(121710145807591205)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
,p_updated_on=>wwv_flow_imp.dz('20260309141808Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(121160473725653834)
,p_db_column_name=>'C002'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Nivel 01'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_use_as_row_header=>'N'
,p_updated_on=>wwv_flow_imp.dz('20260309141808Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(121160531456653835)
,p_db_column_name=>'C003'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Nivel 02'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_use_as_row_header=>'N'
,p_updated_on=>wwv_flow_imp.dz('20260309141808Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(121160630450653836)
,p_db_column_name=>'C004'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Obj. Origen'
,p_column_type=>'STRING'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_rpt_named_lov=>wwv_flow_imp.id(142729312902456972)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
,p_updated_on=>wwv_flow_imp.dz('20260310161108Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(142694415309105420)
,p_db_column_name=>'C020'
,p_display_order=>140
,p_column_identifier=>'K'
,p_column_label=>'Comentarios'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_use_as_row_header=>'N'
,p_updated_on=>wwv_flow_imp.dz('20260309141808Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(376253799860576948)
,p_db_column_name=>'C021'
,p_display_order=>150
,p_column_identifier=>'L'
,p_column_label=>'C021'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20260310160837Z')
,p_updated_on=>wwv_flow_imp.dz('20260310160837Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(376253896115576949)
,p_db_column_name=>'CLOB001'
,p_display_order=>160
,p_column_identifier=>'M'
,p_column_label=>'Clob001'
,p_allow_sorting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'CLOB'
,p_heading_alignment=>'LEFT'
,p_rpt_show_filter_lov=>'N'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20260310160837Z')
,p_updated_on=>wwv_flow_imp.dz('20260310160837Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(386064706847380807)
,p_db_column_name=>'BASEDISTRIBUCION'
,p_display_order=>170
,p_column_identifier=>'N'
,p_column_label=>'Basedistribucion'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20260310164719Z')
,p_updated_on=>wwv_flow_imp.dz('20260310164719Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(386064871694380808)
,p_db_column_name=>'CONDDISTRIBUCION'
,p_display_order=>180
,p_column_identifier=>'O'
,p_column_label=>'Conddistribucion'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20260310164719Z')
,p_updated_on=>wwv_flow_imp.dz('20260310164719Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(386064925823380809)
,p_db_column_name=>'BASECONDDISTRIBUCION'
,p_display_order=>190
,p_column_identifier=>'P'
,p_column_label=>'Baseconddistribucion'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20260310170544Z')
,p_updated_on=>wwv_flow_imp.dz('20260310170544Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(121198958553751220)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'1211990'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'SEQ_ID:C001:C004:C002:C003:C020:'
,p_sort_column_1=>'SEQ_ID'
,p_sort_direction_1=>'ASC'
,p_sort_column_2=>'0'
,p_sort_direction_2=>'ASC'
,p_sort_column_3=>'0'
,p_sort_direction_3=>'ASC'
,p_sort_column_4=>'0'
,p_sort_direction_4=>'ASC'
,p_sort_column_5=>'0'
,p_sort_direction_5=>'ASC'
,p_sort_column_6=>'0'
,p_sort_direction_6=>'ASC'
,p_updated_on=>wwv_flow_imp.dz('20260311171747Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_condition(
 p_id=>wwv_flow_imp.id(387695851024344838)
,p_report_id=>wwv_flow_imp.id(121198958553751220)
,p_name=>'Sin Condicion y Base Distribucion'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'BASECONDDISTRIBUCION'
,p_operator=>'='
,p_expr=>'0'
,p_condition_sql=>' (case when ("BASECONDDISTRIBUCION" = to_number(#APXWS_EXPR#)) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_row_bg_color=>'#dab8db'
,p_row_font_color=>'#ffffff'
,p_created_on=>wwv_flow_imp.dz('20260311171747Z')
,p_updated_on=>wwv_flow_imp.dz('20260311171747Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_condition(
 p_id=>wwv_flow_imp.id(387696276949344843)
,p_report_id=>wwv_flow_imp.id(121198958553751220)
,p_name=>'Sin Base de Distribucion'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'BASEDISTRIBUCION'
,p_operator=>'='
,p_expr=>'0'
,p_condition_sql=>' (case when ("BASEDISTRIBUCION" = to_number(#APXWS_EXPR#)) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_row_bg_color=>'#ff9e9e'
,p_row_font_color=>'#ffffff'
,p_created_on=>wwv_flow_imp.dz('20260311171747Z')
,p_updated_on=>wwv_flow_imp.dz('20260311171747Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_condition(
 p_id=>wwv_flow_imp.id(387696639738344843)
,p_report_id=>wwv_flow_imp.id(121198958553751220)
,p_name=>'Sin Condiciones de Distribucion'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'CONDDISTRIBUCION'
,p_operator=>'='
,p_expr=>'0'
,p_condition_sql=>' (case when ("CONDDISTRIBUCION" = to_number(#APXWS_EXPR#)) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_row_bg_color=>'#9ea4ff'
,p_created_on=>wwv_flow_imp.dz('20260311171747Z')
,p_updated_on=>wwv_flow_imp.dz('20260311171747Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(121104825216255912)
,p_plug_name=>'PYG INDUSTRIALES - CRUD - REGLAS DE DISTRIBUCION'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(38289867500120143)
,p_plug_display_sequence=>20
,p_query_type=>'TABLE'
,p_query_table=>'T_FINZ_DISTRIBUCIONRGL'
,p_include_rowid_column=>false
,p_is_editable=>true
,p_edit_operations=>'i:u:d'
,p_lost_update_check_type=>'VALUES'
,p_plug_source_type=>'NATIVE_FORM'
,p_updated_on=>wwv_flow_imp.dz('20260327033627Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(121116502404255945)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(118989930449315742)
,p_button_name=>'ATRAS'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860056812106557)
,p_button_image_alt=>'Atras'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'LEFT'
,p_button_redirect_url=>'f?p=&APP_ID.:440:&SESSION.::&DEBUG.:RR,440::'
,p_icon_css_classes=>'fa-arrow-left'
,p_updated_on=>wwv_flow_imp.dz('20260227135609Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(121117180854255946)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(118989930449315742)
,p_button_name=>'DELETE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860056812106557)
,p_button_image_alt=>'Delete'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_button_execute_validations=>'N'
,p_confirm_message=>'&APP_TEXT$DELETE_MSG!RAW.'
,p_confirm_style=>'danger'
,p_button_condition=>'P446_ID'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_icon_css_classes=>'fa-trash-o'
,p_database_action=>'DELETE'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(121117516542255946)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(118989930449315742)
,p_button_name=>'SAVE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860056812106557)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Apply Changes'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_button_condition=>'P446_ID'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_icon_css_classes=>'fa-save'
,p_database_action=>'UPDATE'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(121117918958255947)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(118989930449315742)
,p_button_name=>'CREATE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860056812106557)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Create'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_button_condition=>'P446_ID'
,p_button_condition_type=>'ITEM_IS_NULL'
,p_icon_css_classes=>'fa-save-as'
,p_database_action=>'INSERT'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(121161106172653841)
,p_button_sequence=>160
,p_button_plug_id=>wwv_flow_imp.id(118989833895315741)
,p_button_name=>'Reglas_Distribucion'
,p_button_static_id=>'btnReglasDist'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860181880106559)
,p_button_image_alt=>'Reglas Distribucion'
,p_button_position=>'COPY'
,p_button_redirect_url=>'f?p=&APP_ID.:447:&SESSION.::&DEBUG.:RR,447:P447_REGLANUMERO,P447_TITLE:&G_VALORRGN.,'
,p_updated_on=>wwv_flow_imp.dz('20260303162003Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(118990063081315743)
,p_name=>'P446_TIPO'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(121104825216255912)
,p_item_source_plug_id=>wwv_flow_imp.id(121104825216255912)
,p_prompt=>'Tipo'
,p_source=>'TIPO'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'select campo2,campo1 from table(pk_commons.f_split2table(''VTA:Venta;ASC:Asientos Contables'','':'','';''))'
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(118990122706315744)
,p_name=>'P446_VERSION1'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(121104825216255912)
,p_prompt=>'Version1'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(121105212328255916)
,p_name=>'P446_ID'
,p_source_data_type=>'NUMBER'
,p_is_required=>true
,p_is_primary_key=>true
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_imp.id(118989833895315741)
,p_item_source_plug_id=>wwv_flow_imp.id(121104825216255912)
,p_prompt=>'id'
,p_source=>'ID'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_protection_level=>'S'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_updated_on=>wwv_flow_imp.dz('20260311155834Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(121105622811255921)
,p_name=>'P446_USERCREA'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>130
,p_item_plug_id=>wwv_flow_imp.id(118989833895315741)
,p_item_source_plug_id=>wwv_flow_imp.id(121104825216255912)
,p_prompt=>'Usercrea'
,p_source=>'USERCREA'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>32
,p_cMaxlength=>25
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'NONE'
,p_updated_on=>wwv_flow_imp.dz('20260311155835Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(121106026993255924)
,p_name=>'P446_FECHCREA'
,p_source_data_type=>'TIMESTAMP'
,p_item_sequence=>140
,p_item_plug_id=>wwv_flow_imp.id(118989833895315741)
,p_item_source_plug_id=>wwv_flow_imp.id(121104825216255912)
,p_prompt=>'Fechcrea'
,p_source=>'FECHCREA'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DATE_PICKER_APEX'
,p_cSize=>32
,p_cMaxlength=>255
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'POPUP'
,p_attribute_03=>'NONE'
,p_attribute_06=>'NONE'
,p_attribute_09=>'N'
,p_attribute_11=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20260311155835Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(121106865413255938)
,p_name=>'P446_USERMODI'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>160
,p_item_plug_id=>wwv_flow_imp.id(118989833895315741)
,p_item_source_plug_id=>wwv_flow_imp.id(121104825216255912)
,p_prompt=>'Usermodi'
,p_source=>'USERMODI'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>32
,p_cMaxlength=>25
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'NONE'
,p_updated_on=>wwv_flow_imp.dz('20260311155835Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(121107236568255938)
,p_name=>'P446_FECHMODI'
,p_source_data_type=>'TIMESTAMP'
,p_item_sequence=>170
,p_item_plug_id=>wwv_flow_imp.id(118989833895315741)
,p_item_source_plug_id=>wwv_flow_imp.id(121104825216255912)
,p_prompt=>'Fechmodi'
,p_source=>'FECHMODI'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DATE_PICKER_APEX'
,p_cSize=>32
,p_cMaxlength=>255
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'POPUP'
,p_attribute_03=>'NONE'
,p_attribute_06=>'NONE'
,p_attribute_09=>'N'
,p_attribute_11=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20260311155835Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(121108442592255939)
,p_name=>'P446_DESCRIPCION'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(121104825216255912)
,p_item_source_plug_id=>wwv_flow_imp.id(121104825216255912)
,p_prompt=>'Descripcion'
,p_source=>'DESCRIPCION'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>60
,p_cMaxlength=>500
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(121108839645255939)
,p_name=>'P446_VERSION'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>210
,p_item_plug_id=>wwv_flow_imp.id(118989833895315741)
,p_item_source_plug_id=>wwv_flow_imp.id(121104825216255912)
,p_prompt=>'Version'
,p_source=>'VERSION'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>32
,p_cMaxlength=>255
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'left'
,p_attribute_04=>'decimal'
,p_updated_on=>wwv_flow_imp.dz('20260311155835Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(121109298889255940)
,p_name=>'P446_PARAMETROS'
,p_data_type=>'CLOB'
,p_source_data_type=>'CLOB'
,p_item_sequence=>180
,p_item_plug_id=>wwv_flow_imp.id(118989833895315741)
,p_item_source_plug_id=>wwv_flow_imp.id(121104825216255912)
,p_prompt=>'Parametros'
,p_source=>'PARAMETROS'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>60
,p_cHeight=>4
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
,p_updated_on=>wwv_flow_imp.dz('20260311155835Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(121109632470255940)
,p_name=>'P446_VALIDACIONES'
,p_data_type=>'CLOB'
,p_source_data_type=>'CLOB'
,p_item_sequence=>190
,p_item_plug_id=>wwv_flow_imp.id(118989833895315741)
,p_item_source_plug_id=>wwv_flow_imp.id(121104825216255912)
,p_prompt=>'Validaciones'
,p_source=>'VALIDACIONES'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>60
,p_cHeight=>4
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
,p_updated_on=>wwv_flow_imp.dz('20260311155835Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(121110060456255940)
,p_name=>'P446_REGLA1'
,p_data_type=>'CLOB'
,p_source_data_type=>'CLOB'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(118989833895315741)
,p_item_source_plug_id=>wwv_flow_imp.id(121104825216255912)
,p_prompt=>'Regla1'
,p_source=>'REGLA1'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>60
,p_cHeight=>4
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
,p_updated_on=>wwv_flow_imp.dz('20260311155835Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(121110440215255940)
,p_name=>'P446_REGLA2'
,p_data_type=>'CLOB'
,p_source_data_type=>'CLOB'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(118989833895315741)
,p_item_source_plug_id=>wwv_flow_imp.id(121104825216255912)
,p_prompt=>'Regla2'
,p_source=>'REGLA2'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>60
,p_cHeight=>4
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
,p_updated_on=>wwv_flow_imp.dz('20260311155835Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(121110847974255940)
,p_name=>'P446_REGLA3'
,p_data_type=>'CLOB'
,p_source_data_type=>'CLOB'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(118989833895315741)
,p_item_source_plug_id=>wwv_flow_imp.id(121104825216255912)
,p_prompt=>'Regla3'
,p_source=>'REGLA3'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>60
,p_cHeight=>4
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
,p_updated_on=>wwv_flow_imp.dz('20260311155835Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(121111268132255941)
,p_name=>'P446_REGLA4'
,p_data_type=>'CLOB'
,p_source_data_type=>'CLOB'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(118989833895315741)
,p_item_source_plug_id=>wwv_flow_imp.id(121104825216255912)
,p_prompt=>'Regla4'
,p_source=>'REGLA4'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>60
,p_cHeight=>4
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
,p_updated_on=>wwv_flow_imp.dz('20260311155835Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(121111664978255941)
,p_name=>'P446_REGLA5'
,p_data_type=>'CLOB'
,p_source_data_type=>'CLOB'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(118989833895315741)
,p_item_source_plug_id=>wwv_flow_imp.id(121104825216255912)
,p_prompt=>'Regla5'
,p_source=>'REGLA5'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>60
,p_cHeight=>4
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
,p_updated_on=>wwv_flow_imp.dz('20260311155835Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(121157690951653806)
,p_name=>'P446_REGLANUMERO'
,p_item_sequence=>120
,p_item_plug_id=>wwv_flow_imp.id(118989833895315741)
,p_prompt=>'Reglanumero'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_updated_on=>wwv_flow_imp.dz('20260311155835Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(361601751886728509)
,p_name=>'P446_COMPANIA'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>150
,p_item_plug_id=>wwv_flow_imp.id(118989833895315741)
,p_item_source_plug_id=>wwv_flow_imp.id(121104825216255912)
,p_item_default=>'G_COMPANIADIST'
,p_item_default_type=>'ITEM'
,p_prompt=>'Compania'
,p_source=>'COMPANIA'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_cMaxlength=>5
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_created_on=>wwv_flow_imp.dz('20260220145925Z')
,p_updated_on=>wwv_flow_imp.dz('20260311155835Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(361601870696728510)
,p_name=>'P446_REGLA6'
,p_data_type=>'CLOB'
,p_source_data_type=>'CLOB'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(118989833895315741)
,p_item_source_plug_id=>wwv_flow_imp.id(121104825216255912)
,p_prompt=>'Regla6'
,p_source=>'REGLA6'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>30
,p_cHeight=>5
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
,p_created_on=>wwv_flow_imp.dz('20260220145925Z')
,p_updated_on=>wwv_flow_imp.dz('20260311155835Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(361601965011728511)
,p_name=>'P446_REGLA7'
,p_data_type=>'CLOB'
,p_source_data_type=>'CLOB'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(118989833895315741)
,p_item_source_plug_id=>wwv_flow_imp.id(121104825216255912)
,p_prompt=>'Regla7'
,p_source=>'REGLA7'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>30
,p_cHeight=>5
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
,p_created_on=>wwv_flow_imp.dz('20260220145925Z')
,p_updated_on=>wwv_flow_imp.dz('20260311155835Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(361602041325728512)
,p_name=>'P446_REGLA8'
,p_data_type=>'CLOB'
,p_source_data_type=>'CLOB'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(118989833895315741)
,p_item_source_plug_id=>wwv_flow_imp.id(121104825216255912)
,p_prompt=>'Regla8'
,p_source=>'REGLA8'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>30
,p_cHeight=>5
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
,p_created_on=>wwv_flow_imp.dz('20260220145925Z')
,p_updated_on=>wwv_flow_imp.dz('20260311155835Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(361602867041728520)
,p_name=>'P446_NOTA'
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_imp.id(118989833895315741)
,p_item_default=>'ORI: origen, BT4: Objeto de Costo 4, MCU: unidad de negocio, RP7:RP7'
,p_prompt=>'Nota:'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_colspan=>1
,p_grid_column=>1
,p_grid_label_column_span=>0
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--stretchInputs:t-Form-fieldContainer--xlarge:margin-top-none:margin-bottom-none:margin-left-none:margin-right-none'
,p_attribute_01=>'N'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
,p_created_on=>wwv_flow_imp.dz('20260221160055Z')
,p_updated_on=>wwv_flow_imp.dz('20260311155835Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(367064809778202247)
,p_name=>'P446_MENSAJE'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(118989833895315741)
,p_prompt=>'Mensaje'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_created_on=>wwv_flow_imp.dz('20260225020746Z')
,p_updated_on=>wwv_flow_imp.dz('20260311155834Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(121685952553483246)
,p_validation_name=>'Tipo no vacio'
,p_validation_sequence=>10
,p_validation=>'P446_TIPO'
,p_validation_type=>'ITEM_NOT_NULL_OR_ZERO'
,p_error_message=>'Se requiere un valor para #LABEL#.'
,p_associated_item=>wwv_flow_imp.id(118990063081315743)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(121686073764483247)
,p_validation_name=>'Descripcion no vacio'
,p_validation_sequence=>20
,p_validation=>'P446_DESCRIPCION'
,p_validation_type=>'ITEM_NOT_NULL_OR_ZERO'
,p_error_message=>'Se requiere un valor para #LABEL#.'
,p_associated_item=>wwv_flow_imp.id(121108442592255939)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(121686114584483248)
,p_validation_name=>'REGLA1 no vacio'
,p_validation_sequence=>30
,p_validation=>'P446_REGLA1'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>'No se ha definido ninguna regla. Ingrese al menos una.'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(121160705749653837)
,p_name=>'cambio REGLA'
,p_event_sequence=>10
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P446_REGLANUMERO'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
,p_updated_on=>wwv_flow_imp.dz('20260303162004Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(121160882829653838)
,p_event_id=>wwv_flow_imp.id(121160705749653837)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>':G_VALORRGN:=:P446_REGLANUMERO;'
,p_attribute_02=>'P446_REGLANUMERO'
,p_attribute_03=>'G_VALORRGN'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20260303162003Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(121223409184878522)
,p_event_id=>wwv_flow_imp.id(121160705749653837)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'$(''#btnReglasDist'').trigger("click");',
'ocultarBarra();'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(121685636847483243)
,p_name=>'CloseDialog'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(121161106172653841)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
,p_updated_on=>wwv_flow_imp.dz('20260311154743Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(121682200231483209)
,p_event_id=>wwv_flow_imp.id(121685636847483243)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_name=>'RG-GASTOSFLETE'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>':P446_REGLA1:=:G_VALOR1;'
,p_attribute_02=>'G_VALOR1'
,p_attribute_03=>'P446_REGLA1'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
,p_client_condition_type=>'EQUALS'
,p_client_condition_element=>'P446_REGLANUMERO'
,p_client_condition_expression=>'1'
,p_updated_on=>wwv_flow_imp.dz('20260311154743Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(121685773441483244)
,p_event_id=>wwv_flow_imp.id(121685636847483243)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_name=>'RG-VENTANETA'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>':P446_REGLA2:=:G_VALOR2;'
,p_attribute_02=>'G_VALOR2'
,p_attribute_03=>'P446_REGLA2'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
,p_client_condition_type=>'EQUALS'
,p_client_condition_element=>'P446_REGLANUMERO'
,p_client_condition_expression=>'2'
,p_updated_on=>wwv_flow_imp.dz('20260311154743Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(142527658016714437)
,p_event_id=>wwv_flow_imp.id(121685636847483243)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_name=>'RG-COSTOVENTA'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>':P446_REGLA3:=:G_VALOR3;'
,p_attribute_02=>'G_VALOR3'
,p_attribute_03=>'P446_REGLA3'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
,p_client_condition_type=>'EQUALS'
,p_client_condition_element=>'P446_REGLANUMERO'
,p_client_condition_expression=>'3'
,p_updated_on=>wwv_flow_imp.dz('20260311154743Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(142693725341105413)
,p_event_id=>wwv_flow_imp.id(121685636847483243)
,p_event_result=>'TRUE'
,p_action_sequence=>50
,p_execute_on_page_init=>'N'
,p_name=>'RG-COSTOFLETE'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>':P446_REGLA4:=:G_VALOR4;'
,p_attribute_02=>'G_VALOR4'
,p_attribute_03=>'P446_REGLA4'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
,p_client_condition_type=>'EQUALS'
,p_client_condition_element=>'P446_REGLANUMERO'
,p_client_condition_expression=>'4'
,p_updated_on=>wwv_flow_imp.dz('20260311154743Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(361602216420728514)
,p_event_id=>wwv_flow_imp.id(121685636847483243)
,p_event_result=>'TRUE'
,p_action_sequence=>60
,p_execute_on_page_init=>'N'
,p_name=>'RG-OTROSGASTOS'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>':P446_REGLA5:=:G_VALOR5;'
,p_attribute_02=>'G_VALOR5'
,p_attribute_03=>'P446_REGLA5'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
,p_client_condition_type=>'EQUALS'
,p_client_condition_element=>'P446_REGLANUMERO'
,p_client_condition_expression=>'5'
,p_created_on=>wwv_flow_imp.dz('20260220152802Z')
,p_updated_on=>wwv_flow_imp.dz('20260311154743Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(121685856723483245)
,p_event_id=>wwv_flow_imp.id(121685636847483243)
,p_event_result=>'TRUE'
,p_action_sequence=>70
,p_execute_on_page_init=>'N'
,p_name=>'RefreshRglvN'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'var regiones = [',
'    "tbDistVentaNeta","tbDistCostoVenta","tbDistCostoFlete",',
'    "tbDistGastosFlete","tbDistOtrosGastos"',
'];',
'',
'regiones.forEach(function(id) {',
'    try {',
'        var region = apex.region(id);',
'        if (region) {',
'            region.refresh();',
'        }',
'    } catch (e) {',
unistr('        console.warn("No se pudo refrescar la regi\00F3n:", id);'),
'    }',
'});',
''))
,p_updated_on=>wwv_flow_imp.dz('20260311154743Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(121118736013255952)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_region_id=>wwv_flow_imp.id(121104825216255912)
,p_process_type=>'NATIVE_FORM_DML'
,p_process_name=>'Process form PYG INDUSTRIALES - CRUD - REGLAS DE DISTRIBUCION'
,p_attribute_01=>'REGION_SOURCE'
,p_attribute_05=>'Y'
,p_attribute_06=>'Y'
,p_attribute_08=>'Y'
,p_process_error_message=>unistr('Ocurri\00F3 un error al procesar la informaci\00F3n.')
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_success_message=>'Los datos se han actualizado correctamente.'
,p_internal_uid=>121118736013255952
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(118990221032315745)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Setup Interface'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'if (:G_VALORRGL is null)then :G_VALORRGL:=:P446_ID;end if;',
'if (:G_VALORRVR is null)then :G_VALORRVR:=:P446_VERSION;end if;',
':G_VALOR1:= trim(:P446_REGLA1);',
':G_VALOR2:= trim(:P446_REGLA2);',
':G_VALOR3:= trim(:P446_REGLA3);',
':G_VALOR4:= trim(:P446_REGLA4);',
':G_VALOR5:= trim(:P446_REGLA5);',
':G_VALOR6:= trim(:P446_REGLA6);',
':G_VALOR7:= trim(:P446_REGLA7);',
':G_VALOR8:= trim(:P446_REGLA8);',
':G_VALOR9:=NULL;',
'',
'IF APEX_COLLECTION.COLLECTION_EXISTS(''COLECCION_REGLAS1DIST'') THEN APEX_COLLECTION.DELETE_COLLECTION(''COLECCION_REGLAS1DIST''); END IF;',
'IF APEX_COLLECTION.COLLECTION_EXISTS(''COLECCION_REGLAS2DIST'') THEN APEX_COLLECTION.DELETE_COLLECTION(''COLECCION_REGLAS2DIST''); END IF;',
'IF APEX_COLLECTION.COLLECTION_EXISTS(''COLECCION_REGLAS3DIST'') THEN APEX_COLLECTION.DELETE_COLLECTION(''COLECCION_REGLAS3DIST''); END IF;',
'IF APEX_COLLECTION.COLLECTION_EXISTS(''COLECCION_REGLAS4DIST'') THEN APEX_COLLECTION.DELETE_COLLECTION(''COLECCION_REGLAS4DIST''); END IF;',
'IF APEX_COLLECTION.COLLECTION_EXISTS(''COLECCION_REGLAS5DIST'') THEN APEX_COLLECTION.DELETE_COLLECTION(''COLECCION_REGLAS5DIST''); END IF;',
'IF APEX_COLLECTION.COLLECTION_EXISTS(''COLECCION_REGLAS6DIST'') THEN APEX_COLLECTION.DELETE_COLLECTION(''COLECCION_REGLAS6DIST''); END IF;',
'IF APEX_COLLECTION.COLLECTION_EXISTS(''COLECCION_REGLAS7DIST'') THEN APEX_COLLECTION.DELETE_COLLECTION(''COLECCION_REGLAS7DIST''); END IF;',
'IF APEX_COLLECTION.COLLECTION_EXISTS(''COLECCION_REGLAS8DIST'') THEN APEX_COLLECTION.DELETE_COLLECTION(''COLECCION_REGLAS8DIST''); END IF;',
''))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>118990221032315745
,p_updated_on=>wwv_flow_imp.dz('20260310165729Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(121118354550255951)
,p_process_sequence=>20
,p_process_point=>'BEFORE_HEADER'
,p_region_id=>wwv_flow_imp.id(121104825216255912)
,p_process_type=>'NATIVE_FORM_INIT'
,p_process_name=>'Initialize form PYG INDUSTRIALES - CRUD - REGLAS DE DISTRIBUCION'
,p_internal_uid=>121118354550255951
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(118990353389315746)
,p_process_sequence=>30
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'SetupPage'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
':G_MENSAJE:=null;',
'IF (:P446_ID IS NULL)THEN',
'	select nvl(max(VERSION) ,0) into :P446_VERSION FROM t_finz_distribucionrgl where ID=:G_COMPANIADIST;',
'	:P446_VERSION:=nvl(:P446_VERSION,0)+1;   ',
'END IF;',
'',
':P446_VERSION1 := ''V'' || LPAD(:P446_VERSION, 5, ''0'');',
'',
'IF(:P446_REGLA1 IS NOT NULL)THEN :G_VALOR1:=:P446_REGLA1;END IF;',
'IF(:P446_REGLA2 IS NOT NULL)THEN :G_VALOR2:=:P446_REGLA2;END IF;',
'IF(:P446_REGLA3 IS NOT NULL)THEN :G_VALOR3:=:P446_REGLA3;END IF;',
'IF(:P446_REGLA4 IS NOT NULL)THEN :G_VALOR4:=:P446_REGLA4;END IF;',
'IF(:P446_REGLA5 IS NOT NULL)THEN :G_VALOR5:=:P446_REGLA5;END IF;',
'IF(:P446_REGLA6 IS NOT NULL)THEN :G_VALOR6:=:P446_REGLA6;END IF;',
'IF(:P446_REGLA7 IS NOT NULL)THEN :G_VALOR7:=:P446_REGLA7;END IF;',
'IF(:P446_REGLA8 IS NOT NULL)THEN :G_VALOR8:=:P446_REGLA8;END IF;',
'declare V_NOMBRECOLECCION varchar2(399);',
'begin',
'    FOR i IN 1..8 ',
'    LOOP',
'        V_NOMBRECOLECCION:=''COLECCION_REGLAS''||i;',
'',
'        IF NOT  APEX_COLLECTION.COLLECTION_EXISTS(V_NOMBRECOLECCION||''DIST'') THEN APEX_COLLECTION.CREATE_COLLECTION  (V_NOMBRECOLECCION||''DIST''); END IF;',
'        IF      APEX_COLLECTION.COLLECTION_EXISTS(V_NOMBRECOLECCION||''DIST'') THEN APEX_COLLECTION.TRUNCATE_COLLECTION(V_NOMBRECOLECCION||''DIST''); END IF;',
'         ',
'		FOR COLS IN ( ',
'            SELECT ',
'                ID',
'	            ,CASE i WHEN  1 THEN TO_CHAR(TIPOVENTA) WHEN  2 THEN TO_CHAR(TIPOVENTA) WHEN  3 THEN TO_CHAR(TIPOVENTA) WHEN  4 THEN TO_CHAR(TIPOVENTA) WHEN  5 THEN TO_CHAR(TIPOVENTA) ELSE NULL END C001',
'	            ,CASE i WHEN  1 THEN TO_CHAR(NIVEL01)	WHEN  2 THEN TO_CHAR(NIVEL01)	WHEN  3 THEN TO_CHAR(NIVEL01)	WHEN  4 THEN TO_CHAR(NIVEL01)	WHEN  5 THEN TO_CHAR(NIVEL01)	ELSE NULL END C002',
'	            ,CASE i WHEN  1 THEN TO_CHAR(NIVEL02)	WHEN  2 THEN TO_CHAR(NIVEL02)	WHEN  3 THEN TO_CHAR(NIVEL02)	WHEN  4 THEN TO_CHAR(NIVEL02)	WHEN  5 THEN TO_CHAR(NIVEL02)	ELSE NULL END C003',
'	            ,CASE i WHEN  1 THEN TO_CHAR(CTACONTAB)	WHEN  2 THEN TO_CHAR(CTACONTAB)	WHEN  3 THEN TO_CHAR(CTACONTAB)	WHEN  4 THEN TO_CHAR(CTACONTAB)	WHEN  5 THEN TO_CHAR(OBJORIG)	ELSE NULL END C004',
'	            ,CASE i WHEN  1 THEN TO_CHAR(CONDIC1)	WHEN  2 THEN TO_CHAR(MOTIVO)	WHEN  3 THEN TO_CHAR(TIPOORDEN)	WHEN  4 THEN TO_CHAR(OBJCST1)	WHEN  5 THEN NULL				ELSE NULL END C005',
'	            ,CASE i WHEN  1 THEN TO_CHAR(OBJORIG)	WHEN  2 THEN TO_CHAR(TIPOORDEN)	WHEN  3 THEN TO_CHAR(TIPODOCUM)	WHEN  4 THEN TO_CHAR(OBJCST2)	WHEN  5 THEN NULL				ELSE NULL END C006',
'	            ,CASE i WHEN  1 THEN TO_CHAR(COLORIG)	WHEN  2 THEN TO_CHAR(TIPODOCUM)	WHEN  3 THEN TO_CHAR(OBJORIG)	WHEN  4 THEN TO_CHAR(OBJORIG)	WHEN  5 THEN NULL				ELSE NULL END C007',
'	            ,CASE i WHEN  1 THEN TO_CHAR(OBJDEST)	WHEN  2 THEN TO_CHAR(PRECIOSAJ)	WHEN  3 THEN TO_CHAR(COLORIG)	WHEN  4 THEN TO_CHAR(COLORIG)	WHEN  5 THEN NULL				ELSE NULL END C008',
'	            ,CASE i WHEN  1 THEN TO_CHAR(COLDEST)	WHEN  2 THEN TO_CHAR(OBJORIG)	WHEN  3 THEN TO_CHAR(OBJDEST)	WHEN  4 THEN TO_CHAR(OBJDEST)	WHEN  5 THEN NULL				ELSE NULL END C009',
'	            ,CASE i WHEN  1 THEN NULL				WHEN  2 THEN TO_CHAR(COLORIG)	WHEN  3 THEN TO_CHAR(COLDEST)	WHEN  4 THEN TO_CHAR(COLDEST)	WHEN  5 THEN NULL				ELSE NULL END C010',
'	            ,CASE i WHEN  1 THEN NULL				WHEN  2 THEN TO_CHAR(OBJDEST)	WHEN  3 THEN NULL				WHEN  4 THEN TO_CHAR(CONDIC1)	WHEN  5 THEN NULL				ELSE NULL END C011',
'	            ,CASE i WHEN  1 THEN NULL				WHEN  2 THEN TO_CHAR(COLDEST)	WHEN  3 THEN NULL				WHEN  4 THEN TO_CHAR(CONDIC2)	WHEN  5 THEN NULL				ELSE NULL END C012',
'		            ,CASE i WHEN  1 THEN NULL				WHEN  2 THEN NULL				WHEN  3 THEN NULL				WHEN  4 THEN TO_CHAR(CTACONTA2)	WHEN  5 THEN NULL				ELSE NULL END C013',
'	            ,CASE i WHEN  1 THEN TO_CHAR(COMENTARI)	WHEN  2 THEN TO_CHAR(COMENTARI)	WHEN  3 THEN TO_CHAR(COMENTARI)	WHEN  4 THEN TO_CHAR(COMENTARI)	WHEN  5 THEN TO_CHAR(COMENTARI)	ELSE NULL END C020',
'				,BASEDIST',
'					,BASEDIST5',
'					,CASE i WHEN  1 THEN NULL				WHEN  2 THEN NULL				WHEN  3 THEN NULL				WHEN  4 THEN null				WHEN  5 THEN (CONDICION)	ELSE NULL END C021',
'            FROM JSON_TABLE(  ',
'				CASE i ',
'					WHEN 1 THEN :G_VALOR1',
'					WHEN 2 THEN :G_VALOR2',
'					WHEN 3 THEN :G_VALOR3',
'					WHEN 4 THEN :G_VALOR4',
'					WHEN 5 THEN :G_VALOR5',
'					WHEN 6 THEN :G_VALOR6',
'					WHEN 7 THEN :G_VALOR7',
'					WHEN 8 THEN :G_VALOR8',
'				END ,''$.MODULO[*]''',
'                COLUMNS (',
'                     ID             NUMBER         PATH ''$.ID''',
'                    ,TIPOVENTA      VARCHAR2(3999) PATH ''$.TIPOVENTA''',
'                    ,NIVEL01        VARCHAR2(3999) PATH ''$.NIVEL01''',
'                    ,NIVEL02        VARCHAR2(3999) PATH ''$.NIVEL02''',
'                    ,CTACONTAB      VARCHAR2(3999) PATH ''$.CTACONTAB''',
'	                ,CTACONTA2  VARCHAR2(3999) PATH ''$.CTACONTA2''',
'                    ,TIPOORDEN      VARCHAR2(3999) PATH ''$.TIPOORDEN''',
'                    ,TIPODOCUM      VARCHAR2(3999) PATH ''$.TIPODOCUM''',
'                    ,MOTIVO         VARCHAR2(3999) PATH ''$.MOTIVO''',
'                    ,PRECIOSAJ      VARCHAR2(3999) PATH ''$.PRECIOSAJ''',
'                    ,OBJORIG        VARCHAR2(3999) PATH ''$.OBJORIG''',
'                    ,COLORIG   		VARCHAR2(3999) PATH ''$.COLORIG''',
'                    ,OBJDEST        VARCHAR2(3999) PATH ''$.OBJDEST''',
'                    ,COLDEST   		VARCHAR2(3999) PATH ''$.COLDEST''',
'                    ,COMENTARI      VARCHAR2(3999) PATH ''$.COMENTARI''',
'',
'                    ,OBJCST1        VARCHAR2(3999) PATH ''$.OBJCST1''',
'                    ,CONDIC1        VARCHAR2(3999) PATH ''$.CONDIC1''',
'                    ,OBJCST2        VARCHAR2(3999) PATH ''$.OBJCST2''',
'                    ,CONDIC2        VARCHAR2(3999) PATH ''$.CONDIC2''',
'                    ,CTACONMCU      VARCHAR2(3999) PATH ''$.CTACONMCU''',
'                    ,CTACONOBJ      VARCHAR2(3999) PATH ''$.CTACONOBJ''',
'                    ,CTACONSUB      VARCHAR2(3999) PATH ''$.CTACONSUB'' ',
'                    ,ORIGEN       	VARCHAR2(3999) PATH ''$.ORIGEN''',
'                    ,CANAL       	VARCHAR2(3999) PATH ''$.CANAL''',
'                    ,CTAMCU       	VARCHAR2(3999) PATH ''$.CTAMCU''',
'                    ,RP7       		VARCHAR2(3999) PATH ''$.RP7''	',
'					,BASEDIST5 CLOB FORMAT JSON PATH ''$.AUXILIAR.BASEDIST''',
'					,BASEDIST 		CLOB FORMAT JSON PATH ''$.BASEDIST''',
'					,CONDICION CLOB FORMAT JSON PATH ''$.AUXILIAR.CONDICION''',
'                )',
'            ) ORDER BY ID',
'        )',
'        LOOP',
'            APEX_COLLECTION.ADD_MEMBER(',
'                p_collection_name =>V_NOMBRECOLECCION||''DIST'',',
'                p_c001 => COLS.c001,',
'	            p_c002 => COLS.c002,',
'	            p_c003 => COLS.c003,',
'	            p_c004 => COLS.c004,',
'	            p_c005 => COLS.c005,',
'	            p_c006 => COLS.c006,',
'	            p_c007 => COLS.c007,',
'	            p_c008 => COLS.c008,',
'	            p_c009 => COLS.c009,',
'	            p_c010 => COLS.c010,',
'	            p_c011 => COLS.c011,',
'	            p_c012 => COLS.c012,',
'	            p_c013 => COLS.c013,',
'	            p_c020 => COLS.c020,',
'				p_c021 => REPLACE(COLS.c021,''null'',''''),',
'				p_clob001 => CASE WHEN i=5 THEN REPLACE(COLS.BASEDIST5,''null'','''') ELSE REPLACE(COLS.BASEDIST,''null'','''') END',
'            );',
'        END LOOP;		 ',
'    END LOOP;',
'end;',
'',
''))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>118990353389315746
,p_updated_on=>wwv_flow_imp.dz('20260310163927Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp.component_end;
end;
/
