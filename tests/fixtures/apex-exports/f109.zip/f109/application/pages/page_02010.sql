prompt --application/pages/page_02010
begin
--   Manifest
--     PAGE: 02010
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>109
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_page.create_page(
 p_id=>2010
,p_name=>'Nuevo Registro'
,p_page_mode=>'MODAL'
,p_step_title=>'Nuevo Registro'
,p_autocomplete_on_off=>'OFF'
,p_javascript_code=>'var htmldb_delete_message=''"DELETE_CONFIRM_MSG"'';'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'02'
,p_created_on=>wwv_flow_imp.dz('20230714141525Z')
,p_last_updated_on=>wwv_flow_imp.dz('20220923104642Z')
,p_last_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(86147612116116038)
,p_plug_name=>'Nuevo Registro'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(37786313898106507)
,p_plug_display_sequence=>10
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'TEXT',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(86148314871116038)
,p_plug_name=>'Buttons'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(37787379178106507)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_03'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'TEXT',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(86148758470116038)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(86148314871116038)
,p_button_name=>'CANCEL'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860181880106559)
,p_button_image_alt=>'Salir'
,p_button_position=>'CLOSE'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(86148271613116038)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(86148314871116038)
,p_button_name=>'DELETE'
,p_button_action=>'REDIRECT_URL'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860181880106559)
,p_button_image_alt=>'Eliminar'
,p_button_position=>'DELETE'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'javascript:apex.confirm(htmldb_delete_message,''DELETE'');'
,p_button_execute_validations=>'N'
,p_button_condition=>'P2010_ID'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_database_action=>'DELETE'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(86148103003116038)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(86148314871116038)
,p_button_name=>'SAVE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860181880106559)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Guardar'
,p_button_position=>'NEXT'
,p_button_alignment=>'RIGHT'
,p_button_condition=>'P2010_ID'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_database_action=>'UPDATE'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(86148073562116038)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(86148314871116038)
,p_button_name=>'CREATE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860181880106559)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Crear'
,p_button_position=>'NEXT'
,p_button_alignment=>'RIGHT'
,p_button_condition=>'P2010_ID'
,p_button_condition_type=>'ITEM_IS_NULL'
,p_database_action=>'INSERT'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(85729863593745411)
,p_name=>'P2010_CUOTASUGERIDA'
,p_item_sequence=>150
,p_item_plug_id=>wwv_flow_imp.id(86147612116116038)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Cuota Sugerida'
,p_source=>'CUOTASUGERIDA'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'0'
,p_attribute_03=>'right'
,p_attribute_04=>'text'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(85729935516745412)
,p_name=>'P2010_CUOTASUGERIDA_IVA'
,p_item_sequence=>160
,p_item_plug_id=>wwv_flow_imp.id(86147612116116038)
,p_prompt=>'Cuota Sug. + IVA'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(85730029323745413)
,p_name=>'P2010_MONTOTOTAL_IVA'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(86147612116116038)
,p_prompt=>'Total + IVA'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(85730120983745414)
,p_name=>'P2010_MONTOABONO_IVA'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_imp.id(86147612116116038)
,p_prompt=>'Abono + IVA'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(86151100403116042)
,p_name=>'P2010_ID'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(86147612116116038)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Id'
,p_source=>'ID'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_label_alignment=>'RIGHT'
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_protection_level=>'S'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(86151538075116042)
,p_name=>'P2010_USERCREA'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(86147612116116038)
,p_use_cache_before_default=>'NO'
,p_source=>'USERCREA'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(86151933908116042)
,p_name=>'P2010_FECHCREA'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(86147612116116038)
,p_use_cache_before_default=>'NO'
,p_source=>'FECHCREA'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(86152726421116042)
,p_name=>'P2010_USERMODI'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(86147612116116038)
,p_use_cache_before_default=>'NO'
,p_source=>'USERMODI'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(86153124192116042)
,p_name=>'P2010_FECHMODI'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(86147612116116038)
,p_use_cache_before_default=>'NO'
,p_source=>'FECHMODI'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(86153975175116043)
,p_name=>'P2010_CODIGOCLIENTE'
,p_is_required=>true
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(86147612116116038)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Cliente'
,p_source=>'CODIGOCLIENTE'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_named_lov=>'LOV_CLIENTES_FRQ'
,p_lov=>'select CODIGO||''-''||NOMBRES as d,CODIGO   as r from VT_JDE_CLIENTE where canalalterno = ''FRQ'' and estado = 1 order by 1;'
,p_cSize=>32
,p_cMaxlength=>255
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'DIALOG'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_04=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(86154366096116043)
,p_name=>'P2010_MONTOTOTAL'
,p_is_required=>true
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(86147612116116038)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Total'
,p_source=>'MONTOTOTAL'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>32
,p_cMaxlength=>255
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'0'
,p_attribute_03=>'right'
,p_attribute_04=>'text'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(86154720065116043)
,p_name=>'P2010_VALORIVA'
,p_is_required=>true
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_imp.id(86147612116116038)
,p_use_cache_before_default=>'NO'
,p_item_default=>'12'
,p_prompt=>'% IVA'
,p_source=>'VALORIVA'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>32
,p_cMaxlength=>255
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'0'
,p_attribute_03=>'right'
,p_attribute_04=>'text'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(86155529177116043)
,p_name=>'P2010_MONTOABONO'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(86147612116116038)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Abono'
,p_format_mask=>'999G999G999G999G990D0000'
,p_source=>'MONTOABONO'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>32
,p_cMaxlength=>255
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_03=>'right'
,p_attribute_04=>'text'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(86155985952116043)
,p_name=>'P2010_FECHAINICIO'
,p_item_sequence=>130
,p_item_plug_id=>wwv_flow_imp.id(86147612116116038)
,p_use_cache_before_default=>'NO'
,p_item_default=>'sysdate'
,p_item_default_type=>'EXPRESSION'
,p_item_default_language=>'PLSQL'
,p_prompt=>'Fecha Inicio'
,p_source=>'FECHAINICIO'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>32
,p_cMaxlength=>255
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(86156384283116043)
,p_name=>'P2010_CANTPAGOS'
,p_is_required=>true
,p_item_sequence=>140
,p_item_plug_id=>wwv_flow_imp.id(86147612116116038)
,p_use_cache_before_default=>'NO'
,p_item_default=>'1'
,p_prompt=>'Pagos'
,p_source=>'CANTPAGOS'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>32
,p_cMaxlength=>255
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'1'
,p_attribute_03=>'right'
,p_attribute_04=>'text'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(86152493915116042)
,p_validation_name=>'P2010_FECHCREA must be timestamp'
,p_validation_sequence=>30
,p_validation=>'P2010_FECHCREA'
,p_validation_type=>'ITEM_IS_TIMESTAMP'
,p_error_message=>'#LABEL# must be a valid timestamp.'
,p_associated_item=>wwv_flow_imp.id(86151933908116042)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(86153646227116043)
,p_validation_name=>'P2010_FECHMODI must be timestamp'
,p_validation_sequence=>50
,p_validation=>'P2010_FECHMODI'
,p_validation_type=>'ITEM_IS_TIMESTAMP'
,p_error_message=>'#LABEL# must be a valid timestamp.'
,p_associated_item=>wwv_flow_imp.id(86153124192116042)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(86148861005116038)
,p_name=>'Cancel Dialog'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(86148758470116038)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(86149605971116038)
,p_event_id=>wwv_flow_imp.id(86148861005116038)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CANCEL'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(86117322151091114)
,p_name=>unistr('C\00E1lculo IVA')
,p_event_sequence=>20
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P2010_MONTOTOTAL,P2010_VALORIVA'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(86117495014091115)
,p_event_id=>wwv_flow_imp.id(86117322151091114)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare v_iva	number;',
'begin',
'	v_iva := 1 + (:p2010_valoriva/100);',
'	select round(v_iva*:p2010_montototal,2)',
'	into :p2010_montototal_iva',
'	from dual;',
'end;'))
,p_attribute_02=>'P2010_MONTOTOTAL,P2010_VALORIVA'
,p_attribute_03=>'P2010_MONTOTOTAL_IVA'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(85730219082745415)
,p_name=>unistr('C\00E1lculo IVA Abono')
,p_event_sequence=>30
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P2010_MONTOABONO,P2010_VALORIVA'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(85730364618745416)
,p_event_id=>wwv_flow_imp.id(85730219082745415)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare v_iva	number;',
'begin',
'	v_iva := 1 + (:p2010_valoriva/100);',
'	select round(v_iva*:p2010_montoabono,2)',
'	into :p2010_montoabono_iva',
'	from dual;',
'end;'))
,p_attribute_02=>'P2010_VALORIVA,P2010_MONTOABONO'
,p_attribute_03=>'P2010_MONTOABONO_IVA'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(85730830466745421)
,p_name=>unistr('C\00E1lculo IVA Cuota')
,p_event_sequence=>40
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P2010_CUOTASUGERIDA,P2010_VALORIVA'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(85730913021745422)
,p_event_id=>wwv_flow_imp.id(85730830466745421)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare v_iva	number;',
'begin',
'	v_iva := 1 + (:p2010_valoriva/100);',
'	select round(v_iva*:p2010_cuotasugerida,2)',
'	into :p2010_cuotasugerida_iva',
'	from dual;',
'end;'))
,p_attribute_02=>'P2010_VALORIVA,P2010_CUOTASUGERIDA'
,p_attribute_03=>'P2010_CUOTASUGERIDA_IVA'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(85730637367745419)
,p_name=>'Cuota Sugerida'
,p_event_sequence=>50
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P2010_MONTOTOTAL,P2010_MONTOABONO,P2010_CANTPAGOS,P2010_VALORIVA'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(85730731596745420)
,p_event_id=>wwv_flow_imp.id(85730637367745419)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'v_cuota	number;',
'v_saldo	number;',
'v_iva	number;',
'begin',
'	v_iva := 1 + (:p2010_valoriva/100);',
'',
'	select nvl(:p2010_montototal,0) - nvl(:p2010_montoabono,0)',
'	into v_saldo',
'	from dual;',
'',
'	select v_saldo/:p2010_cantpagos',
'	into v_cuota',
'	from dual;',
'',
'	:p2010_cuotasugerida 		:= round(v_cuota,2);',
'end;'))
,p_attribute_02=>'P2010_MONTOTOTAL,P2010_MONTOABONO,P2010_CANTPAGOS,P2010_VALORIVA'
,p_attribute_03=>'P2010_CUOTASUGERIDA'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(86157182791116045)
,p_process_sequence=>10
,p_process_point=>'AFTER_HEADER'
,p_process_type=>'NATIVE_FORM_FETCH'
,p_process_name=>'Fetch Row from T_FINZ_AMORTIZACIONFEEFRQ'
,p_attribute_02=>'T_FINZ_AMORTIZACIONFEEFRQ'
,p_attribute_03=>'P2010_ID'
,p_attribute_04=>'ID'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>86157182791116045
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(86157531386116045)
,p_process_sequence=>30
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_FORM_PROCESS'
,p_process_name=>'Process Row of T_FINZ_AMORTIZACIONFEEFRQ'
,p_attribute_02=>'T_FINZ_AMORTIZACIONFEEFRQ'
,p_attribute_03=>'P2010_ID'
,p_attribute_04=>'ID'
,p_attribute_11=>'I:U:D'
,p_attribute_12=>'Y'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_success_message=>'Action Processed.'
,p_internal_uid=>86157531386116045
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(86157985971116046)
,p_process_sequence=>40
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_SESSION_STATE'
,p_process_name=>'reset page'
,p_attribute_01=>'CLEAR_CACHE_CURRENT_PAGE'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(86148271613116038)
,p_internal_uid=>86157985971116046
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(86158347281116046)
,p_process_sequence=>50
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_CLOSE_WINDOW'
,p_process_name=>'Close Dialog'
,p_attribute_02=>'N'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>'CREATE,SAVE,DELETE'
,p_process_when_type=>'REQUEST_IN_CONDITION'
,p_internal_uid=>86158347281116046
);
wwv_flow_imp.component_end;
end;
/
