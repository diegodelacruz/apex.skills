prompt --application/pages/page_00111
begin
--   Manifest
--     PAGE: 00111
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>109
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_page.create_page(
 p_id=>111
,p_name=>'Solicitud de Bloqueo de Pagos'
,p_step_title=>'Solicitud de Bloqueo de Pagos'
,p_autocomplete_on_off=>'OFF'
,p_javascript_code_onload=>'$(regOcultos).hide();'
,p_page_template_options=>'#DEFAULT#'
,p_page_component_map=>'18'
,p_created_on=>wwv_flow_imp.dz('20240105162553Z')
,p_last_updated_on=>wwv_flow_imp.dz('20250326160547Z')
,p_last_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(640192875162655872)
,p_plug_name=>'Facturas Pendientes'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(37806762584106520)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select apex_item.checkbox(1,y.rowid,''class="chkF01"'') seleccion',
'--	, apex_item.checkbox(1, trim(rpvinv)||rplnid,''class="chkF01"'') seleccion',
'	, y.rowid',
'	, trim(rpvinv)||rplnid id',
'	, rpkco compania',
'	, rpdoc numerodocumento',
'	, rpdct tipodocumento',
'	, rpan8 proveedor',
'	, pk_commons.f_jde2g(rpdivj) fechafactura',
'	, rpvinv numerofacturaproveedor',
'	, rppo numeroordencompra',
'	, rppdct tipoordencompra',
'	, pk_commons.f_jde2g(rpddj) fechavencimiento',
'	, rpag/100 montototal',
'	, rpaap/100 montopendiente',
'	, rplnid linea',
'	, (select x.nroinforme from dp.v_pr_resumen x where y.rpkco = x.compania and y.rppo = substr(x.ordencompra,1,8) and y.rppdct = substr(x.ordencompra,10,2) and rownum = 1) informe_rechazo',
'from f0411@jdedtadl y',
'where 1 = 1',
'	and y.rppst = ''H''',
'	and rppdct in (''BN'',''BM'',''CM'',''CN'',''OD'',''OI'',''  '')',
'	and (trim(rpvinv) = :p111_factura or :p111_factura is null)',
'	and (rpan8 = :p111_proveedor or :p111_proveedor is null)',
'	and (rppo = :p111_num_oc or :p111_num_oc is null)',
'	and rpddj between pk_commons.f_g2jde(:p111_fechainicio) and pk_commons.f_g2jde(:p111_fechafin)',
'	and y.rowid not in (select nvl(rid,rowid) from t_finz_retencionpagos where estado in (''INGRESADO'',''EN_PROCESO'',''BLOQUEADO'',''DESBLOQUEADO''))',
'order by trim(rpvinv)||rplnid '))
,p_plug_source_type=>'NATIVE_IR'
,p_ajax_items_to_submit=>'P111_FACTURA,P111_PROVEEDOR,P111_NUM_OC,P111_FECHAINICIO,P111_FECHAFIN'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>210
,p_prn_height=>297
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_updated_on=>wwv_flow_imp.dz('20250326160516Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(674225704896564349)
,p_max_row_count=>'10000'
,p_max_rows_per_page=>'10'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_control_break=>'N'
,p_show_highlight=>'N'
,p_show_computation=>'N'
,p_show_aggregate=>'N'
,p_show_chart=>'N'
,p_show_group_by=>'N'
,p_show_pivot=>'N'
,p_show_flashback=>'N'
,p_show_help=>'N'
,p_download_formats=>'XLSX'
,p_enable_mail_download=>'N'
,p_owner=>'CVACA'
,p_internal_uid=>674225704896564349
,p_updated_on=>wwv_flow_imp.dz('20250326160516Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(338237948042422851)
,p_db_column_name=>'SELECCION'
,p_display_order=>10
,p_column_identifier=>'L'
,p_column_label=>'-'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(338238365886422851)
,p_db_column_name=>'LINEA'
,p_display_order=>20
,p_column_identifier=>'M'
,p_column_label=>'Linea'
,p_column_type=>'NUMBER'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(338234348982422848)
,p_db_column_name=>'COMPANIA'
,p_display_order=>30
,p_column_identifier=>'A'
,p_column_label=>unistr('Compa\00F1\00EDa')
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(338234794156422848)
,p_db_column_name=>'NUMERODOCUMENTO'
,p_display_order=>40
,p_column_identifier=>'B'
,p_column_label=>'# Documento'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(338235105307422848)
,p_db_column_name=>'TIPODOCUMENTO'
,p_display_order=>50
,p_column_identifier=>'C'
,p_column_label=>'Tipo Doc'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(338235507202422850)
,p_db_column_name=>'PROVEEDOR'
,p_display_order=>60
,p_column_identifier=>'D'
,p_column_label=>'Proveedor'
,p_column_type=>'NUMBER'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_rpt_named_lov=>wwv_flow_imp.id(336850420560858390)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(338235901629422850)
,p_db_column_name=>'NUMEROFACTURAPROVEEDOR'
,p_display_order=>70
,p_column_identifier=>'F'
,p_column_label=>'Factura'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(338236331104422850)
,p_db_column_name=>'NUMEROORDENCOMPRA'
,p_display_order=>80
,p_column_identifier=>'G'
,p_column_label=>'Orden Compra'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(338236742937422850)
,p_db_column_name=>'TIPOORDENCOMPRA'
,p_display_order=>90
,p_column_identifier=>'H'
,p_column_label=>'TOC'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(338237180000422850)
,p_db_column_name=>'MONTOTOTAL'
,p_display_order=>100
,p_column_identifier=>'J'
,p_column_label=>'Total'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G990D00'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(338237506196422851)
,p_db_column_name=>'MONTOPENDIENTE'
,p_display_order=>110
,p_column_identifier=>'K'
,p_column_label=>'Pendiente'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G990D00'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(338233153532422846)
,p_db_column_name=>'ID'
,p_display_order=>130
,p_column_identifier=>'N'
,p_column_label=>'Id'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(337501711868323026)
,p_db_column_name=>'INFORME_RECHAZO'
,p_display_order=>140
,p_column_identifier=>'Q'
,p_column_label=>'Inf. Rechazo'
,p_column_link=>'http://jasper.zaimella.com:8080/ReportesZAI/report?_repName=Calidad/rpt_ProductoRechazado&_repFormat=pdf&_dataSource=default&_outFilename=&_repLocale=en_US&_repEncoding=UTF-8&prmID=#INFORME_RECHAZO#'
,p_column_linktext=>'#INFORME_RECHAZO#'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'NUMBER'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(85321186252939437)
,p_db_column_name=>'FECHAFACTURA'
,p_display_order=>150
,p_column_identifier=>'R'
,p_column_label=>'Fecha'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_format_mask=>'dd/mm/yyyy'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(85321223097939438)
,p_db_column_name=>'FECHAVENCIMIENTO'
,p_display_order=>160
,p_column_identifier=>'S'
,p_column_label=>'Vence'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_format_mask=>'dd/mm/yyyy'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(148145127347932338)
,p_db_column_name=>'ROWID'
,p_display_order=>170
,p_column_identifier=>'T'
,p_column_label=>'Rowid'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(674386505924386438)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'3382387'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_display_rows=>10
,p_report_columns=>'SELECCION:LINEA:PROVEEDOR:NUMEROORDENCOMPRA:TIPOORDENCOMPRA:NUMEROFACTURAPROVEEDOR:MONTOTOTAL:MONTOPENDIENTE::INFORME_RECHAZO'
,p_break_on=>'0:0:0:0:0'
,p_break_enabled_on=>'0:0:0:0:0'
,p_created_on=>wwv_flow_imp.dz('20240105162553Z')
,p_updated_on=>wwv_flow_imp.dz('20240105162553Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(649023592025697406)
,p_plug_name=>'Ocultos'
,p_region_name=>'regOcultos'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(38289867500120143)
,p_plug_display_sequence=>160
,p_include_in_reg_disp_sel_yn=>'Y'
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
,p_created_on=>wwv_flow_imp.dz('20250326155329Z')
,p_updated_on=>wwv_flow_imp.dz('20250326155524Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(674467427308612654)
,p_plug_name=>unistr('Filtros de B\00FAsqueda')
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(38289867500120143)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
,p_updated_on=>wwv_flow_imp.dz('20250326155705Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(674688006898174679)
,p_plug_name=>'Solicitud de Bloqueo de Pagos'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(95503811913299190)
,p_plug_display_sequence=>50
,p_include_in_reg_disp_sel_yn=>'Y'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select id',
'	, compania',
'	, codigoproveedor',
'	, ordendecompra',
'	, numerofactura',
'	, fechasolicitud',
'	, fechaestimada fecha_estimada_desbloqueo',
'	, fechadesbloqueo',
'	, fechabloqueo',
'	, aprobador',
'	, solicitante',
'	, estado',
'	, tipoordencompra',
'	, motivo',
'	, id_proceso',
'	, montototal',
'	, montopendiente',
'	, montobloqueo ',
'from t_finz_retencionpagos where id_proceso = :p111_id_proceso and estado = ''INGRESADO'';'))
,p_plug_source_type=>'NATIVE_IG'
,p_ajax_items_to_submit=>'P111_ID_PROCESO'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(674688152094174681)
,p_name=>'ID'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'ID'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>true
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>'ID'
,p_heading_alignment=>'CENTER'
,p_display_sequence=>30
,p_value_alignment=>'CENTER'
,p_attribute_05=>'BOTH'
,p_is_required=>true
,p_max_length=>25
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>true
,p_include_in_export=>true
,p_readonly_condition_type=>'ALWAYS'
,p_readonly_for_each_row=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(674688291442174682)
,p_name=>'COMPANIA'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'COMPANIA'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>true
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>'Compania'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>40
,p_value_alignment=>'LEFT'
,p_attribute_05=>'BOTH'
,p_is_required=>false
,p_max_length=>5
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_include_in_export=>true
,p_readonly_condition_type=>'ALWAYS'
,p_readonly_for_each_row=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(674688350449174683)
,p_name=>'CODIGOPROVEEDOR'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'CODIGOPROVEEDOR'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>true
,p_item_type=>'NATIVE_NUMBER_FIELD'
,p_heading=>'Codigoproveedor'
,p_heading_alignment=>'RIGHT'
,p_display_sequence=>50
,p_value_alignment=>'RIGHT'
,p_attribute_03=>'right'
,p_attribute_04=>'text'
,p_is_required=>false
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_include_in_export=>true
,p_readonly_condition_type=>'ALWAYS'
,p_readonly_for_each_row=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(674688545792174684)
,p_name=>'ORDENDECOMPRA'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'ORDENDECOMPRA'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>true
,p_item_type=>'NATIVE_NUMBER_FIELD'
,p_heading=>'Orden Compra'
,p_heading_alignment=>'CENTER'
,p_display_sequence=>60
,p_value_alignment=>'CENTER'
,p_attribute_03=>'right'
,p_attribute_04=>'text'
,p_is_required=>false
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_include_in_export=>true
,p_readonly_condition_type=>'ALWAYS'
,p_readonly_for_each_row=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(674688638555174685)
,p_name=>'NUMEROFACTURA'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'NUMEROFACTURA'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>true
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>'Factura'
,p_heading_alignment=>'CENTER'
,p_display_sequence=>70
,p_value_alignment=>'CENTER'
,p_attribute_05=>'BOTH'
,p_is_required=>false
,p_max_length=>50
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_include_in_export=>true
,p_readonly_condition_type=>'ALWAYS'
,p_readonly_for_each_row=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(674688687862174686)
,p_name=>'FECHASOLICITUD'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'FECHASOLICITUD'
,p_data_type=>'DATE'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>true
,p_item_type=>'NATIVE_DATE_PICKER'
,p_heading=>'Fecha Solicitud'
,p_heading_alignment=>'CENTER'
,p_display_sequence=>80
,p_value_alignment=>'CENTER'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
,p_is_required=>false
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_date_ranges=>'ALL'
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_include_in_export=>true
,p_readonly_condition_type=>'ALWAYS'
,p_readonly_for_each_row=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(674688868362174688)
,p_name=>'FECHADESBLOQUEO'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'FECHADESBLOQUEO'
,p_data_type=>'DATE'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>true
,p_item_type=>'NATIVE_DATE_PICKER'
,p_heading=>'Fecha Desbloqueo'
,p_heading_alignment=>'CENTER'
,p_display_sequence=>90
,p_value_alignment=>'CENTER'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
,p_is_required=>false
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_date_ranges=>'ALL'
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_include_in_export=>true
,p_readonly_condition_type=>'ALWAYS'
,p_readonly_for_each_row=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(674689025691174689)
,p_name=>'FECHABLOQUEO'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'FECHABLOQUEO'
,p_data_type=>'DATE'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>true
,p_item_type=>'NATIVE_DATE_PICKER'
,p_heading=>'Fecha Bloqueo'
,p_heading_alignment=>'CENTER'
,p_display_sequence=>100
,p_value_alignment=>'CENTER'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
,p_is_required=>false
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_date_ranges=>'ALL'
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_include_in_export=>true
,p_readonly_condition_type=>'ALWAYS'
,p_readonly_for_each_row=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(674689089962174690)
,p_name=>'APROBADOR'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'APROBADOR'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>true
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>'Aprobador'
,p_heading_alignment=>'CENTER'
,p_display_sequence=>110
,p_value_alignment=>'CENTER'
,p_attribute_05=>'BOTH'
,p_is_required=>false
,p_max_length=>20
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_include_in_export=>true
,p_readonly_condition_type=>'ALWAYS'
,p_readonly_for_each_row=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(674689229337174691)
,p_name=>'SOLICITANTE'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'SOLICITANTE'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>true
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>'Solicitante'
,p_heading_alignment=>'CENTER'
,p_display_sequence=>120
,p_value_alignment=>'CENTER'
,p_attribute_05=>'BOTH'
,p_is_required=>false
,p_max_length=>20
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_include_in_export=>true
,p_readonly_condition_type=>'ALWAYS'
,p_readonly_for_each_row=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(674689280838174692)
,p_name=>'ESTADO'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'ESTADO'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>true
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>'Estado'
,p_heading_alignment=>'CENTER'
,p_display_sequence=>130
,p_value_alignment=>'CENTER'
,p_attribute_05=>'BOTH'
,p_is_required=>false
,p_max_length=>20
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_include_in_export=>true
,p_readonly_condition_type=>'ALWAYS'
,p_readonly_for_each_row=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(674689352732174693)
,p_name=>'TIPOORDENCOMPRA'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'TIPOORDENCOMPRA'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>true
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>'TOC'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>140
,p_value_alignment=>'LEFT'
,p_attribute_05=>'BOTH'
,p_is_required=>false
,p_max_length=>20
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_include_in_export=>true
,p_readonly_condition_type=>'ALWAYS'
,p_readonly_for_each_row=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(675060936472151544)
,p_name=>'MOTIVO'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'MOTIVO'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>'Motivo'
,p_heading_alignment=>'CENTER'
,p_display_sequence=>150
,p_value_alignment=>'LEFT'
,p_stretch=>'A'
,p_attribute_05=>'BOTH'
,p_is_required=>false
,p_max_length=>2000
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(675061030789151545)
,p_name=>'ID_PROCESO'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'ID_PROCESO'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>true
,p_item_type=>'NATIVE_NUMBER_FIELD'
,p_heading=>'ID Proceso'
,p_heading_alignment=>'CENTER'
,p_display_sequence=>160
,p_value_alignment=>'CENTER'
,p_attribute_03=>'right'
,p_attribute_04=>'text'
,p_is_required=>false
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_include_in_export=>true
,p_readonly_condition_type=>'ALWAYS'
,p_readonly_for_each_row=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(675061487046151550)
,p_name=>'MONTOTOTAL'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'MONTOTOTAL'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_NUMBER_FIELD'
,p_heading=>'Total'
,p_heading_alignment=>'CENTER'
,p_display_sequence=>170
,p_value_alignment=>'RIGHT'
,p_attribute_03=>'right'
,p_attribute_04=>'text'
,p_format_mask=>'FML999G999G999G999G990D00'
,p_is_required=>false
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
,p_readonly_condition_type=>'ALWAYS'
,p_readonly_for_each_row=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(675061614582151551)
,p_name=>'MONTOPENDIENTE'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'MONTOPENDIENTE'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_NUMBER_FIELD'
,p_heading=>'Pendiente'
,p_heading_alignment=>'CENTER'
,p_display_sequence=>180
,p_value_alignment=>'RIGHT'
,p_attribute_03=>'right'
,p_attribute_04=>'text'
,p_format_mask=>'FML999G999G999G999G990D00'
,p_is_required=>false
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
,p_readonly_condition_type=>'ALWAYS'
,p_readonly_for_each_row=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(675061676372151552)
,p_name=>'MONTOBLOQUEO'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'MONTOBLOQUEO'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_NUMBER_FIELD'
,p_heading=>'Bloqueo'
,p_heading_alignment=>'RIGHT'
,p_display_sequence=>190
,p_value_alignment=>'RIGHT'
,p_attribute_03=>'right'
,p_attribute_04=>'text'
,p_format_mask=>'FML999G999G999G999G990D00'
,p_is_required=>false
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(675062504304151560)
,p_name=>'FECHA_ESTIMADA_DESBLOQUEO'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'FECHA_ESTIMADA_DESBLOQUEO'
,p_data_type=>'DATE'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_DATE_PICKER'
,p_heading=>'Est. Desbloqueo'
,p_heading_alignment=>'CENTER'
,p_display_sequence=>200
,p_value_alignment=>'CENTER'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
,p_is_required=>false
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_date_ranges=>'ALL'
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(675063620790151571)
,p_name=>'APEX$ROW_ACTION'
,p_session_state_data_type=>'VARCHAR2'
,p_item_type=>'NATIVE_ROW_ACTION'
,p_display_sequence=>20
,p_use_as_row_header=>false
,p_enable_hide=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(675063738939151572)
,p_name=>'APEX$ROW_SELECTOR'
,p_session_state_data_type=>'VARCHAR2'
,p_item_type=>'NATIVE_ROW_SELECTOR'
,p_display_sequence=>10
,p_attribute_01=>'Y'
,p_attribute_02=>'Y'
,p_attribute_03=>'N'
,p_use_as_row_header=>false
,p_enable_hide=>true
);
wwv_flow_imp_page.create_interactive_grid(
 p_id=>wwv_flow_imp.id(674688122425174680)
,p_internal_uid=>674688122425174680
,p_is_editable=>true
,p_edit_operations=>'u:d'
,p_lost_update_check_type=>'VALUES'
,p_submit_checked_rows=>false
,p_lazy_loading=>false
,p_requires_filter=>false
,p_show_nulls_as=>'-'
,p_select_first_row=>true
,p_fixed_row_height=>true
,p_pagination_type=>'SCROLL'
,p_show_total_row_count=>true
,p_show_toolbar=>true
,p_toolbar_buttons=>'SEARCH_COLUMN:SEARCH_FIELD:ACTIONS_MENU:SAVE'
,p_enable_save_public_report=>false
,p_enable_subscriptions=>true
,p_enable_flashback=>true
,p_define_chart_view=>true
,p_enable_download=>true
,p_enable_mail_download=>true
,p_fixed_header=>'PAGE'
,p_show_icon_view=>false
,p_show_detail_view=>false
);
wwv_flow_imp_page.create_ig_report(
 p_id=>wwv_flow_imp.id(675066754023159557)
,p_interactive_grid_id=>wwv_flow_imp.id(674688122425174680)
,p_static_id=>'186570'
,p_type=>'PRIMARY'
,p_default_view=>'GRID'
,p_show_row_number=>false
,p_settings_area_expanded=>false
);
wwv_flow_imp_page.create_ig_report_view(
 p_id=>wwv_flow_imp.id(675066941600159558)
,p_report_id=>wwv_flow_imp.id(675066754023159557)
,p_view_type=>'GRID'
,p_stretch_columns=>false
,p_srv_exclude_null_values=>false
,p_srv_only_display_columns=>true
,p_edit_mode=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(675067430753159563)
,p_view_id=>wwv_flow_imp.id(675066941600159558)
,p_display_seq=>1
,p_column_id=>wwv_flow_imp.id(674688152094174681)
,p_is_visible=>false
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(675067860925159568)
,p_view_id=>wwv_flow_imp.id(675066941600159558)
,p_display_seq=>2
,p_column_id=>wwv_flow_imp.id(674688291442174682)
,p_is_visible=>false
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(675068350022159571)
,p_view_id=>wwv_flow_imp.id(675066941600159558)
,p_display_seq=>3
,p_column_id=>wwv_flow_imp.id(674688350449174683)
,p_is_visible=>false
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(675068883738159574)
,p_view_id=>wwv_flow_imp.id(675066941600159558)
,p_display_seq=>4
,p_column_id=>wwv_flow_imp.id(674688545792174684)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(675069362679159575)
,p_view_id=>wwv_flow_imp.id(675066941600159558)
,p_display_seq=>5
,p_column_id=>wwv_flow_imp.id(674688638555174685)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>132
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(675069886737159578)
,p_view_id=>wwv_flow_imp.id(675066941600159558)
,p_display_seq=>7
,p_column_id=>wwv_flow_imp.id(674688687862174686)
,p_is_visible=>false
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(675070756432159585)
,p_view_id=>wwv_flow_imp.id(675066941600159558)
,p_display_seq=>8
,p_column_id=>wwv_flow_imp.id(674688868362174688)
,p_is_visible=>false
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(675071273591159588)
,p_view_id=>wwv_flow_imp.id(675066941600159558)
,p_display_seq=>9
,p_column_id=>wwv_flow_imp.id(674689025691174689)
,p_is_visible=>false
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(675071776300159591)
,p_view_id=>wwv_flow_imp.id(675066941600159558)
,p_display_seq=>10
,p_column_id=>wwv_flow_imp.id(674689089962174690)
,p_is_visible=>false
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(675072300328159594)
,p_view_id=>wwv_flow_imp.id(675066941600159558)
,p_display_seq=>11
,p_column_id=>wwv_flow_imp.id(674689229337174691)
,p_is_visible=>false
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(675072778069159597)
,p_view_id=>wwv_flow_imp.id(675066941600159558)
,p_display_seq=>12
,p_column_id=>wwv_flow_imp.id(674689280838174692)
,p_is_visible=>false
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(675073296799159600)
,p_view_id=>wwv_flow_imp.id(675066941600159558)
,p_display_seq=>6
,p_column_id=>wwv_flow_imp.id(674689352732174693)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>86
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(675073773644159603)
,p_view_id=>wwv_flow_imp.id(675066941600159558)
,p_display_seq=>18
,p_column_id=>wwv_flow_imp.id(675060936472151544)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>253
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(675074294136159607)
,p_view_id=>wwv_flow_imp.id(675066941600159558)
,p_display_seq=>13
,p_column_id=>wwv_flow_imp.id(675061030789151545)
,p_is_visible=>false
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(675078224779210946)
,p_view_id=>wwv_flow_imp.id(675066941600159558)
,p_display_seq=>14
,p_column_id=>wwv_flow_imp.id(675061487046151550)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(675078717918210949)
,p_view_id=>wwv_flow_imp.id(675066941600159558)
,p_display_seq=>15
,p_column_id=>wwv_flow_imp.id(675061614582151551)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(675079201055210950)
,p_view_id=>wwv_flow_imp.id(675066941600159558)
,p_display_seq=>16
,p_column_id=>wwv_flow_imp.id(675061676372151552)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(675087013519789889)
,p_view_id=>wwv_flow_imp.id(675066941600159558)
,p_display_seq=>17
,p_column_id=>wwv_flow_imp.id(675062504304151560)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>117
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(675373746955495543)
,p_view_id=>wwv_flow_imp.id(675066941600159558)
,p_display_seq=>0
,p_column_id=>wwv_flow_imp.id(675063620790151571)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_highlight(
 p_id=>wwv_flow_imp.id(338232616944422843)
,p_view_id=>wwv_flow_imp.id(675066941600159558)
,p_execution_seq=>5
,p_name=>'motivo'
,p_column_id=>wwv_flow_imp.id(675060936472151544)
,p_background_color=>'#99FF99'
,p_condition_type=>'COLUMN'
,p_condition_column_id=>wwv_flow_imp.id(674688152094174681)
,p_condition_operator=>'NN'
,p_condition_is_case_sensitive=>false
,p_is_enabled=>true
);
wwv_flow_imp_page.create_ig_report_highlight(
 p_id=>wwv_flow_imp.id(338232687491422843)
,p_view_id=>wwv_flow_imp.id(675066941600159558)
,p_execution_seq=>10
,p_name=>'$ bloqueo'
,p_column_id=>wwv_flow_imp.id(675061676372151552)
,p_background_color=>'#99FF99'
,p_condition_type=>'COLUMN'
,p_condition_column_id=>wwv_flow_imp.id(674688152094174681)
,p_condition_operator=>'NN'
,p_condition_is_case_sensitive=>false
,p_is_enabled=>true
);
wwv_flow_imp_page.create_ig_report_highlight(
 p_id=>wwv_flow_imp.id(338232805648422843)
,p_view_id=>wwv_flow_imp.id(675066941600159558)
,p_execution_seq=>15
,p_name=>'Fecha Estimada Desbloqueo'
,p_column_id=>wwv_flow_imp.id(675062504304151560)
,p_background_color=>'#99FF99'
,p_condition_type=>'COLUMN'
,p_condition_column_id=>wwv_flow_imp.id(674688152094174681)
,p_condition_operator=>'NN'
,p_condition_is_case_sensitive=>false
,p_is_enabled=>true
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1599327144053359695)
,p_plug_name=>'Barra de acciones'
,p_region_template_options=>'#DEFAULT#:t-Form--stretchInputs'
,p_plug_template=>wwv_flow_imp.id(38289497777120142)
,p_plug_display_sequence=>40
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'REGION_POSITION_01'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(338254506487422870)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(1599327144053359695)
,p_button_name=>'AGREGAR'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860056812106557)
,p_button_image_alt=>'Agregar'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-plus'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(338254926310422870)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(1599327144053359695)
,p_button_name=>'ENVIAR_APROBAR'
,p_button_action=>'REDIRECT_APP'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860056812106557)
,p_button_image_alt=>'Enviar Aprobar'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=100:101:&SESSION.::&DEBUG.:RP:G_MODULO,G_OBJETO,G_OBJETO_ID,G_USUARIO,G_TIPO1,G_PAGINA:&APP_MODULO.,RETENCION_DE_PAGO,&P111_ID_PROCESO.,&APP_USER.,&P111_RUTA_APROBACION.,FINZP0113'
,p_button_condition=>'select * FROM T_FINZ_RETENCIONPAGOS WHERE ID_PROCESO = :P111_ID_PROCESO AND ESTADO = ''INGRESADO'' and motivo is not null and :P111_RUTA_APROBACION is not null ;'
,p_button_condition_type=>'EXISTS'
,p_icon_css_classes=>'fa fa-check-circle-o'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(338255341886422870)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(1599327144053359695)
,p_button_name=>'BUSCAR'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860056812106557)
,p_button_image_alt=>'Buscar'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-search'
,p_updated_on=>wwv_flow_imp.dz('20250326155747Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(340063852053719110)
,p_button_sequence=>50
,p_button_plug_id=>wwv_flow_imp.id(1599327144053359695)
,p_button_name=>'Regresar'
,p_button_static_id=>'btnRegresar'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860056812106557)
,p_button_image_alt=>'Regresar'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'LEFT'
,p_button_redirect_url=>'f?p=&APP_ID.:100:&SESSION.::&DEBUG.:RP::'
,p_icon_css_classes=>'fa-arrow-left'
,p_updated_on=>wwv_flow_imp.dz('20250326155747Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(102023785724309709)
,p_name=>'P111_RUTA_APROBACION'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(674688006898174679)
,p_prompt=>unistr('Ruta Aprobaci\00F3n')
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'select trim(NOMBRE) NOMBRE,  trim(TIPO1)TIPO1 from  t_admi_ruta where TIPO1 IN(''EXTERIOR'',''VENTAS'',''NACIONAL'') AND NOMBRE LIKE ''RETENCION PAGOS - %'';'
,p_lov_display_null=>'YES'
,p_lov_null_text=>'Seleccione'
,p_cHeight=>1
,p_display_when=>' select * FROM T_FINZ_RETENCIONPAGOS WHERE ID_PROCESO = :P111_ID_PROCESO AND ESTADO = ''INGRESADO''  ;'
,p_display_when_type=>'EXISTS'
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'SUBMIT'
,p_attribute_03=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(102024894455309720)
,p_name=>'P111_MENSAJE'
,p_item_sequence=>140
,p_item_plug_id=>wwv_flow_imp.id(674467427308612654)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
,p_updated_on=>wwv_flow_imp.dz('20250326155705Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(338249886389422865)
,p_name=>'P111_ID_PROCESO'
,p_item_sequence=>150
,p_item_plug_id=>wwv_flow_imp.id(649023592025697406)
,p_prompt=>'Id Proceso'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_updated_on=>wwv_flow_imp.dz('20250326155329Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(338250216113422867)
,p_name=>'P111_VALIDA1'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(674467427308612654)
,p_use_cache_before_default=>'NO'
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20250326155705Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(338250622611422867)
,p_name=>'P111_PROVEEDOR'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(674467427308612654)
,p_prompt=>'Proveedor'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_named_lov=>'LOV_MAESTRO_PROVEEDORES'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select DESCRIPCION as d,',
'       CODIGOPROVEEDOR as r',
'  from VT_JDE_MAESTROPROVEEDOR',
' order by 1'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'Seleccione'
,p_cSize=>30
,p_grid_column=>1
,p_grid_label_column_span=>1
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'POPUP'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_04=>'N'
,p_attribute_05=>'N'
,p_updated_on=>wwv_flow_imp.dz('20250326160547Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(338251055858422867)
,p_name=>'P111_FACTURA'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(674467427308612654)
,p_prompt=>'Factura'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_grid_column=>1
,p_grid_label_column_span=>1
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_updated_on=>wwv_flow_imp.dz('20250326155705Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(338251483131422867)
,p_name=>'P111_NUM_OC'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(674467427308612654)
,p_prompt=>'Orden Compra'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_updated_on=>wwv_flow_imp.dz('20250326160516Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(338251831653422867)
,p_name=>'P111_FECHAINICIO'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(674467427308612654)
,p_item_default=>'trunc(add_months(sysdate,-1),''month'')'
,p_item_default_type=>'EXPRESSION'
,p_item_default_language=>'PLSQL'
,p_prompt=>'Fecha Inicio'
,p_format_mask=>'dd/mm/yyyy'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
,p_updated_on=>wwv_flow_imp.dz('20250326155840Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(338252260013422868)
,p_name=>'P111_FECHAFIN'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_imp.id(674467427308612654)
,p_item_default=>'last_day(add_months(sysdate,1))'
,p_item_default_type=>'EXPRESSION'
,p_item_default_language=>'PLSQL'
,p_prompt=>'Fecha Fin'
,p_format_mask=>'dd/mm/yyyy'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
,p_updated_on=>wwv_flow_imp.dz('20250326155840Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(338252631751422868)
,p_name=>'P111_SELECCION'
,p_item_sequence=>170
,p_item_plug_id=>wwv_flow_imp.id(674467427308612654)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
,p_updated_on=>wwv_flow_imp.dz('20250326155705Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(338253006016422868)
,p_name=>'P111_AREA_SOLICITANTE'
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_imp.id(674467427308612654)
,p_source=>'SELECT DEPARTAMENTO FROM VT_CORP_USUARIO WHERE NOMBREUSUARIO = :APP_USER;'
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20250326155705Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(338253411177422868)
,p_name=>'P111_ENVIO_EXITO'
,p_item_sequence=>120
,p_item_plug_id=>wwv_flow_imp.id(649023592025697406)
,p_prompt=>'Envio Exito'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_updated_on=>wwv_flow_imp.dz('20250326155329Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(338253818319422868)
,p_name=>'P111_TERMINA_FLUJO'
,p_item_sequence=>130
,p_item_plug_id=>wwv_flow_imp.id(649023592025697406)
,p_prompt=>'Termina Flujo'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_updated_on=>wwv_flow_imp.dz('20250326155329Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(338248133033422864)
,p_tabular_form_region_id=>wwv_flow_imp.id(674688006898174679)
,p_validation_name=>'Control Monto'
,p_validation_sequence=>20
,p_validation=>':MONTOBLOQUEO <= :MONTOPENDIENTE'
,p_validation2=>'PLSQL'
,p_validation_type=>'EXPRESSION'
,p_error_message=>'#COLUMN_HEADER# Debe ser menor o igual al monto pendiente'
,p_associated_column=>'MONTOBLOQUEO'
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(337499967852323008)
,p_tabular_form_region_id=>wwv_flow_imp.id(674688006898174679)
,p_validation_name=>'Obligatorio Motivo'
,p_validation_sequence=>30
,p_validation=>'MOTIVO'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>'#COLUMN_HEADER# Debe ingresar un motivo'
,p_associated_column=>'MOTIVO'
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(338256927842422873)
,p_name=>'Seleccionados'
,p_event_sequence=>10
,p_triggering_element_type=>'JQUERY_SELECTOR'
,p_triggering_element=>'.chkF01'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(338257435281422873)
,p_event_id=>wwv_flow_imp.id(338256927842422873)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P111_SELECCION'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'var lineas ="";',
'apex.item("P111_SELECCION").setValue(lineas);',
'document.querySelectorAll(''.chkF01'').forEach(function(seleccion) {',
'    if(seleccion.checked){',
'        var linea = seleccion.value',
'        if(lineas==""){',
'            lineas = linea;',
'        }else{',
'            ',
'            lineas = lineas+'',''+linea;',
'        }      ',
'    }else{',
'        ',
'    }    ',
'});',
'apex.item("P111_SELECCION").setValue(lineas);',
''))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(338257853751422873)
,p_name=>'Buscar'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(338255341886422870)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(338258387614422873)
,p_event_id=>wwv_flow_imp.id(338257853751422873)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_02=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(338260126287422875)
,p_name=>unistr('A\00F1adir Seleccionados')
,p_event_sequence=>50
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(338254506487422870)
,p_condition_element=>'P111_SELECCION'
,p_triggering_condition_type=>'NOT_NULL'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(102025029590309722)
,p_event_id=>wwv_flow_imp.id(338260126287422875)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'apex.message.alert("No ha escogido ninguna factura para la solicitud");'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(103628106602029828)
,p_event_id=>wwv_flow_imp.id(338260126287422875)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare v_proceso number;',
'begin',
'    v_proceso := :p111_id_proceso;',
'',
'    if v_proceso is null then',
'		delete t_finz_retencionpagos where solicitante = :APP_USER and estado = ''INGRESADO'';commit;',
'		pk_commons.sp_apex_log(''apex.109.111.agregar'',1,''Borrar'',null,null,''delete t_finz_retencionpagos where solicitante = ''''''||:APP_USER||'''''' and estado = ''''INGRESADO''''''); commit;',
'	end if;',
'    ',
'	if v_proceso is null then',
'		select nvl(max(id_proceso),0) + 1 into v_proceso from data.t_finz_retencionpagos;',
'		:p111_id_proceso := v_proceso;',
'	end if;',
'    pk_commons.sp_apex_log(''apex.109.111.agregar'',0,''v_proceso: ''||v_proceso,null,null,null);',
'end;'))
,p_attribute_02=>'P111_ID_PROCESO'
,p_attribute_03=>'P111_ID_PROCESO'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(338261152493422876)
,p_event_id=>wwv_flow_imp.id(338260126287422875)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE ',
'v_factura	varchar2(3999);',
'v_orden		varchar2(3999);',
'v_usuario	varchar2(100);',
'v_jde_dsd	number;',
'v_jde_hst	number;',
'v_proceso	number;',
'v_app_dsc	varchar2(500);',
'v_seleccion	varchar2(1000);',
'begin',
'	:p111_mensaje	:= ''OK'';',
'	v_usuario		:= :app_user;',
'	v_seleccion		:= :p111_seleccion;',
'',
'	v_proceso := :p111_id_proceso;',
'',
'	if v_proceso is null then',
'		delete t_finz_retencionpagos where solicitante = v_usuario and estado = ''INGRESADO'';',
'		v_app_dsc := ''Borrar'';',
'		pk_commons.sp_apex_log(''apex.109.111.agregar'',1,v_app_dsc,null,null,null); commit;',
'	end if;',
'',
'	select data.pk_commons.f_g2jde(:p111_fechainicio),data.pk_commons.f_g2jde(:p111_fechafin) into v_jde_dsd,v_jde_hst from dual;',
'	v_app_dsc := ''v_proceso: ''||v_proceso||'', v_jde_dsd: ''||v_jde_dsd||'', v_jde_hst: ''||v_jde_hst;',
'	pk_commons.sp_apex_log(''apex.109.111.agregar'',2,v_app_dsc,v_seleccion,null,null); commit;',
'',
'	for facturas in (',
'		select rowid rid',
'			, trim(rpvinv)||rplnid referencia',
'			, rpkco compania',
'			, rpdoc numerodocumentojde',
'			, rpdct tipodocumentojde',
'			, rpan8 proveedor',
'			, rpdivj fechafactura',
'			, trim(rpvinv) numfacprv',
'			, trim(rppo) numordcmp',
'			, rppdct tipoordencompra',
'			, rpddj fechavencimiento',
'			, rpag/100 montototal',
'			, rpaap/100 montopendiente',
'			, rplnid linea',
'		from f0411@jdedtadl',
'		where rppst = ''H''',
'			and rppdct in (''BN'',''BM'',''CM'',''CN'',''OD'',''OI'','' '')',
'			and (trim(rpvinv) = :p111_factura or :p111_factura is null)',
'			and (rpan8 = :p111_proveedor or :p111_proveedor is null)',
'			and (rppo = :p111_num_oc or :p111_num_oc is null)',
'			and rpddj between v_jde_dsd and v_jde_hst',
'			and rowid in (select regexp_substr(v_seleccion,''[^,]+'',1,level) from dual connect by regexp_substr(v_seleccion,''[^,]+'',1,level) is not null)',
'			and rowid not in (select nvl(rid,rowid) from t_finz_retencionpagos where estado in (''INGRESADO'',''EN_PROCESO'',''BLOQUEADO''))',
'	) loop',
'		v_factura	:= case when facturas.numfacprv = '''' or facturas.numfacprv is null then ''0'' else facturas.numfacprv end;',
'		v_orden		:= case when facturas.numordcmp = '''' or facturas.numordcmp is null then ''0'' else facturas.numordcmp end;',
'',
'		v_app_dsc := ''v_orden: ''||v_orden||'', v_factura: ''||v_factura||'', rid: ''||facturas.rid;',
'		pk_commons.sp_apex_log(''apex.109.111.agregar'',3,v_app_dsc,null,null,null); commit;',
'',
'		insert into t_finz_retencionpagos (',
'			rid,referencia,compania,codigoproveedor,ordendecompra,numerofactura,fechasolicitud,fechaestimada,fechabloqueo,aprobador,solicitante,estado,tipoordencompra,',
'			id_proceso,montototal,montopendiente,montobloqueo,linea,numerodocumentojde,tipodocumentojde,id_proceso_blq',
'		) values (',
'			facturas.rid',
'			, facturas.referencia',
'			, facturas.compania',
'			, facturas.proveedor',
'			, v_orden',
'			, v_factura',
'			, sysdate',
'			, sysdate',
'			, sysdate',
'			, 0',
'			, v_usuario',
'			, ''INGRESADO''',
'			, decode(trim(facturas.tipoordencompra),'''',''  '',trim(facturas.tipoordencompra))',
'			, v_proceso',
'			, facturas.montototal',
'			, facturas.montopendiente',
'			, facturas.montototal',
'			, facturas.linea',
'			, facturas.numerodocumentojde',
'			, facturas.tipodocumentojde',
'			, v_proceso',
'		);',
'	end loop;',
'	commit;',
'	:p111_seleccion:='''';',
'end;'))
,p_attribute_02=>'P111_ID_PROCESO,P111_FECHAINICIO,P111_FECHAFIN,P111_FACTURA,P111_PROVEEDOR,P111_NUM_OC,P111_SELECCION'
,p_attribute_03=>'P111_MENSAJE,P111_SELECCION'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(338260643244422875)
,p_event_id=>wwv_flow_imp.id(338260126287422875)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_02=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(339868083990312548)
,p_event_id=>wwv_flow_imp.id(338260126287422875)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(338254926310422870)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(344510118348702301)
,p_event_id=>wwv_flow_imp.id(338260126287422875)
,p_event_result=>'TRUE'
,p_action_sequence=>50
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_FOCUS'
,p_affected_elements_type=>'COLUMN'
,p_affected_elements=>'#MOTIVO#'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(103627878137029825)
,p_event_id=>wwv_flow_imp.id(338260126287422875)
,p_event_result=>'TRUE'
,p_action_sequence=>60
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P111_SELECCION'
,p_attribute_01=>'STATIC_ASSIGNMENT'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(338261533818422876)
,p_name=>'Save_Activa Flujo Boton'
,p_event_sequence=>90
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(674688006898174679)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'NATIVE_IG|REGION TYPE|interactivegridsave'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(338262013760422876)
,p_event_id=>wwv_flow_imp.id(338261533818422876)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_02=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(344510530595702305)
,p_name=>'Save_Activa Flujo Boton_1'
,p_event_sequence=>100
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(674688006898174679)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'NATIVE_IG|REGION TYPE|interactivegridsave'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(344510666013702306)
,p_event_id=>wwv_flow_imp.id(344510530595702305)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_FOCUS'
,p_affected_elements_type=>'COLUMN'
,p_affected_elements=>'MOTIVO'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(102024371728309715)
,p_name=>'RefrescaItem'
,p_event_sequence=>130
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P111_RUTA_APROBACION'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
,p_display_when_type=>'ITEM_IS_NOT_NULL'
,p_display_when_cond=>'P111_RUTA_APROBACION'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(102024522302309717)
,p_event_id=>wwv_flow_imp.id(102024371728309715)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_01=>'P111_RUTA_APROBACION'
,p_attribute_02=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(338256095663422871)
,p_name=>unistr('Cierre di\00E1logo: env\00EDo flujo')
,p_event_sequence=>140
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(338254926310422870)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(340067071387719142)
,p_event_id=>wwv_flow_imp.id(338256095663422871)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(338254926310422870)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(338256583211422871)
,p_event_id=>wwv_flow_imp.id(338256095663422871)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P111_ENVIO_EXITO,P111_TERMINA_FLUJO'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'var trama = JSON.parse(this.data.G_RESULTADO);',
'var v_mensaje = "";',
'var isTerminoFlujo= trama.resultado.terminoFlujo;',
'apex.item( "P111_TERMINA_FLUJO" ).setValue(0);',
'apex.item( "P111_ENVIO_EXITO" ).setValue(0);',
'',
'if(this.data.G_EXITO==''true''){',
'    apex.item( "P111_ENVIO_EXITO" ).setValue(1);',
'    v_mensaje =this.data.G_MENSAJE;',
'    if(isTerminoFlujo){',
'        apex.item( "P111_TERMINA_FLUJO" ).setValue(1);',
'        v_mensaje =v_mensaje +", Termina el Flujo";',
'    }',
'    console.log("P111_ENVIO_EXITO:"+$v("P111_ENVIO_EXITO")); ',
'    console.log("P111_TERMINA_FLUJO:"+$v("P111_TERMINA_FLUJO")); ',
'    console.log("v_mensaje:"+v_mensaje); ',
'    mensajeExito(v_mensaje );',
'}',
'else{ ',
'     mensajeError(this.data.G_MENSAJE);',
'}',
''))
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(103627948414029826)
,p_event_id=>wwv_flow_imp.id(338256095663422871)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare v_usuario varchar2(20);',
'begin',
'	begin',
'		select codigousuario into v_usuario ',
'        from t_admi_ruta a inner join t_admi_rutadetalle b on a.id_ruta=b.id_ruta ',
'        where tipo1 in (''EXTERIOR'',''VENTAS'',''NACIONAL'') and tipo1 = :p111_ruta_aprobacion and rownum = 1',
'		order by orden;',
'	exception when others then v_usuario := :app_user;',
'	end;',
'    IF (:P111_ENVIO_EXITO=1)THEN',
'        if (:P111_TERMINA_FLUJO=1)then',
'    	    UPDATE T_FINZ_RETENCIONPAGOS SET APROBADOR = v_usuario, ESTADO=''APROBADO'' WHERE ID_PROCESO = :P111_ID_PROCESO;',
'    	    PK_FINZ_RETENCIONPAGOS.SP_PROCESA_BLOQUEO_APROBADO(:P111_ID_PROCESO);',
'    	    PK_FINZ_RETENCIONPAGOS.SP_NOTIFICA_BLOQUEO_APROBADO(:P111_ID_PROCESO);',
'            commit;',
'        ELSE',
'    	    update t_finz_retencionpagos set aprobador = v_usuario, ESTADO=''EN_PROCESO'' where id_proceso = :P111_ID_PROCESO;commit;',
'        end if;',
'        :P111_ID_PROCESO := null;',
'    END IF;',
'	commit;',
'	',
'end;'))
,p_attribute_02=>'P111_RUTA_APROBACION,P111_ID_PROCESO,P111_ENVIO_EXITO,P111_TERMINA_FLUJO'
,p_attribute_03=>'P111_ID_PROCESO'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(148145403346932341)
,p_event_id=>wwv_flow_imp.id(338256095663422871)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>' $(''#btnRegresar'').trigger("click");'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(337502490362323033)
,p_event_id=>wwv_flow_imp.id(338256095663422871)
,p_event_result=>'TRUE'
,p_action_sequence=>50
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_CLEAR'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(674688006898174679)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(104697884668256306)
,p_name=>'RefreshButton'
,p_event_sequence=>150
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P111_RUTA_APROBACION'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(104697944207256307)
,p_event_id=>wwv_flow_imp.id(104697884668256306)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(1599327144053359695)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(104698059978256308)
,p_event_id=>wwv_flow_imp.id(104697884668256306)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_02=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(102023858003309710)
,p_name=>'SeleccionRuta'
,p_event_sequence=>160
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P111_RUTA_APROBACION'
,p_condition_element=>'P111_RUTA_APROBACION'
,p_triggering_condition_type=>'NOT_NULL'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
,p_display_when_type=>'EXISTS'
,p_display_when_cond=>'select * FROM T_FINZ_RETENCIONPAGOS WHERE ID_PROCESO = :P111_ID_PROCESO AND ESTADO = ''INGRESADO'' and motivo is not null  ;'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(102023982045309711)
,p_event_id=>wwv_flow_imp.id(102023858003309710)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(338254926310422870)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(102024024378309712)
,p_event_id=>wwv_flow_imp.id(102023858003309710)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(338254926310422870)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(338248420554422864)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_region_id=>wwv_flow_imp.id(674688006898174679)
,p_process_type=>'NATIVE_IG_DML'
,p_process_name=>'Solicitud de Bloqueo de Pagos - Save Interactive Grid Data'
,p_attribute_01=>'REGION_SOURCE'
,p_attribute_05=>'Y'
,p_attribute_06=>'Y'
,p_attribute_08=>'Y'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_success_message=>'Datos grabados correctamente'
,p_internal_uid=>338248420554422864
);
wwv_flow_imp.component_end;
end;
/
