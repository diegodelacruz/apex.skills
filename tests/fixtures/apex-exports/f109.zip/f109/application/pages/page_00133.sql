prompt --application/pages/page_00133
begin
--   Manifest
--     PAGE: 00133
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>109
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_page.create_page(
 p_id=>133
,p_name=>'ISD/FH - Detalle de OI'
,p_alias=>unistr('DETALLE-DE-ORDEN-DE-IMPORTACI\00D3N')
,p_step_title=>'Detalle de OI'
,p_autocomplete_on_off=>'OFF'
,p_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'function formatearNumero(valor) {',
'    if (!valor) return '''';',
'',
'    var num = parseFloat(valor.toString().replace('','', ''.''));',
'    if (isNaN(num)) return valor;',
'',
'    return num.toLocaleString(''es-ES'', {',
'        minimumFractionDigits: 2,',
'        maximumFractionDigits: 2',
'    });',
'}',
'function formatearOracle(valor) {',
'    if (!valor) return ''0,00'';',
'',
'    var num = parseFloat(valor.toString().replace('','', ''.''));',
'    if (isNaN(num)) return valor;',
'',
'    return num.toLocaleString(''es-ES'', {',
'        minimumFractionDigits: 2,',
'        maximumFractionDigits: 2',
'    });',
'}',
'function generarTabla(data,tipo) {',
'    var totalValortisd = 0;',
'',
'    var html = ''<div class="t-Report t-Report--stretch t-Report--altRowsDefault">'' +',
'               ''<table class="t-Report-report">'' +',
'               ''<thead><tr>'' +',
'               ''<th>Partida Arancelaria</th>'' +',
unistr('               ''<th>C\00F3digo ISD</th>'' +'),
'               ''<th>Porcentaje ISD</th>'' +',
'               ''<th>Valor ISD</th>'' ;',
'                if (tipo===''D''){',
'                    html = html +',
'                    ''<th>Estado</th>'' +',
'                    ''<th>Fecha Auditoria</th>'' ',
'                }',
'        html = html + ''</tr></thead><tbody>'';',
'',
'    if (!data || data.length === 0) {',
'        html += ''<tr><td colspan="5" class="t-Report-cell">Sin datos</td></tr>'';',
'    } else {',
'        data.forEach(function(row) {',
'',
'            var valortisdNum = parseFloat((row.VALORTISD || ''0'').toString().replace('','', ''.''));',
'            if (!isNaN(valortisdNum)) {',
'                totalValortisd += valortisdNum;',
'            }',
'',
'            html += ''<tr>'' +',
'                ''<td class="t-Report-cell">'' + (row.PARANCELA || '''') + ''</td>'' +',
'                ''<td class="t-Report-cell u-textCenter">'' + (row.CODIGOISD || '''') + ''</td>'' +',
'                ''<td class="t-Report-cell u-textEnd">'' + formatearOracle(row.VALORPORC) + ''</td>'' +',
'                ''<td class="t-Report-cell u-textEnd">'' + formatearOracle(row.VALORTISD) + ''</td>'' ;',
'                if (tipo===''D''){',
'                        html = html + ''<td class="t-Report-cell">'' + (row.ESTADO || '''') + ''</td>'' +',
'                            ''<td class="t-Report-cell">'' + (row.FECHA || '''') + ''</td>'' ;',
'                }',
'                html = html +''</tr>'';',
'        });',
'',
'        html += ''<tr class="t-Report-rowHighlight">'' +',
'                ''<td class="t-Report-cell"><b>TOTAL</b></td>'' +',
'                ''<td></td>'' +',
'                ''<td></td>'' +',
'                ''<td class="t-Report-cell u-textEnd"><b>'' + formatearOracle(totalValortisd) + ''</b></td>'' +',
'                ''<td></td>'' +',
'                ''</tr>'';',
'    }',
'',
'    html += ''</tbody></table></div>'';',
'    return html;',
'}',
'',
'function obtenerJsonConDesc(data) {',
'    return new Promise(function(resolve, reject) {',
'        apex.server.process("GET_JSON_CON_DESC", {',
'            x01: JSON.stringify(data)',
'        }, {',
'            success: function(pData) {',
'                resolve(pData);',
'            },',
'            error: function(err) {',
'                console.error("Error AJAX:", err);',
'                reject(err);',
'            }',
'        });',
'    });',
'}',
'',
'async function pintarTablaConDesc(data,tipo) {',
'    try {',
'        const dataConDesc = await obtenerJsonConDesc(data);',
'',
'        var html = generarTabla(dataConDesc,tipo);',
'',
'        apex.region("regReporteIsd").element.empty()',
'            .html(html);',
'',
'        apex.theme.openRegion("regReporteIsd");',
'',
'    } catch (err) {',
'        console.error("Error:", err);',
'    }',
'}',
' '))
,p_javascript_code_onload=>wwv_flow_string.join(wwv_flow_t_varchar2(
'$(".t-Button.t-Button--icon.t-Button--header.t-Button--headerTree.is-active").click();',
'moverToolbar();',
'',
'let grid1 = apex.region("regDetalleImportacion").widget();',
'let actions1 = grid1.interactiveGrid("getActions");',
'actions1.hide("save");',
'$(secItems).hide();',
''))
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.t-Report-report th,',
'.t-Report-report td {',
'    padding: 6px 8px;',
'    font-size: 12px;',
'    text-align: justify;',
'}'))
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'18'
,p_last_updated_on=>wwv_flow_imp.dz('20260515142401Z')
,p_last_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(101640680976829816)
,p_plug_name=>'Barra de acciones'
,p_region_template_options=>'#DEFAULT#:t-Form--stretchInputs'
,p_plug_template=>wwv_flow_imp.id(38289497777120142)
,p_plug_display_sequence=>30
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'REGION_POSITION_01'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(101640707535829817)
,p_plug_name=>'Facturas'
,p_region_name=>'regFacturas'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(37806762584106520)
,p_plug_display_sequence=>70
,p_include_in_reg_disp_sel_yn=>'Y'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'with w_ctisd as (',
'	select idcab,idfac,aplicact,sum(mtoisds) mtoisds,sum(mtoisdn) mtoisdn',
'	from data.t_finz_calculoisddet',
'	group by idcab,idfac,aplicact',
')',
'select f.id',
'	, f.idcab',
'	, f.factura numfactura',
'	, f.ordencompra numorden',
'	, f.mtoflete',
'	, f.mtoenvio',
'	, f.mtoseguro',
'	, f.fechafac',
'	, f.fechavto',
'	, f.porcisds',
'	, f.porcisdn',
'	, nvl(f.porcisdsnvo,0) porcisdsnvo',
'	, nvl(f.porcisdnnvo,0) porcisdnnvo',
'	, f.mtofactura',
'	, f.porcfactura*100 porcfactura',
'	, f.partprovision',
'	, nvl(d.mtoisds,0) mtoisdssct',
'	, nvl(d.mtoisdn,0) mtoisdnsct',
'	, nvl(e.mtoisds,0) mtoisdscct',
'	, nvl(e.mtoisdn,0) mtoisdncct',
'	, f.ordenesadicionales',
'	, case when f.ordenesadicionales is null then null else ''<span class="fa fa-plus-square" aria-hidden="true" title="Agregar OI asociada"></span>'' end agregar_orden',
'    , ''<span class="fa fa-tasks-alt js-ver-json" '' ||''style="cursor:pointer;" '' ||''data-json="'' || apex_escape.html_attribute(F.JSONISD) || ''"></span>'' as BTN_JSON',
' ',
'from data.t_finz_calculoisdfac f',
'left join w_ctisd d on f.idcab = d.idcab and f.id = d.idfac and d.aplicact = 1',
'left join w_ctisd e on f.idcab = e.idcab and f.id = e.idfac and e.aplicact = 0',
'where f.idcab = :p133_idmesa'))
,p_plug_source_type=>'NATIVE_IR'
,p_ajax_items_to_submit=>'P133_IDMESA'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'Facturas'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(101640856456829818)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_show_search_textbox=>'N'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'C'
,p_show_control_break=>'N'
,p_show_highlight=>'N'
,p_show_computation=>'N'
,p_show_chart=>'N'
,p_show_group_by=>'N'
,p_show_pivot=>'N'
,p_show_flashback=>'N'
,p_show_help=>'N'
,p_download_formats=>'XLSX'
,p_enable_mail_download=>'N'
,p_detail_link=>'f?p=&APP_ID.:134:&SESSION.::&DEBUG.:RR,133:P134_ID:#ID#'
,p_detail_link_text=>'<img src="#IMAGE_PREFIX#app_ui/img/icons/apex-edit-page.png" class="apex-edit-page" alt="">'
,p_detail_link_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_detail_link_cond=>'P133_ESTADO'
,p_detail_link_cond2=>'INGRESADO'
,p_owner=>'NETBY3'
,p_internal_uid=>101640856456829818
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(101640946004829819)
,p_db_column_name=>'ID'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'ID'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(101641042737829820)
,p_db_column_name=>'IDCAB'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Idcab'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(102667332900249140)
,p_db_column_name=>'NUMORDEN'
,p_display_order=>30
,p_column_identifier=>'K'
,p_column_label=>unistr('N\00FAm. Orden')
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'NUMBER'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(101641168829829821)
,p_db_column_name=>'NUMFACTURA'
,p_display_order=>40
,p_column_identifier=>'C'
,p_column_label=>'Factura'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(101641297686829822)
,p_db_column_name=>'MTOFLETE'
,p_display_order=>50
,p_column_identifier=>'D'
,p_column_label=>'$ Flete'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G990D00'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(101641325291829823)
,p_db_column_name=>'MTOENVIO'
,p_display_order=>60
,p_column_identifier=>'E'
,p_column_label=>unistr('$ Env\00EDo')
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G990D00'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(101641478489829824)
,p_db_column_name=>'MTOSEGURO'
,p_display_order=>70
,p_column_identifier=>'F'
,p_column_label=>'$ Seguro'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G990D00'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(117300056729208306)
,p_db_column_name=>'MTOFACTURA'
,p_display_order=>80
,p_column_identifier=>'P'
,p_column_label=>'$ Factura'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G990D00'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(103098669619016501)
,p_db_column_name=>'FECHAFAC'
,p_display_order=>90
,p_column_identifier=>'G'
,p_column_label=>'Fecha'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_format_mask=>'dd/mm/yyyy'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(103098721906016502)
,p_db_column_name=>'FECHAVTO'
,p_display_order=>100
,p_column_identifier=>'H'
,p_column_label=>'Vence'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_format_mask=>'dd/mm/yyyy'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(102667498669249141)
,p_db_column_name=>'ORDENESADICIONALES'
,p_display_order=>130
,p_column_identifier=>'L'
,p_column_label=>'OIs Ad.'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(117300169674208307)
,p_db_column_name=>'PORCFACTURA'
,p_display_order=>170
,p_column_identifier=>'Q'
,p_column_label=>'% Fact.'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'NUMBER'
,p_column_alignment=>'CENTER'
,p_format_mask=>'999G999G999G999G990D00'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(117300227562208308)
,p_db_column_name=>'PARTPROVISION'
,p_display_order=>180
,p_column_identifier=>'R'
,p_column_label=>unistr('$ Provisi\00F3n')
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G990D00'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(102667557434249142)
,p_db_column_name=>'AGREGAR_ORDEN'
,p_display_order=>190
,p_column_identifier=>'M'
,p_column_label=>'-'
,p_column_link=>'javascript:$s(''P133_ORDENESNUEVAS'',''#ORDENESADICIONALES#'');$s(''P133_NUMFACTURA'',''#NUMFACTURA#'');'
,p_column_linktext=>'#AGREGAR_ORDEN#'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_column_alignment=>'CENTER'
,p_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_display_condition=>'P133_ESTADO'
,p_display_condition2=>'INGRESADO'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(493211380229847601)
,p_db_column_name=>'PORCISDS'
,p_display_order=>200
,p_column_identifier=>'U'
,p_column_label=>'% ISD-S'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'NUMBER'
,p_column_alignment=>'CENTER'
,p_format_mask=>'999G999G999G999G990D00'
,p_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_display_condition=>'P133_PROCESO'
,p_display_condition2=>'H'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(493211436248847602)
,p_db_column_name=>'PORCISDN'
,p_display_order=>210
,p_column_identifier=>'V'
,p_column_label=>'% ISD-N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'NUMBER'
,p_column_alignment=>'CENTER'
,p_format_mask=>'999G999G999G999G990D00'
,p_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_display_condition=>'P133_PROCESO'
,p_display_condition2=>'H'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(493211536558847603)
,p_db_column_name=>'PORCISDSNVO'
,p_display_order=>220
,p_column_identifier=>'W'
,p_column_label=>'Nvo. % ISD-S'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'NUMBER'
,p_column_alignment=>'CENTER'
,p_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_display_condition=>'P133_PROCESO'
,p_display_condition2=>'H'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(493211674741847604)
,p_db_column_name=>'PORCISDNNVO'
,p_display_order=>230
,p_column_identifier=>'X'
,p_column_label=>'Nvo. % ISD-N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'NUMBER'
,p_column_alignment=>'CENTER'
,p_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_display_condition=>'P133_PROCESO'
,p_display_condition2=>'H'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(493211753288847605)
,p_db_column_name=>'MTOISDSSCT'
,p_display_order=>240
,p_column_identifier=>'Y'
,p_column_label=>'Mto. ISD-S'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G990D00'
,p_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_display_condition=>'P133_PROCESO'
,p_display_condition2=>'H'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(493211881189847606)
,p_db_column_name=>'MTOISDNSCT'
,p_display_order=>250
,p_column_identifier=>'Z'
,p_column_label=>'Mto. ISD-N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G990D00'
,p_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_display_condition=>'P133_PROCESO'
,p_display_condition2=>'H'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(493211975759847607)
,p_db_column_name=>'MTOISDSCCT'
,p_display_order=>260
,p_column_identifier=>'AA'
,p_column_label=>'Mto. ISD-S CCT'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G990D00'
,p_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_display_condition=>'P133_PROCESO'
,p_display_condition2=>'H'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(493212029267847608)
,p_db_column_name=>'MTOISDNCCT'
,p_display_order=>270
,p_column_identifier=>'AB'
,p_column_label=>'Mto. ISD-N CCT'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G990D00'
,p_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_display_condition=>'P133_PROCESO'
,p_display_condition2=>'H'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(245337988491657132)
,p_db_column_name=>'BTN_JSON'
,p_display_order=>300
,p_column_identifier=>'AE'
,p_column_label=>'-'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(102242128033589921)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'1022422'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'NUMORDEN:NUMFACTURA:FECHAVTO:MTOFACTURA:PARTPROVISION:MTOFLETE:MTOENVIO:MTOSEGURO:PORCISDS:AGREGAR_ORDEN:PORCISDN:ORDENESADICIONALES:BTN_JSON'
,p_break_on=>'0:0:0:0:0'
,p_break_enabled_on=>'0:0:0:0:0'
,p_sum_columns_on_break=>'NOALICACT:APLICACT:MTOFACTURA:PARTPROVISION:MTOISDSSCT:MTOISDNSCT'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(101642485024829834)
,p_plug_name=>unistr('Detalle Importaci\00F3n')
,p_region_name=>'regDetalleImportacion'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(37806762584106520)
,p_plug_display_sequence=>80
,p_include_in_reg_disp_sel_yn=>'Y'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select det.id',
unistr('	, case -- Bandera que me indica qu\00E9 puedo editar en el formulario'),
'		when det.aplicafh = 0 and substr(det.tipoprd,1,2) in (''SV'',''AT'') then 1',
'		when det.aplicafh = 1 and substr(det.tipoprd,1,2) not in (''SV'',''AT'') then 2',
'		when det.aplicafh = 1 and substr(det.tipoprd,1,2) in (''SV'',''AT'') then 3',
'		else 0 end editable',
'	, det.linea',
'	, fac.factura numfact',
'	, fac.ordencompra numorden',
'	, det.cantrec',
'	, det.costouni',
'	, det.mtofactura total--det.cantrec*det.costouni total',
'	, det.porcentaje*100 porcentaje',
'	, det.mtoflete monto_flete',
'	, det.mtoenvio monto_envio',
'	, det.mtoseguro monto_seguro',
'	, det.mtofactura/*det.cantrec*det.costouni*/ - (det.mtoflete+det.mtoenvio+det.mtoseguro) fob',
'	-- , det.mtoisd valor_isd',
'	, det.mtoisds mtoisds',
'	, det.mtoisdn mtoisdn',
'	, det.aplicact',
'	, det.aplicafh',
'	, det.codproducto',
'	, prod.nombreproducto',
'	, det.tipoprd',
'	, det.partarancelaria partidaarancel',
'	, det.tipoisd',
'	-- Factor de Humedad',
'	, det.cantdesp          -- ADMT',
'	, det.cantesti valorproporcional -- GMT',
'	, det.preciounit        -- Precio Unitario (FH)',
'	, det.mtoprovision',
'	, case when det.aplicafh = 1 then det.cantdesp*det.preciounit else null end as totallinea',
'	, case when det.aplicafh = 1 then det.mtoprovision/(det.cantdesp*det.preciounit) else null end porcprovisionfactura',
'	, case when det.aplicafh = 1 then (det.cantdesp*det.preciounit)-(det.preciounit*det.cantesti) else null end costohumedad',
'	, case when det.aplicafh = 1 then ((det.cantdesp*det.preciounit)-(det.preciounit*det.cantesti))*(det.mtoprovision/(det.cantdesp*det.preciounit)) else null end costoimportacion',
'	, case when det.aplicafh = 1 then ((det.cantdesp*det.preciounit)-(det.preciounit*det.cantesti))/(det.cantdesp*det.preciounit) else null end as porccostohumedad',
'	, case when det.aplicafh = 1 then ((det.cantdesp*det.preciounit)-(det.preciounit*det.cantesti)) + (((det.cantdesp*det.preciounit)-(det.preciounit*det.cantesti))*(det.mtoprovision/(det.cantdesp*det.preciounit))) else null end factorhumedad',
'	, det.comentario',
'    , det.JSONISD, det.JSONHISISD',
'    , ''VER_JSON_ISD'' as BTN_JSONISD',
'    , ''VER_JSON_HIS'' as BTN_JSONHIS',
'    , JT.VALORPORC PORCEISD',
'from data.t_finz_calculoisddet det',
'inner join data.t_finz_calculoisdfac fac on det.idcab = fac.idcab and det.idfac = fac.id',
'inner join data.vt_jde_productos prod on det.codproducto = prod.codigoproducto',
'LEFT JOIN JSON_TABLE(',
'                         DET.jsonisd,',
'                        ''$[0]'' COLUMNS (',
'                            VALORPORC VARCHAR2(50) PATH ''$.VALORPORC''',
'                        )',
'                    ) jt ON 1 = 1',
'where det.idcab = :p133_idmesa'))
,p_plug_source_type=>'NATIVE_IG'
,p_ajax_items_to_submit=>'P133_IDMESA'
,p_plug_read_only_when_type=>'EXISTS'
,p_plug_read_only_when=>'select * from dual where :p133_estado != ''INGRESADO'''
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>unistr('Detalle Importaci\00F3n')
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
,p_plug_customized=>'1'
,p_updated_on=>wwv_flow_imp.dz('20260505212052Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(101642629957829836)
,p_name=>'ID'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'ID'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_DISPLAY_ONLY'
,p_heading=>'ID'
,p_heading_alignment=>'CENTER'
,p_display_sequence=>30
,p_value_alignment=>'CENTER'
,p_attribute_02=>'VALUE'
,p_attribute_05=>'PLAIN'
,p_enable_filter=>false
,p_filter_is_required=>false
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>false
,p_enable_hide=>true
,p_is_primary_key=>true
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(101643251437829842)
,p_name=>'CANTREC'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'CANTREC'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_NUMBER_FIELD'
,p_heading=>'Cantidad'
,p_heading_alignment=>'CENTER'
,p_display_sequence=>80
,p_value_alignment=>'RIGHT'
,p_attribute_03=>'left'
,p_attribute_04=>'decimal'
,p_is_required=>false
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
,p_readonly_condition_type=>'ALWAYS'
,p_readonly_for_each_row=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(101643335109829843)
,p_name=>'COSTOUNI'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'COSTOUNI'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_NUMBER_FIELD'
,p_heading=>'C. Unitario'
,p_heading_alignment=>'CENTER'
,p_display_sequence=>90
,p_value_alignment=>'RIGHT'
,p_attribute_03=>'left'
,p_attribute_04=>'numeric'
,p_format_mask=>'FML999G999G999G999G990D0000'
,p_is_required=>false
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
,p_readonly_condition_type=>'ALWAYS'
,p_readonly_for_each_row=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(101643454693829844)
,p_name=>'APLICACT'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'APLICACT'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_SELECT_LIST'
,p_heading=>'CT'
,p_heading_alignment=>'CENTER'
,p_display_sequence=>60
,p_value_alignment=>'CENTER'
,p_is_required=>false
,p_lov_type=>'SHARED'
,p_lov_id=>wwv_flow_imp.id(105205170216064959)
,p_lov_display_extra=>true
,p_lov_display_null=>false
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'LOV'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
,p_readonly_condition_type=>'NOT_EXISTS'
,p_readonly_condition=>'select ''x'' from dual where :editable in (1,3)'
,p_readonly_for_each_row=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(101643789107829847)
,p_name=>'TIPOPRD'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'TIPOPRD'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_SELECT_LIST'
,p_heading=>'Tipo'
,p_heading_alignment=>'CENTER'
,p_display_sequence=>110
,p_value_alignment=>'CENTER'
,p_is_required=>false
,p_lov_type=>'SHARED'
,p_lov_id=>wwv_flow_imp.id(114135955609459248)
,p_lov_display_extra=>true
,p_lov_display_null=>true
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'LOV'
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>false
,p_readonly_condition_type=>'ALWAYS'
,p_readonly_for_each_row=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(101643823569829848)
,p_name=>'NUMFACT'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'NUMFACT'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>'Factura'
,p_heading_alignment=>'CENTER'
,p_display_sequence=>120
,p_value_alignment=>'CENTER'
,p_attribute_05=>'BOTH'
,p_is_required=>true
,p_max_length=>25
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
,p_readonly_condition_type=>'ALWAYS'
,p_readonly_for_each_row=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(102665310366249120)
,p_name=>'TOTAL'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'TOTAL'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_NUMBER_FIELD'
,p_heading=>'Total'
,p_heading_alignment=>'CENTER'
,p_display_sequence=>130
,p_value_alignment=>'RIGHT'
,p_attribute_03=>'left'
,p_attribute_04=>'decimal'
,p_format_mask=>'FML999G999G999G999G990D00'
,p_is_required=>false
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
,p_readonly_condition_type=>'ALWAYS'
,p_readonly_for_each_row=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(102665442530249121)
,p_name=>'PORCENTAJE'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'PORCENTAJE'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_NUMBER_FIELD'
,p_heading=>'% part.'
,p_heading_alignment=>'CENTER'
,p_display_sequence=>160
,p_value_alignment=>'CENTER'
,p_attribute_03=>'left'
,p_attribute_04=>'numeric'
,p_format_mask=>'999G999G999G999G990D000'
,p_is_required=>false
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_lov_type=>'NONE'
,p_static_id=>'PORCENTAJE'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
,p_readonly_condition_type=>'ALWAYS'
,p_readonly_for_each_row=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(102665589160249122)
,p_name=>'MONTO_FLETE'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'MONTO_FLETE'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_NUMBER_FIELD'
,p_heading=>'Part. Flete'
,p_heading_alignment=>'CENTER'
,p_display_sequence=>170
,p_value_alignment=>'RIGHT'
,p_attribute_03=>'left'
,p_attribute_04=>'decimal'
,p_format_mask=>'FML999G999G999G999G990D00'
,p_is_required=>false
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
,p_readonly_condition_type=>'ALWAYS'
,p_readonly_for_each_row=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(102665636154249123)
,p_name=>'MONTO_ENVIO'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'MONTO_ENVIO'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_NUMBER_FIELD'
,p_heading=>unistr('Part. Env\00EDo')
,p_heading_alignment=>'CENTER'
,p_display_sequence=>180
,p_value_alignment=>'RIGHT'
,p_attribute_03=>'left'
,p_attribute_04=>'decimal'
,p_format_mask=>'FML999G999G999G999G990D00'
,p_is_required=>false
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
,p_readonly_condition_type=>'ALWAYS'
,p_readonly_for_each_row=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(102665788159249124)
,p_name=>'MONTO_SEGURO'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'MONTO_SEGURO'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_NUMBER_FIELD'
,p_heading=>'Part. Seguro'
,p_heading_alignment=>'CENTER'
,p_display_sequence=>190
,p_value_alignment=>'RIGHT'
,p_attribute_03=>'left'
,p_attribute_04=>'decimal'
,p_format_mask=>'FML999G999G999G999G990D00'
,p_is_required=>false
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
,p_readonly_condition_type=>'ALWAYS'
,p_readonly_for_each_row=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(102665897608249125)
,p_name=>'FOB'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'FOB'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_NUMBER_FIELD'
,p_heading=>'FOB'
,p_heading_alignment=>'CENTER'
,p_display_sequence=>200
,p_value_alignment=>'RIGHT'
,p_attribute_03=>'left'
,p_attribute_04=>'decimal'
,p_format_mask=>'FML999G999G999G999G990D00'
,p_is_required=>false
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
,p_readonly_condition_type=>'ALWAYS'
,p_readonly_for_each_row=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(102667088473249137)
,p_name=>'APEX$ROW_ACTION'
,p_session_state_data_type=>'VARCHAR2'
,p_item_type=>'NATIVE_ROW_ACTION'
,p_display_sequence=>20
,p_use_as_row_header=>false
,p_display_condition_type=>'NEVER'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(102667163693249138)
,p_name=>'APEX$ROW_SELECTOR'
,p_session_state_data_type=>'VARCHAR2'
,p_item_type=>'NATIVE_ROW_SELECTOR'
,p_display_sequence=>10
,p_attribute_01=>'Y'
,p_attribute_02=>'Y'
,p_attribute_03=>'N'
,p_use_as_row_header=>false
,p_display_condition_type=>'NEVER'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(102668242761249149)
,p_name=>'NUMORDEN'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'NUMORDEN'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>true
,p_item_type=>'NATIVE_NUMBER_FIELD'
,p_heading=>unistr('N\00FAm. Orden')
,p_heading_alignment=>'CENTER'
,p_display_sequence=>210
,p_value_alignment=>'CENTER'
,p_attribute_03=>'left'
,p_attribute_04=>'decimal'
,p_is_required=>false
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_include_in_export=>true
,p_readonly_condition_type=>'ALWAYS'
,p_readonly_for_each_row=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(103100590939016520)
,p_name=>'CODPRODUCTO'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'CODPRODUCTO'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_DISPLAY_ONLY'
,p_heading=>unistr('C\00F3d. Producto')
,p_heading_alignment=>'CENTER'
,p_display_sequence=>230
,p_value_alignment=>'LEFT'
,p_attribute_02=>'VALUE'
,p_attribute_05=>'PLAIN'
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(103100616006016521)
,p_name=>'CANTDESP'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'CANTDESP'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_NUMBER_FIELD'
,p_heading=>'ADMT'
,p_heading_alignment=>'CENTER'
,p_display_sequence=>250
,p_value_alignment=>'RIGHT'
,p_attribute_03=>'left'
,p_attribute_04=>'decimal'
,p_format_mask=>'999G999G999G999G990D0000'
,p_is_required=>false
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_enable_hide=>false
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
,p_display_condition_type=>'ITEM_IS_NOT_ZERO'
,p_display_condition=>'P133_BANDERA'
,p_readonly_condition_type=>'NOT_EXISTS'
,p_readonly_condition=>'select ''x'' from dual where :editable in (2,3)'
,p_readonly_for_each_row=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(103100886866016523)
,p_name=>'VALORPROPORCIONAL'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'VALORPROPORCIONAL'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_NUMBER_FIELD'
,p_heading=>'GMT'
,p_heading_alignment=>'CENTER'
,p_display_sequence=>260
,p_value_alignment=>'RIGHT'
,p_attribute_03=>'left'
,p_attribute_04=>'decimal'
,p_format_mask=>'999G999G999G999G990D0000'
,p_is_required=>false
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_enable_hide=>false
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
,p_display_condition_type=>'ITEM_IS_NOT_ZERO'
,p_display_condition=>'P133_BANDERA'
,p_readonly_condition_type=>'NOT_EXISTS'
,p_readonly_condition=>'select ''x'' from dual where :editable in (2,3)'
,p_readonly_for_each_row=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(103100957721016524)
,p_name=>'COSTOPROVISION'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'MTOPROVISION'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_NUMBER_FIELD'
,p_heading=>'Part. Prov.'
,p_heading_alignment=>'CENTER'
,p_display_sequence=>280
,p_value_alignment=>'RIGHT'
,p_attribute_03=>'left'
,p_attribute_04=>'decimal'
,p_format_mask=>'FML999G999G999G999G990D00'
,p_is_required=>false
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_enable_hide=>false
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
,p_display_condition_type=>'ITEM_IS_NOT_ZERO'
,p_display_condition=>'P133_BANDERA'
,p_readonly_condition_type=>'ALWAYS'
,p_readonly_for_each_row=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(103101491405016529)
,p_name=>'FACTORHUMEDAD'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'FACTORHUMEDAD'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>true
,p_item_type=>'NATIVE_NUMBER_FIELD'
,p_heading=>'Factor Hum.'
,p_heading_alignment=>'CENTER'
,p_display_sequence=>340
,p_value_alignment=>'RIGHT'
,p_attribute_03=>'left'
,p_attribute_04=>'decimal'
,p_format_mask=>'FML999G999G999G999G990D00'
,p_item_attributes=>'readonly'
,p_is_required=>false
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>false
,p_is_primary_key=>false
,p_include_in_export=>true
,p_display_condition_type=>'ITEM_IS_NOT_ZERO'
,p_display_condition=>'P133_BANDERA'
,p_readonly_condition_type=>'ALWAYS'
,p_readonly_for_each_row=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(103101980133016534)
,p_name=>'PRECIOUNIT'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'PRECIOUNIT'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_NUMBER_FIELD'
,p_heading=>'P. Unitario*'
,p_heading_alignment=>'CENTER'
,p_display_sequence=>270
,p_value_alignment=>'RIGHT'
,p_attribute_03=>'right'
,p_attribute_04=>'decimal'
,p_format_mask=>'999999999999990D0000'
,p_is_required=>false
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_enable_hide=>false
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
,p_display_condition_type=>'ITEM_IS_NOT_ZERO'
,p_display_condition=>'P133_BANDERA'
,p_readonly_condition_type=>'NOT_EXISTS'
,p_readonly_condition=>'select ''x'' from dual where :editable in (2,3)'
,p_readonly_for_each_row=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(106069735368168709)
,p_name=>'LINEA'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'LINEA'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_NUMBER_FIELD'
,p_heading=>'LN'
,p_heading_alignment=>'CENTER'
,p_display_sequence=>220
,p_value_alignment=>'CENTER'
,p_attribute_03=>'left'
,p_attribute_04=>'decimal'
,p_is_required=>true
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
,p_readonly_condition_type=>'ALWAYS'
,p_readonly_for_each_row=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(106070873485168720)
,p_name=>'PARTIDAARANCEL'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'PARTIDAARANCEL'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_POPUP_LOV'
,p_heading=>'P. Arancelaria'
,p_heading_alignment=>'CENTER'
,p_display_sequence=>100
,p_value_alignment=>'LEFT'
,p_attribute_01=>'DIALOG'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_04=>'N'
,p_attribute_05=>'Y'
,p_attribute_06=>'0'
,p_attribute_08=>'700'
,p_attribute_10=>'CODISD:TIPOISD'
,p_is_required=>true
,p_max_length=>10
,p_lov_type=>'SHARED'
,p_lov_id=>wwv_flow_imp.id(249302130615878860)
,p_lov_display_extra=>false
,p_lov_display_null=>false
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
,p_readonly_condition_type=>'NOT_EXISTS'
,p_readonly_condition=>'select ''x'' from dual where :editable in (1,3)'
,p_readonly_for_each_row=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(106071408237168726)
,p_name=>'NOMBREPRODUCTO'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'NOMBREPRODUCTO'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_DISPLAY_ONLY'
,p_heading=>'Producto'
,p_heading_alignment=>'CENTER'
,p_display_sequence=>240
,p_value_alignment=>'LEFT'
,p_attribute_02=>'VALUE'
,p_attribute_05=>'PLAIN'
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(117300611373208312)
,p_name=>'EDITABLE'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'EDITABLE'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>true
,p_item_type=>'NATIVE_NUMBER_FIELD'
,p_heading=>'Edit'
,p_heading_alignment=>'CENTER'
,p_display_sequence=>40
,p_value_alignment=>'CENTER'
,p_attribute_03=>'left'
,p_attribute_04=>'decimal'
,p_is_required=>false
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_include_in_export=>true
,p_readonly_condition_type=>'ALWAYS'
,p_readonly_for_each_row=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(117300793667208313)
,p_name=>'APLICAFH'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'APLICAFH'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>true
,p_item_type=>'NATIVE_SELECT_LIST'
,p_heading=>'FH'
,p_heading_alignment=>'CENTER'
,p_display_sequence=>50
,p_value_alignment=>'CENTER'
,p_is_required=>false
,p_lov_type=>'SHARED'
,p_lov_id=>wwv_flow_imp.id(105205170216064959)
,p_lov_display_extra=>false
,p_lov_display_null=>false
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_include_in_export=>true
,p_readonly_condition_type=>'ALWAYS'
,p_readonly_for_each_row=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(117300895416208314)
,p_name=>'PORCPROVISIONFACTURA'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'PORCPROVISIONFACTURA'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_NUMBER_FIELD'
,p_heading=>'% PvsF'
,p_heading_alignment=>'CENTER'
,p_display_sequence=>290
,p_value_alignment=>'CENTER'
,p_attribute_03=>'left'
,p_attribute_04=>'decimal'
,p_format_mask=>'999G999G999G999G990D0000'
,p_is_required=>false
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
,p_display_condition_type=>'ITEM_IS_NOT_ZERO'
,p_display_condition=>'P133_BANDERA'
,p_readonly_condition_type=>'ALWAYS'
,p_readonly_for_each_row=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(117300969522208315)
,p_name=>'TOTALLINEA'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'TOTALLINEA'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_NUMBER_FIELD'
,p_heading=>unistr('T. L\00EDnea')
,p_heading_alignment=>'RIGHT'
,p_display_sequence=>300
,p_value_alignment=>'RIGHT'
,p_attribute_03=>'left'
,p_attribute_04=>'decimal'
,p_format_mask=>'FML999G999G999G999G990D00'
,p_is_required=>false
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
,p_display_condition_type=>'ITEM_IS_NOT_ZERO'
,p_display_condition=>'P133_BANDERA'
,p_readonly_condition_type=>'ALWAYS'
,p_readonly_for_each_row=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(117301098021208316)
,p_name=>'COSTOHUMEDAD'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'COSTOHUMEDAD'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_NUMBER_FIELD'
,p_heading=>'Cos. Hum.'
,p_heading_alignment=>'CENTER'
,p_display_sequence=>310
,p_value_alignment=>'RIGHT'
,p_attribute_03=>'left'
,p_attribute_04=>'decimal'
,p_format_mask=>'FML999G999G999G999G990D00'
,p_is_required=>false
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
,p_display_condition_type=>'ITEM_IS_NOT_ZERO'
,p_display_condition=>'P133_BANDERA'
,p_readonly_condition_type=>'ALWAYS'
,p_readonly_for_each_row=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(117301151734208317)
,p_name=>'COSTOIMPORTACION'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'COSTOIMPORTACION'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_NUMBER_FIELD'
,p_heading=>'Cos. Imp.'
,p_heading_alignment=>'RIGHT'
,p_display_sequence=>320
,p_value_alignment=>'RIGHT'
,p_attribute_03=>'left'
,p_attribute_04=>'decimal'
,p_format_mask=>'FML999G999G999G999G990D00'
,p_is_required=>false
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
,p_display_condition_type=>'ITEM_IS_NOT_ZERO'
,p_display_condition=>'P133_BANDERA'
,p_readonly_condition_type=>'ALWAYS'
,p_readonly_for_each_row=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(117301230603208318)
,p_name=>'PORCCOSTOHUMEDAD'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'PORCCOSTOHUMEDAD'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>true
,p_item_type=>'NATIVE_NUMBER_FIELD'
,p_heading=>'% CH'
,p_heading_alignment=>'CENTER'
,p_display_sequence=>330
,p_value_alignment=>'CENTER'
,p_attribute_03=>'left'
,p_attribute_04=>'decimal'
,p_format_mask=>'999G999G999G999G990D0000'
,p_is_required=>false
,p_enable_filter=>false
,p_filter_is_required=>false
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_include_in_export=>true
,p_display_condition_type=>'ITEM_IS_NOT_ZERO'
,p_display_condition=>'P133_BANDERA'
,p_readonly_condition_type=>'ALWAYS'
,p_readonly_for_each_row=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(207050837287772033)
,p_name=>'COMENTARIO'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'COMENTARIO'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXTAREA'
,p_heading=>'Comentario'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>350
,p_value_alignment=>'LEFT'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
,p_is_required=>false
,p_max_length=>1000
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(245336527487657118)
,p_name=>'JSONISD'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'JSONISD'
,p_data_type=>'CLOB'
,p_session_state_data_type=>'CLOB'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXTAREA'
,p_heading=>'Jsonisd'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>380
,p_value_alignment=>'LEFT'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
,p_is_required=>false
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(245336602036657119)
,p_name=>'JSONHISISD'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'JSONHISISD'
,p_data_type=>'CLOB'
,p_session_state_data_type=>'CLOB'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXTAREA'
,p_heading=>'Jsonhisisd'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>390
,p_value_alignment=>'LEFT'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
,p_is_required=>false
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(245336737825657120)
,p_name=>'BTN_JSONISD'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'BTN_JSONISD'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HTML_EXPRESSION'
,p_heading=>'-'
,p_heading_alignment=>'CENTER'
,p_display_sequence=>400
,p_value_alignment=>'LEFT'
,p_attribute_01=>'<button type="button" class="t-Button t-Button--small verJsonISD">ISD</button>'
,p_filter_is_required=>false
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(245336880750657121)
,p_name=>'BTN_JSONHIS'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'BTN_JSONHIS'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HTML_EXPRESSION'
,p_heading=>'-'
,p_heading_alignment=>'CENTER'
,p_display_sequence=>410
,p_value_alignment=>'LEFT'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
' ',
'<span aria-hidden="true" class="fa fa-tasks-alt verJsonHIS"></span>',
''))
,p_filter_is_required=>false
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(252655475507595227)
,p_name=>'PORCEISD'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'PORCEISD'
,p_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>'% ISD'
,p_heading_alignment=>'CENTER'
,p_display_sequence=>150
,p_value_alignment=>'RIGHT'
,p_attribute_05=>'BOTH'
,p_is_required=>false
,p_max_length=>50
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
,p_updated_on=>wwv_flow_imp.dz('20260505212052Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(493212205190847610)
,p_name=>'MTOISDS'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'MTOISDS'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_DISPLAY_ONLY'
,p_heading=>'Mto. ISD'
,p_heading_alignment=>'CENTER'
,p_display_sequence=>360
,p_value_alignment=>'RIGHT'
,p_attribute_02=>'VALUE'
,p_attribute_05=>'PLAIN'
,p_format_mask=>'FML999G999G999G999G990D00'
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(493212327760847611)
,p_name=>'MTOISDN'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'MTOISDN'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_DISPLAY_ONLY'
,p_heading=>'Mto. ISD-N'
,p_heading_alignment=>'CENTER'
,p_display_sequence=>370
,p_value_alignment=>'RIGHT'
,p_attribute_02=>'VALUE'
,p_attribute_05=>'PLAIN'
,p_format_mask=>'FML999G999G999G999G990D00'
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
,p_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_display_condition=>'P133_PROCESO'
,p_display_condition2=>'H'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(493275475592881601)
,p_name=>'TIPOISD'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'TIPOISD'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>'T/ISD'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>140
,p_value_alignment=>'LEFT'
,p_attribute_05=>'BOTH'
,p_item_css_classes=>'u-color-10-text'
,p_item_attributes=>'readonly="true" class="a-GV-cell u-tS is-readonly"'
,p_is_required=>false
,p_enable_filter=>false
,p_filter_is_required=>false
,p_static_id=>'TIPOISD'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_interactive_grid(
 p_id=>wwv_flow_imp.id(101642591036829835)
,p_internal_uid=>101642591036829835
,p_is_editable=>true
,p_edit_operations=>'u'
,p_lost_update_check_type=>'VALUES'
,p_submit_checked_rows=>false
,p_lazy_loading=>false
,p_requires_filter=>false
,p_select_first_row=>true
,p_fixed_row_height=>true
,p_pagination_type=>'SCROLL'
,p_show_total_row_count=>true
,p_no_data_found_message=>'No hay datos.'
,p_show_toolbar=>true
,p_toolbar_buttons=>'SEARCH_FIELD:ACTIONS_MENU:RESET:SAVE'
,p_enable_save_public_report=>false
,p_enable_subscriptions=>true
,p_enable_flashback=>false
,p_define_chart_view=>true
,p_enable_download=>true
,p_download_formats=>'XLSX'
,p_enable_mail_download=>false
,p_fixed_header=>'PAGE'
,p_show_icon_view=>false
,p_show_detail_view=>false
);
wwv_flow_imp_page.create_ig_report(
 p_id=>wwv_flow_imp.id(102669002198249318)
,p_interactive_grid_id=>wwv_flow_imp.id(101642591036829835)
,p_static_id=>'1026691'
,p_type=>'PRIMARY'
,p_default_view=>'GRID'
,p_show_row_number=>false
,p_settings_area_expanded=>false
);
wwv_flow_imp_page.create_ig_report_view(
 p_id=>wwv_flow_imp.id(102669284607249319)
,p_report_id=>wwv_flow_imp.id(102669002198249318)
,p_view_type=>'GRID'
,p_stretch_columns=>false
,p_srv_exclude_null_values=>false
,p_srv_only_display_columns=>true
,p_edit_mode=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(102669678971249323)
,p_view_id=>wwv_flow_imp.id(102669284607249319)
,p_display_seq=>2
,p_column_id=>wwv_flow_imp.id(101642629957829836)
,p_is_visible=>false
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(102675034571249339)
,p_view_id=>wwv_flow_imp.id(102669284607249319)
,p_display_seq=>10
,p_column_id=>wwv_flow_imp.id(101643251437829842)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>61
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(102675919301249341)
,p_view_id=>wwv_flow_imp.id(102669284607249319)
,p_display_seq=>11
,p_column_id=>wwv_flow_imp.id(101643335109829843)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>86
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(102676815288249343)
,p_view_id=>wwv_flow_imp.id(102669284607249319)
,p_display_seq=>19
,p_column_id=>wwv_flow_imp.id(101643454693829844)
,p_is_visible=>false
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(102679524585249350)
,p_view_id=>wwv_flow_imp.id(102669284607249319)
,p_display_seq=>9
,p_column_id=>wwv_flow_imp.id(101643789107829847)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>238
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(102680496398249352)
,p_view_id=>wwv_flow_imp.id(102669284607249319)
,p_display_seq=>4
,p_column_id=>wwv_flow_imp.id(101643823569829848)
,p_is_visible=>false
,p_is_frozen=>false
,p_sort_order=>2
,p_break_order=>10
,p_break_is_enabled=>true
,p_break_sort_direction=>'ASC'
,p_break_sort_nulls=>'LAST'
,p_sort_direction=>'ASC'
,p_sort_nulls=>'LAST'
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(103770071936474891)
,p_view_id=>wwv_flow_imp.id(102669284607249319)
,p_display_seq=>12
,p_column_id=>wwv_flow_imp.id(102665310366249120)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>80
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(103770923940474894)
,p_view_id=>wwv_flow_imp.id(102669284607249319)
,p_display_seq=>13
,p_column_id=>wwv_flow_imp.id(102665442530249121)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>92
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(103771802523474897)
,p_view_id=>wwv_flow_imp.id(102669284607249319)
,p_display_seq=>14
,p_column_id=>wwv_flow_imp.id(102665589160249122)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>70
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(103772785972474899)
,p_view_id=>wwv_flow_imp.id(102669284607249319)
,p_display_seq=>15
,p_column_id=>wwv_flow_imp.id(102665636154249123)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>67
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(103773671240474901)
,p_view_id=>wwv_flow_imp.id(102669284607249319)
,p_display_seq=>16
,p_column_id=>wwv_flow_imp.id(102665788159249124)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>67
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(103774552588474903)
,p_view_id=>wwv_flow_imp.id(102669284607249319)
,p_display_seq=>17
,p_column_id=>wwv_flow_imp.id(102665897608249125)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>77
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(104261528402853058)
,p_view_id=>wwv_flow_imp.id(102669284607249319)
,p_display_seq=>1
,p_column_id=>wwv_flow_imp.id(102667088473249137)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(106054205388138898)
,p_view_id=>wwv_flow_imp.id(102669284607249319)
,p_display_seq=>3
,p_column_id=>wwv_flow_imp.id(102668242761249149)
,p_is_visible=>false
,p_is_frozen=>false
,p_sort_order=>1
,p_break_order=>5
,p_break_is_enabled=>true
,p_break_sort_direction=>'ASC'
,p_break_sort_nulls=>'LAST'
,p_sort_direction=>'ASC'
,p_sort_nulls=>'LAST'
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(106521752207558798)
,p_view_id=>wwv_flow_imp.id(102669284607249319)
,p_display_seq=>6
,p_column_id=>wwv_flow_imp.id(106069735368168709)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>50
,p_sort_order=>3
,p_sort_direction=>'ASC'
,p_sort_nulls=>'LAST'
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(108051743386948800)
,p_view_id=>wwv_flow_imp.id(102669284607249319)
,p_display_seq=>18
,p_column_id=>wwv_flow_imp.id(106070873485168720)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>300
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(108398040968835611)
,p_view_id=>wwv_flow_imp.id(102669284607249319)
,p_display_seq=>7
,p_column_id=>wwv_flow_imp.id(103100590939016520)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>118
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(109653500281289120)
,p_view_id=>wwv_flow_imp.id(102669284607249319)
,p_display_seq=>21
,p_column_id=>wwv_flow_imp.id(103100616006016521)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>81
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(109655375952289129)
,p_view_id=>wwv_flow_imp.id(102669284607249319)
,p_display_seq=>22
,p_column_id=>wwv_flow_imp.id(103100886866016523)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>89
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(109656264363289131)
,p_view_id=>wwv_flow_imp.id(102669284607249319)
,p_display_seq=>24
,p_column_id=>wwv_flow_imp.id(103100957721016524)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>116
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(109660778890289142)
,p_view_id=>wwv_flow_imp.id(102669284607249319)
,p_display_seq=>30
,p_column_id=>wwv_flow_imp.id(103101491405016529)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>100
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(109664230444401413)
,p_view_id=>wwv_flow_imp.id(102669284607249319)
,p_display_seq=>23
,p_column_id=>wwv_flow_imp.id(103101980133016534)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>124
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(110181060571937332)
,p_view_id=>wwv_flow_imp.id(102669284607249319)
,p_display_seq=>8
,p_column_id=>wwv_flow_imp.id(106071408237168726)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>235
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(120368514922265738)
,p_view_id=>wwv_flow_imp.id(102669284607249319)
,p_display_seq=>5
,p_column_id=>wwv_flow_imp.id(117300611373208312)
,p_is_visible=>false
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(120369494817265743)
,p_view_id=>wwv_flow_imp.id(102669284607249319)
,p_display_seq=>34
,p_column_id=>wwv_flow_imp.id(117300793667208313)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>83
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(120430691843586458)
,p_view_id=>wwv_flow_imp.id(102669284607249319)
,p_display_seq=>25
,p_column_id=>wwv_flow_imp.id(117300895416208314)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>75
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(120437976313926991)
,p_view_id=>wwv_flow_imp.id(102669284607249319)
,p_display_seq=>26
,p_column_id=>wwv_flow_imp.id(117300969522208315)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>90
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(120438939720926994)
,p_view_id=>wwv_flow_imp.id(102669284607249319)
,p_display_seq=>27
,p_column_id=>wwv_flow_imp.id(117301098021208316)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>90
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(120439989110926997)
,p_view_id=>wwv_flow_imp.id(102669284607249319)
,p_display_seq=>28
,p_column_id=>wwv_flow_imp.id(117301151734208317)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>90
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(120440986374926999)
,p_view_id=>wwv_flow_imp.id(102669284607249319)
,p_display_seq=>29
,p_column_id=>wwv_flow_imp.id(117301230603208318)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>75
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(222019763952039048)
,p_view_id=>wwv_flow_imp.id(102669284607249319)
,p_display_seq=>35
,p_column_id=>wwv_flow_imp.id(207050837287772033)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(248988078803965225)
,p_view_id=>wwv_flow_imp.id(102669284607249319)
,p_display_seq=>37
,p_column_id=>wwv_flow_imp.id(245336527487657118)
,p_is_visible=>false
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(248988958843965229)
,p_view_id=>wwv_flow_imp.id(102669284607249319)
,p_display_seq=>38
,p_column_id=>wwv_flow_imp.id(245336602036657119)
,p_is_visible=>false
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(248992045966971173)
,p_view_id=>wwv_flow_imp.id(102669284607249319)
,p_display_seq=>39
,p_column_id=>wwv_flow_imp.id(245336737825657120)
,p_is_visible=>false
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(248992963515971177)
,p_view_id=>wwv_flow_imp.id(102669284607249319)
,p_display_seq=>36
,p_column_id=>wwv_flow_imp.id(245336880750657121)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>53
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(252710155352706504)
,p_view_id=>wwv_flow_imp.id(102669284607249319)
,p_display_seq=>33
,p_column_id=>wwv_flow_imp.id(252655475507595227)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(493223938811920925)
,p_view_id=>wwv_flow_imp.id(102669284607249319)
,p_display_seq=>20
,p_column_id=>wwv_flow_imp.id(493212205190847610)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>97
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(493224899534920932)
,p_view_id=>wwv_flow_imp.id(102669284607249319)
,p_display_seq=>31
,p_column_id=>wwv_flow_imp.id(493212327760847611)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>95
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(493282868897888175)
,p_view_id=>wwv_flow_imp.id(102669284607249319)
,p_display_seq=>32
,p_column_id=>wwv_flow_imp.id(493275475592881601)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>98
);
wwv_flow_imp_page.create_ig_report_aggregate(
 p_id=>wwv_flow_imp.id(33361000003)
,p_view_id=>wwv_flow_imp.id(102669284607249319)
,p_function=>'SUM'
,p_column_id=>wwv_flow_imp.id(103101491405016529)
,p_show_grand_total=>true
,p_is_enabled=>true
);
wwv_flow_imp_page.create_ig_report_aggregate(
 p_id=>wwv_flow_imp.id(89540000001)
,p_view_id=>wwv_flow_imp.id(102669284607249319)
,p_function=>'SUM'
,p_column_id=>wwv_flow_imp.id(102665589160249122)
,p_show_grand_total=>true
,p_is_enabled=>true
);
wwv_flow_imp_page.create_ig_report_aggregate(
 p_id=>wwv_flow_imp.id(92270000001)
,p_view_id=>wwv_flow_imp.id(102669284607249319)
,p_function=>'SUM'
,p_column_id=>wwv_flow_imp.id(102665310366249120)
,p_show_grand_total=>true
,p_is_enabled=>true
);
wwv_flow_imp_page.create_ig_report_aggregate(
 p_id=>wwv_flow_imp.id(137254000005)
,p_view_id=>wwv_flow_imp.id(102669284607249319)
,p_function=>'SUM'
,p_column_id=>wwv_flow_imp.id(493212205190847610)
,p_show_grand_total=>true
,p_is_enabled=>true
);
wwv_flow_imp_page.create_ig_report_aggregate(
 p_id=>wwv_flow_imp.id(158868000001)
,p_view_id=>wwv_flow_imp.id(102669284607249319)
,p_function=>'SUM'
,p_column_id=>wwv_flow_imp.id(102665636154249123)
,p_show_grand_total=>true
,p_is_enabled=>true
);
wwv_flow_imp_page.create_ig_report_aggregate(
 p_id=>wwv_flow_imp.id(210443000005)
,p_view_id=>wwv_flow_imp.id(102669284607249319)
,p_function=>'SUM'
,p_column_id=>wwv_flow_imp.id(493212327760847611)
,p_show_grand_total=>true
,p_is_enabled=>true
);
wwv_flow_imp_page.create_ig_report_aggregate(
 p_id=>wwv_flow_imp.id(230961000001)
,p_view_id=>wwv_flow_imp.id(102669284607249319)
,p_function=>'SUM'
,p_column_id=>wwv_flow_imp.id(102665788159249124)
,p_show_grand_total=>true
,p_is_enabled=>true
);
wwv_flow_imp_page.create_ig_report_aggregate(
 p_id=>wwv_flow_imp.id(395855000001)
,p_view_id=>wwv_flow_imp.id(102669284607249319)
,p_function=>'SUM'
,p_column_id=>wwv_flow_imp.id(102665897608249125)
,p_show_grand_total=>true
,p_is_enabled=>true
);
wwv_flow_imp_page.create_ig_report_aggregate(
 p_id=>wwv_flow_imp.id(1052343008921)
,p_view_id=>wwv_flow_imp.id(102669284607249319)
,p_tooltip=>'Total Porcentaje'
,p_function=>'SUM'
,p_column_id=>wwv_flow_imp.id(102665442530249121)
,p_show_grand_total=>true
,p_is_enabled=>true
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(228905640175347549)
,p_plug_name=>'Items'
,p_region_name=>'secItems'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(38289867500120143)
,p_plug_display_sequence=>110
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(245336467875657117)
,p_plug_name=>'Reporte isd'
,p_title=>'DETALLE DE CODIGOS Y PORCENTAJES ISD'
,p_region_name=>'regReporteIsd'
,p_region_template_options=>'#DEFAULT#:js-dialog-autoheight:js-dialog-size720x480'
,p_plug_template=>wwv_flow_imp.id(37804699672106518)
,p_plug_display_sequence=>100
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(330853370005165820)
,p_plug_name=>unistr('Par\00E1metros')
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(38289867500120143)
,p_plug_display_sequence=>60
,p_include_in_reg_disp_sel_yn=>'Y'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(245335193124657104)
,p_plug_name=>'New'
,p_parent_plug_id=>wwv_flow_imp.id(330853370005165820)
,p_region_template_options=>'#DEFAULT#:t-Form--noPadding:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels:margin-top-none:margin-bottom-none:margin-left-none:margin-right-none'
,p_plug_template=>wwv_flow_imp.id(38289867500120143)
,p_plug_display_sequence=>70
,p_location=>null
,p_plug_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_plug_display_when_condition=>'P133_PROCESO'
,p_plug_display_when_cond2=>'H'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(101642372140829833)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(101640680976829816)
,p_button_name=>'ATRAS'
,p_button_static_id=>'btnAtras'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860056812106557)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Atras'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'LEFT'
,p_button_redirect_url=>'f?p=&APP_ID.:131:&SESSION.::&DEBUG.:RP,131::'
,p_icon_css_classes=>'fa-arrow-left'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(106070948323168721)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(101640680976829816)
,p_button_name=>'BLOQUEAR'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860056812106557)
,p_button_image_alt=>'Bloquear'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
,p_button_condition=>'select ''x'' from t_finz_calculoisddet where idcab = :p133_idmesa and :p133_estado = ''INGRESADO'''
,p_button_condition_type=>'EXISTS'
,p_icon_css_classes=>'fa-lock'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(110889983660300031)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(101640680976829816)
,p_button_name=>'FINALIZAR'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860056812106557)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Cerrar'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
,p_button_condition=>':P133_ESTADO = ''PENDIENTE'''
,p_button_condition2=>'PLSQL'
,p_button_condition_type=>'EXPRESSION'
,p_icon_css_classes=>'fa-cogs'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(85321748289939443)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(101640680976829816)
,p_button_name=>'NOTIFICAR'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860056812106557)
,p_button_image_alt=>'Notificar'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
,p_button_condition=>'P133_ESTADO'
,p_button_condition2=>'CERRADO'
,p_button_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_icon_css_classes=>'fa-paper-plane-o'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(101641610732829826)
,p_button_sequence=>50
,p_button_plug_id=>wwv_flow_imp.id(101640680976829816)
,p_button_name=>'CARGARDATOS'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860056812106557)
,p_button_image_alt=>'Cargar Datos'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
,p_button_condition=>'P133_ESTADO'
,p_button_condition2=>'INGRESADO'
,p_button_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_icon_css_classes=>'fa-gear'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(125699446603728801)
,p_button_sequence=>70
,p_button_plug_id=>wwv_flow_imp.id(101640680976829816)
,p_button_name=>'BORRAR'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860056812106557)
,p_button_image_alt=>'Borrar'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
,p_button_condition=>'P133_ESTADO'
,p_button_condition2=>'INGRESADO'
,p_button_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_icon_css_classes=>'fa-trash-o'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(330853582204165822)
,p_button_sequence=>80
,p_button_plug_id=>wwv_flow_imp.id(101640680976829816)
,p_button_name=>'ACTUALIZAISD'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860056812106557)
,p_button_image_alt=>'Actualiza ISD'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
,p_button_condition=>':P133_ESTADO=''CERRADO'' AND :P133_PROCESO=''H'''
,p_button_condition2=>'PLSQL'
,p_button_condition_type=>'EXPRESSION'
,p_icon_css_classes=>'fa-save'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(245339547995657148)
,p_button_sequence=>90
,p_button_name=>'Guardar'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860056812106557)
,p_button_image_alt=>'Guardar'
,p_show_processing=>'Y'
,p_button_css_classes=>'btnAccion'
,p_icon_css_classes=>'fa-save'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(125699922175728806)
,p_branch_name=>'Pag. 131'
,p_branch_action=>'f?p=&APP_ID.:131:&SESSION.::&DEBUG.:131::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_imp.id(125699446603728801)
,p_branch_sequence=>20
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(101641813972829828)
,p_name=>'P133_IDMESA'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(228905640175347549)
,p_prompt=>'Idmesa'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_warn_on_unsaved_changes=>'I'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(101642204510829832)
,p_name=>'P133_ORDENCOMPRA'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(330853370005165820)
,p_prompt=>unistr('Orden de Importaci\00F3n')
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_read_only_when_type=>'ALWAYS'
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(102667633037249143)
,p_name=>'P133_ORDENESNUEVAS'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(101640707535829817)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(102667796929249144)
,p_name=>'P133_NUMFACTURA'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(101640707535829817)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(106070788796168719)
,p_name=>'P133_ESTADO'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(330853370005165820)
,p_prompt=>'Estado'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(117300462401208310)
,p_name=>'P133_BANDERA'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(228905640175347549)
,p_prompt=>'Bandera'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_warn_on_unsaved_changes=>'I'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(207051069561772035)
,p_name=>'P133_ERROR'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(228905640175347549)
,p_prompt=>'Error'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_warn_on_unsaved_changes=>'I'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(228905428360347547)
,p_name=>'P133_PROCESO'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(228905640175347549)
,p_prompt=>'Proceso'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_warn_on_unsaved_changes=>'I'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(228905762403347550)
,p_name=>'P133_LABELISD001'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(228905640175347549)
,p_prompt=>'Labelisd001'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_warn_on_unsaved_changes=>'I'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(245334855512657101)
,p_name=>'P133_LABELISD002'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(228905640175347549)
,p_prompt=>'Labelisd002'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_warn_on_unsaved_changes=>'I'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(245334981317657102)
,p_name=>'P133_LABELISD003'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(228905640175347549)
,p_prompt=>'Labelisd003'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_warn_on_unsaved_changes=>'I'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(245335007389657103)
,p_name=>'P133_LABELISD004'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(228905640175347549)
,p_prompt=>'Labelisd004'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_warn_on_unsaved_changes=>'I'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(245339465042657147)
,p_name=>'P133_EDITABLE'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_imp.id(228905640175347549)
,p_prompt=>'Editable'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_warn_on_unsaved_changes=>'I'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(330853477381165821)
,p_name=>'P133_PORCISDSNVO'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(245335193124657104)
,p_prompt=>'Nvo. ISD-S'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>10
,p_display_when=>'P133_ESTADO'
,p_display_when2=>'CERRADO'
,p_display_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'0'
,p_attribute_03=>'right'
,p_attribute_04=>'decimal'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(493212170192847609)
,p_name=>'P133_PORCISDNNVO'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(245335193124657104)
,p_prompt=>'Nvo. ISD-N'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>10
,p_begin_on_new_line=>'N'
,p_display_when=>'P133_ESTADO'
,p_display_when2=>'CERRADO'
,p_display_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'0'
,p_attribute_03=>'right'
,p_attribute_04=>'decimal'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(106072401996168736)
,p_validation_name=>'Facturas'
,p_validation_sequence=>10
,p_validation=>'select ''x'' from data.t_finz_calculoisdfac where idcab = :p133_idmesa;'
,p_validation_type=>'EXISTS'
,p_error_message=>'Debe cargar los datos de esta orden antes de pasar a la siguiente etapa'
,p_validation_condition=>'CONTINUARPROCESO'
,p_validation_condition_type=>'REQUEST_EQUALS_CONDITION'
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(103102808474016543)
,p_validation_name=>'OCs Adicionales'
,p_validation_sequence=>20
,p_validation=>'select ''x'' from data.t_finz_calculoisdfac where idcab = :p133_idmesa and ordenesadicionales is not null;'
,p_validation_type=>'NOT_EXISTS'
,p_error_message=>'No pueden haber ordenes adicionales en una factura de esta orden'
,p_validation_condition=>'CONTINUARPROCESO'
,p_validation_condition_type=>'REQUEST_EQUALS_CONDITION'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(106072396910168735)
,p_validation_name=>'Detalle'
,p_validation_sequence=>30
,p_validation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select detalle.idcab from data.t_finz_calculoisddet detalle',
'inner join data.t_corp_udc hom on (detalle.codproducto = hom.valor and hom.activo = ''S'' and hom.id_cabecera = ''CMEX_FHUM'')',
'where 1 = 1',
'and detalle.idcab = :p133_idmesa;'))
,p_validation_type=>'NOT_EXISTS'
,p_error_message=>'Debe ingresar los valores para productos con Factor de Humedad'
,p_validation_condition=>':REQUEST = ''CONTINUARPROCESO'''
,p_validation_condition2=>'PLSQL'
,p_validation_condition_type=>'EXPRESSION'
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(102667946510249146)
,p_name=>'Cambio Num Factura'
,p_event_sequence=>30
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P133_NUMFACTURA'
,p_condition_element=>'P133_NUMFACTURA'
,p_triggering_condition_type=>'NOT_NULL'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(102668019043249147)
,p_event_id=>wwv_flow_imp.id(102667946510249146)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_CONFIRM'
,p_attribute_01=>unistr('\00BFEst\00E1 seguro que desea agregar esa orden?')
,p_attribute_02=>'Confirme'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(102668162682249148)
,p_event_id=>wwv_flow_imp.id(102667946510249146)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_01=>'AGG_ORDENAD'
,p_attribute_02=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(102668359612249150)
,p_name=>'CLIC_BTNCARGARDATOS'
,p_event_sequence=>40
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(101641610732829826)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(106068992051168701)
,p_event_id=>wwv_flow_imp.id(102668359612249150)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_CONFIRM'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
unistr('Si usted ya ha llenado o modificado la informaci\00F3n de factura o detalle se borrar\00E1 todo su progreso,'),
unistr('\00BFEst\00E1 seguro que desea cargar los datos?')))
,p_attribute_02=>unistr('Confirmaci\00F3n')
,p_attribute_03=>'warning'
,p_attribute_04=>'fa-exception'
,p_attribute_06=>'Si'
,p_attribute_07=>'No'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(106069090147168702)
,p_event_id=>wwv_flow_imp.id(102668359612249150)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_01=>'CARGAR_DATOS'
,p_attribute_02=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(106070480202168716)
,p_name=>'GuardaIG'
,p_event_sequence=>50
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(101642485024829834)
,p_condition_element_type=>'ITEM'
,p_condition_element=>'P133_ESTADO'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'1'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'NATIVE_IG|REGION TYPE|interactivegridsave'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(106070579263168717)
,p_event_id=>wwv_flow_imp.id(106070480202168716)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(101642485024829834)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(106071067323168722)
,p_name=>'Bloquear Proceso'
,p_event_sequence=>60
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(106070948323168721)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(106071180542168723)
,p_event_id=>wwv_flow_imp.id(106071067323168722)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_CONFIRM'
,p_attribute_01=>unistr('\00BFEst\00E1 seguro de bloquear el proceso? No podr\00E1 editar la informaci\00F3n ingresada.')
,p_attribute_02=>unistr('Confirmaci\00F3n')
,p_attribute_03=>'warning'
,p_attribute_04=>'fa-exclamation-triangle-o'
,p_attribute_06=>'Aceptar'
,p_attribute_07=>'Cancelar'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(106071249845168724)
,p_event_id=>wwv_flow_imp.id(106071067323168722)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_01=>'CONTINUARPROCESO'
,p_attribute_02=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(106072032598168732)
,p_name=>'Setea Calculos'
,p_event_sequence=>70
,p_triggering_element_type=>'COLUMN'
,p_triggering_region_id=>wwv_flow_imp.id(101642485024829834)
,p_triggering_element=>'CANTDESP,PRECIOUNIT,VALORPROPORCIONAL,COSTOPROVISION'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
,p_display_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_display_when_cond=>'P133_ESTADO'
,p_display_when_cond2=>'2'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(106072105639168733)
,p_event_id=>wwv_flow_imp.id(106072032598168732)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'V_TOTAL_LINEA NUMBER;',
'V_PORC_PROV NUMBER;',
'V_CH NUMBER;',
'V_IMP NUMBER;',
'V_FACTOR_H NUMBER;',
'V_CH_X_TOTAL NUMBER;',
'BEGIN',
'IF :CANTDESP IS NOT NULL AND :PRECIOUNIT IS NOT NULL AND :COSTOPROVISION IS NOT NULL AND :VALORPROPORCIONAL IS NOT NULL THEN',
'',
'V_TOTAL_LINEA := :CANTDESP * :PRECIOUNIT; -- Total Linea',
'V_PORC_PROV := :COSTOPROVISION/V_TOTAL_LINEA; -- % Prov vs Total',
'V_CH := V_TOTAL_LINEA - (:PRECIOUNIT * :VALORPROPORCIONAL); --Costo de Humedad',
'V_CH_X_TOTAL := V_CH/V_TOTAL_LINEA; -- % CH/Total Linea',
'V_IMP := V_CH * V_PORC_PROV; -- Valor Importe',
'V_FACTOR_H := V_IMP + V_CH; --Factor de Humedad',
'',
'',
':TOTAL_LINEA := V_TOTAL_LINEA;',
':PROV_VS_TOTAL := V_PORC_PROV * 100;',
':CH := V_CH;',
':CH_X_TOTAL := V_CH_X_TOTAL * 100;',
':COSTO_IMP := V_IMP;',
':FACTORHUMEDAD := V_FACTOR_H;',
'',
'ELSE',
':FACTORHUMEDAD := NULL;',
'END IF;',
'--CANTDESP,PRECIOUNIT,VALORPROPORCIONAL,COSTOPROVISION',
'END;'))
,p_attribute_02=>'CANTDESP,PRECIOUNIT,COSTOPROVISION,VALORPROPORCIONAL'
,p_attribute_03=>'TOTAL_LINEA,PROV_VS_TOTAL,CH,CH_X_TOTAL,COSTO_IMP,FACTORHUMEDAD'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(110890011683300032)
,p_name=>'Finalizar Proceso'
,p_event_sequence=>80
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(110889983660300031)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(110890169381300033)
,p_event_id=>wwv_flow_imp.id(110890011683300032)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_CONFIRM'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
unistr('Este proceso registrar\00E1 asientos en Interoperabilidad.'),
unistr('\00BFDesea continuar?')))
,p_attribute_02=>unistr('Confirmaci\00F3n')
,p_attribute_03=>'danger'
,p_attribute_04=>'fa-exclamation-triangle-o'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(117301720751208323)
,p_event_id=>wwv_flow_imp.id(110890011683300032)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'mostrarBarra();'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(117301829004208324)
,p_event_id=>wwv_flow_imp.id(110890011683300032)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'v_respuesta	number;',
'v_idmesa	number;',
'v_log_app	varchar2(100);',
'v_log_dps	varchar2(999);',
'begin',
'	v_log_app := ''apex.109.133.Finalizar'';',
'	v_idmesa := :p133_idmesa;',
'',
'	if data.pk_finz_factorhumedad.F_ValidaDetalleFh (p_idmesa => v_idmesa) = 0 then',
'		data.pk_finz_factorhumedad.sp_provision(:g_compania,:app_user,v_idmesa,v_respuesta);',
'',
'		v_log_dps := ''v_idmesa: ''||v_idmesa||'', v_respuesta: ''||v_respuesta;',
'		pk_commons.sp_apex_log(v_log_app,1,v_log_dps,null,null,null); commit;',
'',
'		if v_respuesta = 1 then',
'			update data.t_finz_calculoisd x set x.estado = ''CERRADO'' where id = v_idmesa;',
'		end if;',
'		commit;',
'		:P133_ERROR := 0 ; ',
'	else',
'		:P133_ERROR := 1 ; ',
'	end if;',
'end;'))
,p_attribute_02=>'P133_IDMESA'
,p_attribute_03=>'P133_ERROR'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(117301918995208325)
,p_event_id=>wwv_flow_imp.id(110890011683300032)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'ocultarBarra();'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(110890287693300034)
,p_event_id=>wwv_flow_imp.id(110890011683300032)
,p_event_result=>'TRUE'
,p_action_sequence=>50
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_02=>'Y'
,p_client_condition_type=>'NOT_EQUALS'
,p_client_condition_element=>'P133_ERROR'
,p_client_condition_expression=>'1'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(207051244543772037)
,p_event_id=>wwv_flow_imp.id(110890011683300032)
,p_event_result=>'TRUE'
,p_action_sequence=>60
,p_execute_on_page_init=>'N'
,p_name=>'Datos Nulos'
,p_action=>'NATIVE_ALERT'
,p_attribute_01=>'Los datos de factor de humedad no pueden ser nulos'
,p_attribute_02=>'Error'
,p_client_condition_type=>'EQUALS'
,p_client_condition_element=>'P133_ERROR'
,p_client_condition_expression=>'1'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(110890377307300035)
,p_name=>'Cambio PA'
,p_event_sequence=>90
,p_triggering_element_type=>'COLUMN'
,p_triggering_region_id=>wwv_flow_imp.id(101642485024829834)
,p_triggering_element=>'PARTIDAARANCEL'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
,p_display_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_display_when_cond=>'P133_PROCESO'
,p_display_when_cond2=>'H'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(110890408511300036)
,p_event_id=>wwv_flow_imp.id(110890377307300035)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_name=>'Aplica CT'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'COLUMN'
,p_affected_elements=>'APLICACT'
,p_attribute_01=>'SQL_STATEMENT'
,p_attribute_03=>'select decode(trim(vt_cat.drsphd),''S'',1,0) from vt_jde_udcjde vt_cat where vt_cat.drsy = ''41'' and vt_cat.drrt = ''10'' and trim(vt_cat.drky) = :PARTIDAARANCEL'
,p_attribute_07=>'PARTIDAARANCEL'
,p_attribute_08=>'Y'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(125699643797728803)
,p_name=>'Borrar'
,p_event_sequence=>110
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(125699446603728801)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(125699783382728804)
,p_event_id=>wwv_flow_imp.id(125699643797728803)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_CONFIRM'
,p_attribute_01=>unistr('\00BFEst\00E1 seguro de borrar el proceso? No se podr\00E1 recuperar la informaci\00F3n modificada.')
,p_attribute_02=>'Borrar'
,p_attribute_03=>'danger'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(125699803342728805)
,p_event_id=>wwv_flow_imp.id(125699643797728803)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'mostrarBarra()'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(85322233176939448)
,p_event_id=>wwv_flow_imp.id(125699643797728803)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'v_idmesa number;',
'begin',
'    v_idmesa := :p133_idmesa;',
'    delete from data.t_finz_calculoisddet where idcab = v_idmesa;',
'    delete from data.t_finz_calculoisdfac where idcab = v_idmesa;',
'    delete from data.t_finz_calculoisd where id = v_idmesa;',
'    commit;',
'end;'))
,p_attribute_02=>'P133_IDMESA'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(85322328604939449)
,p_event_id=>wwv_flow_imp.id(125699643797728803)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'ocultarBarra();',
'$(''#btnAtras'').trigger("click");'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(85321824064939444)
,p_name=>'Notificar'
,p_event_sequence=>120
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(85321748289939443)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(85321945223939445)
,p_event_id=>wwv_flow_imp.id(85321824064939444)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'mostrarBarra();'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(85322003256939446)
,p_event_id=>wwv_flow_imp.id(85321824064939444)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'    data.pk_finz_factorhumedad.sp_notificacion(:p133_idmesa,:p133_estado);',
'end;'))
,p_attribute_02=>'P133_IDMESA,P133_ESTADO'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(85322107329939447)
,p_event_id=>wwv_flow_imp.id(85321824064939444)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'mensajeExito("Correo enviado.");',
'ocultarBarra();'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(330853635458165823)
,p_name=>'Actualiza ISD'
,p_event_sequence=>130
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(330853582204165822)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(330853715122165824)
,p_event_id=>wwv_flow_imp.id(330853635458165823)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'mostrarBarra();'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(330853894081165825)
,p_event_id=>wwv_flow_imp.id(330853635458165823)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'v_idcab		number;',
'v_nuevoisds	number;',
'v_nuevoisdn	number;',
'begin',
'	v_idcab		:= :p133_idmesa;',
'	v_nuevoisds	:= nvl(:p133_porcisdsnvo,0);',
'	v_nuevoisds	:= nvl(:p133_porcisdnnvo,0);',
'',
'	begin',
'		update data.t_finz_calculoisdfac x set x.porcisdsnvo = v_nuevoisds, x.porcisdnnvo = v_nuevoisdn',
'		where idcab = v_idcab;',
'	end;',
'end;'))
,p_attribute_02=>'P133_IDMESA,P133_PORCISDSNVO'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(330853908527165826)
,p_event_id=>wwv_flow_imp.id(330853635458165823)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'ocultarBarra();'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(330854004559165827)
,p_event_id=>wwv_flow_imp.id(330853635458165823)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_02=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(245336046854657113)
,p_name=>'verJsonISD'
,p_event_sequence=>140
,p_triggering_element_type=>'JQUERY_SELECTOR'
,p_triggering_element=>'.verJsonISD'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(245336151496657114)
,p_event_id=>wwv_flow_imp.id(245336046854657113)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'var ig$ = apex.region("regDetalleImportacion").widget();',
'var view = ig$.interactiveGrid("getViews","grid");',
'var model = view.model;',
'',
'var record = view.getContextRecord(this.triggeringElement)[0];',
'',
'var json = model.getValue(record, "JSONISD");',
'var data = JSON.parse(json || "[]");',
'',
'pintarTablaConDesc(data,''D'');'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(245337794148657130)
,p_name=>'verJsonFacISD'
,p_event_sequence=>150
,p_triggering_element_type=>'JQUERY_SELECTOR'
,p_triggering_element=>'.js-ver-json'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(245337836238657131)
,p_event_id=>wwv_flow_imp.id(245337794148657130)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'var json = $(this.triggeringElement).attr("data-json");',
'',
'try {',
'    var data = JSON.parse(json || "[]");',
'    pintarTablaConDesc(data,''F'');',
'} catch(e) {',
unistr('    console.error("JSON inv\00E1lido:", json);'),
'}'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(245336210657657115)
,p_name=>'verJsonHIS'
,p_event_sequence=>160
,p_triggering_element_type=>'JQUERY_SELECTOR'
,p_triggering_element=>'.verJsonHIS'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(245336370710657116)
,p_event_id=>wwv_flow_imp.id(245336210657657115)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'var ig$ = apex.region("regDetalleImportacion").widget();',
'var view = ig$.interactiveGrid("getViews","grid");',
'var model = view.model;',
'',
'var record = view.getContextRecord(this.triggeringElement)[0];',
'',
'var json = model.getValue(record, "JSONHISISD");',
'var data = JSON.parse(json || "[]");',
'',
'pintarTablaConDesc(data,''D'');'))
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(117300538154208311)
,p_process_sequence=>10
,p_process_point=>'AFTER_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Valida FH'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare v_idcab	number;',
'begin',
'	v_idcab := :p133_idmesa;',
'',
'	select count(1) into :p133_bandera from data.t_finz_calculoisddet ',
'	where idcab = v_idcab and aplicafh = 1;',
'',
'	if :p133_estado = ''CERRADO'' then',
'    	begin',
'    		select porcisdsnvo into :p133_porcisdsnvo from data.t_finz_calculoisdfac where idcab = v_idcab and porcisdsnvo is not null and rownum = 1;',
'',
'    		exception when others then',
'    		begin',
'    			select porcisds into :p133_porcisdsnvo from data.t_finz_calculoisdfac where idcab = v_idcab and porcisdsnvo is not null and rownum = 1;',
'',
'    			exception when others then :p133_porcisdsnvo := 0;',
'    		end;',
'    	end;',
'',
'    	begin',
'    		select porcisdnnvo into :p133_porcisdnnvo from data.t_finz_calculoisdfac where idcab = v_idcab and porcisdnnvo is not null and rownum = 1;',
'',
'    		exception when others then',
'    		begin',
'    			select porcisdn into :p133_porcisdnnvo from data.t_finz_calculoisdfac where idcab = v_idcab and porcisdnnvo is not null and rownum = 1;',
'',
'    			exception when others then :p133_porcisdnnvo := 0;',
'    		end;',
'    	end;',
'	end if;',
'    select COUNT(DISTINCT 1 ) ',
'    INTO :P133_EDITABLE',
'    from data.t_finz_calculoisddet det',
'    inner join data.t_finz_calculoisdfac fac on det.idcab = fac.idcab and det.idfac = fac.id',
'    inner join data.vt_jde_productos prod on det.codproducto = prod.codigoproducto',
'    where det.idcab = :p133_idmesa',
unistr('    AND (case -- Bandera que me indica qu\00E9 puedo editar en el formulario'),
'		when det.aplicafh = 0 and substr(det.tipoprd,1,2) in (''SV'',''AT'') then 1',
'		when det.aplicafh = 1 and substr(det.tipoprd,1,2) not in (''SV'',''AT'') then 2',
'		when det.aplicafh = 1 and substr(det.tipoprd,1,2) in (''SV'',''AT'') then 3',
'		else 0 end) IN (2,3);',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>117300538154208311
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(101641790036829827)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Cargar Datos'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'v_resultado number;',
'begin',
'	pk_finz_factorhumedad.sp_cargardatos(',
'		p_compania	=> :g_compania,',
'		p_usuario	=> :app_user,',
'		p_idmesa	=> :p133_idmesa,',
'		p_resultado	=> v_resultado',
'	);',
'',
'	data.pk_finz_factorhumedad.sp_consolidar_isd_por_factura(:p133_idmesa);',
'',
'	if v_resultado = -1 then',
'		apex_error.add_error(',
'			p_message			=> ''Datos ya cargados. CD'',',
'			p_display_location	=> apex_error.c_inline_in_notification',
'		);',
'	end if;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>'CARGAR_DATOS'
,p_process_when_type=>'REQUEST_EQUALS_CONDITION'
,p_internal_uid=>101641790036829827
,p_updated_on=>wwv_flow_imp.dz('20260505211931Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(102667840895249145)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Agregar Orden Adicional'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'v_resultado number;',
'begin',
'	pk_finz_factorhumedad.sp_agregarorden(',
'		p_idmesa	=> :p133_idmesa, ',
'		p_ordenes	=> :p133_ordenesnuevas, ',
'		p_factura	=> :p133_numfactura, ',
'		p_resultado	=> v_resultado',
'	);',
'',
'	if v_resultado = -1 then',
'		apex_error.add_error(',
'			p_message			=> ''Datos ya cargados. OC.'',',
'			p_display_location	=> apex_error.c_inline_in_notification',
'		);',
'	end if;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>'AGG_ORDENAD'
,p_process_when_type=>'REQUEST_EQUALS_CONDITION'
,p_internal_uid=>102667840895249145
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(106071313686168725)
,p_process_sequence=>30
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Bloquear Proceso'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare v_idmesa number;',
'begin',
'	v_idmesa := :p133_idmesa;',
'',
'	 if data.pk_finz_factorhumedad.F_ValidaDetalleFh ( p_idmesa => v_idmesa ) = 0 then',
'',
'		update data.t_finz_calculoisdfac x set x.batch =',
'			(select max(y.batch) from vt_cmex_provision y where y.ordencompra = x.tipooc||''-''||x.ordencompra)',
'		where x.idcab = v_idmesa and exists',
'			(select max(y.batch) from vt_cmex_provision y where y.ordencompra = x.tipooc||''-''||x.ordencompra);',
'		',
'		update data.t_finz_calculoisd x set x.estado = ''PENDIENTE'' where id = v_idmesa;',
'	else',
'		apex_error.add_error(',
'			p_message			=> ''No puede tener datos nulos en FH'',',
'			p_display_location	=> apex_error.c_inline_in_notification',
'		);',
'	end if;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_process_error_message=>'No se pudo actualizar el estado del Proceso.'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>'CONTINUARPROCESO'
,p_process_when_type=>'REQUEST_EQUALS_CONDITION'
,p_process_success_message=>'Procesado correctamente'
,p_internal_uid=>106071313686168725
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(102667280975249139)
,p_process_sequence=>40
,p_process_point=>'AFTER_SUBMIT'
,p_region_id=>wwv_flow_imp.id(101642485024829834)
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>unistr('Detalle Importaci\00F3n - Save Interactive Grid Data')
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare ',
'    src   data.t_finz_calculoisddet%rowtype;',
'    prt   data.t_finz_calculoisdprt%rowtype;',
'begin',
' ',
'        :P133_LABELISD002:=NULL;',
'        SELECT * into prt FROM t_finz_calculoisdprt where CODISD=:TIPOISD and  PARARC=:partidaarancel;',
'        Select * into src from data.t_finz_calculoisddet where id =:ID;',
'        :P133_LABELISD002:=:P133_LABELISD002||'',partidaarancel>>''||:partidaarancel||CHR(10);',
'        :P133_LABELISD002:=:P133_LABELISD002||'',ID>>''||:ID||CHR(10);',
'        :P133_LABELISD002:=:P133_LABELISD002||'',TIPOISD>>''||:TIPOISD||CHR(10);',
'',
'        :P133_LABELISD002:=:P133_LABELISD002||'',cantrec>>''||:cantrec||CHR(10);',
'        :P133_LABELISD002:=:P133_LABELISD002||'',costouni>>''||:costouni||CHR(10);',
'        :P133_LABELISD002:=:P133_LABELISD002||'',prt.TASISD>>''||prt.TASISD||CHR(10);',
'        :P133_LABELISD002:=:P133_LABELISD002||'',CALCULO>>''|| PK_COMMONS.SAFE_TO_NUMBER( TO_CHAR( ( (:cantrec*PK_COMMONS.SAFE_TO_NUMBER(REPLACE(:costouni,''$'','''')))*(prt.TASISD/100)),''999G999G999G999G990D00'') )||CHR(10) ;',
'        ',
'        update data.t_finz_calculoisddet ',
'        set ',
'          partarancelaria = :partidaarancel',
'        , TIPOISD= :TIPOISD',
'        , MTOISDS=(:cantrec*PK_COMMONS.SAFE_TO_NUMBER(REPLACE(:costouni,''$'','''')))*(prt.TASISD/100)',
'        , jsonisd = pk_finz_factorhumedad.fn_jsondetisd(-- JSON LINEA',
'                                :partidaarancel,',
'                                :TIPOISD,',
'                                prt.TASISD,',
'                                PK_COMMONS.SAFE_TO_NUMBER( TO_CHAR( ( (:cantrec*PK_COMMONS.SAFE_TO_NUMBER(REPLACE(:costouni,''$'','''')))*(prt.TASISD/100)),''999G999G999G999G990D00'') )',
'                            )',
unistr('        , jsonhisisd = pk_finz_factorhumedad.fn_jsondetisdhist(-- JSON hist\00F3rico'),
'                                src.jsonhisisd,',
'                                :partidaarancel,',
'                                :TIPOISD,',
'                                prt.TASISD,',
'                                PK_COMMONS.SAFE_TO_NUMBER( TO_CHAR( ( (:cantrec*PK_COMMONS.SAFE_TO_NUMBER(REPLACE(:costouni,''$'','''')))*(prt.TASISD/100)),''999G999G999G999G990D00'') )',
'                           )',
'        where id = :ID;COMMIT;',
'        pk_finz_factorhumedad.sp_consolidar_isd_por_factura(:P133_IDMESA);',
'        COMMIT;',
' ',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_process_error_message=>'Error al actualizar.'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_success_message=>'Actualizado.'
,p_internal_uid=>102667280975249139
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(245339392531657146)
,p_process_sequence=>50
,p_process_point=>'AFTER_SUBMIT'
,p_region_id=>wwv_flow_imp.id(101642485024829834)
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>unistr('Detalle Importaci\00F3n - Save Interactive Grid Data_1')
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare ',
'begin',
'    IF( :editable in (2,3))THEN',
'        update data.t_finz_calculoisddet set ',
'          aplicact		= :aplicact',
'        , cantdesp		= decode(:aplicafh,0,null,:cantdesp)',
'    	, preciounit 	= decode(:aplicafh,0,null,:preciounit)',
'    	, cantesti 		= decode(:aplicafh,0,null,:valorproporcional)',
'        , comentario	= :comentario',
'        where id 		= :ID; --AND :editable in (2,3);',
'    END IF;        ',
'EXCEPTION WHEN OTHERS THEN',
'    NULL;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_process_error_message=>'Error al actualizar.'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>':P133_EDITABLE =1'
,p_process_when_type=>'EXPRESSION'
,p_process_when2=>'PLSQL'
,p_exec_cond_for_each_row=>'Y'
,p_process_success_message=>'Actualizado.'
,p_internal_uid=>245339392531657146
,p_updated_on=>wwv_flow_imp.dz('20260515142401Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(106069307054168705)
,p_process_sequence=>10
,p_process_point=>'BEFORE_BOX_BODY'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Setar Orden Principal'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare l_filaisd data.t_finz_calculoisd%ROWTYPE;',
'begin',
'    select * into l_filaisd',
'    from data.t_finz_calculoisd',
'    where id = :p133_idmesa;',
'    :p133_ordencompra:= l_filaisd.ordencompra;',
'    :p133_estado:=l_filaisd.estado ;',
'    :p133_proceso:= l_filaisd.proceso;',
'     :P133_LABELISD001:= CASE WHEN (l_filaisd.proceso=''H'')THEN ''% ISD-S'' ELSE ''% ISD'' END ;',
' EXCEPTION WHEN OTHERS THEN',
'    NULL;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>106069307054168705
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(245337064477657123)
,p_process_sequence=>20
,p_process_point=>'ON_DEMAND'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'GET_JSON_CON_DESC'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_json clob := apex_application.g_x01;',
'begin',
'    apex_json.open_array;',
'',
'    for r in (',
'        SELECT ',
'            jt.parcela,',
'            jt.codigoisd,',
'            jt.valorporc,',
'            jt.valortisd,',
'            jt.estado,',
'            jt.fecha,',
'            TO_DATE(jt.fecha,''DD/MM/YYYY HH24:MI:SS'') fecha_ord',
'        FROM JSON_TABLE(',
'            l_json,',
'            ''$[*]'' COLUMNS (',
'                parcela    VARCHAR2(100)  PATH ''$.PARANCELA'',',
'                codigoisd  VARCHAR2(100)  PATH ''$.CODIGOISD'',',
'                valorporc  VARCHAR2(50)   PATH ''$.VALORPORC'',',
'                valortisd  VARCHAR2(50)   PATH ''$.VALORTISD'',',
'                estado     VARCHAR2(100)  PATH ''$.ESTADO'',',
'                fecha      VARCHAR2(50)   PATH ''$.FECHA''',
'            )',
'        ) jt',
'        ORDER BY fecha_ord DESC',
'    ) loop',
'',
'        declare',
'            v_desc varchar2(4000);',
'        begin',
'            if r.parcela is not null then',
'                begin',
'                    select drky||'' ''||drdl01||'' ''||drdl02',
'                    into v_desc',
'                    from data.vt_jde_udcjde',
'                    where drsy = ''41''',
'                      and drrt = ''10''',
'                      and drky = trim(r.parcela);',
'                exception',
'                    when no_data_found then',
'                        v_desc := r.parcela;',
'                end;',
'            else',
'                v_desc := r.parcela;',
'            end if;',
'',
'            apex_json.open_object;',
'',
'            apex_json.write(''PARANCELA'', v_desc);',
'            apex_json.write(''CODIGOISD'', r.codigoisd);',
'            apex_json.write(''VALORPORC'', r.valorporc);',
'            apex_json.write(''VALORTISD'', r.valortisd);',
'            apex_json.write(''ESTADO'', r.estado);',
'            apex_json.write(''FECHA'', r.fecha);',
'',
'            apex_json.close_object;',
'',
'        end;',
'    end loop;',
'',
'    apex_json.close_array;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>245337064477657123
);
wwv_flow_imp.component_end;
end;
/
