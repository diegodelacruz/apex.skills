prompt --application/pages/page_00443
begin
--   Manifest
--     PAGE: 00443
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>109
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_page.create_page(
 p_id=>443
,p_name=>'PYG INDUSTRIALES - DLG - PARAMETRIZACION COLUMNAS (UR)'
,p_alias=>'PYG-INDUSTRIALES-PARAMETRIZACION-COLUMNAS'
,p_page_mode=>'MODAL'
,p_step_title=>'PARAMETRIZACION COLUMNAS'
,p_autocomplete_on_off=>'OFF'
,p_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'$(document).on("click", ".btn-subir, .btn-bajar", function () {',
'    mostrarBarra();',
'    var region = apex.region("rgColumnas"); // Static ID correcto',
'    var view = region.call("getCurrentView");',
'    var model = view.model;',
'    var $td = $(this).closest("td");',
'    var record = view.getContextRecord($td)[0];',
'',
'    if (!record){ ocultarBarra();return;}',
'    var ordenActual = Number(model.getValue(record, "ORDEN_VISUAL"));',
'    var seqActual   = model.getValue(record, "SEQ_ID");',
'    var direccion   = $(this).hasClass("btn-subir") ? -1 : 1;',
'',
'    // Reemplazo correcto del getRecords',
'    var allRecords = [];',
'    model.forEach(function(rec) {allRecords.push(rec);});',
'',
'    var index = allRecords.findIndex(r => model.getValue(r, "SEQ_ID") === seqActual);',
'',
'    var indexDestino = index + direccion;',
'    if (indexDestino < 0 || indexDestino >= allRecords.length){ ocultarBarra();return;}',
'',
'    var recordDestino = allRecords[indexDestino];',
'',
'    var seqDestino = model.getValue(recordDestino, "SEQ_ID");',
'',
'    f_llamarInterCambiarOrden(seqActual,seqDestino	).then((resultado) => {',
'        console.log("resultado:"+resultado);',
'        if(resultado=="OK"){',
'            region.refresh();',
'        }',
'    }).catch((error) => {',
'       console.log("Hubo un error: " + error);',
'    });',
'    ocultarBarra();',
'});',
'function f_llamarInterCambiarOrden (seqActual, seqDestino){',
'    var result = null;',
'    // Llamada al proceso en el servidor',
'',
'    return new Promise((resolve, reject) => {',
'        apex.server.process(',
'            ''INTERCAMBIAR_ORDEN'', // Nombre del proceso',
'            {',
'                x01:seqActual,',
'                x02:seqDestino,',
'            }, // variables del proceso',
'            {',
'                dataType: "json",',
'                success: function(pData)',
'                {',
'                    result = pData.result;',
'                    resolve(result);  // Resuelve la promesa con los datos del servidor',
'                }',
'                ,error: function(err) {',
'                    // Manejo de errores',
'                    console.error("Error INTERCAMBIAR_ORDEN:", err);',
'                        reject(err);  // Rechaza la promesa en caso de error',
'                }',
'            }',
'        );',
'    });',
'}'))
,p_javascript_code_onload=>wwv_flow_string.join(wwv_flow_t_varchar2(
'moverToolbar();',
'$(secItems).hide();',
''))
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.ui-dialog .ui-dialog-titlebar-close {',
'    position: absolute;',
'    right: 12px;',
'    top: 12px;',
'    width: 24px;',
'    margin: 0;',
'    padding: 0;',
'    height: 24px;',
'    border-radius: 100%;',
'    display: none;',
'}',
'',
'.a-GV--editMode .a-GV-cell.is-readonly, .a-GV--editMode .a-GV-row.is-readonly .a-GV-cell {',
'    background-color: #ffffff;',
'    color: #333;',
'}',
''))
,p_step_template=>wwv_flow_imp.id(37774372912106498)
,p_page_template_options=>'#DEFAULT#'
,p_dialog_width=>'1200'
,p_dialog_css_classes=>'dlg-sin-cerrar'
,p_protection_level=>'C'
,p_page_component_map=>'21'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(839375462600724991)
,p_plug_name=>'items'
,p_region_name=>'secItems'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(38289867500120143)
,p_plug_display_sequence=>40
,p_include_in_reg_disp_sel_yn=>'Y'
,p_location=>null
,p_ai_enabled=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(839376465856725001)
,p_plug_name=>'Columnas'
,p_region_name=>'rgColumnas'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(37806762584106520)
,p_plug_display_sequence=>10
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'  SEQ_ID,',
'  C001,',
'  C002,',
'  C003,',
'  C004',
'  ',
'FROM APEX_COLLECTIONS ',
'WHERE COLLECTION_NAME = ''COLECCION_COLUMNAS''',
' '))
,p_plug_source_type=>'NATIVE_IG'
,p_plug_read_only_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_plug_read_only_when=>'P443_READONLY'
,p_plug_read_only_when2=>'1'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(199097041222689944)
,p_name=>'C003'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'C003'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_DISPLAY_ONLY'
,p_heading=>unistr('Descripci\00F3n Columna')
,p_heading_alignment=>'LEFT'
,p_display_sequence=>70
,p_value_alignment=>'LEFT'
,p_attribute_02=>'VALUE'
,p_attribute_05=>'PLAIN'
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(839376866280725005)
,p_name=>'SEQ_ID'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'SEQ_ID'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_DISPLAY_ONLY'
,p_heading=>'Seq Id'
,p_heading_alignment=>'CENTER'
,p_display_sequence=>40
,p_value_alignment=>'CENTER'
,p_attribute_02=>'VALUE'
,p_attribute_05=>'PLAIN'
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>true
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(839377442858725011)
,p_name=>'APEX$ROW_ACTION'
,p_session_state_data_type=>'VARCHAR2'
,p_item_type=>'NATIVE_ROW_ACTION'
,p_display_sequence=>30
,p_use_as_row_header=>false
,p_display_condition_type=>'NEVER'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(839377624709725012)
,p_name=>'APEX$ROW_SELECTOR'
,p_session_state_data_type=>'VARCHAR2'
,p_item_type=>'NATIVE_ROW_SELECTOR'
,p_display_sequence=>20
,p_attribute_01=>'Y'
,p_attribute_02=>'Y'
,p_attribute_03=>'Y'
,p_use_as_row_header=>false
,p_display_condition_type=>'NEVER'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(880643814773754686)
,p_name=>'C001'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'C001'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_POPUP_LOV'
,p_heading=>'Columna/Campo'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>50
,p_value_alignment=>'LEFT'
,p_attribute_01=>'POPUP'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_04=>'Y'
,p_attribute_05=>'Y'
,p_attribute_06=>'0'
,p_is_required=>false
,p_max_length=>4000
,p_lov_type=>'SQL_QUERY'
,p_lov_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'with tablesObjetos as (SELECT  TO_CHAR(ITEM) TABLENAME FROM TABLE(PK_COMMONS.F_DIVIDIRTEXTO(:P443_OBJETO,'':'')))',
',tablesJDE as (',
'    SELECT DISTINCT C.TABLE_NAME||''.''||c.COLUMN_NAME D,C.TABLE_NAME||''.''||c.COLUMN_NAME R ,C.TABLE_NAME,c.COLUMN_NAME , C.COLUMN_ID ORDEN ',
'    FROM ALL_TAB_COLUMNS@JDEDTADL C ',
'    INNER JOIN tablesObjetos  I ON C.TABLE_NAME =I.TABLENAME order by C.TABLE_NAME,C.COLUMN_ID',
')',
',tablesDTA as (',
'    SELECT DISTINCT C.TABLE_NAME||''.''||c.COLUMN_NAME D,C.TABLE_NAME||''.''||c.COLUMN_NAME R ,C.TABLE_NAME,c.COLUMN_NAME , C.COLUMN_ID ORDEN ',
'    FROM ALL_TAB_COLUMNS  C ',
'    INNER JOIN tablesObjetos  I ON C.TABLE_NAME =I.TABLENAME order by C.TABLE_NAME,C.COLUMN_ID',
')',
',RESUMEN AS ',
'(SELECT d,r,ORDEN FROM tablesJDE ',
'UNION ALL',
'SELECT d,r,ORDEN FROM tablesDTA)',
'SELECT D,R FROM RESUMEN;'))
,p_lov_display_extra=>true
,p_lov_display_null=>true
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'LOV'
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(880643875857754687)
,p_name=>'C002'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'C002'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_DISPLAY_ONLY'
,p_heading=>'Alias '
,p_heading_alignment=>'LEFT'
,p_display_sequence=>60
,p_value_alignment=>'LEFT'
,p_attribute_05=>'HTML'
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_enable_hide=>false
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(880647897191754727)
,p_name=>'C004'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'C004'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_DISPLAY_ONLY'
,p_heading=>'Tipo Dato'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>80
,p_value_alignment=>'LEFT'
,p_attribute_02=>'LOV'
,p_attribute_05=>'PLAIN'
,p_lov_type=>'STATIC'
,p_lov_source=>'STATIC2:Texto;T,Numero;N,Decimal;D,Moneda;M,Fecha;F'
,p_lov_display_extra=>true
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'LOV'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_default_type=>'STATIC'
,p_default_expression=>'T'
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_interactive_grid(
 p_id=>wwv_flow_imp.id(839376761193725004)
,p_internal_uid=>839376761193725004
,p_is_editable=>true
,p_edit_operations=>'u'
,p_lost_update_check_type=>'VALUES'
,p_submit_checked_rows=>false
,p_lazy_loading=>true
,p_requires_filter=>false
,p_show_nulls_as=>'-'
,p_select_first_row=>true
,p_fixed_row_height=>true
,p_pagination_type=>'SET'
,p_show_total_row_count=>true
,p_show_toolbar=>true
,p_toolbar_buttons=>'SEARCH_COLUMN:SEARCH_FIELD:ACTIONS_MENU:SAVE'
,p_enable_save_public_report=>false
,p_enable_subscriptions=>true
,p_enable_flashback=>false
,p_define_chart_view=>false
,p_enable_download=>true
,p_download_formats=>'XLSX'
,p_enable_mail_download=>true
,p_fixed_header=>'NONE'
,p_show_icon_view=>false
,p_show_detail_view=>false
,p_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'function (config) {',
'	return cargarToolbar(config);',
'}'))
);
wwv_flow_imp_page.create_ig_report(
 p_id=>wwv_flow_imp.id(839402104602957734)
,p_interactive_grid_id=>wwv_flow_imp.id(839376761193725004)
,p_static_id=>'5406172'
,p_type=>'PRIMARY'
,p_default_view=>'GRID'
,p_rows_per_page=>1000
,p_show_row_number=>false
,p_settings_area_expanded=>true
);
wwv_flow_imp_page.create_ig_report_view(
 p_id=>wwv_flow_imp.id(839402281731957734)
,p_report_id=>wwv_flow_imp.id(839402104602957734)
,p_view_type=>'GRID'
,p_stretch_columns=>true
,p_srv_exclude_null_values=>false
,p_srv_only_display_columns=>true
,p_edit_mode=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(199500667132744624)
,p_view_id=>wwv_flow_imp.id(839402281731957734)
,p_display_seq=>6
,p_column_id=>wwv_flow_imp.id(199097041222689944)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(305485020900903760)
,p_view_id=>wwv_flow_imp.id(839402281731957734)
,p_display_seq=>5
,p_column_id=>wwv_flow_imp.id(880647897191754727)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>120
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(839402752675957738)
,p_view_id=>wwv_flow_imp.id(839402281731957734)
,p_display_seq=>2
,p_column_id=>wwv_flow_imp.id(839376866280725005)
,p_is_visible=>false
,p_is_frozen=>false
,p_sort_order=>1
,p_sort_direction=>'ASC'
,p_sort_nulls=>'LAST'
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(839413043797040074)
,p_view_id=>wwv_flow_imp.id(839402281731957734)
,p_display_seq=>1
,p_column_id=>wwv_flow_imp.id(839377442858725011)
,p_is_visible=>false
,p_is_frozen=>true
,p_width=>41
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(880650876884786641)
,p_view_id=>wwv_flow_imp.id(839402281731957734)
,p_display_seq=>3
,p_column_id=>wwv_flow_imp.id(880643814773754686)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(880651740929786645)
,p_view_id=>wwv_flow_imp.id(839402281731957734)
,p_display_seq=>4
,p_column_id=>wwv_flow_imp.id(880643875857754687)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(839377408033725010)
,p_plug_name=>'Botones'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(38290276266120143)
,p_plug_display_sequence=>30
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'REGION_POSITION_03'
,p_location=>null
,p_ai_enabled=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(99830523695957591)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(839377408033725010)
,p_button_name=>'Cerrar'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860181880106559)
,p_button_image_alt=>'Cerrar'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(199097511802689981)
,p_name=>'P443_TABLAPROCESO'
,p_item_sequence=>150
,p_item_plug_id=>wwv_flow_imp.id(839375462600724991)
,p_prompt=>'Tablaproceso'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(307695177942925810)
,p_name=>'P443_ACCION'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(839375462600724991)
,p_prompt=>'Accion'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(311234574857486406)
,p_name=>'P443_TIPOOBJETO'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_imp.id(839375462600724991)
,p_prompt=>'Tipoobjeto'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(328399880625898793)
,p_name=>'P443_TIENE_DATOS'
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_imp.id(839375462600724991)
,p_prompt=>'Tiene Datos'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(344001279404969204)
,p_name=>'P443_NUMERO_REGISTROS'
,p_item_sequence=>120
,p_item_plug_id=>wwv_flow_imp.id(839375462600724991)
,p_prompt=>'Numero Registros'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(839377475341725094)
,p_name=>'P443_OBJETO'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(839375462600724991)
,p_prompt=>'Objeto'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(843963680593467526)
,p_name=>'P443_READONLY'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(839375462600724991)
,p_prompt=>'Readonly'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_read_only_when_type=>'ALWAYS'
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(99839875409957644)
,p_name=>'cargarColeccion'
,p_event_sequence=>10
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(839376465856725001)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'NATIVE_IG|REGION TYPE|interactivegridsave'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(99840373709957644)
,p_event_id=>wwv_flow_imp.id(99839875409957644)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    v_datos CLOB;',
'    v_tieneCompleto number;',
'BEGIN',
'    v_datos := '''';',
'    SELECT ',
'        count(distinct 1)',
'        into v_tieneCompleto',
'    FROM APEX_COLLECTIONS ',
'    WHERE COLLECTION_NAME = ''COLECCION_COLUMNAS'' ',
'    and trim(c001) is null ;',
'    :P443_TIENE_DATOS:=1;',
'    if (v_tieneCompleto=1)then :P443_TIENE_DATOS:=0; return;END IF;',
'    SELECT ',
'    JSON_ARRAYAGG(JSON_OBJECT(*) RETURNING CLOB)',
'    into v_datos',
'    FROM (',
'        SELECT ',
'            seq_id ID,',
'            c001 COLUMNA,',
'            c002 alias,',
'            c003 COMENTARIO_COLUMNA,',
'            c004 TIPO_DATO',
'        FROM APEX_COLLECTIONS ',
'        WHERE COLLECTION_NAME = ''COLECCION_COLUMNAS'' ',
'        ORDER BY seq_id',
'    );',
'    :P443_TIENE_DATOS:=1;',
'    :G_GT_COLUMNAS:=v_datos;',
'END;'))
,p_attribute_03=>'G_GT_COLUMNAS'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(99964295898702824)
,p_event_id=>wwv_flow_imp.id(99839875409957644)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'if ($v("P443_TIENE_DATOS")===0){',
'    mensajeError("Los campos de columnas deben ser completos.");',
'',
'}'))
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(99834904775957620)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_region_id=>wwv_flow_imp.id(839376465856725001)
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Columnas - Save Interactive Grid Data'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare ',
'    v_alias varchar2(3999);',
'    v_columna varchar2(3999);',
'    v_comentario varchar2(3999);',
'    v_tipodato varchar2(3999);',
'    v_cont  number;',
'    v_indx number;',
'    v_APEXROW_STATUS varchar2(399);',
'BEGIN',
'    v_APEXROW_STATUS:=:APEX$ROW_STATUS;',
'    v_columna :=trim(upper(:C001));',
'    v_alias:=   :C002;',
'    v_comentario :=:C003;',
'    v_tipodato:=:C004;',
'',
'    case v_APEXROW_STATUS  ',
'        WHEN ''U'' THEN',
'            APEX_COLLECTION.UPDATE_MEMBER(p_collection_name => ''COLECCION_COLUMNAS'',p_seq => :seq_id,p_c001=>v_columna,p_c002=>v_alias,p_c003=>v_comentario,p_c004=>v_tipodato);',
'    END CASE;',
'EXCEPTION WHEN OTHERS THEN ',
'    apex_error.add_error (',
'    p_message          => ''ERROR::''||v_APEXROW_STATUS||'' ''||SQLERRM  ,',
'    p_display_location =>apex_error.c_inline_in_notification );',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_only_for_changed_rows=>'N'
,p_internal_uid=>99834904775957620
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(99837012712957640)
,p_process_sequence=>30
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Cargarcoleccion'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    v_datos CLOB;',
'    v_tieneCompleto number;',
'BEGIN',
'    v_datos := '''';',
'    SELECT ',
'        count(distinct 1)',
'        into v_tieneCompleto',
'    FROM APEX_COLLECTIONS ',
'    WHERE COLLECTION_NAME = ''COLECCION_COLUMNAS'' ',
'    and trim(c001) is null ;',
'    if (v_tieneCompleto=1)then ',
'        apex_error.add_error (',
'            p_message          => ''Los campos de columnas deben ser completos.'',',
'            p_display_location =>apex_error.c_inline_in_notification ',
'        );',
'        :P443_TIENE_DATOS:=0;',
'        --return;',
'    END IF;',
'    SELECT ',
'    JSON_ARRAYAGG(JSON_OBJECT(*) RETURNING CLOB)',
'    into v_datos',
'    FROM (',
'        SELECT ',
'            seq_id ID,',
'            c001 COLUMNA,',
'            c002 alias,',
'            c003 COMENTARIO_COLUMNA,',
'            c004 TIPO_DATO',
'        FROM APEX_COLLECTIONS ',
'        WHERE COLLECTION_NAME = ''COLECCION_COLUMNAS'' ',
'        ORDER BY seq_id',
'    );',
'    :P443_TIENE_DATOS:=1;',
'    :G_GT_COLUMNAS:=v_datos;',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_process_error_message=>unistr('Ocurri\00F3 un error al procesar la informaci\00F3n.')
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(99830523695957591)
,p_process_success_message=>'Los datos se han actualizado correctamente.'
,p_internal_uid=>99837012712957640
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(99836620913957639)
,p_process_sequence=>40
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_CLOSE_WINDOW'
,p_process_name=>'Close Dialog '
,p_attribute_01=>'G_GT_COLUMNAS'
,p_attribute_02=>'Y'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(99830523695957591)
,p_process_when=>'P443_TIENE_DATOS'
,p_process_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_process_when2=>'1'
,p_internal_uid=>99836620913957639
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(99835442810957639)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'por borrar'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
':G_GT_OBJETOS:=''F0101:F0411'';',
':G_GT_COLUMNAS:=NULL;',
':P443_TABLAPROCESO:=''T_FINZ_DISTRIBUCIONASC'';',
'  IF NOT APEX_COLLECTION.COLLECTION_EXISTS(''COLECCION_COLUMNAS'') THEN',
'     APEX_COLLECTION.CREATE_COLLECTION(''COLECCION_COLUMNAS'');',
'    END IF;',
'    IF APEX_COLLECTION.COLLECTION_EXISTS(''COLECCION_COLUMNAS'') THEN',
'     APEX_COLLECTION.TRUNCATE_COLLECTION(''COLECCION_COLUMNAS'');',
'    END IF;'))
,p_process_clob_language=>'PLSQL'
,p_process_when_type=>'NEVER'
,p_internal_uid=>99835442810957639
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(99836279284957639)
,p_process_sequence=>20
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'SetupPage'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare ',
'    v_contador number;',
'begin',
'    IF APEX_COLLECTION.COLLECTION_EXISTS(''COLECCION_COLUMNAS'') THEN',
'        APEX_COLLECTION.TRUNCATE_COLLECTION(''COLECCION_COLUMNAS'');        ',
'    END IF;',
'    EXECUTE IMMEDIATE ''TRUNCATE TABLE T_TMP_B DROP STORAGE'';',
'    IF(:G_GT_OBJETOS IS NOT NULL)THEN :P443_OBJETO:= :G_GT_OBJETOS ; END IF;    ',
'    ',
'    INSERT INTO T_TMP_B(TXT01,NUM01,TXT02,TXT03,TXT04,TXT05)',
'        WITH T_JSON AS(',
'            SELECT ROWNUM ORDEN, ID, COLUMNA, ALIAS, TIPO_DATO, COMENTARIO_COLUMNA',
'            FROM JSON_TABLE(:G_GT_COLUMNAS,''$[*]''',
'                COLUMNS (ID NUMBER PATH ''$.ID'',COLUMNA VARCHAR2(3999) PATH ''$.COLUMNA'',ALIAS VARCHAR2(3999) PATH ''$.ALIAS'',TIPO_DATO VARCHAR2(5) PATH ''$.TIPO_DATO'',COMENTARIO_COLUMNA VARCHAR2(3999) PATH ''$.COMENTARIO_COLUMNA'')',
'            )',
'        )',
'        ,T_COLUMNS AS (',
'                SELECT c.column_id ID,c.column_name ALIAS,case when c.data_type like ''VARCHAR%'' then ''T'' when c.data_type like ''NUMBER%'' then ''N'' when c.data_type like ''DECIMAL%'' then ''M'' when c.data_type like ''DATE'' then ''F'' END TIPO_DATO,',
'                        TRIM(cc.comments) COMENTARIO_COLUMNA',
'                FROM    all_tab_columns   c',
'                LEFT JOIN all_col_comments cc ON cc.owner = c.owner AND cc.table_name  = c.table_name AND cc.column_name = c.column_name',
'                WHERE   1=1 AND c.table_name = upper(:P443_TABLAPROCESO)',
'                AND c.column_name!=''GLPKY''',
'                ORDER BY c.column_id',
'        )',
'        SELECT ''COLECCION_COLUMNAS'' COLLECTTION_NAME,A.ID, nvl(B.COLUMNA,A.ALIAS),A.ALIAS,NVL(B.TIPO_DATO,A.TIPO_DATO),A.COMENTARIO_COLUMNA FROM T_COLUMNS A LEFT JOIN T_JSON B ON A.ALIAS=B.ALIAS;',
'        ',
'    FOR coltab IN (SELECT TXT01 COLLECTTION_NAME ,NUM01 ID,TXT02 COLUMNA,TXT03 ALIAS,TXT04 TIPO_DATO ,TXT05 COMENTARIO_COLUMNA FROM T_TMP_B ORDER BY ID)',
'    LOOP ',
'        APEX_COLLECTION.ADD_MEMBER(',
'            p_collection_name =>''COLECCION_COLUMNAS'',',
'            p_c001 => coltab.COLUMNA,',
'            p_c002 => coltab.alias,',
'            p_c003 => coltab.COMENTARIO_COLUMNA,',
'            p_c004 => coltab.TIPO_DATO',
'        );        ',
'    END LOOP;',
'    ',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>99836279284957639
);
wwv_flow_imp.component_end;
end;
/
