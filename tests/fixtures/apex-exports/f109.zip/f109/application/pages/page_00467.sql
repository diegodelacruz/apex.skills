prompt --application/pages/page_00467
begin
--   Manifest
--     PAGE: 00467
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>109
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_page.create_page(
 p_id=>467
,p_name=>'Activos Fijos - Carga Masiva'
,p_alias=>'CARGA-MASIVA'
,p_step_title=>'Carga Masiva'
,p_autocomplete_on_off=>'OFF'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'th[headers="colDescripcion"],  /* encabezado */',
'td[headers="colDescripcion"] { /* celdas */',
'    width: 800px !important;',
'    max-width: 800px;',
'    white-space: nowrap;',
'    overflow: hidden;',
'    text-overflow: ellipsis;',
'}',
''))
,p_page_template_options=>'#DEFAULT#'
,p_page_component_map=>'18'
,p_last_updated_on=>wwv_flow_imp.dz('20260327152653Z')
,p_last_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(105937919052040235)
,p_plug_name=>'Carga archivo'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(38289867500120143)
,p_plug_display_sequence=>20
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(106108532275266779)
,p_plug_name=>'Barra de acciones'
,p_region_template_options=>'#DEFAULT#:t-Form--stretchInputs'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(38289497777120142)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_location=>null
,p_menu_id=>wwv_flow_imp.id(37761271469106475)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(37860983999106559)
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(106487907523337846)
,p_plug_name=>'Resumen'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(38289867500120143)
,p_plug_display_sequence=>50
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(108657575713160003)
,p_plug_name=>'Carga Archivo'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(95503811913299190)
,p_plug_display_sequence=>40
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select X.ID ID,',
'       C01, C02, C03, C04, C05, C06, C07, C08, C09, C10, C11, C12, C13, C14, C15, C16, C17, C18, C19, C20,',
'       C21, C22, C23, C24, C25, C26, C27, C28, C29, C30, C31, C32, C33, C34, C35, C36, C37, C38, C39, C40,',
'       C41, C42, C43, C44, C45, C46, C47, C48, C49, C50,',
'       COLUMNA,DESCRIPCION',
'  from VT_APEX_EXCEL X,T_APEX_EXCEL_ERRORES Y',
'  WHERE X.ID=ID_FILA(+)'))
,p_plug_source_type=>'NATIVE_IR'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(108657611636160004)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'MALBAN'
,p_internal_uid=>108657611636160004
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(108657787417160005)
,p_db_column_name=>'ID'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Id'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(108657838281160006)
,p_db_column_name=>'C01'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'C01'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(108657914019160007)
,p_db_column_name=>'C02'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Compania'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(108658060857160008)
,p_db_column_name=>'C03'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>unistr(' C\00F3d. ERP')
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(108658113822160009)
,p_db_column_name=>'C04'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>unistr('Descripci\00F3n 2')
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(108658207637160010)
,p_db_column_name=>'C05'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>unistr('Descripci\00F3n 3')
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(108658341437160011)
,p_db_column_name=>'C06'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>unistr('C\00F3d. Tipo')
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(108658454345160012)
,p_db_column_name=>'C07'
,p_display_order=>80
,p_column_identifier=>'H'
,p_column_label=>unistr('C\00F3d. Categor\00EDa')
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(108658512421160013)
,p_db_column_name=>'C08'
,p_display_order=>90
,p_column_identifier=>'I'
,p_column_label=>unistr('C\00F3d. Subcategor\00EDa')
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(108658637146160014)
,p_db_column_name=>'C09'
,p_display_order=>100
,p_column_identifier=>'J'
,p_column_label=>'Costo'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(108658797765160015)
,p_db_column_name=>'C10'
,p_display_order=>110
,p_column_identifier=>'K'
,p_column_label=>'Depreciable'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(108658863217160016)
,p_db_column_name=>'C11'
,p_display_order=>120
,p_column_identifier=>'L'
,p_column_label=>unistr('M\00E9todo Dep.')
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(108658903974160017)
,p_db_column_name=>'C12'
,p_display_order=>130
,p_column_identifier=>'M'
,p_column_label=>unistr('Meses Vida \00FCtil')
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(108659044037160018)
,p_db_column_name=>'C13'
,p_display_order=>140
,p_column_identifier=>'N'
,p_column_label=>unistr('Convensi\00F3n Dep.')
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(108659194905160019)
,p_db_column_name=>'C14'
,p_display_order=>150
,p_column_identifier=>'O'
,p_column_label=>'Valor Resisual'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(108659241570160020)
,p_db_column_name=>'C15'
,p_display_order=>160
,p_column_identifier=>'P'
,p_column_label=>'Centro de Costo'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(108659351015160021)
,p_db_column_name=>'C16'
,p_display_order=>170
,p_column_identifier=>'Q'
,p_column_label=>'Fecha Ini. Dep.'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(108659463881160022)
,p_db_column_name=>'C17'
,p_display_order=>180
,p_column_identifier=>'R'
,p_column_label=>'Fecha Fini Dep.'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(108659545270160023)
,p_db_column_name=>'C18'
,p_display_order=>190
,p_column_identifier=>'S'
,p_column_label=>unistr('C\00F3d. Ubicaci\00F3n')
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(108659683814160024)
,p_db_column_name=>'C19'
,p_display_order=>200
,p_column_identifier=>'T'
,p_column_label=>unistr('C\00F3d. Custodio')
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(108659702589160025)
,p_db_column_name=>'C20'
,p_display_order=>210
,p_column_identifier=>'U'
,p_column_label=>unistr('C\00F3d. Proveedor')
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(108659826147160026)
,p_db_column_name=>'C21'
,p_display_order=>220
,p_column_identifier=>'V'
,p_column_label=>unistr('N\00FAmero Factura')
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(108659944716160027)
,p_db_column_name=>'C22'
,p_display_order=>230
,p_column_identifier=>'W'
,p_column_label=>'Tipo Orden'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(108660091488160028)
,p_db_column_name=>'C23'
,p_display_order=>240
,p_column_identifier=>'X'
,p_column_label=>'Orden de Compra'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(108660168630160029)
,p_db_column_name=>'C24'
,p_display_order=>250
,p_column_identifier=>'Y'
,p_column_label=>unistr('C\00F3d. Libro')
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(108660241821160030)
,p_db_column_name=>'C25'
,p_display_order=>260
,p_column_identifier=>'Z'
,p_column_label=>'CC Plan de Cuenta'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(108660302998160031)
,p_db_column_name=>'C26'
,p_display_order=>270
,p_column_identifier=>'AA'
,p_column_label=>'Objeto  Plan de Cuenta'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(108660471262160032)
,p_db_column_name=>'C27'
,p_display_order=>280
,p_column_identifier=>'AB'
,p_column_label=>'Auxiliar Plan de Cuenta'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(108660553003160033)
,p_db_column_name=>'C28'
,p_display_order=>290
,p_column_identifier=>'AC'
,p_column_label=>'C28'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(108660604775160034)
,p_db_column_name=>'C29'
,p_display_order=>300
,p_column_identifier=>'AD'
,p_column_label=>'C29'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(108660751860160035)
,p_db_column_name=>'C30'
,p_display_order=>310
,p_column_identifier=>'AE'
,p_column_label=>'C30'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(108660809848160036)
,p_db_column_name=>'C31'
,p_display_order=>320
,p_column_identifier=>'AF'
,p_column_label=>'C31'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(108660942680160037)
,p_db_column_name=>'C32'
,p_display_order=>330
,p_column_identifier=>'AG'
,p_column_label=>'C32'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(108661065978160038)
,p_db_column_name=>'C33'
,p_display_order=>340
,p_column_identifier=>'AH'
,p_column_label=>'C33'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(108661114840160039)
,p_db_column_name=>'C34'
,p_display_order=>350
,p_column_identifier=>'AI'
,p_column_label=>'C34'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(108661213012160040)
,p_db_column_name=>'C35'
,p_display_order=>360
,p_column_identifier=>'AJ'
,p_column_label=>'C35'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(108661336748160041)
,p_db_column_name=>'C36'
,p_display_order=>370
,p_column_identifier=>'AK'
,p_column_label=>'C36'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(108661491837160042)
,p_db_column_name=>'C37'
,p_display_order=>380
,p_column_identifier=>'AL'
,p_column_label=>'C37'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(108661525345160043)
,p_db_column_name=>'C38'
,p_display_order=>390
,p_column_identifier=>'AM'
,p_column_label=>'C38'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(108661648522160044)
,p_db_column_name=>'C39'
,p_display_order=>400
,p_column_identifier=>'AN'
,p_column_label=>'C39'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(108661719393160045)
,p_db_column_name=>'C40'
,p_display_order=>410
,p_column_identifier=>'AO'
,p_column_label=>'C40'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(108661845852160046)
,p_db_column_name=>'C41'
,p_display_order=>420
,p_column_identifier=>'AP'
,p_column_label=>'C41'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(108661992783160047)
,p_db_column_name=>'C42'
,p_display_order=>430
,p_column_identifier=>'AQ'
,p_column_label=>'C42'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(108662028022160048)
,p_db_column_name=>'C43'
,p_display_order=>440
,p_column_identifier=>'AR'
,p_column_label=>'C43'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(108662135644160049)
,p_db_column_name=>'C44'
,p_display_order=>450
,p_column_identifier=>'AS'
,p_column_label=>'C44'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(108662281725160050)
,p_db_column_name=>'C45'
,p_display_order=>460
,p_column_identifier=>'AT'
,p_column_label=>'C45'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(108676849972627601)
,p_db_column_name=>'C46'
,p_display_order=>470
,p_column_identifier=>'AU'
,p_column_label=>'C46'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(108676998366627602)
,p_db_column_name=>'C47'
,p_display_order=>480
,p_column_identifier=>'AV'
,p_column_label=>'C47'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(108677007420627603)
,p_db_column_name=>'C48'
,p_display_order=>490
,p_column_identifier=>'AW'
,p_column_label=>'C48'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(108677140286627604)
,p_db_column_name=>'C49'
,p_display_order=>500
,p_column_identifier=>'AX'
,p_column_label=>'C49'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(108677241281627605)
,p_db_column_name=>'C50'
,p_display_order=>510
,p_column_identifier=>'AY'
,p_column_label=>'C50'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(108677388041627606)
,p_db_column_name=>'COLUMNA'
,p_display_order=>520
,p_column_identifier=>'AZ'
,p_column_label=>'Columna'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(108677454873627607)
,p_db_column_name=>'DESCRIPCION'
,p_display_order=>530
,p_column_identifier=>'BA'
,p_column_label=>'Errorres'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_static_id=>'colDescripcion'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(108699259438639808)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'1086993'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'ID:C02:C03:C04:C05:C06:C07:C08:C09:C10:C11:C12:C13:C14:C15:C16:C17:C18:C19:C20:C21:C22:C23:C24:C25:C26:C27:DESCRIPCION:C28:C29:C30:C31:C32:C33:C34:C35:C36:C37:C38:C39:C40:C41:C42:C43:C44:C45:C46:C47:C48:C49:C50:'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(117850562082716920)
,p_plug_name=>'Items'
,p_region_name=>'secItems'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(38289867500120143)
,p_plug_display_sequence=>10
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(105937548861040231)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(106108532275266779)
,p_button_name=>'Cancelar'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860056812106557)
,p_button_image_alt=>'Cancelar'
,p_button_position=>'ABOVE_BOX'
,p_button_alignment=>'LEFT'
,p_button_redirect_url=>'f?p=&APP_ID.:460:&SESSION.::&DEBUG.:460::'
,p_icon_css_classes=>'fa-long-arrow-left'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(105937685768040232)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(106108532275266779)
,p_button_name=>'Descargar'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860056812106557)
,p_button_image_alt=>'Descargar Formato'
,p_button_position=>'ABOVE_BOX'
,p_button_alignment=>'RIGHT'
,p_icon_css_classes=>'fa-file-arrow-down'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(105937746887040233)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(106108532275266779)
,p_button_name=>'Validar'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860056812106557)
,p_button_image_alt=>'Validar carga'
,p_button_position=>'ABOVE_BOX'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-badge-check'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(105937810269040234)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(106108532275266779)
,p_button_name=>'Confirmar'
,p_button_static_id=>'btnConfirmar'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860056812106557)
,p_button_image_alt=>'Confirmar carga'
,p_button_position=>'ABOVE_BOX'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
,p_button_condition=>'P467_TOTALERROR'
,p_button_condition_type=>'ITEM_NOT_NULL_OR_ZERO'
,p_icon_css_classes=>'fa-calendar-check-o'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(105938162918040237)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(105937919052040235)
,p_button_name=>'Cargar'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'t-Button--large:t-Button--success:t-Button--pillEnd'
,p_button_template_id=>wwv_flow_imp.id(37860056812106557)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Cargar'
,p_button_position=>'TOP'
,p_button_alignment=>'RIGHT'
,p_icon_css_classes=>'fa-file-arrow-up'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(105938044762040236)
,p_name=>'P467_CARGAARCHIVO'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(105937919052040235)
,p_prompt=>'Carga de archivo : (.xlsx)'
,p_display_as=>'NATIVE_FILE'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'APEX_APPLICATION_TEMP_FILES'
,p_attribute_09=>'SESSION'
,p_attribute_10=>'N'
,p_attribute_12=>'INLINE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(106488077641337847)
,p_name=>'P467_TOTALREGISTROS'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(106487907523337846)
,p_prompt=>'Totales:  '
,p_post_element_text=>'    procesados'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_warn_on_unsaved_changes=>'I'
,p_attribute_01=>'N'
,p_attribute_02=>'Y'
,p_attribute_03=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(106488101402337848)
,p_name=>'P467_TOTALVALIDOS'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(106487907523337846)
,p_prompt=>unistr('v\00E1lidos: ')
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'Y'
,p_attribute_03=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(106488277746337849)
,p_name=>'P467_TOTALERROR'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(106487907523337846)
,p_prompt=>'con error: '
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'Y'
,p_attribute_03=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(117850624634716921)
,p_name=>'P467_MENSAJE'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(117850562082716920)
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>30
,p_cHeight=>5
,p_read_only_when_type=>'ALWAYS'
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(106488398638337850)
,p_name=>'Validar'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(105937746887040233)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(108657340673160001)
,p_event_id=>wwv_flow_imp.id(106488398638337850)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    V_ERRORES varchar2(4000);',
'    V_TOTAL     number :=0;',
'    V_VALIDOS     number :=0;',
'    V_CONERROR     number :=0;',
'    V_TOTERROR     NUMBER  :=0;',
'',
'    CURSOR CARGA IS',
'        SELECT * FROM VT_APEX_EXCEL;',
'',
'BEGIN',
'   -- cuento registros cargados',
'   SELECT COUNT(*) INTO V_TOTAL',
'   FROM VT_APEX_EXCEL;',
'   ',
'   :P467_TOTALREGISTROS:=V_TOTAL;',
'',
unistr('   -- verifico por cada registro si la informaci\00F3n es v\00E1lida y contabilizo errores'),
'   PK_FINZ_ACTIVOSFIJOS.SP_VALIDA_CARGAEXCEL(V_TOTERROR);',
'',
'   ',
'   :P467_TOTALVALIDOS:=V_TOTAL-V_TOTERROR;',
'',
'   :P467_TOTALERROR:=V_TOTERROR;',
'',
'   :P467_MENSAJE:=''VALIDACION FINALIZADA'';',
'        ',
'END;   '))
,p_attribute_03=>'P467_TOTALREGISTROS,P467_TOTALVALIDOS,P467_TOTALERROR,P467_MENSAJE'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(108677676920627609)
,p_event_id=>wwv_flow_imp.id(106488398638337850)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(108657575713160003)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(108677706952627610)
,p_event_id=>wwv_flow_imp.id(106488398638337850)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(106487907523337846)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(108677597725627608)
,p_event_id=>wwv_flow_imp.id(106488398638337850)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(105937810269040234)
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'var totalError = $v("P467_TOTALERROR"); // Obtiene el valor del item',
'',
'if (totalError === "0" || totalError === "") {',
unistr('    // Si NO hay errores, mostrar el bot\00F3n'),
'    $("#btnConfirmar").show();',
'} else {',
unistr('    // Si hay errores, ocultar el bot\00F3n'),
'    $("#btnConfirmar").hide();',
'}',
'',
''))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(117850351227716918)
,p_name=>'crear_af'
,p_event_sequence=>20
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(105937810269040234)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(117850452935716919)
,p_event_id=>wwv_flow_imp.id(117850351227716918)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'   V_MENSAJE    clob;--(100);',
'BEGIN',
'    -- ejecuto el procedimiento para crear AF',
'    pk_finz_activosfijos.SP_CREAR_MASIVAMENTE(:APP_USER,V_MENSAJE);',
'    :P467_MENSAJE:=V_MENSAJE;',
'    --apex_application.g_print_success_message := V_MENSAJE;',
'END;'))
,p_attribute_03=>'P467_MENSAJE'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(106487676750337843)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Cargar datos_2'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    v_hoja       VARCHAR2(1000);',
'    v_query      CLOB;',
'BEGIN',
unistr('    -- Borrar colecci\00F3n si existe'),
'    IF APEX_COLLECTION.COLLECTION_EXISTS(''TABLA_EXCEL'') THEN',
'        APEX_COLLECTION.DELETE_COLLECTION(''TABLA_EXCEL'');',
'    END IF;',
'    ',
'    -- borro tabla temporal de errores',
'',
'    DELETE FROM T_APEX_EXCEL_ERRORES;',
'    ',
'    -- Obtener la primera hoja',
'    SELECT column_value INTO v_hoja',
'    FROM TABLE(PK_APEX_XLS.get_worksheets(p_xlsx_name => :P467_CARGAARCHIVO))',
'    WHERE ROWNUM = 1;',
'',
unistr('    -- Crear colecci\00F3n temporal con todo el Excel, incluyendo cabeceras'),
'    v_query := ''SELECT * FROM TABLE(',
'                    PK_APEX_XLS.parse(',
'                        p_xlsx_name => '''''' || :P467_CARGAARCHIVO || '''''',',
'                        p_worksheet_name => ''''''||''sheet1''||''''''',
'                    )',
'                )'';',
'',
'    APEX_COLLECTION.CREATE_COLLECTION_FROM_QUERY(',
'        p_collection_name => ''TABLA_EXCEL'',',
'        p_query           => v_query,',
'        p_generate_md5    => ''YES''',
'    );',
'',
'    -- Borrar la primera fila original (cabecera)',
'    APEX_COLLECTION.DELETE_MEMBER(',
'        p_collection_name => ''TABLA_EXCEL'',',
'        p_seq             => 1',
'    );',
'    :P467_MENSAJE:=''CARGA FINALIZADA'';',
'END;',
''))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(105938162918040237)
,p_process_when=>'P467_CARGAARCHIVO'
,p_process_when_type=>'ITEM_IS_NOT_NULL'
,p_internal_uid=>106487676750337843
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(106487474734337841)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Validar datos'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    V_ERRORES varchar2(4000);',
'    V_TOTAL     number :=0;',
'    V_VALIDOS     number :=0;',
'    V_CONERROR     number :=0;',
'',
'BEGIN',
'',
'   SELECT COUNT(*) INTO V_TOTAL',
'   FROM VT_APEX_EXCEL;',
'   ',
'   :P467_TOTALREGISTROS:=V_TOTAL;',
unistr('   :P467_MENSAJE:=''Validaci\00F3n finalizada'';'),
'        ',
'END;   '))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(105937746887040233)
,p_process_when=>'1=2'
,p_process_when_type=>'EXPRESSION'
,p_process_when2=>'PLSQL'
,p_internal_uid=>106487474734337841
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(106487575760337842)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Borrar Coleccion'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'IF  APEX_COLLECTION.COLLECTION_EXISTS (p_collection_name => ''TABLA_EXCEL'') THEN',
'       ',
'    APEX_COLLECTION.DELETE_COLLECTION(p_collection_name => ''TABLA_EXCEL'');',
'       ',
'END IF;'))
,p_process_clob_language=>'PLSQL'
,p_process_when=>'P467_CARGAARCHIVO'
,p_process_when_type=>'ITEM_IS_NULL'
,p_internal_uid=>106487575760337842
);
wwv_flow_imp.component_end;
end;
/
