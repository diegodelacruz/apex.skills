prompt --application/pages/page_00448
begin
--   Manifest
--     PAGE: 00448
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>109
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_page.create_page(
 p_id=>448
,p_name=>'PYG INDUSTRIALES - DLG - DIMENSION DISTRIBUCION (UR)'
,p_alias=>'PYG-INDUSTRIALES-DIMENSION-DISTRIBUCION'
,p_page_mode=>'MODAL'
,p_step_title=>'PYG INDUSTRIALES - DIMENSION DISTRIBUCION'
,p_autocomplete_on_off=>'OFF'
,p_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'',
''))
,p_javascript_code_onload=>'$(secItems).hide();'
,p_step_template=>wwv_flow_imp.id(37774372912106498)
,p_page_template_options=>'#DEFAULT#'
,p_dialog_css_classes=>'dlg-sin-cerrar'
,p_protection_level=>'C'
,p_page_component_map=>'16'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(127437502784147913)
,p_plug_name=>'items'
,p_region_name=>'secItems'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(38289867500120143)
,p_plug_display_sequence=>30
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(127438008942147918)
,p_plug_name=>'Barra de Acciones'
,p_region_template_options=>'#DEFAULT#:t-Form--stretchInputs'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(38289497777120142)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_location=>null
,p_menu_id=>wwv_flow_imp.id(37761271469106475)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(37860983999106559)
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(127439210196147930)
,p_plug_name=>unistr('Formulario Dimensi\00F3n de Costo')
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:t-Region--removeHeader:t-Region--noBorder:t-Region--scrollBody:t-Form--noPadding'
,p_plug_template=>wwv_flow_imp.id(37807886111106520)
,p_plug_display_sequence=>20
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(127583160318192022)
,p_plug_name=>'REGOC01'
,p_parent_plug_id=>wwv_flow_imp.id(127439210196147930)
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(38289867500120143)
,p_plug_display_sequence=>20
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(127583233611192023)
,p_plug_name=>'REGOC05'
,p_parent_plug_id=>wwv_flow_imp.id(127439210196147930)
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(38289867500120143)
,p_plug_display_sequence=>80
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(127583356915192024)
,p_plug_name=>'REGOC03'
,p_parent_plug_id=>wwv_flow_imp.id(127439210196147930)
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(38289867500120143)
,p_plug_display_sequence=>40
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(127583448304192025)
,p_plug_name=>'REGOC07'
,p_parent_plug_id=>wwv_flow_imp.id(127439210196147930)
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(38289867500120143)
,p_plug_display_sequence=>100
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(127583511852192026)
,p_plug_name=>'REGOC02'
,p_parent_plug_id=>wwv_flow_imp.id(127439210196147930)
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(38289867500120143)
,p_plug_display_sequence=>30
,p_plug_new_grid_row=>false
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(127583620331192027)
,p_plug_name=>'REGOC04'
,p_parent_plug_id=>wwv_flow_imp.id(127439210196147930)
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(38289867500120143)
,p_plug_display_sequence=>70
,p_plug_new_grid_row=>false
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(127583788445192028)
,p_plug_name=>'REGOC06'
,p_parent_plug_id=>wwv_flow_imp.id(127439210196147930)
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(38289867500120143)
,p_plug_display_sequence=>90
,p_plug_new_grid_row=>false
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(127583836199192029)
,p_plug_name=>'REGOC08'
,p_parent_plug_id=>wwv_flow_imp.id(127439210196147930)
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(38289867500120143)
,p_plug_display_sequence=>110
,p_plug_new_grid_row=>false
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(127585247915192043)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(127438008942147918)
,p_button_name=>'Atras'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860056812106557)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Atras'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'LEFT'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-arrow-left'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(127581311784192004)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(127438008942147918)
,p_button_name=>'Anterior'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860181880106559)
,p_button_image_alt=>'Anterior'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
,p_button_condition_type=>'NEVER'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(127581458221192005)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(127438008942147918)
,p_button_name=>'Siguiente'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860181880106559)
,p_button_image_alt=>'Siguiente'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
,p_button_condition_type=>'NEVER'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(127439357501147931)
,p_button_sequence=>50
,p_button_plug_id=>wwv_flow_imp.id(127438008942147918)
,p_button_name=>'Grabar'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860056812106557)
,p_button_image_alt=>'Grabar'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-save'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(127585392010192044)
,p_branch_name=>'Go To Page 444'
,p_branch_action=>'f?p=&APP_ID.:444:&SESSION.::&DEBUG.:444:P444_ID,P444_DIMENSIONES:&G_VALORMTD.,&G_DIMENSIONDIST.&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'BEFORE_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_sequence=>10
,p_branch_condition_type=>'REQUEST_EQUALS_CONDITION'
,p_branch_condition=>'SENDTOLEAVE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(127439490410147932)
,p_name=>'P448_ID'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(127437502784147913)
,p_prompt=>'Id'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(127439555685147933)
,p_name=>'P448_ABT1'
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_imp.id(127583160318192022)
,p_prompt=>'Objeto de Costo 01'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'LOV_FINZ_PGI_DIMENSIONMETODODISTRIBUCION'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
' select  CTABT1||'' - ''|| TRIM(CTDL01) CTDL01,CTABT1 ',
' from ',
' f1620@jdedtadl ORDER BY 1; '))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_grid_label_column_span=>0
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(127439651712147934)
,p_name=>'P448_ABT2'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(127583511852192026)
,p_prompt=>'Objeto de Costo 02'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'LOV_FINZ_PGI_DIMENSIONMETODODISTRIBUCION'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
' select  CTABT1||'' - ''|| TRIM(CTDL01) CTDL01,CTABT1 ',
' from ',
' f1620@jdedtadl ORDER BY 1; '))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_grid_label_column_span=>0
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(127439774847147935)
,p_name=>'P448_ABT3'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(127583356915192024)
,p_prompt=>'Objeto de Costo 03'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'LOV_FINZ_PGI_DIMENSIONMETODODISTRIBUCION'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
' select  CTABT1||'' - ''|| TRIM(CTDL01) CTDL01,CTABT1 ',
' from ',
' f1620@jdedtadl ORDER BY 1; '))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_grid_label_column_span=>0
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(127439822883147936)
,p_name=>'P448_ABT4'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(127583620331192027)
,p_prompt=>'Objeto de Costo 04'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'LOV_FINZ_PGI_DIMENSIONMETODODISTRIBUCION'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
' select  CTABT1||'' - ''|| TRIM(CTDL01) CTDL01,CTABT1 ',
' from ',
' f1620@jdedtadl ORDER BY 1; '))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_grid_label_column_span=>0
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(127439959179147937)
,p_name=>'P448_ABT5'
,p_item_sequence=>160
,p_item_plug_id=>wwv_flow_imp.id(127583233611192023)
,p_prompt=>'Objeto de Costo 05}'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'LOV_FINZ_PGI_DIMENSIONMETODODISTRIBUCION'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
' select  CTABT1||'' - ''|| TRIM(CTDL01) CTDL01,CTABT1 ',
' from ',
' f1620@jdedtadl ORDER BY 1; '))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_grid_label_column_span=>0
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(127440033896147938)
,p_name=>'P448_ABT6'
,p_item_sequence=>180
,p_item_plug_id=>wwv_flow_imp.id(127583788445192028)
,p_prompt=>'Objeto de Costo 06'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'LOV_FINZ_PGI_DIMENSIONMETODODISTRIBUCION'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
' select  CTABT1||'' - ''|| TRIM(CTDL01) CTDL01,CTABT1 ',
' from ',
' f1620@jdedtadl ORDER BY 1; '))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_grid_label_column_span=>0
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(127440121872147939)
,p_name=>'P448_ABT7'
,p_item_sequence=>200
,p_item_plug_id=>wwv_flow_imp.id(127583448304192025)
,p_prompt=>'Objeto de Costo 07'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'LOV_FINZ_PGI_DIMENSIONMETODODISTRIBUCION'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
' select  CTABT1||'' - ''|| TRIM(CTDL01) CTDL01,CTABT1 ',
' from ',
' f1620@jdedtadl ORDER BY 1; '))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_grid_label_column_span=>0
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(127440238937147940)
,p_name=>'P448_ABT8'
,p_item_sequence=>220
,p_item_plug_id=>wwv_flow_imp.id(127583836199192029)
,p_prompt=>'Objeto de Costo 08'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'LOV_FINZ_PGI_DIMENSIONMETODODISTRIBUCION'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
' select  CTABT1||'' - ''|| TRIM(CTDL01) CTDL01,CTABT1 ',
' from ',
' f1620@jdedtadl ORDER BY 1; '))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_grid_label_column_span=>0
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(127581014410192001)
,p_name=>'P448_IDX'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(127437502784147913)
,p_item_default=>'1'
,p_prompt=>'Idx'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(127582618705192017)
,p_name=>'P448_CHK1'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_imp.id(127583160318192022)
,p_prompt=>'Objeto de Costo 01'
,p_display_as=>'NATIVE_SINGLE_CHECKBOX'
,p_grid_label_column_span=>0
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--xlarge:t-Form-fieldContainer--radioButtonGroup'
,p_attribute_01=>'N'
,p_attribute_02=>'S'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(127582948114192020)
,p_name=>'P448_CHK2'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(127583511852192026)
,p_prompt=>'Objeto de Costo 02'
,p_display_as=>'NATIVE_SINGLE_CHECKBOX'
,p_grid_label_column_span=>0
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--xlarge:t-Form-fieldContainer--radioButtonGroup'
,p_attribute_01=>'N'
,p_attribute_02=>'S'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(127583035208192021)
,p_name=>'P448_CHK3'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(127583356915192024)
,p_prompt=>'Objeto de Costo 03'
,p_display_as=>'NATIVE_SINGLE_CHECKBOX'
,p_grid_label_column_span=>0
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--xlarge:t-Form-fieldContainer--radioButtonGroup'
,p_attribute_01=>'N'
,p_attribute_02=>'S'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(127584048624192031)
,p_name=>'P448_CHK7'
,p_item_sequence=>190
,p_item_plug_id=>wwv_flow_imp.id(127583448304192025)
,p_prompt=>'Objeto de Costo 07'
,p_display_as=>'NATIVE_SINGLE_CHECKBOX'
,p_grid_label_column_span=>0
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--xlarge:t-Form-fieldContainer--radioButtonGroup'
,p_attribute_01=>'N'
,p_attribute_02=>'S'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(127584199715192032)
,p_name=>'P448_CHK8'
,p_item_sequence=>210
,p_item_plug_id=>wwv_flow_imp.id(127583836199192029)
,p_prompt=>'Objeto de Costo 08'
,p_display_as=>'NATIVE_SINGLE_CHECKBOX'
,p_grid_label_column_span=>0
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--xlarge:t-Form-fieldContainer--radioButtonGroup'
,p_attribute_01=>'N'
,p_attribute_02=>'S'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(127584238124192033)
,p_name=>'P448_CHK6'
,p_item_sequence=>170
,p_item_plug_id=>wwv_flow_imp.id(127583788445192028)
,p_prompt=>'Objeto de Costo 06'
,p_display_as=>'NATIVE_SINGLE_CHECKBOX'
,p_grid_label_column_span=>0
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--xlarge:t-Form-fieldContainer--radioButtonGroup'
,p_attribute_01=>'N'
,p_attribute_02=>'S'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(127584328392192034)
,p_name=>'P448_CHK5'
,p_item_sequence=>150
,p_item_plug_id=>wwv_flow_imp.id(127583233611192023)
,p_prompt=>'Objeto de Costo 05'
,p_display_as=>'NATIVE_SINGLE_CHECKBOX'
,p_grid_label_column_span=>0
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--xlarge:t-Form-fieldContainer--radioButtonGroup'
,p_attribute_01=>'N'
,p_attribute_02=>'S'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(127584431103192035)
,p_name=>'P448_CHK4'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(127583620331192027)
,p_prompt=>'Objeto de Costo 04'
,p_display_as=>'NATIVE_SINGLE_CHECKBOX'
,p_grid_label_column_span=>0
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--xlarge:t-Form-fieldContainer--radioButtonGroup'
,p_attribute_01=>'N'
,p_attribute_02=>'S'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(127585708919192048)
,p_name=>'P448_ITEMSCHAGE'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(127437502784147913)
,p_prompt=>'Itemschage'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(127582026816192011)
,p_validation_name=>'Validaciones Json'
,p_validation_sequence=>10
,p_validation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare ',
'  -- 1) Tipos y variables primero',
'  type t_item is record (name varchar2(30), val varchar2(4000));',
'  type t_tab  is table of t_item index by pls_integer;',
'  type t_seen is table of pls_integer index by varchar2(4000);',
'  l_items t_tab;',
'  l_seen  t_seen;',
'  v_key   varchar2(4000);',
'  v_dup1  pls_integer;',
'',
unistr('  -- 2) Subprograma local despu\00E9s de tipos/variables'),
'  function norm(p_txt varchar2) return varchar2 is',
'  begin',
'    if p_txt is null then return null; end if;',
unistr('    -- usa clase POSIX para espacios (m\00E1s portable en Oracle):'),
'    return upper(regexp_replace(trim(p_txt), ''[[:space:]]+'', '' ''));',
'  end;',
'begin',
'  -- 3) Cargar pares (nombre, valor normalizado)',
'  l_items(1).name := '' Objeto de Costo 01''; l_items(1).val := norm(:P448_ABT1);',
'  l_items(2).name := '' Objeto de Costo 02''; l_items(2).val := norm(:P448_ABT2);',
'  l_items(3).name := '' Objeto de Costo 03''; l_items(3).val := norm(:P448_ABT3);',
'  l_items(4).name := '' Objeto de Costo 04''; l_items(4).val := norm(:P448_ABT4);',
'  l_items(5).name := '' Objeto de Costo 05''; l_items(5).val := norm(:P448_ABT5);',
'  l_items(6).name := '' Objeto de Costo 06''; l_items(6).val := norm(:P448_ABT6);',
'  l_items(7).name := '' Objeto de Costo 07''; l_items(7).val := norm(:P448_ABT7);',
'  l_items(8).name := '' Objeto de Costo 08''; l_items(8).val := norm(:P448_ABT8);',
'',
unistr('  -- 4) Revisar duplicados ignorando NULL/vac\00EDos'),
'  for idx in 1..8 loop',
'--    DBMS_OUTPUT.PUT_LINE(''idx:''||idx);',
'    v_key := to_char(l_items(idx).val);',
'    if trim(v_key) is not null  then',
'      if l_seen.exists(v_key) then',
'        v_dup1 := l_seen(v_key);',
unistr('       return (''Valor duplicado "''||v_key||''" en ''|| l_items(v_dup1).name||'' y ''||l_items(idx).name||''. Cada Objeto de Costo debe ser \00FAnico.'');'),
'      else',
'        l_seen(v_key) := idx;',
'      end if;',
'    end if;',
'  end loop;',
'  return null; -- OK',
'end f_validaDimensiones;'))
,p_validation2=>'PLSQL'
,p_validation_type=>'FUNC_BODY_RETURNING_ERR_TEXT'
,p_validation_condition=>'submit_grabar'
,p_validation_condition_type=>'REQUEST_EQUALS_CONDITION'
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(127581530848192006)
,p_name=>'botonAnt'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(127581311784192004)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(127581622232192007)
,p_event_id=>wwv_flow_imp.id(127581530848192006)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'(function(){',
'  var idx = Number($v(''P448_IDX'')||1);',
'  if (idx > 1) {',
'    $s(''P448_IDX'', String(idx-1)); ',
'    apex.page.submit({request:''NAV'',showWait:true});',
'  } else {',
unistr('    apex.message.showPageSuccess(''Ya est\00E1s en el primero.'');'),
'  }',
'})();',
''))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(127581801070192009)
,p_name=>'botonSig'
,p_event_sequence=>20
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(127581458221192005)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(127581979549192010)
,p_event_id=>wwv_flow_imp.id(127581801070192009)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'(function(){',
'  var idx = Number($v(''P448_IDX'')||1);',
'  $s(''P448_IDX'', String(idx+1));',
'  apex.page.submit({request:''NAV'',showWait:true});',
'})();',
''))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(127582388854192014)
,p_name=>'Cambio Objeto Costo'
,p_event_sequence=>30
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P448_ABT1,P448_ABT2,P448_ABT3,P448_ABT4,P448_ABT5,P448_ABT6,P448_ABT7,P448_ABT8'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(127582453156192015)
,p_event_id=>wwv_flow_imp.id(127582388854192014)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'(function(){ ',
'  const ids = [',
'    ''P448_ABT1'',''P448_ABT2'',''P448_ABT3'',''P448_ABT4'',',
'    ''P448_ABT5'',''P448_ABT6'',''P448_ABT7'',''P448_ABT8''',
'  ];',
'',
'  const norm = s => (s||'''').trim().replace(/\s+/g,'' '').toUpperCase();',
'',
unistr('  // Funci\00F3n auxiliar: obtiene el texto de la etiqueta (label) asociada al item'),
'  function getLabel(id){',
'    const labelEl = document.querySelector(`label[for="${id}"]`);',
'    if (labelEl) return labelEl.textContent.trim();',
'    // si no hay etiqueta visible, usar nombre del item',
'    return id;',
'  }',
'',
'  const seen = {};',
'  for (const id of ids) {',
'    const v = norm($v(id));',
'    const label = getLabel(id);',
'    if (v) {',
'      if (seen[v]) {',
'        apex.message.clearErrors();',
'        apex.message.showErrors([{',
'          type:       "error",',
'          location:   ["inline","page"],',
'          pageItem:   id,',
'          message:    `Valor duplicado "${v}" ya usado en "${seen[v]}".`,',
'          unsafe:     false',
'        }]);',
'        return;',
'      }',
'      seen[v] = label;',
'    }',
'  }',
'  apex.message.clearErrors();',
'})();',
''))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(127584665906192037)
,p_name=>'pageload'
,p_event_sequence=>40
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'ready'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(127584715016192038)
,p_event_id=>wwv_flow_imp.id(127584665906192037)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'(function(){',
'  const pairs = [',
'    [''P448_CHK1'',''P448_ABT1''],',
'    [''P448_CHK2'',''P448_ABT2''],',
'    [''P448_CHK3'',''P448_ABT3''],',
'    [''P448_CHK4'',''P448_ABT4''],',
'    [''P448_CHK5'',''P448_ABT5''],',
'    [''P448_CHK6'',''P448_ABT6''],',
'    [''P448_CHK7'',''P448_ABT7''],',
'    [''P448_CHK8'',''P448_ABT8''],',
'  ];',
'  function applyPair(chk, txt){',
'    const on  = ($v(chk) === ''S'');',
'    const $el = $(''#''+txt+'', select[name="''+txt+''"]'');',
'    // Para selects, usar disabled',
'    $el.prop(''disabled'', !on);',
'    $el.closest(''.t-Form-fieldContainer'').toggleClass(''is-disabled'', !on);',
unistr('    // marca para \201Cre-habilitar\201D antes del submit'),
'    $el.attr(''data-disabled-by-check'', (!on ? ''1'':''''));',
'  }',
'  pairs.forEach(([c,t])=>applyPair(c,t));',
'})();',
'',
''))
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(127585486489192045)
,p_event_id=>wwv_flow_imp.id(127584665906192037)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'(function(){',
'  window._chgP448 = new Set();',
'  var v_chgP448="";',
'  $(document).on("change input", ''input[id^="P448_"], select[id^="P448_"], textarea[id^="P448_"]'', function(){',
'    if (this.id) { ',
'        window._chgP448.add(this.id);',
'    }',
'  });',
'})();',
''))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(127584882422192039)
,p_name=>'Cambio Check OCXX'
,p_event_sequence=>50
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P448_CHK1,P448_CHK2,P448_CHK3,P448_CHK4,P448_CHK5,P448_CHK6,P448_CHK7,P448_CHK8'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(127584963285192040)
,p_event_id=>wwv_flow_imp.id(127584882422192039)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'(function(trigId){',
'  var baseId = (trigId || "").replace(/_\d+$/,'''');',
'  ',
'  var map = {',
'    P448_CHK1:''P448_ABT1'',',
'    P448_CHK2:''P448_ABT2'',',
'    P448_CHK3:''P448_ABT3'',',
'    P448_CHK4:''P448_ABT4'',',
'    P448_CHK5:''P448_ABT5'',',
'    P448_CHK6:''P448_ABT6'',',
'    P448_CHK7:''P448_ABT7'',',
'    P448_CHK8:''P448_ABT8''',
'  };',
'  var txt = map[baseId];',
'  if (!txt) return;',
'  var on = ($v(baseId) === ''S'');',
'  ',
'  var $el = $(''#''+txt+'', select[name="''+txt+''"]'');',
'  $el.prop(''disabled'', !on);',
'  $el.closest(''.t-Form-fieldContainer'').toggleClass(''is-disabled'', !on);',
'  $el.attr(''data-disabled-by-check'', (!on ? ''1'' : ''''));',
'  if (on) { try { apex.item(txt).setFocus(); } catch(e) {console.log(e)} }',
'})(this.triggeringElement.id);'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(127585013546192041)
,p_name=>'before_page_submit'
,p_event_sequence=>60
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexbeforepagesubmit'
,p_display_when_type=>'NEVER'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(127585134055192042)
,p_event_id=>wwv_flow_imp.id(127585013546192041)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'(function(){',
'  $(''select[data-disabled-by-check="1"]'').each(function(){',
'    // habilita para que el submit incluya el valor actual',
'    $(this).prop(''disabled'', false);',
'  });',
'})();',
''))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(127585814043192049)
,p_name=>'ATRAS'
,p_event_sequence=>70
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(127585247915192043)
,p_triggering_condition_type=>'JAVASCRIPT_EXPRESSION'
,p_triggering_expression=>'apex.page.isChanged()'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(127585568109192046)
,p_event_id=>wwv_flow_imp.id(127585814043192049)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_name=>'detecta cambios  P448_EN_'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'(function(){',
'  if (!apex.page.isChanged()) return;',
'',
unistr('  // toma hasta 5 \00EDtems cambiados y convierte a label legible'),
'  const ids = Array.from(window._chgP448 || []);',
'  function getLabel(id){',
'    const el = document.querySelector(''label[for="''+id+''"]'');',
'    return el ? el.textContent.trim() : id;',
'  }',
unistr('  const lista = ids.slice(0,5).map(getLabel).join('', '') || ''la p\00E1gina'';'),
'',
'  apex.message.clearErrors();',
'  apex.message.showErrors([{',
'    type: "error",',
'    location: ["page"],',
'    message: "Hay cambios sin guardar en: " + lista + ".",',
'    unsafe: false',
'  }]);',
'',
'  window._blockSubmit = true;',
'})();',
''))
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(128913796365329301)
,p_event_id=>wwv_flow_imp.id(127585814043192049)
,p_event_result=>'FALSE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_01=>'SENDTOLEAVE'
,p_attribute_02=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(127585662738192047)
,p_event_id=>wwv_flow_imp.id(127585814043192049)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_CANCEL_EVENT'
,p_client_condition_type=>'JAVASCRIPT_EXPRESSION'
,p_client_condition_expression=>'window._blockSubmit === true'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(129166291892853425)
,p_name=>'New'
,p_event_sequence=>80
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(127439357501147931)
,p_triggering_condition_type=>'JAVASCRIPT_EXPRESSION'
,p_triggering_expression=>'apex.page.isChanged()'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(129166313719853426)
,p_event_id=>wwv_flow_imp.id(129166291892853425)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_CONFIRM'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
unistr('<span style="text-align: justify;width: 157px;">La modificaci\00F3n del tipo de objeto de costo actualizar\00E1 y reemplazar\00E1 los criterios de distribuci\00F3n existentes.</span>'),
unistr('<br /><br />Si contin\00FAa, se eliminar\00E1n definitivamente los datos anteriores.'),
unistr('<br /><br /><br />\00BFDesea proceder?')))
,p_attribute_03=>'warning'
,p_attribute_04=>'fa-warning'
,p_attribute_06=>unistr('S\00CD')
,p_attribute_07=>'NO'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(129166645961853429)
,p_event_id=>wwv_flow_imp.id(129166291892853425)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>'UPDATE  data.t_finz_distribucionmtd SET criterio= NULL WHERE ID=:G_VALORMTD;'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(129166451553853427)
,p_event_id=>wwv_flow_imp.id(129166291892853425)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_01=>'submit_grabar'
,p_attribute_02=>'Y'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(127581216748192003)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'guardar_json_array'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    v_new_obj  clob;',
'    v_json_in  clob := :G_DIMENSIONDIST;',
'    v_is_array number;',
'    v_cnt      number;',
'    v_pos      number;',
'    v_out      clob;',
'    v_tieneerror number;',
'begin',
'    v_tieneerror:=0;',
'    if ((:P448_CHK1 is not null and :P448_ABT1 is null))then apex_error.add_error (p_message=> ''Seleccione un valor para el objeto de costo 01.'',p_display_location =>apex_error.c_inline_in_notification,p_page_item_name   => ''P448_ABT1''); v_tieneerror'
||':=1; end if;',
'    if ((:P448_CHK2 is not null and :P448_ABT2 is null))then apex_error.add_error (p_message=> ''Seleccione un valor para el objeto de costo 02.'',p_display_location =>apex_error.c_inline_in_notification,p_page_item_name   => ''P448_ABT2''); v_tieneerror'
||':=1; end if;',
'    if ((:P448_CHK3 is not null and :P448_ABT3 is null))then apex_error.add_error (p_message=> ''Seleccione un valor para el objeto de costo 03.'',p_display_location =>apex_error.c_inline_in_notification,p_page_item_name   => ''P448_ABT3''); v_tieneerror'
||':=1; end if;',
'    if ((:P448_CHK4 is not null and :P448_ABT4 is null))then apex_error.add_error (p_message=> ''Seleccione un valor para el objeto de costo 04.'',p_display_location =>apex_error.c_inline_in_notification,p_page_item_name   => ''P448_ABT4''); v_tieneerror'
||':=1; end if;',
'    if ((:P448_CHK5 is not null and :P448_ABT5 is null))then apex_error.add_error (p_message=> ''Seleccione un valor para el objeto de costo 05.'',p_display_location =>apex_error.c_inline_in_notification,p_page_item_name   => ''P448_ABT5''); v_tieneerror'
||':=1; end if;',
'    if ((:P448_CHK6 is not null and :P448_ABT6 is null))then apex_error.add_error (p_message=> ''Seleccione un valor para el objeto de costo 06.'',p_display_location =>apex_error.c_inline_in_notification,p_page_item_name   => ''P448_ABT6''); v_tieneerror'
||':=1; end if;',
'    if ((:P448_CHK7 is not null and :P448_ABT7 is null))then apex_error.add_error (p_message=> ''Seleccione un valor para el objeto de costo 07.'',p_display_location =>apex_error.c_inline_in_notification,p_page_item_name   => ''P448_ABT7''); v_tieneerror'
||':=1; end if;',
'    if ((:P448_CHK8 is not null and :P448_ABT8 is null))then apex_error.add_error (p_message=> ''Seleccione un valor para el objeto de costo 08.'',p_display_location =>apex_error.c_inline_in_notification,p_page_item_name   => ''P448_ABT8''); v_tieneerror'
||':=1; end if;',
'    if (v_tieneerror=1)then ',
'        return;',
'    end if;',
'    select json_object(''ID''         value nvl(:P448_ID,1),',
'        ''ABT1'' value case when :P448_CHK1=''S'' then :P448_ABT1 else null end,''ABT2'' value case when :P448_CHK2=''S'' then :P448_ABT2 else null end,',
'        ''ABT3'' value case when :P448_CHK3=''S'' then :P448_ABT3 else null end,''ABT4'' value case when :P448_CHK4=''S'' then :P448_ABT4 else null end,',
'        ''ABT5'' value case when :P448_CHK5=''S'' then :P448_ABT5 else null end,''ABT6'' value case when :P448_CHK6=''S'' then :P448_ABT6 else null end,',
'        ''ABT7'' value case when :P448_CHK7=''S'' then :P448_ABT7 else null end,''ABT8'' value case when :P448_CHK8=''S'' then :P448_ABT8 else null end,',
'        ''CHK1'' value case when :P448_CHK1=''S'' then 1 else 0 end,''CHK2'' value case when :P448_CHK2=''S'' then 2 else 0 end,',
'        ''CHK3'' value case when :P448_CHK3=''S'' then 3 else 0 end,''CHK4'' value case when :P448_CHK4=''S'' then 4 else 0 end,',
'        ''CHK5'' value case when :P448_CHK5=''S'' then 5 else 0 end,''CHK6'' value case when :P448_CHK6=''S'' then 6 else 0 end,',
'        ''CHK7'' value case when :P448_CHK7=''S'' then 7 else 0 end,''CHK8'' value case when :P448_CHK8=''S'' then 7 else 0 end',
'        returning clob',
'    )',
'    into v_new_obj',
'    from dual;',
'',
'    if v_json_in is null or dbms_lob.getlength(v_json_in)=0 then',
'        :G_DIMENSIONDIST := v_new_obj;',
'    else',
'        select case when json_query(v_json_in, ''$[*]'' returning varchar2(1)) is not null then 1 else 0 end into v_is_array from dual;',
'        if v_is_array = 1 then',
'            select count(*) into v_cnt from json_table(v_json_in, ''$[*]'' columns (x path ''$''));',
'            v_pos := greatest(1, least(nvl(:P448_IDX,1), v_cnt));',
'            select json_arrayagg( case when rn = v_pos then json(v_new_obj) else value end returning clob )',
'            into v_out',
'            from ( select rownum rn, value from json_table( v_json_in,''$[*]''columns ( value json path ''$'' ) ) );',
'            :G_DIMENSIONDIST := v_out;',
'        else',
'            :G_DIMENSIONDIST := v_new_obj;',
'        end if;',
'    end if;',
'    UPDATE  data.t_finz_distribucionmtd SET dimensiones= :G_DIMENSIONDIST WHERE ID=:G_VALORMTD;',
'    :G_CRITERIOSDIST:=NULL;',
'end;',
''))
,p_process_clob_language=>'PLSQL'
,p_process_error_message=>unistr('Ocurri\00F3 un error al procesar la informaci\00F3n.')
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>'submit_grabar'
,p_process_when_type=>'REQUEST_EQUALS_CONDITION'
,p_process_success_message=>'Los datos se han actualizado correctamente.'
,p_internal_uid=>127581216748192003
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(127440496288147942)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'guardar_json_sinple_row'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    v_json clob;',
'begin',
'    select json_object(',
'        ''ID'' value :P448_ID,',
'        ''abt1'' value :P448_ABT1,',
'        ''abt2'' value :P448_ABT2,',
'        ''abt3'' value :P448_ABT3,',
'        ''abt4'' value :P448_ABT4,',
'        ''abt5'' value :P448_ABT5,',
'        ''abt6'' value :P448_ABT6,',
'        ''abt7'' value :P448_ABT7,',
'        ''abt8'' value :P448_ABT8',
'        returning clob',
'    )',
'    into v_json',
'    from dual;',
'',
'    :G_DIMENSIONDIST := v_json;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(127439357501147931)
,p_process_when_type=>'NEVER'
,p_internal_uid=>127440496288147942
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(127440343404147941)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'SetupPage_array'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'  v_is_array   number;',
'  v_cnt        number;',
'  v_pos        number;',
'  v_json_any   clob := :G_DIMENSIONDIST;',
'',
'  -- destino',
'  v_id         varchar2(3999);',
'  v_oc01       varchar2(399); v_oc02 varchar2(399); v_oc03 varchar2(399); v_oc04 varchar2(399);',
'  v_oc05       varchar2(399); v_oc06 varchar2(399); v_oc07 varchar2(399); v_oc08 varchar2(399);',
'begin',
'  if v_json_any is null or dbms_lob.getlength(v_json_any)=0 then',
'    -- limpia items',
'    :P448_ID:=null; :P448_ABT1:=null; :P448_ABT2:=null; :P448_ABT3:=null; :P448_ABT4:=null;',
'    :P448_ABT5:=null; :P448_ABT6:=null; :P448_ABT7:=null; :P448_ABT8:=null;',
'    return;',
'  end if;',
'',
unistr('  -- \00BFes arreglo?'),
'  select case when json_query(v_json_any, ''$[*]'' returning varchar2(1)) is not null then 1 else 0 end',
'  into v_is_array',
'  from dual;',
'',
'  if v_is_array = 1 then',
'    -- cuenta elementos',
'    select count(*)',
'      into v_cnt',
'      from json_table(v_json_any, ''$[*]'' columns (x path ''$''));',
'',
unistr('    v_pos := greatest(1, least(nvl(:P448_IDX,1), v_cnt)); -- clamp \00EDndice'),
'',
unistr('    -- extrae por posici\00F3n'),
'    select ID, ABT1,ABT2,ABT3,ABT4,ABT5,ABT6,ABT7,ABT8',
'      into v_id, v_oc01,v_oc02,v_oc03,v_oc04,v_oc05,v_oc06,v_oc07,v_oc08',
'    from (',
'      select rownum rn,',
'             jt.ID, jt.ABT1, jt.ABT2, jt.ABT3, jt.ABT4,',
'             jt.ABT5, jt.ABT6, jt.ABT7, jt.ABT8',
'      from json_table(',
'             v_json_any, ''$[*]''',
'             columns (',
'               ID           varchar2(3999) path ''$.ID'',',
'               ABT1   varchar2(399)  path ''$.ABT1'',',
'               ABT2   varchar2(399)  path ''$.ABT2'',',
'               ABT3   varchar2(399)  path ''$.ABT3'',',
'               ABT4   varchar2(399)  path ''$.ABT4'',',
'               ABT5   varchar2(399)  path ''$.ABT5'',',
'               ABT6   varchar2(399)  path ''$.ABT6'',',
'               ABT7   varchar2(399)  path ''$.ABT7'',',
'               ABT8   varchar2(399)  path ''$.ABT8''',
'             )',
'           ) jt',
'    ) t',
'    where t.rn = v_pos;',
'',
'    :P448_IDX := v_pos; -- normaliza',
'  else',
'    -- objeto plano',
'    select ID, ABT1,ABT2,ABT3,ABT4,ABT5,ABT6,ABT7,ABT8',
'      into v_id, v_oc01,v_oc02,v_oc03,v_oc04,v_oc05,v_oc06,v_oc07,v_oc08',
'    from json_table(',
'           v_json_any, ''$''',
'           columns (',
'             ID           varchar2(3999) path ''$.ID'',',
'             ABT1   varchar2(399)  path ''$.ABT1'',',
'             ABT2   varchar2(399)  path ''$.ABT2'',',
'             ABT3   varchar2(399)  path ''$.ABT3'',',
'             ABT4   varchar2(399)  path ''$.ABT4'',',
'             ABT5   varchar2(399)  path ''$.ABT5'',',
'             ABT6   varchar2(399)  path ''$.ABT6'',',
'             ABT7   varchar2(399)  path ''$.ABT7'',',
'             ABT8   varchar2(399)  path ''$.ABT8''',
'           )',
'         );',
'',
'    :P448_IDX := 1;',
'  end if;',
'',
'  -- asigna items',
'  :P448_ID := v_id;',
'  :P448_ABT1 := v_oc01; :P448_ABT2 := v_oc02; :P448_ABT3 := v_oc03; :P448_ABT4 := v_oc04;',
'  :P448_ABT5 := v_oc05; :P448_ABT6 := v_oc06; :P448_ABT7 := v_oc07; :P448_ABT8 := v_oc08;',
'exception',
'  when no_data_found then',
'    :P448_ID:=null; :P448_ABT1:=null; :P448_ABT2:=null; :P448_ABT3:=null; :P448_ABT4:=null;',
'    :P448_ABT5:=null; :P448_ABT6:=null; :P448_ABT7:=null; :P448_ABT8:=null;',
'end;',
''))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>127440343404147941
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(127581150280192002)
,p_process_sequence=>20
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'SetupPage_singlerow'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    v_id varchar2(3999);',
'    v_oc01 varchar2(399);',
'    v_oc02 varchar2(399);',
'    v_oc03 varchar2(399);',
'    v_oc04 varchar2(399);',
'    v_oc05 varchar2(399);',
'    v_oc06 varchar2(399);',
'    v_oc07 varchar2(399);',
'    v_oc08 varchar2(399);',
'begin',
'    select ID, ABT1, ABT2, ABT3, ABT4,ABT5, ABT6, ABT7, ABT8 ',
'    into v_id, v_oc01, v_oc02, v_oc03, v_oc04, v_oc05, v_oc06, v_oc07, v_oc08',
'    from json_table(',
'        :G_DIMENSIONDIST,',
'        ''$[*]'' columns (',
'            ID varchar2(3999) path ''$.ID'',',
'            ABT1 varchar2(399) path ''$.ABT1'',',
'            ABT2 varchar2(399) path ''$.ABT2'',',
'            ABT3 varchar2(399) path ''$.ABT3'',',
'            ABT4 varchar2(399) path ''$.ABT4'',',
'            ABT5 varchar2(399) path ''$.ABT5'',',
'            ABT6 varchar2(399) path ''$.ABT6'',',
'            ABT7 varchar2(399) path ''$.ABT7'',',
'            ABT8 varchar2(399) path ''$.ABT8''',
'        )',
'    )',
'    fetch first 1 row only;',
'',
'    :P448_ID := v_id;',
'    :P448_ABT1 := v_oc01;',
'    :P448_ABT2 := v_oc02;',
'    :P448_ABT3 := v_oc03;',
'    :P448_ABT4 := v_oc04;',
'    :P448_ABT5 := v_oc05;',
'    :P448_ABT6 := v_oc06;',
'    :P448_ABT7 := v_oc07;',
'    :P448_ABT8 := v_oc08;',
'    exception when no_data_found then',
unistr('    null; -- si el JSON viene vac\00EDo, deje los items en blanco'),
'end;'))
,p_process_clob_language=>'PLSQL'
,p_process_when_type=>'NEVER'
,p_internal_uid=>127581150280192002
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(127584517751192036)
,p_process_sequence=>30
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Setup Interface'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
':P448_CHK1 := case when :P448_ABT1 is not null then ''S'' end;',
':P448_CHK2 := case when :P448_ABT2 is not null then ''S'' end;',
':P448_CHK3 := case when :P448_ABT3 is not null then ''S'' end;',
':P448_CHK4 := case when :P448_ABT4 is not null then ''S'' end;',
':P448_CHK5 := case when :P448_ABT5 is not null then ''S'' end;',
':P448_CHK6 := case when :P448_ABT6 is not null then ''S'' end;',
':P448_CHK7 := case when :P448_ABT7 is not null then ''S'' end;',
':P448_CHK8 := case when :P448_ABT8 is not null then ''S'' end;',
''))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>127584517751192036
);
wwv_flow_imp.component_end;
end;
/
