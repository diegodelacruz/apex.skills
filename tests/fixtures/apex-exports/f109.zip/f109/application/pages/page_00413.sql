prompt --application/pages/page_00413
begin
--   Manifest
--     PAGE: 00413
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>109
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_page.create_page(
 p_id=>413
,p_name=>'DOCUMENTOS ELECTRONICOS - PAG - FUERA DE LINEA'
,p_alias=>'DOCUMENTOS-ELECTRONICOS-PAG-FUERA-DE-LINEA'
,p_step_title=>'DOCUMENTOS ELECTRONICOS - PAG - FUERA DE LINEA'
,p_autocomplete_on_off=>'OFF'
,p_javascript_code_onload=>'$(secItems).hide();'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.apex-item-file {',
'    opacity: 1 !important;',
'    border: 1px solid #ccced1;',
'}'))
,p_page_template_options=>'#DEFAULT#'
,p_page_component_map=>'18'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(99965487222702836)
,p_plug_name=>'Cabecera'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(38289867500120143)
,p_plug_display_sequence=>10
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(99965998270702841)
,p_plug_name=>'Items'
,p_region_name=>'secItems'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(38289867500120143)
,p_plug_display_sequence=>30
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(114466911408667039)
,p_plug_name=>'DETALLE'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(37806762584106520)
,p_plug_display_sequence=>20
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ',
'        id, tipodocumentoerp orden,numerodocumentoerp num_orden,null bodega,null usuario_orden,',
'        case when aprobado=1 then ''APROBADO'' when aprobado=0 THEN ''SIN APROBAR'' else ''PROCESANDO'' END estado,',
'        codigoan8 codigo,codigoan8 cliente_proveedor,',
'        numerodocumento numero_documento,case TIPODOCUMENTO ',
unistr(' when ''D1'' then ''Nota de Cr\00E9dito'' '),
unistr(' when ''FE'' then ''Factura de Exportaci\00F3n'' '),
' when ''FN'' then ''Facturas Nacionales'' ',
unistr(' when ''GE'' then ''Guia de Remisi\00F3n Exportaci\00F3n'' '),
unistr(' when ''GN'' then ''Guia de Remisi\00F3n Nacional'' '),
' when ''PJ'' then ''Reembolso'' ',
' when ''PQ'' then ''Liqui. de Servicios y Bienes'' ',
unistr(' when ''UR'' then ''Comprobante de Retenci\00F3n'' '),
'end tipo_documento,null fecha_orden, claveacceso,',
'        decode(claveacceso, null,null,to_date(substr(claveacceso, 1, 2)|| ''/''|| substr(claveacceso, 3, 2)|| ''/''|| substr(claveacceso, 5, 4))) fecha_factura,',
'        case ',
'            when aprobado = 0 and autorizado = 0                                  then ''<span style="color:red"   title="Sin Aprobar"       class="fa fa-thumbs-down"></span>''',
'            when aprobado = 1 and autorizado = 0 and errordescripcion is null     then ''<span style="color:transparent" title="Aprobado"          class="fa fa-thumbs-up"></span>''',
unistr('            when aprobado = 1 and autorizado = 0 and errordescripcion is not null then ''<span style="color:red"   title="Sin Autorizaci\00F3n"  class="fa fa-times-circle"></span>'''),
'            when aprobado = 1 and autorizado = 1                                  then ''<span style="color:green" title="Autorizado"        class="fa fa-check-circle"></span>''',
'        end  estado_autorizacion, ',
'        null batch, null ride, null retencion, usercrea usuario_factura, ',
unistr('        case when errordescripcion is null then '''' else ''<span aria-hidden="true" title="Descripci\00F3n Errores" class="fa fa-alert">'' end descripcion_error,'),
'        case ',
'            when aprobado = 1 then ''<span class="fa fa-cloud-download" title="Descargar Documentos" aria-hidden="true"></span>''',
'            else ''''',
'        end  descargar, ',
'        case ',
'            when aprobado = 1 and autorizado = 0  /*and  errordescripcion is null*/  then ',
'                ''<a href="javascript: $s(''''P413_ID'''','''''''');$s(''''P413_ID'''',''''''||ID||'''''');$s(''''P413_ACCION'''','''''''');$s(''''P413_ACCION'''',''''ENVIAR'''');"><span aria-hidden="true" title="Enviar SRI" style="font-size: small;" class="fa fa-file-signature">SRI</'
||'span>''',
'            else ''''',
'        end  enviar,',
'        case ',
'            when  autorizado = 0 /*and  errordescripcion is null       */then ',
'            ''<a href="javascript: $s(''''P413_ID'''','''''''');$s(''''P413_ID'''',''''''||ID||'''''');$s(''''P413_ACCION'''','''''''');$s(''''P413_ACCION'''',''''APROBAR'''');"><span aria-hidden="true" title="Reprocesar XML Zaimella" class="fa fa-gears"></span></a>''',
'            else ''''',
'        end  aprobar,',
'        case ',
'            when  autorizado = 0 /*and  errordescripcion is null       */then ',
'            ''<a href="javascript: $s(''''P413_ID'''','''''''');$s(''''P413_ID'''',''''''||ID||'''''');$s(''''P413_ACCION'''','''''''');$s(''''P413_ACCION'''',''''BORRAR'''');"><span aria-hidden="true" title="Eliminar" class="fa fa-trash"></span></a>''',
'            else ''''',
'        end  eliminar         ',
'    from  t_finz_documento_electronico where ESTADO=3 AND (TIPODOCUMENTO= :P413_TIPO_DOCUMENTO OR :P413_TIPO_DOCUMENTO IS NULL);',
'    '))
,p_plug_source_type=>'NATIVE_IR'
,p_ajax_items_to_submit=>'P413_TIPO_DOCUMENTO'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(114467043619667040)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'EMASABANDA'
,p_internal_uid=>114467043619667040
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(114467186965667041)
,p_db_column_name=>'ID'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Id'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(114467293185667042)
,p_db_column_name=>'ORDEN'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Orden'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(114467399580667043)
,p_db_column_name=>'NUM_ORDEN'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Num Orden'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(114467467951667044)
,p_db_column_name=>'BODEGA'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Bodega'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(114467530511667045)
,p_db_column_name=>'CLAVEACCESO'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Claveacceso'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(114467660323667046)
,p_db_column_name=>'ESTADO'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'Estado'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(114467776006667047)
,p_db_column_name=>'CLIENTE_PROVEEDOR'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>'Cliente Proveedor'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(114467820703667048)
,p_db_column_name=>'NUMERO_DOCUMENTO'
,p_display_order=>80
,p_column_identifier=>'H'
,p_column_label=>'Numero Documento'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(114467955811667049)
,p_db_column_name=>'TIPO_DOCUMENTO'
,p_display_order=>90
,p_column_identifier=>'I'
,p_column_label=>'Tipo Documento'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(114468046708667050)
,p_db_column_name=>'FECHA_ORDEN'
,p_display_order=>100
,p_column_identifier=>'J'
,p_column_label=>'Fecha Orden'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(114514718426768701)
,p_db_column_name=>'FECHA_FACTURA'
,p_display_order=>110
,p_column_identifier=>'K'
,p_column_label=>'Fecha Factura'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(114514841253768702)
,p_db_column_name=>'ESTADO_AUTORIZACION'
,p_display_order=>120
,p_column_identifier=>'L'
,p_column_label=>'Estado Autorizacion'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(114514962165768703)
,p_db_column_name=>'BATCH'
,p_display_order=>130
,p_column_identifier=>'M'
,p_column_label=>'Batch'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(114515078640768704)
,p_db_column_name=>'RETENCION'
,p_display_order=>140
,p_column_identifier=>'N'
,p_column_label=>'Retencion'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(114515145238768705)
,p_db_column_name=>'USUARIO_FACTURA'
,p_display_order=>150
,p_column_identifier=>'O'
,p_column_label=>'Usuario Factura'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(114515278004768706)
,p_db_column_name=>'DESCRIPCION_ERROR'
,p_display_order=>160
,p_column_identifier=>'P'
,p_column_label=>'Descripcion Error'
,p_column_link=>'f?p=&APP_ID.:406:&SESSION.::&DEBUG.:406:P406_ID:#ID#'
,p_column_linktext=>'#DESCRIPCION_ERROR#'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(114515303303768707)
,p_db_column_name=>'DESCARGAR'
,p_display_order=>170
,p_column_identifier=>'Q'
,p_column_label=>'Descargar'
,p_column_link=>'f?p=&APP_ID.:407:&SESSION.::&DEBUG.:RR,407:P407_TABLA,P407_ID,P407_ESTADO:T_FINZ_DOCUMENTO_ELECTRONICO,#ID#,1'
,p_column_linktext=>'#DESCARGAR#'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(114515490581768708)
,p_db_column_name=>'ENVIAR'
,p_display_order=>180
,p_column_identifier=>'R'
,p_column_label=>'Enviar'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(114515548456768709)
,p_db_column_name=>'APROBAR'
,p_display_order=>190
,p_column_identifier=>'S'
,p_column_label=>'Aprobar'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(114515712340768711)
,p_db_column_name=>'USUARIO_ORDEN'
,p_display_order=>200
,p_column_identifier=>'U'
,p_column_label=>'Usuario Orden'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(114515862254768712)
,p_db_column_name=>'CODIGO'
,p_display_order=>210
,p_column_identifier=>'V'
,p_column_label=>'Codigo'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(114515951152768713)
,p_db_column_name=>'RIDE'
,p_display_order=>220
,p_column_identifier=>'W'
,p_column_label=>'Ride'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(114516265155768716)
,p_db_column_name=>'ELIMINAR'
,p_display_order=>230
,p_column_identifier=>'X'
,p_column_label=>'Eliminar'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(114526855724769027)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'1145269'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'ID:NUMERO_DOCUMENTO:TIPO_DOCUMENTO:CLAVEACCESO:ESTADO:FECHA_FACTURA:ESTADO_AUTORIZACION:USUARIO_FACTURA:DESCRIPCION_ERROR:DESCARGAR:ENVIAR:ELIMINAR:'
,p_sort_column_1=>'ID'
,p_sort_direction_1=>'DESC'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(99965505315702837)
,p_name=>'P413_TIPO_DOCUMENTO'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(99965487222702836)
,p_prompt=>'Tipo Documento'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT distinct ',
'case TIPODOCUMENTO ',
unistr(' when ''D1'' then ''Nota de Cr\00E9dito'' '),
unistr(' when ''FE'' then ''Factura de Exportaci\00F3n'' '),
' when ''FN'' then ''Facturas Nacionales'' ',
unistr(' when ''GE'' then ''Guia de Remisi\00F3n Exportaci\00F3n'' '),
unistr(' when ''GN'' then ''Guia de Remisi\00F3n Nacional'' '),
' when ''PJ'' then ''Reembolso'' ',
' when ''PQ'' then ''Liqui. de Servicios y Bienes'' ',
unistr(' when ''UR'' then ''Comprobante de Retenci\00F3n'' '),
'end  d, TIPODOCUMENTO r FROM ',
'DATA.t_finz_documento_electronico',
'--where TIPODOCUMENTO NOT in (''PJ'',''PQ'')',
'ORDER BY 1;'))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_grid_label_column_span=>1
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(99965603530702838)
,p_name=>'P413_ARCHIVO'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(99965487222702836)
,p_prompt=>'Archivo (XML)'
,p_display_as=>'NATIVE_FILE'
,p_cSize=>120
,p_begin_on_new_line=>'N'
,p_grid_label_column_span=>1
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'APEX_APPLICATION_TEMP_FILES'
,p_attribute_09=>'REQUEST'
,p_attribute_10=>'N'
,p_attribute_11=>'.xml'
,p_attribute_12=>'NATIVE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(99966609586702848)
,p_name=>'P413_BORRAR'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(99965998270702841)
,p_prompt=>'Borrar'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>30
,p_cHeight=>5
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(114533138233802871)
,p_name=>'P413_ID'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(99965998270702841)
,p_prompt=>'Id'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(114533461273804592)
,p_name=>'P413_ACCION'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(99965998270702841)
,p_prompt=>'Accion'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(99965714299702839)
,p_name=>'CAMBIAR ARCHIVO'
,p_event_sequence=>10
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P413_ARCHIVO'
,p_condition_element=>'P413_ARCHIVO'
,p_triggering_condition_type=>'NOT_NULL'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(99966306782702845)
,p_event_id=>wwv_flow_imp.id(99965714299702839)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'if($v("P413_TIPO_DOCUMENTO")===""){',
'    mensajeError("Debe seleccionar un tipo de documento a ser cargado.");',
'    $s("P413_ARCHIVO","");',
'    return false;',
'}else{',
'return true;',
'}'))
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(114516392532768717)
,p_event_id=>wwv_flow_imp.id(99965714299702839)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_02=>'Y'
,p_client_condition_type=>'NULL'
,p_client_condition_element=>'P413_ARCHIVO'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(99965882644702840)
,p_event_id=>wwv_flow_imp.id(99965714299702839)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_name=>'SUBMIT_CAMBIAR ARCHIVO'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_01=>'SUBMIT_CAMBIAR_ARCHIVO'
,p_attribute_02=>'Y'
,p_client_condition_type=>'NOT_NULL'
,p_client_condition_element=>'P413_ARCHIVO'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(114533671167807397)
,p_name=>'DOCUMENTOS ELECTRONICOS'
,p_event_sequence=>20
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P413_ACCION'
,p_condition_element=>'P413_ACCION'
,p_triggering_condition_type=>'NOT_NULL'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(114534071578807409)
,p_event_id=>wwv_flow_imp.id(114533671167807397)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'console.log(new Date().toString());',
'mostrarBarra()',
'console.log("P413_ID:"+$v("P413_ID"));',
'console.log("P413_ACCION:"+$v("P413_ACCION"));',
''))
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(114534569733807410)
,p_event_id=>wwv_flow_imp.id(114533671167807397)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_CANCEL_EVENT'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(114535094889807410)
,p_event_id=>wwv_flow_imp.id(114533671167807397)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'if(:P413_ACCION=''ENVIAR'')THEN',
'    PK_FINZ_SRI_AUTORIZACION.sp_documento_autorizar(:P413_ID);    ',
'elsif(:P413_ACCION=''BORRAR'')then',
'    delete files.t_apex_archivos where tabla=''T_FINZ_DOCUMENTO_ELECTRONICO'' and id_tabla =:P413_ID;',
'    delete DATA.t_finz_documento_electronico WHERE ID =:P413_ID;commit;',
'END IF;',
':P413_ID:=NULL;',
':P413_ACCION:=NULL;'))
,p_attribute_02=>'P413_ACCION,P413_ID'
,p_attribute_03=>'P413_ACCION,P413_ID'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(114535598802807411)
,p_event_id=>wwv_flow_imp.id(114533671167807397)
,p_event_result=>'TRUE'
,p_action_sequence=>50
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(114466911408667039)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(114536059666807411)
,p_event_id=>wwv_flow_imp.id(114533671167807397)
,p_event_result=>'TRUE'
,p_action_sequence=>60
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'ocultarBarra()',
'console.log("P413_ID:"+$v("P413_ID"));',
'console.log("P413_ACCION:"+$v("P413_ACCION"));',
'console.log(new Date().toString());'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(114516083616768714)
,p_name=>'CAMBIA TIPO DOCUMENTO'
,p_event_sequence=>30
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P413_TIPO_DOCUMENTO'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(114516146087768715)
,p_event_id=>wwv_flow_imp.id(114516083616768714)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_name=>'CAMBIA TIPO DOCUMENTO'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_02=>'Y'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(99966223018702844)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Cargar datos'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare ',
'    v_blob BLOB;',
'    V_tramaxml CLOB;',
'    v_sql clob;',
'    v_infoTributaria clob;',
'    v_infoDocumento clob;',
'    v_identificacion varchar2(20);',
'    v_codigoan8 number;',
'    V_AMBIENTE NUMBER;',
'    V_CLAVEACCESO VARCHAR2(50);',
'    V_CODDOC VARCHAR2(2);',
'    V_SECUENCIAL NUMBER;',
'    v_iddocumento number;',
'    v_APROBADO number:=1;',
'    v_AUTORIZADO number:=0;',
'    v_NUMEROINTENTO number:=1;',
'    v_ESTADO number:=3;',
'    v_GENERO_XML_ZM number:=1;',
'    v_GENERO_HTM_ZM number:=0;',
'    v_GENERO_PDF_ZM number:=0;',
'    v_numeroarchivo NUMBER;',
'    v_tipoorden varchar2(399);',
'    v_numeroorden number;',
'    v_filacli f0101@jdedtadl%rowtype;',
'    v_eserror number:=0;',
'    v_tipodocerror varchar2(399):='''';',
'    v_mensajeerror varchar2(399):='''';',
'begin',
'    FOR ARCHIVOS IN (',
'        SELECT ROWNUM IDROW,ID,APPLICATION_ID,NAME,FILENAME,MIME_TYPE,CREATED_ON,BLOB_CONTENT',
'        FROM APEX_APPLICATION_TEMP_FILES order by CREATED_ON, FILENAME ',
'    )',
'    LOOP',
'        v_blob:=NULL;',
'        V_tramaxml:=NULL;',
'        v_blob:=ARCHIVOS.BLOB_CONTENT;',
'        V_tramaxml:=pk_commons.f_blob_to_clob(v_blob);',
'        v_infoTributaria    :=  pk_sri_ws.f_get_xml_tag(V_tramaxml,''infoTributaria'') ;',
'',
'         SELECT AMBIENTE,  CLAVEACCESO,  CODDOC, TO_NUMBER(SECUENCIAL)SECUENCIAL',
'         INTO V_AMBIENTE,V_CLAVEACCESO,V_CODDOC,                    V_SECUENCIAL',
'         FROM table(pk_sri_ws.f_clobInfoTrib(v_infoTributaria) );',
'         ',
'        if (V_CODDOC=''01'')then',
'            if (:P413_TIPO_DOCUMENTO NOT in (''FE'',''FN''))THEN v_eserror:=1;v_mensajeerror:=''Tipo Documento seleccionado no valido para el documento XML Factura.'';end if;',
'        elsif (V_CODDOC=''03'')then',
'            if (:P413_TIPO_DOCUMENTO NOT in (''PJ'',''PQ''))THEN v_eserror:=1;v_mensajeerror:=''Tipo Documento seleccionado no valido para el documento XML Liquidacion de compras.'';end if;',
'        elsif (V_CODDOC=''04'')then',
unistr('            if (:P413_TIPO_DOCUMENTO NOT in (''D1''))THEN v_eserror:=1;v_mensajeerror:=''Tipo Documento seleccionado no valido para el documento XML Nota de Cr\00E9dito.'';end if;'),
'        elsif (V_CODDOC=''06'')then',
unistr('            if (:P413_TIPO_DOCUMENTO NOT in (''GE'',''GN''))THEN v_eserror:=1;v_mensajeerror:=''Tipo Documento seleccionado no valido para el documento XML Nota de Cr\00E9dito.'';end if;'),
'        elsif (V_CODDOC=''07'')then',
unistr('            if (:P413_TIPO_DOCUMENTO NOT in (''UR''))THEN v_eserror:=1;v_mensajeerror:=''Tipo Documento seleccionado no valido para el documento XML Comprobante de Retenci\00F3n.'';end if;'),
'        end if;',
'        IF (v_eserror=1)THEN',
'            :P413_ARCHIVO:=null;',
'            apex_error.add_error (',
'                p_message          => v_mensajeerror,',
'                p_display_location =>apex_error.c_inline_in_notification ,',
'                p_page_item_name   => ''P413_TIPO_DOCUMENTO''',
'            );',
'        else',
'            if (V_CODDOC=''01'')then',
'                v_infoDocumento:=pk_sri_ws.f_get_xml_tag(V_tramaxml,''infoFactura'') ;',
'            elsif (V_CODDOC=''03'')then',
'                v_infoDocumento:=pk_sri_ws.f_get_xml_tag(V_tramaxml,''infoLiquidacionCompra'') ;',
'            elsif (V_CODDOC=''04'')then',
'                v_infoDocumento:=pk_sri_ws.f_get_xml_tag(V_tramaxml,''infoNotaCredito'') ;',
'            elsif (V_CODDOC=''06'')then',
'                v_infoDocumento:=pk_sri_ws.f_get_xml_tag(V_tramaxml,''infoGuiaRemision'') ;',
'            elsif (V_CODDOC=''07'')then',
'                v_infoDocumento:=pk_sri_ws.f_get_xml_tag(V_tramaxml,''infoCompRetencion'') ;',
'            end if;',
'            v_sql:=''select ''||case V_CODDOC',
'                     when ''01'' then ''identificacionComprador''',
'                     when ''03'' then ''identificacionProveedor''',
'                     when ''04'' then ''identificacionComprador''',
'                     when ''06'' then ''rucTransportista''',
'                     when ''07'' then ''identificacionSujetoRetenido''',
'                 end||'' identificacion',
'             FROM table(pk_sri_ws.''||case V_CODDOC',
'                     when ''01'' then ''f_clobInfoFact''',
'                     when ''03'' then ''f_clobinfoLiquidacionCompra''',
'                     when ''04'' then ''f_clobInfoNtCr''',
'                     when ''06'' then ''f_clobinfoGuiaRemision''',
'                     when ''07'' then ''f_clobinfoCompRetencion''',
'                 end||''(''''''||v_infoDocumento||'''''') )'';-- returning identificacion into v_identificacion',
'            execute immediate v_sql  into v_identificacion;',
'            :P413_BORRAR:=V_SECUENCIAL;',
'            begin ',
'                SELECT * into v_filacli FROM f0101@jdedtadl WHERE trim(ABTAX)= trim(v_identificacion);  ',
'                v_codigoan8:=to_char(v_filacli.aban8);',
'            exception when others then ',
'                v_codigoan8:=null;',
'            end;',
'            begin',
'                select id, APROBADO,AUTORIZADO into  v_iddocumento,v_APROBADO,v_AUTORIZADO',
'                from t_finz_documento_electronico ',
'                where tipodocumento=:P413_TIPO_DOCUMENTO and  numerodocumento=V_SECUENCIAL;--and tipodocumentoerp =v_tipodocumentoerp and numerodocumentoerp = v_coddocumentoerp;',
'            exception when others then ',
'                v_iddocumento:=null;',
'            end ;',
'            IF (v_iddocumento IS NOT NULL)THEN',
'                apex_error.add_error (',
unistr('                    p_message          => ''Documento ya existente :''||case when v_APROBADO=1 then ''Aprobado y '' else '''' end||case when v_AUTORIZADO=1 then '' Autorizado'' else ''Sin Autorizaci\00F3n '' end ,'),
'                    p_display_location =>apex_error.c_inline_in_notification ',
'                );',
'            else',
'                insert into DATA.t_finz_documento_electronico ',
'                      (       TIPODOCUMENTO,NUMERODOCUMENTO,TIPODOCUMENTOERP,NUMERODOCUMENTOERP,  CODIGOAN8,  CLAVEACCESO,  APROBADO,  AUTORIZADO,  NUMEROINTENTO,  ESTADO,  GENERO_XML_ZM,  GENERO_HTM_ZM,  GENERO_PDF_ZM)',
'                values(:P413_TIPO_DOCUMENTO,   V_SECUENCIAL,     v_tipoorden,     v_numeroorden,v_codigoan8,v_claveacceso,v_APROBADO,v_AUTORIZADO,v_NUMEROINTENTO,v_ESTADO,v_GENERO_XML_ZM,v_GENERO_HTM_ZM,v_GENERO_PDF_ZM)',
'                returning id into v_iddocumento;',
'                DBMS_OUTPUT.PUT_LINE(''v_iddocumento:''||v_iddocumento);',
'                delete files.t_apex_archivos where tabla=pk_finz_sri_gestion.v_tabla_documentos and id_tabla= v_iddocumento  and  tipo in (''ARCH_XML'');',
'                PK_FINZ_SRI_GESTION.sp_enviarfilesarchivo( v_iddocumento, V_tramaxml, 4, pk_finz_sri_gestion.v_tabla_documentos ,v_numeroarchivo);',
'                commit;                    ',
'            END IF ;',
'             ',
'        END IF;',
'    END LOOP;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>'SUBMIT_CAMBIAR_ARCHIVO'
,p_process_when_type=>'REQUEST_EQUALS_CONDITION'
,p_internal_uid=>99966223018702844
);
wwv_flow_imp.component_end;
end;
/
