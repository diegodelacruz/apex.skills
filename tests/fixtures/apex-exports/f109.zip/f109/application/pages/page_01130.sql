prompt --application/pages/page_01130
begin
--   Manifest
--     PAGE: 01130
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>109
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_page.create_page(
 p_id=>1130
,p_name=>'Prueba Departamental - Proceso'
,p_step_title=>'Prueba Departamental'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'02'
,p_created_on=>wwv_flow_imp.dz('20230705164635Z')
,p_last_updated_on=>wwv_flow_imp.dz('20260427203120Z')
,p_last_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(529456338260316946)
,p_plug_name=>'Registros'
,p_region_name=>'rptRegistrosPDs'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(37806762584106520)
,p_plug_display_sequence=>30
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select a.rowid rid',
'	, apex_item.checkbox(1,a.id) seleccion',
'	, a.*',
'from t_finz_pruebadepdet a where a.idcab = :p1130_id'))
,p_plug_source_type=>'NATIVE_IR'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>210
,p_prn_height=>297
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_updated_on=>wwv_flow_imp.dz('20230708224432Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(529456423199316947)
,p_max_row_count=>'1000000'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_highlight=>'N'
,p_show_chart=>'N'
,p_show_flashback=>'N'
,p_show_help=>'N'
,p_download_formats=>'XLSX'
,p_enable_mail_download=>'N'
,p_owner=>'MCOELLO'
,p_internal_uid=>495115079406416640
,p_updated_on=>wwv_flow_imp.dz('20230708224432Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(532838501350979530)
,p_db_column_name=>'RID'
,p_display_order=>10
,p_column_identifier=>'P'
,p_column_label=>'Rid'
,p_column_type=>'OTHER'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(536252170741286907)
,p_db_column_name=>'RIDJDE'
,p_display_order=>20
,p_column_identifier=>'R'
,p_column_label=>'Ridjde'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(532839589329979540)
,p_db_column_name=>'SELECCION'
,p_display_order=>30
,p_column_identifier=>'Q'
,p_column_label=>'<input type="checkbox" id="selectunselectall">'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(529456525175316948)
,p_db_column_name=>'IDCAB'
,p_display_order=>40
,p_column_identifier=>'A'
,p_column_label=>'Idcab'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(529456705105316950)
,p_db_column_name=>'OBSERVACION'
,p_display_order=>50
,p_column_identifier=>'C'
,p_column_label=>'Observacion'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(532835611907979501)
,p_db_column_name=>'COMENTARIO'
,p_display_order=>60
,p_column_identifier=>'D'
,p_column_label=>'Comentario'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(532835706531979502)
,p_db_column_name=>'ESTADO'
,p_display_order=>70
,p_column_identifier=>'E'
,p_column_label=>'Estado'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(537331323995679317)
,p_db_column_name=>'GLDGJ'
,p_display_order=>80
,p_column_identifier=>'U'
,p_column_label=>'Fecha'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_format_mask=>'dd/mm/yyyy'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(532835854605979503)
,p_db_column_name=>'GLAID'
,p_display_order=>90
,p_column_identifier=>'F'
,p_column_label=>'Glaid'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(532836764883979512)
,p_db_column_name=>'GLICU'
,p_display_order=>100
,p_column_identifier=>'O'
,p_column_label=>unistr('N\00FAm. Batch')
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_hide=>'N'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(532836279272979507)
,p_db_column_name=>'GLDCT'
,p_display_order=>110
,p_column_identifier=>'J'
,p_column_label=>'Tipo Doc.'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(532836485678979509)
,p_db_column_name=>'GLDOC'
,p_display_order=>120
,p_column_identifier=>'L'
,p_column_label=>'Documento'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_hide=>'N'
,p_column_type=>'NUMBER'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(532836191363979506)
,p_db_column_name=>'GLDCTO'
,p_display_order=>130
,p_column_identifier=>'I'
,p_column_label=>'Tipo Orden'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(532836629702979511)
,p_db_column_name=>'GLPO'
,p_display_order=>140
,p_column_identifier=>'N'
,p_column_label=>'Ord. Compra'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(532836590809979510)
,p_db_column_name=>'GLAN8'
,p_display_order=>150
,p_column_identifier=>'M'
,p_column_label=>unistr('N\00FAm. Direcci\00F3n')
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_hide=>'N'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(532836361463979508)
,p_db_column_name=>'GLEXA'
,p_display_order=>160
,p_column_identifier=>'K'
,p_column_label=>unistr('Explicaci\00F3n')
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(532835995990979504)
,p_db_column_name=>'GLRCND'
,p_display_order=>170
,p_column_identifier=>'G'
,p_column_label=>unistr('C\00F3d. Con.')
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(532836062047979505)
,p_db_column_name=>'GLAA'
,p_display_order=>180
,p_column_identifier=>'H'
,p_column_label=>'Monto'
,p_column_link=>'f?p=&APP_ID.:1131:&SESSION.::&DEBUG.:1131:P1131_IDCAB,P1131_RID:#IDCAB#,#RID#'
,p_column_linktext=>'#GLAA#'
,p_allow_ctrl_breaks=>'N'
,p_allow_hide=>'N'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G990D00'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(537330871749679312)
,p_db_column_name=>'ID'
,p_display_order=>190
,p_column_identifier=>'S'
,p_column_label=>'Id'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(537330927100679313)
,p_db_column_name=>'FLAG'
,p_display_order=>200
,p_column_identifier=>'T'
,p_column_label=>'Flag'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(20360501455483023)
,p_db_column_name=>'GLEXR'
,p_display_order=>210
,p_column_identifier=>'V'
,p_column_label=>unistr('Exp. Observaci\00F3n')
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(20360954681483027)
,p_db_column_name=>'GLSBL'
,p_display_order=>220
,p_column_identifier=>'W'
,p_column_label=>'LM Aux.'
,p_column_type=>'STRING'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(532850160609022035)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'5328502'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'SELECCION:ESTADO:GLRCND:GLICU:GLDGJ:GLDCTO:GLDCT:GLPO:GLDOC:GLAN8:GLEXA:GLEXR:GLAA::GLSBL'
,p_sum_columns_on_break=>'GLAA'
,p_created_on=>wwv_flow_imp.dz('20230705164635Z')
,p_updated_on=>wwv_flow_imp.dz('20230705164635Z')
,p_created_by=>'CVACA'
,p_updated_by=>'CVACA'
);
wwv_flow_imp_page.create_worksheet_condition(
 p_id=>wwv_flow_imp.id(20938145559321301)
,p_report_id=>wwv_flow_imp.id(532850160609022035)
,p_name=>'Conciliados'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'ESTADO'
,p_operator=>'='
,p_expr=>'CONCILIADO'
,p_condition_sql=>' (case when ("ESTADO" = #APXWS_EXPR#) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# = ''CONCILIADO''  '
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_row_bg_color=>'#D5F5E3'
,p_created_on=>wwv_flow_imp.dz('20230705164635Z')
,p_updated_on=>wwv_flow_imp.dz('20230705164635Z')
,p_created_by=>'CVACA'
,p_updated_by=>'CVACA'
);
wwv_flow_imp_page.create_worksheet_condition(
 p_id=>wwv_flow_imp.id(20937395223321300)
,p_report_id=>wwv_flow_imp.id(532850160609022035)
,p_condition_type=>'FILTER'
,p_allow_delete=>'Y'
,p_column_name=>'GLAA'
,p_operator=>'!='
,p_expr=>'0'
,p_condition_sql=>'"GLAA" != to_number(#APXWS_EXPR#)'
,p_condition_display=>'#APXWS_COL_NAME# != #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
,p_created_on=>wwv_flow_imp.dz('20230705164635Z')
,p_updated_on=>wwv_flow_imp.dz('20230705164635Z')
,p_created_by=>'CVACA'
,p_updated_by=>'CVACA'
);
wwv_flow_imp_page.create_worksheet_condition(
 p_id=>wwv_flow_imp.id(20937736441321300)
,p_report_id=>wwv_flow_imp.id(532850160609022035)
,p_condition_type=>'FILTER'
,p_allow_delete=>'Y'
,p_column_name=>'GLAA'
,p_operator=>'='
,p_expr=>'0'
,p_condition_sql=>'"GLAA" = to_number(#APXWS_EXPR#)'
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'N'
,p_created_on=>wwv_flow_imp.dz('20230705164635Z')
,p_updated_on=>wwv_flow_imp.dz('20230705164635Z')
,p_created_by=>'CVACA'
,p_updated_by=>'CVACA'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(532672259243047409)
,p_plug_name=>'Prueba Departamental'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(38289867500120143)
,p_plug_display_sequence=>10
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'TEXT',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(536252230492286908)
,p_plug_name=>'Conciliar'
,p_region_name=>'regConciliar'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(38289867500120143)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(536255071771286936)
,p_plug_name=>'Botones'
,p_parent_plug_id=>wwv_flow_imp.id(536252230492286908)
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(38289867500120143)
,p_plug_display_sequence=>10
,p_plug_grid_column_span=>1
,p_plug_display_point=>'SUB_REGIONS'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(536255198496286937)
,p_plug_name=>unistr('Campos Agrupaci\00F3n')
,p_parent_plug_id=>wwv_flow_imp.id(536252230492286908)
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(38289867500120143)
,p_plug_display_sequence=>20
,p_plug_new_grid_row=>false
,p_plug_grid_column_span=>11
,p_plug_display_point=>'SUB_REGIONS'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(538864318155470014)
,p_plug_name=>'Comentarios'
,p_region_name=>'rptComentarios'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(37806762584106520)
,p_plug_display_sequence=>40
,p_include_in_reg_disp_sel_yn=>'Y'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select a.*',
'	, case when trim(a.comentario) is null then 1 else 0 end com',
'	, apex_item.text(p_idx => 3,p_value => a.comentario,p_item_id => a.id,p_attributes => ''class = "TX01"'') txtcomentario',
'	, apex_item.checkbox(p_idx => 4,p_value => a.flag,p_item_id => a.id,p_attributes => case when a.flag = 1 then ''CHECKED class = "CK01"'' else ''class = "CK01"'' end) ckbflag',
'from t_finz_pruebadepdet a where a.idcab = :p1130_id;'))
,p_plug_source_type=>'NATIVE_IR'
,p_ajax_items_to_submit=>'P1130_ID'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>210
,p_prn_height=>297
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_updated_on=>wwv_flow_imp.dz('20230708224432Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(538864452966470015)
,p_max_row_count=>'1000000'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_highlight=>'N'
,p_show_chart=>'N'
,p_show_flashback=>'N'
,p_show_help=>'N'
,p_download_formats=>'XLSX'
,p_enable_mail_download=>'N'
,p_owner=>'MCOELLO'
,p_internal_uid=>495115079406416640
,p_updated_on=>wwv_flow_imp.dz('20230708224432Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(538864510001470016)
,p_db_column_name=>'ID'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Id'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(538864621316470017)
,p_db_column_name=>'IDCAB'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Idcab'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(538864725459470018)
,p_db_column_name=>'RIDJDE'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Ridjde'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(538864813807470019)
,p_db_column_name=>'FLAG'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Flag'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(538864940841470020)
,p_db_column_name=>'OBSERVACION'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Observacion'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(538865055708470021)
,p_db_column_name=>'COMENTARIO'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'Comentario'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(538865116186470022)
,p_db_column_name=>'ESTADO'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>'Estado'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(538865279440470023)
,p_db_column_name=>'GLRCND'
,p_display_order=>80
,p_column_identifier=>'H'
,p_column_label=>unistr('C\00F3d. Con.')
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(538865337247470024)
,p_db_column_name=>'GLDGJ'
,p_display_order=>90
,p_column_identifier=>'I'
,p_column_label=>'Fecha'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_format_mask=>'dd/mm/yyyy'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(538865441936470025)
,p_db_column_name=>'GLAA'
,p_display_order=>100
,p_column_identifier=>'J'
,p_column_label=>'Monto'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G990D00'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(538865523812470026)
,p_db_column_name=>'GLDCTO'
,p_display_order=>110
,p_column_identifier=>'K'
,p_column_label=>'Tipo Orden'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(538865628231470027)
,p_db_column_name=>'GLDCT'
,p_display_order=>120
,p_column_identifier=>'L'
,p_column_label=>'Tipo Doc.'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(538865718430470028)
,p_db_column_name=>'GLEXA'
,p_display_order=>130
,p_column_identifier=>'M'
,p_column_label=>unistr('Explicaci\00F3n')
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(538865854584470029)
,p_db_column_name=>'GLAID'
,p_display_order=>140
,p_column_identifier=>'N'
,p_column_label=>'Glaid'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(538865979057470030)
,p_db_column_name=>'GLDOC'
,p_display_order=>150
,p_column_identifier=>'O'
,p_column_label=>'Documento'
,p_column_type=>'NUMBER'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(538866023070470031)
,p_db_column_name=>'GLAN8'
,p_display_order=>160
,p_column_identifier=>'P'
,p_column_label=>unistr('N\00FAm. Direcci\00F3n')
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(538866184528470032)
,p_db_column_name=>'GLPO'
,p_display_order=>170
,p_column_identifier=>'Q'
,p_column_label=>'Ord. Compra'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(538866298250470033)
,p_db_column_name=>'GLICU'
,p_display_order=>180
,p_column_identifier=>'R'
,p_column_label=>unistr('N\00FAm. Batch')
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(538866390993470034)
,p_db_column_name=>'COM'
,p_display_order=>190
,p_column_identifier=>'S'
,p_column_label=>'Flag Com.'
,p_column_type=>'NUMBER'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(538866401282470035)
,p_db_column_name=>'TXTCOMENTARIO'
,p_display_order=>200
,p_column_identifier=>'T'
,p_column_label=>'Comentario'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(538866547931470036)
,p_db_column_name=>'CKBFLAG'
,p_display_order=>210
,p_column_identifier=>'U'
,p_column_label=>'-'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(20360684981483024)
,p_db_column_name=>'GLEXR'
,p_display_order=>220
,p_column_identifier=>'V'
,p_column_label=>unistr('Exp. Observaci\00F3n')
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(20361002490483028)
,p_db_column_name=>'GLSBL'
,p_display_order=>230
,p_column_identifier=>'W'
,p_column_label=>'LM Aux.'
,p_column_type=>'STRING'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(6772692114994828)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'67727'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'ID:IDCAB:RIDJDE:FLAG:OBSERVACION:COMENTARIO:ESTADO:GLRCND:GLDGJ:GLAA:GLDCTO:GLDCT:GLEXA:GLAID:GLDOC:GLAN8:GLPO:GLICU:COM:TXTCOMENTARIO:CKBFLAG:GLEXR:GLSBL'
,p_created_on=>wwv_flow_imp.dz('20230705164635Z')
,p_updated_on=>wwv_flow_imp.dz('20230705164635Z')
,p_created_by=>'CVACA'
,p_updated_by=>'CVACA'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(539883079851683002)
,p_plug_name=>'Reporte Final'
,p_region_name=>'rptReporteFinal'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(37806762584106520)
,p_plug_display_sequence=>50
,p_include_in_reg_disp_sel_yn=>'Y'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select a.*',
'	, case when trim(a.comentario) is null then 1 else 0 end com',
'	, apex_item.checkbox(p_idx => 4,p_value => a.flag,p_item_id => a.id,p_attributes => case when a.flag = 1 then ''CHECKED'' else '''' end) ckbflag',
'from t_finz_pruebadepdet a where a.idcab = :p1130_id;'))
,p_plug_source_type=>'NATIVE_IR'
,p_ajax_items_to_submit=>'P1130_ID'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>210
,p_prn_height=>297
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_updated_on=>wwv_flow_imp.dz('20230708224432Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(539883330308683005)
,p_max_row_count=>'1000000'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_highlight=>'N'
,p_show_chart=>'N'
,p_show_flashback=>'N'
,p_show_help=>'N'
,p_download_formats=>'XLSX'
,p_enable_mail_download=>'N'
,p_owner=>'MCOELLO'
,p_internal_uid=>495115079406416640
,p_updated_on=>wwv_flow_imp.dz('20230708224432Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(539883428647683006)
,p_db_column_name=>'ID'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Id'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(539883507037683007)
,p_db_column_name=>'IDCAB'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Idcab'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(539883600467683008)
,p_db_column_name=>'RIDJDE'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Ridjde'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(539883760472683009)
,p_db_column_name=>'FLAG'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Flag'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(539883824864683010)
,p_db_column_name=>'OBSERVACION'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Observacion'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(539884036034683012)
,p_db_column_name=>'ESTADO'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>'Estado'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(539884197593683013)
,p_db_column_name=>'GLRCND'
,p_display_order=>80
,p_column_identifier=>'H'
,p_column_label=>unistr('C\00F3d. Con.')
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(539884231432683014)
,p_db_column_name=>'GLDGJ'
,p_display_order=>90
,p_column_identifier=>'I'
,p_column_label=>'Fecha'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_format_mask=>'dd/mm/yyyy'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(539884316453683015)
,p_db_column_name=>'GLAA'
,p_display_order=>100
,p_column_identifier=>'J'
,p_column_label=>'Monto'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G990D00'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(539884494008683016)
,p_db_column_name=>'GLDCTO'
,p_display_order=>110
,p_column_identifier=>'K'
,p_column_label=>'Tipo Orden'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(539884568959683017)
,p_db_column_name=>'GLDCT'
,p_display_order=>120
,p_column_identifier=>'L'
,p_column_label=>'Tipo Doc.'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(539884697370683018)
,p_db_column_name=>'GLEXA'
,p_display_order=>130
,p_column_identifier=>'M'
,p_column_label=>unistr('Explicaci\00F3n')
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(539884754329683019)
,p_db_column_name=>'GLAID'
,p_display_order=>140
,p_column_identifier=>'N'
,p_column_label=>'Glaid'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(539884853163683020)
,p_db_column_name=>'GLDOC'
,p_display_order=>150
,p_column_identifier=>'O'
,p_column_label=>'Documento'
,p_column_type=>'NUMBER'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(539884982944683021)
,p_db_column_name=>'GLAN8'
,p_display_order=>160
,p_column_identifier=>'P'
,p_column_label=>unistr('N\00FAm. Direcci\00F3n')
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(539885081321683022)
,p_db_column_name=>'GLPO'
,p_display_order=>170
,p_column_identifier=>'Q'
,p_column_label=>'Ord. Compra'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(539885139268683023)
,p_db_column_name=>'GLICU'
,p_display_order=>180
,p_column_identifier=>'R'
,p_column_label=>unistr('N\00FAm. Batch')
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(539885240871683024)
,p_db_column_name=>'COM'
,p_display_order=>190
,p_column_identifier=>'S'
,p_column_label=>'Flag Com.'
,p_column_type=>'NUMBER'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(539883919478683011)
,p_db_column_name=>'COMENTARIO'
,p_display_order=>200
,p_column_identifier=>'F'
,p_column_label=>'Comentario'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(539885431602683026)
,p_db_column_name=>'CKBFLAG'
,p_display_order=>210
,p_column_identifier=>'T'
,p_column_label=>'-'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(20360767788483025)
,p_db_column_name=>'GLEXR'
,p_display_order=>220
,p_column_identifier=>'U'
,p_column_label=>unistr('Exp. Observaci\00F3n')
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(20361113820483029)
,p_db_column_name=>'GLSBL'
,p_display_order=>230
,p_column_identifier=>'V'
,p_column_label=>'LM Aux.'
,p_column_type=>'STRING'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(6773229597994835)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'67733'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'ESTADO:GLRCND:GLDGJ:GLAA:GLDCTO:GLDCT:GLEXA:GLDOC:GLAN8:GLPO:GLICU:COM:GLEXR:COMENTARIO:CKBFLAG::GLSBL'
,p_created_on=>wwv_flow_imp.dz('20230705164635Z')
,p_updated_on=>wwv_flow_imp.dz('20230705164635Z')
,p_created_by=>'CVACA'
,p_updated_by=>'CVACA'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1415613620673388944)
,p_plug_name=>'Barra de Acciones'
,p_region_template_options=>'#DEFAULT#:t-Form--stretchInputs'
,p_plug_template=>wwv_flow_imp.id(38289497777120142)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'REGION_POSITION_01'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(532672902888047410)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(1415613620673388944)
,p_button_name=>'CANCEL'
,p_button_static_id=>'btnAtras'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860056812106557)
,p_button_image_alt=>'Salir'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'LEFT'
,p_button_redirect_url=>'f?p=&APP_ID.:1128:&SESSION.::&DEBUG.:::'
,p_icon_css_classes=>'fa-arrow-left'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(538863691919470007)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(1415613620673388944)
,p_button_name=>'REVERSARPD'
,p_button_static_id=>'btnReversarPD'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860056812106557)
,p_button_image_alt=>'Reversar PD'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-undo'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(537332191036679325)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(1415613620673388944)
,p_button_name=>'GUARDARHISTORICO'
,p_button_static_id=>'btnGuardarHistorico'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860056812106557)
,p_button_image_alt=>unistr('Guardar Hist\00F3rico')
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-cloud-plus'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(529454609179316929)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(1415613620673388944)
,p_button_name=>'EJECUTAR'
,p_button_static_id=>'btnEjecutar'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860056812106557)
,p_button_image_alt=>'Ejecutar'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-search'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(532672855323047410)
,p_button_sequence=>50
,p_button_plug_id=>wwv_flow_imp.id(1415613620673388944)
,p_button_name=>'DELETE'
,p_button_static_id=>'btnDelete'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860056812106557)
,p_button_image_alt=>'Borrar'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_button_execute_validations=>'N'
,p_warn_on_unsaved_changes=>null
,p_button_condition=>'P1130_ID'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_icon_css_classes=>'fa-trash-o'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(537765051676717632)
,p_button_sequence=>70
,p_button_plug_id=>wwv_flow_imp.id(1415613620673388944)
,p_button_name=>'FINALIZAR'
,p_button_static_id=>'btnFinalizar'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860056812106557)
,p_button_image_alt=>'Finalizar PD'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-folder-check'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(536254320036286929)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(536255071771286936)
,p_button_name=>'AGRUPAR'
,p_button_static_id=>'btnAgrupar'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860056812106557)
,p_button_image_alt=>unistr('Ver Agrupaci\00F3n')
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:1132:&SESSION.::&DEBUG.:RP,1132:P1132_IDCAB:&P1130_ID.'
,p_icon_css_classes=>'fa-table-plus'
,p_grid_new_row=>'N'
,p_grid_new_column=>'N'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(536253159144286917)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(536255071771286936)
,p_button_name=>'AGRUPARCONCILIAR'
,p_button_static_id=>'btnAgruparConciliar'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860056812106557)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Agrupar y Conciliar'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-list-ol'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(532672762822047410)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(532672259243047409)
,p_button_name=>'SAVE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860181880106559)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Apply Changes'
,p_button_position=>'CHANGE'
,p_button_alignment=>'RIGHT'
,p_button_condition_type=>'NEVER'
,p_grid_new_row=>'Y'
,p_database_action=>'UPDATE'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(532672611325047410)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(532672259243047409)
,p_button_name=>'CREATE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860181880106559)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Create'
,p_button_position=>'CREATE'
,p_button_alignment=>'RIGHT'
,p_button_condition_type=>'NEVER'
,p_grid_new_row=>'Y'
,p_database_action=>'INSERT'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(532839832476979543)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(529456338260316946)
,p_button_name=>'CONCILIAR'
,p_button_static_id=>'btnConciliar'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860056812106557)
,p_button_image_alt=>unistr('Conciliar Selecci\00F3n')
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
,p_button_alignment=>'RIGHT'
,p_button_execute_validations=>'N'
,p_button_css_classes=>'btnAccion'
,p_icon_css_classes=>'fa-table fam-check fam-is-success'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(537330631479679310)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(529456338260316946)
,p_button_name=>'DESCONCILIAR'
,p_button_static_id=>'btnDesconciliar'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860056812106557)
,p_button_image_alt=>unistr('Desconciliar Selecci\00F3n')
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
,p_button_alignment=>'RIGHT'
,p_button_execute_validations=>'N'
,p_icon_css_classes=>'fa-table fam-check fam-is-danger'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(529454209174316925)
,p_name=>'P1130_FECHADESDE'
,p_item_sequence=>140
,p_item_plug_id=>wwv_flow_imp.id(532672259243047409)
,p_use_cache_before_default=>'NO'
,p_item_default=>'to_date(:p1130_anno||:p1130_mes,''yyyymm'')'
,p_item_default_type=>'EXPRESSION'
,p_item_default_language=>'PLSQL'
,p_prompt=>'Desde'
,p_source=>'FECHADESDE'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'U'
,p_encrypt_session_state_yn=>'N'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(529454337938316926)
,p_name=>'P1130_FECHAHASTA'
,p_item_sequence=>150
,p_item_plug_id=>wwv_flow_imp.id(532672259243047409)
,p_use_cache_before_default=>'NO'
,p_item_default=>'last_day(to_date(:p1130_anno||:p1130_mes,''yyyymm''))'
,p_item_default_type=>'EXPRESSION'
,p_item_default_language=>'PLSQL'
,p_prompt=>'Hasta'
,p_source=>'FECHAHASTA'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'U'
,p_encrypt_session_state_yn=>'N'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(529454455394316927)
,p_name=>'P1130_TIPOREGISTRO'
,p_item_sequence=>130
,p_item_plug_id=>wwv_flow_imp.id(532672259243047409)
,p_use_cache_before_default=>'NO'
,p_item_default=>'TODO'
,p_prompt=>'Tipo registro'
,p_source=>'TIPOREGISTRO'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_RADIOGROUP'
,p_lov=>'STATIC:Conciliados;CON,No Conciliados;noCON,TODO;TODO'
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'U'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'3'
,p_attribute_02=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(529455637534316939)
,p_name=>'P1130_RESPUESTA'
,p_item_sequence=>190
,p_item_plug_id=>wwv_flow_imp.id(532672259243047409)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(532674930405047417)
,p_name=>'P1130_ID'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(532672259243047409)
,p_use_cache_before_default=>'NO'
,p_source=>'ID'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_protection_level=>'S'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(532675327436047417)
,p_name=>'P1130_COMPANIA'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(532672259243047409)
,p_use_cache_before_default=>'NO'
,p_source=>'COMPANIA'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(532675766323047418)
,p_name=>'P1130_IDCFG'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(532672259243047409)
,p_use_cache_before_default=>'NO'
,p_source=>'IDCFG'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(532676100980047418)
,p_name=>'P1130_IDCUENTA'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(532672259243047409)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Cuenta'
,p_source=>'IDCUENTA'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_named_lov=>'LOV_CUENTAXID'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select replace(gmmcu||''.''||gmobj||''.''||gmsub,'' '',null)||'' - ''||trim(gmdl01) d, trim(gmaid) r',
'from f0901@jdedtadl',
'where gmco = :g_compania and ',
'(replace(gmmcu,'' '',''x'') != ''xxxxxxxxxxxx'' and gmmcu not like ''%MODELO%'') and',
'replace(gmobj,'' '',''x'') != ''xxxxxx'' and ',
'replace(gmsub,'' '',''x'') != ''xxxxxxxx''',
'order by 1'))
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'LOV'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(532676564950047418)
,p_name=>'P1130_CAMPOS'
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_imp.id(532672259243047409)
,p_use_cache_before_default=>'NO'
,p_source=>'CAMPOS'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(532676993908047420)
,p_name=>'P1130_ESTADO'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(532672259243047409)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Estado'
,p_source=>'ESTADO'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(532677363166047420)
,p_name=>'P1130_CODUSUARIO'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(532672259243047409)
,p_use_cache_before_default=>'NO'
,p_source=>'CODUSUARIO'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(532677762115047421)
,p_name=>'P1130_CODRESPONSABLE'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(532672259243047409)
,p_use_cache_before_default=>'NO'
,p_source=>'CODRESPONSABLE'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(532678168484047421)
,p_name=>'P1130_FECHAEJE'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_imp.id(532672259243047409)
,p_use_cache_before_default=>'NO'
,p_source=>'FECHAEJE'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(532678962183047423)
,p_name=>'P1130_CONSULTA'
,p_item_sequence=>120
,p_item_plug_id=>wwv_flow_imp.id(532672259243047409)
,p_use_cache_before_default=>'NO'
,p_source=>'CONSULTA'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(532839337685979538)
,p_name=>'P1130_ANNO'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(532672259243047409)
,p_use_cache_before_default=>'NO'
,p_prompt=>unistr('A\00F1o')
,p_source=>'ANNO'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(532839417978979539)
,p_name=>'P1130_MES'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(532672259243047409)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Mes'
,p_source=>'MES'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_named_lov=>'LOV_MESES'
,p_lov=>'select to_char(to_date(level,''MM''),''Month'') d, level r from dual connect by level <= 12'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'LOV'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(532840094572979545)
,p_name=>'P1130_BANDERA1'
,p_item_sequence=>200
,p_item_plug_id=>wwv_flow_imp.id(532672259243047409)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(532840113633979546)
,p_name=>'P1130_BANDERA2'
,p_item_sequence=>210
,p_item_plug_id=>wwv_flow_imp.id(532672259243047409)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(536252011656286906)
,p_name=>'P1130_SALDO'
,p_item_sequence=>160
,p_item_plug_id=>wwv_flow_imp.id(532672259243047409)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Saldo LM'
,p_format_mask=>'FML999G999G999G999G990D00'
,p_source=>'SALDOLM'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(536252922577286915)
,p_name=>'P1130_CAMPOSAGRUPACION'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(536255198496286937)
,p_prompt=>unistr('Campos de Agrupaci\00F3n')
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select distinct a.campo||'' - ''||nvl(b.descripcion2,b.descripcion) d, a.campo',
'from vt_finz_cfgconciliacion a left join t_corp_udc b on a.campo = decode(a.tabla,''F0911'',''GL''||b.id_tabla,b.id_tabla) and b.id_cabecera = ''1''',
'where a.opcion = ''PRUEBADEP'' order by 1'))
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'4'
,p_multi_value_type=>'SEPARATED'
,p_multi_value_separator=>':'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(536253720222286923)
,p_name=>'P1130_SALDOCUENTA'
,p_item_sequence=>170
,p_item_plug_id=>wwv_flow_imp.id(532672259243047409)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Saldo Cuenta'
,p_format_mask=>'FML999G999G999G999G990D00'
,p_source=>'SALDOCT'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(536253818711286924)
,p_name=>'P1130_DIFERENCIA'
,p_item_sequence=>180
,p_item_plug_id=>wwv_flow_imp.id(532672259243047409)
,p_prompt=>'Diferencia'
,p_source=>'select to_char(nvl(saldolm,0) - nvl(saldoct,0),''FML999G999G999G999G990D00'') d from t_finz_pruebadepcab where id = :p1130_id'
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(538867541709470046)
,p_name=>'P1130_TABLAID'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(538864318155470014)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(538867640844470047)
,p_name=>'P1130_TABLAVALOR'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(538864318155470014)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(532678614026047421)
,p_validation_name=>'P1130_FECHAEJE must be timestamp'
,p_validation_sequence=>90
,p_validation=>'P1130_FECHAEJE'
,p_validation_type=>'ITEM_IS_TIMESTAMP'
,p_error_message=>'#LABEL# must be a valid timestamp.'
,p_associated_item=>wwv_flow_imp.id(532678168484047421)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(529454952006316932)
,p_name=>'Delete'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(532672855323047410)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(529455081197316933)
,p_event_id=>wwv_flow_imp.id(529454952006316932)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'mostrarBarra();'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(529455230725316935)
,p_event_id=>wwv_flow_imp.id(529454952006316932)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'    update t_finz_pruebadepcab x set x.estado = ''BORRADO'', x.fechaeje = sysdate where id = :p1130_id;',
'end;'))
,p_attribute_02=>'P1130_ID'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(529455198107316934)
,p_event_id=>wwv_flow_imp.id(529454952006316932)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'ocultarBarra();',
'$(''#btnAtras'').trigger("click");'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(529455322831316936)
,p_name=>'Ejecutar'
,p_event_sequence=>20
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(529454609179316929)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(529455406278316937)
,p_event_id=>wwv_flow_imp.id(529455322831316936)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'mostrarBarra();'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(529455580221316938)
,p_event_id=>wwv_flow_imp.id(529455322831316936)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'v_aux_num1	number;',
'v_aux_num2	number;',
'begin',
'    pk_finz_conciliacion.sp_pruebadepartamental(:g_compania,:app_user,:p1130_id,:p1130_fechadesde,:p1130_fechahasta,:p1130_tiporegistro,:p1130_respuesta);',
'',
'	select pk_finz_conciliacion.f_saldolm(compania,idcuenta,anno,mes),pk_finz_conciliacion.f_saldocuenta(compania,idcuenta,''noCON'',anno,mes)',
'    into v_aux_num1,v_aux_num2 from t_finz_pruebadepcab where id = :p1130_id;',
'',
'	:p1130_saldo := v_aux_num1; :p1130_saldocuenta := v_aux_num2; :p1130_diferencia := nvl(v_aux_num1,0) - nvl(v_aux_num2,0);',
'',
'    update t_finz_pruebadepcab x set x.saldolm = v_aux_num1, x.saldoct = v_aux_num2 where x.id = :p1130_id;',
'',
'    select count(*) into :p1130_bandera1 from t_finz_pruebadepdet a where a.idcab = :p1130_id;',
'end;'))
,p_attribute_02=>'G_COMPANIA,APP_USER,P1130_ID,P1130_FECHAHASTA,P1130_FECHADESDE,P1130_TIPOREGISTRO'
,p_attribute_03=>'P1130_RESPUESTA,P1130_BANDERA1,P1130_SALDO,P1130_SALDOCUENTA,P1130_DIFERENCIA'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(529456035224316943)
,p_event_id=>wwv_flow_imp.id(529455322831316936)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'if ($v(''P1130_BANDERA1'') > 0 ){',
'	$(''#btnGuardarHistorico'').show();',
'	$(''#regConciliar'').show();',
'	$(''#rptRegistrosPDs'').show();',
'}'))
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(529455744133316940)
,p_event_id=>wwv_flow_imp.id(529455322831316936)
,p_event_result=>'TRUE'
,p_action_sequence=>50
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(532672259243047409)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(536251826501286904)
,p_event_id=>wwv_flow_imp.id(529455322831316936)
,p_event_result=>'TRUE'
,p_action_sequence=>60
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(536252230492286908)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(537331252582679316)
,p_event_id=>wwv_flow_imp.id(529455322831316936)
,p_event_result=>'TRUE'
,p_action_sequence=>70
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(529456338260316946)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(536252313753286909)
,p_event_id=>wwv_flow_imp.id(529455322831316936)
,p_event_result=>'TRUE'
,p_action_sequence=>80
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'ocultarBarra();'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(532839601511979541)
,p_name=>unistr('Selecci\00F3n IR')
,p_event_sequence=>30
,p_triggering_element_type=>'JQUERY_SELECTOR'
,p_triggering_element=>'#selectunselectall'
,p_bind_type=>'live'
,p_bind_delegate_to_selector=>'#rptRegistrosPDs'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(532839797591979542)
,p_event_id=>wwv_flow_imp.id(532839601511979541)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'if ($(''#rptRegistrosPDs #selectunselectall'' ).is('':checked'')) {',
'    $(''#rptRegistrosPDs input[type=checkbox][name=f01]'').prop(''checked'',true);',
'} else {',
'    $(''#rptRegistrosPDs input[type=checkbox][name=f01]'').prop(''checked'',false);',
'}'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(538866693359470037)
,p_name=>unistr('Selecci\00F3n IR Comentarios')
,p_event_sequence=>40
,p_triggering_element_type=>'JQUERY_SELECTOR'
,p_triggering_element=>'#selectunselectallcomentario'
,p_bind_type=>'live'
,p_bind_delegate_to_selector=>'#rptComentarios'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(538866719491470038)
,p_event_id=>wwv_flow_imp.id(538866693359470037)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'if ($(''#rptComentarios #selectunselectallcomentario'' ).is('':checked'')) {',
'    $(''#rptComentarios input[type=checkbox][name=f02]'').prop(''checked'',true);',
'} else {',
'    $(''#rptComentarios input[type=checkbox][name=f02]'').prop(''checked'',false);',
'}'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(536253210096286918)
,p_name=>'Agrupar y Conciliar'
,p_event_sequence=>50
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(536253159144286917)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
,p_updated_on=>wwv_flow_imp.dz('20241211140520Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(536253394226286919)
,p_event_id=>wwv_flow_imp.id(536253210096286918)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'mostrarBarra();'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(536253596476286921)
,p_event_id=>wwv_flow_imp.id(536253210096286918)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'v_respuesta number;',
'v_aux_num1	number;',
'v_aux_num2	number;',
'begin',
'    pk_finz_conciliacion.sp_agruparconciliar(:app_user,:p1130_id,:p1130_camposagrupacion,v_respuesta); commit;',
'',
'	select pk_finz_conciliacion.f_saldolm(compania,idcuenta,anno,mes),pk_finz_conciliacion.f_saldocuenta(compania,idcuenta,''noCON'',anno,mes)',
'    into v_aux_num1,v_aux_num2 from t_finz_pruebadepcab where id = :p1130_id;',
'',
'    :p1130_saldo := v_aux_num1; :p1130_saldocuenta := v_aux_num2; :p1130_diferencia := nvl(v_aux_num1,0) - nvl(v_aux_num2,0);',
'',
'    update t_finz_pruebadepcab x set x.saldolm = v_aux_num1, x.saldoct = v_aux_num2 where x.id = :p1130_id;',
'',
'    :p1130_camposagrupacion := null;',
'end;'))
,p_attribute_02=>'APP_USER,P1130_ID,P1130_CAMPOSAGRUPACION'
,p_attribute_03=>'P1130_CAMPOSAGRUPACION,P1130_SALDO,P1130_SALDOCUENTA,P1130_DIFERENCIA'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20241211140520Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(536253671273286922)
,p_event_id=>wwv_flow_imp.id(536253210096286918)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(529456338260316946)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(536253460654286920)
,p_event_id=>wwv_flow_imp.id(536253210096286918)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'ocultarBarra();'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(536254632622286932)
,p_name=>'Cambio'
,p_event_sequence=>60
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P1130_CAMPOSAGRUPACION'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(536254747388286933)
,p_event_id=>wwv_flow_imp.id(536254632622286932)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'    :g_variable := :p1130_camposagrupacion;',
'end;'))
,p_attribute_02=>'P1130_CAMPOSAGRUPACION'
,p_attribute_03=>'G_VARIABLE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(537331584613679319)
,p_name=>'Tipo Registro'
,p_event_sequence=>70
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P1130_TIPOREGISTRO'
,p_condition_element=>'P1130_TIPOREGISTRO'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'noCON'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(537331655653679320)
,p_event_id=>wwv_flow_imp.id(537331584613679319)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P1130_FECHADESDE,P1130_FECHAHASTA'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(537331744394679321)
,p_event_id=>wwv_flow_imp.id(537331584613679319)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P1130_FECHADESDE,P1130_FECHAHASTA'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(537331859685679322)
,p_name=>unistr('Cargar p\00E1gina')
,p_event_sequence=>80
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'ready'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(537331970434679323)
,p_event_id=>wwv_flow_imp.id(537331859685679322)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'    select count(*) into :p1130_bandera1 from t_finz_pruebadepdet a where a.idcab = :p1130_id;',
'    select pk_admi_gestionparametros.f_admi_accesoacciones(:app_modulo,:app_user,:app_page_id,''REVERSARESTADOPD'') into :p1130_bandera2 from dual;',
'end;'))
,p_attribute_02=>'G_COMPANIA,P1130_ID,APP_MODULO,APP_USER,APP_PAGE_ID'
,p_attribute_03=>'P1130_BANDERA1,P1130_BANDERA2'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(537332003377679324)
,p_event_id=>wwv_flow_imp.id(537331859685679322)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'if ($v(''P1130_ESTADO'') == ''CREADO'') {',
'	$(''#btnDelete'').show();',
'	$(''#btnEjecutar'').show();',
'	$(''#btnFinalizar'').hide();',
'	$(''#btnGuardarComentarios'').hide();',
'	$(''#btnReversarPD'').hide();',
'	$(''#rptComentarios'').hide();',
'    $(''#rptReporteFinal'').hide();',
'',
'	if ($v(''P1130_BANDERA1'') > 0) {',
'		$(''#btnGuardarHistorico'').show(); $(''#regConciliar'').show(); $(''#rptRegistrosPDs'').show();',
'	} else if ($v(''P1130_BANDERA1'') == 0) {',
'		$(''#btnGuardarHistorico'').hide(); $(''#regConciliar'').hide(); $(''#rptRegistrosPDs'').hide();',
'	}',
unistr('} else if ($v(''P1130_ESTADO'') == ''REVISI\00D3N'') {'),
'	if ($v(''P1130_BANDERA2'') == 1) {$(''#btnReversarPD'').show();} else {$(''#btnReversarPD'').hide();}',
'	apex.item("P1130_TIPOREGISTRO").disable();',
'	$(''#btnGuardarComentarios'').show();',
'	$(''#btnGuardarHistorico'').hide();	',
'	$(''#btnDelete'').hide();',
'	$(''#btnEjecutar'').hide();',
'	$(''#btnFinalizar'').show();',
'	$(''#regConciliar'').show();',
'	$(''#btnAgruparConciliar'').hide();',
'	$(''#rptComentarios'').show();',
'	$(''#rptRegistrosPDs'').hide();',
'    $(''#rptReporteFinal'').hide();',
'} else if ($v(''P1130_ESTADO'') == ''FINALIZADO'') {',
'	apex.item("P1130_TIPOREGISTRO").hide();',
'	$(''#btnGuardarComentarios'').hide();',
'	$(''#btnGuardarHistorico'').hide();',
'	if ($v(''P1130_BANDERA2'') == 1) {$(''#btnReversarPD'').show();} else {$(''#btnReversarPD'').hide();}',
'	$(''#btnDelete'').hide();',
'	$(''#btnEjecutar'').hide();',
'	$(''#btnFinalizar'').hide();',
'	$(''#regConciliar'').hide();',
'	$(''#rptComentarios'').hide();',
'	$(''#rptRegistrosPDs'').hide();',
'    $(''#rptReporteFinal'').show();',
'}'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(537332267416679326)
,p_name=>unistr('Guardar Hist\00F3rico')
,p_event_sequence=>90
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(537332191036679325)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(537332320739679327)
,p_event_id=>wwv_flow_imp.id(537332267416679326)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'mostrarBarra();'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(537332588472679329)
,p_event_id=>wwv_flow_imp.id(537332267416679326)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'v_aux_num1	number;',
'v_aux_num2	number;',
'begin',
unistr('    update t_finz_pruebadepcab x set x.estado = ''REVISI\00D3N'' where x.id = :p1130_id;'),
'',
'	select pk_finz_conciliacion.f_saldolm(compania,idcuenta,anno,mes),pk_finz_conciliacion.f_saldocuenta(compania,idcuenta,''noCON'',anno,mes)',
'    into v_aux_num1,v_aux_num2 from t_finz_pruebadepcab where id = :p1130_id;',
'',
'    :p1130_saldo := v_aux_num1; :p1130_saldocuenta := v_aux_num2; :p1130_diferencia := nvl(v_aux_num1,0) - nvl(v_aux_num2,0);',
'',
'    update t_finz_pruebadepcab x set x.saldolm = v_aux_num1, x.saldoct = v_aux_num2 where x.id = :p1130_id;',
'',
unistr('    :p1130_estado := ''REVISI\00D3N'';'),
'    select pk_admi_gestionparametros.f_admi_accesoacciones(:app_modulo,:app_user,:app_page_id,''REVERSARESTADOPD'') into :p1130_bandera2 from dual;',
'end;'))
,p_attribute_02=>'P1130_ID,APP_MODULO,APP_USER,APP_PAGE_ID'
,p_attribute_03=>'P1130_ESTADO,P1130_BANDERA2,P1130_SALDO,P1130_SALDOCUENTA,P1130_DIFERENCIA'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(537332659522679330)
,p_event_id=>wwv_flow_imp.id(537332267416679326)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(532672259243047409)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(537332783246679331)
,p_event_id=>wwv_flow_imp.id(537332267416679326)
,p_event_result=>'TRUE'
,p_action_sequence=>50
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
unistr('if ($v(''P1130_ESTADO'') == ''REVISI\00D3N'') {'),
'	if ($v(''P1130_BANDERA2'') == 1) {$(''#btnReversarPD'').show();} else {$(''#btnReversarPD'').hide();}',
'	apex.item("P1130_TIPOREGISTRO").disable();',
'	$(''#btnGuardarComentarios'').show();',
'	$(''#btnGuardarHistorico'').hide();	',
'	$(''#btnDelete'').hide();',
'	$(''#btnEjecutar'').hide();',
'	$(''#btnFinalizar'').show();',
'	$(''#regConciliar'').show();',
'	$(''#btnAgruparConciliar'').hide();',
'	$(''#rptComentarios'').show();',
'	$(''#rptRegistrosPDs'').hide();',
'}',
'ocultarBarra();'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(537765132566717633)
,p_name=>'Finalizar PD'
,p_event_sequence=>100
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(537765051676717632)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(537765238805717634)
,p_event_id=>wwv_flow_imp.id(537765132566717633)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'mostrarBarra();'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(537765430358717636)
,p_event_id=>wwv_flow_imp.id(537765132566717633)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'v_aux_num1	number;',
'v_aux_num2	number;',
'begin',
'    update t_finz_pruebadepcab x set x.estado = ''FINALIZADO'' where x.id = :p1130_id; commit;',
'',
'	select pk_finz_conciliacion.f_saldolm(compania,idcuenta,anno,mes),pk_finz_conciliacion.f_saldocuenta(compania,idcuenta,''noCON'',anno,mes)',
'    into v_aux_num1,v_aux_num2 from t_finz_pruebadepcab where id = :p1130_id;',
'',
'	:p1130_saldo := v_aux_num1; :p1130_saldocuenta := v_aux_num2; :p1130_diferencia := nvl(v_aux_num1,0) - nvl(v_aux_num2,0);',
'',
'    update t_finz_pruebadepcab x set x.saldolm = v_aux_num1, x.saldoct = v_aux_num2 where x.id = :p1130_id;',
'end;'))
,p_attribute_02=>'P1130_ID'
,p_attribute_03=>'P1130_SALDO,P1130_SALDOCUENTA,P1130_DIFERENCIA'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(537765377199717635)
,p_event_id=>wwv_flow_imp.id(537765132566717633)
,p_event_result=>'TRUE'
,p_action_sequence=>60
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'ocultarBarra();',
'$(''#btnAtras'').trigger("click");'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(538863714447470008)
,p_name=>'Reversar PD'
,p_event_sequence=>110
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(538863691919470007)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(538863875046470009)
,p_event_id=>wwv_flow_imp.id(538863714447470008)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'mostrarBarra();'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(538864133703470012)
,p_event_id=>wwv_flow_imp.id(538863714447470008)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'    update t_finz_pruebadepcab x set x.estado = ''CREADO'' where x.id = :p1130_id;',
'    :p1130_estado := ''CREADO'';',
'    select pk_admi_gestionparametros.f_admi_accesoacciones(:app_modulo,:app_user,:app_page_id,''REVERSARESTADOPD'') into :p1130_bandera2 from dual;    ',
'end;'))
,p_attribute_02=>'P1130_ID,APP_MODULO,APP_USER,APP_PAGE_ID'
,p_attribute_03=>'P1130_ESTADO,P1130_BANDERA2'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(538864229432470013)
,p_event_id=>wwv_flow_imp.id(538863714447470008)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(532672259243047409)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(538863982117470010)
,p_event_id=>wwv_flow_imp.id(538863714447470008)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'if ($v(''P1130_ESTADO'') == ''CREADO'') {',
'	$(''#btnDelete'').show();',
'	$(''#btnEjecutar'').show();',
'	$(''#btnFinalizar'').hide();',
'	$(''#btnGuardarComentarios'').hide();',
'	$(''#btnReversarPD'').hide();',
'	$(''#rptComentarios'').hide();',
'',
'	if ($v(''P1130_BANDERA1'') > 0) {',
'		$(''#btnGuardarHistorico'').show(); $(''#regConciliar'').show(); $(''#rptRegistrosPDs'').show();',
'	} else if ($v(''P1130_BANDERA1'') == 0) {',
'		$(''#btnGuardarHistorico'').hide(); $(''#regConciliar'').hide(); $(''#rptRegistrosPDs'').hide();',
'	}',
'}',
'ocultarBarra();'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(538867352600470044)
,p_name=>'Guarda Comentario'
,p_event_sequence=>120
,p_triggering_element_type=>'JQUERY_SELECTOR'
,p_triggering_element=>'.TX01'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(538867430583470045)
,p_event_id=>wwv_flow_imp.id(538867352600470044)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'var i=$(this.triggeringElement).attr(''id'');',
'var v=$(this.triggeringElement).val();',
'console.log("cambio id:"+i+" valor:"+v)',
'apex.item("P1130_TABLAVALOR").setValue(v);',
'apex.item("P1130_TABLAID").setValue(i);',
'mensajeExito(''Cambios guardados'');'))
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(538867772852470048)
,p_event_id=>wwv_flow_imp.id(538867352600470044)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'    update t_finz_pruebadepdet x set x.comentario = :p1130_tablavalor where id = :p1130_tablaid;',
'end;'))
,p_attribute_02=>'P1130_TABLAVALOR,P1130_TABLAID'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(538867811575470049)
,p_name=>'Guarda Checkbox'
,p_event_sequence=>130
,p_triggering_element_type=>'JQUERY_SELECTOR'
,p_triggering_element=>'.CK01'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(538867970057470050)
,p_event_id=>wwv_flow_imp.id(538867811575470049)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'var i=$(this.triggeringElement).attr(''id'');',
'var v=$(this.triggeringElement).val();',
'console.log("cambio id:"+i+" valor:"+v)',
'apex.item("P1130_TABLAVALOR").setValue(v);',
'apex.item("P1130_TABLAID").setValue(i);',
'mensajeExito(''Cambios guardados'');'))
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(539882967203683001)
,p_event_id=>wwv_flow_imp.id(538867811575470049)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'    update t_finz_pruebadepdet x set x.flag = case when x.flag = 1 then null else 1 end where id = :p1130_tablaid;',
'end;'))
,p_attribute_02=>'P1130_TABLAVALOR,P1130_TABLAID'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(532679700617047423)
,p_process_sequence=>10
,p_process_point=>'AFTER_HEADER'
,p_process_type=>'NATIVE_FORM_FETCH'
,p_process_name=>'Fetch Row from T_FINZ_PRUEBADEPCAB'
,p_attribute_02=>'T_FINZ_PRUEBADEPCAB'
,p_attribute_03=>'P1130_ID'
,p_attribute_04=>'ID'
,p_internal_uid=>532679700617047423
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(532680181324047425)
,p_process_sequence=>30
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_FORM_PROCESS'
,p_process_name=>'Process Row of T_FINZ_PRUEBADEPCAB'
,p_attribute_02=>'T_FINZ_PRUEBADEPCAB'
,p_attribute_03=>'P1130_ID'
,p_attribute_04=>'ID'
,p_attribute_11=>'I:U:D'
,p_attribute_12=>'Y'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_success_message=>'Action Processed.'
,p_internal_uid=>532680181324047425
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(532680568290047425)
,p_process_sequence=>40
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_SESSION_STATE'
,p_process_name=>'reset page'
,p_attribute_01=>'CLEAR_CACHE_CURRENT_PAGE'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(532672855323047410)
,p_internal_uid=>532680568290047425
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(536251763277286903)
,p_process_sequence=>50
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Conciliar'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'v_iddet number;',
'v_aux_num1	number;',
'v_aux_num2	number;',
'begin',
'	for i in 1..apex_application.g_f01.count loop',
'        v_iddet := apex_application.g_f01(i);',
'        pk_finz_conciliacion.sp_conciliar(:app_user,v_iddet,1);',
'	end loop;',
'',
'	select pk_finz_conciliacion.f_saldolm(compania,idcuenta,anno,mes),pk_finz_conciliacion.f_saldocuenta(compania,idcuenta,''noCON'',anno,mes)',
'    into v_aux_num1,v_aux_num2 from t_finz_pruebadepcab where id = :p1130_id;',
'',
'    :p1130_saldo := v_aux_num1; :p1130_saldocuenta := v_aux_num2; :p1130_diferencia := nvl(v_aux_num1,0) - nvl(v_aux_num2,0);',
'	',
'    update t_finz_pruebadepcab x set x.saldolm = v_aux_num1, x.saldoct = v_aux_num2 where x.id = :p1130_id;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(532839832476979543)
,p_internal_uid=>536251763277286903
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(537330781177679311)
,p_process_sequence=>60
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Desconciliar'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'v_iddet number;',
'v_aux_num1	number;',
'v_aux_num2	number;',
'begin',
'	for i in 1..apex_application.g_f01.count loop',
'        v_iddet := apex_application.g_f01(i);',
'        pk_finz_conciliacion.sp_conciliar(:app_user,v_iddet,2);',
'	end loop;',
'',
'	select pk_finz_conciliacion.f_saldolm(compania,idcuenta,anno,mes),pk_finz_conciliacion.f_saldocuenta(compania,idcuenta,''noCON'',anno,mes)',
'    into v_aux_num1,v_aux_num2 from t_finz_pruebadepcab where id = :p1130_id;',
'',
'    :p1130_saldo := v_aux_num1; :p1130_saldocuenta := v_aux_num2; :p1130_diferencia := nvl(v_aux_num1,0) - nvl(v_aux_num2,0);',
'	',
'    update t_finz_pruebadepcab x set x.saldolm = v_aux_num1, x.saldoct = v_aux_num2 where x.id = :p1130_id;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(537330631479679310)
,p_internal_uid=>537330781177679311
);
wwv_flow_imp.component_end;
end;
/
