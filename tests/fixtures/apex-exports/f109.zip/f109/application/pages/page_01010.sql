prompt --application/pages/page_01010
begin
--   Manifest
--     PAGE: 01010
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>109
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_page.create_page(
 p_id=>1010
,p_name=>unistr('Modificaci\00F3n de Estados de OCs de Pagos Recurrentes')
,p_step_title=>unistr('Modificaci\00F3n de Estados de OCs de Pagos Recurrentes')
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_page_component_map=>'17'
,p_created_on=>wwv_flow_imp.dz('20230705164635Z')
,p_last_updated_on=>wwv_flow_imp.dz('20220926140116Z')
,p_last_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(87117382646254514)
,p_plug_name=>unistr('Par\00E1metros')
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(38289867500120143)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(260747734829089916)
,p_plug_name=>'Acciones'
,p_region_template_options=>'#DEFAULT#:t-Form--stretchInputs'
,p_plug_template=>wwv_flow_imp.id(38289497777120142)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(87117745987254518)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(260747734829089916)
,p_button_name=>'EJECUTAR'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860056812106557)
,p_button_image_alt=>'Ejecutar'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-gear'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(87117412515254515)
,p_name=>'P1010_ORDENCOMPRA'
,p_is_required=>true
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(87117382646254514)
,p_prompt=>'Orden Compra'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'select distinct dpdoco d, dpdoco r from f554300A@jdedtadl order by dpdoco desc'
,p_lov_display_null=>'YES'
,p_lov_null_text=>'Seleccione'
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(87117595238254516)
,p_name=>'P1010_NUMEROPAGO'
,p_is_required=>true
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(87117382646254514)
,p_prompt=>'Pago'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'select distinct dpidln d, dpidln r from f554300A@jdedtadl where dpdoco = :p1010_ordencompra order by dpidln'
,p_lov_display_null=>'YES'
,p_lov_null_text=>'Seleccione'
,p_lov_cascade_parent_items=>'P1010_ORDENCOMPRA'
,p_ajax_optimize_refresh=>'Y'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(87117678443254517)
,p_name=>'P1010_ACCION'
,p_is_required=>true
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(87117382646254514)
,p_prompt=>unistr('Acci\00F3n')
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'STATIC:Activar Pago;1'
,p_lov_display_null=>'YES'
,p_lov_null_text=>'Seleccione'
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(87118218014254523)
,p_name=>'P1010_RESPUESTA'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(87117382646254514)
,p_prompt=>'Respuesta'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_lov=>'STATIC2:Desactivar Pago;1,Habilitar Orden;2'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(87117801438254519)
,p_name=>'Ejecutar'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(87117745987254518)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(87117915646254520)
,p_event_id=>wwv_flow_imp.id(87117801438254519)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'mostrarBarra();'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(87118145466254522)
,p_event_id=>wwv_flow_imp.id(87117801438254519)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare v_aux_nm1    number;',
'v_orden   number;',
'v_pago    number;',
'v_accion  number;',
'v_log_qty    number;',
'v_log_app    varchar2(100);',
'v_log_dsc    varchar2(999);',
'begin',
'    v_orden   := :p1010_ordencompra;',
'    v_pago    := :p1010_numeropago;',
'    v_accion  := :p1010_accion;',
'',
'    v_log_app := ''apex.109.1010'';',
unistr('    v_log_dsc := ''Par\00E1metros: p1010_ordencompra: ''||v_orden||'', p1010_numeropago: ''||v_pago||'', p1010_accion: ''||v_accion;'),
'    if :p1010_accion = 1 then',
'        update f554300A@jdedtadl SET DPSTATUS = ''4'', DPAEXP = '''', DPIVD = '''', DPVINV = '''', DPFUTSTR1 = '''' ',
'        WHERE  DPDOCO = v_orden AND DPIDLN = v_pago;',
'        v_log_qty := sql%rowcount;',
'    elsif :p1010_accion = 2 then',
'        null;',
'    else',
'        null;',
'    end if;',
'',
'    if v_log_qty > 1 then',
'        :p1010_respuesta := v_log_qty||'' registros actualizados.'';',
'    elsif v_log_qty = 1 then',
'        :p1010_respuesta := v_log_qty||'' registro actualizado.'';',
'    else',
'        :p1010_respuesta := ''No hubo cambios.'';',
'    end if;',
'',
'    data.pk_commons.sp_apex_log(v_log_app,v_log_qty,v_log_dsc,null,null,null);',
'    commit;',
'end;'))
,p_attribute_02=>'P1010_ACCION,P1010_ORDENCOMPRA,P1010_NUMEROPAGO'
,p_attribute_03=>'P1010_RESPUESTA'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(87118059606254521)
,p_event_id=>wwv_flow_imp.id(87117801438254519)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'ocultarBarra();'
);
wwv_flow_imp.component_end;
end;
/
