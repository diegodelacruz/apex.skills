prompt --application/pages/page_00171
begin
--   Manifest
--     PAGE: 00171
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>109
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_page.create_page(
 p_id=>171
,p_name=>'Gestion de Viaticos'
,p_alias=>'GESTION-DE-VIATICOS'
,p_step_title=>'Gestion de Viaticos'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_page_component_map=>'02'
,p_created_on=>wwv_flow_imp.dz('20240702212733Z')
,p_last_updated_on=>wwv_flow_imp.dz('20240711134156Z')
,p_last_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(236294355699220486)
,p_plug_name=>'Gestion Viaticos'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(38290610465120145)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(37761271469106475)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(37860983999106559)
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(236336189908962614)
,p_plug_name=>'Gestion'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(38289867500120143)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_read_only_when_type=>'ITEM_IS_NOT_NULL'
,p_plug_read_only_when=>'P171_NUMEROVIATICO'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(207052155997772046)
,p_plug_name=>'Destino'
,p_parent_plug_id=>wwv_flow_imp.id(236336189908962614)
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(38289867500120143)
,p_plug_display_sequence=>20
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'TABLE'
,p_query_table=>'T_GVIA_DESTINOVIATICOS'
,p_include_rowid_column=>false
,p_is_editable=>false
,p_plug_source_type=>'NATIVE_FORM'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(236294925738220497)
,p_plug_name=>'Gestion de Viaticos'
,p_parent_plug_id=>wwv_flow_imp.id(236336189908962614)
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(38289867500120143)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'TABLE'
,p_query_table=>'T_GVIA_VIATICOS'
,p_include_rowid_column=>false
,p_is_editable=>true
,p_edit_operations=>'i:u:d'
,p_lost_update_check_type=>'VALUES'
,p_plug_source_type=>'NATIVE_FORM'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(236336801924962621)
,p_plug_name=>'Costos'
,p_parent_plug_id=>wwv_flow_imp.id(236336189908962614)
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(38289867500120143)
,p_plug_display_sequence=>30
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'TABLE'
,p_query_table=>'T_GVIA_COSTOVIATICOS'
,p_include_rowid_column=>false
,p_is_editable=>false
,p_plug_source_type=>'NATIVE_FORM'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(236336292552962615)
,p_plug_name=>'Barra de Acciones'
,p_region_template_options=>'#DEFAULT#:t-Form--stretchInputs'
,p_plug_template=>wwv_flow_imp.id(38289497777120142)
,p_plug_display_sequence=>50
,p_plug_display_point=>'REGION_POSITION_01'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(236310237472220512)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(236336292552962615)
,p_button_name=>'SAVE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860181880106559)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Apply Changes'
,p_button_position=>'BOTTOM'
,p_button_alignment=>'RIGHT'
,p_button_condition_type=>'NEVER'
,p_database_action=>'UPDATE'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(236310694390220512)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(236336292552962615)
,p_button_name=>'CREATE'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860056812106557)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'GUARDAR'
,p_button_position=>'BOTTOM'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
,p_button_condition=>'select ''x'' from t_corp_udc where id_cabecera = ''GVIA_USTMP'' and upper(id_tabla) = :app_user'
,p_button_condition_type=>'EXISTS'
,p_icon_css_classes=>'fa-save'
,p_database_action=>'INSERT'
,p_updated_on=>wwv_flow_imp.dz('20240711134156Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(207052302894772048)
,p_name=>'P171_ID'
,p_source_data_type=>'NUMBER'
,p_is_primary_key=>true
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(207052155997772046)
,p_item_source_plug_id=>wwv_flow_imp.id(207052155997772046)
,p_source=>'ID'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_protection_level=>'S'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(207052406095772049)
,p_name=>'P171_NUMEROVIATICO_1'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(207052155997772046)
,p_item_source_plug_id=>wwv_flow_imp.id(207052155997772046)
,p_source=>'NUMEROVIATICO'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(207052570611772050)
,p_name=>'P171_CODIGOORIGEN'
,p_source_data_type=>'VARCHAR2'
,p_is_required=>true
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_imp.id(236294925738220497)
,p_item_source_plug_id=>wwv_flow_imp.id(207052155997772046)
,p_item_default=>'EC'
,p_prompt=>'Origen'
,p_source=>'CODIGOORIGEN'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT DESCRIPCION, ID_TABLA ',
'FROM DP.T_GENERALDET WHERE ID_TGRALCAB =1228',
'AND id_tabla = ''EC'' ;'))
,p_cHeight=>1
,p_read_only_when=>'P171_CODIGODESTINO'
,p_read_only_when_type=>'ITEM_IS_NOT_NULL'
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(236295239144220497)
,p_name=>'P171_NUMEROVIATICO'
,p_source_data_type=>'NUMBER'
,p_is_primary_key=>true
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(236294925738220497)
,p_item_source_plug_id=>wwv_flow_imp.id(236294925738220497)
,p_source=>'NUMEROVIATICO'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_protection_level=>'S'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(236295672643220502)
,p_name=>'P171_COMPANIA'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(236294925738220497)
,p_item_source_plug_id=>wwv_flow_imp.id(236294925738220497)
,p_source=>'COMPANIA'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(236296063198220504)
,p_name=>'P171_USUARIOCREA'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(236294925738220497)
,p_item_source_plug_id=>wwv_flow_imp.id(236294925738220497)
,p_source=>'USUARIOCREA'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(236296403336220504)
,p_name=>'P171_USUARIOMODIFICA'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(236294925738220497)
,p_item_source_plug_id=>wwv_flow_imp.id(236294925738220497)
,p_source=>'USUARIOMODIFICA'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(236296838786220504)
,p_name=>'P171_FECHASOLICITUD'
,p_source_data_type=>'DATE'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(236294925738220497)
,p_item_source_plug_id=>wwv_flow_imp.id(236294925738220497)
,p_source=>'FECHASOLICITUD'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(236297216278220505)
,p_name=>'P171_FECHAAPROBACION'
,p_source_data_type=>'DATE'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(236294925738220497)
,p_item_source_plug_id=>wwv_flow_imp.id(236294925738220497)
,p_source=>'FECHAAPROBACION'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(236297666450220505)
,p_name=>'P171_FECHAPAGO'
,p_source_data_type=>'DATE'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(236294925738220497)
,p_item_source_plug_id=>wwv_flow_imp.id(236294925738220497)
,p_source=>'FECHAPAGO'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(236298071710220505)
,p_name=>'P171_FECHAINICIO'
,p_source_data_type=>'DATE'
,p_is_required=>true
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(236294925738220497)
,p_item_source_plug_id=>wwv_flow_imp.id(236294925738220497)
,p_prompt=>'Fecha Inicio'
,p_source=>'FECHAINICIO'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DATE_PICKER_APEX'
,p_cSize=>32
,p_cMaxlength=>255
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'POPUP'
,p_attribute_03=>'NONE'
,p_attribute_06=>'NONE'
,p_attribute_09=>'N'
,p_attribute_11=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(236298492962220505)
,p_name=>'P171_FECHAFIN'
,p_source_data_type=>'DATE'
,p_is_required=>true
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(236294925738220497)
,p_item_source_plug_id=>wwv_flow_imp.id(236294925738220497)
,p_prompt=>'Fecha Fin'
,p_source=>'FECHAFIN'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DATE_PICKER_APEX'
,p_cSize=>32
,p_cMaxlength=>255
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'POPUP'
,p_attribute_03=>'NONE'
,p_attribute_06=>'NONE'
,p_attribute_09=>'N'
,p_attribute_11=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(236298861068220506)
,p_name=>'P171_TIPOVIATICO'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>120
,p_item_plug_id=>wwv_flow_imp.id(236294925738220497)
,p_item_source_plug_id=>wwv_flow_imp.id(236294925738220497)
,p_item_default=>'1'
,p_source=>'TIPOVIATICO'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(236299272387220506)
,p_name=>'P171_MOTIVOVIAJE'
,p_source_data_type=>'VARCHAR2'
,p_is_required=>true
,p_item_sequence=>130
,p_item_plug_id=>wwv_flow_imp.id(236294925738220497)
,p_item_source_plug_id=>wwv_flow_imp.id(236294925738220497)
,p_prompt=>'Motivo Viaje'
,p_source=>'MOTIVOVIAJE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>60
,p_cMaxlength=>260
,p_cHeight=>4
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(236299666256220506)
,p_name=>'P171_MOTIVORECHAZO'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>150
,p_item_plug_id=>wwv_flow_imp.id(236294925738220497)
,p_item_source_plug_id=>wwv_flow_imp.id(236294925738220497)
,p_source=>'MOTIVORECHAZO'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(236300010594220506)
,p_name=>'P171_ACUERDOLEGAL'
,p_source_data_type=>'NUMBER'
,p_is_required=>true
,p_item_sequence=>260
,p_item_plug_id=>wwv_flow_imp.id(236294925738220497)
,p_item_source_plug_id=>wwv_flow_imp.id(236294925738220497)
,p_prompt=>unistr('El trabajador acepta que conoce y que fue notificado en su debido momento, de su obligaci\00F3n de justificar todos los anticipos generados a su nombre n de acuerdo a las pol\00EDticas establecidas. En el caso de incumplimiento a esta obligaci\00F3n, ser\00E1n sanci')
||'onados de acuerdo a lo estipulado en el Reglamento Interno de Trabajo debidamente aprobado por el Ministerio de Trabajo.'
,p_source=>'ACUERDOLEGAL'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SINGLE_CHECKBOX'
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'1'
,p_attribute_03=>'0'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(236300447502220506)
,p_name=>'P171_ESTADOAPROBACION'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>170
,p_item_plug_id=>wwv_flow_imp.id(236294925738220497)
,p_item_source_plug_id=>wwv_flow_imp.id(236294925738220497)
,p_source=>'ESTADOAPROBACION'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(236300826962220506)
,p_name=>'P171_ESTADO'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>180
,p_item_plug_id=>wwv_flow_imp.id(236294925738220497)
,p_item_source_plug_id=>wwv_flow_imp.id(236294925738220497)
,p_source=>'ESTADO'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(236301213254220507)
,p_name=>'P171_NUMEROBATCH'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>190
,p_item_plug_id=>wwv_flow_imp.id(236294925738220497)
,p_item_source_plug_id=>wwv_flow_imp.id(236294925738220497)
,p_source=>'NUMEROBATCH'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(236301630485220507)
,p_name=>'P171_IDFLUJO'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>200
,p_item_plug_id=>wwv_flow_imp.id(236294925738220497)
,p_item_source_plug_id=>wwv_flow_imp.id(236294925738220497)
,p_source=>'IDFLUJO'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(236302060882220507)
,p_name=>'P171_USUARIOFLUJO'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>210
,p_item_plug_id=>wwv_flow_imp.id(236294925738220497)
,p_item_source_plug_id=>wwv_flow_imp.id(236294925738220497)
,p_source=>'USUARIOFLUJO'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(236302440710220507)
,p_name=>'P171_CENTROCOSTOS'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>220
,p_item_plug_id=>wwv_flow_imp.id(236294925738220497)
,p_item_source_plug_id=>wwv_flow_imp.id(236294925738220497)
,p_source=>'CENTROCOSTOS'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(236302884426220507)
,p_name=>'P171_FECHALIQUIDACION'
,p_source_data_type=>'DATE'
,p_item_sequence=>270
,p_item_plug_id=>wwv_flow_imp.id(236294925738220497)
,p_item_source_plug_id=>wwv_flow_imp.id(236294925738220497)
,p_source=>'FECHALIQUIDACION'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(236334852109962601)
,p_name=>'P171_CODIGODESTINO'
,p_source_data_type=>'VARCHAR2'
,p_is_required=>true
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_imp.id(236294925738220497)
,p_item_source_plug_id=>wwv_flow_imp.id(207052155997772046)
,p_prompt=>'Destino'
,p_source=>'CODIGODESTINO'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT DESCRIPCION, DESCRIPCION ID',
'FROM DP.T_GENERALDET WHERE ID_TGRALCAB =1228',
'AND id_tabla != ''EC'' ;'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'SELECCIONAR'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(236334982602962602)
,p_name=>'P171_VEHICULOPROPIO'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(207052155997772046)
,p_item_source_plug_id=>wwv_flow_imp.id(207052155997772046)
,p_item_default=>'0'
,p_source=>'VEHICULOPROPIO'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(236335020794962603)
,p_name=>'P171_HOTEL'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(207052155997772046)
,p_item_source_plug_id=>wwv_flow_imp.id(207052155997772046)
,p_item_default=>'0'
,p_source=>'HOTEL'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(236335121302962604)
,p_name=>'P171_MOVILIZACIONINTERNA'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(207052155997772046)
,p_item_source_plug_id=>wwv_flow_imp.id(207052155997772046)
,p_item_default=>'0'
,p_source=>'MOVILIZACIONINTERNA'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(236335204572962605)
,p_name=>'P171_MOVILIZACIONTERRESTRE'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(207052155997772046)
,p_item_source_plug_id=>wwv_flow_imp.id(207052155997772046)
,p_item_default=>'0'
,p_source=>'MOVILIZACIONTERRESTRE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(236335301242962606)
,p_name=>'P171_DIAS'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(236294925738220497)
,p_item_source_plug_id=>wwv_flow_imp.id(207052155997772046)
,p_prompt=>unistr('D\00EDas')
,p_source=>'DIAS'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'left'
,p_attribute_04=>'decimal'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(236335413872962607)
,p_name=>'P171_MULTIDESTINODIARIO'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_imp.id(207052155997772046)
,p_item_source_plug_id=>wwv_flow_imp.id(207052155997772046)
,p_item_default=>'0'
,p_source=>'MULTIDESTINODIARIO'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(236335570790962608)
,p_name=>'P171_DESTINOINTERMEDIO'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_imp.id(207052155997772046)
,p_item_source_plug_id=>wwv_flow_imp.id(207052155997772046)
,p_item_default=>'[]'
,p_source=>'DESTINOINTERMEDIO'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(236335600153962609)
,p_name=>'P171_ESTADO_1'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>120
,p_item_plug_id=>wwv_flow_imp.id(207052155997772046)
,p_item_source_plug_id=>wwv_flow_imp.id(207052155997772046)
,p_item_default=>'1'
,p_source=>'ESTADO'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(236337014546962623)
,p_name=>'P171_ID_1'
,p_source_data_type=>'NUMBER'
,p_is_primary_key=>true
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(236336801924962621)
,p_item_source_plug_id=>wwv_flow_imp.id(236336801924962621)
,p_source=>'ID'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_protection_level=>'S'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(236337163577962624)
,p_name=>'P171_NUMEROVIATICO_2'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(236336801924962621)
,p_item_source_plug_id=>wwv_flow_imp.id(236336801924962621)
,p_source=>'NUMEROVIATICO'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(236337268604962625)
,p_name=>'P171_COMPANIA_1'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(236336801924962621)
,p_item_source_plug_id=>wwv_flow_imp.id(236336801924962621)
,p_source=>'COMPANIA'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(236337388616962626)
,p_name=>'P171_CODIGOORIGEN_1'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(236336801924962621)
,p_item_source_plug_id=>wwv_flow_imp.id(236336801924962621)
,p_source=>'CODIGOORIGEN'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(236337434777962627)
,p_name=>'P171_CODIGODESTINO_1'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(236336801924962621)
,p_item_source_plug_id=>wwv_flow_imp.id(236336801924962621)
,p_source=>'CODIGODESTINO'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(236337502849962628)
,p_name=>'P171_MONEDA'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(236336801924962621)
,p_item_source_plug_id=>wwv_flow_imp.id(236336801924962621)
,p_item_default=>'USD'
,p_source=>'MONEDA'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(236337603541962629)
,p_name=>'P171_DIAS_1'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(236336801924962621)
,p_item_source_plug_id=>wwv_flow_imp.id(236336801924962621)
,p_source=>'DIAS'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(236337782830962630)
,p_name=>'P171_VALOR'
,p_source_data_type=>'NUMBER'
,p_is_required=>true
,p_item_sequence=>250
,p_item_plug_id=>wwv_flow_imp.id(236294925738220497)
,p_item_source_plug_id=>wwv_flow_imp.id(236336801924962621)
,p_prompt=>'Valor'
,p_format_mask=>'999G999G999G999G990D00'
,p_source=>'VALOR'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'left'
,p_attribute_04=>'decimal'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(236337859449962631)
,p_name=>'P171_SUBTOTAL'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(236336801924962621)
,p_item_source_plug_id=>wwv_flow_imp.id(236336801924962621)
,p_item_default=>'0'
,p_source=>'SUBTOTAL'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(236337993447962632)
,p_name=>'P171_DISTANCIA'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_imp.id(236336801924962621)
,p_item_source_plug_id=>wwv_flow_imp.id(236336801924962621)
,p_item_default=>'1'
,p_source=>'DISTANCIA'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(236338023395962633)
,p_name=>'P171_TIPOTARIFA'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_imp.id(236336801924962621)
,p_item_source_plug_id=>wwv_flow_imp.id(236336801924962621)
,p_item_default=>'0'
,p_source=>'TIPOTARIFA'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(238263403220347405)
,p_name=>'P171_CENTROCOSTOSTEMP'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>230
,p_item_plug_id=>wwv_flow_imp.id(236294925738220497)
,p_item_source_plug_id=>wwv_flow_imp.id(236294925738220497)
,p_prompt=>'Centro Costos'
,p_source=>'CENTROCOSTOSTEMP'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select distinct r.categoria1, r.tipo1',
'from t_admi_ruta r inner join t_corp_udc u on (u.id_cabecera = ''GVIA_RTMP'' and r.tipo1 = u.id_tabla and u.activo = ''1'')',
'where r.codigomodulo = ''GVIA'' and tipo2 = ''G'''))
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_updated_on=>wwv_flow_imp.dz('20240702213153Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(236338747244962640)
,p_validation_name=>'Acuerdo'
,p_validation_sequence=>10
,p_validation=>':P171_ACUERDOLEGAL = 1'
,p_validation2=>'PLSQL'
,p_validation_type=>'EXPRESSION'
,p_error_message=>'Se debe aceptar el acuerdo legal'
,p_when_button_pressed=>wwv_flow_imp.id(236310694390220512)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(236335780480962610)
,p_name=>'GUARDAR'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(236310694390220512)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(236338690935962639)
,p_event_id=>wwv_flow_imp.id(236335780480962610)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_ENABLE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P171_DIAS'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(236335900764962612)
,p_event_id=>wwv_flow_imp.id(236335780480962610)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare ',
'    lv_numero number ;',
'BEGIN',
'   ',
'    --Asigna el codigo',
'    select SQ_GVIA_VIATICOS_S1.nextval INTO lv_numero from  DUAL ;',
'    :P171_NUMEROVIATICO_1 := lv_numero ;',
'    :P171_NUMEROVIATICO := lv_numero ;',
'    :P171_NUMEROVIATICO_2 := lv_numero ;',
'    ',
'    :P171_CODIGOORIGEN_1 := :P171_CODIGOORIGEN;',
'    :P171_CODIGODESTINO_1 := :P171_CODIGODESTINO ;',
'    :P171_SUBTOTAL := :P171_VALOR ;',
'    ',
'END;'))
,p_attribute_02=>'P171_CODIGOORIGEN,P171_CODIGODESTINO,P171_VALOR'
,p_attribute_03=>'P171_NUMEROVIATICO,P171_NUMEROVIATICO_1,P171_CODIGOORIGEN_1,P171_NUMEROVIATICO_2,P171_CODIGODESTINO_1,P171_SUBTOTAL'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(236336385673962616)
,p_event_id=>wwv_flow_imp.id(236335780480962610)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_01=>'CREATE'
,p_attribute_02=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(236336421897962617)
,p_name=>'ChangeFecha'
,p_event_sequence=>20
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P171_FECHAINICIO,P171_FECHAFIN'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(236338535742962638)
,p_event_id=>wwv_flow_imp.id(236336421897962617)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_ENABLE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P171_DIAS,P171_DIAS_1'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(236336557237962618)
,p_event_id=>wwv_flow_imp.id(236336421897962617)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    lv_fechainicio date;',
'    lv_fechafin date;',
'begin',
'    if :P171_FECHAINICIO is not null and :P171_FECHAFIN is not null then',
'        :P171_DIAS := 1  + (TO_DATE(:P171_FECHAFIN) - TO_DATE(:P171_FECHAINICIO)) ;',
'        :P171_DIAS_1 := 1  + (TO_DATE(:P171_FECHAFIN) - TO_DATE(:P171_FECHAINICIO)) ;',
'    end if ;',
'end;'))
,p_attribute_02=>'P171_FECHAFIN,P171_FECHAINICIO'
,p_attribute_03=>'P171_DIAS,P171_DIAS_1'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(236338455125962637)
,p_event_id=>wwv_flow_imp.id(236336421897962617)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_DISABLE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P171_DIAS'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(236336002886962613)
,p_process_sequence=>10
,p_process_point=>'AFTER_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Datos'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE ',
'    v_ccosto Varchar2(10) ;',
'BEGIN',
'    SELECT CODCENTROCOSTO',
'    INTO v_ccosto',
'    FROM VT_CORP_USUARIO WHERE NOMBREUSUARIO = :APP_USER ;',
'',
'    :P171_CENTROCOSTOS := v_ccosto;',
'    :P171_CENTROCOSTOSTEMP := v_ccosto ;',
'    :P171_COMPANIA := :G_COMPANIA ;',
'    :P171_COMPANIA_1 := :G_COMPANIA ;',
'    ',
'    :P171_USUARIOCREA := :APP_USER ;',
'    :P171_USUARIOMODIFICA := :APP_USER ;',
'    :P171_FECHASOLICITUD := SYSDATE ;',
'    :P171_ESTADOAPROBACION := ''G'';',
'    :P171_ESTADO := 1 ;',
' ',
'    ',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>236336002886962613
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(236311811041220515)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_region_id=>wwv_flow_imp.id(236294925738220497)
,p_process_type=>'NATIVE_FORM_DML'
,p_process_name=>'Process form Gestion de Viaticos'
,p_attribute_01=>'REGION_SOURCE'
,p_attribute_05=>'Y'
,p_attribute_06=>'Y'
,p_attribute_08=>'N'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>236311811041220515
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(236336621979962619)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_region_id=>wwv_flow_imp.id(207052155997772046)
,p_process_type=>'NATIVE_FORM_DML'
,p_process_name=>'Process form Destinos'
,p_attribute_01=>'REGION_SOURCE'
,p_attribute_05=>'Y'
,p_attribute_06=>'Y'
,p_attribute_08=>'Y'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>236336621979962619
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(236338132861962634)
,p_process_sequence=>30
,p_process_point=>'AFTER_SUBMIT'
,p_region_id=>wwv_flow_imp.id(236336801924962621)
,p_process_type=>'NATIVE_FORM_DML'
,p_process_name=>'Process form costos'
,p_attribute_01=>'REGION_SOURCE'
,p_attribute_05=>'Y'
,p_attribute_06=>'Y'
,p_attribute_08=>'Y'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>236338132861962634
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(236338234223962635)
,p_process_sequence=>40
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'EnviarRuta'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    v_resultado number;',
'begin    ',
'    DATA.PK_CORP_FLUJOAPROBACION.SP_FLUJOENVIAR(',
'                p_id=> :P171_NUMEROVIATICO,',
'                p_objeto=> ''Viaticos'',',
'                p_objetodescripcion=>''Viatico Nro.: ''||:P171_NUMEROVIATICO ,',
'                p_usuario=> :APP_USER,',
'                p_modulo=>''GVIA'',',
'                p_compania=>:G_COMPANIA,',
'                P_CODIGOPAGINA => ''GVIAMOD07'',',
'				P_TIPO1=> :P171_CENTROCOSTOSTEMP,',
'                P_TIPO2=> ''G'',',
'                p_exito =>  v_resultado); ',
'',
'	IF(v_resultado=0) THEN',
'	    apex_error.add_error ( p_message          => data.PK_CORP_FLUJOAPROBACION.G_MENSAJE,',
'                                p_display_location =>apex_error.c_inline_in_notification );',
'    else ',
'',
'        update t_gvia_viaticos ',
'        set (idflujo,usuarioflujo)=  ( SELECT id, usuarioactual ',
'                                       FROM t_flujo_aprobacion_cab ',
'                                       WHERE ESTADO=''EN_PROCESO'' ',
'                                       and  ENTIDAD_CLASE=''Viaticos'' ',
'                                       and ENTIDAD_ID = :P171_NUMEROVIATICO ',
'                                       and  CODMODULO=''GVIA'' )',
'       where exists (SELECT 1 FROM t_flujo_aprobacion_cab ',
'                     WHERE ESTADO=''EN_PROCESO'' and  ENTIDAD_CLASE=''Viaticos'' ',
'                     and ENTIDAD_ID = :P171_NUMEROVIATICO and  CODMODULO=''GVIA'' )',
'        and  NUMEROVIATICO = :P171_NUMEROVIATICO ;',
'',
'        apex_application.g_print_success_message :=''Se envio a ruta con exito ''||:P171_NUMEROVIATICO;',
'',
'    END IF; ',
'	',
'end ;    '))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>236338234223962635
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(236311473641220514)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_region_id=>wwv_flow_imp.id(236294925738220497)
,p_process_type=>'NATIVE_FORM_INIT'
,p_process_name=>'Initialize form Gestion de Viaticos'
,p_attribute_03=>'1'
,p_internal_uid=>236311473641220514
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(236336775800962620)
,p_process_sequence=>20
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'DatoDestino'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'    if :P171_NUMEROVIATICO is not null then',
'        select id into :P171_ID from t_gvia_destinoviaticos where numeroviatico=:P171_NUMEROVIATICO;',
'    end if;',
'end ;        '))
,p_process_clob_language=>'PLSQL'
,p_process_when_type=>'NEVER'
,p_internal_uid=>236336775800962620
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(207052201695772047)
,p_process_sequence=>30
,p_process_point=>'BEFORE_HEADER'
,p_region_id=>wwv_flow_imp.id(207052155997772046)
,p_process_type=>'NATIVE_FORM_INIT'
,p_process_name=>'Initialize form Destino'
,p_internal_uid=>207052201695772047
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(236336937134962622)
,p_process_sequence=>40
,p_process_point=>'BEFORE_HEADER'
,p_region_id=>wwv_flow_imp.id(236336801924962621)
,p_process_type=>'NATIVE_FORM_INIT'
,p_process_name=>'Initialize formCosto'
,p_internal_uid=>236336937134962622
);
wwv_flow_imp.component_end;
end;
/
