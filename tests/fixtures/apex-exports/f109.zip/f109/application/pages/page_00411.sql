prompt --application/pages/page_00411
begin
--   Manifest
--     PAGE: 00411
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>109
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_page.create_page(
 p_id=>411
,p_name=>'Dlg Agregar DE'
,p_alias=>'DLG-AGREGAR-DE'
,p_page_mode=>'MODAL'
,p_step_title=>unistr('Descargar Documento Electr\00F3nico desde SRI')
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'16'
,p_created_on=>wwv_flow_imp.dz('20241014135801Z')
,p_last_updated_on=>wwv_flow_imp.dz('20240920190036Z')
,p_last_updated_by=>'JASANZA'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(300497798814195442)
,p_plug_name=>'Documento Electronico'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(38289867500120143)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(300498081666195445)
,p_plug_name=>'Botones'
,p_parent_plug_id=>wwv_flow_imp.id(300497798814195442)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(38290276266120143)
,p_plug_display_sequence=>30
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(300497947058195444)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(300498081666195445)
,p_button_name=>'OBTENER'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860181880106559)
,p_button_image_alt=>'Obtener'
,p_button_alignment=>'RIGHT'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(314311590875891910)
,p_branch_name=>'Ir a pag 410'
,p_branch_action=>'f?p=&APP_ID.:412:&SESSION.::&DEBUG.::P412_CLAVEACCESO:&P411_CLAVEACCESO.&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_sequence=>10
,p_branch_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_branch_condition=>'P411_ERROR'
,p_branch_condition_text=>'1'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(300497853871195443)
,p_name=>'P411_CLAVEACCESO'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(300497798814195442)
,p_prompt=>'Clave Acceso'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(314311128893891906)
,p_name=>'P411_ERROR'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(300497798814195442)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(312913156359582784)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'CARGARDOCUMENTO'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare ',
'V_respuesta clob;',
'',
'V_TIPO varchar2(2);',
'V_NTIPO number;',
'',
'begin',
'    :P411_ERROR := 0 ;',
'    V_TIPO:=SUBSTR(:P411_CLAVEACCESO,9,2);',
'    if v_tipo is not null then',
'        V_NTIPO :=   case V_TIPO ',
'                    when ''01'' then 1 --Factura ',
unistr('                    when ''04'' then 2 --Nota de Cr\00E9dito'),
unistr('                    when ''07'' then 4 --Comprobante de Retenci\00F3n'),
'                else 0 end;     ',
'        PK_FINANZAS.SP_DOCELECTRONICO( P_COMPANIA => :G_COMPANIA,',
'                                        P_USUARIO => :APP_USER,',
'                                        P_CLAVEACCESO => :P411_CLAVEACCESO,',
'                                        P_TIPOREVISION => V_NTIPO,',
'                                        P_EXITO => :P411_ERROR,',
'                                        P_RESPUESTA => V_respuesta',
'                                      );       ',
'        --DBMS_OUTPUT.PUT_LINE(V_respuesta);',
'        if (:P411_ERROR = 1 )then',
'            apex_application.g_print_success_message :=V_respuesta;',
'            --:P411_CLAVEACCESO:=null;',
'        ELSE',
'            --DBMS_OUTPUT.PUT_LINE(V_respuesta);',
'            :P411_ERROR := 0 ;',
'            apex_error.add_error (p_message          => V_respuesta,',
'            p_display_location =>apex_error.c_inline_in_notification ,',
'            p_page_item_name   => ''P411_CLAVEACCESO''); ',
'        end if;',
'    end if;    ',
' end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(300497947058195444)
,p_internal_uid=>312913156359582784
);
wwv_flow_imp.component_end;
end;
/
