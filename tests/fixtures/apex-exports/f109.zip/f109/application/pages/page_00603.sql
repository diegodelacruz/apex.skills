prompt --application/pages/page_00603
begin
--   Manifest
--     PAGE: 00603
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>109
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_page.create_page(
 p_id=>603
,p_name=>'Control - Cierre'
,p_alias=>'CONTROL-CIERRE'
,p_page_mode=>'MODAL'
,p_step_title=>'Control - Cierre'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_dialog_width=>'80%'
,p_protection_level=>'C'
,p_browser_cache=>'N'
,p_page_component_map=>'18'
,p_last_updated_on=>wwv_flow_imp.dz('20260604195904Z')
,p_last_updated_by=>'JBALCAZAR'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(369551547832034092)
,p_plug_name=>unistr('Par\00E1metros')
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_region_attributes=>'style="display:none"'
,p_plug_template=>wwv_flow_imp.id(38289867500120143)
,p_plug_display_sequence=>180
,p_location=>null
,p_ai_enabled=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(369551818821034094)
,p_plug_name=>'Ventas'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(38289867500120143)
,p_plug_display_sequence=>10
,p_location=>null
,p_plug_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_plug_display_when_condition=>'P603_MODULO'
,p_plug_display_when_cond2=>'DCO250'
,p_ai_enabled=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(424608740347923169)
,p_plug_name=>unistr('\00D3rdenes sin contabilizar')
,p_parent_plug_id=>wwv_flow_imp.id(369551818821034094)
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(112813843178917343)
,p_plug_display_sequence=>20
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'WITH TIPO_DOCUMENTO AS (',
'    SELECT TIPO_DOCUMENTO',
'    FROM DATA.T_FINZ_DOCUMENTOS',
'    WHERE ACTIVO = ''S''',
'    AND ID_MODULO IN (',
'        SELECT ID_MODULO  FROM T_FINZ_RESPONSABLECIERRE WHERE CODIGO_MODULO =  ''DCO250'' AND ACTIVO = ''S''',
'    ) ',
')',
'SELECT DISTINCT',
'       SDDOCO AS DOCUMENTO,',
'       SDDCTO AS TIPO,',
'       SDAN8  AS CLIENTE,',
'       TRIM(ab.ABALPH) AS NOMBRE_CLIENTE,',
'       SDNXTR AS ESTADO,',
'       TO_DATE(TO_CHAR(NULLIF(so.SDTRDJ, 0) + 1900000), ''YYYYDDD'') AS FECHA_DOCUMENTO,',
'       TO_DATE(TO_CHAR(NULLIF(so.SDUPMJ, 0) + 1900000), ''YYYYDDD'') AS FECHA_ACTUALIZACION',
'FROM proddta.F4211@jdedtadl so',
'JOIN TIPO_DOCUMENTO d',
'     ON d.TIPO_DOCUMENTO = so.SDDCTO',
'JOIN proddta.F0101@jdedtadl ab ON so.SDAN8 = ab.ABAN8',
'WHERE so.SDNXTR > 560',
'  AND so.SDNXTR < 620',
'',
'  -- Fecha del mes actual',
'  AND so.SDTRDJ BETWEEN :P603_INICIO_MES_JDE AND :P603_FIN_MES_JDE',
'',
unistr('  -- Demora mayor a 2 d\00EDas entre documento y actualizaci\00F3n'),
'  AND (NULLIF(so.SDUPMJ,0) - NULLIF(so.SDTRDJ,0)) >= 2'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_display_condition_type=>'EXPRESSION'
,p_plug_display_when_condition=>':P603_ID_REGION = 1'
,p_plug_display_when_cond2=>'PLSQL'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(424608881694923170)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'MFERRIN'
,p_internal_uid=>424608881694923170
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(424608993028923171)
,p_db_column_name=>'DOCUMENTO'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Documento'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(424609113247923172)
,p_db_column_name=>'TIPO'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Tipo'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(424609166492923173)
,p_db_column_name=>'CLIENTE'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Cliente'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(425333514376193279)
,p_db_column_name=>'NOMBRE_CLIENTE'
,p_display_order=>40
,p_column_identifier=>'G'
,p_column_label=>'Nombre Cliente'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(424609312715923174)
,p_db_column_name=>'ESTADO'
,p_display_order=>50
,p_column_identifier=>'D'
,p_column_label=>'Estado'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(424609348610923175)
,p_db_column_name=>'FECHA_DOCUMENTO'
,p_display_order=>60
,p_column_identifier=>'E'
,p_column_label=>'Fecha Documento'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(424609486226923176)
,p_db_column_name=>'FECHA_ACTUALIZACION'
,p_display_order=>70
,p_column_identifier=>'F'
,p_column_label=>'Fecha Actualizacion'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(425236706308721320)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'1803061'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'DOCUMENTO:TIPO:CLIENTE:NOMBRE_CLIENTE:ESTADO:FECHA_DOCUMENTO:FECHA_ACTUALIZACION:'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(424609853327923180)
,p_plug_name=>unistr('\00D3rdenes ingresadas \00FAltimo d\00EDa')
,p_parent_plug_id=>wwv_flow_imp.id(369551818821034094)
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(112813843178917343)
,p_plug_display_sequence=>50
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'WITH TIPO_DOCUMENTO_SDDCTO AS (',
'    SELECT TIPO_DOCUMENTO',
'    FROM DATA.T_FINZ_DOCUMENTOS',
'    WHERE ACTIVO = ''S''',
'    AND ID_MODULO IN (',
'        SELECT ID_MODULO  FROM T_FINZ_RESPONSABLECIERRE WHERE CODIGO_MODULO =  ''DCO250'' AND ACTIVO = ''S''',
'    ) ',
')',
'SELECT DISTINCT',
'       SDDOCO AS DOCUMENTO,',
'       SDDCTO AS TIPO,',
'       SDAN8  AS CLIENTE,',
'       TRIM(ab.ABALPH) AS NOMBRE_CLIENTE,',
'       SDNXTR AS ESTADO,',
'       TO_DATE(TO_CHAR(NULLIF(so.SDTRDJ, 0) + 1900000), ''YYYYDDD'') AS FECHA_DOCUMENTO,',
'       TO_DATE(TO_CHAR(NULLIF(so.SDUPMJ, 0) + 1900000), ''YYYYDDD'') AS FECHA_ACTUALIZACION',
'FROM proddta.F4211@jdedtadl so',
'JOIN proddta.F0101@jdedtadl ab ON so.SDAN8 = ab.ABAN8',
'WHERE so.SDNXTR > 520',
'  AND so.SDNXTR < 620',
'',
'  AND so.SDDCTO IN (SELECT TIPO_DOCUMENTO FROM TIPO_DOCUMENTO_SDDCTO)',
'',
'  AND (',
unistr('      -- A. \00DAltimo d\00EDa del mes actual'),
'      so.SDTRDJ = :P603_FIN_MES_JDE',
'      ',
'      OR ',
'      ',
unistr('      -- B. \00DAltimo d\00EDa del mes anterior (SOLO si estamos en los primeros 5 D\00CDAS H\00C1BILES)'),
'      (',
'        :P603_EN_VENT_ANT = 1',
'        AND',
'        so.SDTRDJ = :P603_FIN_MES_ANTERIOR_JDE',
'      )',
'  );'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_display_condition_type=>'EXPRESSION'
,p_plug_display_when_condition=>':P603_ID_REGION = 2'
,p_plug_display_when_cond2=>'PLSQL'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(424610705961923188)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'MFERRIN'
,p_internal_uid=>424610705961923188
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(424610737823923189)
,p_db_column_name=>'DOCUMENTO'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Documento'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(424610871070923190)
,p_db_column_name=>'TIPO'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Tipo'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(424610926961923191)
,p_db_column_name=>'CLIENTE'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Cliente'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(425333360034193278)
,p_db_column_name=>'NOMBRE_CLIENTE'
,p_display_order=>40
,p_column_identifier=>'G'
,p_column_label=>'Nombre Cliente'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(424611086403923192)
,p_db_column_name=>'ESTADO'
,p_display_order=>50
,p_column_identifier=>'D'
,p_column_label=>'Estado'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(424611183500923193)
,p_db_column_name=>'FECHA_DOCUMENTO'
,p_display_order=>60
,p_column_identifier=>'E'
,p_column_label=>'Fecha Documento'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(424611286680923194)
,p_db_column_name=>'FECHA_ACTUALIZACION'
,p_display_order=>70
,p_column_identifier=>'F'
,p_column_label=>'Fecha Actualizacion'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(425258276058850292)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'1803277'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'DOCUMENTO:TIPO:CLIENTE:NOMBRE_CLIENTE:ESTADO:FECHA_DOCUMENTO:FECHA_ACTUALIZACION:'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(424609930680923181)
,p_plug_name=>unistr('\00D3rdenes con diferencia en Kardex')
,p_parent_plug_id=>wwv_flow_imp.id(369551818821034094)
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(112813843178917343)
,p_plug_display_sequence=>60
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'WITH TIPO_DOCUMENTO_SDDCTO AS (',
'    SELECT TIPO_DOCUMENTO',
'    FROM DATA.T_FINZ_DOCUMENTOS',
'    WHERE ACTIVO = ''S''',
'    AND ID_MODULO IN (',
'        SELECT ID_MODULO  FROM T_FINZ_RESPONSABLECIERRE WHERE CODIGO_MODULO =  ''DCO250'' AND ACTIVO = ''S''',
'    ) ',
')',
'SELECT DISTINCT',
'       so.SDDOCO AS DOCUMENTO,',
'       so.SDDCTO AS TIPO,',
'       so.SDAN8  AS CLIENTE,',
'       TRIM(ab.ABALPH) AS NOMBRE_CLIENTE,',
'       so.SDNXTR AS ESTADO,',
'       TO_DATE(TO_CHAR(NULLIF(so.SDTRDJ, 0) + 1900000), ''YYYYDDD'') AS FECHA_DOCUMENTO,',
'       TO_DATE(TO_CHAR(NULLIF(so.SDUPMJ, 0) + 1900000), ''YYYYDDD'') AS FECHA_ACTUALIZACION',
'FROM proddta.F4211@jdedtadl so',
'JOIN proddta.F0101@jdedtadl ab ON so.SDAN8 = ab.ABAN8',
'WHERE so.SDNXTR > 560',
'  AND so.SDNXTR < 620',
'',
'  AND so.SDDCTO IN (SELECT TIPO_DOCUMENTO FROM TIPO_DOCUMENTO_SDDCTO)',
'  ',
'  -- FECHA_DOCUMENTO (SDTRDJ) solo del mes actual',
'  AND (',
'    (so.SDTRDJ BETWEEN :P603_INICIO_MES_JDE AND :P603_FIN_MES_JDE AND :P603_EN_VENT_ANT = 0)',
'    OR ',
'    (so.SDTRDJ BETWEEN :P603_INICIO_MES_ANTERIOR_JDE AND :P603_FIN_MES_ANTERIOR_JDE AND :P603_EN_VENT_ANT = 1)',
'  )',
'  ',
unistr('  -- Condici\00F3n F4111: existe movimiento con misma llave pero cantidad distinta'),
'  AND EXISTS (',
'        SELECT 1',
'        FROM proddta.F4111@jdedtadl il',
'        WHERE il.ILKCO = ''00001''',
'          AND il.ILLITM = so.SDLITM',
'          AND il.ILMCU  = so.SDMCU',
'          AND il.ILDCTO = so.SDDCTO',
'          AND il.ILDOCO = so.SDDOCO',
'          AND so.SDSOQS <> il.ILTRQT',
'  );'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_display_condition_type=>'EXPRESSION'
,p_plug_display_when_condition=>':P603_ID_REGION = 3'
,p_plug_display_when_cond2=>'PLSQL'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
,p_ai_enabled=>false
,p_updated_on=>wwv_flow_imp.dz('20260513174558Z')
,p_updated_by=>'JBALCAZAR'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(424611369208923195)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'MFERRIN'
,p_internal_uid=>424611369208923195
,p_updated_on=>wwv_flow_imp.dz('20260513174558Z')
,p_updated_by=>'JBALCAZAR'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(424611482366923196)
,p_db_column_name=>'DOCUMENTO'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Documento'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(424611576066923197)
,p_db_column_name=>'TIPO'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Tipo'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(424611674874923198)
,p_db_column_name=>'CLIENTE'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Cliente'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(425333312160193277)
,p_db_column_name=>'NOMBRE_CLIENTE'
,p_display_order=>40
,p_column_identifier=>'G'
,p_column_label=>'Nombre Cliente'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(424611791408923199)
,p_db_column_name=>'ESTADO'
,p_display_order=>50
,p_column_identifier=>'D'
,p_column_label=>'Estado'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(424611870078923200)
,p_db_column_name=>'FECHA_DOCUMENTO'
,p_display_order=>60
,p_column_identifier=>'E'
,p_column_label=>'Fecha Documento'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(424611946376923201)
,p_db_column_name=>'FECHA_ACTUALIZACION'
,p_display_order=>70
,p_column_identifier=>'F'
,p_column_label=>'Fecha Actualizacion'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(425263853666871009)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'1803333'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'DOCUMENTO:TIPO:CLIENTE:NOMBRE_CLIENTE:ESTADO:FECHA_DOCUMENTO:FECHA_ACTUALIZACION:'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(424610098541923182)
,p_plug_name=>unistr('\00D3rdenes ingresadas m\00E1s de dos d\00EDas')
,p_parent_plug_id=>wwv_flow_imp.id(369551818821034094)
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(112813843178917343)
,p_plug_display_sequence=>70
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'WITH TIPO_DOCUMENTO_SDDCTO AS (',
'    SELECT TIPO_DOCUMENTO',
'    FROM DATA.T_FINZ_DOCUMENTOS',
'    WHERE ACTIVO = ''S''',
'    AND ID_MODULO IN (',
'        SELECT ID_MODULO  ',
'        FROM T_FINZ_RESPONSABLECIERRE ',
'        WHERE CODIGO_MODULO = ''DCO250'' ',
'        AND ACTIVO = ''S''',
'    ) ',
')',
'SELECT DISTINCT',
'       so.SDDOCO AS DOCUMENTO,',
'       so.SDDCTO AS TIPO,',
'       so.SDAN8  AS CLIENTE,',
'       TRIM(ab.ABALPH) AS NOMBRE_CLIENTE,',
'       so.SDNXTR AS ESTADO,',
'       TO_DATE(TO_CHAR(NULLIF(so.SDTRDJ, 0) + 1900000), ''YYYYDDD'') AS FECHA_DOCUMENTO,',
'       TO_DATE(TO_CHAR(NULLIF(so.SDUPMJ, 0) + 1900000), ''YYYYDDD'') AS FECHA_ACTUALIZACION',
'FROM proddta.F4211@jdedtadl so',
'JOIN proddta.F0101@jdedtadl ab ON so.SDAN8 = ab.ABAN8',
'WHERE so.SDNXTR = 560',
'  AND so.SDDCTO IN (SELECT TIPO_DOCUMENTO FROM TIPO_DOCUMENTO_SDDCTO)',
'  ',
'  -- Si no ha cambiado de estado',
'  AND so.SDTRDJ = so.SDUPMJ',
'',
unistr('  -- L\00D3GICA DE VISIBILIDAD DE MESES (Qu\00E9 meses puedo ver)'),
'  AND (',
'      -- Escenario A: Siempre traemos los documentos del MES ACTUAL',
'      (:P603_EN_VENT_ANT = 0 AND so.SDTRDJ BETWEEN :P603_INICIO_MES_JDE AND :P603_FIN_MES_JDE)',
'      OR ',
unistr('      -- Escenario B: Traemos TODO el MES ANTERIOR, SOLO si han pasado 5 d\00EDas h\00E1biles o menos'),
'      (:P603_EN_VENT_ANT = 1 AND so.SDTRDJ BETWEEN :P603_INICIO_MES_ANTERIOR_JDE AND :P603_FIN_MES_ANTERIOR_JDE)',
'  )',
'  ',
unistr('  -- REGLA DE ANTIG\00DCEDAD: Que hayan pasado al menos 2 d\00EDas calendario desde su creaci\00F3n'),
'  AND so.SDTRDJ <= TO_NUMBER(TO_CHAR(TRUNC(SYSDATE) - 2, ''YYYYDDD'')) - 1900000;'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_display_condition_type=>'EXPRESSION'
,p_plug_display_when_condition=>':P603_ID_REGION = 4'
,p_plug_display_when_cond2=>'PLSQL'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
,p_ai_enabled=>false
,p_updated_on=>wwv_flow_imp.dz('20260603193947Z')
,p_updated_by=>'JBALCAZAR'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(424612078559923202)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'TOP_AND_BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'MFERRIN'
,p_internal_uid=>424612078559923202
,p_updated_on=>wwv_flow_imp.dz('20260603193947Z')
,p_updated_by=>'JBALCAZAR'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(424612168648923203)
,p_db_column_name=>'DOCUMENTO'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Documento'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(424612263903923204)
,p_db_column_name=>'TIPO'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Tipo'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(424612368021923205)
,p_db_column_name=>'CLIENTE'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Cliente'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(425333182657193276)
,p_db_column_name=>'NOMBRE_CLIENTE'
,p_display_order=>40
,p_column_identifier=>'G'
,p_column_label=>'Nombre Cliente'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(424612482447923206)
,p_db_column_name=>'ESTADO'
,p_display_order=>50
,p_column_identifier=>'D'
,p_column_label=>'Estado'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(424612608928923207)
,p_db_column_name=>'FECHA_DOCUMENTO'
,p_display_order=>60
,p_column_identifier=>'E'
,p_column_label=>'Fecha Documento'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(424612667497923208)
,p_db_column_name=>'FECHA_ACTUALIZACION'
,p_display_order=>70
,p_column_identifier=>'F'
,p_column_label=>unistr('Fecha Actualizaci\00F3n')
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(425267354855881633)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'1803368'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'DOCUMENTO:TIPO:CLIENTE:NOMBRE_CLIENTE:ESTADO:FECHA_DOCUMENTO:FECHA_ACTUALIZACION:'
,p_sort_column_1=>'DOCUMENTO'
,p_sort_direction_1=>'ASC'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(369551842629034095)
,p_plug_name=>'Compras'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(38289867500120143)
,p_plug_display_sequence=>20
,p_location=>null
,p_plug_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_plug_display_when_condition=>'P603_MODULO'
,p_plug_display_when_cond2=>'DOP356'
,p_ai_enabled=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(369551967812034096)
,p_plug_name=>unistr('\00D3RDENES PENDIENTES DE RECEPCIONAR')
,p_parent_plug_id=>wwv_flow_imp.id(369551842629034095)
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(112813843178917343)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'WITH TIPO_DOCUMENTO AS (',
'    SELECT /*+ MATERIALIZE */ TIPO_DOCUMENTO',
'    FROM DATA.T_FINZ_DOCUMENTOS',
'    WHERE ACTIVO = ''S''',
'    AND ID_MODULO IN (',
'        SELECT ID_MODULO  FROM T_FINZ_RESPONSABLECIERRE WHERE CODIGO_MODULO =  ''DOP356'' AND ACTIVO = ''S''',
'    ) ',
')',
'SELECT /*+ DRIVING_SITE(so) LEADING(td so ab) USE_NL(so ab) */',
'       DISTINCT',
'       PDDCTO AS TIPO,',
'       PDDOCO AS DOCUMENTO,',
'       PDAN8  AS CLIENTE,',
'       TRIM(ab.ABALPH) AS NOMBRE_CLIENTE,',
'       PDNXTR AS ESTADO,',
'       TO_DATE(TO_CHAR(NULLIF(so.PDTRDJ, 0) + 1900000), ''YYYYDDD'') AS FECHA_DOCUMENTO,',
'       TO_DATE(TO_CHAR(NULLIF(so.PDPDDJ, 0) + 1900000), ''YYYYDDD'') AS FECHA_ENTREGA',
'FROM TIPO_DOCUMENTO td',
'JOIN proddta.F4311@jdedtadl so ON  so.PDDCTO = td.TIPO_DOCUMENTO',
'JOIN proddta.F0101@jdedtadl ab ON so.PDAN8 = ab.ABAN8',
'WHERE so.PDNXTR < 999',
'',
'  AND so.PDDCTO IN (SELECT TIPO_DOCUMENTO FROM TIPO_DOCUMENTO)',
'',
'  AND so.PDPDDJ BETWEEN',
'      GREATEST(',
unistr('          -- 1 de enero del a\00F1o actual'),
'          TO_NUMBER(TO_CHAR(SYSDATE,''YYYY'')||''000'') - 1900000,',
unistr('          -- Primer d\00EDa del mes anterior'),
'          :P603_INICIO_MES_ANTERIOR_JDE',
'      )',
'      AND :P603_HOY_JDE',
'',
'  AND so.PDADDJ = 0'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_display_condition_type=>'EXPRESSION'
,p_plug_display_when_condition=>':P603_ID_REGION = 1'
,p_plug_display_when_cond2=>'PLSQL'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(369552072322034097)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'TOP_AND_BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'MFERRIN'
,p_internal_uid=>369552072322034097
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(369552145385034098)
,p_db_column_name=>'DOCUMENTO'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Documento'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(369552249326034099)
,p_db_column_name=>'TIPO'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Tipo'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(369552368638034100)
,p_db_column_name=>'CLIENTE'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Cliente'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(369552430472034101)
,p_db_column_name=>'NOMBRE_CLIENTE'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Nombre Cliente'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(369552536802034102)
,p_db_column_name=>'ESTADO'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Estado'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(369552627086034103)
,p_db_column_name=>'FECHA_DOCUMENTO'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'Fecha Documento'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(369552780607034104)
,p_db_column_name=>'FECHA_ENTREGA'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>'Fecha Entrega'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(426649163147881032)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'1817186'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'DOCUMENTO:TIPO:CLIENTE:NOMBRE_CLIENTE:ESTADO:FECHA_DOCUMENTO:FECHA_ENTREGA'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(425333571821193280)
,p_plug_name=>unistr('\00D3rdenes recepcionadas sin factura')
,p_parent_plug_id=>wwv_flow_imp.id(369551842629034095)
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(112813843178917343)
,p_plug_display_sequence=>20
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'WITH TIPO_DOCUMENTO AS (',
'    SELECT TIPO_DOCUMENTO',
'    FROM DATA.T_FINZ_DOCUMENTOS',
'    WHERE ACTIVO = ''S''',
'    AND ID_MODULO IN (',
'        SELECT ID_MODULO  FROM T_FINZ_RESPONSABLECIERRE WHERE CODIGO_MODULO =  ''DOP356'' AND ACTIVO = ''S''',
'    ) ',
')',
'',
'SELECT  /*+ DRIVING_SITE(so) */ DISTINCT',
'       PDDCTO AS TIPO,',
'       PDDOCO AS DOCUMENTO,',
'       PDAN8 AS CLIENTE,',
'       TRIM(ab.ABALPH) AS NOMBRE_CLIENTE,',
'       PDNXTR AS ESTADO,',
'       TO_DATE(TO_CHAR(NULLIF(so.PDTRDJ, 0) + 1900000), ''YYYYDDD'') AS FECHA_DOCUMENTO',
'FROM PRODDTA.F4311@jdedtadl so',
'JOIN proddta.F0101@jdedtadl ab ON so.PDAN8 = ab.ABAN8',
'WHERE',
'    so.PDDCTO IN (SELECT TIPO_DOCUMENTO FROM TIPO_DOCUMENTO)',
'    AND so.PDUREC <> 0',
'    AND ',
'    (',
'       (PDDCTO = ''CN'' AND PDNXTR = 400)',
'       OR (PDDCTO = ''CT'' AND PDNXTR = 400)',
'       OR (PDDCTO = ''OI'' AND PDNXTR IN (380,385))',
'    )',
'    AND so.PDTRDJ BETWEEN TO_NUMBER(TO_CHAR(SYSDATE,''YYYY'')||''000'') - 1900000 AND :P603_HOY_JDE',
'',
'    AND NOT EXISTS (',
'       SELECT 1',
'       FROM PRODDTA.F0413@jdedtadl m',
'       WHERE m.RMDOCM = so.PDDOCO',
'       AND   m.RMDCTM = so.PDDCTO',
'    )'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_display_condition_type=>'EXPRESSION'
,p_plug_display_when_condition=>':P603_ID_REGION = 2'
,p_plug_display_when_cond2=>'PLSQL'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(425333666915193281)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'TOP_AND_BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'MFERRIN'
,p_internal_uid=>425333666915193281
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(425334003433193284)
,p_db_column_name=>'CLIENTE'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Cliente'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(425334132652193286)
,p_db_column_name=>'ESTADO'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Estado'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(425334675007193291)
,p_db_column_name=>'NOMBRE_CLIENTE'
,p_display_order=>80
,p_column_identifier=>'J'
,p_column_label=>'Nombre Cliente'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(425334798935193292)
,p_db_column_name=>'TIPO'
,p_display_order=>90
,p_column_identifier=>'K'
,p_column_label=>'Tipo'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(425334872150193293)
,p_db_column_name=>'DOCUMENTO'
,p_display_order=>100
,p_column_identifier=>'L'
,p_column_label=>'Documento'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(425334960076193294)
,p_db_column_name=>'FECHA_DOCUMENTO'
,p_display_order=>110
,p_column_identifier=>'M'
,p_column_label=>'Fecha Documento'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(426656115466617597)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'1817255'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'DOCUMENTO:TIPO:CLIENTE:NOMBRE_CLIENTE:ESTADO:FECHA_DOCUMENTO:'
,p_sort_column_1=>'DOCUMENTO'
,p_sort_direction_1=>'ASC'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(424610536325923187)
,p_plug_name=>'Barra Accion'
,p_region_template_options=>'#DEFAULT#:t-Form--stretchInputs'
,p_plug_template=>wwv_flow_imp.id(38289497777120142)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_location=>null
,p_ai_enabled=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(430620330181493187)
,p_plug_name=>unistr('Log\00EDstica')
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(38289867500120143)
,p_plug_display_sequence=>80
,p_location=>null
,p_plug_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_plug_display_when_condition=>'P603_LOGISTICA'
,p_plug_display_when_cond2=>'1'
,p_ai_enabled=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(430620514221493188)
,p_plug_name=>'SALDOS EN CANTIDAD NEGATIVOS'
,p_parent_plug_id=>wwv_flow_imp.id(430620330181493187)
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(112813843178917343)
,p_plug_display_sequence=>100
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'WITH BODEGAS AS (',
'SELECT',
'    MCMCU AS CODIGO_BODEGA',
'FROM',
'    PRODDTA.F0006@jdedtadl',
'WHERE',
'    MCCO = ''00001''',
'AND MCRP20 = :P603_BDG_LOGISTICA',
')',
'SELECT lp.LIITM CODIGO_CORTO,p.CODIGOPRODUCTO CODIGO_PRODUCTO,p.NOMBREPRODUCTO NOMBRE_PRODUCTO,lp.LIPQOH/10000 CANTIDAD,LIMCU BODEGA,LILOCN UBICACION,LILOTN LOTE',
'FROM proddta.F41021@jdedtadl lp',
'INNER JOIN BODEGAS BDG ON BDG.CODIGO_BODEGA = lp.LIMCU',
'INNER JOIN DATA.VT_JDE_PRODUCTOS p ON p.CODIGOCORTO=lp.LIITM',
'WHERE round(lp.LIPQOH/10000,4)<0'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_display_condition_type=>'EXPRESSION'
,p_plug_display_when_condition=>':P603_ID_REGION = 1'
,p_plug_display_when_cond2=>'PLSQL'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(430620532634493189)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'MFERRIN'
,p_internal_uid=>430620532634493189
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(430620660642493190)
,p_db_column_name=>'CODIGO_CORTO'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Codigo Corto'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(430620727129493191)
,p_db_column_name=>'CODIGO_PRODUCTO'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Codigo Producto'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(430620892555493192)
,p_db_column_name=>'NOMBRE_PRODUCTO'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Nombre Producto'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(430620992765493193)
,p_db_column_name=>'UBICACION'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Ubicacion'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(430621075918493194)
,p_db_column_name=>'LOTE'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Lote'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(430621149249493195)
,p_db_column_name=>'CANTIDAD'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'Cantidad'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(430621317073493196)
,p_db_column_name=>'BODEGA'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>'Bodega'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(432585554291194508)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'1876550'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'CODIGO_CORTO:CODIGO_PRODUCTO:NOMBRE_PRODUCTO:BODEGA:UBICACION:LOTE:CANTIDAD:'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(432605669064412181)
,p_plug_name=>'TRANSACCIONES ABIERTAS DE TRANSFERENCIA ENTRE BODEGAS'
,p_parent_plug_id=>wwv_flow_imp.id(430620330181493187)
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(112813843178917343)
,p_plug_display_sequence=>150
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'WITH BODEGAS AS (',
'SELECT',
'    MCMCU AS CODIGO_BODEGA',
'FROM',
'    PRODDTA.F0006@jdedtadl',
'WHERE',
'    MCCO = ''00001''',
'AND MCRP20 = :P603_BDG_LOGISTICA',
')',
'',
'SELECT /*+ DRIVING_SITE(so) LEADING(so po) INDEX(so F4211_18) */',
'    so.SDDOCO        AS DOC_ORIGEN,',
'    so.SDDCTO        AS TIPO_ORIGEN,',
'    so.SDLITM        AS ITEM,',
'    so.SDNXTR        AS ESTADO_ORIGEN,',
'    po.PDDOCO        AS DOC_DESTINO,',
'    po.PDDCTO        AS TIPO_DESTINO,',
'    po.PDNXTR        AS ESTADO_DESTINO,',
'    so.SDMCU         AS BODEGA,',
'    CASE',
'        WHEN po.PDDOCO IS NULL',
'            THEN ''SIN CONTRAPARTE''',
'',
'        WHEN so.SDNXTR <= ''580'' AND po.PDNXTR <= ''400''',
'            THEN ''ESTADO MT/OT INCORRECTO''',
'    END AS VALIDACION',
'',
'FROM PRODDTA.F4211@jdedtadl so',
'INNER JOIN BODEGAS BDG ON BDG.CODIGO_BODEGA = so.SDMCU',
'LEFT JOIN PRODDTA.F4311@jdedtadl po',
'       ON TRIM(po.PDRORN) = TO_CHAR(so.SDDOCO)',
'      AND so.SDLNID = po.PDLNID',
'      AND so.SDKCOO = po.PDKCOO',
'      AND so.SDLITM = po.PDLITM',
'      AND (',
'              (so.SDDCTO = ''DT'' AND po.PDDCTO = ''MT'')',
'           OR (so.SDDCTO = ''ST'' AND po.PDDCTO = ''OT'')',
'          )',
'',
'WHERE ',
'  so.SDKCOO = ''00001''',
'  AND so.SDDCTO IN (''DT'',''ST'')',
'  AND so.SDNXTR <= ''580''',
'  AND so.SDTRDJ >= TO_NUMBER(TO_CHAR(SYSDATE,''YYYYDDD'')) - 1900000',
'  AND (',
'        po.PDDOCO IS NULL',
'        OR po.PDNXTR <= ''400''',
'      )',
'',
'ORDER BY',
'    so.SDDCTO,',
'    so.SDDOCO,',
'    so.SDLNID;'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_display_condition_type=>'EXPRESSION'
,p_plug_display_when_condition=>':P603_ID_REGION = 4'
,p_plug_display_when_cond2=>'PLSQL'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(432605770746412182)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'TOP_AND_BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'MFERRIN'
,p_internal_uid=>432605770746412182
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(432606185545412186)
,p_db_column_name=>'TIPO_ORIGEN'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Tipo Origen'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(432606510534412189)
,p_db_column_name=>'DOC_ORIGEN'
,p_display_order=>50
,p_column_identifier=>'G'
,p_column_label=>'Doc Origen'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(432606591344412190)
,p_db_column_name=>'ITEM'
,p_display_order=>60
,p_column_identifier=>'H'
,p_column_label=>'Item'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(432606648271412191)
,p_db_column_name=>'ESTADO_ORIGEN'
,p_display_order=>70
,p_column_identifier=>'I'
,p_column_label=>'Estado Origen'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(432606778214412192)
,p_db_column_name=>'DOC_DESTINO'
,p_display_order=>80
,p_column_identifier=>'J'
,p_column_label=>'Doc Destino'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(432606885504412193)
,p_db_column_name=>'TIPO_DESTINO'
,p_display_order=>90
,p_column_identifier=>'K'
,p_column_label=>'Tipo Destino'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(432606999577412194)
,p_db_column_name=>'ESTADO_DESTINO'
,p_display_order=>100
,p_column_identifier=>'L'
,p_column_label=>'Estado Destino'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(432607024692412195)
,p_db_column_name=>'VALIDACION'
,p_display_order=>110
,p_column_identifier=>'M'
,p_column_label=>'Validacion'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(439422818788348902)
,p_db_column_name=>'BODEGA'
,p_display_order=>120
,p_column_identifier=>'N'
,p_column_label=>'Bodega'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(432627103253892937)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'1876965'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'DOC_ORIGEN:TIPO_ORIGEN:ITEM:ESTADO_ORIGEN:DOC_DESTINO:TIPO_DESTINO:ESTADO_DESTINO:BODEGA:VALIDACION:'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(432607177115412196)
,p_plug_name=>unistr('PRODUCTOS PARAMETRIZADOS QUE NECESITEN LOTE A EXCEPCI\00D3N DE SEMIELABORADOS')
,p_parent_plug_id=>wwv_flow_imp.id(430620330181493187)
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(112813843178917343)
,p_plug_display_sequence=>170
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'WITH BODEGAS AS (',
'SELECT',
'    MCMCU AS CODIGO_BODEGA',
'FROM',
'    PRODDTA.F0006@jdedtadl',
'WHERE',
'    MCCO = ''00001''',
'AND MCRP20 = :P603_BDG_LOGISTICA',
')',
'SELECT p.CODIGOCORTO,p.CODIGOPRODUCTO,p.NOMBREPRODUCTO, ib.IBMCU BODEGA',
'FROM PRODDTA.F4102@jdedtadl ib',
'INNER JOIN BODEGAS BDG ON BDG.CODIGO_BODEGA = ib.IBMCU',
'--INNER JOIN DATA.VT_JDE_PRODUCTOS p ON p.CODIGOCORTO=ib.IBITM',
'INNER JOIN (SELECT p.CODIGOCORTO,p.CODIGOPRODUCTO,p.NOMBREPRODUCTO',
'          FROM DATA.VT_JDE_PRODUCTOS p',
'          WHERE p.TEXTOBUSQUEDA <> ''SEMIELABORADO''',
'            AND p.CODESTADO <> ''O''',
'            ) P ON p.CODIGOCORTO=ib.IBITM',
'WHERE ',
'ib.IBSRCE = ''1'''))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_display_condition_type=>'EXPRESSION'
,p_plug_display_when_condition=>':P603_ID_REGION = 6'
,p_plug_display_when_cond2=>'PLSQL'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
,p_ai_enabled=>false
,p_updated_on=>wwv_flow_imp.dz('20260427112947Z')
,p_updated_by=>'JBALCAZAR'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(432607277445412197)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'TOP_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'MFERRIN'
,p_internal_uid=>432607277445412197
,p_updated_on=>wwv_flow_imp.dz('20260427112947Z')
,p_updated_by=>'JBALCAZAR'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(432608130558412206)
,p_db_column_name=>'CODIGOCORTO'
,p_display_order=>10
,p_column_identifier=>'I'
,p_column_label=>'Codigocorto'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(432608304367412207)
,p_db_column_name=>'CODIGOPRODUCTO'
,p_display_order=>20
,p_column_identifier=>'J'
,p_column_label=>'Codigoproducto'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(432608405233412208)
,p_db_column_name=>'NOMBREPRODUCTO'
,p_display_order=>30
,p_column_identifier=>'K'
,p_column_label=>'Nombreproducto'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(439422977189348904)
,p_db_column_name=>'BODEGA'
,p_display_order=>40
,p_column_identifier=>'L'
,p_column_label=>'Bodega'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(433009891603799559)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'1880793'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'CODIGOCORTO:CODIGOPRODUCTO:NOMBREPRODUCTO:BODEGA:'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(432608435989412209)
,p_plug_name=>unistr('PRODUCTOS QUE TENGAN SALDO EN LOTE A EXCEPCI\00D3N DE SEMIELABORADOS')
,p_parent_plug_id=>wwv_flow_imp.id(430620330181493187)
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(112813843178917343)
,p_plug_display_sequence=>180
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'WITH BODEGAS AS (',
'SELECT',
'    MCMCU AS CODIGO_BODEGA',
'FROM',
'    PRODDTA.F0006@jdedtadl',
'WHERE',
'    MCCO = ''00001''',
'AND MCRP20 = :P603_BDG_LOGISTICA',
')',
'',
'SELECT',
'    li.LIITM AS CODIGO_CORTO,',
'    p.CODIGOPRODUCTO,',
'    p.NOMBREPRODUCTO,',
'    li.LIMCU AS BODEGA,',
'    li.LILOCN AS UBICACION,',
'    li.LILOTN AS LOTE,',
'    ROUND(li.LIPQOH/10000,4) AS SALDO_CANTIDAD',
'FROM PRODDTA.F41021@jdedtadl li',
'INNER JOIN BODEGAS BDG ON BDG.CODIGO_BODEGA = li.LIMCU',
'INNER JOIN (SELECT p.CODIGOCORTO,p.CODIGOPRODUCTO,p.NOMBREPRODUCTO',
'          FROM DATA.VT_JDE_PRODUCTOS p',
'          WHERE p.TEXTOBUSQUEDA <> ''SEMIELABORADO''',
'            AND p.CODESTADO <> ''O'') P ON p.CODIGOCORTO=li.LIITM',
'WHERE ',
'li.LILOTN IS NOT NULL',
'AND TRIM(li.LILOTN) IS NOT NULL',
'AND LENGTH(TRIM(li.LILOTN)) > 0',
'AND ROUND(li.LIPQOH/10000,4) <> 0',
'ORDER BY',
'    p.CODIGOPRODUCTO,',
'    li.LILOTN;'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_display_condition_type=>'EXPRESSION'
,p_plug_display_when_condition=>':P603_ID_REGION = 7'
,p_plug_display_when_cond2=>'PLSQL'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(432608566621412210)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'MFERRIN'
,p_internal_uid=>432608566621412210
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(433019812308094262)
,p_db_column_name=>'CODIGOPRODUCTO'
,p_display_order=>20
,p_column_identifier=>'A'
,p_column_label=>'Codigoproducto'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(433019890957094263)
,p_db_column_name=>'NOMBREPRODUCTO'
,p_display_order=>30
,p_column_identifier=>'B'
,p_column_label=>'Nombreproducto'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(433020012189094264)
,p_db_column_name=>'CODIGO_CORTO'
,p_display_order=>40
,p_column_identifier=>'C'
,p_column_label=>'Codigo Corto'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(433020089351094265)
,p_db_column_name=>'BODEGA'
,p_display_order=>50
,p_column_identifier=>'D'
,p_column_label=>'Bodega'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(433020142083094266)
,p_db_column_name=>'UBICACION'
,p_display_order=>60
,p_column_identifier=>'E'
,p_column_label=>'Ubicacion'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(433020253197094267)
,p_db_column_name=>'LOTE'
,p_display_order=>70
,p_column_identifier=>'F'
,p_column_label=>'Lote'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(433020509610094269)
,p_db_column_name=>'SALDO_CANTIDAD'
,p_display_order=>80
,p_column_identifier=>'H'
,p_column_label=>'Saldo Cantidad'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D0000000'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(433027555787097111)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'1880970'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'CODIGO_CORTO:CODIGOPRODUCTO:NOMBREPRODUCTO:BODEGA:UBICACION:LOTE:SALDO_CANTIDAD:'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(433020607403094270)
,p_plug_name=>unistr('TRANSACCIONES QUE TENGAN DISTINTO LA FECHA TRANSACCI\00D3N A LA FECHA LM')
,p_parent_plug_id=>wwv_flow_imp.id(430620330181493187)
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(112813843178917343)
,p_plug_display_sequence=>190
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'WITH BODEGAS AS (',
'SELECT',
'    MCMCU AS CODIGO_BODEGA',
'FROM',
'    PRODDTA.F0006@jdedtadl',
'WHERE',
'    MCCO = ''00001''',
'AND MCRP20 = :P603_BDG_LOGISTICA',
')',
'',
'SELECT',
'    ic.ILDOC  AS DOCUMENTO,',
'    ic.ILDCT  AS TIPO_DOC,',
'    ic.ILDCTO AS TIPO_ORIGEN,',
'    ic.ILMCU  AS BODEGA,',
'    ic.ILITM  AS ITEM,',
'    ic.ILTRQT/10000 AS CANTIDAD,',
'    ic.ILUNCS/100 AS COSTO,',
'',
'    TO_DATE(TO_CHAR(NULLIF(ic.ILTRDJ,0)+1900000),''YYYYDDD'') AS FECHA_TRANSACCION,',
'    TO_DATE(TO_CHAR(NULLIF(ic.ILDGL,0)+1900000),''YYYYDDD'') AS FECHA_GL_KARDEX,',
'',
'    TO_DATE(TO_CHAR(NULLIF(gl.GLDGJ,0)+1900000),''YYYYDDD'') AS FECHA_GL_CONTABLE',
'',
'FROM PRODDTA.F4111@jdedtadl ic',
'INNER JOIN BODEGAS BDG ON BDG.CODIGO_BODEGA = ic.ILMCU',
'INNER JOIN PRODDTA.F0911@jdedtadl gl',
'       ON gl.GLDOC = ic.ILDOC',
'      AND gl.GLDCT = ic.ILDCT',
'      AND gl.GLKCO = ic.ILKCO',
'      AND gl.GLDGJ = ic.ILDGL',
'WHERE ',
'ic.ILKCOO = ''00001''',
'AND ic.ILDCTO IN (''MT'',''OT'',''TR'')',
'AND ic.ILTRDJ > ic.ILDGL',
'',
'AND ic.ILTRDJ >= TO_NUMBER(TO_CHAR(TRUNC(SYSDATE,''MM''),''YYYYDDD'')) - 1900000',
'',
'ORDER BY ic.ILDOC;'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_display_condition_type=>'EXPRESSION'
,p_plug_display_when_condition=>':P603_ID_REGION = 8'
,p_plug_display_when_cond2=>'PLSQL'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(433020628516094271)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'MFERRIN'
,p_internal_uid=>433020628516094271
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(433021087033094275)
,p_db_column_name=>'BODEGA'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Bodega'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(433021505319094279)
,p_db_column_name=>'DOCUMENTO'
,p_display_order=>50
,p_column_identifier=>'H'
,p_column_label=>'Documento'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(433021538190094280)
,p_db_column_name=>'TIPO_DOC'
,p_display_order=>60
,p_column_identifier=>'I'
,p_column_label=>'Tipo Doc'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(433021716229094281)
,p_db_column_name=>'ITEM'
,p_display_order=>70
,p_column_identifier=>'J'
,p_column_label=>'Item'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(433021753405094282)
,p_db_column_name=>'FECHA_TRANSACCION'
,p_display_order=>80
,p_column_identifier=>'K'
,p_column_label=>'Fecha Transaccion'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(433021839846094283)
,p_db_column_name=>'FECHA_GL_KARDEX'
,p_display_order=>90
,p_column_identifier=>'L'
,p_column_label=>'Fecha Gl Kardex'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(433022022070094284)
,p_db_column_name=>'FECHA_GL_CONTABLE'
,p_display_order=>100
,p_column_identifier=>'M'
,p_column_label=>'Fecha Gl Contable'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(433022114020094285)
,p_db_column_name=>'TIPO_ORIGEN'
,p_display_order=>110
,p_column_identifier=>'N'
,p_column_label=>'Tipo Origen'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(446838858296129061)
,p_db_column_name=>'CANTIDAD'
,p_display_order=>120
,p_column_identifier=>'O'
,p_column_label=>'Cantidad'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(446838937703129062)
,p_db_column_name=>'COSTO'
,p_display_order=>130
,p_column_identifier=>'P'
,p_column_label=>'Costo'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(433046759775367238)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'1881162'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'BODEGA:DOCUMENTO:TIPO_DOC:TIPO_ORIGEN:ITEM:CANTIDAD:COSTO:FECHA_TRANSACCION:FECHA_GL_KARDEX:FECHA_GL_CONTABLE:'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(433022201483094286)
,p_plug_name=>'TRANSACCIONES EN ESTADO SIGUIENTE <999'
,p_parent_plug_id=>wwv_flow_imp.id(430620330181493187)
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(112813843178917343)
,p_plug_display_sequence=>160
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'WITH',
'BODEGAS AS (',
'SELECT',
'    MCMCU AS CODIGO_BODEGA',
'FROM',
'    PRODDTA.F0006@jdedtadl',
'WHERE',
'    MCCO = ''00001''',
'AND MCRP20 = :P603_BDG_LOGISTICA',
')',
'',
'SELECT  ',
'    SDDOCO AS DOCUMENTO,',
'    SDDCTO AS TIPO,',
'    SDNXTR AS ESTADO_SIGUIENTE,',
'    TO_DATE(TO_CHAR(NULLIF(SDTRDJ, 0) + 1900000), ''YYYYDDD'') Fecha_Documento,',
'    SDMCU BODEGA',
'FROM PRODDTA.F4211@jdedtadl ',
'INNER JOIN BODEGAS BDG ON BDG.CODIGO_BODEGA = SDMCU',
'WHERE SDDCTO IN (''DT'',''ST'')',
'AND SDTRDJ BETWEEN',
'            (TO_NUMBER(TO_CHAR(TRUNC(SYSDATE,''MM''),''YYYYDDD'')) - 1900000)',
'        AND (TO_NUMBER(TO_CHAR(SYSDATE,''YYYYDDD'')) - 1900000)',
'AND SDNXTR < 999',
'--AND :P603_ES_ULTIMO_DIA_H = 1',
'',
'UNION ALL',
'',
'SELECT  ',
'    PDDOCO AS DOCUMENTO,',
'    PDDCTO AS TIPO,',
'    PDNXTR AS ESTADO_SIGUIENTE,',
'    TO_DATE(TO_CHAR(NULLIF(PDTRDJ, 0) + 1900000), ''YYYYDDD'') Fecha_Documento,',
'    PDMCU BODEGA',
'FROM PRODDTA.F4311@jdedtadl ',
'INNER JOIN BODEGAS BDG ON BDG.CODIGO_BODEGA = PDMCU',
'WHERE PDDCTO IN (''MT'',''OT'')',
'AND PDTRDJ BETWEEN',
'            (TO_NUMBER(TO_CHAR(TRUNC(SYSDATE,''MM''),''YYYYDDD'')) - 1900000)',
'        AND (TO_NUMBER(TO_CHAR(SYSDATE,''YYYYDDD'')) - 1900000)',
'AND PDNXTR < 999',
'--AND :P603_ES_ULTIMO_DIA_H = 1',
'',
'ORDER BY TIPO, DOCUMENTO;'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_display_condition_type=>'EXPRESSION'
,p_plug_display_when_condition=>':P603_ID_REGION = 5'
,p_plug_display_when_cond2=>'PLSQL'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(433022267505094287)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'TOP_AND_BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'MFERRIN'
,p_internal_uid=>433022267505094287
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(433023182535094296)
,p_db_column_name=>'DOCUMENTO'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Documento'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(433023294295094297)
,p_db_column_name=>'TIPO'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Tipo'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(433023362412094298)
,p_db_column_name=>'ESTADO_SIGUIENTE'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Estado Siguiente'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(433023448156094299)
,p_db_column_name=>'FECHA_DOCUMENTO'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Fecha Documento'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(439422918744348903)
,p_db_column_name=>'BODEGA'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Bodega'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(433210666038050133)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'1882801'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'DOCUMENTO:TIPO:FECHA_DOCUMENTO:ESTADO_SIGUIENTE:BODEGA:'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(434040141834949378)
,p_plug_name=>unistr('VARIACI\00D3N EN COSTO PROMEDIO VS TRANSACCIONAL')
,p_parent_plug_id=>wwv_flow_imp.id(430620330181493187)
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(112813843178917343)
,p_plug_display_sequence=>200
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'WITH BASE AS (',
'SELECT',
'    DOCUMENTO_ORIGEN,',
'    DOCUMENTO,',
'    TIPO_DOCUMENTO,',
'    BODEGA,',
'    UN_MOV,',
'    ILITM,',
'    CANTIDAD_MOV,',
'    COSTO_MOV,',
'    COSTO_TOTAL_MOV',
'FROM (',
'    SELECT',
'        KD.ILDOCO AS DOCUMENTO_ORIGEN,',
'        KD.ILDOC  AS DOCUMENTO,',
'        KD.ILDCT  AS TIPO_DOCUMENTO,',
'        KD.ILMCU  AS BODEGA,',
'        KD.ILTRUM AS UN_MOV,',
'        KD.ILITM,',
'        KD.ILTRQT/10000 AS CANTIDAD_MOV,',
'        KD.ILUNCS/10000 AS COSTO_MOV,',
'        KD.ILPAID/100 AS COSTO_TOTAL_MOV,',
'',
'        ROW_NUMBER() OVER (',
'            PARTITION BY KD.ILITM',
'            ORDER BY KD.ILTRDJ DESC, KD.ILTDAY DESC',
'        ) AS RN',
'',
'    FROM PRODDTA.F4111@jdedtadl KD',
'    INNER JOIN (',
'        SELECT',
'            MCMCU AS CODIGO_BODEGA',
'        FROM',
'            PRODDTA.F0006@jdedtadl',
'        WHERE',
'            MCCO = ''00001''',
'        AND MCRP20 = :P603_BDG_LOGISTICA',
'    ) BDG ON BDG.CODIGO_BODEGA = KD.ILMCU',
'    WHERE',
'    KD.ILKCO = ''00001''',
'    AND KD.ILTRDJ >= TO_NUMBER(TO_CHAR(TRUNC(SYSDATE,''MM''),''YYYYDDD'')) - 1900000',
'    AND KD.ILTRQT < 0',
')',
'WHERE RN = 1',
'),',
'PRODUCTOS AS (',
'    SELECT P.CODIGOCORTO, P.CODIGOPRODUCTO, P.UNIDADPRINCIPAL,FACTOR,UMUM UNIDAD_ORIGEN,CP.COSTO',
'    FROM DATA.VT_JDE_PRODUCTOS P',
'    INNER JOIN DATA.VT_JDE_COSTOPROMEDIOPRODUCTO CP',
'        ON CP.CODIGOCORTO = P.CODIGOCORTO AND CP.METODOCOSTO = ''02'' AND CP.BODEGA = LPAD(17003,12)',
'    INNER JOIN DATA.VT_JDE_CONVERSIONES C',
'        ON C.UMITM = P.CODIGOCORTO AND P.UNIDADPRINCIPAL = C.A_UM',
')',
'SELECT B.DOCUMENTO_ORIGEN,B.DOCUMENTO,B.BODEGA, B.ILITM PRODUCTO, P.CODIGOPRODUCTO CODIGO_PRODUCTO,',
'       ROUND((B.COSTO_MOV/P.FACTOR),4) AS COSTO_UNITARIO_TRANS,',
'       P.COSTO AS COSTO_PROMEDIO,TIPO_DOCUMENTO, ROUND((B.COSTO_MOV/P.FACTOR),4) - P.COSTO DIFERENCIA',
'FROM BASE B',
'JOIN PRODUCTOS P ON P.CODIGOCORTO = B.ILITM AND P.UNIDAD_ORIGEN = B.UN_MOV',
'WHERE ROUND((B.COSTO_MOV/P.FACTOR),4) <> P.COSTO'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_display_condition_type=>'EXPRESSION'
,p_plug_display_when_condition=>':P603_ID_REGION = 9'
,p_plug_display_when_cond2=>'PLSQL'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(434040279948949379)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'MFERRIN'
,p_internal_uid=>434040279948949379
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(434040367837949380)
,p_db_column_name=>'BODEGA'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Bodega'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(434040510043949381)
,p_db_column_name=>'DOCUMENTO'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Documento'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(434041179974949388)
,p_db_column_name=>'DOCUMENTO_ORIGEN'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Documento Origen'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(434041766440949394)
,p_db_column_name=>'COSTO_PROMEDIO'
,p_display_order=>90
,p_column_identifier=>'I'
,p_column_label=>'Costo Promedio'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(434041919234949395)
,p_db_column_name=>'PRODUCTO'
,p_display_order=>100
,p_column_identifier=>'J'
,p_column_label=>'Producto'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(434042009933949396)
,p_db_column_name=>'COSTO_UNITARIO_TRANS'
,p_display_order=>110
,p_column_identifier=>'K'
,p_column_label=>'Costo Unitario Trans'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(434042041738949397)
,p_db_column_name=>'CODIGO_PRODUCTO'
,p_display_order=>120
,p_column_identifier=>'L'
,p_column_label=>'Codigo Producto'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(441023778244228962)
,p_db_column_name=>'TIPO_DOCUMENTO'
,p_display_order=>130
,p_column_identifier=>'M'
,p_column_label=>'Tipo Documento'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(446747285692575788)
,p_db_column_name=>'DIFERENCIA'
,p_display_order=>140
,p_column_identifier=>'N'
,p_column_label=>'Diferencia'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(434125903604965789)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'1891953'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'TIPO_DOCUMENTO:DOCUMENTO:DOCUMENTO_ORIGEN:BODEGA:CODIGO_PRODUCTO:COSTO_PROMEDIO:COSTO_UNITARIO_TRANS:DIFERENCIA:'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(434042188391949398)
,p_plug_name=>'PROCESOS DE INVENTARIOS ABIERTOS'
,p_parent_plug_id=>wwv_flow_imp.id(430620330181493187)
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(112813843178917343)
,p_plug_display_sequence=>210
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'WITH FERIADOS AS (',
'    SELECT TO_DATE(',
'               LPAD(TRIM(VALOR), 2, ''0'') || ''/'' || ',
'               LPAD(TRIM(VALOR2), 2, ''0'') || ''/'' || ',
'               EXTRACT(YEAR FROM SYSDATE), ',
'               ''DD/MM/YYYY''',
'           ) AS FECHA_FERIADO',
'    FROM DATA.T_CORP_UDC',
'    WHERE ID_CABECERA = ''ADT_FERIAD'' ',
'      AND CODIGOCOMPANIA = ''00001'' ',
'      AND ACTIVO = 1',
'),',
unistr('CALENDARIO_MES AS ( -- D\00EDas transcurridos del mes actual'),
'    SELECT TRUNC(SYSDATE, ''MM'') + LEVEL - 1 AS FECHA_EVAL',
'    FROM DUAL',
'    CONNECT BY TRUNC(SYSDATE, ''MM'') + LEVEL - 1 <= TRUNC(SYSDATE)',
'),',
'DIAS_HABILES_TRANSCURRIDOS AS (',
'    SELECT COUNT(*) AS CANTIDAD_DIAS',
'    FROM CALENDARIO_MES',
'    WHERE TO_CHAR(FECHA_EVAL, ''DY'', ''NLS_DATE_LANGUAGE=ENGLISH'') NOT IN (''SAT'', ''SUN'')',
'      AND FECHA_EVAL NOT IN (SELECT FECHA_FERIADO FROM FERIADOS)',
'),',
'ULTIMO_DIA_HABIL AS (',
'    SELECT MAX(FECHA_EVAL) AS FECHA',
'    FROM (',
'        SELECT TRUNC(LAST_DAY(SYSDATE)) - LEVEL + 1 AS FECHA_EVAL',
'        FROM DUAL',
'        CONNECT BY LEVEL <= 31',
'    )',
'    WHERE TO_CHAR(FECHA_EVAL,''DY'',''NLS_DATE_LANGUAGE=ENGLISH'') NOT IN (''SAT'',''SUN'')',
'      AND FECHA_EVAL NOT IN (SELECT FECHA_FERIADO FROM FERIADOS)',
'),',
'BODEGAS AS (',
'SELECT',
'    MCMCU AS CODIGO_BODEGA',
'FROM',
'    PRODDTA.F0006@jdedtadl',
'WHERE',
'    MCCO = ''00001''',
'AND MCRP20 = :P603_BDG_LOGISTICA',
')',
'',
'SELECT distinct CORTE_ID,UBICACION,USUARIO, UNIDADNEGOCIO BODEGA',
'FROM data.t_invc_itemcorte',
'INNER JOIN BODEGAS BDG ON TO_NUMBER(TRIM(BDG.CODIGO_BODEGA))= UNIDADNEGOCIO',
'WHERE ESTADO < 6 ',
'--AND UNIDADNEGOCIO = 17003',
unistr('  -- L\00D3GICA DE VISIBILIDAD DE MESES (Qu\00E9 meses puedo ver)'),
'  AND (',
'      -- Escenario A: Siempre traemos los documentos del MES ACTUAL, SOLO SE PUEDEN VER EL ULTIMO DIA DEL MES',
'      (',
'        TRUNC(SYSDATE) = (SELECT FECHA FROM ULTIMO_DIA_HABIL)',
'        AND FECHACREACION BETWEEN TRUNC(SYSDATE, ''MM'') AND SYSDATE',
'      )',
'      ',
'      OR ',
'      ',
unistr('      -- Escenario B: Traemos TODO el MES ANTERIOR, SOLO si han pasado 5 d\00EDas h\00E1biles o menos'),
'      (',
'          (SELECT CANTIDAD_DIAS FROM DIAS_HABILES_TRANSCURRIDOS) <= 5',
'          AND FECHACREACION >= ADD_MONTHS(TRUNC(SYSDATE, ''MM''), -1)',
'          AND FECHACREACION <  TRUNC(SYSDATE, ''MM'')',
'      )',
'  )',
'ORDER BY CORTE_ID'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_display_condition_type=>'EXPRESSION'
,p_plug_display_when_condition=>':P603_ID_REGION = 10'
,p_plug_display_when_cond2=>'PLSQL'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
,p_ai_enabled=>false
,p_updated_on=>wwv_flow_imp.dz('20260505143904Z')
,p_updated_by=>'JBALCAZAR'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(434042224517949399)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'TOP_AND_BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'MFERRIN'
,p_internal_uid=>434042224517949399
,p_updated_on=>wwv_flow_imp.dz('20260505143904Z')
,p_updated_by=>'JBALCAZAR'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(434042372731949400)
,p_db_column_name=>'CORTE_ID'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Corte Id'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(434042449440949401)
,p_db_column_name=>'UBICACION'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Ubicacion'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(434042540233949402)
,p_db_column_name=>'USUARIO'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Usuario'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(439423081535348905)
,p_db_column_name=>'BODEGA'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Bodega'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(434147024090055784)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'1892165'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'CORTE_ID:UBICACION:USUARIO:BODEGA:'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(434042629472949403)
,p_plug_name=>'ETIQUETAS EN ESTADO INGRESADO DEL MES'
,p_parent_plug_id=>wwv_flow_imp.id(430620330181493187)
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(112813843178917343)
,p_plug_display_sequence=>220
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT * FROM ',
'(',
'WITH FERIADOS AS (',
'    SELECT TO_DATE(',
'               LPAD(TRIM(VALOR), 2, ''0'') || ''/'' || ',
'               LPAD(TRIM(VALOR2), 2, ''0'') || ''/'' || ',
'               EXTRACT(YEAR FROM SYSDATE), ',
'               ''DD/MM/YYYY''',
'           ) AS FECHA_FERIADO',
'    FROM DATA.T_CORP_UDC',
'    WHERE ID_CABECERA = ''ADT_FERIAD'' ',
'      AND CODIGOCOMPANIA = ''00001'' ',
'      AND ACTIVO = 1',
'),',
unistr('CALENDARIO_MES AS ( -- D\00EDas transcurridos del mes actual'),
'    SELECT TRUNC(SYSDATE, ''MM'') + LEVEL - 1 AS FECHA_EVAL',
'    FROM DUAL',
'    CONNECT BY TRUNC(SYSDATE, ''MM'') + LEVEL - 1 <= TRUNC(SYSDATE)',
'),',
'DIAS_HABILES_TRANSCURRIDOS AS (',
'    SELECT COUNT(*) AS CANTIDAD_DIAS',
'    FROM CALENDARIO_MES',
'    WHERE TO_CHAR(FECHA_EVAL, ''DY'', ''NLS_DATE_LANGUAGE=ENGLISH'') NOT IN (''SAT'', ''SUN'')',
'      AND FECHA_EVAL NOT IN (SELECT FECHA_FERIADO FROM FERIADOS)',
'),',
'ULTIMO_DIA_HABIL AS (',
'    SELECT MAX(FECHA_EVAL) AS FECHA',
'    FROM (',
'        SELECT TRUNC(LAST_DAY(SYSDATE)) - LEVEL + 1 AS FECHA_EVAL',
'        FROM DUAL',
'        CONNECT BY LEVEL <= 31',
'    )',
'    WHERE TO_CHAR(FECHA_EVAL,''DY'',''NLS_DATE_LANGUAGE=ENGLISH'') NOT IN (''SAT'',''SUN'')',
'      AND FECHA_EVAL NOT IN (SELECT FECHA_FERIADO FROM FERIADOS)',
'),',
'CONSTANTES AS (',
'    SELECT',
'        TO_NUMBER(TO_CHAR(TRUNC(SYSDATE)-5,''YYYYDDD'')) - 1900000 FEC_INI_DOCS,',
'        TRUNC(SYSDATE)-1 AYER',
'    FROM dual',
'),',
'BODEGAS AS (',
'SELECT',
'    MCMCU AS CODIGO_BODEGA',
'FROM',
'    PRODDTA.F0006@jdedtadl',
'WHERE',
'    MCCO = ''00001''',
'AND MCRP20 = :P603_BDG_LOGISTICA',
'),',
'B_PT AS (',
'    SELECT',
'        ILTREX,',
'        ILDOC,',
'        ILKCO,',
'        ILMCU',
'    FROM proddta.F4111@jdedtadl',
'    INNER JOIN BODEGAS BDG ON BDG.CODIGO_BODEGA = ILMCU',
'    CROSS JOIN CONSTANTES f',
'    WHERE ILDCT = ''IT''',
'      AND ILTRDJ >= f.FEC_INI_DOCS',
'      --AND ILMCU = f.BODEGA_PT',
'    GROUP BY ILTREX, ILDOC, ILKCO,ILMCU',
'),',
'D_ADAIA AS (',
'    SELECT',
'        DATTXT AS BODEGA,',
'        RPAD(''ETIQUETA:'' || TRIM(A.cntdorref),30) AS ETIQUETA',
'    FROM ADAIA.cntdor A',
'    JOIN ADAIA.CNTNDO B ON A.CNTCOD = B.CNTCOD',
'    JOIN ADAIA.ART C ON B.ARTCOD = C.ARTCOD',
'    JOIN ADAIA.DATPRV D',
'         ON D.DATKEY = A.CNTCOD',
'        AND TRIM(DATTIP) = ''TRUO''',
'    CROSS JOIN CONSTANTES f',
'    WHERE A.cntdorref LIKE ''275%''',
'      AND A.cntsit = ''OK''',
'      AND MOMCRE >= f.AYER',
')',
'SELECT B.ILDOC AS DOCUMENTO, B.ILKCO AS COMPANIA, A.ETIQUETA, B.ILMCU BODEGA,',
'CASE WHEN B.ILTREX IS NOT NULL THEN ''SI'' ELSE ''NO'' END AS ADAIA_EN_BODEGA',
'FROM D_ADAIA A',
'LEFT JOIN B_PT B ON B.ILTREX = A.ETIQUETA',
'WHERE TRUNC(SYSDATE) = (SELECT FECHA FROM ULTIMO_DIA_HABIL)',
')',
'WHERE ',
'ADAIA_EN_BODEGA = ''NO'''))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_display_condition_type=>'EXPRESSION'
,p_plug_display_when_condition=>':P603_ID_REGION = 11'
,p_plug_display_when_cond2=>'PLSQL'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(434042789994949404)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'MFERRIN'
,p_internal_uid=>434042789994949404
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(434042867702949405)
,p_db_column_name=>'DOCUMENTO'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Documento'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(434042994177949406)
,p_db_column_name=>'ETIQUETA'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Etiqueta'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(434043078824949407)
,p_db_column_name=>'COMPANIA'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Compania'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(439423133061348906)
,p_db_column_name=>'BODEGA'
,p_display_order=>40
,p_column_identifier=>'G'
,p_column_label=>'Bodega'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(439423310663348907)
,p_db_column_name=>'ADAIA_EN_BODEGA'
,p_display_order=>50
,p_column_identifier=>'H'
,p_column_label=>'Adaia En Bodega'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(434163545674265367)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'1892330'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'DOCUMENTO:ETIQUETA:COMPANIA:BODEGA:ADAIA_EN_BODEGA:'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(434151805277228569)
,p_plug_name=>'TRANSACCIONES PENDIENTES DE RECOLECTAR'
,p_parent_plug_id=>wwv_flow_imp.id(430620330181493187)
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(112813843178917343)
,p_plug_display_sequence=>230
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'WITH',
'BODEGAS AS (',
'SELECT',
'    MCMCU AS CODIGO_BODEGA',
'FROM',
'    PRODDTA.F0006@jdedtadl',
'WHERE',
'    MCCO = ''00001''',
'AND MCRP20 = :P603_BDG_LOGISTICA',
')',
'',
'SELECT NUMERO, TIPO, ',
'CASE WHEN TIPO IN(''DS'', ''VJ'') THEN NULL ELSE BODEGADESTINO END BODEGADESTINO,',
'BODEGADESTINO BODEGACODIGO,',
'CASE WHEN TIPO NOT IN(''DS'', ''VJ'') THEN NULL ELSE SOLICITANTE END SOLICITANTE,',
'UBICACION,',
'CASE WHEN (LENGTH(MAX(TO_CHAR((SELECT IALONGMSG FROM proddta.f564310@jdedtadl WHERE iadcto =TIPO AND IADOCO = NUMERO AND IALNID = LINEA)))))>1 THEN  MAX(TO_CHAR((SELECT IALONGMSG FROM f564310@jdedtadl WHERE iadcto =TIPO AND IADOCO = NUMERO AND IALNID'
||' = LINEA))) ELSE MAX(TO_CHAR(DESCRIPCION2)) END AS DESCRIPCION,',
'FECHA ,hora',
'FROM DATA.VT_LOGI_MP_DESPACHOS',
'INNER JOIN BODEGAS BDG ON BDG.CODIGO_BODEGA = BODEGA',
'WHERE TIPO<>''VM''',
'AND :P603_ES_ULTIMO_DIA_H = 1',
'GROUP BY NUMERO, TIPO, BODEGADESTINO, SOLICITANTE, UBICACION, FECHA, ESTADO,hora'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_display_condition_type=>'EXPRESSION'
,p_plug_display_when_condition=>':P603_ID_REGION = 12'
,p_plug_display_when_cond2=>'PLSQL'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(434151921579228570)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'MFERRIN'
,p_internal_uid=>434151921579228570
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(434152401048228575)
,p_db_column_name=>'NUMERO'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Numero'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(434152523076228576)
,p_db_column_name=>'TIPO'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Tipo'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(434152552014228577)
,p_db_column_name=>'BODEGADESTINO'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Bodegadestino'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(434152670297228578)
,p_db_column_name=>'BODEGACODIGO'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Bodegacodigo'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(434152817430228579)
,p_db_column_name=>'SOLICITANTE'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Solicitante'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(434152829630228580)
,p_db_column_name=>'UBICACION'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'Ubicacion'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(434152931095228581)
,p_db_column_name=>'DESCRIPCION'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>'Descripcion'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(434153071390228582)
,p_db_column_name=>'FECHA'
,p_display_order=>80
,p_column_identifier=>'H'
,p_column_label=>'Fecha'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(434153512187228586)
,p_db_column_name=>'HORA'
,p_display_order=>120
,p_column_identifier=>'L'
,p_column_label=>'Hora'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(434330942595356551)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'1894004'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'NUMERO:TIPO:BODEGADESTINO:BODEGACODIGO:SOLICITANTE:UBICACION:DESCRIPCION:FECHA:HORA'
,p_break_on=>'BODEGADESTINO'
,p_break_enabled_on=>'BODEGADESTINO'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(446748640119575802)
,p_plug_name=>'CONFIRMACIONES COSTO 0 DE TRANSFERENCIAS ENTRE BODEGAS'
,p_parent_plug_id=>wwv_flow_imp.id(430620330181493187)
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(112813843178917343)
,p_plug_display_sequence=>140
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT /*+ DRIVING_SITE(il) */',
'    ILDOCO DOCUMENTO_ORIGEN,',
'    ILDOC DOCUMENTO,',
'    ILDCT TIPO,',
'    ILDCTO TIPO_ORIGEN,',
'    ILMCU BODEGA,',
'    ILLITM PRODUCTO,',
'    COALESCE(',
'    CASE WHEN ILDCTO IN (''DT'', ''ST'') THEN SUM(NVL(ILUNCS, 0)) END,',
'    CASE WHEN ILDCT = ''TR'' THEN SUM(',
'        CASE',
'            WHEN ILFRTO = ''F'' THEN NVL(ILUNCS, 0)',
'            WHEN ILFRTO = ''T'' THEN (NVL(ILUNCS, 0) * -1)',
'            ELSE 0',
'        END) END',
'    ) / 100 COSTO',
'FROM PRODDTA.F4111@jdedtadl il',
'INNER JOIN (SELECT MCMCU AS CODIGO_BODEGA FROM PRODDTA.F0006@jdedtadl  WHERE MCCO = ''00001'' AND MCRP20 = :P603_BDG_LOGISTICA) BDG ',
'    ON BDG.CODIGO_BODEGA = ILMCU',
'WHERE',
'    ILKCO = ''00001''',
'    AND (ILDCTO IN (''DT'', ''ST'') OR ILDCT = ''TR'')',
'    AND ILTRDJ >= TO_NUMBER(TO_CHAR(TRUNC(SYSDATE, ''MM''), ''YYYYDDD'')) - 1900000',
'    AND ILDCT <> ''IB''',
'GROUP BY',
'    ILDOCO,',
'    ILDOC,',
'    ILDCT,',
'    ILDCTO,',
'    ILMCU,',
'    ILLITM',
'HAVING',
'    -- Regla 1: Para Manufactura (MT/OT), el costo total es 0',
'    (ILDCTO IN (''DT'', ''ST'') AND SUM(NVL(ILUNCS, 0)) = 0.0)',
'    OR',
'    --Regla 2: Para (TR), el balance entre From (F) y To (T) es distinto de 0',
'    (ILDCT = ''TR'' AND SUM(',
'        CASE',
'            WHEN ILFRTO = ''F'' THEN NVL(ILUNCS, 0)',
'            WHEN ILFRTO = ''T'' THEN (NVL(ILUNCS, 0) * -1)',
'            ELSE 0',
'        END) = 0)',
'ORDER BY ILDOC;'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_display_condition_type=>'EXPRESSION'
,p_plug_display_when_condition=>':P603_ID_REGION = 3'
,p_plug_display_when_cond2=>'PLSQL'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
,p_ai_enabled=>false
,p_updated_on=>wwv_flow_imp.dz('20260603144655Z')
,p_updated_by=>'JBALCAZAR'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(446748790772575803)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'MFERRIN'
,p_internal_uid=>446748790772575803
,p_updated_on=>wwv_flow_imp.dz('20260603144655Z')
,p_updated_by=>'JBALCAZAR'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(446748838464575804)
,p_db_column_name=>'COSTO'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Costo'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(446748935164575805)
,p_db_column_name=>'DOCUMENTO'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>unistr('N\00EDmero Orden')
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(446749112240575806)
,p_db_column_name=>'TIPO'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Tipo'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(446749217481575807)
,p_db_column_name=>'TIPO_ORIGEN'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Tipo Origen'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(446749275119575808)
,p_db_column_name=>'BODEGA'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Bodega'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(446749408170575809)
,p_db_column_name=>'PRODUCTO'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'Producto'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(446749514205575810)
,p_db_column_name=>'DOCUMENTO_ORIGEN'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>'Documento Origen'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(446824935722072584)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'2018944'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'DOCUMENTO_ORIGEN:TIPO_ORIGEN:DOCUMENTO:TIPO:BODEGA:PRODUCTO:COSTO:'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(451453177289529867)
,p_plug_name=>'SALDOS DE STOCK CON VALOR 0'
,p_parent_plug_id=>wwv_flow_imp.id(430620330181493187)
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(112813843178917343)
,p_plug_display_sequence=>240
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'WITH HISTORIAL_MENSUAL AS (',
'    SELECT',
'        INDCT AS TIPO,',
'        INMCU AS BODEGA,',
'        INITM AS CODIGO_INTERNO,',
'        CODIGOPRODUCTO CODIGO_PRODUCTO,',
'        ',
unistr('        -- Selecci\00F3n din\00E1mica del Monto (Amount - Net Posting) seg\00FAn el mes actual'),
'        SUM(CASE EXTRACT(MONTH FROM SYSDATE)',
'            WHEN 1 THEN INAN01 WHEN 2 THEN INAN02 WHEN 3 THEN INAN03',
'            WHEN 4 THEN INAN04 WHEN 5 THEN INAN05 WHEN 6 THEN INAN06',
'            WHEN 7 THEN INAN07 WHEN 8 THEN INAN08 WHEN 9 THEN INAN09',
'            WHEN 10 THEN INAN10 WHEN 11 THEN INAN11 WHEN 12 THEN INAN12',
'        END)/100 AS MONTO_NETO,',
'',
unistr('        -- Selecci\00F3n din\00E1mica de la Cantidad (Net Quantity) seg\00FAn el mes actual'),
'        SUM(CASE EXTRACT(MONTH FROM SYSDATE)',
'            WHEN 1 THEN INNQ01 WHEN 2 THEN INNQ02 WHEN 3 THEN INNQ03',
'            WHEN 4 THEN INNQ04 WHEN 5 THEN INNQ05 WHEN 6 THEN INNQ06',
'            WHEN 7 THEN INNQ07 WHEN 8 THEN INNQ08 WHEN 9 THEN INNQ09',
'            WHEN 10 THEN INNQ10 WHEN 11 THEN INNQ11 WHEN 12 THEN INNQ12',
'        END) AS CANTIDAD_NETA',
'',
'    FROM',
'        PRODDTA.F41112@jdedtadl',
'    INNER JOIN ',
'        DATA.VT_JDE_PRODUCTOS ON INITM = CODIGOCORTO',
'    WHERE',
unistr('        -- Extrae los \00FAltimos 2 d\00EDgitos del a\00F1o actual (Ej. 2026 -> 26)'),
'        INFY = TO_NUMBER(TO_CHAR(SYSDATE, ''YY''))',
'        AND INMCU IN ( SELECT MCMCU FROM PRODDTA.F0006@jdedtadl WHERE MCCO = ''00001'' AND MCRP20 = :P603_BDG_LOGISTICA)',
'    GROUP BY',
'        INDCT, INMCU, INITM, CODIGOPRODUCTO',
')',
'',
unistr('-- Filtramos buscando la anomal\00EDa: Hubo valor financiero, pero cero unidades movidas'),
'SELECT * FROM HISTORIAL_MENSUAL',
'WHERE',
'    CANTIDAD_NETA = 0',
'    AND MONTO_NETO != 0;'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_display_condition_type=>'EXPRESSION'
,p_plug_display_when_condition=>':P603_ID_REGION = 13'
,p_plug_display_when_cond2=>'PLSQL'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(451453237857529868)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'TOP_AND_BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'MFERRIN'
,p_internal_uid=>451453237857529868
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(451453369675529869)
,p_db_column_name=>'TIPO'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Tipo'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(451453449363529870)
,p_db_column_name=>'BODEGA'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Bodega'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(451453605660529871)
,p_db_column_name=>'CODIGO_INTERNO'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Codigo Interno'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(451453649280529872)
,p_db_column_name=>'MONTO_NETO'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Monto Neto'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G990D00'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(451453804798529873)
,p_db_column_name=>'CANTIDAD_NETA'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Cantidad Neta'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D0000'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(453372629436372875)
,p_db_column_name=>'CODIGO_PRODUCTO'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'Codigo Producto'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(451505231373874339)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'2065747'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'BODEGA:CODIGO_PRODUCTO:MONTO_NETO:CANTIDAD_NETA:'
,p_sum_columns_on_break=>'MONTO_NETO:CANTIDAD_NETA'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(478568411040003570)
,p_plug_name=>'DUPLICIDAD EN TRANSFERENCIA ENTRE BODEGAS'
,p_parent_plug_id=>wwv_flow_imp.id(430620330181493187)
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(112813843178917343)
,p_plug_display_sequence=>130
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'WITH FECHA AS (',
unistr('    -- Mantenemos tu fecha l\00EDmite'),
'    SELECT (TO_NUMBER(TO_CHAR(SYSDATE - 1, ''YYYYDDD'')) - 1900000) AS F FROM DUAL',
'),',
'BODEGAS AS (',
'    -- Filtro de bodegas',
'    SELECT MCMCU AS CODIGO_BODEGA',
'    FROM PRODDTA.F0006@jdedtadl',
'    WHERE MCCO = ''00001'' AND MCRP20 = :P603_BDG_LOGISTICA',
'),',
'MT_OT AS (',
unistr('    -- 1. Contamos cu\00E1ntas L\00CDNEAS tiene cada producto en la Orden de Compra'),
'    SELECT /*+ DRIVING_SITE(po) INDEX(po F4311_4) */',
'        PO.PDDOCO AS DOCUMENTO,',
'        PO.PDDCTO AS TIPO,',
'        PO.PDITM AS PRODUCTO_CORTO,',
'        po.PDLITM AS PRODUCTO,',
'        po.PDRORN AS RELACIONADO,',
'        po.PDMCU AS BODEGA,',
'        COUNT(*) AS LINEAS',
'    FROM PRODDTA.F4311@jdedtadl po',
'    INNER JOIN BODEGAS BDG ON BDG.CODIGO_BODEGA = PO.PDMCU',
'    WHERE PO.PDDCTO IN (''MT'',''OT'')',
'      AND PO.PDTRDJ >= (SELECT F FROM FECHA)',
'    GROUP BY',
'        PO.PDDOCO,',
'        PO.PDDCTO,',
'        PO.PDITM,',
'        PO.PDLITM,',
'        PO.PDRORN,',
'        PO.PDMCU',
'),',
'DT_ST AS (',
unistr('    -- 2. Contamos cu\00E1ntas L\00CDNEAS tiene el mismo producto en la Orden de Venta'),
'    SELECT /*+ DRIVING_SITE(SO) INDEX(SO F4211_0) */',
'        SO.SDRORN AS RELACIONADO,',
'        SO.SDDOCO AS DOCUMENTO,',
'        SO.SDDCTO AS TIPO,',
'        SO.SDITM AS PRODUCTO_CORTO,',
'        SO.SDLITM AS PRODUCTO,',
'        SO.SDMCU AS BODEGA,',
'        COUNT(SO.SDLNID) AS LINEAS',
'    FROM PRODDTA.F4211@jdedtadl SO',
'    WHERE SO.SDDOCO IN (SELECT RELACIONADO FROM MT_OT)',
'        AND SO.SDDCTO IN (''DT'',''ST'')',
'        AND SO.SDKCOO = ''00001''',
'        AND SO.SDTRDJ >= (SELECT F FROM FECHA)',
'    GROUP BY',
'        SO.SDRORN,',
'        SO.SDDOCO,',
'        SO.SDDCTO,',
'        SO.SDITM,',
'        SO.SDLITM,',
'        SO.SDMCU',
')',
unistr('-- 3. Cruzamos los conteos de l\00EDneas por producto y mostramos los descuadres'),
'SELECT',
'    C.DOCUMENTO,',
'    C.TIPO,',
'    C.BODEGA,',
'    C.RELACIONADO,',
'    NVL(V.TIPO, ''N/A'') AS TIPO_RELACIONADO,',
'    V.BODEGA AS BODEGA_RELACIONAD,',
'    C.PRODUCTO,',
'    C.LINEAS,',
'    NVL(V.LINEAS, 0) AS LINEAS_RELACIONADO,',
'    (C.LINEAS - NVL(V.LINEAS, 0)) AS DIFERENCIA_DE_LINEAS',
'FROM DT_ST C',
'JOIN MT_OT V ON C.DOCUMENTO = V.RELACIONADO AND C.PRODUCTO_CORTO = V.PRODUCTO_CORTO',
'WHERE (C.LINEAS - NVL(V.LINEAS, 0)) <> 0',
'ORDER BY C.DOCUMENTO, C.PRODUCTO;'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_display_condition_type=>'EXPRESSION'
,p_plug_display_when_condition=>':P603_ID_REGION = 2'
,p_plug_display_when_cond2=>'PLSQL'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
,p_ai_enabled=>false
,p_updated_on=>wwv_flow_imp.dz('20260427110740Z')
,p_updated_by=>'JBALCAZAR'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(478568492271003571)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'MFERRIN'
,p_internal_uid=>478568492271003571
,p_updated_on=>wwv_flow_imp.dz('20260427110740Z')
,p_updated_by=>'JBALCAZAR'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(478568538737003572)
,p_db_column_name=>'BODEGA'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Bodega'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(478568698123003573)
,p_db_column_name=>'DOCUMENTO'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>unistr('N\00FAmero de orden')
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(478568766533003574)
,p_db_column_name=>'TIPO'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Tipo'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(478568895863003575)
,p_db_column_name=>'PRODUCTO'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Producto'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(478568943259003576)
,p_db_column_name=>'RELACIONADO'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Relacionado'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(478569051956003577)
,p_db_column_name=>'LINEAS'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'Lineas'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(478569201968003578)
,p_db_column_name=>'TIPO_RELACIONADO'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>'Tipo Relacionado'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(478569299442003579)
,p_db_column_name=>'BODEGA_RELACIONAD'
,p_display_order=>80
,p_column_identifier=>'H'
,p_column_label=>'Bodega Relacionad'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(478569338833003580)
,p_db_column_name=>'LINEAS_RELACIONADO'
,p_display_order=>90
,p_column_identifier=>'I'
,p_column_label=>'Lineas Relacionado'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(478569508871003581)
,p_db_column_name=>'DIFERENCIA_DE_LINEAS'
,p_display_order=>100
,p_column_identifier=>'J'
,p_column_label=>'Diferencia De Lineas'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(478593777087018108)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'2336632'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'BODEGA:DOCUMENTO:TIPO:PRODUCTO:RELACIONADO:LINEAS:TIPO_RELACIONADO:BODEGA_RELACIONAD:LINEAS_RELACIONADO:DIFERENCIA_DE_LINEAS'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(434153656030228588)
,p_plug_name=>'Activos Fijos'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(38289867500120143)
,p_plug_display_sequence=>90
,p_location=>null
,p_plug_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_plug_display_when_condition=>'P603_MODULO'
,p_plug_display_when_cond2=>'ACTFI'
,p_ai_enabled=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
,p_updated_on=>wwv_flow_imp.dz('20260427141904Z')
,p_updated_by=>'JBALCAZAR'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(434153859675228590)
,p_plug_name=>unistr('ACTIVOS FIJOS QUE EST\00C1N PENDIENTES DE ACTIVACI\00D3N ')
,p_parent_plug_id=>wwv_flow_imp.id(434153656030228588)
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(112813843178917343)
,p_plug_display_sequence=>20
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT /*+ DRIVING_SITE(gl) */',
'    gl.GLDOC AS DOCUMENTO,',
'    gl.GLDCT AS TIPO,',
'    TRIM(gl.GLANI) AS CUENTA,',
'    TRIM(gl.GLEXA) AS EXPLICACION,',
'    TRIM(gl.GLEXR) AS REFERENCIA,',
'',
'    TRIM(gl.GLASID) AS ID_ACT_CONTABLE,',
'    TO_DATE(TO_CHAR(1900000 + gl.GLDGJ), ''YYYYDDD'') AS FECHA_CONTABLE,',
'',
'    gl.GLBRE AS EST_ACT_FIJO',
'',
'FROM',
'    PRODDTA.F0911@jdedtadl gl',
'WHERE',
'    gl.GLKCO = ''00001''',
'    AND gl.GLPOST = ''P''',
'    AND gl.GLBRE = '' ''',
'    AND gl.GLLT = ''AA''',
unistr('    AND gl.GLFY = TO_NUMBER(TO_CHAR(SYSDATE, ''YYYY'')) - 2000 -- A\00F1o fiscal actual'),
'    AND (',
'        (gl.GLPN = EXTRACT(MONTH FROM SYSDATE)-1 AND :P603_EN_VENT_ANT = 1)',
'        OR',
'        (gl.GLPN = EXTRACT(MONTH FROM SYSDATE) AND :P603_EN_VENT_ANT = 0)',
'    )',
'    AND TRIM(gl.GLOBJ) IN (''12102'', ''12103'', ''12104'', ''12105'', ''12106'')',
'    AND gl.GLGLC IN (''AT01'',''AT02'',''AT03'',''AT04'')',
'    AND gl.GLICUT <> ''X ''',
'    AND gl.GLDCT = ''OV''',
'',
'ORDER BY',
'    gl.GLDGJ DESC,',
'    gl.GLDOC ASC'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_display_condition_type=>'EXPRESSION'
,p_plug_display_when_condition=>':P603_ID_REGION = 2'
,p_plug_display_when_cond2=>'PLSQL'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
,p_ai_enabled=>false
,p_updated_on=>wwv_flow_imp.dz('20260506172634Z')
,p_updated_by=>'JBALCAZAR'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(434153956730228591)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'MFERRIN'
,p_internal_uid=>434153956730228591
,p_updated_on=>wwv_flow_imp.dz('20260506172634Z')
,p_updated_by=>'JBALCAZAR'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(434154128688228593)
,p_db_column_name=>'TIPO'
,p_display_order=>20
,p_column_identifier=>'A'
,p_column_label=>'Tipo'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(434154987560228601)
,p_db_column_name=>'DOCUMENTO'
,p_display_order=>80
,p_column_identifier=>'C'
,p_column_label=>'Documento'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(434155046961228602)
,p_db_column_name=>'CUENTA'
,p_display_order=>90
,p_column_identifier=>'D'
,p_column_label=>'Cuenta'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(434155147396228603)
,p_db_column_name=>'EXPLICACION'
,p_display_order=>100
,p_column_identifier=>'E'
,p_column_label=>'Explicacion'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(434155306579228604)
,p_db_column_name=>'REFERENCIA'
,p_display_order=>110
,p_column_identifier=>'F'
,p_column_label=>'Referencia'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(434155393662228605)
,p_db_column_name=>'ID_ACT_CONTABLE'
,p_display_order=>120
,p_column_identifier=>'G'
,p_column_label=>'Id Act Contable'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(434155546587228607)
,p_db_column_name=>'FECHA_CONTABLE'
,p_display_order=>140
,p_column_identifier=>'I'
,p_column_label=>'Fecha Contable'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(434155693573228608)
,p_db_column_name=>'EST_ACT_FIJO'
,p_display_order=>150
,p_column_identifier=>'J'
,p_column_label=>'Est Act Fijo'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(434983909621751690)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'1900533'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'TIPO:DOCUMENTO:CUENTA:EXPLICACION:REFERENCIA:ID_ACT_CONTABLE:FECHA_CONTABLE:EST_ACT_FIJO'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(434155776979228609)
,p_plug_name=>unistr('12501.01 QUE TENGA FECHA TRANSACCI\00D3N <90 D\00CDAS')
,p_parent_plug_id=>wwv_flow_imp.id(434153656030228588)
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(112813843178917343)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT /*+ DRIVING_SITE(gl) */',
'    gl.GLDOC AS DOCUMENTO,',
'    gl.GLDCT AS TIPO,',
'    TRIM(gl.GLANI) AS CUENTA,',
'    TRIM(gl.GLEXA) AS EXPLICACION,',
'    TRIM(gl.GLEXR) AS REFERENCIA,',
'',
'    TRIM(gl.GLASID) AS ID_ACT_CONTABLE,',
'',
'    TO_DATE(TO_CHAR(1900000 + gl.GLDGJ), ''YYYYDDD'') AS FECHA_CONTABLE,',
'',
'    gl.GLBRE AS EST_ACT_FIJO',
'',
'FROM',
'    PRODDTA.F0911@jdedtadl gl',
'WHERE',
'    gl.GLKCO = ''00001''',
'    AND gl.GLPOST = ''P''',
'    AND gl.GLBRE = '' ''',
'    AND gl.GLLT = ''AA''',
unistr('    AND gl.GLFY = TO_NUMBER(TO_CHAR(SYSDATE, ''YYYY'')) - 2000 -- A\00F1o fiscal actual'),
'    AND (',
'        (gl.GLPN = EXTRACT(MONTH FROM SYSDATE)-1 AND :P603_EN_VENT_ANT = 1)',
'        OR',
'        (gl.GLPN = EXTRACT(MONTH FROM SYSDATE) AND :P603_EN_VENT_ANT = 0)',
'    )',
'    AND gl.GLOBJ = ''12501''',
'    AND gl.GLGLC = ''SV22''',
'    AND gl.GLICUT <> ''X ''',
'    AND gl.GLDCT = ''OV''',
'',
'ORDER BY',
'    gl.GLDGJ DESC,',
'    gl.GLDOC ASC'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_display_condition_type=>'EXPRESSION'
,p_plug_display_when_condition=>':P603_ID_REGION = 1'
,p_plug_display_when_cond2=>'PLSQL'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
,p_ai_enabled=>false
,p_updated_on=>wwv_flow_imp.dz('20260506172609Z')
,p_updated_by=>'JBALCAZAR'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(434155870126228610)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'MFERRIN'
,p_internal_uid=>434155870126228610
,p_updated_on=>wwv_flow_imp.dz('20260506172609Z')
,p_updated_by=>'JBALCAZAR'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(434974302505746961)
,p_db_column_name=>'TIPO'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Tipo'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(434974462822746963)
,p_db_column_name=>'DOCUMENTO'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Documento'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(434974568167746964)
,p_db_column_name=>'CUENTA'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Cuenta'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(434974698956746965)
,p_db_column_name=>'EXPLICACION'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Explicacion'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(434974794485746966)
,p_db_column_name=>'REFERENCIA'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'Referencia'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(434974842256746967)
,p_db_column_name=>'ID_ACT_CONTABLE'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>'Id Act Contable'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(434975098745746969)
,p_db_column_name=>'FECHA_CONTABLE'
,p_display_order=>90
,p_column_identifier=>'I'
,p_column_label=>'Fecha Contable'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(434975211320746970)
,p_db_column_name=>'EST_ACT_FIJO'
,p_display_order=>100
,p_column_identifier=>'J'
,p_column_label=>'Est Act Fijo'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(434989175219953575)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'1900586'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'TIPO:DOCUMENTO:CUENTA:EXPLICACION:REFERENCIA:ID_ACT_CONTABLE:FECHA_CONTABLE:EST_ACT_FIJO'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(434975693406746975)
,p_plug_name=>unistr('DEPRECIACI\00D3N DEL MES REALIZADA')
,p_parent_plug_id=>wwv_flow_imp.id(434153656030228588)
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(112813843178917343)
,p_plug_display_sequence=>30
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'WITH FERIADOS AS (',
unistr('    -- (Tu l\00F3gica de feriados se mantiene igual)'),
'    SELECT TO_DATE(LPAD(TRIM(VALOR), 2, ''0'') || ''/'' || LPAD(TRIM(VALOR2), 2, ''0'') || ''/'' || EXTRACT(YEAR FROM SYSDATE), ''DD/MM/YYYY'') AS FECHA_FERIADO',
'    FROM DATA.T_CORP_UDC',
'    WHERE ID_CABECERA = ''ADT_FERIAD'' AND CODIGOCOMPANIA = ''00001'' AND ACTIVO = 1',
'),',
'QUINTO_DIA_HABIL AS (',
unistr('    -- (Tu l\00F3gica de quinto d\00EDa se mantiene igual)'),
'    SELECT MAX(FECHA_EVAL) AS FECHA FROM (',
'        SELECT FECHA_EVAL, ROW_NUMBER() OVER (ORDER BY FECHA_EVAL DESC) AS POSICION',
'        FROM (',
'            SELECT TRUNC(LAST_DAY(SYSDATE)) - LEVEL + 1 AS FECHA_EVAL',
'            FROM DUAL CONNECT BY LEVEL <= TO_CHAR(LAST_DAY(SYSDATE), ''DD'')',
'        )',
'        WHERE TO_CHAR(FECHA_EVAL, ''DY'', ''NLS_DATE_LANGUAGE=ENGLISH'') NOT IN (''SAT'', ''SUN'')',
'          AND FECHA_EVAL NOT IN (SELECT FECHA_FERIADO FROM FERIADOS)',
'    ) WHERE POSICION = 5',
')',
'',
unistr('SELECT ''NO EXISTE DEPRECIACI\00D3N PARA EL MES ACTUAL'' AS ESTADO_DEPRECIACION'),
'FROM DUAL',
'WHERE NOT EXISTS (',
'    SELECT 1 FROM PRODDTA.F0911@jdedtadl',
'    WHERE GLKCO = ''00001'' AND GLPOST = ''P'' AND GLLT = ''AA''',
'      AND GLFY = TO_NUMBER(TO_CHAR(SYSDATE, ''YYYY'')) - 2000',
'      AND GLPN = EXTRACT(MONTH FROM SYSDATE)',
'      AND GLICUT = ''X '' AND GLSUB = ''02''',
')',
'AND TRUNC(SYSDATE) > (SELECT FECHA FROM QUINTO_DIA_HABIL)',
'UNION ALL',
'',
unistr('SELECT ''NO EXISTE DEPRECIACI\00D3N PARA EL MES ANTERIOR'' AS ESTADO_DEPRECIACION'),
'FROM DUAL',
'WHERE NOT EXISTS (',
'    SELECT 1 FROM PRODDTA.F0911@jdedtadl',
'    WHERE GLKCO = ''00001'' AND GLPOST = ''P'' AND GLLT = ''AA''',
'      AND GLFY = TO_NUMBER(TO_CHAR(SYSDATE, ''YYYY'')) - 2000',
'      AND GLPN = EXTRACT(MONTH FROM SYSDATE) - 1',
'      AND GLICUT = ''X '' AND GLSUB = ''02''',
')',
'AND TRUNC(SYSDATE) <= (SELECT FECHA FROM QUINTO_DIA_HABIL);'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_display_condition_type=>'EXPRESSION'
,p_plug_display_when_condition=>':P603_ID_REGION = 3'
,p_plug_display_when_cond2=>'PLSQL'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(434975801287746976)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'MFERRIN'
,p_internal_uid=>434975801287746976
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(434976634737746985)
,p_db_column_name=>'ESTADO_DEPRECIACION'
,p_display_order=>10
,p_column_identifier=>'I'
,p_column_label=>'Estado Depreciacion'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(435318916226895227)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'1903883'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'ESTADO_DEPRECIACION:'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(434977053211746989)
,p_plug_name=>unistr('DIFERENCIAS DE DEPRECIACI\00D3N Y CONTABLE POR ACTIVO')
,p_parent_plug_id=>wwv_flow_imp.id(434153656030228588)
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(112813843178917343)
,p_plug_display_sequence=>40
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'WITH SALDOS_F1202 AS (',
'    SELECT /*+ MATERIALIZE */',
'        FLNUMB AS Numero_Corto,',
'        FLOBJ AS Cuenta_Objeto,',
'        FLSUB AS Cuenta_Auxiliar,',
'        (FLAPYC / 100) AS Acumulado_Anterior,',
'        ((FLAPYC + FLAN01 + FLAN02 + FLAN03 + FLAN04 + FLAN05 + FLAN06 + FLAN07 +',
'          FLAN08 + FLAN09 + FLAN10 + FLAN11 + FLAN12) / 100) AS F1202_AsOf_Febrero',
'    FROM PRODDTA.F1202@jdedtadl',
'    WHERE FLLT = ''AA''',
'      AND FLFY = TO_NUMBER(TO_CHAR(SYSDATE, ''YYYY'')) - 2000',
'      AND FLSUB = ''02      ''',
'      AND FLAPYC > 0',
'),',
'CONTABLE_F0911 AS (',
'    SELECT /*+ DRIVING_SITE(gl) */',
'        fa.FANUMB AS Numero_Corto,',
'        gl.GLOBJ AS Cuenta_Objeto,',
'        gl.GLSUB AS Cuenta_Auxiliar,',
'        SUM(gl.GLAA / 100) AS F0911_YTD',
'    FROM PRODDTA.F1201@jdedtadl fa',
'    INNER JOIN PRODDTA.F0911@jdedtadl gl',
'       -- Ajuste para GLASID de 25 caracteres:',
unistr('       -- 1. Formato asterisco: * + 8 d\00EDgitos + espacios hasta 25'),
'       -- 2. Formato ASID: ID + espacios hasta 25',
'       ON (gl.GLASID = RPAD(''*'' || LPAD(TO_CHAR(fa.FANUMB), 8, ''0''), 25, '' '')',
'           OR gl.GLASID = RPAD(fa.FAASID, 25, '' ''))',
'    WHERE gl.GLKCO = ''00001''',
'      AND gl.GLPOST = ''P''',
'      AND gl.GLLT = ''AA''',
'      AND gl.GLFY = TO_NUMBER(TO_CHAR(SYSDATE, ''YYYY'')) - 2000',
'      AND gl.GLPN <= EXTRACT(MONTH FROM SYSDATE)',
'      AND gl.GLICUT = ''X''',
'      AND gl.GLSUB = ''02      ''',
'      -- Filtro de empuje para reducir el set de la F0911',
'      AND EXISTS (SELECT 1 FROM SALDOS_F1202 s WHERE s.Numero_Corto = fa.FANUMB)',
'    GROUP BY fa.FANUMB, gl.GLOBJ, gl.GLSUB',
')',
'SELECT',
'    S.Numero_Corto AS Activo_JDE,',
'    TRIM(S.Cuenta_Objeto) AS Objeto,',
'    TRIM(S.Cuenta_Auxiliar) AS Auxiliar,',
unistr('    S.Acumulado_Anterior AS "Saldo a\00F1o anterior",'),
'    (S.Acumulado_Anterior + NVL(C.F0911_YTD, 0)) AS Contable_Total,',
'    S.F1202_AsOf_Febrero AS Modulo_Total_AsOf,',
'    ((S.Acumulado_Anterior + NVL(C.F0911_YTD, 0)) - S.F1202_AsOf_Febrero) AS Diferencia_Total',
'FROM SALDOS_F1202 S',
'LEFT JOIN CONTABLE_F0911 C',
'    ON S.Numero_Corto = C.Numero_Corto',
'   AND S.Cuenta_Objeto = C.Cuenta_Objeto',
'   AND S.Cuenta_Auxiliar = C.Cuenta_Auxiliar',
'WHERE ABS((S.Acumulado_Anterior + NVL(C.F0911_YTD, 0)) - S.F1202_AsOf_Febrero) > 0',
'ORDER BY S.Numero_Corto ASC;'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_display_condition_type=>'EXPRESSION'
,p_plug_display_when_condition=>':P603_ID_REGION = 4'
,p_plug_display_when_cond2=>'PLSQL'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
,p_ai_enabled=>false
,p_updated_on=>wwv_flow_imp.dz('20260427154200Z')
,p_updated_by=>'JBALCAZAR'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(434977198125746990)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'TOP_AND_BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'MFERRIN'
,p_internal_uid=>434977198125746990
,p_updated_on=>wwv_flow_imp.dz('20260427154200Z')
,p_updated_by=>'JBALCAZAR'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(436580842104582171)
,p_db_column_name=>'ACTIVO_JDE'
,p_display_order=>10
,p_column_identifier=>'B'
,p_column_label=>'Activo Jde'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(436581005878582172)
,p_db_column_name=>'OBJETO'
,p_display_order=>20
,p_column_identifier=>'C'
,p_column_label=>'Objeto'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(436581815913582180)
,p_db_column_name=>'AUXILIAR'
,p_display_order=>90
,p_column_identifier=>'K'
,p_column_label=>'Auxiliar'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(436581994292582182)
,p_db_column_name=>'MODULO_TOTAL_ASOF'
,p_display_order=>110
,p_column_identifier=>'M'
,p_column_label=>'Modulo Total Asof'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(436582116581582183)
,p_db_column_name=>'DIFERENCIA_TOTAL'
,p_display_order=>120
,p_column_identifier=>'N'
,p_column_label=>'Diferencia Total'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(436582138183582184)
,p_db_column_name=>unistr('Saldo a\00F1o anterior')
,p_display_order=>130
,p_column_identifier=>'O'
,p_column_label=>unistr('Saldo A\00F1o Anterior')
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(436582304968582185)
,p_db_column_name=>'CONTABLE_TOTAL'
,p_display_order=>140
,p_column_identifier=>'P'
,p_column_label=>'Contable Total'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(435354498459366029)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'1904239'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>unistr('ACTIVO_JDE:OBJETO:AUXILIAR:Saldo a\00F1o anterior:CONTABLE_TOTAL:MODULO_TOTAL_ASOF:DIFERENCIA_TOTAL:')
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(434977358816746992)
,p_plug_name=>'ACTIVOS FIJOS QUE NO TENGAN VALOR RESUDIAL EN EL MAESTRO'
,p_parent_plug_id=>wwv_flow_imp.id(434153656030228588)
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(112813843178917343)
,p_plug_display_sequence=>50
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT',
'    af.FANUMB AS Numero_Corto_JDE,',
'    TRIM(af.FAASID) AS ID_Activo,',
unistr('    TRIM(af.FADL01) AS Categor\00EDa,'),
'    TRIM(af.FADL02)||'' - ''||TRIM(af.FADSCC) AS Descripcion_Activo,',
'    TRIM(af.FAACL1) AS Clase_Activo,',
'    TRIM(af.FAMCU) AS Centro_Costo,',
'',
'    (ba.FLTKER / 100) AS Valor_Residual,',
'',
'    TO_DATE(TO_CHAR(1900000 + ba.FLUPMJ), ''YYYYDDD'') AS Fecha_Ultima_Actualizacion',
'',
'FROM',
'    PRODDTA.F1201@jdedtadl af',
'',
'INNER JOIN',
'    PRODDTA.F1202@jdedtadl ba',
'    ON af.FANUMB = ba.FLNUMB',
'    AND af.FAAMCU = ba.FLMCU',
'    AND af.FAAOBJ = ba.FLOBJ',
'    AND af.FAASUB = ba.FLSUB',
'',
'WHERE',
unistr('    --af.FADL01 IN (''MAQUINARIA'', ''VEH\00CDCULOS'', ''CONSTRUCCIONES'')'),
'    af.FAACL1 IN (''MAQ'',''EDI'',''VEH'')',
'    AND af.FADAJ > 112001',
'    AND af.FAEQST NOT IN (''FO'')',
'    --AND af.FAEQST = ''AV''',
'',
'    AND ba.FLLT = ''AA''    -- Solo saldos reales',
'    AND ba.FLFY = TO_NUMBER(TO_CHAR(SYSDATE, ''YYYY'')) - 2000',
'',
'    AND ba.FLTKER = 0',
''))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_display_condition_type=>'EXPRESSION'
,p_plug_display_when_condition=>':P603_ID_REGION = 5'
,p_plug_display_when_cond2=>'PLSQL'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
,p_ai_enabled=>false
,p_updated_on=>wwv_flow_imp.dz('20260604195904Z')
,p_updated_by=>'JBALCAZAR'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(434977463437746993)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'TOP_AND_BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'MFERRIN'
,p_internal_uid=>434977463437746993
,p_updated_on=>wwv_flow_imp.dz('20260604195904Z')
,p_updated_by=>'JBALCAZAR'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(436580083324582163)
,p_db_column_name=>'NUMERO_CORTO_JDE'
,p_display_order=>10
,p_column_identifier=>'B'
,p_column_label=>'Numero Corto Jde'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(436580137651582164)
,p_db_column_name=>'ID_ACTIVO'
,p_display_order=>20
,p_column_identifier=>'C'
,p_column_label=>'Id Activo'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(436580268227582165)
,p_db_column_name=>'DESCRIPCION_ACTIVO'
,p_display_order=>30
,p_column_identifier=>'D'
,p_column_label=>'Descripcion Activo'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(436580449760582167)
,p_db_column_name=>'CENTRO_COSTO'
,p_display_order=>50
,p_column_identifier=>'F'
,p_column_label=>'Centro Costo'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(436580711224582169)
,p_db_column_name=>'FECHA_ULTIMA_ACTUALIZACION'
,p_display_order=>70
,p_column_identifier=>'H'
,p_column_label=>'Fecha Ultima Actualizacion'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(436580729067582170)
,p_db_column_name=>unistr('CATEGOR\00CDA')
,p_display_order=>80
,p_column_identifier=>'I'
,p_column_label=>unistr('Categor\00EDa')
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(436582412572582186)
,p_db_column_name=>'CLASE_ACTIVO'
,p_display_order=>90
,p_column_identifier=>'J'
,p_column_label=>'Clase Activo'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(436583731851582200)
,p_db_column_name=>'VALOR_RESIDUAL'
,p_display_order=>100
,p_column_identifier=>'K'
,p_column_label=>'Valor Residual'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(435379163139377754)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'1904486'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>unistr('NUMERO_CORTO_JDE:ID_ACTIVO:CATEGOR\00CDA:CLASE_ACTIVO:DESCRIPCION_ACTIVO:VALOR_RESIDUAL:CENTRO_COSTO:FECHA_ULTIMA_ACTUALIZACION:')
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(434978588642747004)
,p_plug_name=>unistr('ACTIVOS FIJOS QUE NO TENGAN MISMO CENTRO DE COSTOS VS UBICACI\00D3N')
,p_parent_plug_id=>wwv_flow_imp.id(434153656030228588)
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(112813843178917343)
,p_plug_display_sequence=>70
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'WITH ULTIMA_UBICACION AS (',
'    SELECT',
'        FMNUMB,',
'        TRIM(FMLOC) AS Ubicacion_F1204,',
'        ROW_NUMBER() OVER (',
'            PARTITION BY FMNUMB',
'            ORDER BY FMDDTS DESC, FMUPMT DESC',
'        ) AS RN',
'    FROM',
'        PRODDTA.F1204@jdedtadl',
')',
'',
'SELECT',
'    af.FANUMB AS Numero_Corto_JDE,',
'    TRIM(af.FAASID) AS ID_Activo,',
unistr('    TRIM(af.FADL01) AS Categor\00EDa,'),
'    TRIM(af.FAACL1) AS Clase_Activo,',
'    TRIM(af.FADL02)||'' - ''||TRIM(af.FADSCC) AS Descripcion,',
'',
'    TRIM(af.FAMCU) AS Centro_Costo,',
'    loc.Ubicacion_F1204 AS Ubicacion_Fisica,',
'',
'    af.FAEQST AS Estado_Activo',
'',
'FROM',
'    PRODDTA.F1201@jdedtadl af',
'',
'INNER JOIN',
'    ULTIMA_UBICACION loc',
'    ON af.FANUMB = loc.FMNUMB',
'    AND loc.RN = 1',
'',
'WHERE',
unistr('    --af.FADL01 IN (''MAQUINARIA'', ''VEH\00CDCULOS'', ''CONSTRUCCIONES'')'),
'    af.FAACL1 IN (''MAQ'',''EDI'',''VEH'')',
'    --AND af.FAEQST NOT IN (''FO'')',
'    AND af.FAEQST = (''AV'')',
'',
'    AND trim(af.FAMCU) <> trim(loc.Ubicacion_F1204)'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_display_condition_type=>'EXPRESSION'
,p_plug_display_when_condition=>':P603_ID_REGION = 6'
,p_plug_display_when_cond2=>'PLSQL'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(434978639606747005)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'TOP_AND_BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'MFERRIN'
,p_internal_uid=>434978639606747005
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(434978766627747006)
,p_db_column_name=>'NUMERO_CORTO_JDE'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Numero Corto Jde'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(434978869509747007)
,p_db_column_name=>'ID_ACTIVO'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Id Activo'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(434979016364747008)
,p_db_column_name=>'DESCRIPCION'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Descripcion'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(434979039324747009)
,p_db_column_name=>'CENTRO_COSTO'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Centro Costo'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(434979207140747010)
,p_db_column_name=>'UBICACION_FISICA'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Ubicacion Fisica'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(436579912281582161)
,p_db_column_name=>'ESTADO_ACTIVO'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'Estado Activo'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(436579951836582162)
,p_db_column_name=>unistr('CATEGOR\00CDA')
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>unistr('Categor\00EDa')
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(436582523385582187)
,p_db_column_name=>'CLASE_ACTIVO'
,p_display_order=>80
,p_column_identifier=>'H'
,p_column_label=>'Clase Activo'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(436589762458598500)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'1916592'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>unistr('NUMERO_CORTO_JDE:ID_ACTIVO:CATEGOR\00CDA:CLASE_ACTIVO:DESCRIPCION:CENTRO_COSTO:UBICACION_FISICA:ESTADO_ACTIVO:')
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(436584633965582209)
,p_plug_name=>'Contabilidad'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(38289867500120143)
,p_plug_display_sequence=>100
,p_location=>null
,p_plug_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_plug_display_when_condition=>'P603_MODULO'
,p_plug_display_when_cond2=>'CONTA'
,p_ai_enabled=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
,p_updated_on=>wwv_flow_imp.dz('20260427160059Z')
,p_updated_by=>'JBALCAZAR'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(436584731903582210)
,p_plug_name=>'ASIENTOS DE HONORARIOS Y PROVISIONES DE COMERCIAL'
,p_parent_plug_id=>wwv_flow_imp.id(436584633965582209)
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(112813843178917343)
,p_plug_display_sequence=>80
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'WITH CUENTAS_REQUERIDAS AS (',
'    -- 1. Definimos el universo de cuentas que obligatoriamente deben tener un asiento JE',
'    SELECT ''63101'' AS Objeto, ''04'' AS Auxiliar FROM DUAL UNION ALL',
'    SELECT ''64101'' AS Objeto, ''15'' AS Auxiliar FROM DUAL UNION ALL',
'',
'    -- Los 4 auxiliares para la cuenta 41102',
'    SELECT ''41102'' AS Objeto, ''07'' AS Auxiliar FROM DUAL UNION ALL',
'    SELECT ''41102'' AS Objeto, ''08'' AS Auxiliar FROM DUAL UNION ALL',
'    SELECT ''41102'' AS Objeto, ''09'' AS Auxiliar FROM DUAL UNION ALL',
'    SELECT ''41102'' AS Objeto, ''11'' AS Auxiliar FROM DUAL',
')',
'',
'-- 2. Seleccionamos de nuestra lista virtual y filtramos las que NO existen en contabilidad',
'SELECT',
'    c.Objeto AS Cuenta_Objeto,',
'    c.Auxiliar AS Cuenta_Auxiliar,',
'    c.Objeto || ''.'' || c.Auxiliar AS Cuenta_Formateada,',
'    ''FALTA ASIENTO TIPO JE EN EL MES ACTUAL'' AS Estado_Alerta',
'',
'FROM',
'    CUENTAS_REQUERIDAS c',
'',
'WHERE NOT EXISTS (',
unistr('    -- 3. Buscamos si el asiento ya se registr\00F3 en la F0911'),
'    SELECT 1',
'    FROM PRODDTA.F0911@jdedtadl gl',
'    WHERE',
'        gl.GLOBJ = c.Objeto',
'        AND gl.GLSUB = c.Auxiliar',
'',
'        -- Filtros vitales de JD Edwards',
'        AND gl.GLDCT = ''JE''           -- Tipo de Documento: Journal Entry',
'        AND gl.GLLT = ''AA''            -- Moneda Base (evita falsos positivos con moneda extranjera)',
unistr('        AND gl.GLPOST = ''P''           -- \00A1IMPORTANTE! Validar que el asiento est\00E9 contabilizado'),
unistr('        AND gl.GLKCO = ''00001''        -- Compa\00F1\00EDa'),
'',
unistr('        -- Filtro din\00E1mico para buscar solo en el mes y a\00F1o en curso'),
'        AND gl.GLFY = TO_NUMBER(TO_CHAR(SYSDATE, ''YYYY'')) - 2000',
'        AND (',
'            (gl.GLPN = EXTRACT(MONTH FROM SYSDATE) AND :P603_EN_VENT_ANT = 0)',
'            OR',
'            (gl.GLPN = EXTRACT(MONTH FROM SYSDATE)-1 AND :P603_EN_VENT_ANT = 1)',
'        )',
')',
'ORDER BY c.Objeto,c.Auxiliar ;',
''))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_display_condition_type=>'EXPRESSION'
,p_plug_display_when_condition=>':P603_ID_REGION = 1'
,p_plug_display_when_cond2=>'PLSQL'
,p_ai_enabled=>false
,p_updated_on=>wwv_flow_imp.dz('20260514151348Z')
,p_updated_by=>'JBALCAZAR'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(436654734111617461)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'TOP_AND_BOTTOM_RIGHT'
,p_show_search_bar=>'N'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_enable_mail_download=>'Y'
,p_owner=>'MFERRIN'
,p_internal_uid=>436654734111617461
,p_updated_on=>wwv_flow_imp.dz('20260514151348Z')
,p_updated_by=>'JBALCAZAR'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(436655627930617470)
,p_db_column_name=>'CUENTA_OBJETO'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Cuenta Objeto'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(436655814269617471)
,p_db_column_name=>'CUENTA_AUXILIAR'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Cuenta Auxiliar'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(436655826887617472)
,p_db_column_name=>'CUENTA_FORMATEADA'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Cuenta Formateada'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(436655955982617473)
,p_db_column_name=>'ESTADO_ALERTA'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Estado Alerta'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(436662168597623598)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'1917316'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'CUENTA_OBJETO:CUENTA_AUXILIAR:CUENTA_FORMATEADA:ESTADO_ALERTA'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(436657129777617485)
,p_plug_name=>'ASIENTOS DE MUESTRAS'
,p_parent_plug_id=>wwv_flow_imp.id(436584633965582209)
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(112813843178917343)
,p_plug_display_sequence=>90
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'-- =========================================================================',
unistr('-- VALIDACI\00D3N 1: Verificar que exista el asiento ''JE'''),
'-- =========================================================================',
'SELECT ',
'    ''16200'' AS Centro_Costo,',
'    ''64101'' AS Objeto,',
'    ''04'' AS Auxiliar,',
'    ''FALTA EL ASIENTO TIPO [JE] PARA ESTA CUENTA'' AS Estado',
'FROM ',
'    DUAL',
'WHERE NOT EXISTS (',
'    SELECT 1 ',
'    FROM PRODDTA.F0911@jdedtadl gl',
'    WHERE ',
'        gl.GLMCU = LPAD(''16200'', 12, '' '')',
unistr('        AND gl.GLKCO = ''00001''        -- Compa\00F1\00EDa'),
'        AND gl.GLOBJ = ''64101''',
'        AND gl.GLSUB = ''04''',
'        --AND gl.GLAN8 = 1',
unistr('        AND gl.GLDCT = ''JE''           -- Buscamos espec\00EDficamente el JE'),
'        AND gl.GLLT = ''AA''',
'        AND gl.GLPOST = ''P''',
'        AND gl.GLFY = TO_NUMBER(TO_CHAR(SYSDATE, ''YYYY'')) - 2000',
'        AND (',
'            (gl.GLPN = EXTRACT(MONTH FROM SYSDATE) AND :P603_EN_VENT_ANT = 0)',
'            OR',
'            (gl.GLPN = EXTRACT(MONTH FROM SYSDATE)-1 AND :P603_EN_VENT_ANT = 1)',
'        )',
')',
'',
'UNION ALL',
'',
'-- =========================================================================',
unistr('-- VALIDACI\00D3N 2: Verificar que exista el recibo/cobro ''RC'''),
'-- =========================================================================',
'SELECT ',
'    ''16200'' AS Centro_Costo,',
'    ''64101'' AS Objeto,',
'    ''04'' AS Auxiliar,',
'    ''FALTA EL RECIBO TIPO [RC] PARA ESTA CUENTA'' AS Estado',
'FROM ',
'    DUAL',
'WHERE NOT EXISTS (',
'    SELECT 1 ',
'    FROM PRODDTA.F0911@jdedtadl gl',
'    WHERE ',
'        gl.GLMCU = LPAD(''16200'', 12, '' '')',
unistr('        AND gl.GLCO = ''00001''        -- Compa\00F1\00EDa'),
'        AND gl.GLOBJ = ''64101''',
'        AND gl.GLSUB = ''04''',
'        AND gl.GLAN8 = 1',
unistr('        AND gl.GLDCT = ''RC''           -- Buscamos espec\00EDficamente el RC'),
'        AND gl.GLLT = ''AA''',
'        AND gl.GLPOST = ''P''',
'        AND gl.GLFY = TO_NUMBER(TO_CHAR(SYSDATE, ''YYYY'')) - 2000',
'        AND (',
'            (gl.GLPN = EXTRACT(MONTH FROM SYSDATE) AND :P603_EN_VENT_ANT = 0)',
'            OR',
'            (gl.GLPN = EXTRACT(MONTH FROM SYSDATE)-1 AND :P603_EN_VENT_ANT = 1)',
'        )',
');'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_display_condition_type=>'EXPRESSION'
,p_plug_display_when_condition=>':P603_ID_REGION = 2'
,p_plug_display_when_cond2=>'PLSQL'
,p_ai_enabled=>false
,p_updated_on=>wwv_flow_imp.dz('20260603142837Z')
,p_updated_by=>'JBALCAZAR'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(436657291943617486)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'TOP_AND_BOTTOM_RIGHT'
,p_show_search_bar=>'N'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_enable_mail_download=>'Y'
,p_owner=>'MFERRIN'
,p_internal_uid=>436657291943617486
,p_updated_on=>wwv_flow_imp.dz('20260603142837Z')
,p_updated_by=>'JBALCAZAR'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(436657403942617487)
,p_db_column_name=>'CENTRO_COSTO'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Centro Costo'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(436657470484617488)
,p_db_column_name=>'OBJETO'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Objeto'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(436657578616617489)
,p_db_column_name=>'AUXILIAR'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Auxiliar'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(436657727662617491)
,p_db_column_name=>'ESTADO'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Estado'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(436684586398671360)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'1917540'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'CENTRO_COSTO:OBJETO:AUXILIAR:ESTADO'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(436657831345617492)
,p_plug_name=>'ASIENTOS DE FLETES'
,p_parent_plug_id=>wwv_flow_imp.id(436584633965582209)
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(112813843178917343)
,p_plug_display_sequence=>100
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'WITH CUENTAS_REQUERIDAS AS (',
'    -- 1. Definimos el universo de cuentas que obligatoriamente deben tener un asiento JE',
'    SELECT ''51102'' AS Objeto, ''01'' AS Auxiliar FROM DUAL',
')',
'',
'-- 2. Seleccionamos de nuestra lista virtual y filtramos las que NO existen en contabilidad',
'SELECT',
'    c.Objeto AS Cuenta_Objeto,',
'    c.Auxiliar AS Cuenta_Auxiliar,',
'    c.Objeto || ''.'' || c.Auxiliar AS Cuenta_Formateada,',
'    ''FALTA ASIENTO TIPO JE EN EL MES ACTUAL'' AS Estado_Alerta',
'',
'FROM',
'    CUENTAS_REQUERIDAS c',
'',
'WHERE NOT EXISTS (',
unistr('    -- 3. Buscamos si el asiento ya se registr\00F3 en la F0911'),
'    SELECT 1',
'    FROM PRODDTA.F0911@jdedtadl gl',
'    WHERE',
'        gl.GLOBJ = c.Objeto',
'        AND gl.GLSUB = c.Auxiliar',
'',
'        -- Filtros vitales de JD Edwards',
'        AND gl.GLDCT = ''JE''           -- Tipo de Documento: Journal Entry',
'        AND gl.GLLT = ''AA''            -- Moneda Base (evita falsos positivos con moneda extranjera)',
unistr('        AND gl.GLPOST = ''P''           -- \00A1IMPORTANTE! Validar que el asiento est\00E9 contabilizado'),
unistr('        AND gl.GLKCO = ''00001''        -- Compa\00F1\00EDa'),
'',
unistr('        -- Filtro din\00E1mico para buscar solo en el mes y a\00F1o en curso'),
'        AND gl.GLFY = TO_NUMBER(TO_CHAR(SYSDATE, ''YYYY'')) - 2000',
'        AND (',
'            (gl.GLPN = EXTRACT(MONTH FROM SYSDATE) AND :P603_EN_VENT_ANT = 0)',
'            OR',
'            (gl.GLPN = EXTRACT(MONTH FROM SYSDATE)-1 AND :P603_EN_VENT_ANT = 1)',
'        )',
')',
'ORDER BY c.Objeto,c.Auxiliar ;',
''))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_display_condition_type=>'EXPRESSION'
,p_plug_display_when_condition=>':P603_ID_REGION = 3'
,p_plug_display_when_cond2=>'PLSQL'
,p_ai_enabled=>false
,p_updated_on=>wwv_flow_imp.dz('20260514151748Z')
,p_updated_by=>'JBALCAZAR'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(436657945395617493)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'TOP_AND_BOTTOM_RIGHT'
,p_show_search_bar=>'N'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_enable_mail_download=>'Y'
,p_owner=>'MFERRIN'
,p_internal_uid=>436657945395617493
,p_updated_on=>wwv_flow_imp.dz('20260514151748Z')
,p_updated_by=>'JBALCAZAR'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(436658050035617494)
,p_db_column_name=>'CUENTA_OBJETO'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Cuenta Objeto'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(436658181202617495)
,p_db_column_name=>'CUENTA_AUXILIAR'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Cuenta Auxiliar'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(436658295859617496)
,p_db_column_name=>'CUENTA_FORMATEADA'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Cuenta Formateada'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(436658366522617497)
,p_db_column_name=>'ESTADO_ALERTA'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Estado Alerta'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(436704717583715008)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'1917741'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'CUENTA_OBJETO:CUENTA_AUXILIAR:CUENTA_FORMATEADA:ESTADO_ALERTA'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(436658487058617498)
,p_plug_name=>'ASIENTOS CUENTAS POR COBRAR TRANSPORTE'
,p_parent_plug_id=>wwv_flow_imp.id(436584633965582209)
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(112813843178917343)
,p_plug_display_sequence=>120
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'WITH CUENTAS_REQUERIDAS AS (',
'    -- 1. Definimos el universo de cuentas que obligatoriamente deben tener un asiento JE',
'    SELECT ''11305'' AS Objeto, ''09'' AS Auxiliar FROM DUAL',
')',
'',
'-- 2. Seleccionamos de nuestra lista virtual y filtramos las que NO existen en contabilidad',
'SELECT',
'    c.Objeto AS Cuenta_Objeto,',
'    c.Auxiliar AS Cuenta_Auxiliar,',
'    c.Objeto || ''.'' || c.Auxiliar AS Cuenta_Formateada,',
'    ''FALTA ASIENTO TIPO JE EN EL MES ACTUAL'' AS Estado_Alerta',
'',
'FROM',
'    CUENTAS_REQUERIDAS c',
'',
'WHERE NOT EXISTS (',
unistr('    -- 3. Buscamos si el asiento ya se registr\00F3 en la F0911'),
'    SELECT 1',
'    FROM PRODDTA.F0911@jdedtadl gl',
'    WHERE',
'        gl.GLOBJ = c.Objeto',
'        AND gl.GLSUB = c.Auxiliar',
'',
'        -- Filtros vitales de JD Edwards',
'        AND gl.GLDCT = ''JE''           -- Tipo de Documento: Journal Entry',
'        AND gl.GLLT = ''AA''            -- Moneda Base (evita falsos positivos con moneda extranjera)',
unistr('        AND gl.GLPOST = ''P''           -- \00A1IMPORTANTE! Validar que el asiento est\00E9 contabilizado'),
unistr('        AND gl.GLKCO = ''00001''        -- Compa\00F1\00EDa'),
'',
unistr('        -- Filtro din\00E1mico para buscar solo en el mes y a\00F1o en curso'),
'        AND gl.GLFY = TO_NUMBER(TO_CHAR(SYSDATE, ''YYYY'')) - 2000',
'        AND (',
'            (gl.GLPN = EXTRACT(MONTH FROM SYSDATE) AND :P603_EN_VENT_ANT = 0)',
'            OR',
'            (gl.GLPN = EXTRACT(MONTH FROM SYSDATE)-1 AND :P603_EN_VENT_ANT = 1)',
'        )',
')',
'ORDER BY c.Objeto,c.Auxiliar ;',
''))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_display_condition_type=>'EXPRESSION'
,p_plug_display_when_condition=>':P603_ID_REGION = 4'
,p_plug_display_when_cond2=>'PLSQL'
,p_ai_enabled=>false
,p_updated_on=>wwv_flow_imp.dz('20260514152946Z')
,p_updated_by=>'JBALCAZAR'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(436658582758617499)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'TOP_AND_BOTTOM_RIGHT'
,p_show_search_bar=>'N'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_enable_mail_download=>'Y'
,p_owner=>'MFERRIN'
,p_internal_uid=>436658582758617499
,p_updated_on=>wwv_flow_imp.dz('20260514152946Z')
,p_updated_by=>'JBALCAZAR'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(436658709395617500)
,p_db_column_name=>'CUENTA_OBJETO'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Cuenta Objeto'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(436658823347617501)
,p_db_column_name=>'CUENTA_AUXILIAR'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Cuenta Auxiliar'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(436658908908617502)
,p_db_column_name=>'CUENTA_FORMATEADA'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Cuenta Formateada'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(436659010865617503)
,p_db_column_name=>'ESTADO_ALERTA'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Estado Alerta'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(436713229305754202)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'1917827'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'CUENTA_OBJETO:CUENTA_AUXILIAR:CUENTA_FORMATEADA:ESTADO_ALERTA'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(436659057262617504)
,p_plug_name=>'ASIENTOS DE PROVISIONES'
,p_parent_plug_id=>wwv_flow_imp.id(436584633965582209)
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(112813843178917343)
,p_plug_display_sequence=>130
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'WITH CUENTAS_REQUERIDAS AS (',
'    -- 1. Definimos el universo de cuentas que obligatoriamente deben tener un asiento JE',
'    SELECT ''22502'' AS Objeto, ''11'' AS Auxiliar FROM DUAL UNION ALL',
'    SELECT ''22502'' AS Objeto, ''12'' AS Auxiliar FROM DUAL',
')',
'',
'-- 2. Seleccionamos de nuestra lista virtual y filtramos las que NO existen en contabilidad',
'SELECT',
'    c.Objeto AS Cuenta_Objeto,',
'    c.Auxiliar AS Cuenta_Auxiliar,',
'    c.Objeto || ''.'' || c.Auxiliar AS Cuenta_Formateada,',
'    ''FALTA ASIENTO TIPO JE EN EL MES ACTUAL'' AS Estado_Alerta',
'',
'FROM',
'    CUENTAS_REQUERIDAS c',
'',
'WHERE NOT EXISTS (',
unistr('    -- 3. Buscamos si el asiento ya se registr\00F3 en la F0911'),
'    SELECT 1',
'    FROM PRODDTA.F0911@jdedtadl gl',
'    WHERE',
'        gl.GLOBJ = c.Objeto',
'        AND gl.GLSUB = c.Auxiliar',
'',
'        -- Filtros vitales de JD Edwards',
'        AND gl.GLDCT = ''JE''           -- Tipo de Documento: Journal Entry',
'        AND gl.GLLT = ''AA''            -- Moneda Base (evita falsos positivos con moneda extranjera)',
unistr('        AND gl.GLPOST = ''P''           -- \00A1IMPORTANTE! Validar que el asiento est\00E9 contabilizado'),
unistr('        AND gl.GLKCO = ''00001''        -- Compa\00F1\00EDa'),
'',
unistr('        -- Filtro din\00E1mico para buscar solo en el mes y a\00F1o en curso'),
'        AND gl.GLFY = TO_NUMBER(TO_CHAR(SYSDATE, ''YYYY'')) - 2000',
'        AND (',
'            (gl.GLPN = EXTRACT(MONTH FROM SYSDATE) AND :P603_EN_VENT_ANT = 0)',
'            OR',
'            (gl.GLPN = EXTRACT(MONTH FROM SYSDATE)-1 AND :P603_EN_VENT_ANT = 1)',
'        )',
')',
'ORDER BY c.Objeto,c.Auxiliar ;',
''))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_display_condition_type=>'EXPRESSION'
,p_plug_display_when_condition=>':P603_ID_REGION = 5'
,p_plug_display_when_cond2=>'PLSQL'
,p_ai_enabled=>false
,p_updated_on=>wwv_flow_imp.dz('20260514153322Z')
,p_updated_by=>'JBALCAZAR'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(436659190764617505)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'TOP_AND_BOTTOM_RIGHT'
,p_show_search_bar=>'N'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_enable_mail_download=>'Y'
,p_owner=>'MFERRIN'
,p_internal_uid=>436659190764617505
,p_updated_on=>wwv_flow_imp.dz('20260514153322Z')
,p_updated_by=>'JBALCAZAR'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(436659257916617506)
,p_db_column_name=>'CUENTA_OBJETO'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Cuenta Objeto'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(436659419891617507)
,p_db_column_name=>'CUENTA_AUXILIAR'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Cuenta Auxiliar'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(436659445265617508)
,p_db_column_name=>'CUENTA_FORMATEADA'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Cuenta Formateada'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(436659622270617509)
,p_db_column_name=>'ESTADO_ALERTA'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Estado Alerta'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(436716642390774587)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'1917861'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'CUENTA_OBJETO:CUENTA_AUXILIAR:CUENTA_FORMATEADA:ESTADO_ALERTA'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(436659716067617510)
,p_plug_name=>unistr('VARIACI\00D3N ENTRE VENTAS Y CUENTAS POR COBRAR')
,p_parent_plug_id=>wwv_flow_imp.id(436584633965582209)
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(112813843178917343)
,p_plug_display_sequence=>140
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'WITH VENTAS_F42119 AS (',
'    -- 1. F42119 es el Maestro. Sumarizamos la Venta Neta.',
'    SELECT',
'        SDKCO AS Compania,',
'        SDDCT AS Tipo_Factura,',
'        SDDOC AS Numero_Factura,',
'',
'        -- SDAEXP es el Precio Extendido (Venta Neta sin impuestos)',
'        SUM(SDAEXP / 100) AS Venta_Neta_F42119',
'    FROM',
'        PRODDTA.F42119@jdedtadl',
'    WHERE',
'        SDKCO = ''00001''',
'        AND SDDOC <> 0',
'        AND (',
'            (SDIVD BETWEEN :P603_INICIO_MES_JDE AND :P603_FIN_MES_JDE AND :P603_EN_VENT_ANT = 0)',
'            OR',
'            (SDIVD BETWEEN :P603_INICIO_MES_ANTERIOR_JDE AND :P603_FIN_MES_ANTERIOR_JDE AND :P603_EN_VENT_ANT = 1)',
'        )',
'        AND SDDCT IN (''FN'',''FE'')',
'    GROUP BY',
'        SDKCO, SDDCT, SDDOC',
'),',
'',
'CXC_F03B11 AS (',
'    -- 2. Sumarizamos y desglosamos la deuda en CXC',
'    SELECT',
'        RPKCO AS Compania,',
'        RPDCT AS Tipo_Factura,',
'        RPDOC AS Numero_Factura,',
'',
'        SUM(RPAG / 100) AS Monto_Bruto_CXC,',
'        SUM(NVL(RPSTAM, 0) / 100) AS Impuesto_CXC,',
'        SUM((RPAG - NVL(RPSTAM, 0)) / 100) AS Venta_Neta_CXC',
'    FROM',
'        PRODDTA.F03B11@jdedtadl',
'    WHERE',
'        RPKCO = ''00001''',
'        AND (',
'            (RPDIVJ BETWEEN :P603_INICIO_MES_JDE AND :P603_FIN_MES_JDE AND :P603_EN_VENT_ANT = 0)',
'            OR',
'            (RPDIVJ BETWEEN :P603_INICIO_MES_ANTERIOR_JDE AND :P603_FIN_MES_ANTERIOR_JDE AND :P603_EN_VENT_ANT = 1)',
'        )',
'        AND RPDCT IN (''FN'',''FE'')',
'    GROUP BY',
'        RPKCO, RPDCT, RPDOC',
')',
'',
'-- 3. Cruzamos partiendo siempre desde Ventas (LEFT JOIN)',
'SELECT',
'    V.Tipo_Factura,',
'    V.Numero_Factura,',
'',
'    NVL(V.Venta_Neta_F42119, 0) AS Venta_Neta_F42119,',
'    NVL(C.Venta_Neta_CXC, 0) AS Venta_Neta_CXC,',
'    NVL(C.Monto_Bruto_CXC, 0) AS CXC_Factura_Total,',
'',
'    (NVL(V.Venta_Neta_F42119, 0) - NVL(C.Venta_Neta_CXC, 0)) AS Diferencia_Neta,',
'',
'    -- Alerta ajustada a la nueva realidad',
'    CASE',
unistr('        WHEN C.Numero_Factura IS NULL THEN ''Factura se qued\00F3 en Ventas y NO pas\00F3 a CXC'''),
'        ELSE ''Descuadre de Montos (Revisar Descuentos/Fletes)''',
'    END AS Estado_Alerta',
'',
'FROM',
'    VENTAS_F42119 V',
'LEFT JOIN',
'    CXC_F03B11 C',
'    ON V.Compania = C.Compania',
'    AND V.Tipo_Factura = C.Tipo_Factura',
'    AND V.Numero_Factura = C.Numero_Factura',
'',
'WHERE',
'    -- Comparamos que las ventas netas sean exactamente iguales',
'    ROUND(NVL(V.Venta_Neta_F42119, 0), 2) <> ROUND(NVL(C.Venta_Neta_CXC, 0), 2)',
'',
'ORDER BY',
'    V.Numero_Factura ASC;'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_display_condition_type=>'EXPRESSION'
,p_plug_display_when_condition=>':P603_ID_REGION = 6'
,p_plug_display_when_cond2=>'PLSQL'
,p_ai_enabled=>false
,p_updated_on=>wwv_flow_imp.dz('20260514155120Z')
,p_updated_by=>'JBALCAZAR'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(436740916401177761)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'TOP_AND_BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'MFERRIN'
,p_internal_uid=>436740916401177761
,p_updated_on=>wwv_flow_imp.dz('20260514155120Z')
,p_updated_by=>'JBALCAZAR'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(436741241302177765)
,p_db_column_name=>'ESTADO_ALERTA'
,p_display_order=>40
,p_column_identifier=>'A'
,p_column_label=>'Estado Alerta'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(436741440323177767)
,p_db_column_name=>'TIPO_FACTURA'
,p_display_order=>60
,p_column_identifier=>'C'
,p_column_label=>'Tipo Factura'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(436741609196177768)
,p_db_column_name=>'NUMERO_FACTURA'
,p_display_order=>70
,p_column_identifier=>'D'
,p_column_label=>'Numero Factura'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(436741635342177769)
,p_db_column_name=>'VENTA_NETA_F42119'
,p_display_order=>80
,p_column_identifier=>'E'
,p_column_label=>'Venta Neta F42119'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(436741775002177770)
,p_db_column_name=>'VENTA_NETA_CXC'
,p_display_order=>90
,p_column_identifier=>'F'
,p_column_label=>'Venta Neta Cxc'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(436741902163177771)
,p_db_column_name=>'CXC_FACTURA_TOTAL'
,p_display_order=>100
,p_column_identifier=>'G'
,p_column_label=>'Cxc Factura Total'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(436742000541177772)
,p_db_column_name=>'DIFERENCIA_NETA'
,p_display_order=>110
,p_column_identifier=>'H'
,p_column_label=>'Diferencia Neta'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(436749347235205029)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'1918188'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'ESTADO_ALERTA:TIPO_FACTURA:NUMERO_FACTURA:VENTA_NETA_F42119:VENTA_NETA_CXC:CXC_FACTURA_TOTAL:DIFERENCIA_NETA'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(436743631381177789)
,p_plug_name=>unistr('VARIACI\00D3N ENTRE CUENTAS POR COBRAR Y ASIENT0')
,p_parent_plug_id=>wwv_flow_imp.id(436584633965582209)
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(112813843178917343)
,p_plug_display_sequence=>150
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'WITH CXC_F03B11 AS (',
unistr('    -- 1. Resumen desde el M\00F3dulo de Cuentas por Cobrar'),
'    SELECT',
'        RPKCO AS Compania,',
'        RPDCT AS Tipo_Documento,',
'        RPDOC AS Numero_Documento,',
'        RPICU AS Batch,',
'        RPICUT AS Batch_Type,',
'',
'        SUM((RPAG-NVL(RPSTAM, 0)) / 100) AS Monto_Total_CXC',
'    FROM',
'        PRODDTA.F03B11@jdedtadl',
'    WHERE',
'        RPKCO = ''00001''',
unistr('        --AND RPPOST = ''P''  -- Solo validamos lo que el sistema dice que "ya est\00E1 contabilizado"'),
'',
'        -- Filtramos por el mes en curso',
'        AND (',
'            (RPDIVJ BETWEEN :P603_INICIO_MES_JDE AND :P603_FIN_MES_JDE AND :P603_EN_VENT_ANT = 0)',
'            OR',
'            (RPDIVJ BETWEEN :P603_INICIO_MES_ANTERIOR_JDE AND :P603_FIN_MES_ANTERIOR_JDE AND :P603_EN_VENT_ANT = 1)',
'        )',
'        AND RPDCT IN (''FN'',''FE'')',
'    GROUP BY',
'        RPKCO, RPDCT, RPDOC, RPICUT, RPICU',
'),',
'',
'CONTABLE_F0911 AS (',
'    -- 2. Resumen desde el Libro Mayor (Contabilidad)',
'    SELECT',
'        GLKCO AS Compania,',
'        GLDCT AS Tipo_Documento,',
'        GLDOC AS Numero_Documento,',
'        GLICU AS Batch,',
'        GLICUT AS Batch_Type,',
'',
'        ABS(SUM(GLAA / 100))  AS Monto_Total_GL',
'    FROM',
'        PRODDTA.F0911@jdedtadl',
'    WHERE',
'        GLKCO = ''00001''',
'        AND GLLT = ''AA''',
'        --AND GLPOST = ''P''',
'',
'        -- Filtramos los tipos de documento comunes de CXC para optimizar la consulta',
'        AND GLDCT IN (''FN'',''FE'')',
'',
unistr('        AND GLFY = TO_NUMBER(TO_CHAR(SYSDATE, ''YYYY'')) - 2000 -- A\00F1o fiscal actual'),
'        AND (',
'            (GLPN = EXTRACT(MONTH FROM SYSDATE) AND :P603_EN_VENT_ANT = 0)',
'            OR',
'            (GLPN = EXTRACT(MONTH FROM SYSDATE)-1 AND :P603_EN_VENT_ANT = 1)',
'        )',
'    GROUP BY',
'        GLKCO, GLDCT, GLDOC, GLICU, GLICUT',
')',
'SELECT',
'    COALESCE(C.Compania, G.Compania) AS Compania,',
'    COALESCE(C.Tipo_Documento, G.Tipo_Documento) AS Tipo_Documento,',
'    COALESCE(C.Numero_Documento, G.Numero_Documento) AS Numero_Documento,',
'',
'    NVL(C.Monto_Total_CXC, 0) AS Monto_CXC,',
'    NVL(G.Monto_Total_GL, 0) AS Monto_Contable,',
'',
'    (NVL(C.Monto_Total_CXC, 0) - NVL(G.Monto_Total_GL, 0)) AS Diferencia,',
'',
'    -- Clasificamos el error',
'    CASE',
unistr('        WHEN G.Numero_Documento IS NULL THEN ''En CXC, pero NO pas\00F3 a Contabilidad'''),
'        ELSE ''Descuadre de Montos''',
'    END AS Motivo_Alerta',
'',
'FROM',
'    CXC_F03B11 C',
'LEFT JOIN',
'    CONTABLE_F0911 G',
'    ON C.Compania = G.Compania',
'    AND C.Tipo_Documento = G.Tipo_Documento',
'    AND C.Numero_Documento = G.Numero_Documento',
'    AND C.Batch = G.Batch',
'    AND C.Batch_Type = G.Batch_Type',
'',
'WHERE',
'    --Mostramos solo los documentos que tengan variaciones',
'    ROUND(NVL(C.Monto_Total_CXC, 0), 2) <> ROUND(NVL(G.Monto_Total_GL, 0), 2)',
'',
'ORDER BY',
'    Numero_Documento ASC;'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_display_condition_type=>'EXPRESSION'
,p_plug_display_when_condition=>':P603_ID_REGION = 7'
,p_plug_display_when_cond2=>'PLSQL'
,p_ai_enabled=>false
,p_updated_on=>wwv_flow_imp.dz('20260514153955Z')
,p_updated_by=>'JBALCAZAR'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(436743778000177790)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'TOP_AND_BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'MFERRIN'
,p_internal_uid=>436743778000177790
,p_updated_on=>wwv_flow_imp.dz('20260514153955Z')
,p_updated_by=>'JBALCAZAR'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(436743840054177791)
,p_db_column_name=>'COMPANIA'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Compania'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(436743933309177792)
,p_db_column_name=>'TIPO_DOCUMENTO'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Tipo Documento'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(436744035308177793)
,p_db_column_name=>'NUMERO_DOCUMENTO'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Numero Documento'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(436744353459177796)
,p_db_column_name=>'DIFERENCIA'
,p_display_order=>60
,p_column_identifier=>'D'
,p_column_label=>'Diferencia'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(436744476747177797)
,p_db_column_name=>'MOTIVO_ALERTA'
,p_display_order=>70
,p_column_identifier=>'E'
,p_column_label=>'Motivo Alerta'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(436744590427177798)
,p_db_column_name=>'MONTO_CXC'
,p_display_order=>80
,p_column_identifier=>'F'
,p_column_label=>'Monto Cxc'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(436744645799177799)
,p_db_column_name=>'MONTO_CONTABLE'
,p_display_order=>90
,p_column_identifier=>'G'
,p_column_label=>'Monto Contable'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(437049929270142915)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'1921194'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'TIPO_DOCUMENTO:NUMERO_DOCUMENTO:DIFERENCIA:MOTIVO_ALERTA:MONTO_CXC:MONTO_CONTABLE:'
,p_updated_on=>wwv_flow_imp.dz('20260427164058Z')
,p_updated_by=>'GCACHIPUENDO'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(436744773565177800)
,p_plug_name=>unistr('VALIDACI\00D3N CONTABLE DE LAS CUENTAS DE VENTAS')
,p_parent_plug_id=>wwv_flow_imp.id(436584633965582209)
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(112813843178917343)
,p_plug_display_sequence=>160
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT DISTINCT',
'    G1.GLKCO AS Compania,',
'    G1.GLDCT AS Tipo_Documento,',
'    G1.GLDOC AS Numero_Documento,',
'',
unistr('    -- Mostramos la fecha del asiento para saber de cu\00E1ndo es el error'),
'    TO_DATE(TO_CHAR(1900000 + G1.GLDGJ), ''YYYYDDD'') AS Fecha_Contable,',
'',
'    ''VENTA SIN INGRESO EN CUENTAS 41101 AL 41105'' AS Estado_Alerta',
'',
'FROM',
'    PRODDTA.F0911@jdedtadl G1',
'',
'WHERE',
'    G1.GLKCO = ''00001''  -- Regla de oro inquebrantable',
'    AND G1.GLLT = ''AA''',
unistr('    --AND G1.GLPOST = ''P'' -- Validamos lo que ya est\00E1 contabilizado'),
'',
unistr('    -- Filtramos espec\00EDficamente los tipos de documento solicitados'),
'    AND G1.GLDCT IN (''FN'', ''FE'', ''D1'')',
'',
'    -- Filtramos por el periodo en curso para no asfixiar la base de datos',
'    --AND G1.GLDGJ >= TO_NUMBER(TO_CHAR(TRUNC(SYSDATE, ''MM''), ''YYYYDDD'')) - 1900000',
unistr('    AND G1.GLFY = TO_NUMBER(TO_CHAR(SYSDATE, ''YYYY'')) - 2000 -- Filtramos por el a\00F1o en curso (2026)'),
'    AND (',
'        (G1.GLPN = EXTRACT(MONTH FROM SYSDATE) AND :P603_EN_VENT_ANT = 0)',
'        OR',
'        (G1.GLPN = EXTRACT(MONTH FROM SYSDATE)-1 AND :P603_EN_VENT_ANT = 1)',
'    )',
'',
'    -- =========================================================================',
unistr('    -- EL FILTRO ESTRELLA: Excluimos los documentos que S\00CD tocaron las cuentas correctas'),
'    -- =========================================================================',
'    AND NOT EXISTS (',
'        SELECT 1',
'        FROM PRODDTA.F0911@jdedtadl G2',
'        WHERE',
'            G1.GLKCO = G2.GLKCO',
'            AND G1.GLDCT = G2.GLDCT',
'            AND G1.GLDOC = G2.GLDOC',
'            AND G2.GLLT = ''AA''',
unistr('            -- Si el documento tiene al menos una l\00EDnea en estas cuentas, es un documento "sano" y lo ignoramos'),
'            AND G2.GLOBJ IN (''41101'', ''41102'', ''41103'', ''41104'', ''41105'')',
'    )',
'ORDER BY',
'    G1.GLDCT,',
'    G1.GLDOC;'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_display_condition_type=>'EXPRESSION'
,p_plug_display_when_condition=>':P603_ID_REGION = 8'
,p_plug_display_when_cond2=>'PLSQL'
,p_ai_enabled=>false
,p_updated_on=>wwv_flow_imp.dz('20260514153322Z')
,p_updated_by=>'JBALCAZAR'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(436744829215177801)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'TOP_AND_BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'MFERRIN'
,p_internal_uid=>436744829215177801
,p_updated_on=>wwv_flow_imp.dz('20260514153322Z')
,p_updated_by=>'JBALCAZAR'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(436744950287177802)
,p_db_column_name=>'COMPANIA'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Compania'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(436745064216177803)
,p_db_column_name=>'TIPO_DOCUMENTO'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Tipo Documento'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(436745220323177804)
,p_db_column_name=>'NUMERO_DOCUMENTO'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Numero Documento'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(436745712809177809)
,p_db_column_name=>'FECHA_CONTABLE'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Fecha Contable'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(436745783512177810)
,p_db_column_name=>'ESTADO_ALERTA'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Estado Alerta'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(437054745988257733)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'1921242'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'COMPANIA:TIPO_DOCUMENTO:NUMERO_DOCUMENTO:FECHA_CONTABLE:ESTADO_ALERTA'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(437056966594266877)
,p_plug_name=>'CIERRE CONTABLE DEL MES ANTERIOR'
,p_parent_plug_id=>wwv_flow_imp.id(436584633965582209)
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(112813843178917343)
,p_plug_display_sequence=>170
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT',
'    f.CCCO AS Compania,',
'    TRIM(f.CCNAME) AS Nombre_Compania,',
'',
unistr('    -- Mostramos c\00F3mo est\00E1n los periodos en JDE'),
'    f.CCPNC AS Periodo_Contabilidad,',
'',
'    EXTRACT(MONTH FROM SYSDATE) AS Mes_Calendario_Actual,',
'',
unistr('    ''EL PERIODO ANTERIOR A\00DAN EST\00C1 ABIERTO'' AS Estado_Cierre'),
'',
'FROM',
'    PRODDTA.F0010@jdedtadl f',
'',
'WHERE',
'    f.CCCO = ''00001''',
'',
unistr('    -- CONDICI\00D3N 1: Solo evaluamos DURANTE los primeros 5 d\00EDas h\00E1biles del mes'),
'    AND :P603_EN_VENT_ANT = 1',
'',
unistr('    -- CONDICI\00D3N 2: El periodo en JDE no es el mes actual (sigue en el pasado)'),
'    AND f.CCPNC <> EXTRACT(MONTH FROM SYSDATE)'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_display_condition_type=>'EXPRESSION'
,p_plug_display_when_condition=>':P603_ID_REGION = 9'
,p_plug_display_when_cond2=>'PLSQL'
,p_ai_enabled=>false
,p_updated_on=>wwv_flow_imp.dz('20260514173637Z')
,p_updated_by=>'JBALCAZAR'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(437057095536266878)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'TOP_AND_BOTTOM_RIGHT'
,p_show_search_bar=>'N'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_enable_mail_download=>'Y'
,p_owner=>'MFERRIN'
,p_internal_uid=>437057095536266878
,p_updated_on=>wwv_flow_imp.dz('20260514173637Z')
,p_updated_by=>'JBALCAZAR'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(437057222116266879)
,p_db_column_name=>'COMPANIA'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Compania'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(437057265034266880)
,p_db_column_name=>'NOMBRE_COMPANIA'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Nombre Compania'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(437057408802266881)
,p_db_column_name=>'MES_CALENDARIO_ACTUAL'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Mes Calendario Actual'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(437057450989266882)
,p_db_column_name=>'ESTADO_CIERRE'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Estado Cierre'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(437057617338266883)
,p_db_column_name=>'PERIODO_CONTABILIDAD'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Periodo Contabilidad'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(437072124264348783)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'1921416'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'COMPANIA:NOMBRE_COMPANIA:MES_CALENDARIO_ACTUAL:ESTADO_CIERRE:PERIODO_CONTABILIDAD'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(437058126608266889)
,p_plug_name=>'Cuentas por pagar'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(38289867500120143)
,p_plug_display_sequence=>110
,p_location=>null
,p_plug_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_plug_display_when_condition=>'P603_MODULO'
,p_plug_display_when_cond2=>'CXPFI'
,p_ai_enabled=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
,p_updated_on=>wwv_flow_imp.dz('20260427171350Z')
,p_updated_by=>'JBALCAZAR'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(437911110755301414)
,p_plug_name=>unistr('VARIACI\00D3N FACTURA PROVEEDOR VS LA ORDEN')
,p_parent_plug_id=>wwv_flow_imp.id(437058126608266889)
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(112813843178917343)
,p_plug_display_sequence=>140
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'WITH BASE_FACTURAS AS (',
unistr('    -- 2. MATERIALIZE: Empacamos las poquitas facturas del mes en una tabla temporal ultra r\00E1pida'),
'    SELECT /*+ MATERIALIZE */',
'        CASE',
'            WHEN REGEXP_LIKE(TRIM(RPPO), ''^[0-9]+$'') THEN TO_NUMBER(TRIM(RPPO))',
'            ELSE -1',
'        END AS ORDEN_COMPRA,',
'        RPAN8 AS CLIENTE,',
'        LISTAGG(RPVINV, '', '') WITHIN GROUP (ORDER BY RPVINV) AS FACTURA_LEGAL,',
'        LISTAGG(RPDOC, '', '') WITHIN GROUP (ORDER BY RPDOC) AS DOCUMENTOS_ASOCIADOS,',
'        SUM(RPATXA) AS TOTAL_CXP_ORDEN',
'    FROM PRODDTA.F0411@jdedtadl',
'    WHERE RPCO = ''00001''',
'      AND RPFY = EXTRACT(YEAR FROM SYSDATE) - 2000',
'      AND RPPN = EXTRACT(MONTH FROM SYSDATE)',
'      AND RPDCT IN (''PV'',''PJ'',''DI'')',
'      AND TRIM(RPPO) IS NOT NULL',
'    GROUP BY TRIM(RPPO), RPAN8',
'),',
'RESUMEN_F4311 AS (',
unistr('    -- 3. EL TRUCO DE MAGIA: Metemos el INNER JOIN con BASE_FACTURAS aqu\00ED adentro.'),
'    SELECT O.PDDOCO, O.PDAN8, O.PDDCTO, SUM(O.PDAREC) AS TOTAL_ORDEN',
'    FROM PRODDTA.F4311@jdedtadl O',
'    INNER JOIN BASE_FACTURAS F ON O.PDDOCO = F.ORDEN_COMPRA AND O.PDAN8 = F.CLIENTE',
'    WHERE O.PDKCOO = ''00001''',
'      AND O.PDDCTO IN (''CM'',''CN'')',
'    GROUP BY O.PDDOCO, O.PDAN8, O.PDDCTO',
'),',
'RESUMEN_F43121 AS (',
unistr('    -- 4. Kardex de Recepciones con Funci\00F3n Anal\00EDtica'),
'    SELECT R.PRDOCO, R.PRAN8, R.PRDCTO, R.PRITM,',
'           SUM(R.PRAPTD) AS TOTAL_RECIBIDO_LINEA,',
'           -- LA MAGIA: Sumamos el total de la orden en la memoria RAM sin volver a consultar la tabla',
'           SUM(SUM(R.PRAPTD)) OVER (PARTITION BY R.PRDOCO, R.PRAN8, R.PRDCTO) AS TOTAL_COTEJADO',
'    FROM PRODDTA.F43121@jdedtadl R',
'    INNER JOIN BASE_FACTURAS F ON R.PRDOCO = F.ORDEN_COMPRA AND R.PRAN8 = F.CLIENTE',
'    WHERE R.PRDCTO IN (''CM'',''CN'')',
'      AND R.PRRCDJ >= TO_NUMBER(TO_CHAR(TRUNC(SYSDATE, ''MM''), ''YYYYDDD'')) - 1900000',
'      AND TRIM(R.PRVINV) IS NOT NULL',
'    GROUP BY R.PRDOCO, R.PRAN8, R.PRDCTO, R.PRITM',
')',
unistr('-- 5. El cruce final ahora une 3 tablas min\00FAsculas.'),
'SELECT',
'    f0.DOCUMENTOS_ASOCIADOS,',
'    f0.ORDEN_COMPRA,',
'    f0.CLIENTE,',
'    f0.FACTURA_LEGAL,',
'    f0.TOTAL_CXP_ORDEN/100 AS TOTAL_CXP_ORDEN,',
'    f4_sum.TOTAL_ORDEN/100 AS TOTAL_ORDEN,',
'    f4_rec2.TOTAL_COTEJADO/100 AS TOTAL_COTEJADO,',
'    f4_det.PDLITM AS PRODUCTO,',
'    f4_det.PDLNID/1000 AS LINEA,',
'    f4_det.PDAREC/100 AS MONTO_LINEA_OC,',
'    f4_rec2.TOTAL_RECIBIDO_LINEA/100 AS TOTAL_RECIBIDO_LINEA,',
'    f4_det.PDAREC/100 - f4_rec2.TOTAL_RECIBIDO_LINEA/100 DIFERENCIA_LINEA',
'FROM BASE_FACTURAS f0',
'INNER JOIN RESUMEN_F4311 f4_sum',
'        ON f0.ORDEN_COMPRA = f4_sum.PDDOCO',
'       AND f0.CLIENTE = f4_sum.PDAN8',
'INNER JOIN PRODDTA.F4311@jdedtadl f4_det',
'        ON f0.ORDEN_COMPRA = f4_det.PDDOCO',
'       AND f0.CLIENTE = f4_det.PDAN8',
'       AND f4_sum.PDDCTO = f4_det.PDDCTO',
'INNER JOIN RESUMEN_F43121 f4_rec2',
'        ON f0.ORDEN_COMPRA = f4_rec2.PRDOCO',
'       AND f0.CLIENTE = f4_rec2.PRAN8',
'       AND f4_sum.PDDCTO = f4_rec2.PRDCTO',
'       AND f4_det.PDITM = f4_rec2.PRITM',
'WHERE f0.TOTAL_CXP_ORDEN <> f4_sum.TOTAL_ORDEN',
'  AND f4_det.PDAREC <> f4_rec2.TOTAL_RECIBIDO_LINEA',
'ORDER BY f0.ORDEN_COMPRA,f4_det.PDLNID'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_display_condition_type=>'EXPRESSION'
,p_plug_display_when_condition=>':P603_ID_REGION = 2'
,p_plug_display_when_cond2=>'PLSQL'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>11
,p_prn_height=>8.5
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
,p_created_on=>wwv_flow_imp.dz('20260422221113Z')
,p_updated_on=>wwv_flow_imp.dz('20260423162046Z')
,p_created_by=>'JBALCAZAR'
,p_updated_by=>'GMUNOZ'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(437911261463301415)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'TOP_AND_BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'JBALCAZAR'
,p_internal_uid=>437911261463301415
,p_created_on=>wwv_flow_imp.dz('20260422221114Z')
,p_updated_on=>wwv_flow_imp.dz('20260423162046Z')
,p_created_by=>'JBALCAZAR'
,p_updated_by=>'GMUNOZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(437911433521301417)
,p_db_column_name=>'CLIENTE'
,p_display_order=>20
,p_column_identifier=>'A'
,p_column_label=>'Cliente'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20260422221114Z')
,p_updated_on=>wwv_flow_imp.dz('20260422221114Z')
,p_created_by=>'JBALCAZAR'
,p_updated_by=>'JBALCAZAR'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(437911542361301418)
,p_db_column_name=>'FACTURA_LEGAL'
,p_display_order=>30
,p_column_identifier=>'B'
,p_column_label=>'Factura Legal'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20260422221114Z')
,p_updated_on=>wwv_flow_imp.dz('20260422221114Z')
,p_created_by=>'JBALCAZAR'
,p_updated_by=>'JBALCAZAR'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(437911663750301419)
,p_db_column_name=>'MONTO_LINEA_OC'
,p_display_order=>40
,p_column_identifier=>'C'
,p_column_label=>'Monto Linea Oc'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G990D00'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20260422221114Z')
,p_updated_on=>wwv_flow_imp.dz('20260422221114Z')
,p_created_by=>'JBALCAZAR'
,p_updated_by=>'JBALCAZAR'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(437911703723301420)
,p_db_column_name=>'DOCUMENTOS_ASOCIADOS'
,p_display_order=>50
,p_column_identifier=>'D'
,p_column_label=>'Documentos Asociados'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20260422221114Z')
,p_updated_on=>wwv_flow_imp.dz('20260422221114Z')
,p_created_by=>'JBALCAZAR'
,p_updated_by=>'JBALCAZAR'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(437911815415301421)
,p_db_column_name=>'TOTAL_CXP_ORDEN'
,p_display_order=>60
,p_column_identifier=>'E'
,p_column_label=>'Total Cxp Orden'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G990D00'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20260422221114Z')
,p_updated_on=>wwv_flow_imp.dz('20260422221114Z')
,p_created_by=>'JBALCAZAR'
,p_updated_by=>'JBALCAZAR'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(437911980718301422)
,p_db_column_name=>'TOTAL_ORDEN'
,p_display_order=>70
,p_column_identifier=>'F'
,p_column_label=>'Total Orden'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G990D00'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20260422221115Z')
,p_updated_on=>wwv_flow_imp.dz('20260422221115Z')
,p_created_by=>'JBALCAZAR'
,p_updated_by=>'JBALCAZAR'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(437912036620301423)
,p_db_column_name=>'TOTAL_COTEJADO'
,p_display_order=>80
,p_column_identifier=>'G'
,p_column_label=>'Total Cotejado'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G990D00'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20260422221115Z')
,p_updated_on=>wwv_flow_imp.dz('20260422221442Z')
,p_created_by=>'JBALCAZAR'
,p_updated_by=>'JBALCAZAR'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(437912186180301424)
,p_db_column_name=>'LINEA'
,p_display_order=>90
,p_column_identifier=>'H'
,p_column_label=>'Linea'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20260422221115Z')
,p_updated_on=>wwv_flow_imp.dz('20260422221115Z')
,p_created_by=>'JBALCAZAR'
,p_updated_by=>'JBALCAZAR'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(437912272442301425)
,p_db_column_name=>'TOTAL_RECIBIDO_LINEA'
,p_display_order=>100
,p_column_identifier=>'I'
,p_column_label=>'Total Recibido Linea'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G990D00'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20260422221115Z')
,p_updated_on=>wwv_flow_imp.dz('20260422221442Z')
,p_created_by=>'JBALCAZAR'
,p_updated_by=>'JBALCAZAR'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(437912389512301426)
,p_db_column_name=>'PRODUCTO'
,p_display_order=>110
,p_column_identifier=>'J'
,p_column_label=>'Producto'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20260422221115Z')
,p_updated_on=>wwv_flow_imp.dz('20260422221115Z')
,p_created_by=>'JBALCAZAR'
,p_updated_by=>'JBALCAZAR'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(437912419241301427)
,p_db_column_name=>'ORDEN_COMPRA'
,p_display_order=>120
,p_column_identifier=>'K'
,p_column_label=>'Orden Compra'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20260422221115Z')
,p_updated_on=>wwv_flow_imp.dz('20260422221115Z')
,p_created_by=>'JBALCAZAR'
,p_updated_by=>'JBALCAZAR'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(437914536736301448)
,p_db_column_name=>'DIFERENCIA_LINEA'
,p_display_order=>130
,p_column_identifier=>'L'
,p_column_label=>'Diferencia Linea'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G990D00'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20260423161928Z')
,p_updated_on=>wwv_flow_imp.dz('20260423161959Z')
,p_created_by=>'JBALCAZAR'
,p_updated_by=>'JBALCAZAR'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(438013423025586747)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'4380135'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'DOCUMENTOS_ASOCIADOS:FACTURA_LEGAL:ORDEN_COMPRA:CLIENTE:TOTAL_CXP_ORDEN:TOTAL_ORDEN:TOTAL_COTEJADO:PRODUCTO:LINEA:MONTO_LINEA_OC:TOTAL_RECIBIDO_LINEA:DIFERENCIA_LINEA:'
,p_created_on=>wwv_flow_imp.dz('20260422221123Z')
,p_updated_on=>wwv_flow_imp.dz('20260423162046Z')
,p_created_by=>'GMUNOZ'
,p_updated_by=>'GMUNOZ'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(441121180801004682)
,p_plug_name=>'ANTICIPO SIN FACTURA'
,p_parent_plug_id=>wwv_flow_imp.id(437058126608266889)
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(112813843178917343)
,p_plug_display_sequence=>150
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
unistr('--Mostrar si existe facturas que tengan proveedor con tipo de pago CONTADO y no est\00E9 la factura.'),
'SELECT F.RPDOC DOCUMENTO,F.RPAN8 CLIENTE, TRIM(ab.ABALPH) NOMBRE_CLIENTE,RPVINV FACTURA_LEGAL',
'FROM PRODDTA.F0411@jdedtadl F',
'JOIN PRODDTA.F0401@jdedtadl P ON F.RPAN8 = P.A6AN8',
'JOIN PRODDTA.F0101@jdedtadl ab ON F.RPAN8 = ab.ABAN8',
'WHERE F.RPKCO = ''00001'' AND A6TRAP = ''CT.'' AND RPVINV IS NULL;'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_display_condition_type=>'EXPRESSION'
,p_plug_display_when_condition=>':P603_ID_REGION = 3'
,p_plug_display_when_cond2=>'PLSQL'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>11
,p_prn_height=>8.5
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
,p_ai_enabled=>false
,p_updated_on=>wwv_flow_imp.dz('20260422221113Z')
,p_updated_by=>'JBALCAZAR'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(441121268186004683)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'TOP_AND_BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'MFERRIN'
,p_internal_uid=>441121268186004683
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(441121358975004684)
,p_db_column_name=>'CLIENTE'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Cliente'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(441121442940004685)
,p_db_column_name=>'FACTURA_LEGAL'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Factura Legal'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(441121581815004686)
,p_db_column_name=>'DOCUMENTO'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Documento'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(441121704926004687)
,p_db_column_name=>'NOMBRE_CLIENTE'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Nombre Cliente'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(441856533239156185)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'1969260'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'DOCUMENTO:FACTURA_LEGAL:CLIENTE:NOMBRE_CLIENTE:'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(441122891178004699)
,p_plug_name=>'FACTURA EMITIDA VS FECHA DE REGISTRO >=5 DIAS'
,p_parent_plug_id=>wwv_flow_imp.id(437058126608266889)
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(112813843178917343)
,p_plug_display_sequence=>170
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT DISTINCT',
'    RP.RPDCT AS Tipo_Factura_CXP,',
'    RP.RPDOC AS Numero_Factura_CXP,',
'',
'    -- Datos de la Orden de Compra Origen',
'    RP.RPPO AS Orden_Compra_CN,',
'    RP.RPPDCT AS Tipo_OC_CN,',
'',
'    -- Convertimos a formato fecha tradicional',
'    TO_DATE(TO_CHAR(1900000 + RP.RPDIVJ), ''YYYYDDD'') AS Fecha_Emision_Factura,',
'    TO_DATE(TO_CHAR(1900000 + RP.RPDICJ), ''YYYYDDD'') AS Fecha_Promesa_Entrega,',
'',
unistr('    -- LA RESTA INVERTIDA: Promesa de entrega menos Emisi\00F3n de la factura'),
'    ABS(RP.RPDIVJ - RP.RPDICJ) AS Dias_Facturacion_Anticipada',
'',
'FROM',
'    PRODDTA.F0411@jdedtadl RP',
'',
'INNER JOIN',
'    PRODDTA.F4311@jdedtadl PO',
'    ON RP.RPPO = PO.PDDOCO',
'    AND RP.RPPDCT = PO.PDDCTO',
'    AND RP.RPPKCO = PO.PDKCOO',
'',
'WHERE',
'    RP.RPKCO = ''00001''',
'    AND RP.RPPDCT IN (''CN'',''CM'')',
'',
'    AND RPFY = TO_NUMBER(TO_CHAR(SYSDATE, ''YY''))',
'    AND RPPN = EXTRACT(MONTH FROM SYSDATE)',
'',
'    -- Filtros de seguridad para fechas nulas',
'    AND RP.RPDIVJ > 0',
'    AND RP.RPDICJ > 0',
'',
'    AND ABS(RP.RPDIVJ - RP.RPDICJ) >= 5',
''))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_display_condition_type=>'EXPRESSION'
,p_plug_display_when_condition=>':P603_ID_REGION = 5'
,p_plug_display_when_cond2=>'PLSQL'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>11
,p_prn_height=>8.5
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
,p_ai_enabled=>false
,p_updated_on=>wwv_flow_imp.dz('20260427203048Z')
,p_updated_by=>'JBALCAZAR'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(441123006632004700)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'TOP_AND_BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'MFERRIN'
,p_internal_uid=>441123006632004700
,p_updated_on=>wwv_flow_imp.dz('20260427203048Z')
,p_updated_by=>'JBALCAZAR'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(441123496837004705)
,p_db_column_name=>'TIPO_FACTURA_CXP'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Tipo Factura Cxp'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(441123537656004706)
,p_db_column_name=>'NUMERO_FACTURA_CXP'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Numero Factura Cxp'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(441123683520004707)
,p_db_column_name=>'ORDEN_COMPRA_CN'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Orden Compra Cn'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(441123796098004708)
,p_db_column_name=>'TIPO_OC_CN'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Tipo Oc Cn'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(441123860017004709)
,p_db_column_name=>'FECHA_EMISION_FACTURA'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Fecha Emision Factura'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(441123929143004710)
,p_db_column_name=>'FECHA_PROMESA_ENTREGA'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'Fecha Promesa Entrega'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(444061878725883561)
,p_db_column_name=>'DIAS_FACTURACION_ANTICIPADA'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>'Dias Facturacion Anticipada'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(444072333322888141)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'1991418'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'TIPO_FACTURA_CXP:NUMERO_FACTURA_CXP:ORDEN_COMPRA_CN:TIPO_OC_CN:FECHA_EMISION_FACTURA:FECHA_PROMESA_ENTREGA:DIAS_FACTURACION_ANTICIPADA'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(444061941247883562)
,p_plug_name=>unistr('OI QUE NO TENGAN JE AFECTANDO LA CUENTA 22502.09 CON UN RANGO DE 30 D\00CDAS (PROVISI\00D3N IMPORTACIONES)')
,p_parent_plug_id=>wwv_flow_imp.id(437058126608266889)
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(112813843178917343)
,p_plug_display_sequence=>190
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    O.PHDOCO AS Numero_Orden_OI,',
'    O.PHAN8 AS CLiente,',
'    cl.ABALPH AS NOMBRE,',
'    ',
'    -- Fecha de la Orden a nivel de cabecera',
'    TO_DATE(TO_CHAR(1900000 + O.PHTRDJ), ''YYYYDDD'') AS Fecha_Orden_OI',
'',
'FROM ',
'    PRODDTA.F4301@jdedtadl O',
'INNER JOIN PRODDTA.F0101@jdedtadl cl on O.PHAN8 = CL.ABAN8',
'WHERE ',
'    O.PHKCOO = ''00001''',
'    AND O.PHDCTO = ''OI''',
'    ',
unistr('    -- Filtramos las \00F3rdenes OI del a\00F1o actual para velocidad extrema'),
'    AND O.PHTRDJ >= TO_NUMBER(TO_CHAR(TRUNC(SYSDATE, ''Y''), ''YYYYDDD'')) - 1900000',
'',
'    -- =========================================================================',
unistr('    -- EL CONTROL: No existe un JE en la cuenta 22502.09 dentro de los 30 d\00EDas'),
'    -- =========================================================================',
'    AND NOT EXISTS (',
'        SELECT 1 ',
'        FROM PRODDTA.F0911@jdedtadl J',
'        WHERE ',
'            J.GLKCO = O.PHKCOO',
'            ',
'            AND J.GLDOC = O.PHDOCO ',
'            ',
'            AND J.GLDCT = ''JE''',
'            AND TRIM(J.GLOBJ) = ''22502''',
'            AND TRIM(J.GLSUB) = ''09''',
'            AND J.GLLT = ''AA''',
'            AND J.GLPOST = ''P'' ',
'            ',
unistr('            -- Calculamos la diferencia absoluta de 30 d\00EDas entre el JE y la Orden'),
'            AND ABS(',
'                TO_DATE(TO_CHAR(1900000 + J.GLDGJ), ''YYYYDDD'') - ',
'                TO_DATE(TO_CHAR(1900000 + O.PHTRDJ), ''YYYYDDD'')',
'            ) <= 30',
'    )',
'ORDER BY ',
'    O.PHDOCO DESC;'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_display_condition_type=>'EXPRESSION'
,p_plug_display_when_condition=>':P603_ID_REGION = 7'
,p_plug_display_when_cond2=>'PLSQL'
,p_ai_enabled=>false
,p_updated_on=>wwv_flow_imp.dz('20260427204451Z')
,p_updated_by=>'JBALCAZAR'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(444062024547883563)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'TOP_AND_BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'MFERRIN'
,p_internal_uid=>444062024547883563
,p_updated_on=>wwv_flow_imp.dz('20260427204451Z')
,p_updated_by=>'JBALCAZAR'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(444062899906883571)
,p_db_column_name=>'NUMERO_ORDEN_OI'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Numero Orden Oi'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(444062996092883572)
,p_db_column_name=>'FECHA_ORDEN_OI'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Fecha Orden Oi'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(444063023767883573)
,p_db_column_name=>'CLIENTE'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Cliente'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(440583918410170149)
,p_db_column_name=>'NOMBRE'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Nombre'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20260427203857Z')
,p_updated_on=>wwv_flow_imp.dz('20260427203857Z')
,p_created_by=>'JBALCAZAR'
,p_updated_by=>'JBALCAZAR'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(444132715370544518)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'1992021'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'NUMERO_ORDEN_OI:CLIENTE:NOMBRE:FECHA_ORDEN_OI:'
,p_updated_on=>wwv_flow_imp.dz('20260427204240Z')
,p_updated_by=>'GMUNOZ'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(444063954289883582)
,p_plug_name=>unistr('FACTURAS SIN ORDEN DE COMPRA Y  CON \00D3RDENES DE COMPRA (EN ESTADOS: RUTA  IMPRESI\00D3N O RECEPCI\00D3N  - MENOR A 999)')
,p_parent_plug_id=>wwv_flow_imp.id(437058126608266889)
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(112813843178917343)
,p_plug_display_sequence=>160
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'WITH FACTURAS_RECIENTES AS (',
'    -- 1. Obtenemos las facturas (Vouchers)',
'    SELECT DISTINCT',
'        F.RPKCO AS CIA_FACTURA,',
'        F.RPDCT AS TIPO_FACTURA,',
'        F.RPDOC AS DOCUMENTO_CXP,',
'        F.RPAN8 AS PROVEEDOR,',
'        TRIM(AB.ABALPH) AS NOMBRE_PROVEEDOR,',
'        F.RPPYIN AS TIPO_PAGO,',
'        F.RPVINV AS FACTURA_LEGAL,',
'',
'        -- La llave de la OC (RPPO es String, lo limpiamos de espacios)',
'        F.RPPKCO AS CIA_ORDEN,',
'        F.RPPDCT AS TIPO_ORDEN,',
'        TRIM(F.RPPO) AS ORDEN_COMPRA_STR,',
'',
'        TO_DATE(TO_CHAR(1900000 + F.RPDIVJ), ''YYYYDDD'') AS FECHA_FACTURA',
'    FROM',
'        PRODDTA.F0411@jdedtadl F',
'    JOIN',
'        PRODDTA.F0101@jdedtadl AB',
'        ON F.RPAN8 = AB.ABAN8',
'    WHERE',
'        F.RPKCO = ''00001''',
'        AND F.RPDCT = ''PV''',
'        AND F.RPFY = TO_NUMBER(TO_CHAR(SYSDATE, ''YYYY'')) - 2000',
'        AND F.RPPN = EXTRACT(MONTH FROM SYSDATE)',
'',
'        AND TRIM(F.RPPO) IS NOT NULL',
'),',
'',
'ORDENES_ABIERTAS AS (',
unistr('    -- 2. Buscamos el universo de \00F3rdenes vivas'),
'    SELECT',
'        PDKCOO AS CIA_ORDEN,',
'        PDDCTO AS TIPO_ORDEN,',
'        PDDOCO AS ORDEN_COMPRA_NUM,',
'        PDAN8 AS PROVEEDOR_ORDEN',
'    FROM',
'        PRODDTA.F4311@jdedtadl',
'    WHERE',
'        TRIM(PDNXTR) < ''999''',
'    GROUP BY',
'        PDKCOO, PDDCTO, PDDOCO,PDAN8',
')',
'',
unistr('-- 3. REPORTE FINAL: Cruzamos convirtiendo el N\00FAmero a String para igualarlos'),
'SELECT',
'    F.DOCUMENTO_CXP,',
'    F.PROVEEDOR,',
'    F.NOMBRE_PROVEEDOR,',
'    F.FACTURA_LEGAL,',
'    F.CIA_ORDEN,',
'    F.TIPO_ORDEN,',
'    F.ORDEN_COMPRA_STR AS ORDEN_COMPRA,',
'    F.TIPO_PAGO,',
'    F.FECHA_FACTURA',
'FROM',
'    FACTURAS_RECIENTES F',
'WHERE EXISTS (',
'    SELECT 1',
'    FROM ORDENES_ABIERTAS O',
'    WHERE',
unistr('        -- Convertimos el DOCO (Num\00E9rico) a String para cruzarlo con el RPPO (String)'),
'        TO_CHAR(O.ORDEN_COMPRA_NUM) = F.ORDEN_COMPRA_STR',
'        AND O.TIPO_ORDEN = F.TIPO_ORDEN',
'        AND O.CIA_ORDEN = F.CIA_ORDEN',
'        AND O.PROVEEDOR_ORDEN = F.PROVEEDOR',
')',
'ORDER BY',
'    F.FECHA_FACTURA DESC;'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_display_condition_type=>'EXPRESSION'
,p_plug_display_when_condition=>':P603_ID_REGION = 4'
,p_plug_display_when_cond2=>'PLSQL'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>11
,p_prn_height=>8.5
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
,p_ai_enabled=>false
,p_updated_on=>wwv_flow_imp.dz('20260427175849Z')
,p_updated_by=>'JBALCAZAR'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(444064062434883583)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'TOP_AND_BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'MFERRIN'
,p_internal_uid=>444064062434883583
,p_updated_on=>wwv_flow_imp.dz('20260427175848Z')
,p_updated_by=>'JBALCAZAR'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(444064129185883584)
,p_db_column_name=>'FACTURA_LEGAL'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Factura Legal'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(444064386030883586)
,p_db_column_name=>'PROVEEDOR'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Proveedor'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(444064454130883587)
,p_db_column_name=>'NOMBRE_PROVEEDOR'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Nombre Proveedor'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(444064610773883588)
,p_db_column_name=>'CIA_ORDEN'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Cia Orden'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(444064643826883589)
,p_db_column_name=>'TIPO_ORDEN'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'Tipo Orden'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(444064796108883590)
,p_db_column_name=>'ORDEN_COMPRA'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>'Orden Compra'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(444064919363883591)
,p_db_column_name=>'TIPO_PAGO'
,p_display_order=>80
,p_column_identifier=>'H'
,p_column_label=>'Tipo Pago'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(444064949690883592)
,p_db_column_name=>'FECHA_FACTURA'
,p_display_order=>90
,p_column_identifier=>'I'
,p_column_label=>'Fecha Factura'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(444065095897883593)
,p_db_column_name=>'DOCUMENTO_CXP'
,p_display_order=>100
,p_column_identifier=>'J'
,p_column_label=>'Documento Cxp'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(444175249525200800)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'1992447'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'FACTURA_LEGAL:DOCUMENTO_CXP:PROVEEDOR:NOMBRE_PROVEEDOR:CIA_ORDEN:TIPO_ORDEN:ORDEN_COMPRA:TIPO_PAGO:FECHA_FACTURA:'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(444191037144659464)
,p_plug_name=>unistr('RETENCIONES NO AUTORIZADAS DESPU\00C9S DE GESTIONAR EMISI\00D3N')
,p_parent_plug_id=>wwv_flow_imp.id(437058126608266889)
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(112813843178917343)
,p_plug_display_sequence=>180
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ID',
'    , ESTADO',
'	, ORDEN AS "TO"',
'	, NUM_ORDEN',
'    , TIPO_DOCUMENTO AS "TD"',
'    , NUMERO_DOCUMENTO',
'    , CLIENTE_PROVEEDOR',
'    , FECHA_FACTURA FECHA_EMISION',
'	, CLAVEACCESO',
' FROM DATA.VT_FINZ_MESADOCUMETOELECTRONICO',
'WHERE ORDEN = ''PV'' AND TIPO_DOCUMENTO = ''UR'' AND ESTADO <> ''APROBADO'' AND TRUNC(TO_DATE(FECHA_FACTURA,''DD/MM/YYYY''),''MM'') = TRUNC(SYSDATE,''MM'')'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_display_condition_type=>'EXPRESSION'
,p_plug_display_when_condition=>':P603_ID_REGION = 6'
,p_plug_display_when_cond2=>'PLSQL'
,p_ai_enabled=>false
,p_updated_on=>wwv_flow_imp.dz('20260429183436Z')
,p_updated_by=>'JBALCAZAR'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(444191131989659465)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'TOP_AND_BOTTOM_RIGHT'
,p_show_actions_menu=>'N'
,p_report_list_mode=>'NONE'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_enable_mail_download=>'Y'
,p_owner=>'MFERRIN'
,p_internal_uid=>444191131989659465
,p_updated_on=>wwv_flow_imp.dz('20260429183436Z')
,p_updated_by=>'JBALCAZAR'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(444192015376659473)
,p_db_column_name=>'ID'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Id'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(444192041222659474)
,p_db_column_name=>'ESTADO'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Estado'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(444192273187659476)
,p_db_column_name=>'NUM_ORDEN'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Num Orden'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(444192517757659478)
,p_db_column_name=>'NUMERO_DOCUMENTO'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'Numero Documento'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(444192530983659479)
,p_db_column_name=>'CLIENTE_PROVEEDOR'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>'Cliente Proveedor'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(444192689653659480)
,p_db_column_name=>'FECHA_EMISION'
,p_display_order=>80
,p_column_identifier=>'H'
,p_column_label=>'Fecha Emision'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(444192842713659482)
,p_db_column_name=>'CLAVEACCESO'
,p_display_order=>100
,p_column_identifier=>'J'
,p_column_label=>'Claveacceso'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(444193022644659483)
,p_db_column_name=>'TO'
,p_display_order=>110
,p_column_identifier=>'K'
,p_column_label=>'To'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(444193085455659484)
,p_db_column_name=>'TD'
,p_display_order=>120
,p_column_identifier=>'L'
,p_column_label=>'Td'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(444199468548668005)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'1992689'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'ID:TO:ESTADO:NUM_ORDEN:TD:NUMERO_DOCUMENTO:CLIENTE_PROVEEDOR:FECHA_EMISION:CLAVEACCESO:'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(444193144805659485)
,p_plug_name=>'VALORES DE BANCOS PENDIENTES DE REGISTRAR EN JD'
,p_parent_plug_id=>wwv_flow_imp.id(437058126608266889)
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(112813843178917343)
,p_plug_display_sequence=>200
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT MPAID CUENTA, MPEDUS USUARIO, MPCKNU NUMERO, MPAA/100 AS TOTAL, MPEXR EXPLICACION, TO_DATE(TO_CHAR(1900000 + MPDGJ), ''YYYYDDD'') AS FECHA',
'FROM PRODDTA.F5509505@jdedtadl',
'WHERE (MPAID = ''00405198'' or MPAID = ''00330376'') AND MPEV02 = '' '' AND MPDGJ >= TO_NUMBER(TO_CHAR(TRUNC(SYSDATE, ''Y''), ''YYYYDDD'')) - 1900000',
';'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_display_condition_type=>'EXPRESSION'
,p_plug_display_when_condition=>':P603_ID_REGION = 8'
,p_plug_display_when_cond2=>'PLSQL'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>11
,p_prn_height=>8.5
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
,p_ai_enabled=>false
,p_updated_on=>wwv_flow_imp.dz('20260422221114Z')
,p_updated_by=>'JBALCAZAR'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(444193298842659486)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'TOP_AND_BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'MFERRIN'
,p_internal_uid=>444193298842659486
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(444193699710659490)
,p_db_column_name=>'USUARIO'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Usuario'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(444193727695659491)
,p_db_column_name=>'NUMERO'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Numero'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(444193922024659492)
,p_db_column_name=>'TOTAL'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Total'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G990D00'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(444193924256659493)
,p_db_column_name=>'EXPLICACION'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Explicacion'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(444194055502659494)
,p_db_column_name=>'FECHA'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Fecha'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(486666953648272995)
,p_db_column_name=>'CUENTA'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'Cuenta'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(444212288131810173)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'1992817'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'USUARIO:CUENTA:NUMERO:TOTAL:EXPLICACION:FECHA:'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(444194172025659495)
,p_plug_name=>unistr('FACTURAS DE PROVEEDORES SIN RETENCI\00D3N')
,p_parent_plug_id=>wwv_flow_imp.id(437058126608266889)
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(112813843178917343)
,p_plug_display_sequence=>210
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select documento.codchar codigo',
'	, documento.codigo codigodocumento',
'	, documento.numero',
'	, documento.tipo',
'	, documento.batch',
'	, decode(documento.batch,null,'''',''ORDEN COMPRA'') ordencompra',
'	, documento.codigoproveedor',
'	, documento.proveedor',
'	, documento.estado',
'	, usuario',
'	, documento.fecha fechaemision',
'	, documento.observacion',
'from data.vt_digi_documentos documento',
'where documento.compania = ''00001''',
'	and documento.tipo = ''PV''',
'    and documento.FECHA BETWEEN TRUNC(SYSDATE,''Y'') AND SYSDATE',
'    and not exists(',
'        select 1 from',
'        data.vt_jde_certificados_reten_cab certificados',
'        where documento.codigoproveedor = certificados.codigoproveedor',
'        and documento.tipo = certificados.documentotipo',
'        and rpad(documento.numero,25,'' '') = certificados.numerofactura',
');'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_display_condition_type=>'EXPRESSION'
,p_plug_display_when_condition=>':P603_ID_REGION = 9'
,p_plug_display_when_cond2=>'PLSQL'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>11
,p_prn_height=>8.5
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
,p_ai_enabled=>false
,p_updated_on=>wwv_flow_imp.dz('20260422221114Z')
,p_updated_by=>'JBALCAZAR'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(444194299152659496)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'TOP_AND_BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'MFERRIN'
,p_internal_uid=>444194299152659496
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(444194377597659497)
,p_db_column_name=>'USUARIO'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Usuario'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(444194454164659498)
,p_db_column_name=>'NUMERO'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Numero'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(444194873789659502)
,p_db_column_name=>'CODIGO'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Codigo'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(444195020472659503)
,p_db_column_name=>'CODIGODOCUMENTO'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Codigodocumento'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(444195067147659504)
,p_db_column_name=>'TIPO'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Tipo'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(444195214044659505)
,p_db_column_name=>'BATCH'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'Batch'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(444195231782659506)
,p_db_column_name=>'ORDENCOMPRA'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>'Ordencompra'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(444195410563659507)
,p_db_column_name=>'CODIGOPROVEEDOR'
,p_display_order=>80
,p_column_identifier=>'H'
,p_column_label=>'Codigoproveedor'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(444195514802659508)
,p_db_column_name=>'PROVEEDOR'
,p_display_order=>90
,p_column_identifier=>'I'
,p_column_label=>'Proveedor'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(444195557792659509)
,p_db_column_name=>'ESTADO'
,p_display_order=>100
,p_column_identifier=>'J'
,p_column_label=>'Estado'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(444195699807659510)
,p_db_column_name=>'FECHAEMISION'
,p_display_order=>110
,p_column_identifier=>'K'
,p_column_label=>'Fechaemision'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(444226789896197061)
,p_db_column_name=>'OBSERVACION'
,p_display_order=>120
,p_column_identifier=>'L'
,p_column_label=>'Observacion'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(444236409294200617)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'1993058'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'USUARIO:NUMERO:CODIGO:CODIGODOCUMENTO:TIPO:BATCH:ORDENCOMPRA:CODIGOPROVEEDOR:PROVEEDOR:ESTADO:FECHAEMISION:OBSERVACION'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(467376626359480373)
,p_plug_name=>unistr('\00D3RDENES RECEPCIONADAS PENDIENTES DE COTEJAR')
,p_parent_plug_id=>wwv_flow_imp.id(437058126608266889)
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(112813843178917343)
,p_plug_display_sequence=>20
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'with tob as (SELECT id_tabla tob_id, descripcion tob_descripcion',
'             FROM DATA.T_CORP_UDC',
'             WHERE activo = ''1''',
'               and id_cabecera = ''FINZ_GT02''',
'               AND id_tabla >= ''900'')',
'   , tpr as (SELECT id_tabla tpr_id, descripcion tpr_descripcion',
'             FROM DATA.T_CORP_UDC',
'             WHERE activo = ''1''',
'               and id_cabecera = ''FINZ_GT01''',
'               AND id_tabla != ''000''',
'               and id_tabla = ''001'')',
'   , base as (select case',
'                         when dat.estado = ''3'' then datosfin',
'                         else',
'                             case when datosmod is null then datosini else datosmod end',
'                         end',
'                         datosjson',
'              from DATA.t_finz_gestiontributariadet det',
'                       inner join DATA.t_finz_gestiontributariadatos dat on det.id = dat.iddet',
'                       inner join DATA.t_finz_gestiontributariacfg cfg on cfg.id = dat.idcfg',
'                       INNER JOIN DATA.t_finz_gestiontributaria gtb on to_char(gtb.id) = to_char(det.idgtb)',
'                       INNER JOIN tob ON tob_id = cfg.tipoobjeto',
'                       INNER JOIN tpr ON tpr_id = cfg.idproceso',
'              WHERE 1 = 1',
'                and det.idgtb = (SELECT max(id) FROM DATA.T_FINZ_GESTIONTRIBUTARIA where compania = ''00001'')',
'                and cfg.estado = 1',
'                and trim(tob_descripcion) != ''RESULTADOS ATS XML''',
'                and datosmod is not null)',
'',
'SELECT jt.comprobante,',
'       jt.documento_jde,',
'       jt.tipo_documento_jde,',
'       jt.documento,',
'       jt.tipodocumento,',
'       jt.codigo_emisor,',
'       jt.ruc_emisor,',
'       jt.razon_social_emisor,',
'       jt.fechaemision,',
'       jt.num_doc_modificado,',
'       jt.total_jde,',
'       jt.total_rec,',
'       jt.total_sri,',
'       jt.dif_jdesri,',
'       jt.comentario',
'FROM base b,',
'     JSON_TABLE(',
'             b.datosjson,',
'             ''$[*]''',
'             COLUMNS (',
'                 id NUMBER PATH ''$.ID'',',
'                 idpadre NUMBER PATH ''$.IDPADRE'',',
'                 comprobante VARCHAR2(50) PATH ''$.COMPROBANTE'',',
'                 documento_jde VARCHAR2(50) PATH ''$.DOCUMENTO_JDE'',',
'                 tipo_documento_jde VARCHAR2(10) PATH ''$.TIPO_DOCUMENTO_JDE'',',
'                 documento VARCHAR2(50) PATH ''$.DOCUMENTO'',',
'                 tipodocumento VARCHAR2(5) PATH ''$.TIPODOCUMENTO'',',
'                 codigo_emisor VARCHAR2(20) PATH ''$.CODIGO_EMISOR'',',
'                 ruc_emisor VARCHAR2(20) PATH ''$.RUC_EMISOR'',',
'                 razon_social_emisor VARCHAR2(200) PATH ''$.RAZON_SOCIAL_EMISOR'',',
'                 fechaemision TIMESTAMP PATH ''$.FECHAEMISION'',',
'                 num_doc_modificado VARCHAR2(50) PATH ''$.NUMERO_DOCUMENTO_MODIFICADO'',',
'                 total_jde NUMBER(15, 2) PATH ''$.TOTALJDE'',',
'                 total_rec NUMBER(15, 2) PATH ''$.TOTALREC'',',
'                 total_sri NUMBER(15, 2) PATH ''$.TOTALSRI'',',
'                 dif_jdesri NUMBER(15, 2) PATH ''$.DIF_JDESRI'',',
'                 comentario VARCHAR2(500) PATH ''$.COMENTARIO'',',
'                 validaciones VARCHAR2(500) PATH ''$.VALIDACIONES''',
'                 )',
'     ) jt',
'where (validaciones like ''%Doc. no encontrado JDE%'' or validaciones like ''%Doc. no registrado por el cliente/proveedor%'' )',
'and jt.tipo_documento_jde = ''PV''',
''))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_display_condition_type=>'EXPRESSION'
,p_plug_display_when_condition=>':P603_ID_REGION = 1'
,p_plug_display_when_cond2=>'PLSQL'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>11
,p_prn_height=>8.5
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(467376821527480374)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'TOP_AND_BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'MFERRIN'
,p_internal_uid=>467376821527480374
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(467376884881480375)
,p_db_column_name=>'COMPROBANTE'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Comprobante'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(467376949139480376)
,p_db_column_name=>'DOCUMENTO_JDE'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Documento Jde'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(467377046377480377)
,p_db_column_name=>'TIPO_DOCUMENTO_JDE'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Tipo Documento Jde'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(467377125258480378)
,p_db_column_name=>'DOCUMENTO'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Documento'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(467377232546480379)
,p_db_column_name=>'TIPODOCUMENTO'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Tipodocumento'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(467377402702480380)
,p_db_column_name=>'CODIGO_EMISOR'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'Codigo Emisor'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(467377502743480381)
,p_db_column_name=>'RUC_EMISOR'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>'Ruc Emisor'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(467377578524480382)
,p_db_column_name=>'RAZON_SOCIAL_EMISOR'
,p_display_order=>80
,p_column_identifier=>'H'
,p_column_label=>'Razon Social Emisor'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(467377624526480383)
,p_db_column_name=>'FECHAEMISION'
,p_display_order=>90
,p_column_identifier=>'I'
,p_column_label=>'Fechaemision'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(467377776645480384)
,p_db_column_name=>'NUM_DOC_MODIFICADO'
,p_display_order=>100
,p_column_identifier=>'J'
,p_column_label=>'Num Doc Modificado'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(467377858073480385)
,p_db_column_name=>'TOTAL_JDE'
,p_display_order=>110
,p_column_identifier=>'K'
,p_column_label=>'Total Jde'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(467377989895480386)
,p_db_column_name=>'TOTAL_REC'
,p_display_order=>120
,p_column_identifier=>'L'
,p_column_label=>'Total Rec'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(467378063391480387)
,p_db_column_name=>'TOTAL_SRI'
,p_display_order=>130
,p_column_identifier=>'M'
,p_column_label=>'Total Sri'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(467378191068480388)
,p_db_column_name=>'DIF_JDESRI'
,p_display_order=>140
,p_column_identifier=>'N'
,p_column_label=>'Dif Jdesri'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(467378236512480389)
,p_db_column_name=>'COMENTARIO'
,p_display_order=>150
,p_column_identifier=>'O'
,p_column_label=>'Comentario'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(467563856617522364)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'2226333'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'COMPROBANTE:DOCUMENTO_JDE:TIPO_DOCUMENTO_JDE:DOCUMENTO:TIPODOCUMENTO:CODIGO_EMISOR:RUC_EMISOR:RAZON_SOCIAL_EMISOR:FECHAEMISION:NUM_DOC_MODIFICADO:TOTAL_JDE:TOTAL_REC:TOTAL_SRI:DIF_JDESRI:COMENTARIO'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(444226935198197063)
,p_plug_name=>'Cuentas por pagar (Colaboradores)'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(38289867500120143)
,p_plug_display_sequence=>120
,p_location=>null
,p_plug_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_plug_display_when_condition=>'P603_MODULO'
,p_plug_display_when_cond2=>'CXPCF'
,p_ai_enabled=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
,p_updated_on=>wwv_flow_imp.dz('20260428143434Z')
,p_updated_by=>'JBALCAZAR'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(444679213268692561)
,p_plug_name=>unistr('VI\00C1TICOS PENDIENTES DE LIQUIDAR (PENDIENTE DE SUBIR LOS SOPORTES)')
,p_parent_plug_id=>wwv_flow_imp.id(444226935198197063)
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(112813843178917343)
,p_plug_display_sequence=>120
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT CODMODULO,NUMEROVIATICO,NUMEROIDENTIFICACION,SOLICITANTE,UNIDADNEGOCIODES,',
'       ESTADOAPROBACION,FECHASOLICITUD,FECHAAPROBACION,FECHAINICIO,',
'       FECHAFIN,FECHAPAGO,FECHALIQUIDACION FROM DATA.VT_GVIA_DATOSVIATICO',
unistr('WHERE ESTADOAPROBACION = ''Pendiente Liquidaci\00F3n'''),
'AND FECHAFIN BETWEEN TRUNC(SYSDATE,''MM'') AND LAST_DAY(SYSDATE)'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_display_condition_type=>'EXPRESSION'
,p_plug_display_when_condition=>':P603_ID_REGION = 2'
,p_plug_display_when_cond2=>'PLSQL'
,p_ai_enabled=>false
,p_updated_on=>wwv_flow_imp.dz('20260428143645Z')
,p_updated_by=>'JBALCAZAR'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(444679234463692562)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'TOP_AND_BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'MFERRIN'
,p_internal_uid=>444679234463692562
,p_updated_on=>wwv_flow_imp.dz('20260428140218Z')
,p_updated_by=>'JBALCAZAR'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(444679359250692563)
,p_db_column_name=>'CODMODULO'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Codmodulo'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(444679512155692564)
,p_db_column_name=>'NUMEROVIATICO'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Numeroviatico'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(444679547387692565)
,p_db_column_name=>'NUMEROIDENTIFICACION'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Numeroidentificacion'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(444679632411692566)
,p_db_column_name=>'SOLICITANTE'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Solicitante'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(444679751870692567)
,p_db_column_name=>'UNIDADNEGOCIODES'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Unidadnegociodes'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(444679856260692568)
,p_db_column_name=>'ESTADOAPROBACION'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'Estadoaprobacion'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(444680026380692570)
,p_db_column_name=>'FECHASOLICITUD'
,p_display_order=>80
,p_column_identifier=>'G'
,p_column_label=>'Fechasolicitud'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(444680154610692571)
,p_db_column_name=>'FECHAINICIO'
,p_display_order=>90
,p_column_identifier=>'H'
,p_column_label=>'Fechainicio'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(444680321827692572)
,p_db_column_name=>'FECHAFIN'
,p_display_order=>100
,p_column_identifier=>'I'
,p_column_label=>'Fechafin'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(444680403075692573)
,p_db_column_name=>'FECHAPAGO'
,p_display_order=>110
,p_column_identifier=>'J'
,p_column_label=>'Fechapago'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(444680456622692574)
,p_db_column_name=>'FECHALIQUIDACION'
,p_display_order=>120
,p_column_identifier=>'K'
,p_column_label=>'Fechaliquidacion'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(444680637121692576)
,p_db_column_name=>'FECHAAPROBACION'
,p_display_order=>130
,p_column_identifier=>'L'
,p_column_label=>'Fechaaprobacion'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(444688773090718352)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'1997582'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'CODMODULO:NUMEROVIATICO:NUMEROIDENTIFICACION:SOLICITANTE:UNIDADNEGOCIODES:ESTADOAPROBACION:FECHASOLICITUD:FECHAINICIO:FECHAFIN:FECHAPAGO:FECHALIQUIDACION:FECHAAPROBACION'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(444680813298692577)
,p_plug_name=>unistr('VI\00C1TICOS SIN LIQUIDAR CON FECHA M\00C1XIMA HASTA EL 1 DEL SIGUIENTE MES  (SEGUNDA QUINCENA)')
,p_parent_plug_id=>wwv_flow_imp.id(444226935198197063)
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(112813843178917343)
,p_plug_display_sequence=>130
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT CODMODULO,NUMEROVIATICO,NUMEROIDENTIFICACION,SOLICITANTE,UNIDADNEGOCIODES,',
'       ESTADOAPROBACION,FECHASOLICITUD,FECHAAPROBACION,FECHAINICIO,',
'       FECHAFIN,FECHAPAGO,FECHALIQUIDACION FROM DATA.VT_GVIA_DATOSVIATICO',
unistr('WHERE ESTADOAPROBACION = ''Pendiente Liquidaci\00F3n'' '),
'AND FECHAFIN BETWEEN TRUNC(SYSDATE,''MM'') AND LAST_DAY(SYSDATE)',
'AND EXTRACT(DAY FROM SYSDATE) >= 20;'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_display_condition_type=>'EXPRESSION'
,p_plug_display_when_condition=>':P603_ID_REGION = 3'
,p_plug_display_when_cond2=>'PLSQL'
,p_ai_enabled=>false
,p_updated_on=>wwv_flow_imp.dz('20260428143645Z')
,p_updated_by=>'JBALCAZAR'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(444680869985692578)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'TOP_AND_BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'MFERRIN'
,p_internal_uid=>444680869985692578
,p_updated_on=>wwv_flow_imp.dz('20260428140704Z')
,p_updated_by=>'JBALCAZAR'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(444680969142692579)
,p_db_column_name=>'CODMODULO'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Codmodulo'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(444681085243692580)
,p_db_column_name=>'NUMEROVIATICO'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Numeroviatico'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(444681173203692581)
,p_db_column_name=>'NUMEROIDENTIFICACION'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Numeroidentificacion'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(444681304113692582)
,p_db_column_name=>'SOLICITANTE'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Solicitante'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(444681412254692583)
,p_db_column_name=>'UNIDADNEGOCIODES'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Unidadnegociodes'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(444681430536692584)
,p_db_column_name=>'ESTADOAPROBACION'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'Estadoaprobacion'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(444681608744692585)
,p_db_column_name=>'FECHASOLICITUD'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>'Fechasolicitud'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(444681650528692586)
,p_db_column_name=>'FECHAINICIO'
,p_display_order=>80
,p_column_identifier=>'H'
,p_column_label=>'Fechainicio'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(444681739360692587)
,p_db_column_name=>'FECHAFIN'
,p_display_order=>90
,p_column_identifier=>'I'
,p_column_label=>'Fechafin'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(444681920299692588)
,p_db_column_name=>'FECHAPAGO'
,p_display_order=>100
,p_column_identifier=>'J'
,p_column_label=>'Fechapago'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(444682010644692589)
,p_db_column_name=>'FECHALIQUIDACION'
,p_display_order=>110
,p_column_identifier=>'K'
,p_column_label=>'Fechaliquidacion'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(444682085448692590)
,p_db_column_name=>'FECHAAPROBACION'
,p_display_order=>120
,p_column_identifier=>'L'
,p_column_label=>'Fechaaprobacion'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(444701333669840482)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'1997708'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'CODMODULO:NUMEROVIATICO:NUMEROIDENTIFICACION:SOLICITANTE:UNIDADNEGOCIODES:ESTADOAPROBACION:FECHASOLICITUD:FECHAINICIO:FECHAFIN:FECHAPAGO:FECHALIQUIDACION:FECHAAPROBACION'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(444682210705692591)
,p_plug_name=>unistr('VI\00C1TICOS ENVIADOS A CORTE DESPU\00C9S DEL 22 CON FECHA FIN MENOR AL 20')
,p_parent_plug_id=>wwv_flow_imp.id(444226935198197063)
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(112813843178917343)
,p_plug_display_sequence=>140
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT CODMODULO,NUMEROVIATICO,NUMEROIDENTIFICACION,SOLICITANTE,UNIDADNEGOCIODES,',
'       ESTADOAPROBACION,FECHASOLICITUD,FECHAAPROBACION,FECHAINICIO,',
'       FECHAFIN,FECHAPAGO,FECHALIQUIDACION FROM DATA.VT_GVIA_DATOSVIATICO',
'WHERE ',
'FECHASOLICITUD BETWEEN TRUNC(SYSDATE,''MM'') AND LAST_DAY(SYSDATE)',
'AND ',
unistr('EXTRACT(DAY FROM FECHASOLICITUD) >= 22 AND EXTRACT(DAY FROM FECHAFIN) <= 20 AND ESTADOAPROBACION = ''Pendiente Liquidaci\00F3n'' ')))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_display_condition_type=>'EXPRESSION'
,p_plug_display_when_condition=>':P603_ID_REGION = 4'
,p_plug_display_when_cond2=>'PLSQL'
,p_ai_enabled=>false
,p_updated_on=>wwv_flow_imp.dz('20260428143645Z')
,p_updated_by=>'JBALCAZAR'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(444682311144692592)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'TOP_AND_BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'MFERRIN'
,p_internal_uid=>444682311144692592
,p_updated_on=>wwv_flow_imp.dz('20260428141014Z')
,p_updated_by=>'JBALCAZAR'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(444682326552692593)
,p_db_column_name=>'CODMODULO'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Codmodulo'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(444682475076692594)
,p_db_column_name=>'NUMEROVIATICO'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Numeroviatico'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(444682592468692595)
,p_db_column_name=>'NUMEROIDENTIFICACION'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Numeroidentificacion'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(444682718515692596)
,p_db_column_name=>'SOLICITANTE'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Solicitante'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(444682767675692597)
,p_db_column_name=>'UNIDADNEGOCIODES'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Unidadnegociodes'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(444682902435692598)
,p_db_column_name=>'ESTADOAPROBACION'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'Estadoaprobacion'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(444683003086692599)
,p_db_column_name=>'FECHASOLICITUD'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>'Fechasolicitud'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(444683030095692600)
,p_db_column_name=>'FECHAINICIO'
,p_display_order=>80
,p_column_identifier=>'H'
,p_column_label=>'Fechainicio'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(444683131238692601)
,p_db_column_name=>'FECHAFIN'
,p_display_order=>90
,p_column_identifier=>'I'
,p_column_label=>'Fechafin'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(444683319080692602)
,p_db_column_name=>'FECHAPAGO'
,p_display_order=>100
,p_column_identifier=>'J'
,p_column_label=>'Fechapago'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(444683361734692603)
,p_db_column_name=>'FECHALIQUIDACION'
,p_display_order=>110
,p_column_identifier=>'K'
,p_column_label=>'Fechaliquidacion'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(444683510774692604)
,p_db_column_name=>'FECHAAPROBACION'
,p_display_order=>120
,p_column_identifier=>'L'
,p_column_label=>'Fechaaprobacion'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(444700538046831031)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'1997700'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'CODMODULO:NUMEROVIATICO:NUMEROIDENTIFICACION:SOLICITANTE:UNIDADNEGOCIODES:ESTADOAPROBACION:FECHASOLICITUD:FECHAINICIO:FECHAFIN:FECHAPAGO:FECHALIQUIDACION:FECHAAPROBACION'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(446840031172129073)
,p_plug_name=>unistr('EXISTENCIA DE DOS O M\00C1S VI\00C1TICOS POR PERSONA EN MISMA FECHA')
,p_parent_plug_id=>wwv_flow_imp.id(444226935198197063)
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(112813843178917343)
,p_plug_display_sequence=>110
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT',
'    V1.NUMEROIDENTIFICACION,',
'    V1.NUMEROVIATICO AS VIATICO_BASE,',
'    V1.FECHAINICIO AS INICIO_BASE,',
'    V1.FECHAFIN AS FIN_BASE,',
'    V2.NUMEROVIATICO AS VIATICO_SOLAPADO,',
'    V2.FECHAINICIO AS INICIO_SOLAPADO,',
'    V2.FECHAFIN AS FIN_SOLAPADO,',
'    V1.SOLICITANTE',
'FROM DATA.VT_GVIA_DATOSVIATICO V1',
'INNER JOIN DATA.VT_GVIA_DATOSVIATICO V2',
'    ON V1.NUMEROIDENTIFICACION = V2.NUMEROIDENTIFICACION -- Mismo empleado',
'    AND V1.NUMEROVIATICO > V2.NUMEROVIATICO            -- No compararse consigo mismo',
'WHERE V1.FECHASOLICITUD >= TRUNC(SYSDATE, ''Y'')',
unistr('    -- L\00F3gica de Solapamiento:'),
'    AND V1.FECHAINICIO <= V2.FECHAFIN',
'    AND V1.FECHAFIN >= V2.FECHAINICIO',
'ORDER BY V1.NUMEROIDENTIFICACION, V1.FECHAINICIO;'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_display_condition_type=>'EXPRESSION'
,p_plug_display_when_condition=>':P603_ID_REGION = 1'
,p_plug_display_when_cond2=>'PLSQL'
,p_ai_enabled=>false
,p_updated_on=>wwv_flow_imp.dz('20260428143645Z')
,p_updated_by=>'JBALCAZAR'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(446840165555129074)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'TOP_AND_BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'MFERRIN'
,p_internal_uid=>446840165555129074
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(446840246352129075)
,p_db_column_name=>'NUMEROIDENTIFICACION'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Numeroidentificacion'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(446840410283129076)
,p_db_column_name=>'SOLICITANTE'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Solicitante'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(446840501126129077)
,p_db_column_name=>'VIATICO_BASE'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Viatico Base'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(446840556656129078)
,p_db_column_name=>'INICIO_BASE'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Inicio Base'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(446840700255129079)
,p_db_column_name=>'FIN_BASE'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Fin Base'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(446840805690129080)
,p_db_column_name=>'VIATICO_SOLAPADO'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'Viatico Solapado'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(446840825472129081)
,p_db_column_name=>'INICIO_SOLAPADO'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>'Inicio Solapado'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(446840949206129082)
,p_db_column_name=>'FIN_SOLAPADO'
,p_display_order=>80
,p_column_identifier=>'H'
,p_column_label=>'Fin Solapado'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(446949120188435482)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'2020185'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'NUMEROIDENTIFICACION:SOLICITANTE:VIATICO_BASE:INICIO_BASE:FIN_BASE:VIATICO_SOLAPADO:INICIO_SOLAPADO:FIN_SOLAPADO'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(446842101993129093)
,p_plug_name=>unistr('Tesorer\00EDa')
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(38289867500120143)
,p_plug_display_sequence=>130
,p_location=>null
,p_plug_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_plug_display_when_condition=>'P603_MODULO'
,p_plug_display_when_cond2=>'TESOR'
,p_ai_enabled=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
,p_updated_on=>wwv_flow_imp.dz('20260506175646Z')
,p_updated_by=>'JBALCAZAR'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(446843525975129108)
,p_plug_name=>'EMPLEADOS SIN CUENTA DE BANCO'
,p_parent_plug_id=>wwv_flow_imp.id(446842101993129093)
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(112813843178917343)
,p_plug_display_sequence=>160
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT',
'    AB.ABALPH NOMBRES, AB.ABTAX DNI, TO_DATE(TO_CHAR(1900000 + AB.ABUPMJ), ''YYYYDDD'') FECHA_ACTUALIZACION, AB.ABYEARSTAR ANIO_CREACION',
'FROM',
'    PRODDTA.F0101@jdedtadl AB',
'INNER JOIN DATA.VT_ADT_EMPLEADOS VT ON AB.ABTAX = RPAD(IDENTIFICACION,20)',
'WHERE AB.ABAT1 = ''E''',
'AND VT.ESTADO = 1',
'AND NOT EXISTS(',
'    SELECT 1',
'    FROM PRODDTA.F76E0030@jdedtadl C',
'    WHERE AB.ABAN8 = C.IBAN8',
');'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_display_condition_type=>'EXPRESSION'
,p_plug_display_when_condition=>':P603_ID_REGION = 1'
,p_plug_display_when_cond2=>'PLSQL'
,p_ai_enabled=>false
,p_updated_on=>wwv_flow_imp.dz('20260506180017Z')
,p_updated_by=>'JBALCAZAR'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(446843629069129109)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'TOP_AND_BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'MFERRIN'
,p_internal_uid=>446843629069129109
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(449398519826305272)
,p_db_column_name=>'NOMBRES'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Nombres'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(449398539887305273)
,p_db_column_name=>'DNI'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Dni'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(449398753756305275)
,p_db_column_name=>'ANIO_CREACION'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Anio Creacion'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(449398850108305276)
,p_db_column_name=>'FECHA_ACTUALIZACION'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Fecha Actualizacion'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(449408221394306607)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'2044776'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'NOMBRES:DNI:FECHA_ACTUALIZACION:ANIO_CREACION:'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(449398969967305277)
,p_plug_name=>unistr('CONTROL DE SERVICIOS B\00C1SICOS Y MANTENIMIENTO')
,p_parent_plug_id=>wwv_flow_imp.id(446842101993129093)
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(112813843178917343)
,p_plug_display_sequence=>170
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT',
'    AB.ABAN8 AS Codigo_Proveedor,',
'    TRIM(AB.ABALPH) AS Nombre_Proveedor,',
'    AB.ABSIC AS Clasificacion,',
unistr('    ''SERVICIO B\00C1SICO SIN FACTURA [PV] INGRESADA ESTE MES'' AS Estado'),
'FROM',
'    PRODDTA.F0101@jdedtadl AB',
'WHERE',
'    AB.ABAN8 IN (54260, 53881, 52560, 68718)',
'    --AND',
'    --AB.ABSIC =''MANT'' AND AB.ABAT1 IN (''PL'',''PE'')',
'    -- Validamos que no tengan ninguna PV en el periodo actual',
'    AND NOT EXISTS (',
'        SELECT 1',
'        FROM PRODDTA.F0411@jdedtadl RP',
'        WHERE',
'            RP.RPPYE = AB.ABAN8',
'            AND RP.RPKCO = ''00001''',
'            AND RP.RPDCT = ''PV''',
'            AND RP.RPFY = TO_NUMBER(TO_CHAR(SYSDATE, ''YYYY'')) - 2000',
'            AND (',
'             (RPPN = EXTRACT(MONTH FROM SYSDATE)-1 AND :P603_EN_VENT_ANT = 1)',
'             OR ',
'             (RPPN = EXTRACT(MONTH FROM SYSDATE) AND :P603_EN_VENT_ANT = 0)',
'            )',
'    )',
'ORDER BY',
'    AB.ABALPH ASC;',
''))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_display_condition_type=>'EXPRESSION'
,p_plug_display_when_condition=>':P603_ID_REGION = 2'
,p_plug_display_when_cond2=>'PLSQL'
,p_ai_enabled=>false
,p_updated_on=>wwv_flow_imp.dz('20260506180017Z')
,p_updated_by=>'JBALCAZAR'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(449399027782305278)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'TOP_AND_BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'MFERRIN'
,p_internal_uid=>449399027782305278
,p_updated_on=>wwv_flow_imp.dz('20260506171442Z')
,p_updated_by=>'JBALCAZAR'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(449399616919305283)
,p_db_column_name=>'CODIGO_PROVEEDOR'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Codigo Proveedor'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(449399690609305284)
,p_db_column_name=>'NOMBRE_PROVEEDOR'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Nombre Proveedor'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(449399758769305285)
,p_db_column_name=>'CLASIFICACION'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Clasificacion'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(449399880190305286)
,p_db_column_name=>'ESTADO'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Estado'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(449418762759536197)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'2044882'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'CODIGO_PROVEEDOR:NOMBRE_PROVEEDOR:CLASIFICACION:ESTADO'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(449401636035305304)
,p_plug_name=>'ASIENTOS COMISIONES BANCOS LOCALES'
,p_parent_plug_id=>wwv_flow_imp.id(446842101993129093)
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(112813843178917343)
,p_plug_display_sequence=>220
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'WITH CUENTAS_REQUERIDAS AS (',
'    -- 1. Definimos la cuenta completa: Centro de Costo (MCU), Objeto (OBJ) y Auxiliar (SUB)',
'    SELECT ''16101'' AS Centro_Costo, ''65101'' AS Objeto, ''02'' AS Auxiliar FROM DUAL',
')',
'',
'-- 2. Seleccionamos de nuestra lista virtual y filtramos las que NO existen en contabilidad',
'SELECT',
'    c.Centro_Costo,',
'    c.Objeto AS Cuenta_Objeto,',
'    c.Auxiliar AS Cuenta_Auxiliar,',
'    c.Centro_Costo || ''.'' || c.Objeto || ''.'' || c.Auxiliar AS Cuenta_Formateada,',
'    ''FALTA ASIENTO TIPO JE EN CUENTA 16101.65101.02'' AS Estado_Alerta',
'',
'FROM',
'    CUENTAS_REQUERIDAS c',
'',
'WHERE NOT EXISTS (',
unistr('    -- 3. Buscamos si el gasto ya se distribuy\00F3 en la F0911'),
'    SELECT 1',
'    FROM PRODDTA.F0911@jdedtadl gl',
'    WHERE',
'        TRIM(gl.GLMCU) = c.Centro_Costo',
'        AND gl.GLOBJ = c.Objeto',
'        AND gl.GLSUB = c.Auxiliar',
'',
'        -- Filtros vitales de JD Edwards',
'        AND gl.GLDCT = ''PV''           -- Tipo de Documento: Voucher (Factura de proveedor)',
'        AND gl.GLLT = ''AA''            -- Moneda Base',
unistr('        AND gl.GLPOST = ''P''           -- Distribuci\00F3n contabilizada'),
unistr('        AND gl.GLKCO = ''00001''        -- Compa\00F1\00EDa'),
'',
unistr('        -- Filtro din\00E1mico para buscar solo en el mes y a\00F1o en curso'),
'        AND gl.GLFY = TO_NUMBER(TO_CHAR(SYSDATE, ''YYYY'')) - 2000',
'        AND (',
'            (gl.GLPN = EXTRACT(MONTH FROM SYSDATE)-1 AND :P603_EN_VENT_ANT = 1)',
'            OR ',
'            (gl.GLPN = EXTRACT(MONTH FROM SYSDATE) AND :P603_EN_VENT_ANT = 0)',
'        )',
')',
'ORDER BY',
'    c.Centro_Costo,',
'    c.Objeto,',
'    c.Auxiliar;'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_display_condition_type=>'EXPRESSION'
,p_plug_display_when_condition=>':P603_ID_REGION = 34'
,p_plug_display_when_cond2=>'PLSQL'
,p_ai_enabled=>false
,p_updated_on=>wwv_flow_imp.dz('20260506164428Z')
,p_updated_by=>'JBALCAZAR'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(449401791079305305)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'TOP_AND_BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'MFERRIN'
,p_internal_uid=>449401791079305305
,p_updated_on=>wwv_flow_imp.dz('20260506164150Z')
,p_updated_by=>'JBALCAZAR'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(449401865175305306)
,p_db_column_name=>'CUENTA_OBJETO'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Cuenta Objeto'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(449402009732305307)
,p_db_column_name=>'CUENTA_AUXILIAR'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Cuenta Auxiliar'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(449402041409305308)
,p_db_column_name=>'CUENTA_FORMATEADA'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Cuenta Formateada'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(449402187098305309)
,p_db_column_name=>'ESTADO_ALERTA'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Estado Alerta'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(449402231564305310)
,p_db_column_name=>'CENTRO_COSTO'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Centro Costo'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(449453640659945826)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'2045231'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'CENTRO_COSTO:CUENTA_OBJETO:CUENTA_AUXILIAR:CUENTA_FORMATEADA:ESTADO_ALERTA:'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(451456602893529901)
,p_plug_name=>'COMISIONES BANCOS EXTERIOR'
,p_parent_plug_id=>wwv_flow_imp.id(446842101993129093)
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(112813843178917343)
,p_plug_display_sequence=>210
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT',
'    ''CITIBANK NEW YORK'' NOMBRE_BANCO,',
'    ''00405227'' CUENTA,',
'    SUM(MPAA/100) AS TOTAL,',
'    TRIM(GMMCU)||''.''||TRIM(GMOBJ)||''.''||TRIM(GMSUB) CUENTA_INTERES,',
'    ''11111.71201.04'' CUENTA_PRINCIPAL',
'FROM PRODDTA.F5509505@jdedtadl a',
'INNER JOIN PRODDTA.f0901@jdedtadl b ON a.MPAID = b.GMAID',
'WHERE trim(a.MPAID) = ''00405227'' AND MPEXR LIKE ''%BILLING%''',
' AND (',
'    (a.MPDGJ BETWEEN :P603_INICIO_MES_JDE AND :P603_FIN_MES_JDE AND :P603_EN_VENT_ANT = 0)',
'    OR',
'    (a.MPDGJ BETWEEN :P603_INICIO_MES_ANTERIOR_JDE AND :P603_FIN_MES_ANTERIOR_JDE AND :P603_EN_VENT_ANT = 1)',
' )',
'GROUP BY GMMCU,GMOBJ,GMSUB'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_display_condition_type=>'EXPRESSION'
,p_plug_display_when_condition=>':P603_ID_REGION = 36'
,p_plug_display_when_cond2=>'PLSQL'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>11
,p_prn_height=>8.5
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
,p_ai_enabled=>false
,p_updated_on=>wwv_flow_imp.dz('20260506163824Z')
,p_updated_by=>'JBALCAZAR'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(451456715149529902)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'TOP_AND_BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'MFERRIN'
,p_internal_uid=>451456715149529902
,p_updated_on=>wwv_flow_imp.dz('20260506163824Z')
,p_updated_by=>'JBALCAZAR'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(451456757852529903)
,p_db_column_name=>'NOMBRE_BANCO'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Nombre Banco'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(451456878011529904)
,p_db_column_name=>'CUENTA'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Cuenta'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(451456938741529905)
,p_db_column_name=>'TOTAL'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Total'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G990D00'
,p_use_as_row_header=>'N'
,p_updated_on=>wwv_flow_imp.dz('20260506163824Z')
,p_updated_by=>'JBALCAZAR'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(451457120374529906)
,p_db_column_name=>'CUENTA_INTERES'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Cuenta Interes'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(451457210446529907)
,p_db_column_name=>'CUENTA_PRINCIPAL'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Cuenta Principal'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(452830813224245074)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'2079002'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'NOMBRE_BANCO:CUENTA:TOTAL:CUENTA_INTERES:CUENTA_PRINCIPAL'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(452833104203307668)
,p_plug_name=>'CUENTAS DE BANCOS SOBREGIRADAS'
,p_parent_plug_id=>wwv_flow_imp.id(446842101993129093)
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(112813843178917343)
,p_plug_display_sequence=>230
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'WITH SALDOS_BANCARIOS AS (',
'    SELECT',
'        -- Concatenamos la cuenta y la limpiamos',
'        TRIM(B.GBMCU) || ''.'' || TRIM(B.GBOBJ) || ''.'' || TRIM(B.GBSUB) AS CUENTA_CONTABLE,',
'        TRIM(M.GMDL01) AS NOMBRE_BANCO,',
'',
unistr('        -- Envolvemos en SUM() para agrupar cualquier subauxiliar o divisi\00F3n interna'),
'        SUM(',
'            (B.GBAPYC +',
'             CASE WHEN EXTRACT(MONTH FROM SYSDATE) >= 1 THEN B.GBAN01 ELSE 0 END +',
'             CASE WHEN EXTRACT(MONTH FROM SYSDATE) >= 2 THEN B.GBAN02 ELSE 0 END +',
'             CASE WHEN EXTRACT(MONTH FROM SYSDATE) >= 3 THEN B.GBAN03 ELSE 0 END +',
'             CASE WHEN EXTRACT(MONTH FROM SYSDATE) >= 4 THEN B.GBAN04 ELSE 0 END +',
'             CASE WHEN EXTRACT(MONTH FROM SYSDATE) >= 5 THEN B.GBAN05 ELSE 0 END +',
'             CASE WHEN EXTRACT(MONTH FROM SYSDATE) >= 6 THEN B.GBAN06 ELSE 0 END +',
'             CASE WHEN EXTRACT(MONTH FROM SYSDATE) >= 7 THEN B.GBAN07 ELSE 0 END +',
'             CASE WHEN EXTRACT(MONTH FROM SYSDATE) >= 8 THEN B.GBAN08 ELSE 0 END +',
'             CASE WHEN EXTRACT(MONTH FROM SYSDATE) >= 9 THEN B.GBAN09 ELSE 0 END +',
'             CASE WHEN EXTRACT(MONTH FROM SYSDATE) >= 10 THEN B.GBAN10 ELSE 0 END +',
'             CASE WHEN EXTRACT(MONTH FROM SYSDATE) >= 11 THEN B.GBAN11 ELSE 0 END +',
'             CASE WHEN EXTRACT(MONTH FROM SYSDATE) >= 12 THEN B.GBAN12 ELSE 0 END',
'            ) / 100',
'        ) AS SALDO_ACTUAL',
'',
'    FROM',
'        PRODDTA.F0902@jdedtadl B',
'    INNER JOIN',
'        PRODDTA.F0901@jdedtadl M ON B.GBAID = M.GMAID',
'',
'    WHERE',
'        B.GBCO = ''00001''',
'        AND B.GBFY = TO_NUMBER(TO_CHAR(SYSDATE, ''YY''))',
'        AND B.GBLT = ''AA''',
'        AND TRIM(B.GBOBJ) IN (''11102'', ''11103'', ''11201'', ''11202'', ''11203'')',
'',
unistr('    -- Agrupamos para colapsar los duplicados en una sola l\00EDnea maestra'),
'    GROUP BY',
'        TRIM(B.GBMCU) || ''.'' || TRIM(B.GBOBJ) || ''.'' || TRIM(B.GBSUB),',
'        TRIM(M.GMDL01)',
')',
'',
'SELECT',
'    CUENTA_CONTABLE,',
'    NOMBRE_BANCO,',
'    SALDO_ACTUAL,',
'    ''ALERTA: CUENTA BANCARIA CON SALDO EN ROJO (SOBREGIRADA)'' AS ESTADO',
'FROM',
'    SALDOS_BANCARIOS',
'WHERE',
'    SALDO_ACTUAL < 0',
'ORDER BY',
'    CUENTA_CONTABLE;',
''))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_display_condition_type=>'EXPRESSION'
,p_plug_display_when_condition=>':P603_ID_REGION = 37'
,p_plug_display_when_cond2=>'PLSQL'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>11
,p_prn_height=>8.5
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(452833181671307669)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'TOP_AND_BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'MFERRIN'
,p_internal_uid=>452833181671307669
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(452833283959307670)
,p_db_column_name=>'NOMBRE_BANCO'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Nombre Banco'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(452833395924307671)
,p_db_column_name=>'CUENTA_CONTABLE'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Cuenta Contable'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(452833468203307672)
,p_db_column_name=>'SALDO_ACTUAL'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Saldo Actual'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(452833560851307673)
,p_db_column_name=>'ESTADO'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Estado'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(452845503994397045)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'2079149'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'NOMBRE_BANCO:CUENTA_CONTABLE:SALDO_ACTUAL:ESTADO'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(486667041356272996)
,p_plug_name=>'ASIENTO JE EN CUENTA 71201.04 (intereses ganados)'
,p_parent_plug_id=>wwv_flow_imp.id(446842101993129093)
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(112813843178917343)
,p_plug_display_sequence=>190
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT',
'    ''PRODUBANCO'' NOMBRE_BANCO,',
'    ''00330376'' CUENTA,',
'    SUM(MPAA/100) AS TOTAL,',
'    TRIM(GMMCU)||''.''||TRIM(GMOBJ)||''.''||TRIM(GMSUB) CUENTA_INTERES,',
'    ''11111.71201.04'' CUENTA_PRINCIPAL',
'FROM PRODDTA.F5509505@jdedtadl a',
'INNER JOIN PRODDTA.f0901@jdedtadl b ON a.MPAID = b.GMAID',
'WHERE TRIM(a.MPAID) = ''00330376'' AND a.MPEXR LIKE ''%OVERNIGHT%''',
' AND (',
'    (a.MPDGJ BETWEEN :P603_INICIO_MES_JDE AND :P603_FIN_MES_JDE AND :P603_EN_VENT_ANT = 0)',
'    OR',
'    (a.MPDGJ BETWEEN :P603_INICIO_MES_ANTERIOR_JDE AND :P603_FIN_MES_ANTERIOR_JDE AND :P603_EN_VENT_ANT = 1)',
' )',
'GROUP BY b.GMMCU, b.GMOBJ, b.GMSUB',
'UNION ALL',
'-- Bolivariano',
'SELECT',
'    ''BOLIVARIANO'' NOMBRE_BANCO,',
'    ''00405198'' CUENTA,',
'    SUM(MPAA/100) AS TOTAL,',
'    TRIM(GMMCU)||''.''||TRIM(GMOBJ)||''.''||TRIM(GMSUB) CUENTA_INTERES,',
'    ''11111.71201.04'' CUENTA_PRINCIPAL',
'FROM PRODDTA.F5509505@jdedtadl a',
'INNER JOIN PRODDTA.f0901@jdedtadl b ON a.MPAID = b.GMAID',
'WHERE TRIM(a.MPAID) = ''00405198'' AND a.MPEXR LIKE ''%PAGO DE INTERESES%''',
' AND (',
'    (a.MPDGJ BETWEEN :P603_INICIO_MES_JDE AND :P603_FIN_MES_JDE AND :P603_EN_VENT_ANT = 0)',
'    OR',
'    (a.MPDGJ BETWEEN :P603_INICIO_MES_ANTERIOR_JDE AND :P603_FIN_MES_ANTERIOR_JDE AND :P603_EN_VENT_ANT = 1)',
' )',
'GROUP BY b.GMMCU, b.GMOBJ, b.GMSUB',
'UNION ALL',
'-- Internacional',
'SELECT',
'    ''INTERNACIONAL'' NOMBRE_BANCO,',
'    ''00405171'' CUENTA,',
'    SUM(MPAA/100) AS TOTAL,',
'    TRIM(GMMCU)||''.''||TRIM(GMOBJ)||''.''||TRIM(GMSUB) CUENTA_INTERES,',
'    ''11111.71201.04'' CUENTA_PRINCIPAL',
'FROM PRODDTA.F5509505@jdedtadl a',
'INNER JOIN PRODDTA.f0901@jdedtadl b ON a.MPAID = b.GMAID',
'WHERE TRIM(a.MPAID) = ''00405171'' AND a.MPEXR LIKE ''%INTERESES%''',
' AND (',
'    (a.MPDGJ BETWEEN :P603_INICIO_MES_JDE AND :P603_FIN_MES_JDE AND :P603_EN_VENT_ANT = 0)',
'    OR',
'    (a.MPDGJ BETWEEN :P603_INICIO_MES_ANTERIOR_JDE AND :P603_FIN_MES_ANTERIOR_JDE AND :P603_EN_VENT_ANT = 1)',
' )',
'GROUP BY b.GMMCU, b.GMOBJ, b.GMSUB',
'UNION ALL',
'-- Citibank',
'SELECT',
'    ''CITIBANK'' NOMBRE_BANCO,',
'    ''00405201'' CUENTA,',
'    SUM(MPAA/100) AS TOTAL,',
'    TRIM(GMMCU)||''.''||TRIM(GMOBJ)||''.''||TRIM(GMSUB) CUENTA_INTERES,',
'    ''11111.71201.04'' CUENTA_PRINCIPAL',
'FROM PRODDTA.F5509505@jdedtadl a',
'INNER JOIN PRODDTA.f0901@jdedtadl b ON a.MPAID = b.GMAID',
'WHERE TRIM(a.MPAID) = ''00405201'' AND a.MPEXR LIKE ''%INTERES GANADO CTA%''',
' AND (',
'    (a.MPDGJ BETWEEN :P603_INICIO_MES_JDE AND :P603_FIN_MES_JDE AND :P603_EN_VENT_ANT = 0)',
'    OR',
'    (a.MPDGJ BETWEEN :P603_INICIO_MES_ANTERIOR_JDE AND :P603_FIN_MES_ANTERIOR_JDE AND :P603_EN_VENT_ANT = 1)',
' )',
'GROUP BY b.GMMCU, b.GMOBJ, b.GMSUB'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_display_condition_type=>'EXPRESSION'
,p_plug_display_when_condition=>':P603_ID_REGION = 35'
,p_plug_display_when_cond2=>'PLSQL'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>11
,p_prn_height=>8.5
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
,p_ai_enabled=>false
,p_updated_on=>wwv_flow_imp.dz('20260506163824Z')
,p_updated_by=>'JBALCAZAR'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(486667195733272997)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'TOP_AND_BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'MFERRIN'
,p_internal_uid=>486667195733272997
,p_updated_on=>wwv_flow_imp.dz('20260506163824Z')
,p_updated_by=>'JBALCAZAR'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(486667299743272998)
,p_db_column_name=>'NOMBRE_BANCO'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Nombre Banco'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(486667376935272999)
,p_db_column_name=>'CUENTA'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Cuenta'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(486667485558273000)
,p_db_column_name=>'TOTAL'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Total'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G990D00'
,p_use_as_row_header=>'N'
,p_updated_on=>wwv_flow_imp.dz('20260506163824Z')
,p_updated_by=>'JBALCAZAR'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(486667529701273001)
,p_db_column_name=>'CUENTA_INTERES'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Cuenta Interes'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(486667641340273002)
,p_db_column_name=>'CUENTA_PRINCIPAL'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Cuenta Principal'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(488088093582869410)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'2431575'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'NOMBRE_BANCO:CUENTA:TOTAL:CUENTA_INTERES:CUENTA_PRINCIPAL'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(451954149628478375)
,p_plug_name=>'RRHH'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(38289867500120143)
,p_plug_display_sequence=>170
,p_location=>null
,p_plug_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_plug_display_when_condition=>'P603_MODULO'
,p_plug_display_when_cond2=>'RRHH'
,p_ai_enabled=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(451954316934478376)
,p_plug_name=>'ASIENTO JN EN CUENTA 22401.01 y 11102.01 (PAGO IESS%)'
,p_parent_plug_id=>wwv_flow_imp.id(451954149628478375)
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(112813843178917343)
,p_plug_display_sequence=>110
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'WITH ASIENTOS_MES AS (',
unistr('    -- 1. Buscamos el monto de la l\00EDnea de provisi\00F3n espec\00EDfica (22401.01)'),
'    SELECT /*+ DRIVING_SITE(gl) */',
'        (gl.GLAA / 100) AS MONTO',
'    FROM PRODDTA.F0911@jdedtadl gl',
'    WHERE ',
'        gl.GLKCO = ''00001'' ',
'        AND gl.GLDCT = ''JN'' ',
'        AND gl.GLLT = ''AA'' ',
'        AND gl.GLFY = TO_NUMBER(TO_CHAR(SYSDATE, ''YY'')) ',
'        AND (',
'            (gl.GLPN = EXTRACT(MONTH FROM SYSDATE) AND :P603_EN_VENT_ANT = 0)',
'            OR ',
'            (gl.GLPN = EXTRACT(MONTH FROM SYSDATE)-1 AND :P603_EN_VENT_ANT = 1)',
'        )',
'        AND TRIM(gl.GLOBJ) = ''22401'' ',
'        AND TRIM(gl.GLSUB) = ''01''   -- Tu nueva cuenta objetivo',
'        ',
'        -- Validamos que tenga su contrapartida en bancos',
'        AND EXISTS (',
'            SELECT 1 ',
'            FROM PRODDTA.F0911@jdedtadl gl2',
'            WHERE ',
'                gl2.GLDOC = gl.GLDOC ',
'                AND gl2.GLKCO = gl.GLKCO ',
'                AND gl2.GLDCT = gl.GLDCT ',
'                AND gl2.GLFY = gl.GLFY',
'                AND TRIM(gl2.GLOBJ) = ''11102'' ',
'                AND TRIM(gl2.GLSUB) = ''01''',
'        )',
')',
'-- 2. Evaluamos el resultado para mostrar el estado y el total real',
'SELECT ',
'    CASE ',
'        WHEN SUM(MONTO) IS NULL THEN ''NO SE HA GENERADO ASIENTO''',
'        ELSE ''ASIENTO GENERADO''',
'    END AS ESTADO_ASIENTO,',
'    ',
'    -- Mantenemos el ABS() para que el valor contable negativo se muestre como un total positivo',
'    NVL(ABS(SUM(MONTO)), 0) AS TOTAL_ASIENTO ',
'FROM ',
'    ASIENTOS_MES;'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_display_condition_type=>'EXPRESSION'
,p_plug_display_when_condition=>':P603_ID_REGION = 1'
,p_plug_display_when_cond2=>'PLSQL'
,p_ai_enabled=>false
,p_updated_on=>wwv_flow_imp.dz('20260507180351Z')
,p_updated_by=>'JBALCAZAR'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(451954328390478377)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'TOP_AND_BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'MFERRIN'
,p_internal_uid=>451954328390478377
,p_updated_on=>wwv_flow_imp.dz('20260507180351Z')
,p_updated_by=>'JBALCAZAR'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(427465984063807007)
,p_db_column_name=>'ESTADO_ASIENTO'
,p_display_order=>10
,p_column_identifier=>'F'
,p_column_label=>'Estado Asiento'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20260421190247Z')
,p_updated_on=>wwv_flow_imp.dz('20260421190247Z')
,p_created_by=>'JBALCAZAR'
,p_updated_by=>'JBALCAZAR'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(427466042099807008)
,p_db_column_name=>'TOTAL_ASIENTO'
,p_display_order=>20
,p_column_identifier=>'G'
,p_column_label=>'Total Asiento'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G990D00'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20260421190247Z')
,p_updated_on=>wwv_flow_imp.dz('20260424195408Z')
,p_created_by=>'JBALCAZAR'
,p_updated_by=>'JBALCAZAR'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(451967576738334406)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'2070370'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'ESTADO_ASIENTO:TOTAL_ASIENTO:'
,p_updated_on=>wwv_flow_imp.dz('20260421190302Z')
,p_updated_by=>'MCHUQUIMARCA'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(451954922321478382)
,p_plug_name=>unistr('ASIENTO JN EN CUENTA 22401.02 y 11102.01 (PROVISI\00D3N FONDOS DE RESERVA)')
,p_parent_plug_id=>wwv_flow_imp.id(451954149628478375)
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(112813843178917343)
,p_plug_display_sequence=>120
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'WITH ASIENTOS_MES AS (',
unistr('    -- 1. Buscamos el monto de la l\00EDnea de provisi\00F3n espec\00EDfica (22401.02)'),
'    SELECT /*+ DRIVING_SITE(gl) */',
'        (gl.GLAA / 100) AS MONTO',
'    FROM PRODDTA.F0911@jdedtadl gl',
'    WHERE ',
'        gl.GLKCO = ''00001'' ',
'        AND gl.GLDCT = ''JN'' ',
'        AND gl.GLLT = ''AA'' ',
'        AND gl.GLFY = TO_NUMBER(TO_CHAR(SYSDATE, ''YY'')) ',
'        AND (',
'            (gl.GLPN = EXTRACT(MONTH FROM SYSDATE) AND :P603_EN_VENT_ANT = 0)',
'            OR ',
'            (gl.GLPN = EXTRACT(MONTH FROM SYSDATE)-1 AND :P603_EN_VENT_ANT = 1)',
'        )',
'        AND TRIM(gl.GLOBJ) = ''22401'' ',
'        AND TRIM(gl.GLSUB) = ''02''   -- Apuntando a la .02',
'        ',
'        -- Validamos que el mismo documento tenga la contrapartida en bancos (11102.01)',
'        AND EXISTS (',
'            SELECT 1 ',
'            FROM PRODDTA.F0911@jdedtadl gl2',
'            WHERE ',
'                gl2.GLDOC = gl.GLDOC ',
'                AND gl2.GLKCO = gl.GLKCO ',
'                AND gl2.GLDCT = gl.GLDCT ',
'                AND gl2.GLFY = gl.GLFY',
'                AND TRIM(gl2.GLOBJ) = ''11102'' ',
'                AND TRIM(gl2.GLSUB) = ''01''',
'        )',
')',
'-- 2. Evaluamos el resultado para mostrar el estado y el total real',
'SELECT ',
'    CASE ',
'        WHEN SUM(MONTO) IS NULL THEN ''NO SE HA GENERADO ASIENTO''',
'        ELSE ''ASIENTO GENERADO''',
'    END AS ESTADO_ASIENTO,',
'    ',
unistr('    -- Aplicamos ABS() para presentar el cr\00E9dito contable como un valor total positivo'),
'    NVL(ABS(SUM(MONTO)), 0) AS TOTAL_ASIENTO ',
'FROM ',
'    ASIENTOS_MES;'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_display_condition_type=>'EXPRESSION'
,p_plug_display_when_condition=>':P603_ID_REGION = 2'
,p_plug_display_when_cond2=>'PLSQL'
,p_ai_enabled=>false
,p_updated_on=>wwv_flow_imp.dz('20260507180351Z')
,p_updated_by=>'JBALCAZAR'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(451954997499478383)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'TOP_AND_BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'MFERRIN'
,p_internal_uid=>451954997499478383
,p_updated_on=>wwv_flow_imp.dz('20260507180351Z')
,p_updated_by=>'JBALCAZAR'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(427466129387807009)
,p_db_column_name=>'ESTADO_ASIENTO'
,p_display_order=>10
,p_column_identifier=>'F'
,p_column_label=>'Estado Asiento'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20260421190505Z')
,p_updated_on=>wwv_flow_imp.dz('20260421190505Z')
,p_created_by=>'JBALCAZAR'
,p_updated_by=>'JBALCAZAR'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(427466296736807010)
,p_db_column_name=>'TOTAL_ASIENTO'
,p_display_order=>20
,p_column_identifier=>'G'
,p_column_label=>'Total Asiento'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G990D00'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20260421190505Z')
,p_updated_on=>wwv_flow_imp.dz('20260424195408Z')
,p_created_by=>'JBALCAZAR'
,p_updated_by=>'JBALCAZAR'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(451999851089392319)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'2070693'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'ESTADO_ASIENTO:TOTAL_ASIENTO:'
,p_updated_on=>wwv_flow_imp.dz('20260421190518Z')
,p_updated_by=>'MCHUQUIMARCA'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(451955517817478388)
,p_plug_name=>unistr('ASIENTO JN EN CUENTA 22401.03 y 11102.01 (PR\00C9STAMOS)')
,p_parent_plug_id=>wwv_flow_imp.id(451954149628478375)
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(112813843178917343)
,p_plug_display_sequence=>130
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'WITH ASIENTOS_MES AS (',
unistr('    -- 1. Buscamos el monto de la l\00EDnea de provisi\00F3n de los asientos que cumplen ambas reglas'),
'    SELECT /*+ DRIVING_SITE(gl) */',
'        (gl.GLAA / 100) AS MONTO',
'    FROM PRODDTA.F0911@jdedtadl gl',
'    WHERE ',
'        gl.GLKCO = ''00001'' ',
'        AND gl.GLDCT = ''JN'' ',
'        AND gl.GLLT = ''AA'' ',
'        AND gl.GLFY = TO_NUMBER(TO_CHAR(SYSDATE, ''YY'')) ',
'        AND (',
'            (gl.GLPN = EXTRACT(MONTH FROM SYSDATE) AND :P603_EN_VENT_ANT = 0)',
'            OR ',
'            (gl.GLPN = EXTRACT(MONTH FROM SYSDATE)-1 AND :P603_EN_VENT_ANT = 1)',
'        )',
'        AND TRIM(gl.GLOBJ) = ''22401'' ',
'        AND TRIM(gl.GLSUB) = ''03''',
'        ',
'        -- Validamos que el mismo documento tenga la contrapartida en bancos',
'        AND EXISTS (',
'            SELECT 1 ',
'            FROM PRODDTA.F0911@jdedtadl gl2',
'            WHERE ',
'                gl2.GLDOC = gl.GLDOC ',
'                AND gl2.GLKCO = gl.GLKCO ',
'                AND gl2.GLDCT = gl.GLDCT ',
'                AND gl2.GLFY = gl.GLFY',
'                AND TRIM(gl2.GLOBJ) = ''11102'' ',
'                AND TRIM(gl2.GLSUB) = ''01''',
'        )',
')',
'-- 2. Evaluamos el resultado para lanzar la alerta o el total',
'SELECT ',
'    CASE ',
'        WHEN SUM(MONTO) IS NULL THEN ''NO SE HA GENERADO ASIENTO''',
'        ELSE ''ASIENTO GENERADO''',
'    END AS ESTADO_ASIENTO,',
'    ',
unistr('    -- Usamos ABS() por si la provisi\00F3n se guard\00F3 en negativo (cr\00E9dito)'),
'    NVL(ABS(SUM(MONTO)), 0) AS TOTAL_ASIENTO ',
'FROM ',
'    ASIENTOS_MES;'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_display_condition_type=>'EXPRESSION'
,p_plug_display_when_condition=>':P603_ID_REGION = 3'
,p_plug_display_when_cond2=>'PLSQL'
,p_ai_enabled=>false
,p_updated_on=>wwv_flow_imp.dz('20260507180351Z')
,p_updated_by=>'JBALCAZAR'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(451955611502478389)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'TOP_AND_BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'MFERRIN'
,p_internal_uid=>451955611502478389
,p_updated_on=>wwv_flow_imp.dz('20260507180351Z')
,p_updated_by=>'JBALCAZAR'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(427465786133807005)
,p_db_column_name=>'ESTADO_ASIENTO'
,p_display_order=>10
,p_column_identifier=>'F'
,p_column_label=>'Estado Asiento'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20260421185701Z')
,p_updated_on=>wwv_flow_imp.dz('20260421185701Z')
,p_created_by=>'JBALCAZAR'
,p_updated_by=>'JBALCAZAR'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(427465810391807006)
,p_db_column_name=>'TOTAL_ASIENTO'
,p_display_order=>20
,p_column_identifier=>'G'
,p_column_label=>'Total Asiento'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G990D00'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20260421185701Z')
,p_updated_on=>wwv_flow_imp.dz('20260424195408Z')
,p_created_by=>'JBALCAZAR'
,p_updated_by=>'JBALCAZAR'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(452872528969233837)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'2079420'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'ESTADO_ASIENTO:TOTAL_ASIENTO:'
,p_updated_on=>wwv_flow_imp.dz('20260421191005Z')
,p_updated_by=>'MCHUQUIMARCA'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(451956091174478394)
,p_plug_name=>'ASIENTO JN EN CUENTA 22403.02 ()'
,p_parent_plug_id=>wwv_flow_imp.id(451954149628478375)
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(112813843178917343)
,p_plug_display_sequence=>140
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'WITH ASIENTOS_MES AS (',
unistr('    -- 1. Buscamos el monto de la cuenta espec\00EDfica (22403.02)'),
'    SELECT /*+ DRIVING_SITE(gl) */',
'        (gl.GLAA / 100) AS MONTO',
'    FROM PRODDTA.F0911@jdedtadl gl',
'    WHERE ',
'        gl.GLKCO = ''00001'' ',
'        AND gl.GLDCT = ''JN'' ',
'        AND gl.GLLT = ''AA'' ',
'        AND gl.GLFY = TO_NUMBER(TO_CHAR(SYSDATE, ''YY'')) ',
'        AND (',
'            (gl.GLPN = EXTRACT(MONTH FROM SYSDATE) AND :P603_EN_VENT_ANT = 0)',
'            OR ',
'            (gl.GLPN = EXTRACT(MONTH FROM SYSDATE)-1 AND :P603_EN_VENT_ANT = 1)',
'        )',
'        AND TRIM(gl.GLOBJ) = ''22403'' ',
'        AND TRIM(gl.GLSUB) = ''02''',
')',
'-- 2. Evaluamos el resultado para mostrar el estado y el total real',
'SELECT ',
'    CASE ',
'        WHEN SUM(MONTO) IS NULL THEN ''NO SE HA GENERADO ASIENTO''',
'        ELSE ''ASIENTO GENERADO''',
'    END AS ESTADO_ASIENTO,',
'    ',
'    -- Aplicamos ABS() para presentar el valor contable como un total positivo',
'    NVL(ABS(SUM(MONTO)), 0) AS TOTAL_ASIENTO ',
'FROM ',
'    ASIENTOS_MES;'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_display_condition_type=>'EXPRESSION'
,p_plug_display_when_condition=>':P603_ID_REGION = 4'
,p_plug_display_when_cond2=>'PLSQL'
,p_ai_enabled=>false
,p_updated_on=>wwv_flow_imp.dz('20260507180351Z')
,p_updated_by=>'JBALCAZAR'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(451956159043478395)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'TOP_AND_BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'MFERRIN'
,p_internal_uid=>451956159043478395
,p_updated_on=>wwv_flow_imp.dz('20260507180351Z')
,p_updated_by=>'JBALCAZAR'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(427466376395807011)
,p_db_column_name=>'ESTADO_ASIENTO'
,p_display_order=>10
,p_column_identifier=>'F'
,p_column_label=>'Estado Asiento'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20260421190724Z')
,p_updated_on=>wwv_flow_imp.dz('20260421190724Z')
,p_created_by=>'JBALCAZAR'
,p_updated_by=>'JBALCAZAR'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(427466413819807012)
,p_db_column_name=>'TOTAL_ASIENTO'
,p_display_order=>20
,p_column_identifier=>'G'
,p_column_label=>'Total Asiento'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G990D00'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20260421190724Z')
,p_updated_on=>wwv_flow_imp.dz('20260424195408Z')
,p_created_by=>'JBALCAZAR'
,p_updated_by=>'JBALCAZAR'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(452855142233512216)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'2079246'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'ESTADO_ASIENTO:TOTAL_ASIENTO:'
,p_updated_on=>wwv_flow_imp.dz('20260421190949Z')
,p_updated_by=>'MCHUQUIMARCA'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(451956682229478400)
,p_plug_name=>unistr('ASIENTO JN EN CUENTA 22501.08 (PROVISI\00D3N BONO ANUAL)')
,p_parent_plug_id=>wwv_flow_imp.id(451954149628478375)
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(112813843178917343)
,p_plug_display_sequence=>150
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'WITH ASIENTOS_MES AS (',
'    -- 1. Extraemos el monto directamente de la cuenta 22501.08',
'    SELECT /*+ DRIVING_SITE(gl) */',
'        (gl.GLAA / 100) AS MONTO',
'    FROM PRODDTA.F0911@jdedtadl gl',
'    WHERE ',
'        gl.GLKCO = ''00001'' ',
'        AND gl.GLDCT = ''JN'' ',
'        AND gl.GLLT = ''AA'' ',
'        AND gl.GLFY = TO_NUMBER(TO_CHAR(SYSDATE, ''YY'')) ',
'        AND (',
'            (gl.GLPN = EXTRACT(MONTH FROM SYSDATE) AND :P603_EN_VENT_ANT = 0)',
'            OR ',
'            (gl.GLPN = EXTRACT(MONTH FROM SYSDATE)-1 AND :P603_EN_VENT_ANT = 1)',
'        )',
'        AND TRIM(gl.GLOBJ) = ''22501'' ',
'        AND TRIM(gl.GLSUB) = ''08''',
')',
'-- 2. Evaluamos si existe para devolver el mensaje y el valor total',
'SELECT ',
'    CASE ',
'        WHEN SUM(MONTO) IS NULL THEN ''NO SE HA GENERADO ASIENTO''',
'        ELSE ''ASIENTO GENERADO''',
'    END AS ESTADO_ASIENTO,',
'    ',
unistr('    -- El ABS() nos asegura presentar el cr\00E9dito como un total positivo'),
'    NVL(ABS(SUM(MONTO)), 0) AS TOTAL_ASIENTO ',
'FROM ',
'    ASIENTOS_MES;'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_display_condition_type=>'EXPRESSION'
,p_plug_display_when_condition=>':P603_ID_REGION = 5'
,p_plug_display_when_cond2=>'PLSQL'
,p_ai_enabled=>false
,p_updated_on=>wwv_flow_imp.dz('20260507180351Z')
,p_updated_by=>'JBALCAZAR'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(451956750992478401)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'TOP_AND_BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'MFERRIN'
,p_internal_uid=>451956750992478401
,p_updated_on=>wwv_flow_imp.dz('20260507180351Z')
,p_updated_by=>'JBALCAZAR'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(427466525135807013)
,p_db_column_name=>'ESTADO_ASIENTO'
,p_display_order=>10
,p_column_identifier=>'F'
,p_column_label=>'Estado Asiento'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20260421190926Z')
,p_updated_on=>wwv_flow_imp.dz('20260421190926Z')
,p_created_by=>'JBALCAZAR'
,p_updated_by=>'JBALCAZAR'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(427466657008807014)
,p_db_column_name=>'TOTAL_ASIENTO'
,p_display_order=>20
,p_column_identifier=>'G'
,p_column_label=>'Total Asiento'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G990D00'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20260421190926Z')
,p_updated_on=>wwv_flow_imp.dz('20260424195408Z')
,p_created_by=>'JBALCAZAR'
,p_updated_by=>'JBALCAZAR'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(452876538391244038)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'2079460'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'ESTADO_ASIENTO:TOTAL_ASIENTO:'
,p_updated_on=>wwv_flow_imp.dz('20260421190939Z')
,p_updated_by=>'MCHUQUIMARCA'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(451957227235478406)
,p_plug_name=>unistr('ASIENTO JN EN CUENTA 22501.04 (PROVISI\00D3N REMUNERACI\00D3N VARIABLE)')
,p_parent_plug_id=>wwv_flow_imp.id(451954149628478375)
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(112813843178917343)
,p_plug_display_sequence=>160
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'WITH ASIENTOS_MES AS (',
'    -- 1. Extraemos el monto directamente de la cuenta 22501.04',
'    SELECT /*+ DRIVING_SITE(gl) */',
'        (gl.GLAA / 100) AS MONTO',
'    FROM PRODDTA.F0911@jdedtadl gl',
'    WHERE ',
'        gl.GLKCO = ''00001'' ',
'        AND gl.GLDCT = ''JN'' ',
'        AND gl.GLLT = ''AA'' ',
'        AND gl.GLFY = TO_NUMBER(TO_CHAR(SYSDATE, ''YY'')) ',
'        AND (',
'            (gl.GLPN = EXTRACT(MONTH FROM SYSDATE) AND :P603_EN_VENT_ANT = 0)',
'            OR ',
'            (gl.GLPN = EXTRACT(MONTH FROM SYSDATE)-1 AND :P603_EN_VENT_ANT = 1)',
'        )',
'        AND TRIM(gl.GLOBJ) = ''22501'' ',
'        AND TRIM(gl.GLSUB) = ''04''',
')',
'-- 2. Evaluamos si existe para devolver el mensaje y el valor total',
'SELECT ',
'    CASE ',
'        WHEN SUM(MONTO) IS NULL THEN ''NO SE HA GENERADO ASIENTO''',
'        ELSE ''ASIENTO GENERADO''',
'    END AS ESTADO_ASIENTO,',
'    ',
unistr('    -- El ABS() nos asegura presentar el cr\00E9dito como un total positivo'),
'    NVL(ABS(SUM(MONTO)), 0) AS TOTAL_ASIENTO ',
'FROM ',
'    ASIENTOS_MES;'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_display_condition_type=>'EXPRESSION'
,p_plug_display_when_condition=>':P603_ID_REGION = 6'
,p_plug_display_when_cond2=>'PLSQL'
,p_ai_enabled=>false
,p_updated_on=>wwv_flow_imp.dz('20260507180351Z')
,p_updated_by=>'JBALCAZAR'
);
end;
/
begin
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(451957384361478407)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'TOP_AND_BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'MFERRIN'
,p_internal_uid=>451957384361478407
,p_updated_on=>wwv_flow_imp.dz('20260507180351Z')
,p_updated_by=>'JBALCAZAR'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(427466739902807015)
,p_db_column_name=>'ESTADO_ASIENTO'
,p_display_order=>10
,p_column_identifier=>'F'
,p_column_label=>'Estado Asiento'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20260421191113Z')
,p_updated_on=>wwv_flow_imp.dz('20260421191113Z')
,p_created_by=>'JBALCAZAR'
,p_updated_by=>'JBALCAZAR'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(427466889835807016)
,p_db_column_name=>'TOTAL_ASIENTO'
,p_display_order=>20
,p_column_identifier=>'G'
,p_column_label=>'Total Asiento'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G990D00'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20260421191113Z')
,p_updated_on=>wwv_flow_imp.dz('20260424195408Z')
,p_created_by=>'JBALCAZAR'
,p_updated_by=>'JBALCAZAR'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(452881044244255067)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'2079505'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'ESTADO_ASIENTO:TOTAL_ASIENTO:'
,p_updated_on=>wwv_flow_imp.dz('20260421191125Z')
,p_updated_by=>'MCHUQUIMARCA'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(451968785828350562)
,p_plug_name=>unistr('ASIENTO JN EN CUENTA 23301.01 (PROVISI\00D3N JUBILACI\00D3N PATRONAL)')
,p_parent_plug_id=>wwv_flow_imp.id(451954149628478375)
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(112813843178917343)
,p_plug_display_sequence=>170
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'WITH ASIENTOS_MES AS (',
'    -- 1. Extraemos el monto directamente de la cuenta 23301.01',
'    SELECT /*+ DRIVING_SITE(gl) */',
'        (gl.GLAA / 100) AS MONTO',
'    FROM PRODDTA.F0911@jdedtadl gl',
'    WHERE ',
'        gl.GLKCO = ''00001'' ',
'        AND gl.GLDCT = ''JN'' ',
'        AND gl.GLLT = ''AA'' ',
'        AND gl.GLFY = TO_NUMBER(TO_CHAR(SYSDATE, ''YY'')) ',
'        AND (',
'            (gl.GLPN = EXTRACT(MONTH FROM SYSDATE) AND :P603_EN_VENT_ANT = 0)',
'            OR ',
'            (gl.GLPN = EXTRACT(MONTH FROM SYSDATE)-1 AND :P603_EN_VENT_ANT = 1)',
'        )',
'        AND TRIM(gl.GLOBJ) = ''23301'' ',
'        AND TRIM(gl.GLSUB) = ''01''',
')',
'-- 2. Evaluamos si existe para devolver el mensaje y el valor total',
'SELECT ',
'    CASE ',
'        WHEN SUM(MONTO) IS NULL THEN ''NO SE HA GENERADO ASIENTO''',
'        ELSE ''ASIENTO GENERADO''',
'    END AS ESTADO_ASIENTO,',
'    ',
'    -- El ABS() nos asegura presentar el saldo contable como un total positivo',
'    NVL(ABS(SUM(MONTO)), 0) AS TOTAL_ASIENTO ',
'FROM ',
'    ASIENTOS_MES;'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_display_condition_type=>'EXPRESSION'
,p_plug_display_when_condition=>':P603_ID_REGION = 7'
,p_plug_display_when_cond2=>'PLSQL'
,p_ai_enabled=>false
,p_updated_on=>wwv_flow_imp.dz('20260507180351Z')
,p_updated_by=>'JBALCAZAR'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(451968879409350563)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'TOP_AND_BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'MFERRIN'
,p_internal_uid=>451968879409350563
,p_updated_on=>wwv_flow_imp.dz('20260507180351Z')
,p_updated_by=>'JBALCAZAR'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(427466978048807017)
,p_db_column_name=>'ESTADO_ASIENTO'
,p_display_order=>10
,p_column_identifier=>'F'
,p_column_label=>'Estado Asiento'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20260421191221Z')
,p_updated_on=>wwv_flow_imp.dz('20260421191221Z')
,p_created_by=>'JBALCAZAR'
,p_updated_by=>'JBALCAZAR'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(427467090366807018)
,p_db_column_name=>'TOTAL_ASIENTO'
,p_display_order=>20
,p_column_identifier=>'G'
,p_column_label=>'Total Asiento'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G990D00'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20260421191221Z')
,p_updated_on=>wwv_flow_imp.dz('20260424195408Z')
,p_created_by=>'JBALCAZAR'
,p_updated_by=>'JBALCAZAR'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(452887254217277768)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'2079567'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'ESTADO_ASIENTO:TOTAL_ASIENTO:'
,p_updated_on=>wwv_flow_imp.dz('20260421191302Z')
,p_updated_by=>'MCHUQUIMARCA'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(451969393736350568)
,p_plug_name=>unistr('ASIENTO JN EN CUENTA 23302.02 (PROVISI\00D3N DESAHUCIO)')
,p_parent_plug_id=>wwv_flow_imp.id(451954149628478375)
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(112813843178917343)
,p_plug_display_sequence=>180
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'WITH ASIENTOS_MES AS (',
'    -- 1. Extraemos el monto directamente de la cuenta 23302.02',
'    SELECT /*+ DRIVING_SITE(gl) */',
'        (gl.GLAA / 100) AS MONTO',
'    FROM PRODDTA.F0911@jdedtadl gl',
'    WHERE ',
'        gl.GLKCO = ''00001'' ',
'        AND gl.GLDCT = ''JN'' ',
'        AND gl.GLLT = ''AA'' ',
'        AND gl.GLFY = TO_NUMBER(TO_CHAR(SYSDATE, ''YY'')) ',
'        AND (',
'            (gl.GLPN = EXTRACT(MONTH FROM SYSDATE) AND :P603_EN_VENT_ANT = 0)',
'            OR ',
'            (gl.GLPN = EXTRACT(MONTH FROM SYSDATE)-1 AND :P603_EN_VENT_ANT = 1)',
'        )',
'        AND TRIM(gl.GLOBJ) = ''23302'' ',
'        AND TRIM(gl.GLSUB) = ''02''',
')',
'-- 2. Evaluamos si existe para devolver el mensaje y el valor total',
'SELECT ',
'    CASE ',
'        WHEN SUM(MONTO) IS NULL THEN ''NO SE HA GENERADO ASIENTO''',
'        ELSE ''ASIENTO GENERADO''',
'    END AS ESTADO_ASIENTO,',
'    ',
'    -- El ABS() nos asegura presentar el saldo contable como un total positivo',
'    NVL(ABS(SUM(MONTO)), 0) AS TOTAL_ASIENTO ',
'FROM ',
'    ASIENTOS_MES;'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_display_condition_type=>'EXPRESSION'
,p_plug_display_when_condition=>':P603_ID_REGION = 8'
,p_plug_display_when_cond2=>'PLSQL'
,p_ai_enabled=>false
,p_updated_on=>wwv_flow_imp.dz('20260507180351Z')
,p_updated_by=>'JBALCAZAR'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(451969444593350569)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'TOP_AND_BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'MFERRIN'
,p_internal_uid=>451969444593350569
,p_updated_on=>wwv_flow_imp.dz('20260507180351Z')
,p_updated_by=>'JBALCAZAR'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(427467117412807019)
,p_db_column_name=>'ESTADO_ASIENTO'
,p_display_order=>10
,p_column_identifier=>'F'
,p_column_label=>'Estado Asiento'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20260421191351Z')
,p_updated_on=>wwv_flow_imp.dz('20260421191351Z')
,p_created_by=>'JBALCAZAR'
,p_updated_by=>'JBALCAZAR'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(427467271387807020)
,p_db_column_name=>'TOTAL_ASIENTO'
,p_display_order=>20
,p_column_identifier=>'G'
,p_column_label=>'Total Asiento'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G990D00'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20260421191351Z')
,p_updated_on=>wwv_flow_imp.dz('20260424195408Z')
,p_created_by=>'JBALCAZAR'
,p_updated_by=>'JBALCAZAR'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(452856394032513689)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'2079258'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'ESTADO_ASIENTO:TOTAL_ASIENTO:'
,p_updated_on=>wwv_flow_imp.dz('20260421191448Z')
,p_updated_by=>'MCHUQUIMARCA'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(451970000977350574)
,p_plug_name=>'ASIENTO JN EN CUENTA 61101.12 y 22503.07 (TRANSPORTE Y TRANSPORTE EXTRA)'
,p_parent_plug_id=>wwv_flow_imp.id(451954149628478375)
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(112813843178917343)
,p_plug_display_sequence=>190
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'WITH ASIENTOS_MES AS (',
unistr('    -- 1. Buscamos el monto de la l\00EDnea espec\00EDfica (22503.07)'),
'    SELECT /*+ DRIVING_SITE(gl) */',
'        (gl.GLAA / 100) AS MONTO',
'    FROM PRODDTA.F0911@jdedtadl gl',
'    WHERE ',
'        gl.GLKCO = ''00001'' ',
'        AND gl.GLDCT = ''JN'' ',
'        AND gl.GLLT = ''AA'' ',
'        AND gl.GLFY = TO_NUMBER(TO_CHAR(SYSDATE, ''YY'')) ',
'        AND (',
'            (gl.GLPN = EXTRACT(MONTH FROM SYSDATE) AND :P603_EN_VENT_ANT = 0)',
'            OR ',
'            (gl.GLPN = EXTRACT(MONTH FROM SYSDATE)-1 AND :P603_EN_VENT_ANT = 1)',
'        )',
'        AND TRIM(gl.GLOBJ) = ''22503'' ',
'        AND TRIM(gl.GLSUB) = ''07''',
'        ',
'        -- Validamos que el mismo documento tenga su contrapartida exacta (61101.12)',
'        AND EXISTS (',
'            SELECT 1 ',
'            FROM PRODDTA.F0911@jdedtadl gl2',
'            WHERE ',
'                gl2.GLDOC = gl.GLDOC ',
'                AND gl2.GLKCO = gl.GLKCO ',
'                AND gl2.GLDCT = gl.GLDCT ',
'                AND gl2.GLFY = gl.GLFY',
'                AND TRIM(gl2.GLOBJ) = ''61101'' ',
'                AND TRIM(gl2.GLSUB) = ''12''',
'        )',
')',
'-- 2. Evaluamos el resultado para mostrar el estado y el total real',
'SELECT ',
'    CASE ',
'        WHEN SUM(MONTO) IS NULL THEN ''NO SE HA GENERADO ASIENTO''',
'        ELSE ''ASIENTO GENERADO''',
'    END AS ESTADO_ASIENTO,',
'    ',
'    -- Aplicamos ABS() para presentar el valor contable como un total positivo',
'    NVL(ABS(SUM(MONTO)), 0) AS TOTAL_ASIENTO ',
'FROM ',
'    ASIENTOS_MES;'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_display_condition_type=>'EXPRESSION'
,p_plug_display_when_condition=>':P603_ID_REGION = 9'
,p_plug_display_when_cond2=>'PLSQL'
,p_ai_enabled=>false
,p_updated_on=>wwv_flow_imp.dz('20260507180351Z')
,p_updated_by=>'JBALCAZAR'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(451970043498350575)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'TOP_AND_BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'MFERRIN'
,p_internal_uid=>451970043498350575
,p_updated_on=>wwv_flow_imp.dz('20260507180351Z')
,p_updated_by=>'JBALCAZAR'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(427467381827807021)
,p_db_column_name=>'ESTADO_ASIENTO'
,p_display_order=>10
,p_column_identifier=>'F'
,p_column_label=>'Estado Asiento'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20260421191554Z')
,p_updated_on=>wwv_flow_imp.dz('20260421191554Z')
,p_created_by=>'JBALCAZAR'
,p_updated_by=>'JBALCAZAR'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(427467439426807022)
,p_db_column_name=>'TOTAL_ASIENTO'
,p_display_order=>20
,p_column_identifier=>'G'
,p_column_label=>'Total Asiento'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G990D00'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20260421191554Z')
,p_updated_on=>wwv_flow_imp.dz('20260424195408Z')
,p_created_by=>'JBALCAZAR'
,p_updated_by=>'JBALCAZAR'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(452857391516520092)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'2079268'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'ESTADO_ASIENTO:TOTAL_ASIENTO:'
,p_updated_on=>wwv_flow_imp.dz('20260421191611Z')
,p_updated_by=>'MCHUQUIMARCA'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(451970573453350580)
,p_plug_name=>'ASIENTO JN EN CUENTA 11703.01 y 11102.01 (SEGUROS HIJOS)'
,p_parent_plug_id=>wwv_flow_imp.id(451954149628478375)
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(112813843178917343)
,p_plug_display_sequence=>200
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'WITH ASIENTOS_MES AS (',
unistr('    -- 1. Buscamos el monto de la l\00EDnea espec\00EDfica (11703.01)'),
'    SELECT /*+ DRIVING_SITE(gl) */',
'        (gl.GLAA / 100) AS MONTO, GLEXR',
'    FROM PRODDTA.F0911@jdedtadl gl',
'    WHERE ',
'        gl.GLKCO = ''00001'' ',
'        AND gl.GLDCT = ''JN'' ',
'        AND gl.GLLT = ''AA'' ',
'        AND gl.GLFY = TO_NUMBER(TO_CHAR(SYSDATE, ''YY'')) ',
'        AND (',
'            (gl.GLPN = EXTRACT(MONTH FROM SYSDATE) AND :P603_EN_VENT_ANT = 0)',
'            OR ',
'            (gl.GLPN = EXTRACT(MONTH FROM SYSDATE)-1 AND :P603_EN_VENT_ANT = 1)',
'        )',
'        AND TRIM(gl.GLOBJ) = ''11703'' ',
'        AND TRIM(gl.GLSUB) = ''01''',
'        ',
'        -- Validamos que tenga su contrapartida exacta (11102)',
'        AND EXISTS (',
'            SELECT 1 ',
'            FROM PRODDTA.F0911@jdedtadl gl2',
'            WHERE ',
'                gl2.GLDOC = gl.GLDOC ',
'                AND gl2.GLKCO = gl.GLKCO ',
'                AND gl2.GLDCT = gl.GLDCT ',
'                AND gl2.GLFY = gl.GLFY',
'                AND TRIM(gl2.GLOBJ) = ''11102''',
unistr('                -- Se mantiene comentado seg\00FAn tu dise\00F1o original:'),
'                AND TRIM(gl2.GLSUB) = ''01''',
'        )',
')',
'-- 2. Evaluamos el resultado para mostrar el estado y el total real',
'SELECT ',
'    CASE ',
'        WHEN SUM(MONTO) IS NULL THEN ''NO SE HA GENERADO ASIENTO''',
'        ELSE ''ASIENTO GENERADO''||'' - ''||to_char(GLEXR)',
'    END AS ESTADO_ASIENTO,',
'    ',
'    -- Aplicamos ABS() para presentar el valor contable como un total positivo',
'    NVL(ABS(SUM(MONTO)), 0) AS TOTAL_ASIENTO ',
'FROM ',
'    ASIENTOS_MES',
'GROUP BY GLEXR;'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_display_condition_type=>'EXPRESSION'
,p_plug_display_when_condition=>':P603_ID_REGION = 10'
,p_plug_display_when_cond2=>'PLSQL'
,p_ai_enabled=>false
,p_updated_on=>wwv_flow_imp.dz('20260604194407Z')
,p_updated_by=>'JBALCAZAR'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(451970648616350581)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'TOP_AND_BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'MFERRIN'
,p_internal_uid=>451970648616350581
,p_updated_on=>wwv_flow_imp.dz('20260604194407Z')
,p_updated_by=>'JBALCAZAR'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(427467503076807023)
,p_db_column_name=>'ESTADO_ASIENTO'
,p_display_order=>10
,p_column_identifier=>'F'
,p_column_label=>'Estado Asiento'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20260421191725Z')
,p_updated_on=>wwv_flow_imp.dz('20260421191725Z')
,p_created_by=>'JBALCAZAR'
,p_updated_by=>'JBALCAZAR'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(427467664274807024)
,p_db_column_name=>'TOTAL_ASIENTO'
,p_display_order=>20
,p_column_identifier=>'G'
,p_column_label=>'Total Asiento'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G990D00'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20260421191725Z')
,p_updated_on=>wwv_flow_imp.dz('20260424195408Z')
,p_created_by=>'JBALCAZAR'
,p_updated_by=>'JBALCAZAR'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(452855784956512563)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'2079252'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'ESTADO_ASIENTO:TOTAL_ASIENTO:'
,p_updated_on=>wwv_flow_imp.dz('20260421191739Z')
,p_updated_by=>'MCHUQUIMARCA'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(451971133213350586)
,p_plug_name=>'ASIENTO JN EN CUENTA 61101.10 (PAGO COMEDOR)'
,p_parent_plug_id=>wwv_flow_imp.id(451954149628478375)
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(112813843178917343)
,p_plug_display_sequence=>210
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'WITH ASIENTOS_MES AS (',
'    -- 1. Extraemos el monto directamente de la cuenta 61101.10',
'    SELECT /*+ DRIVING_SITE(gl) */',
'        (gl.GLAA / 100) AS MONTO',
'    FROM PRODDTA.F0911@jdedtadl gl',
'    WHERE ',
'        gl.GLKCO = ''00001'' ',
'        AND gl.GLDCT = ''JN'' ',
'        AND gl.GLLT = ''AA'' ',
'        AND gl.GLFY = TO_NUMBER(TO_CHAR(SYSDATE, ''YY'')) ',
'        AND (',
'            (gl.GLPN = EXTRACT(MONTH FROM SYSDATE) AND :P603_EN_VENT_ANT = 0)',
'            OR ',
'            (gl.GLPN = EXTRACT(MONTH FROM SYSDATE)-1 AND :P603_EN_VENT_ANT = 1)',
'        )',
'        AND TRIM(gl.GLOBJ) = ''61101'' ',
'        AND TRIM(gl.GLSUB) = ''10''',
')',
'-- 2. Evaluamos si existe para devolver el mensaje y el valor total',
'SELECT ',
'    CASE ',
'        WHEN SUM(MONTO) IS NULL THEN ''NO SE HA GENERADO ASIENTO''',
'        ELSE ''ASIENTO GENERADO''',
'    END AS ESTADO_ASIENTO,',
'    ',
'    -- El ABS() nos asegura presentar el saldo contable como un total positivo',
'    NVL(ABS(SUM(MONTO)), 0) AS TOTAL_ASIENTO ',
'FROM ',
'    ASIENTOS_MES;'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_display_condition_type=>'EXPRESSION'
,p_plug_display_when_condition=>':P603_ID_REGION = 11'
,p_plug_display_when_cond2=>'PLSQL'
,p_ai_enabled=>false
,p_updated_on=>wwv_flow_imp.dz('20260507180351Z')
,p_updated_by=>'JBALCAZAR'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(451971323659350587)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'TOP_AND_BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'MFERRIN'
,p_internal_uid=>451971323659350587
,p_updated_on=>wwv_flow_imp.dz('20260507180351Z')
,p_updated_by=>'JBALCAZAR'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(427467715115807025)
,p_db_column_name=>'ESTADO_ASIENTO'
,p_display_order=>10
,p_column_identifier=>'F'
,p_column_label=>'Estado Asiento'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20260421191902Z')
,p_updated_on=>wwv_flow_imp.dz('20260421191902Z')
,p_created_by=>'JBALCAZAR'
,p_updated_by=>'JBALCAZAR'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(427467835371807026)
,p_db_column_name=>'TOTAL_ASIENTO'
,p_display_order=>20
,p_column_identifier=>'G'
,p_column_label=>'Total Asiento'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G990D00'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20260421191902Z')
,p_updated_on=>wwv_flow_imp.dz('20260424195408Z')
,p_created_by=>'JBALCAZAR'
,p_updated_by=>'JBALCAZAR'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(452899794203346031)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'2079692'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'ESTADO_ASIENTO:TOTAL_ASIENTO:'
,p_updated_on=>wwv_flow_imp.dz('20260421191916Z')
,p_updated_by=>'MCHUQUIMARCA'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(451971777739350592)
,p_plug_name=>'ASIENTO JN EN CUENTA 22503.07 y 61101.19 (PAGO DISPENSARIO Y EXTRAS)'
,p_parent_plug_id=>wwv_flow_imp.id(451954149628478375)
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(112813843178917343)
,p_plug_display_sequence=>220
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'WITH ASIENTOS_MES AS (',
unistr('    -- 1. Buscamos el monto de la l\00EDnea espec\00EDfica (22503.07)'),
'    SELECT /*+ DRIVING_SITE(gl) */',
'        (gl.GLAA / 100) AS MONTO',
'    FROM PRODDTA.F0911@jdedtadl gl',
'    WHERE ',
'        gl.GLKCO = ''00001'' ',
'        AND gl.GLDCT = ''JN'' ',
'        AND gl.GLLT = ''AA'' ',
'        AND gl.GLFY = TO_NUMBER(TO_CHAR(SYSDATE, ''YY'')) ',
'        AND (',
'            (gl.GLPN = EXTRACT(MONTH FROM SYSDATE) AND :P603_EN_VENT_ANT = 0)',
'            OR ',
'            (gl.GLPN = EXTRACT(MONTH FROM SYSDATE)-1 AND :P603_EN_VENT_ANT = 1)',
'        )',
'        AND TRIM(gl.GLOBJ) = ''22503'' ',
'        AND TRIM(gl.GLSUB) = ''07''',
'        ',
'        -- Validamos que el mismo documento tenga su contrapartida exacta (61101.19)',
'        AND EXISTS (',
'            SELECT 1 ',
'            FROM PRODDTA.F0911@jdedtadl gl2',
'            WHERE ',
'                gl2.GLDOC = gl.GLDOC ',
'                AND gl2.GLKCO = gl.GLKCO ',
'                AND gl2.GLDCT = gl.GLDCT ',
'                AND gl2.GLFY = gl.GLFY',
'                AND TRIM(gl2.GLOBJ) = ''61101'' ',
'                AND TRIM(gl2.GLSUB) = ''19''',
'        )',
')',
'-- 2. Evaluamos el resultado para mostrar el estado y el total real',
'SELECT ',
'    CASE ',
'        WHEN SUM(MONTO) IS NULL THEN ''NO SE HA GENERADO ASIENTO''',
'        ELSE ''ASIENTO GENERADO''',
'    END AS ESTADO_ASIENTO,',
'    ',
'    -- Aplicamos ABS() para presentar el valor contable como un total positivo',
'    NVL(ABS(SUM(MONTO)), 0) AS TOTAL_ASIENTO ',
'FROM ',
'    ASIENTOS_MES;'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_display_condition_type=>'EXPRESSION'
,p_plug_display_when_condition=>':P603_ID_REGION = 12'
,p_plug_display_when_cond2=>'PLSQL'
,p_ai_enabled=>false
,p_updated_on=>wwv_flow_imp.dz('20260507180351Z')
,p_updated_by=>'JBALCAZAR'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(451971881743350593)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'TOP_AND_BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'MFERRIN'
,p_internal_uid=>451971881743350593
,p_updated_on=>wwv_flow_imp.dz('20260507180351Z')
,p_updated_by=>'JBALCAZAR'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(427467935449807027)
,p_db_column_name=>'ESTADO_ASIENTO'
,p_display_order=>10
,p_column_identifier=>'F'
,p_column_label=>'Estado Asiento'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20260421192025Z')
,p_updated_on=>wwv_flow_imp.dz('20260421192025Z')
,p_created_by=>'JBALCAZAR'
,p_updated_by=>'JBALCAZAR'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(427468004308807028)
,p_db_column_name=>'TOTAL_ASIENTO'
,p_display_order=>20
,p_column_identifier=>'G'
,p_column_label=>'Total Asiento'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G990D00'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20260421192025Z')
,p_updated_on=>wwv_flow_imp.dz('20260424195408Z')
,p_created_by=>'JBALCAZAR'
,p_updated_by=>'JBALCAZAR'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(452895068550315871)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'2079645'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'ESTADO_ASIENTO:TOTAL_ASIENTO:'
,p_updated_on=>wwv_flow_imp.dz('20260421192038Z')
,p_updated_by=>'MCHUQUIMARCA'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(451972327534350598)
,p_plug_name=>'ASIENTO JN EN CUENTA 22503.07 y 61101.11 (PAGO SEGUROS DE VIDA)'
,p_parent_plug_id=>wwv_flow_imp.id(451954149628478375)
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(112813843178917343)
,p_plug_display_sequence=>230
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'WITH ASIENTOS_MES AS (',
unistr('    -- 1. Buscamos el monto de la l\00EDnea espec\00EDfica (22503.07)'),
'    SELECT /*+ DRIVING_SITE(gl) */',
'        (gl.GLAA / 100) AS MONTO',
'    FROM PRODDTA.F0911@jdedtadl gl',
'    WHERE ',
'        gl.GLKCO = ''00001'' ',
'        AND gl.GLDCT = ''JN'' ',
'        AND gl.GLLT = ''AA'' ',
'        AND gl.GLFY = TO_NUMBER(TO_CHAR(SYSDATE, ''YY'')) ',
'        AND (',
'            (gl.GLPN = EXTRACT(MONTH FROM SYSDATE) AND :P603_EN_VENT_ANT = 0)',
'            OR ',
'            (gl.GLPN = EXTRACT(MONTH FROM SYSDATE)-1 AND :P603_EN_VENT_ANT = 1)',
'        )',
'        AND TRIM(gl.GLOBJ) = ''22503'' ',
'        AND TRIM(gl.GLSUB) = ''07''',
'        ',
'        -- Validamos que el mismo documento tenga su contrapartida exacta (61101.11)',
'        AND EXISTS (',
'            SELECT 1 ',
'            FROM PRODDTA.F0911@jdedtadl gl2',
'            WHERE ',
'                gl2.GLDOC = gl.GLDOC ',
'                AND gl2.GLKCO = gl.GLKCO ',
'                AND gl2.GLDCT = gl.GLDCT ',
'                AND gl2.GLFY = gl.GLFY',
'                AND TRIM(gl2.GLOBJ) = ''61101'' ',
'                AND TRIM(gl2.GLSUB) = ''11''',
'        )',
')',
'-- 2. Evaluamos el resultado para mostrar el estado y el total real',
'SELECT ',
'    CASE ',
'        WHEN SUM(MONTO) IS NULL THEN ''NO SE HA GENERADO ASIENTO''',
'        ELSE ''ASIENTO GENERADO''',
'    END AS ESTADO_ASIENTO,',
'    ',
'    -- Aplicamos ABS() para presentar el valor contable como un total positivo',
'    NVL(ABS(SUM(MONTO)), 0) AS TOTAL_ASIENTO ',
'FROM ',
'    ASIENTOS_MES;'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_display_condition_type=>'EXPRESSION'
,p_plug_display_when_condition=>':P603_ID_REGION = 13'
,p_plug_display_when_cond2=>'PLSQL'
,p_ai_enabled=>false
,p_updated_on=>wwv_flow_imp.dz('20260507180351Z')
,p_updated_by=>'JBALCAZAR'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(451972435821350599)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'TOP_AND_BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'MFERRIN'
,p_internal_uid=>451972435821350599
,p_updated_on=>wwv_flow_imp.dz('20260507180351Z')
,p_updated_by=>'JBALCAZAR'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(427468131538807029)
,p_db_column_name=>'ESTADO_ASIENTO'
,p_display_order=>10
,p_column_identifier=>'F'
,p_column_label=>'Estado Asiento'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20260421192145Z')
,p_updated_on=>wwv_flow_imp.dz('20260421192145Z')
,p_created_by=>'JBALCAZAR'
,p_updated_by=>'JBALCAZAR'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(427468220754807030)
,p_db_column_name=>'TOTAL_ASIENTO'
,p_display_order=>20
,p_column_identifier=>'G'
,p_column_label=>'Total Asiento'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G990D00'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20260421192145Z')
,p_updated_on=>wwv_flow_imp.dz('20260424195408Z')
,p_created_by=>'JBALCAZAR'
,p_updated_by=>'JBALCAZAR'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(452913508765378391)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'2079829'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'ESTADO_ASIENTO:TOTAL_ASIENTO:'
,p_updated_on=>wwv_flow_imp.dz('20260421192157Z')
,p_updated_by=>'MCHUQUIMARCA'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(451972959632350604)
,p_plug_name=>unistr('ASIENTO JN EN CUENTA 22503.07 y 61101.08 (TARJETAS PA\00D1ALES)')
,p_parent_plug_id=>wwv_flow_imp.id(451954149628478375)
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(112813843178917343)
,p_plug_display_sequence=>240
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'WITH ASIENTOS_MES AS (',
unistr('    -- 1. Buscamos el monto de la l\00EDnea espec\00EDfica (22503.07)'),
'    SELECT /*+ DRIVING_SITE(gl) */',
'        (gl.GLAA / 100) AS MONTO',
'    FROM PRODDTA.F0911@jdedtadl gl',
'    WHERE ',
'        gl.GLKCO = ''00001'' ',
'        AND gl.GLDCT = ''JN'' ',
'        AND gl.GLLT = ''AA'' ',
'        AND gl.GLFY = TO_NUMBER(TO_CHAR(SYSDATE, ''YY'')) ',
'        AND (',
'            (gl.GLPN = EXTRACT(MONTH FROM SYSDATE) AND :P603_EN_VENT_ANT = 0)',
'            OR ',
'            (gl.GLPN = EXTRACT(MONTH FROM SYSDATE)-1 AND :P603_EN_VENT_ANT = 1)',
'        )',
'        AND TRIM(gl.GLOBJ) = ''22503'' ',
'        AND TRIM(gl.GLSUB) = ''07''',
'        ',
'        -- Validamos que el mismo documento tenga su contrapartida exacta (61101.08)',
'        AND EXISTS (',
'            SELECT 1 ',
'            FROM PRODDTA.F0911@jdedtadl gl2',
'            WHERE ',
'                gl2.GLDOC = gl.GLDOC ',
'                AND gl2.GLKCO = gl.GLKCO ',
'                AND gl2.GLDCT = gl.GLDCT ',
'                AND gl2.GLFY = gl.GLFY',
'                AND TRIM(gl2.GLOBJ) = ''61101'' ',
'                AND TRIM(gl2.GLSUB) = ''08''',
'        )',
')',
'-- 2. Evaluamos el resultado para mostrar el estado y el total real',
'SELECT ',
'    CASE ',
'        WHEN SUM(MONTO) IS NULL THEN ''NO SE HA GENERADO ASIENTO''',
'        ELSE ''ASIENTO GENERADO''',
'    END AS ESTADO_ASIENTO,',
'    ',
'    -- Aplicamos ABS() para presentar el valor contable como un total positivo',
'    NVL(ABS(SUM(MONTO)), 0) AS TOTAL_ASIENTO ',
'FROM ',
'    ASIENTOS_MES;'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_display_condition_type=>'EXPRESSION'
,p_plug_display_when_condition=>':P603_ID_REGION = 14'
,p_plug_display_when_cond2=>'PLSQL'
,p_ai_enabled=>false
,p_updated_on=>wwv_flow_imp.dz('20260507180351Z')
,p_updated_by=>'JBALCAZAR'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(451973079686350605)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'TOP_AND_BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'MFERRIN'
,p_internal_uid=>451973079686350605
,p_updated_on=>wwv_flow_imp.dz('20260507180351Z')
,p_updated_by=>'JBALCAZAR'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(427468378175807031)
,p_db_column_name=>'ESTADO_ASIENTO'
,p_display_order=>10
,p_column_identifier=>'F'
,p_column_label=>'Estado Asiento'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_format_mask=>'FML999G999G999G999G990D00'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20260421192252Z')
,p_updated_on=>wwv_flow_imp.dz('20260424195408Z')
,p_created_by=>'JBALCAZAR'
,p_updated_by=>'JBALCAZAR'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(427468407839807032)
,p_db_column_name=>'TOTAL_ASIENTO'
,p_display_order=>20
,p_column_identifier=>'G'
,p_column_label=>'Total Asiento'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20260421192252Z')
,p_updated_on=>wwv_flow_imp.dz('20260421192252Z')
,p_created_by=>'JBALCAZAR'
,p_updated_by=>'JBALCAZAR'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(451999311131381347)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'2070687'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'ESTADO_ASIENTO:TOTAL_ASIENTO:'
,p_updated_on=>wwv_flow_imp.dz('20260421192310Z')
,p_updated_by=>'MCHUQUIMARCA'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(452835382484307691)
,p_plug_name=>'Cuentas por cobrar'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(38289867500120143)
,p_plug_display_sequence=>140
,p_location=>null
,p_plug_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_plug_display_when_condition=>'P603_MODULO'
,p_plug_display_when_cond2=>'CXC'
,p_ai_enabled=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(452836315478307700)
,p_plug_name=>unistr('CLIENTES SIN ASIGANCI\00D3N DE ASIGNACI\00D3N DE EJECUTIVO VENTAS')
,p_parent_plug_id=>wwv_flow_imp.id(452835382484307691)
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(112813843178917343)
,p_plug_display_sequence=>250
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT CODIGO,NOMBRES ',
'FROM DATA.VT_JDE_CLIENTE ',
'WHERE ESTADO = 1 AND CODIGOEJECUTIVO IS NULL;'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_display_condition_type=>'EXPRESSION'
,p_plug_display_when_condition=>':P603_ID_REGION = 1'
,p_plug_display_when_cond2=>'PLSQL'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>11
,p_prn_height=>8.5
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(452836346181307701)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'TOP_AND_BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'MFERRIN'
,p_internal_uid=>452836346181307701
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(452836868759307706)
,p_db_column_name=>'CODIGO'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Codigo'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(452836986054307707)
,p_db_column_name=>'NOMBRES'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Nombres'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(453364681720294645)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'2084341'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'CODIGO:NOMBRES'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(452837177350307709)
,p_plug_name=>unistr('CLIENTES TIPOS DE RETENCI\00D3N')
,p_parent_plug_id=>wwv_flow_imp.id(452835382484307691)
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(112813843178917343)
,p_plug_display_sequence=>260
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT VC.CODIGO,VC.NOMBRES, UDC.DRDL01 AS TIPO_CONTRIBUYENTE',
'FROM PRODDTA.F76E0001@jdedtadl PE',
'INNER JOIN DATA.VT_JDE_CLIENTE VC ON VC.CODIGO = PE.TCAN8',
'INNER JOIN PRODDTA.F03012@jdedtadl CB ON CB.AIAN8 = VC.CODIGO',
'INNER JOIN PRODCTL.F0005@jdedtadl U ON LTRIM(RTRIM(CB.AIAC21)) = LTRIM(RTRIM(U.DRKY))',
'INNER JOIN DATA.VT_JDE_UDC UDC ON UDC.DRSY = ''76E'' AND UDC.DRRT = ''TC'' AND TRIM(UDC.DRKY) = TRIM(PE.TCKY)',
'WHERE VC.ESTADO = 1',
'AND U.DRSY = ''01''',
'    AND U.DRRT = ''21''',
'    AND CB.AICO = ''00001''',
'    AND CB.AIAC21 IN (''001'',''002'',''003'')'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_display_condition_type=>'EXPRESSION'
,p_plug_display_when_condition=>':P603_ID_REGION = 2'
,p_plug_display_when_cond2=>'PLSQL'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>11
,p_prn_height=>8.5
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(452837243946307710)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'TOP_AND_BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'MFERRIN'
,p_internal_uid=>452837243946307710
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(453371254321372861)
,p_db_column_name=>'CODIGO'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Codigo'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(453371422864372862)
,p_db_column_name=>'NOMBRES'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Nombres'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(453371501909372863)
,p_db_column_name=>'TIPO_CONTRIBUYENTE'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Tipo Contribuyente'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(453377987536374366)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'2084474'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'CODIGO:NOMBRES:TIPO_CONTRIBUYENTE'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(453371544318372864)
,p_plug_name=>'DONACIONES Y AUTOCONSUMOS SIN CERRARSE'
,p_parent_plug_id=>wwv_flow_imp.id(452835382484307691)
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(112813843178917343)
,p_plug_display_sequence=>270
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'    SELECT DISTINCT RWDOC DOCUMENTO, RWDCT TIPO_DOCUMENTO, RWAAP/100 MONTO_ABIERTO, C.ABALPH AS CLIENTE',
'    FROM PRODDTA.F03B112@jdedtadl M',
'    INNER JOIN PRODDTA.F0101@jdedtadl C ON C.ABAN8 = M.RWAN8',
'    WHERE M.RWDCT = ''FN'' AND M.RWAN8 = 1 AND M.RWAAP <> 0',
'    AND NOT EXISTS (',
'        SELECT 1',
'        FROM PRODDTA.F03B14@jdedtadl D',
'        INNER JOIN PRODDTA.F03B13@jdedtadl R ON R.RYAN8 = D.RZAN8 AND R.RYICU = D.RZICU AND R.RYICUT = D.RZICUT AND R.RYPYID = D.RZPYID',
'        WHERE D.RZAN8 = M.RWAN8',
'          AND RZICU = M.RWAN8',
'          AND D.RZDOC = M.RWDOC',
'          AND D.RZDCT = ''RC''',
'    );'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_display_condition_type=>'EXPRESSION'
,p_plug_display_when_condition=>':P603_ID_REGION = 3'
,p_plug_display_when_cond2=>'PLSQL'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>11
,p_prn_height=>8.5
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(453371715843372865)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'TOP_AND_BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'MFERRIN'
,p_internal_uid=>453371715843372865
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(453372095855372869)
,p_db_column_name=>'DOCUMENTO'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Documento'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(453372143756372870)
,p_db_column_name=>'TIPO_DOCUMENTO'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Tipo Documento'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(453372274923372871)
,p_db_column_name=>'MONTO_ABIERTO'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Monto Abierto'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(457860259562908369)
,p_db_column_name=>'CLIENTE'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Cliente'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(453383762644496448)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'2084532'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'CLIENTE:DOCUMENTO:TIPO_DOCUMENTO:MONTO_ABIERTO:'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(453375514173372903)
,p_plug_name=>unistr('FACTURAS SIN RETENCI\00D3N')
,p_parent_plug_id=>wwv_flow_imp.id(452835382484307691)
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(112813843178917343)
,p_plug_display_sequence=>280
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT M.RPDOC FACTURA, C.ABALPH AS RAZON_SOCIAL, M.RPAAP/100 VALOR,',
'       TO_DATE(TO_CHAR(1900000 + M.RPDGJ), ''YYYYDDD'') FECHA, U.DRDL01 AS DESCRIPCION, U.DRDL02 AS PORCENTAJE',
'FROM PRODDTA.F03B11@jdedtadl M',
'INNER JOIN PRODDTA.F03012@jdedtadl CB ON CB.AIAN8 = M.RPAN8',
'INNER JOIN PRODDTA.F0101@jdedtadl C ON C.ABAN8 = M.RPAN8',
'INNER JOIN PRODCTL.F0005@jdedtadl U ON LTRIM(RTRIM(CB.AIAC21)) = LTRIM(RTRIM(U.DRKY))',
'WHERE M.RPDCT IN (''FN'',''FD'') AND M.RPFY = TO_NUMBER(TO_CHAR(SYSDATE, ''YY'')) AND M.RPPN =  EXTRACT(MONTH FROM SYSDATE) AND M.RPAAP=0',
'AND U.DRSY = ''01''',
'    AND U.DRRT = ''21''',
'    AND CB.AICO = ''00001''',
'    AND CB.AIAC21 IN (''001'',''002'',''003'')',
'AND NOT EXISTS(',
'    SELECT 1',
'    FROM PRODDTA.F03B14@jdedtadl D',
'    WHERE D.RZAN8 = M.RPAN8',
'      AND D.RZDOC = M.RPDOC',
'      AND D.RZFY = M.RPFY',
'      AND D.RZRSCO  = ''VT''',
')',
';'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_display_condition_type=>'EXPRESSION'
,p_plug_display_when_condition=>':P603_ID_REGION = 4'
,p_plug_display_when_cond2=>'PLSQL'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>11
,p_prn_height=>8.5
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
,p_ai_enabled=>false
,p_updated_on=>wwv_flow_imp.dz('20260428163326Z')
,p_updated_by=>'JBALCAZAR'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(453375616896372904)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'TOP_AND_BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'MFERRIN'
,p_internal_uid=>453375616896372904
,p_updated_on=>wwv_flow_imp.dz('20260428163326Z')
,p_updated_by=>'JBALCAZAR'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(453375969095372908)
,p_db_column_name=>'FACTURA'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Factura'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(453376028629372909)
,p_db_column_name=>'RAZON_SOCIAL'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Cliente'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(453376164926372910)
,p_db_column_name=>'VALOR'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Monto Abierto'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(455200213471233861)
,p_db_column_name=>'FECHA'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Fecha'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(455200365932233863)
,p_db_column_name=>'DESCRIPCION'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'Tipo de Contribuyente'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(455200481771233864)
,p_db_column_name=>'PORCENTAJE'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>unistr('% Retenci\00F3n')
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(455593661203853994)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'2106631'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'RAZON_SOCIAL:DESCRIPCION:PORCENTAJE:FECHA:FACTURA:VALOR'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(455202512374233884)
,p_plug_name=>unistr('Facturas sin retenci\00F3n notificaci\00F3n ejecutivos')
,p_parent_plug_id=>wwv_flow_imp.id(452835382484307691)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(37806762584106520)
,p_plug_display_sequence=>290
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT US.NOMBRES EJECUTIVO, M.RPDOC FACTURA, C.ABALPH AS RAZON_SOCIAL, SUM(M.RPAAP)/100 VALOR,',
'       TO_DATE(TO_CHAR(1900000 + M.RPDGJ), ''YYYYDDD'') FECHA,(TO_DATE(TO_CHAR(1900000 + M.RPDGJ), ''YYYYDDD'') + 5) FECHA_APROX_RETENC,',
'       CASE M.RPPN ',
unistr('       WHEN EXTRACT(MONTH FROM SYSDATE) THEN ''FACTURA MES ACTUAL, SE DEBE EMITIR RETENCI\00D3N'' '),
unistr('       ELSE ''FACTURA MES ANTERIOR, SE DEBE ANULAR LA FACTURA Y EMITIR RETENCI\00D3N'' END ALERTA,'),
'        M.RPRMR1, M.RPAN8 NUMERO_CLIENTE, M.RPDCT',
'FROM PRODDTA.F03B11@jdedtadl M',
'INNER JOIN PRODDTA.F03012@jdedtadl CB ON CB.AIAN8 = M.RPAN8',
'INNER JOIN PRODDTA.F0101@jdedtadl C ON C.ABAN8 = M.RPAN8',
'INNER JOIN DATA.VT_JDE_CLIENTE VC ON VC.CODIGO = M.RPAN8',
'INNER JOIN DATA.VT_CORP_USUARIO US ON US.NUMEROIDENTIFICACION = VC.EJECUTIVO',
'WHERE M.RPDCT IN (''FN'',''FD'') AND M.RPFY = TO_NUMBER(TO_CHAR(SYSDATE, ''YY''))',
'AND CB.AICO = ''00001''',
'AND RPSTAM <> 0',
'AND CB.AIAC21 IN (''001'',''002'',''003'')',
'AND NOT EXISTS(',
'    SELECT 1',
'    FROM PRODDTA.F03B14@jdedtadl D',
'    WHERE D.RZAN8 = M.RPAN8',
'      AND D.RZDOC = M.RPDOC',
'      AND D.RZKCO = M.RPKCO',
'      AND D.RZDCT = M.RPDCT',
'      AND D.RZFY = M.RPFY',
'      AND D.RZRSCO  = ''VT''',
')',
'GROUP BY ',
'    US.NOMBRES, ',
'    M.RPDOC, ',
'    C.ABALPH, ',
'    M.RPDGJ, ',
'    M.RPPN, ',
'    M.RPRMR1, ',
'    M.RPAN8, ',
'    M.RPDCT;'))
,p_plug_source_type=>'NATIVE_IG'
,p_plug_display_condition_type=>'EXPRESSION'
,p_plug_display_when_condition=>':P603_ID_REGION = 5'
,p_plug_display_when_cond2=>'PLSQL'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
,p_ai_enabled=>false
,p_updated_on=>wwv_flow_imp.dz('20260427172250Z')
,p_updated_by=>'JBALCAZAR'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(455763081069984195)
,p_name=>'EJECUTIVO'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'EJECUTIVO'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>true
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>'Ejecutivo'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>30
,p_value_alignment=>'LEFT'
,p_attribute_05=>'BOTH'
,p_is_required=>false
,p_max_length=>255
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_include_in_export=>true
,p_readonly_condition_type=>'ALWAYS'
,p_readonly_for_each_row=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(455763197532984196)
,p_name=>'FACTURA'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'FACTURA'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>true
,p_item_type=>'NATIVE_NUMBER_FIELD'
,p_heading=>'Factura'
,p_heading_alignment=>'RIGHT'
,p_display_sequence=>40
,p_value_alignment=>'RIGHT'
,p_attribute_03=>'left'
,p_attribute_04=>'decimal'
,p_is_required=>true
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>true
,p_include_in_export=>true
,p_readonly_condition_type=>'ALWAYS'
,p_readonly_for_each_row=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(455763300428984197)
,p_name=>'RAZON_SOCIAL'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'RAZON_SOCIAL'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>true
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>'Razon Social'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>50
,p_value_alignment=>'LEFT'
,p_attribute_05=>'BOTH'
,p_is_required=>false
,p_max_length=>40
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_include_in_export=>true
,p_readonly_condition_type=>'ALWAYS'
,p_readonly_for_each_row=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(455763392781984198)
,p_name=>'VALOR'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'VALOR'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>true
,p_item_type=>'NATIVE_NUMBER_FIELD'
,p_heading=>'Valor'
,p_heading_alignment=>'RIGHT'
,p_display_sequence=>60
,p_value_alignment=>'RIGHT'
,p_attribute_03=>'left'
,p_attribute_04=>'decimal'
,p_is_required=>false
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_include_in_export=>true
,p_readonly_condition_type=>'ALWAYS'
,p_readonly_for_each_row=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(455763519916984199)
,p_name=>'FECHA'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'FECHA'
,p_data_type=>'DATE'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>true
,p_item_type=>'NATIVE_DATE_PICKER_APEX'
,p_heading=>'Fecha'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>70
,p_value_alignment=>'LEFT'
,p_attribute_01=>'N'
,p_attribute_02=>'POPUP'
,p_attribute_03=>'NONE'
,p_attribute_06=>'NONE'
,p_attribute_09=>'N'
,p_attribute_11=>'Y'
,p_is_required=>false
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_date_ranges=>'ALL'
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_include_in_export=>true
,p_readonly_condition_type=>'ALWAYS'
,p_readonly_for_each_row=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(455763538037984200)
,p_name=>'FECHA_APROX_RETENC'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'FECHA_APROX_RETENC'
,p_data_type=>'DATE'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>true
,p_item_type=>'NATIVE_DATE_PICKER_APEX'
,p_heading=>'Fecha Aprox Retenc'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>80
,p_value_alignment=>'LEFT'
,p_attribute_01=>'N'
,p_attribute_02=>'POPUP'
,p_attribute_03=>'NONE'
,p_attribute_06=>'NONE'
,p_attribute_09=>'N'
,p_attribute_11=>'Y'
,p_is_required=>false
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_date_ranges=>'ALL'
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_include_in_export=>true
,p_readonly_condition_type=>'ALWAYS'
,p_readonly_for_each_row=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(455763632557984201)
,p_name=>'ALERTA'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'ALERTA'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>true
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>'Alerta'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>90
,p_value_alignment=>'LEFT'
,p_attribute_05=>'BOTH'
,p_is_required=>false
,p_max_length=>128
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_include_in_export=>true
,p_readonly_condition_type=>'ALWAYS'
,p_readonly_for_each_row=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(455764468791984209)
,p_name=>'SIG_MES'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'RPRMR1'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_SINGLE_CHECKBOX'
,p_heading=>'Sig Mes'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>110
,p_value_alignment=>'LEFT'
,p_attribute_01=>'N'
,p_attribute_02=>'1'
,p_is_required=>false
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(457860093077908367)
,p_name=>'NUMERO_CLIENTE'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'NUMERO_CLIENTE'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_NUMBER_FIELD'
,p_heading=>'Numero Cliente'
,p_heading_alignment=>'RIGHT'
,p_display_sequence=>120
,p_value_alignment=>'RIGHT'
,p_attribute_03=>'left'
,p_attribute_04=>'decimal'
,p_is_required=>false
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
,p_readonly_condition_type=>'ALWAYS'
,p_readonly_for_each_row=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(457860175976908368)
,p_name=>'RPDCT'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'RPDCT'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>'Rpdct'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>130
,p_value_alignment=>'LEFT'
,p_attribute_05=>'BOTH'
,p_is_required=>true
,p_max_length=>2
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
,p_readonly_condition_type=>'ALWAYS'
,p_readonly_for_each_row=>false
);
wwv_flow_imp_page.create_interactive_grid(
 p_id=>wwv_flow_imp.id(455762942320984194)
,p_internal_uid=>455762942320984194
,p_is_editable=>true
,p_edit_operations=>'u'
,p_lost_update_check_type=>'VALUES'
,p_submit_checked_rows=>false
,p_lazy_loading=>false
,p_requires_filter=>false
,p_select_first_row=>false
,p_fixed_row_height=>false
,p_pagination_type=>'SET'
,p_show_total_row_count=>true
,p_show_toolbar=>true
,p_enable_save_public_report=>false
,p_enable_subscriptions=>true
,p_enable_flashback=>true
,p_define_chart_view=>true
,p_enable_download=>true
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>true
,p_fixed_header=>'PAGE'
,p_show_icon_view=>false
,p_show_detail_view=>false
,p_updated_on=>wwv_flow_imp.dz('20260421175320Z')
,p_updated_by=>'JBALCAZAR'
);
wwv_flow_imp_page.create_ig_report(
 p_id=>wwv_flow_imp.id(457834392692825307)
,p_interactive_grid_id=>wwv_flow_imp.id(455762942320984194)
,p_static_id=>'2129038'
,p_type=>'PRIMARY'
,p_default_view=>'GRID'
,p_show_row_number=>false
,p_settings_area_expanded=>true
);
wwv_flow_imp_page.create_ig_report_view(
 p_id=>wwv_flow_imp.id(457834583113825311)
,p_report_id=>wwv_flow_imp.id(457834392692825307)
,p_view_type=>'GRID'
,p_stretch_columns=>true
,p_srv_exclude_null_values=>false
,p_srv_only_display_columns=>true
,p_edit_mode=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(245170433314530371)
,p_view_id=>wwv_flow_imp.id(457834583113825311)
,p_display_seq=>10
,p_column_id=>wwv_flow_imp.id(457860175976908368)
,p_is_visible=>false
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(457835114584825322)
,p_view_id=>wwv_flow_imp.id(457834583113825311)
,p_display_seq=>1
,p_column_id=>wwv_flow_imp.id(455763081069984195)
,p_is_visible=>false
,p_is_frozen=>false
,p_break_order=>5
,p_break_is_enabled=>true
,p_break_sort_direction=>'ASC'
,p_break_sort_nulls=>'LAST'
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(457835987811825330)
,p_view_id=>wwv_flow_imp.id(457834583113825311)
,p_display_seq=>2
,p_column_id=>wwv_flow_imp.id(455763197532984196)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(457836898207825334)
,p_view_id=>wwv_flow_imp.id(457834583113825311)
,p_display_seq=>3
,p_column_id=>wwv_flow_imp.id(455763300428984197)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(457837800490825338)
,p_view_id=>wwv_flow_imp.id(457834583113825311)
,p_display_seq=>4
,p_column_id=>wwv_flow_imp.id(455763392781984198)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(457838550501825342)
,p_view_id=>wwv_flow_imp.id(457834583113825311)
,p_display_seq=>5
,p_column_id=>wwv_flow_imp.id(455763519916984199)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(457839467383825345)
,p_view_id=>wwv_flow_imp.id(457834583113825311)
,p_display_seq=>6
,p_column_id=>wwv_flow_imp.id(455763538037984200)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(457840393463825349)
,p_view_id=>wwv_flow_imp.id(457834583113825311)
,p_display_seq=>7
,p_column_id=>wwv_flow_imp.id(455763632557984201)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(457850484351878441)
,p_view_id=>wwv_flow_imp.id(457834583113825311)
,p_display_seq=>8
,p_column_id=>wwv_flow_imp.id(455764468791984209)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(459360398837824870)
,p_view_id=>wwv_flow_imp.id(457834583113825311)
,p_display_seq=>9
,p_column_id=>wwv_flow_imp.id(457860093077908367)
,p_is_visible=>false
,p_is_frozen=>false
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(455204571778233905)
,p_plug_name=>unistr('BATCH SIN AFECTACI\00D3N A CUENTAS POR COBRAR')
,p_parent_plug_id=>wwv_flow_imp.id(452835382484307691)
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(112813843178917343)
,p_plug_display_sequence=>310
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT GLDOC DOCUMENTO, GLDCT TIPO, GLEXA AS EXTRACTO, GLICU NUMERO_BATCH, GLICUT TIPO_BATCH, GLAN8 NUMERO_CLIENTE, ABALPH NOMBRE_CLIENTE',
'FROM PRODDTA.F0911@jdedtadl ',
'INNER JOIN PRODDTA.F0101@jdedtadl ON GLAN8 = ABAN8',
'WHERE glFY= TO_NUMBER(TO_CHAR(SYSDATE, ''YY''))  and glicut IN (''RB'',''IB'') AND GLPOST =''P'' AND GLPN = EXTRACT(MONTH FROM SYSDATE) AND GLOBJ = ''11301'' AND GLSUB =''01''',
'AND NOT EXISTS',
'(SELECT 1 FROM PRODDTA.F03B11@jdedtadl WHERE RPICUT =GLICUT AND GLICU=RPICU AND GLAN8= RPAN8)'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_display_condition_type=>'EXPRESSION'
,p_plug_display_when_condition=>':P603_ID_REGION = 6'
,p_plug_display_when_cond2=>'PLSQL'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>11
,p_prn_height=>8.5
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(455204668769233906)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'TOP_AND_BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'MFERRIN'
,p_internal_uid=>455204668769233906
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(455759932947984164)
,p_db_column_name=>'DOCUMENTO'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Documento'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(455760102261984165)
,p_db_column_name=>'TIPO'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Tipo'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(455760140490984166)
,p_db_column_name=>'EXTRACTO'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Extracto'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(457859652674908363)
,p_db_column_name=>'NUMERO_BATCH'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Numero Batch'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(457859793028908364)
,p_db_column_name=>'NUMERO_CLIENTE'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Numero Cliente'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(457859858210908365)
,p_db_column_name=>'NOMBRE_CLIENTE'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'Nombre Cliente'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(457859951660908366)
,p_db_column_name=>'TIPO_BATCH'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>'Tipo Batch'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(455766692477000433)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'2108361'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'NUMERO_CLIENTE:NOMBRE_CLIENTE:DOCUMENTO:TIPO:EXTRACTO:NUMERO_BATCH:TIPO_BATCH:'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(453373800741372886)
,p_plug_name=>unistr('Conciliaci\00F3n Bancaria')
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(38289867500120143)
,p_plug_display_sequence=>150
,p_location=>null
,p_plug_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_plug_display_when_condition=>'P603_MODULO'
,p_plug_display_when_cond2=>'CONBAN'
,p_ai_enabled=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(457860896013908375)
,p_plug_name=>'CARGO DE ESTADO DE CUENTA'
,p_parent_plug_id=>wwv_flow_imp.id(453373800741372886)
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(112813843178917343)
,p_plug_display_sequence=>310
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'WITH BANCOS AS (',
'    SELECT ''PRODUBANCO'' NOMBRE_BANCO, ''00330376'' CUENTA, ''FALTA CARGAR ESTADO DE CUENTA'' ALERTA FROM DUAL UNION ALL',
'    SELECT ''BOLIVARIANO'' NOMBRE_BANCO, ''00405198'' CUENTA, ''FALTA CARGAR ESTADO DE CUENTA'' ALERTA FROM DUAL UNION ALL',
'    SELECT ''CITIBANK'' NOMBRE_BANCO, ''00405201'' CUENTA, ''FALTA CARGAR ESTADO DE CUENTA'' ALERTA FROM DUAL UNION ALL',
'    SELECT ''CITIBANK NEW YORK'' NOMBRE_BANCO, ''00405227'' CUENTA, ''FALTA CARGAR ESTADO DE CUENTA'' ALERTA FROM DUAL',
')',
'SELECT * FROM BANCOS',
'WHERE NOT EXISTS(',
'    SELECT 1',
'    FROM PRODDTA.F5509505@jdedtadl a',
'    INNER JOIN PRODDTA.f0901@jdedtadl b ON a.MPAID = b.GMAID',
'    WHERE trim(a.MPAID) = BANCOS.CUENTA',
'    AND a.MPDGJ BETWEEN TO_CHAR(TRUNC(SYSDATE,''MM''), ''YYYYDDD'') - 1900000',
'                AND TO_CHAR(LAST_DAY(SYSDATE), ''YYYYDDD'') - 1900000',
')'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_display_condition_type=>'EXPRESSION'
,p_plug_display_when_condition=>':P603_ID_REGION = 1'
,p_plug_display_when_cond2=>'PLSQL'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>11
,p_prn_height=>8.5
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(457860966188908376)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'TOP_AND_BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'MFERRIN'
,p_internal_uid=>457860966188908376
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(457861373582908380)
,p_db_column_name=>'NOMBRE_BANCO'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Nombre Banco'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(457861445036908381)
,p_db_column_name=>'CUENTA'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Cuenta'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(457861524732908382)
,p_db_column_name=>'ALERTA'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Alerta'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(459688102189965252)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'2147575'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'NOMBRE_BANCO:CUENTA:ALERTA'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(457861677999908383)
,p_plug_name=>'REGISTROS SIN REFERENCIA'
,p_parent_plug_id=>wwv_flow_imp.id(453373800741372886)
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(112813843178917343)
,p_plug_display_sequence=>340
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select to_date(MPDGJ + 1900000,''yyyyddd'') FEC_DOC, trim(GMDL01) nombre_banco, MPCKNU referencia_bancaria, MPAA/100 monto, trim(MPEXR) || '' | '' || TRIM(mpdl01) explicacion ,',
'MPEDLN/1000 Linea, MPEDUS Usuario_Carga, MPEV02, MPEV01, MPEDBT Batch,',
' TRIM(mpdl02) lugar',
'from proddta.F5509505@jdedtadl a, proddta.f0901@jdedtadl b',
'WHERE a.MPAID = b.GMAID and MPDGJ BETWEEN TO_CHAR(trunc(sysdate,''MM'') ,''YYYYDDD'') - 1900000 AND TO_CHAR(LAST_DAY(SYSDATE) ,''YYYYDDD'') - 1900000 AND TRIM(MPCKNU) IS NULL'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_display_condition_type=>'EXPRESSION'
,p_plug_display_when_condition=>':P603_ID_REGION = 3'
,p_plug_display_when_cond2=>'PLSQL'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>11
,p_prn_height=>8.5
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(457861745767908384)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'TOP_AND_BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'MFERRIN'
,p_internal_uid=>457861745767908384
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(457861909981908385)
,p_db_column_name=>'NOMBRE_BANCO'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Nombre Banco'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(457862154536908388)
,p_db_column_name=>'FEC_DOC'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Fec Doc'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(457862244736908389)
,p_db_column_name=>'REFERENCIA_BANCARIA'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Referencia Bancaria'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(457862358582908390)
,p_db_column_name=>'MONTO'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Monto'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(457862521143908391)
,p_db_column_name=>'EXPLICACION'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Explicacion'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(457862575132908392)
,p_db_column_name=>'LINEA'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'Linea'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(457862666783908393)
,p_db_column_name=>'USUARIO_CARGA'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>'Usuario Carga'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(457862803142908394)
,p_db_column_name=>'MPEV02'
,p_display_order=>80
,p_column_identifier=>'H'
,p_column_label=>'Mpev02'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(457862871556908395)
,p_db_column_name=>'MPEV01'
,p_display_order=>90
,p_column_identifier=>'I'
,p_column_label=>'Mpev01'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(457862944522908396)
,p_db_column_name=>'BATCH'
,p_display_order=>100
,p_column_identifier=>'J'
,p_column_label=>'Batch'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(457863080890908397)
,p_db_column_name=>'LUGAR'
,p_display_order=>110
,p_column_identifier=>'K'
,p_column_label=>'Lugar'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(459776076288443969)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'2148455'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'NOMBRE_BANCO:FEC_DOC:REFERENCIA_BANCARIA:MONTO:EXPLICACION:LINEA:USUARIO_CARGA:MPEV02:MPEV01:BATCH:LUGAR'
,p_break_on=>'NOMBRE_BANCO'
,p_break_enabled_on=>'NOMBRE_BANCO'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(457864191628908408)
,p_plug_name=>unistr('ESTADO DE CUENTA VS CONCILIACI\00D3N')
,p_parent_plug_id=>wwv_flow_imp.id(453373800741372886)
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(38289867500120143)
,p_plug_display_sequence=>320
,p_plug_display_point=>'SUB_REGIONS'
,p_location=>null
,p_plug_display_condition_type=>'EXPRESSION'
,p_plug_display_when_condition=>':P603_ID_REGION = 2'
,p_plug_display_when_cond2=>'PLSQL'
,p_ai_enabled=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(457864307348908409)
,p_plug_name=>'Cuentas por Cobrar'
,p_parent_plug_id=>wwv_flow_imp.id(457864191628908408)
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(112813843178917343)
,p_plug_display_sequence=>350
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'WITH PARAMETROS AS (',
unistr('    -- Pre-calculamos la fecha l\00EDmite para mantener la extrema velocidad'),
'    SELECT (TO_NUMBER(TO_CHAR(LAST_DAY(SYSDATE), ''YYYYDDD'')) - 1900000) AS FECHA_JULIANA_LIMITE',
'    FROM DUAL',
'),',
'BANCOS AS (',
'    -- Maestro de bancos',
'    SELECT',
'        TRIM(UPPER(AYDL01)) AS BANCO,',
'        AYAID AS CUENTA_JOIN',
'    FROM PRODDTA.f0030@jdedtadl',
'    WHERE trim(aycbnk) is not null and trim(aydl01) is not null',
')',
'',
'-- ==========================================',
unistr('-- 1. MOVIMIENTOS CXC (F0911) L\00EDnea por l\00EDnea'),
'-- ==========================================',
'SELECT',
'     TRIM(M.GLAID) AS NUMERO_CUENTA,',
'     B.BANCO AS NOMBRE_BANCO,',
'    ''REPORTE CONTABILIDAD'' AS ORIGEN,',
'    SUM(M.GLAA / 100) AS MONTO',
'FROM PRODDTA.F0911@jdedtadl M',
'CROSS JOIN PARAMETROS P',
'INNER JOIN BANCOS B ON M.GLAID = B.CUENTA_JOIN',
'WHERE',
'    M.GLDCT IN (''RC'',''RO'',''J#'',''JE'',''JO'')',
'    AND M.GLRCND = '' ''',
'    AND M.GLAA > 0',
'    AND M.GLDGJ <= P.FECHA_JULIANA_LIMITE',
'    AND M.GLRE != ''V''',
'    AND M.GLLT = ''AA''',
'GROUP BY TRIM(M.GLAID), B.BANCO',
'',
'UNION ALL',
'',
'-- ==========================================',
unistr('-- 2. MOVIMIENTOS CB (F5509505) L\00EDnea por l\00EDnea'),
'-- ==========================================',
'SELECT',
'    TRIM(C.MPAID) AS NUMERO_CUENTA,',
'    B.BANCO AS NOMBRE_BANCO,',
'    ''BANCO'' AS ORIGEN,',
'    sum((C.MPAA) / 100) AS MONTO',
'FROM PRODDTA.F5509505@jdedtadl C',
'CROSS JOIN PARAMETROS P',
'INNER JOIN BANCOS B ON C.MPAID = B.CUENTA_JOIN',
'WHERE',
'    C.MPDGJ <= P.FECHA_JULIANA_LIMITE',
'    AND C.MPAA > 0',
'    AND C.MPEV01 <> ''P''',
'    AND DECODE(C.MPEV01, '' '', ''1'') <> C.MPEV02',
'GROUP BY TRIM(C.MPAID), B.BANCO',
'ORDER BY NOMBRE_BANCO, NUMERO_CUENTA;'))
,p_plug_source_type=>'NATIVE_IR'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>11
,p_prn_height=>8.5
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(457864354262908410)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'TOP_AND_BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'MFERRIN'
,p_internal_uid=>457864354262908410
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(459808582123175561)
,p_db_column_name=>'NOMBRE_BANCO'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Nombre Banco'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(459808895503175564)
,p_db_column_name=>'MONTO'
,p_display_order=>40
,p_column_identifier=>'B'
,p_column_label=>'Monto Total'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(459809656867175572)
,p_db_column_name=>'NUMERO_CUENTA'
,p_display_order=>50
,p_column_identifier=>'C'
,p_column_label=>'Numero Cuenta'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(459809751601175573)
,p_db_column_name=>'ORIGEN'
,p_display_order=>60
,p_column_identifier=>'D'
,p_column_label=>'Origen'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(459815623480180853)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'2148850'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'NUMERO_CUENTA:NOMBRE_BANCO:ORIGEN:MONTO:'
,p_break_on=>'NOMBRE_BANCO'
,p_break_enabled_on=>'NOMBRE_BANCO'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(459809848968175574)
,p_plug_name=>'Cuentas por Pagar'
,p_parent_plug_id=>wwv_flow_imp.id(457864191628908408)
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(112813843178917343)
,p_plug_display_sequence=>370
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'WITH PARAMETROS AS (',
unistr('    -- Pre-calculamos la fecha l\00EDmite para mantener la extrema velocidad'),
'    SELECT (TO_NUMBER(TO_CHAR(LAST_DAY(SYSDATE), ''YYYYDDD'')) - 1900000) AS FECHA_JULIANA_LIMITE',
'    FROM DUAL',
'),',
'BANCOS AS (',
'    -- Maestro de bancos',
'    SELECT',
'        TRIM(UPPER(AYDL01)) AS BANCO,',
'        AYAID AS CUENTA_JOIN',
'    FROM PRODDTA.f0030@jdedtadl',
'    WHERE trim(aycbnk) is not null and trim(aydl01) is not null',
')',
'',
'-- ==========================================',
unistr('-- 1. MOVIMIENTOS CXC (F0911) L\00EDnea por l\00EDnea'),
'-- ==========================================',
'SELECT',
'     TRIM(M.GLAID) AS NUMERO_CUENTA,',
'     B.BANCO AS NOMBRE_BANCO,',
'    ''REPORTE CONTABILIDAD'' AS ORIGEN,',
'    SUM(M.GLAA / 100) AS MONTO',
'FROM PRODDTA.F0911@jdedtadl M',
'CROSS JOIN PARAMETROS P',
'INNER JOIN BANCOS B ON M.GLAID = B.CUENTA_JOIN',
'WHERE',
'    M.GLDCT NOT IN (''RC'',''RO'',''J#'',''RZ'',''PZ'',''MZ'',''4Z'')',
'    AND M.GLRCND = '' ''',
'    AND M.GLAA < 0',
'    AND M.GLDGJ <= P.FECHA_JULIANA_LIMITE',
'    AND M.GLRE != ''V''',
'    AND M.GLLT = ''AA''',
'GROUP BY TRIM(M.GLAID), B.BANCO',
'',
'UNION ALL',
'',
'-- ==========================================',
unistr('-- 2. MOVIMIENTOS CB (F5509505) L\00EDnea por l\00EDnea'),
'-- ==========================================',
'SELECT',
'    TRIM(C.MPAID) AS NUMERO_CUENTA,',
'    B.BANCO AS NOMBRE_BANCO,',
'    ''BANCO'' AS ORIGEN,',
'    sum((C.MPAA) / 100) AS MONTO',
'FROM PRODDTA.F5509505@jdedtadl C',
'CROSS JOIN PARAMETROS P',
'INNER JOIN BANCOS B ON C.MPAID = B.CUENTA_JOIN',
'WHERE',
'    C.MPDGJ <= P.FECHA_JULIANA_LIMITE',
'    AND C.MPAA < 0',
'    AND C.MPEV01 <> ''P''',
'    AND DECODE(C.MPEV01, '' '', ''1'') <> C.MPEV02 --and TRIM(MPEDUS) = ''OIMBAQUING''',
'GROUP BY TRIM(C.MPAID), B.BANCO',
'ORDER BY NOMBRE_BANCO, NUMERO_CUENTA;'))
,p_plug_source_type=>'NATIVE_IR'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>11
,p_prn_height=>8.5
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(459809971493175575)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'TOP_AND_BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'MFERRIN'
,p_internal_uid=>459809971493175575
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(459810119178175576)
,p_db_column_name=>'NOMBRE_BANCO'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Nombre Banco'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(459810152968175577)
,p_db_column_name=>'MONTO'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Monto Total'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(459810293388175578)
,p_db_column_name=>'NUMERO_CUENTA'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Numero Cuenta'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(459810414062175579)
,p_db_column_name=>'ORIGEN'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Origen'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(459818587789197440)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'2148880'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'NUMERO_CUENTA:NOMBRE_BANCO:ORIGEN:MONTO:'
,p_break_on=>'NOMBRE_BANCO'
,p_break_enabled_on=>'NOMBRE_BANCO'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(459810521968175580)
,p_plug_name=>unistr('SALDOS DE CONCILIACI\00D3N DIFERENTE DE 0')
,p_parent_plug_id=>wwv_flow_imp.id(453373800741372886)
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(38289867500120143)
,p_plug_display_sequence=>350
,p_plug_display_point=>'SUB_REGIONS'
,p_location=>null
,p_plug_display_condition_type=>'EXPRESSION'
,p_plug_display_when_condition=>':P603_ID_REGION = 4'
,p_plug_display_when_cond2=>'PLSQL'
,p_ai_enabled=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(459813190629175607)
,p_plug_name=>'Nosotros Debitamos Banco No Acredita'
,p_parent_plug_id=>wwv_flow_imp.id(459810521968175580)
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(112813843178917343)
,p_plug_display_sequence=>350
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'WITH PARAMETROS AS (',
unistr('    -- Pre-calculamos la fecha l\00EDmite una sola vez'),
'    SELECT (TO_NUMBER(TO_CHAR(LAST_DAY(SYSDATE), ''YYYYDDD'')) - 1900000) AS FECHA_JULIANA_LIMITE',
'    FROM DUAL',
'),',
'BANCOS AS (',
'    -- Maestro de bancos',
'    SELECT',
'        TRIM(UPPER(AYDL01)) AS BANCO,',
'        AYAID AS CUENTA_JOIN',
'    FROM PRODDTA.f0030@jdedtadl',
'    WHERE trim(AYCBNK) IS NOT NULL',
'      AND trim(AYDL01) IS NOT NULL',
')',
unistr('SELECT CUENTA_JOIN CUENTA, BANCO, to_date(GLDGJ + 1900000,''yyyyddd'') FEC_DOC,GLDCT TIP_DOC, GLDOC NUM_DOC, GLANI CUENTA_CONTABLE,GLICU BATCH, GLAA/100 MONTO  ,GLEXR COMPROBANTE, GLEXA DESCRIPCI\00D3N'),
'FROM PRODDTA.F0911@jdedtadl',
'INNER JOIN BANCOS B ON GLAID = B.CUENTA_JOIN',
'CROSS JOIN PARAMETROS P',
'WHERE GLDGJ <= P.FECHA_JULIANA_LIMITE AND (GLAA/100)>0',
'AND GLDCT IN (''RC'',''RO'',''J#'',''JE'',''JI'',''JW'',''JO'',''JN'') AND GLRE !=''V'' and GLRCND ='' '' and gllt=''AA''',
'ORDER BY BANCO, GLDGJ;'))
,p_plug_source_type=>'NATIVE_IR'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>11
,p_prn_height=>8.5
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
,p_ai_enabled=>false
,p_updated_on=>wwv_flow_imp.dz('20260514174516Z')
,p_updated_by=>'JBALCAZAR'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(459813291299175608)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'TOP_AND_BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'MFERRIN'
,p_internal_uid=>459813291299175608
,p_updated_on=>wwv_flow_imp.dz('20260429143903Z')
,p_updated_by=>'GCACHIPUENDO'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(459813520161175610)
,p_db_column_name=>'FEC_DOC'
,p_display_order=>20
,p_column_identifier=>'A'
,p_column_label=>'Fec Doc'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(459828625300403662)
,p_db_column_name=>'MONTO'
,p_display_order=>40
,p_column_identifier=>'B'
,p_column_label=>'Monto'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(459829449764403670)
,p_db_column_name=>'TIP_DOC'
,p_display_order=>50
,p_column_identifier=>'C'
,p_column_label=>'Tip Doc'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(459829530124403671)
,p_db_column_name=>'NUM_DOC'
,p_display_order=>60
,p_column_identifier=>'D'
,p_column_label=>'Num Doc'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(459829713571403672)
,p_db_column_name=>'CUENTA'
,p_display_order=>70
,p_column_identifier=>'E'
,p_column_label=>'Cuenta'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(459829812200403673)
,p_db_column_name=>'BATCH'
,p_display_order=>80
,p_column_identifier=>'F'
,p_column_label=>'Batch'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(459829841860403674)
,p_db_column_name=>'COMPROBANTE'
,p_display_order=>90
,p_column_identifier=>'G'
,p_column_label=>'Comprobante'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(459829990641403675)
,p_db_column_name=>unistr('DESCRIPCI\00D3N')
,p_display_order=>100
,p_column_identifier=>'H'
,p_column_label=>unistr('Descripci\00F3n')
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(459831059455403686)
,p_db_column_name=>'BANCO'
,p_display_order=>110
,p_column_identifier=>'I'
,p_column_label=>'Banco'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(459831198547403687)
,p_db_column_name=>'CUENTA_CONTABLE'
,p_display_order=>120
,p_column_identifier=>'J'
,p_column_label=>'Cuenta Contable'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(459837253585419050)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'2149067'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_display_rows=>20
,p_report_columns=>unistr('BANCO:CUENTA:FEC_DOC:TIP_DOC:NUM_DOC:CUENTA_CONTABLE:BATCH:MONTO:COMPROBANTE:DESCRIPCI\00D3N:')
,p_updated_on=>wwv_flow_imp.dz('20260429143903Z')
,p_updated_by=>'GCACHIPUENDO'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(459831262787403688)
,p_plug_name=>'Nosotros Acreditamos Banco No Debita'
,p_parent_plug_id=>wwv_flow_imp.id(459810521968175580)
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(112813843178917343)
,p_plug_display_sequence=>360
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'WITH PARAMETROS AS (',
unistr('    -- Pre-calculamos la fecha l\00EDmite una sola vez'),
'    SELECT (TO_NUMBER(TO_CHAR(LAST_DAY(SYSDATE), ''YYYYDDD'')) - 1900000) AS FECHA_JULIANA_LIMITE',
'    FROM DUAL',
'),',
'BANCOS AS (',
'    -- Maestro de bancos',
'    SELECT',
'        TRIM(UPPER(AYDL01)) AS BANCO,',
'        AYAID AS CUENTA_JOIN',
'    FROM PRODDTA.f0030@jdedtadl',
'    WHERE trim(AYCBNK) IS NOT NULL',
'      AND trim(AYDL01) IS NOT NULL',
')',
unistr('SELECT CUENTA_JOIN CUENTA, BANCO, to_date(GLDGJ + 1900000,''yyyyddd'') FEC_DOC,GLDCT TIP_DOC, GLDOC NUM_DOC, GLANI CUENTA_CONTABLE,GLICU BATCH, GLAA/100 MONTO  ,GLCKNU COMPROBANTE, GLEXA DESCRIPCI\00D3N'),
'FROM PRODDTA.F0911@jdedtadl',
'INNER JOIN BANCOS B ON GLAID = B.CUENTA_JOIN',
'CROSS JOIN PARAMETROS P',
'WHERE GLDGJ <= p.FECHA_JULIANA_LIMITE',
'AND GLDCT NOT IN (''RC'',''RO'',''J#'',''RZ'',''PZ'',''MZ'',''4Z'') AND GLRCND ='' ''  AND GLAA<0',
'AND GLRE !=''V'' AND GLLT=''AA''',
'ORDER BY BANCO,GLDGJ;'))
,p_plug_source_type=>'NATIVE_IR'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>11
,p_prn_height=>8.5
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
,p_ai_enabled=>false
,p_updated_on=>wwv_flow_imp.dz('20260429143959Z')
,p_updated_by=>'GCACHIPUENDO'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(459831363341403689)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'TOP_AND_BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'MFERRIN'
,p_internal_uid=>459831363341403689
,p_updated_on=>wwv_flow_imp.dz('20260429143959Z')
,p_updated_by=>'GCACHIPUENDO'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(459831474290403690)
,p_db_column_name=>'FEC_DOC'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Fec Doc'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(459831569733403691)
,p_db_column_name=>'MONTO'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Monto'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(459831623815403692)
,p_db_column_name=>'TIP_DOC'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Tip Doc'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(459831802105403693)
,p_db_column_name=>'NUM_DOC'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Num Doc'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(459831884397403694)
,p_db_column_name=>'CUENTA'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Cuenta'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(459831992701403695)
,p_db_column_name=>'BATCH'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'Batch'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(459832109724403696)
,p_db_column_name=>'COMPROBANTE'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>'Comprobante'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(459832191096403697)
,p_db_column_name=>unistr('DESCRIPCI\00D3N')
,p_display_order=>80
,p_column_identifier=>'H'
,p_column_label=>unistr('Descripci\00F3n')
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(459832264975403698)
,p_db_column_name=>'BANCO'
,p_display_order=>90
,p_column_identifier=>'I'
,p_column_label=>'Banco'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(459832351626403699)
,p_db_column_name=>'CUENTA_CONTABLE'
,p_display_order=>100
,p_column_identifier=>'J'
,p_column_label=>'Cuenta Contable'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(459855189050506480)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'2149246'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_display_rows=>20
,p_report_columns=>unistr('BANCO:CUENTA:FEC_DOC:TIP_DOC:NUM_DOC:CUENTA_CONTABLE:BATCH:MONTO:COMPROBANTE:DESCRIPCI\00D3N:')
,p_updated_on=>wwv_flow_imp.dz('20260429143959Z')
,p_updated_by=>'GCACHIPUENDO'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(459832481359403700)
,p_plug_name=>'Banco Acredita Nosotros No Debitamos'
,p_parent_plug_id=>wwv_flow_imp.id(459810521968175580)
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(112813843178917343)
,p_plug_display_sequence=>370
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'WITH PARAMETROS AS (',
unistr('    -- Pre-calculamos la fecha l\00EDmite una sola vez'),
'    SELECT (TO_NUMBER(TO_CHAR(LAST_DAY(SYSDATE), ''YYYYDDD'')) - 1900000) AS FECHA_JULIANA_LIMITE',
'    FROM DUAL',
'),',
'BANCOS AS (',
'    -- Maestro de bancos',
'    SELECT',
'        TRIM(UPPER(AYDL01)) AS BANCO,',
'        AYAID AS CUENTA_JOIN',
'    FROM PRODDTA.f0030@jdedtadl',
'    WHERE trim(AYCBNK) IS NOT NULL',
'      AND trim(AYDL01) IS NOT NULL',
')',
unistr('SELECT CUENTA_JOIN CUENTA, BANCO, MPCKNU COMPROBANTE, MPAA/100 MONTO,MPEXR EXPLICACI\00D3N,F_JDE2G(MPDGJ) FECHA'),
'FROM PRODDTA.F5509505@jdedtadl',
'INNER JOIN BANCOS B ON MPAID = B.CUENTA_JOIN',
'CROSS JOIN PARAMETROS P',
'WHERE   MPDGJ <= P.FECHA_JULIANA_LIMITE',
'AND MPAA>0 AND MPEV01 <>''P'' AND MPEV02<>''1''',
'ORDER BY BANCO'))
,p_plug_source_type=>'NATIVE_IR'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>11
,p_prn_height=>8.5
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
,p_ai_enabled=>false
,p_updated_on=>wwv_flow_imp.dz('20260429144017Z')
,p_updated_by=>'GCACHIPUENDO'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(459832524020403701)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'TOP_AND_BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'MFERRIN'
,p_internal_uid=>459832524020403701
,p_updated_on=>wwv_flow_imp.dz('20260429144017Z')
,p_updated_by=>'GCACHIPUENDO'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(459832802370403703)
,p_db_column_name=>'MONTO'
,p_display_order=>20
,p_column_identifier=>'A'
,p_column_label=>'Monto'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(459833056706403706)
,p_db_column_name=>'CUENTA'
,p_display_order=>50
,p_column_identifier=>'B'
,p_column_label=>'Cuenta'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(459833292319403708)
,p_db_column_name=>'COMPROBANTE'
,p_display_order=>70
,p_column_identifier=>'C'
,p_column_label=>'Comprobante'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(459833484558403710)
,p_db_column_name=>'BANCO'
,p_display_order=>90
,p_column_identifier=>'D'
,p_column_label=>'Banco'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(459856719311525362)
,p_db_column_name=>unistr('EXPLICACI\00D3N')
,p_display_order=>100
,p_column_identifier=>'E'
,p_column_label=>unistr('Explicaci\00F3n')
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(459856802875525363)
,p_db_column_name=>'FECHA'
,p_display_order=>110
,p_column_identifier=>'F'
,p_column_label=>'Fecha'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(459864206696528126)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'2149336'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_display_rows=>20
,p_report_columns=>unistr('BANCO:CUENTA:FECHA:COMPROBANTE:MONTO:EXPLICACI\00D3N:')
,p_updated_on=>wwv_flow_imp.dz('20260429144017Z')
,p_updated_by=>'GCACHIPUENDO'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(459856842648525364)
,p_plug_name=>'Banco Debita Nosotros No Acreditamos'
,p_parent_plug_id=>wwv_flow_imp.id(459810521968175580)
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(112813843178917343)
,p_plug_display_sequence=>380
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'WITH PARAMETROS AS (',
unistr('    -- Pre-calculamos la fecha l\00EDmite una sola vez'),
'    SELECT (TO_NUMBER(TO_CHAR(LAST_DAY(SYSDATE), ''YYYYDDD'')) - 1900000) AS FECHA_JULIANA_LIMITE',
'    FROM DUAL',
'),',
'BANCOS AS (',
'    -- Maestro de bancos',
'    SELECT',
'        TRIM(UPPER(AYDL01)) AS BANCO,',
'        AYAID AS CUENTA_JOIN',
'    FROM PRODDTA.f0030@jdedtadl',
'    WHERE trim(AYCBNK) IS NOT NULL',
'      AND trim(AYDL01) IS NOT NULL',
')',
unistr('SELECT CUENTA_JOIN CUENTA, BANCO,MPCKNU COMPROBANTE, MPAA/100 MONTO,MPEXR EXPLICACI\00D3N,F_JDE2G(MPDGJ) FECHA'),
'FROM PRODDTA.F5509505@jdedtadl',
'INNER JOIN BANCOS B ON MPAID = B.CUENTA_JOIN',
'CROSS JOIN PARAMETROS P',
'WHERE   MPDGJ <= P.FECHA_JULIANA_LIMITE',
'AND MPAA<0 AND MPEV01 <>''P'' AND MPEV02<>''1''',
'order by BANCO'))
,p_plug_source_type=>'NATIVE_IR'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>11
,p_prn_height=>8.5
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
,p_ai_enabled=>false
,p_updated_on=>wwv_flow_imp.dz('20260429144034Z')
,p_updated_by=>'GCACHIPUENDO'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(459856979938525365)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'TOP_AND_BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'MFERRIN'
,p_internal_uid=>459856979938525365
,p_updated_on=>wwv_flow_imp.dz('20260429144034Z')
,p_updated_by=>'GCACHIPUENDO'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(459857118185525366)
,p_db_column_name=>'MONTO'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Monto'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(459857259994525368)
,p_db_column_name=>'COMPROBANTE'
,p_display_order=>30
,p_column_identifier=>'B'
,p_column_label=>'Comprobante'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(459857425186525370)
,p_db_column_name=>unistr('EXPLICACI\00D3N')
,p_display_order=>50
,p_column_identifier=>'C'
,p_column_label=>unistr('Explicaci\00F3n')
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(459857547095525371)
,p_db_column_name=>'FECHA'
,p_display_order=>60
,p_column_identifier=>'D'
,p_column_label=>'Fecha'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(459857717586525372)
,p_db_column_name=>'CUENTA'
,p_display_order=>70
,p_column_identifier=>'E'
,p_column_label=>'Cuenta'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(459857765082525373)
,p_db_column_name=>'BANCO'
,p_display_order=>80
,p_column_identifier=>'F'
,p_column_label=>'Banco'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(459868123856557376)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'2149376'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_display_rows=>20
,p_report_columns=>unistr('CUENTA:BANCO:FECHA:COMPROBANTE:MONTO:EXPLICACI\00D3N:')
,p_updated_on=>wwv_flow_imp.dz('20260429144034Z')
,p_updated_by=>'GCACHIPUENDO'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(461467472108089401)
,p_plug_name=>unistr('PARTIDAS NO CONCILIADAS (EXCEPCI\00D3N PRODUBANCO)')
,p_parent_plug_id=>wwv_flow_imp.id(453373800741372886)
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(38289867500120143)
,p_plug_display_sequence=>370
,p_plug_display_point=>'SUB_REGIONS'
,p_location=>null
,p_plug_display_condition_type=>'EXPRESSION'
,p_plug_display_when_condition=>':P603_ID_REGION = 5'
,p_plug_display_when_cond2=>'PLSQL'
,p_ai_enabled=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(461958605753549064)
,p_plug_name=>'Cuentas por Pagar'
,p_parent_plug_id=>wwv_flow_imp.id(461467472108089401)
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(112813843178917343)
,p_plug_display_sequence=>370
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'WITH PARAMETROS AS (',
unistr('    -- Pre-calculamos la fecha l\00EDmite para mantener la extrema velocidad'),
'    SELECT (TO_NUMBER(TO_CHAR(LAST_DAY(SYSDATE), ''YYYYDDD'')) - 1900000) AS FECHA_JULIANA_LIMITE',
'    FROM DUAL',
'),',
'BANCOS AS (',
'    -- Maestro de bancos',
'    SELECT',
'        TRIM(UPPER(AYDL01)) AS BANCO,',
'        AYAID AS CUENTA_JOIN',
'    FROM PRODDTA.f0030@jdedtadl',
'    WHERE trim(aycbnk) is not null and trim(aydl01) is not null and AYAID <> ''00330376''',
'),',
'CONTA AS (',
unistr('    -- 1. MOVIMIENTOS CXC (F0911) L\00EDnea por l\00EDnea'),
'    SELECT',
'         TRIM(M.GLAID) AS NUMERO_CUENTA,',
'         B.BANCO AS NOMBRE_BANCO,',
'        ''REPORTE CONTABILIDAD'' AS ORIGEN,',
'        M.GLAA / 100 AS MONTO,',
unistr('        GLEXA AS EXPLICACI\00D3N,'),
'        NVL(TRIM(DECODE(SUBSTR(GLEXR,1,1),''0'',GLEXR , GLEXR )), GLEXA) AS COMPROBANTE',
'    FROM PRODDTA.F0911@jdedtadl M',
'    CROSS JOIN PARAMETROS P',
'    INNER JOIN BANCOS B ON M.GLAID = B.CUENTA_JOIN',
'    WHERE',
'        M.GLDCT NOT IN (''RC'',''RO'',''J#'',''RZ'',''PZ'',''MZ'',''4Z'')',
'        AND M.GLRCND = '' ''',
'        AND M.GLAA < 0',
'        AND M.GLDGJ <= P.FECHA_JULIANA_LIMITE',
'        AND M.GLRE != ''V''',
'        AND M.GLLT = ''AA''',
'),',
'BANCO_MOV AS (',
unistr('    -- 2. MOVIMIENTOS BANCO (F5509505) L\00EDnea por l\00EDnea'),
'    SELECT',
'        TRIM(C.MPAID) AS NUMERO_CUENTA,',
'        B.BANCO AS NOMBRE_BANCO,',
'        ''BANCO'' AS ORIGEN,',
'        (C.MPAA) / 100 AS MONTO,',
unistr('        MPEXR AS EXPLICACI\00D3N,'),
'        MPCKNU AS COMPROBANTE',
'    FROM PRODDTA.F5509505@jdedtadl C',
'    CROSS JOIN PARAMETROS P',
'    INNER JOIN BANCOS B ON C.MPAID = B.CUENTA_JOIN',
'    WHERE',
'        C.MPDGJ <= P.FECHA_JULIANA_LIMITE',
'        AND C.MPAA < 0',
'        AND C.MPEV01 <> ''P''',
'        AND DECODE(C.MPEV01, '' '', ''1'') <> C.MPEV02',
'),',
'-- ==========================================',
unistr('-- 3. UNI\00D3N DE MOVIMIENTOS'),
'-- ==========================================',
'UNIFICADO AS (',
'    SELECT * FROM CONTA',
'    UNION ALL',
'    SELECT * FROM BANCO_MOV',
'),',
'-- ==========================================',
unistr('-- 4. C\00C1LCULO DE TOTALES POR CUENTA (Window Functions)'),
'-- ==========================================',
'CALCULO_TOTALES AS (',
'    SELECT',
'        U.*,',
'        -- Sumamos el monto solo si es de Contabilidad, particionando por cuenta y banco',
'        SUM(CASE WHEN ORIGEN = ''REPORTE CONTABILIDAD'' THEN MONTO ELSE 0 END)',
'            OVER (PARTITION BY NUMERO_CUENTA) AS TOTAL_CONTA,',
'        -- Sumamos el monto solo si es de Banco, particionando por cuenta y banco',
'        SUM(CASE WHEN ORIGEN = ''BANCO'' THEN MONTO ELSE 0 END)',
'            OVER (PARTITION BY NUMERO_CUENTA) AS TOTAL_BANCO',
'    FROM UNIFICADO U',
')',
'-- ==========================================',
unistr('-- 5. EXTRACCI\00D3N FINAL (Filtro de diferencias)'),
'-- ==========================================',
'SELECT',
'    NUMERO_CUENTA,',
'    NOMBRE_BANCO,',
'    ORIGEN,',
'    MONTO,',
unistr('    EXPLICACI\00D3N,'),
'    COMPROBANTE',
'FROM CALCULO_TOTALES',
'-- Filtramos donde el total de contabilidad sea diferente al del banco',
'WHERE ROUND(TOTAL_CONTA, 2) <> ROUND(TOTAL_BANCO, 2)',
'ORDER BY NUMERO_CUENTA, MONTO, ORIGEN DESC;'))
,p_plug_source_type=>'NATIVE_IR'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>11
,p_prn_height=>8.5
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(461958631144549065)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'TOP_AND_BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'MFERRIN'
,p_internal_uid=>461958631144549065
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(461958750424549066)
,p_db_column_name=>'NOMBRE_BANCO'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Nombre Banco'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(461958848973549067)
,p_db_column_name=>'MONTO'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Monto Total'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(461958981992549068)
,p_db_column_name=>'NUMERO_CUENTA'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Numero Cuenta'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(461959097598549069)
,p_db_column_name=>'ORIGEN'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Origen'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(461960650302549085)
,p_db_column_name=>unistr('EXPLICACI\00D3N')
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>unistr('Explicaci\00F3n')
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(461960784783549086)
,p_db_column_name=>'COMPROBANTE'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'Comprobante'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(461968606712563621)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'2170380'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>unistr('NOMBRE_BANCO:NUMERO_CUENTA:ORIGEN:COMPROBANTE:EXPLICACI\00D3N:MONTO:')
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(461959155873549070)
,p_plug_name=>'Cuentas por Cobrar'
,p_parent_plug_id=>wwv_flow_imp.id(461467472108089401)
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(112813843178917343)
,p_plug_display_sequence=>360
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'WITH PARAMETROS AS (',
unistr('    -- Pre-calculamos la fecha l\00EDmite para mantener la extrema velocidad'),
'    SELECT (TO_NUMBER(TO_CHAR(LAST_DAY(SYSDATE), ''YYYYDDD'')) - 1900000) AS FECHA_JULIANA_LIMITE',
'    FROM DUAL',
'),',
'BANCOS AS (',
'    -- Maestro de bancos',
'    SELECT',
'        TRIM(UPPER(AYDL01)) AS BANCO,',
'        AYAID AS CUENTA_JOIN',
'    FROM PRODDTA.F0030@jdedtadl',
'    WHERE TRIM(AYCBNK) IS NOT NULL AND TRIM(AYDL01) IS NOT NULL AND AYAID <> ''00330376''',
'),',
'CONTA AS (',
unistr('    -- 1. MOVIMIENTOS CXC (F0911) L\00EDnea por l\00EDnea'),
'    SELECT',
'         TRIM(M.GLAID) AS NUMERO_CUENTA,',
'         B.BANCO AS NOMBRE_BANCO,',
'        ''REPORTE CONTABILIDAD'' AS ORIGEN,',
'        M.GLAA / 100 AS MONTO,',
unistr('        GLEXA AS EXPLICACI\00D3N,'),
'        NVL(TRIM(DECODE(SUBSTR(GLEXR,1,1),''0'',GLEXR , GLEXR )), GLEXA) AS COMPROBANTE',
'    FROM PRODDTA.F0911@jdedtadl M',
'    CROSS JOIN PARAMETROS P',
'    INNER JOIN BANCOS B ON M.GLAID = B.CUENTA_JOIN',
'    WHERE',
'        M.GLDCT IN (''RC'',''RO'',''J#'',''JE'',''JO'')',
'        AND M.GLRCND = '' ''',
'        AND M.GLAA > 0',
'        AND M.GLDGJ <= P.FECHA_JULIANA_LIMITE',
'        AND M.GLRE != ''V''',
'        AND M.GLLT = ''AA''',
'),',
'BANCO_MOV AS (',
unistr('    -- 2. MOVIMIENTOS BANCO (F5509505) L\00EDnea por l\00EDnea'),
'    SELECT',
'        TRIM(C.MPAID) AS NUMERO_CUENTA,',
'        B.BANCO AS NOMBRE_BANCO,',
'        ''BANCO'' AS ORIGEN,',
'        (C.MPAA) / 100 AS MONTO,',
unistr('        MPEXR AS EXPLICACI\00D3N,'),
'        MPCKNU AS COMPROBANTE',
'    FROM PRODDTA.F5509505@jdedtadl C',
'    CROSS JOIN PARAMETROS P',
'    INNER JOIN BANCOS B ON C.MPAID = B.CUENTA_JOIN',
'    WHERE',
'        C.MPDGJ <= P.FECHA_JULIANA_LIMITE',
'        AND C.MPAA > 0',
'        AND C.MPEV01 <> ''P''',
'        AND DECODE(C.MPEV01, '' '', ''1'') <> C.MPEV02',
'),',
'-- ==========================================',
unistr('-- 3. UNI\00D3N DE MOVIMIENTOS'),
'-- ==========================================',
'UNIFICADO AS (',
'    SELECT * FROM CONTA',
'    UNION ALL',
'    SELECT * FROM BANCO_MOV',
'),',
'-- ==========================================',
unistr('-- 4. C\00C1LCULO DE TOTALES POR CUENTA (Window Functions)'),
'-- ==========================================',
'CALCULO_TOTALES AS (',
'    SELECT',
'        U.*,',
'        -- Sumamos el monto solo si es de Contabilidad, particionando por cuenta y banco',
'        SUM(CASE WHEN ORIGEN = ''REPORTE CONTABILIDAD'' THEN MONTO ELSE 0 END)',
'            OVER (PARTITION BY NUMERO_CUENTA) AS TOTAL_CONTA,',
'        -- Sumamos el monto solo si es de Banco, particionando por cuenta y banco',
'        SUM(CASE WHEN ORIGEN = ''BANCO'' THEN MONTO ELSE 0 END)',
'            OVER (PARTITION BY NUMERO_CUENTA) AS TOTAL_BANCO',
'    FROM UNIFICADO U',
')',
'-- ==========================================',
unistr('-- 5. EXTRACCI\00D3N FINAL (Filtro de diferencias)'),
'-- ==========================================',
'SELECT',
'    NUMERO_CUENTA,',
'    NOMBRE_BANCO,',
'    ORIGEN,',
'    MONTO,',
unistr('    EXPLICACI\00D3N,'),
'    COMPROBANTE',
'FROM CALCULO_TOTALES',
'-- Filtramos donde el total de contabilidad sea diferente al del banco',
'WHERE ROUND(TOTAL_CONTA, 2) <> ROUND(TOTAL_BANCO, 2)',
'ORDER BY NUMERO_CUENTA, MONTO, ORIGEN DESC;'))
,p_plug_source_type=>'NATIVE_IR'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>11
,p_prn_height=>8.5
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(461959277607549071)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'TOP_AND_BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'MFERRIN'
,p_internal_uid=>461959277607549071
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(461959331998549072)
,p_db_column_name=>'NOMBRE_BANCO'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Nombre Banco'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(461959443117549073)
,p_db_column_name=>'MONTO'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Monto Total'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(461959582898549074)
,p_db_column_name=>'NUMERO_CUENTA'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Numero Cuenta'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(461959681982549075)
,p_db_column_name=>'ORIGEN'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Origen'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(461960430203549083)
,p_db_column_name=>unistr('EXPLICACI\00D3N')
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>unistr('Explicaci\00F3n')
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(461960601433549084)
,p_db_column_name=>'COMPROBANTE'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'Comprobante'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(461968007823563573)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'2170374'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>unistr('NOMBRE_BANCO:NUMERO_CUENTA:ORIGEN:COMPROBANTE:EXPLICACI\00D3N:MONTO:')
,p_sort_column_1=>'NOMBRE_BANCO'
,p_sort_direction_1=>'DESC'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(459857953227525375)
,p_plug_name=>'Impuestos'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(38289867500120143)
,p_plug_display_sequence=>160
,p_location=>null
,p_plug_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_plug_display_when_condition=>'P603_MODULO'
,p_plug_display_when_cond2=>'IMPURE'
,p_ai_enabled=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(459859006154525385)
,p_plug_name=>'PENDIENTES DE CXC'
,p_parent_plug_id=>wwv_flow_imp.id(459857953227525375)
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(112813843178917343)
,p_plug_display_sequence=>30
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT DISTINCT',
'    -- Datos del Lote (F0011)',
'    B.ICICU AS NUMERO_BATCH,',
'    B.ICICUT AS TIPO_BATCH,',
'    TO_DATE(TO_CHAR(1900000 + B.ICDICJ), ''YYYYDDD'') FECHA_BATCH,',
'',
'    -- Datos de la Cuenta por Cobrar (F03B11)',
'    RPDOC DOCUMENTO,',
'    CL.RPDCT AS TIPO_DOCUMENTO,',
'    CL.RPALPH AS CLIENTE,',
'    TO_DATE(TO_CHAR(1900000 + CL.RPDGJ), ''YYYYDDD'') FECHA_CONTABLE,',
'    CL.RPRMK AS OBSERVACION',
'',
'FROM',
'    PRODDTA.F0011@jdedtadl B',
'INNER JOIN',
'    PRODDTA.F03B11@jdedtadl CL',
'    ON CL.RPICUT = B.ICICUT AND CL.RPICU = B.ICICU',
'WHERE',
'    CL.RPPN = EXTRACT(MONTH FROM SYSDATE)',
'    AND CL.RPFY = TO_NUMBER(TO_CHAR(SYSDATE, ''YY''))',
'    AND B.ICIST != ''D'';',
''))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_display_condition_type=>'EXPRESSION'
,p_plug_display_when_condition=>':P603_ID_REGION = 2'
,p_plug_display_when_cond2=>'PLSQL'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>11
,p_prn_height=>8.5
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(459859037475525386)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'TOP_AND_BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'MFERRIN'
,p_internal_uid=>459859037475525386
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(459860309306525398)
,p_db_column_name=>'TIPO_DOCUMENTO'
,p_display_order=>60
,p_column_identifier=>'E'
,p_column_label=>'Tipo Documento'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(459860513402525400)
,p_db_column_name=>'CLIENTE'
,p_display_order=>80
,p_column_identifier=>'G'
,p_column_label=>'Cliente'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(459860687022525402)
,p_db_column_name=>'OBSERVACION'
,p_display_order=>100
,p_column_identifier=>'H'
,p_column_label=>'Observacion'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(459860873827525404)
,p_db_column_name=>'FECHA_CONTABLE'
,p_display_order=>120
,p_column_identifier=>'J'
,p_column_label=>'Fecha Contable'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(459860947355525405)
,p_db_column_name=>'DOCUMENTO'
,p_display_order=>130
,p_column_identifier=>'K'
,p_column_label=>'Documento'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(461959873190549077)
,p_db_column_name=>'NUMERO_BATCH'
,p_display_order=>140
,p_column_identifier=>'Q'
,p_column_label=>'Numero Batch'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(461959989586549078)
,p_db_column_name=>'TIPO_BATCH'
,p_display_order=>150
,p_column_identifier=>'R'
,p_column_label=>'Tipo Batch'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(461960066643549079)
,p_db_column_name=>'FECHA_BATCH'
,p_display_order=>160
,p_column_identifier=>'S'
,p_column_label=>'Fecha Batch'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(461164703417563504)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'2162341'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'TIPO_BATCH:NUMERO_BATCH:FECHA_BATCH:DOCUMENTO:TIPO_DOCUMENTO:CLIENTE:OBSERVACION:FECHA_CONTABLE:'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(459861343691525409)
,p_plug_name=>'PENDIENTES DE CXP'
,p_parent_plug_id=>wwv_flow_imp.id(459857953227525375)
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(112813843178917343)
,p_plug_display_sequence=>40
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT DISTINCT',
'    -- Datos del Lote (F0011)',
'    B.ICICU AS NUMERO_BATCH,',
'    B.ICICUT AS TIPO_BATCH,',
'    TO_DATE(TO_CHAR(1900000 + B.ICDICJ), ''YYYYDDD'') FECHA_BATCH,',
'    ',
'    -- Datos de la Cuenta por Cobrar (F03B11)',
'    CL.RPDOC DOCUMENTO,',
'    CL.RPDCT AS TIPO_DOCUMENTO,',
'    --CL.RPAN8 AS NUMERO_CLIENTE,',
'    CI.ABALPH AS CLIENTE,',
'    TO_DATE(TO_CHAR(1900000 + CL.RPDGJ), ''YYYYDDD'') FECHA_CONTABLE,',
'    CL.RPRMK AS OBSERVACION',
'',
'FROM',
'    PRODDTA.F0011@jdedtadl B',
'INNER JOIN',
'    PRODDTA.F0411@jdedtadl CL',
'    ON CL.RPICUT = B.ICICUT AND CL.RPICU = B.ICICU',
'INNER JOIN',
'    PRODDTA.F0101@jdedtadl CI ON CI.ABAN8 = CL.RPAN8',
'WHERE',
'    CL.RPPN = EXTRACT(MONTH FROM SYSDATE)',
'    AND CL.RPFY = TO_NUMBER(TO_CHAR(SYSDATE, ''YY''))',
'    AND B.ICIST != ''D'';',
''))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_display_condition_type=>'EXPRESSION'
,p_plug_display_when_condition=>':P603_ID_REGION = 3'
,p_plug_display_when_cond2=>'PLSQL'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>11
,p_prn_height=>8.5
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(459861471827525410)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'TOP_AND_BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'MFERRIN'
,p_internal_uid=>459861471827525410
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(461369797449854961)
,p_db_column_name=>'TIPO_DOCUMENTO'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Tipo Documento'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(461369837977854962)
,p_db_column_name=>'CLIENTE'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Cliente'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(461370007223854963)
,p_db_column_name=>'OBSERVACION'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Observacion'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(461370078484854964)
,p_db_column_name=>'FECHA_CONTABLE'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Fecha Contable'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(461370191694854965)
,p_db_column_name=>'DOCUMENTO'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Documento'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(461960137360549080)
,p_db_column_name=>'NUMERO_BATCH'
,p_display_order=>60
,p_column_identifier=>'I'
,p_column_label=>'Numero Batch'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(461960275576549081)
,p_db_column_name=>'TIPO_BATCH'
,p_display_order=>70
,p_column_identifier=>'J'
,p_column_label=>'Tipo Batch'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(461960353191549082)
,p_db_column_name=>'FECHA_BATCH'
,p_display_order=>80
,p_column_identifier=>'K'
,p_column_label=>'Fecha Batch'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(461378003039858143)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'2164474'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'TIPO_BATCH:NUMERO_BATCH:FECHA_BATCH:DOCUMENTO:TIPO_DOCUMENTO:CLIENTE:OBSERVACION:FECHA_CONTABLE:'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(461370611181854969)
,p_plug_name=>unistr('\00D3RDENES DE EXPORTACIONES QUE NO HAN SIDO INGRESADA SU INFORMACI\00D3N ADUANERA')
,p_parent_plug_id=>wwv_flow_imp.id(459857953227525375)
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(112813843178917343)
,p_plug_display_sequence=>80
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT DISTINCT',
'    -- Datos de la Cuenta por Cobrar (F03B11)',
'    CL.RPDOC DOCUMENTO,',
'    CL.RPDCT AS TIPO_DOCUMENTO,',
'    --CL.RPAN8 AS NUMERO_CLIENTE,',
'    CL.RPALPH AS CLIENTE,',
'    TO_DATE(TO_CHAR(1900000 + CL.RPDGJ), ''YYYYDDD'') FECHA_CONTABLE,',
'    CL.RPRMK AS OBSERVACION',
'FROM',
'    PRODDTA.F03B11@jdedtadl CL',
'WHERE',
'    CL.RPPN = EXTRACT(MONTH FROM SYSDATE)',
'    AND CL.RPFY = TO_NUMBER(TO_CHAR(SYSDATE, ''YY''))',
'    AND RPDCT=''FE''',
'AND NOT EXISTS (',
'    SELECT 1',
'    FROM PRODDTA.F76E0003@jdedtadl RC',
'    WHERE RC.IADOC = CL.RPDOC',
'      AND RC.IADCT = CL.RPDCT',
'      AND RC.IAAN8 = CL.RPAN8',
')'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_display_condition_type=>'EXPRESSION'
,p_plug_display_when_condition=>':P603_ID_REGION = 7'
,p_plug_display_when_cond2=>'PLSQL'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>11
,p_prn_height=>8.5
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(461370720673854970)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'TOP_AND_BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'MFERRIN'
,p_internal_uid=>461370720673854970
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(461370812472854971)
,p_db_column_name=>'TIPO_DOCUMENTO'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Tipo Documento'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(461370843052854972)
,p_db_column_name=>'CLIENTE'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Cliente'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(461370969638854973)
,p_db_column_name=>'OBSERVACION'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Observacion'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(461371027592854974)
,p_db_column_name=>'FECHA_CONTABLE'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Fecha Contable'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(461371193472854975)
,p_db_column_name=>'DOCUMENTO'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Documento'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(461401285198920888)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'2164707'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'DOCUMENTO:TIPO_DOCUMENTO:CLIENTE:OBSERVACION:FECHA_CONTABLE:'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(461372794037854991)
,p_plug_name=>unistr('RETENCIONES DE CXP QUE NO EST\00C9N AUTORIZADAS')
,p_parent_plug_id=>wwv_flow_imp.id(459857953227525375)
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(112813843178917343)
,p_plug_display_sequence=>60
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ID',
'    , ESTADO',
'	, ORDEN AS "TO"',
'	, NUM_ORDEN',
'    , TIPO_DOCUMENTO AS "TD"',
'    , NUMERO_DOCUMENTO',
'    , CLIENTE_PROVEEDOR',
'    , FECHA_FACTURA FECHA_EMISION',
'	, CLAVEACCESO',
' FROM DATA.VT_FINZ_MESADOCUMETOELECTRONICO',
'WHERE ORDEN = ''PV'' AND TIPO_DOCUMENTO = ''UR'' AND ESTADO <> ''APROBADO'''))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_display_condition_type=>'EXPRESSION'
,p_plug_display_when_condition=>':P603_ID_REGION = 5'
,p_plug_display_when_cond2=>'PLSQL'
,p_ai_enabled=>false
,p_updated_on=>wwv_flow_imp.dz('20260514142615Z')
,p_updated_by=>'JBALCAZAR'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(461372883280854992)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'TOP_AND_BOTTOM_RIGHT'
,p_report_list_mode=>'NONE'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'MFERRIN'
,p_internal_uid=>461372883280854992
,p_updated_on=>wwv_flow_imp.dz('20260514142615Z')
,p_updated_by=>'JBALCAZAR'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(461373011739854993)
,p_db_column_name=>'ID'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Id'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(461373076418854994)
,p_db_column_name=>'ESTADO'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Estado'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(461373135858854995)
,p_db_column_name=>'NUM_ORDEN'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Num Orden'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(461373228320854996)
,p_db_column_name=>'NUMERO_DOCUMENTO'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Numero Documento'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(461373377531854997)
,p_db_column_name=>'CLIENTE_PROVEEDOR'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Cliente Proveedor'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(461373511137854998)
,p_db_column_name=>'FECHA_EMISION'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'Fecha Emision'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(461373532946854999)
,p_db_column_name=>'CLAVEACCESO'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>'Claveacceso'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(461373701123855000)
,p_db_column_name=>'TO'
,p_display_order=>80
,p_column_identifier=>'H'
,p_column_label=>'To'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(461373748053855001)
,p_db_column_name=>'TD'
,p_display_order=>90
,p_column_identifier=>'I'
,p_column_label=>'Td'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(461450642367047094)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'2165201'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'ID:TO:ESTADO:NUM_ORDEN:TD:NUMERO_DOCUMENTO:CLIENTE_PROVEEDOR:FECHA_EMISION:CLAVEACCESO:'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(461373840392855002)
,p_plug_name=>unistr('RETENCIONES DE CXC QUE NO HAN SIDO GENERADAS EN M\00D3DULO')
,p_parent_plug_id=>wwv_flow_imp.id(459857953227525375)
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(37806762584106520)
,p_plug_display_sequence=>70
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT M.RPDOC FACTURA, C.ABALPH AS RAZON_SOCIAL, SUM(M.RPAAP)/100 VALOR,',
'       TO_DATE(TO_CHAR(1900000 + M.RPDGJ), ''YYYYDDD'') FECHA,(TO_DATE(TO_CHAR(1900000 + M.RPDGJ), ''YYYYDDD'') + 5) FECHA_APROX_RETENC,',
'       CASE M.RPPN ',
unistr('       WHEN EXTRACT(MONTH FROM SYSDATE) THEN ''FACTURA MES ACTUAL, SE DEBE EMITIR RETENCI\00D3N'' '),
unistr('       ELSE ''FACTURA MES ANTERIOR, SE DEBE ANULAR LA FACTURA Y EMITIR RETENCI\00D3N'' END ALERTA,'),
'       CASE WHEN TRIM(M.RPRMR1) IS NULL THEN ''NO'' ELSE ''SI'' END SIG_MES',
'FROM PRODDTA.F03B11@jdedtadl M',
'INNER JOIN PRODDTA.F03012@jdedtadl CB ON CB.AIAN8 = M.RPAN8',
'INNER JOIN PRODDTA.F0101@jdedtadl C ON C.ABAN8 = M.RPAN8',
'INNER JOIN DATA.VT_JDE_CLIENTE VC ON VC.CODIGO = M.RPAN8',
'WHERE M.RPDCT IN (''FN'',''FD'') AND M.RPFY = TO_NUMBER(TO_CHAR(SYSDATE, ''YY''))',
'AND M.RPSTAM <> 0',
'AND CB.AICO = ''00001''',
'AND CB.AIAC21 IN (''001'',''002'',''003'')',
'AND NOT EXISTS(',
'    SELECT 1',
'    FROM PRODDTA.F03B14@jdedtadl D',
'    WHERE D.RZAN8 = M.RPAN8',
'      AND D.RZDOC = M.RPDOC',
'      AND D.RZKCO = M.RPKCO',
'      AND D.RZDCT = M.RPDCT',
'      AND D.RZFY = M.RPFY',
'      AND D.RZRSCO  = ''VT''',
')',
'GROUP BY ',
'    M.RPDOC, ',
'    C.ABALPH, ',
'    M.RPDGJ, ',
'    M.RPPN, ',
'    M.RPRMR1, ',
'    M.RPAN8, ',
'    M.RPDCT;'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_display_condition_type=>'EXPRESSION'
,p_plug_display_when_condition=>':P603_ID_REGION = 6'
,p_plug_display_when_cond2=>'PLSQL'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
,p_ai_enabled=>false
,p_updated_on=>wwv_flow_imp.dz('20260421175320Z')
,p_updated_by=>'JBALCAZAR'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(461463680561089363)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'TOP_AND_BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'MFERRIN'
,p_internal_uid=>461463680561089363
,p_updated_on=>wwv_flow_imp.dz('20260421175320Z')
,p_updated_by=>'JBALCAZAR'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(461463769925089364)
,p_db_column_name=>'FACTURA'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Factura'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(461463866154089365)
,p_db_column_name=>'RAZON_SOCIAL'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Razon Social'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(461464010409089366)
,p_db_column_name=>'VALOR'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Valor'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(461464115908089367)
,p_db_column_name=>'FECHA'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Fecha'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(461464188532089368)
,p_db_column_name=>'FECHA_APROX_RETENC'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Fecha Aprox Retenc'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(461464281091089369)
,p_db_column_name=>'ALERTA'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'Alerta'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(461464650980089373)
,p_db_column_name=>'SIG_MES'
,p_display_order=>70
,p_column_identifier=>'J'
,p_column_label=>'Sig Mes'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(461472466957091002)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'2165419'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'FACTURA:RAZON_SOCIAL:VALOR:FECHA:FECHA_APROX_RETENC:ALERTA'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(461466187021089388)
,p_plug_name=>unistr('NOTAS DE CR\00C9DITO QUE NO SE HAN CRUZADO CON FACTURAS')
,p_parent_plug_id=>wwv_flow_imp.id(459857953227525375)
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(37806762584106520)
,p_plug_display_sequence=>50
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT M.RPDOC FACTURA, C.ABALPH AS RAZON_SOCIAL, SUM(M.RPAAP)/100 VALOR,',
'       TO_DATE(TO_CHAR(1900000 + M.RPDGJ), ''YYYYDDD'') FECHA,(TO_DATE(TO_CHAR(1900000 + M.RPDGJ), ''YYYYDDD'') + 5) FECHA_APROX_RETENC,',
'       CASE M.RPPN ',
unistr('       WHEN EXTRACT(MONTH FROM SYSDATE) THEN ''FACTURA MES ACTUAL, SE DEBE EMITIR RETENCI\00D3N'' '),
unistr('       ELSE ''FACTURA MES ANTERIOR, SE DEBE ANULAR LA FACTURA Y EMITIR RETENCI\00D3N'' END ALERTA,'),
'        M.RPRMR1, M.RPAN8 NUMERO_CLIENTE, M.RPDCT',
'FROM PRODDTA.F03B11@jdedtadl M',
'INNER JOIN PRODDTA.F03012@jdedtadl CB ON CB.AIAN8 = M.RPAN8',
'INNER JOIN PRODDTA.F0101@jdedtadl C ON C.ABAN8 = M.RPAN8',
'INNER JOIN DATA.VT_JDE_CLIENTE VC ON VC.CODIGO = M.RPAN8',
'WHERE M.RPDCT = ''D1'' AND M.RPFY = TO_NUMBER(TO_CHAR(SYSDATE, ''YY''))--d1, con open amountmenor a 0 ,',
'AND CB.AICO = ''00001''',
'AND CB.AIAC21 IN (''001'',''002'',''003'')',
'AND M.RPAAP < 0',
'GROUP BY ',
'    M.RPDOC, ',
'    C.ABALPH, ',
'    M.RPDGJ, ',
'    M.RPPN, ',
'    M.RPRMR1, ',
'    M.RPAN8, ',
'    M.RPDCT;'))
,p_plug_source_type=>'NATIVE_IG'
,p_plug_display_condition_type=>'EXPRESSION'
,p_plug_display_when_condition=>':P603_ID_REGION = 4'
,p_plug_display_when_cond2=>'PLSQL'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(461466502229089391)
,p_name=>'FACTURA'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'FACTURA'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>true
,p_item_type=>'NATIVE_NUMBER_FIELD'
,p_heading=>'Factura'
,p_heading_alignment=>'RIGHT'
,p_display_sequence=>20
,p_value_alignment=>'RIGHT'
,p_attribute_03=>'left'
,p_attribute_04=>'decimal'
,p_is_required=>true
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>true
,p_include_in_export=>true
,p_readonly_condition_type=>'ALWAYS'
,p_readonly_for_each_row=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(461466590195089392)
,p_name=>'RAZON_SOCIAL'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'RAZON_SOCIAL'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>true
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>'Razon Social'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>30
,p_value_alignment=>'LEFT'
,p_attribute_05=>'BOTH'
,p_is_required=>false
,p_max_length=>40
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_include_in_export=>true
,p_readonly_condition_type=>'ALWAYS'
,p_readonly_for_each_row=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(461466686330089393)
,p_name=>'VALOR'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'VALOR'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>true
,p_item_type=>'NATIVE_NUMBER_FIELD'
,p_heading=>'Valor'
,p_heading_alignment=>'RIGHT'
,p_display_sequence=>40
,p_value_alignment=>'RIGHT'
,p_attribute_03=>'left'
,p_attribute_04=>'decimal'
,p_is_required=>false
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_include_in_export=>true
,p_readonly_condition_type=>'ALWAYS'
,p_readonly_for_each_row=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(461466760670089394)
,p_name=>'FECHA'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'FECHA'
,p_data_type=>'DATE'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>true
,p_item_type=>'NATIVE_DATE_PICKER_APEX'
,p_heading=>'Fecha'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>50
,p_value_alignment=>'LEFT'
,p_attribute_01=>'N'
,p_attribute_02=>'POPUP'
,p_attribute_03=>'NONE'
,p_attribute_06=>'NONE'
,p_attribute_09=>'N'
,p_attribute_11=>'Y'
,p_is_required=>false
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_date_ranges=>'ALL'
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_include_in_export=>true
,p_readonly_condition_type=>'ALWAYS'
,p_readonly_for_each_row=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(461466888756089395)
,p_name=>'FECHA_APROX_RETENC'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'FECHA_APROX_RETENC'
,p_data_type=>'DATE'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>true
,p_item_type=>'NATIVE_DATE_PICKER_APEX'
,p_heading=>'Fecha Aprox Retenc'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>60
,p_value_alignment=>'LEFT'
,p_attribute_01=>'N'
,p_attribute_02=>'POPUP'
,p_attribute_03=>'NONE'
,p_attribute_06=>'NONE'
,p_attribute_09=>'N'
,p_attribute_11=>'Y'
,p_is_required=>false
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_date_ranges=>'ALL'
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_include_in_export=>true
,p_readonly_condition_type=>'ALWAYS'
,p_readonly_for_each_row=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(461466995054089396)
,p_name=>'ALERTA'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'ALERTA'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>true
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>'Alerta'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>70
,p_value_alignment=>'LEFT'
,p_attribute_05=>'BOTH'
,p_is_required=>false
,p_max_length=>128
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_include_in_export=>true
,p_readonly_condition_type=>'ALWAYS'
,p_readonly_for_each_row=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(461467111472089397)
,p_name=>'SIG_MES'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'RPRMR1'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_SINGLE_CHECKBOX'
,p_heading=>'Sig Mes'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>80
,p_value_alignment=>'LEFT'
,p_attribute_01=>'N'
,p_attribute_02=>'1'
,p_is_required=>false
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(461467178979089398)
,p_name=>'NUMERO_CLIENTE'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'NUMERO_CLIENTE'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_NUMBER_FIELD'
,p_heading=>'Numero Cliente'
,p_heading_alignment=>'RIGHT'
,p_display_sequence=>90
,p_value_alignment=>'RIGHT'
,p_attribute_03=>'left'
,p_attribute_04=>'decimal'
,p_is_required=>false
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
,p_readonly_condition_type=>'ALWAYS'
,p_readonly_for_each_row=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(461467296773089399)
,p_name=>'RPDCT'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'RPDCT'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>'Rpdct'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>100
,p_value_alignment=>'LEFT'
,p_attribute_05=>'BOTH'
,p_is_required=>true
,p_max_length=>2
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
,p_readonly_condition_type=>'ALWAYS'
,p_readonly_for_each_row=>false
);
wwv_flow_imp_page.create_interactive_grid(
 p_id=>wwv_flow_imp.id(461466230561089389)
,p_internal_uid=>461466230561089389
,p_is_editable=>true
,p_edit_operations=>'u'
,p_lost_update_check_type=>'VALUES'
,p_submit_checked_rows=>false
,p_lazy_loading=>false
,p_requires_filter=>false
,p_select_first_row=>false
,p_fixed_row_height=>false
,p_pagination_type=>'SET'
,p_show_total_row_count=>true
,p_show_toolbar=>true
,p_enable_save_public_report=>false
,p_enable_subscriptions=>true
,p_enable_flashback=>true
,p_define_chart_view=>true
,p_enable_download=>true
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>true
,p_fixed_header=>'PAGE'
,p_show_icon_view=>false
,p_show_detail_view=>false
);
wwv_flow_imp_page.create_ig_report(
 p_id=>wwv_flow_imp.id(461569762160437250)
,p_interactive_grid_id=>wwv_flow_imp.id(461466230561089389)
,p_static_id=>'2166392'
,p_type=>'PRIMARY'
,p_default_view=>'GRID'
,p_show_row_number=>false
,p_settings_area_expanded=>true
);
wwv_flow_imp_page.create_ig_report_view(
 p_id=>wwv_flow_imp.id(461569949734437256)
,p_report_id=>wwv_flow_imp.id(461569762160437250)
,p_view_type=>'GRID'
,p_stretch_columns=>true
,p_srv_exclude_null_values=>false
,p_srv_only_display_columns=>true
,p_edit_mode=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(461570886529437268)
,p_view_id=>wwv_flow_imp.id(461569949734437256)
,p_display_seq=>1
,p_column_id=>wwv_flow_imp.id(461466502229089391)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(461571764884437278)
,p_view_id=>wwv_flow_imp.id(461569949734437256)
,p_display_seq=>2
,p_column_id=>wwv_flow_imp.id(461466590195089392)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(461572656835437282)
,p_view_id=>wwv_flow_imp.id(461569949734437256)
,p_display_seq=>3
,p_column_id=>wwv_flow_imp.id(461466686330089393)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(461573524918437286)
,p_view_id=>wwv_flow_imp.id(461569949734437256)
,p_display_seq=>4
,p_column_id=>wwv_flow_imp.id(461466760670089394)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(461574425391437290)
,p_view_id=>wwv_flow_imp.id(461569949734437256)
,p_display_seq=>5
,p_column_id=>wwv_flow_imp.id(461466888756089395)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(461575355831437294)
,p_view_id=>wwv_flow_imp.id(461569949734437256)
,p_display_seq=>6
,p_column_id=>wwv_flow_imp.id(461466995054089396)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(461576247178437298)
,p_view_id=>wwv_flow_imp.id(461569949734437256)
,p_display_seq=>7
,p_column_id=>wwv_flow_imp.id(461467111472089397)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(461577152729437302)
,p_view_id=>wwv_flow_imp.id(461569949734437256)
,p_display_seq=>8
,p_column_id=>wwv_flow_imp.id(461467178979089398)
,p_is_visible=>false
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(461578066377437306)
,p_view_id=>wwv_flow_imp.id(461569949734437256)
,p_display_seq=>9
,p_column_id=>wwv_flow_imp.id(461467296773089399)
,p_is_visible=>false
,p_is_frozen=>false
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(461961997140549098)
,p_plug_name=>'CXC CRUZADA CON EL ESTADO DEL SRI'
,p_parent_plug_id=>wwv_flow_imp.id(459857953227525375)
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(112813843178917343)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'with tob as (SELECT id_tabla tob_id, descripcion tob_descripcion',
'             FROM DATA.T_CORP_UDC',
'             WHERE activo = ''1''',
'               and id_cabecera = ''FINZ_GT02''',
'               AND id_tabla >= ''900'')',
'   , tpr as (SELECT id_tabla tpr_id, descripcion tpr_descripcion',
'             FROM DATA.T_CORP_UDC',
'             WHERE activo = ''1''',
'               and id_cabecera = ''FINZ_GT01''',
'               AND id_tabla != ''000''',
'               and id_tabla = ''001'')',
'   , base as (select case',
'                         when dat.estado = ''3'' then datosfin',
'                         else',
'                             case when datosmod is null then datosini else datosmod end',
'                         end',
'                         datosjson',
'              from DATA.t_finz_gestiontributariadet det',
'                       inner join DATA.t_finz_gestiontributariadatos dat on det.id = dat.iddet',
'                       inner join DATA.t_finz_gestiontributariacfg cfg on cfg.id = dat.idcfg',
'                       INNER JOIN DATA.t_finz_gestiontributaria gtb on to_char(gtb.id) = to_char(det.idgtb)',
'                       INNER JOIN tob ON tob_id = cfg.tipoobjeto',
'                       INNER JOIN tpr ON tpr_id = cfg.idproceso',
'              WHERE 1 = 1',
'                and det.idgtb = (SELECT max(id) FROM DATA.T_FINZ_GESTIONTRIBUTARIA where compania = ''00001'')',
'                and cfg.estado = 1',
'                and trim(tob_descripcion) != ''RESULTADOS ATS XML''',
'                and datosmod is not null)',
'',
'SELECT jt.comprobante,',
'       jt.documento_jde,',
'       jt.tipo_documento_jde,',
'       jt.documento,',
'       jt.tipodocumento,',
'       jt.codigo_emisor,',
'       jt.ruc_emisor,',
'       jt.razon_social_emisor,',
'       jt.fechaemision,',
'       jt.num_doc_modificado,',
'       jt.total_jde,',
'       jt.total_rec,',
'       jt.total_sri,',
'       jt.dif_jdesri,',
'       jt.comentario',
'FROM base b,',
'     JSON_TABLE(',
'             b.datosjson,',
'             ''$[*]''',
'             COLUMNS (',
'                 id NUMBER PATH ''$.ID'',',
'                 idpadre NUMBER PATH ''$.IDPADRE'',',
'                 comprobante VARCHAR2(50) PATH ''$.COMPROBANTE'',',
'                 documento_jde VARCHAR2(50) PATH ''$.DOCUMENTO_JDE'',',
'                 tipo_documento_jde VARCHAR2(10) PATH ''$.TIPO_DOCUMENTO_JDE'',',
'                 documento VARCHAR2(50) PATH ''$.DOCUMENTO'',',
'                 tipodocumento VARCHAR2(5) PATH ''$.TIPODOCUMENTO'',',
'                 codigo_emisor VARCHAR2(20) PATH ''$.CODIGO_EMISOR'',',
'                 ruc_emisor VARCHAR2(20) PATH ''$.RUC_EMISOR'',',
'                 razon_social_emisor VARCHAR2(200) PATH ''$.RAZON_SOCIAL_EMISOR'',',
'                 fechaemision TIMESTAMP PATH ''$.FECHAEMISION'',',
'                 num_doc_modificado VARCHAR2(50) PATH ''$.NUMERO_DOCUMENTO_MODIFICADO'',',
'                 total_jde NUMBER(15, 2) PATH ''$.TOTALJDE'',',
'                 total_rec NUMBER(15, 2) PATH ''$.TOTALREC'',',
'                 total_sri NUMBER(15, 2) PATH ''$.TOTALSRI'',',
'                 dif_jdesri NUMBER(15, 2) PATH ''$.DIF_JDESRI'',',
'                 comentario VARCHAR2(500) PATH ''$.COMENTARIO'',',
'                 validaciones VARCHAR2(500) PATH ''$.VALIDACIONES''',
'                 )',
'     ) jt',
'where validaciones is not null',
''))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_display_condition_type=>'EXPRESSION'
,p_plug_display_when_condition=>':P603_ID_REGION = 1'
,p_plug_display_when_cond2=>'PLSQL'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>11
,p_prn_height=>8.5
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(461962113807549099)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'TOP_AND_BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'MFERRIN'
,p_internal_uid=>461962113807549099
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(461962924024549108)
,p_db_column_name=>'COMPROBANTE'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Comprobante'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(461963122595549109)
,p_db_column_name=>'DOCUMENTO_JDE'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Documento Jde'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(461963161651549110)
,p_db_column_name=>'TIPO_DOCUMENTO_JDE'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Tipo Documento Jde'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(467375479109480361)
,p_db_column_name=>'DOCUMENTO'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Documento'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(467375545271480362)
,p_db_column_name=>'TIPODOCUMENTO'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Tipodocumento'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(467375721391480363)
,p_db_column_name=>'CODIGO_EMISOR'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'Codigo Emisor'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(467375789874480364)
,p_db_column_name=>'RUC_EMISOR'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>'Ruc Emisor'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(467375850365480365)
,p_db_column_name=>'RAZON_SOCIAL_EMISOR'
,p_display_order=>80
,p_column_identifier=>'H'
,p_column_label=>'Razon Social Emisor'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(467375951402480366)
,p_db_column_name=>'FECHAEMISION'
,p_display_order=>90
,p_column_identifier=>'I'
,p_column_label=>'Fechaemision'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(467376111672480367)
,p_db_column_name=>'NUM_DOC_MODIFICADO'
,p_display_order=>100
,p_column_identifier=>'J'
,p_column_label=>'Num Doc Modificado'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(467376180923480368)
,p_db_column_name=>'TOTAL_JDE'
,p_display_order=>110
,p_column_identifier=>'K'
,p_column_label=>'Total Jde'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(467376312493480369)
,p_db_column_name=>'TOTAL_REC'
,p_display_order=>120
,p_column_identifier=>'L'
,p_column_label=>'Total Rec'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(467376385371480370)
,p_db_column_name=>'TOTAL_SRI'
,p_display_order=>130
,p_column_identifier=>'M'
,p_column_label=>'Total Sri'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(467376478132480371)
,p_db_column_name=>'DIF_JDESRI'
,p_display_order=>140
,p_column_identifier=>'N'
,p_column_label=>'Dif Jdesri'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(467376617682480372)
,p_db_column_name=>'COMENTARIO'
,p_display_order=>150
,p_column_identifier=>'O'
,p_column_label=>'Comentario'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(467391591229490011)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'2224610'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'COMPROBANTE:DOCUMENTO_JDE:TIPO_DOCUMENTO_JDE:DOCUMENTO:TIPODOCUMENTO:CODIGO_EMISOR:RUC_EMISOR:RAZON_SOCIAL_EMISOR:FECHAEMISION:NUM_DOC_MODIFICADO:TOTAL_JDE:TOTAL_REC:TOTAL_SRI:DIF_JDESRI:COMENTARIO'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(478616551125069403)
,p_plug_name=>unistr('Producci\00F3n')
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(38289867500120143)
,p_plug_display_sequence=>40
,p_location=>null
,p_plug_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_plug_display_when_condition=>'P603_PRODUCTIVA'
,p_plug_display_when_cond2=>'1'
,p_ai_enabled=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(369552918840034105)
,p_plug_name=>unistr('CIERRE DE PRODUCCI\00D3N VS DOCUMENTO')
,p_parent_plug_id=>wwv_flow_imp.id(478616551125069403)
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(112813843178917343)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
unistr('SELECT c001 Maquina, c002 "Fec.Orden", c003 Tipo, c004 Orden, c005 Producto, c006 "Descripci\00F3n", '),
'--n001 Bodega, ',
unistr('n002 "Impor Sta", n003 "Contabilizado", n004 "Variaci\00F3n"'),
'FROM APEX_collections',
'WHERE collection_name = ''FINZ_PRODUCCION_CIERRE_''||TRIM(:P603_BDG_PRODUCTIVA)',
'--AND n001 = TO_NUMBER(TRIM(:P603_BDG_PRODUCTIVA))'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_display_condition_type=>'EXPRESSION'
,p_plug_display_when_condition=>':P603_ID_REGION = 1'
,p_plug_display_when_cond2=>'PLSQL'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
,p_ai_enabled=>false
,p_updated_on=>wwv_flow_imp.dz('20260506035700Z')
,p_updated_by=>'JBALCAZAR'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(369553007643034106)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'MFERRIN'
,p_internal_uid=>369553007643034106
,p_updated_on=>wwv_flow_imp.dz('20260506032151Z')
,p_updated_by=>'JBALCAZAR'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(369553091031034107)
,p_db_column_name=>'MAQUINA'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Maquina'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(369553129043034108)
,p_db_column_name=>'Fec.Orden'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Fec.orden'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(369553228358034109)
,p_db_column_name=>'TIPO'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Tipo'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(369553382430034110)
,p_db_column_name=>'ORDEN'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Orden'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(427193365935293761)
,p_db_column_name=>'PRODUCTO'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Producto'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(427193470553293762)
,p_db_column_name=>unistr('Descripci\00F3n')
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>unistr('Descripci\00F3n')
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(427193813066293765)
,p_db_column_name=>'Impor Sta'
,p_display_order=>90
,p_column_identifier=>'I'
,p_column_label=>'Impor Sta'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(427193892729293766)
,p_db_column_name=>unistr('Variaci\00F3n')
,p_display_order=>100
,p_column_identifier=>'J'
,p_column_label=>unistr('Variaci\00F3n')
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(427570085603254690)
,p_db_column_name=>'Contabilizado'
,p_display_order=>110
,p_column_identifier=>'L'
,p_column_label=>'Contabilizado'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(427206311630296330)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'1822757'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>unistr('MAQUINA:Fec.Orden:TIPO:ORDEN:PRODUCTO:Descripci\00F3n:Impor Sta:Contabilizado:Variaci\00F3n')
,p_sort_column_1=>'MAQUINA'
,p_sort_direction_1=>'ASC'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(426792882540244507)
,p_plug_name=>unistr('Etiquetas que no est\00E1n descargadas correctamente')
,p_parent_plug_id=>wwv_flow_imp.id(478616551125069403)
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(112813843178917343)
,p_plug_display_sequence=>40
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT * FROM ',
'(',
'WITH CONSTANTES AS (',
'    SELECT',
'        TO_NUMBER(TO_CHAR(TRUNC(SYSDATE)-5,''YYYYDDD'')) - 1900000 FEC_INI_DOCS,',
'        TRUNC(SYSDATE)-1 AYER,',
'        LPAD(:P603_BDG_PRODUCTIVA,12) BODEGA,',
'        LPAD(''17003'',12) BODEGA_PT',
'    FROM dual',
'),',
'B_PT AS (',
'    SELECT',
'        ILTREX,',
'        ILDOC,',
'        ILKCO',
'    FROM proddta.F4111@jdedtadl',
'    CROSS JOIN CONSTANTES f',
'    WHERE ILDCT = ''IT''',
'      AND ILTRDJ >= f.FEC_INI_DOCS',
'      AND ILMCU = f.BODEGA_PT',
'    GROUP BY ILTREX, ILDOC, ILKCO',
'),',
'B_PP AS (',
'    SELECT',
'        ILTREX,',
'        ILDOC,',
'        ILKCO',
'    FROM proddta.F4111@jdedtadl',
'    CROSS JOIN CONSTANTES f',
'    WHERE ILDCT = ''IT''',
'      AND ILTRDJ >= f.FEC_INI_DOCS',
'      AND ILMCU = f.BODEGA',
'    GROUP BY ILTREX, ILDOC, ILKCO',
'),',
'D_ADAIA AS (',
'    SELECT',
'        DATTXT AS BODEGA,',
'        RPAD(''ETIQUETA:'' || TRIM(A.cntdorref),30) AS ETIQUETA',
'    FROM ADAIA.cntdor A',
'    JOIN ADAIA.CNTNDO B ON A.CNTCOD = B.CNTCOD',
'    JOIN ADAIA.ART C ON B.ARTCOD = C.ARTCOD',
'    JOIN ADAIA.DATPRV D',
'         ON D.DATKEY = A.CNTCOD',
'        AND TRIM(DATTIP) = ''TRUO''',
'    CROSS JOIN CONSTANTES f',
'    WHERE A.cntdorref LIKE ''275%''',
'      AND A.cntsit = ''OK''',
'      AND MOMCRE >= f.AYER',
'      AND DATTXT = f.BODEGA',
')',
'SELECT B.ILDOC AS DOCUMENTO, B.ILKCO AS COMPANIA, A.BODEGA AS BODEGA_ORIGEN, A.ETIQUETA,',
'CASE WHEN C.ILTREX IS NOT NULL THEN ''SI'' ELSE ''NO'' END AS ADAIA_EN_17005,',
'CASE WHEN B.ILTREX IS NOT NULL THEN ''SI'' ELSE ''NO'' END AS ADAIA_EN_17003,',
'CASE WHEN C.ILTREX IS NOT NULL AND B.ILTREX IS NOT NULL THEN ''SI'' ELSE ''NO'' END AS EN_AMBAS_BODEGAS,',
'CASE WHEN B.ILTREX IS NOT NULL AND C.ILTREX IS NULL THEN ''SI'' ELSE ''NO'' END AS SI_17003_NO_EN_17005',
'FROM D_ADAIA A',
'LEFT JOIN B_PT B ON B.ILTREX = A.ETIQUETA',
'LEFT JOIN B_PP C ON A.ETIQUETA = C.ILTREX',
')',
'WHERE ',
'ADAIA_EN_17005 = ''NO'' ',
'OR ADAIA_EN_17003 = ''NO'' ',
'--OR EN_AMBAS_BODEGAS = ''NO'''))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_display_condition_type=>'EXPRESSION'
,p_plug_display_when_condition=>':P603_ID_REGION = 3'
,p_plug_display_when_cond2=>'PLSQL'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
,p_ai_enabled=>false
,p_updated_on=>wwv_flow_imp.dz('20260507203705Z')
,p_updated_by=>'JBALCAZAR'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(426792941459244508)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'MFERRIN'
,p_internal_uid=>426792941459244508
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(426793218259244510)
,p_db_column_name=>'DOCUMENTO'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Documento'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(427567368168254663)
,p_db_column_name=>'ETIQUETA'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Etiqueta'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(427570881773254698)
,p_db_column_name=>'COMPANIA'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'Compania'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(427571016665254699)
,p_db_column_name=>'BODEGA_ORIGEN'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>'Bodega Origen'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(427571482952254704)
,p_db_column_name=>'ADAIA_EN_17005'
,p_display_order=>80
,p_column_identifier=>'L'
,p_column_label=>'Adaia En 17005'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(427571605005254705)
,p_db_column_name=>'ADAIA_EN_17003'
,p_display_order=>90
,p_column_identifier=>'M'
,p_column_label=>'Adaia En 17003'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(427571679750254706)
,p_db_column_name=>'EN_AMBAS_BODEGAS'
,p_display_order=>100
,p_column_identifier=>'N'
,p_column_label=>'En Ambas Bodegas'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(427571934788254709)
,p_db_column_name=>'SI_17003_NO_EN_17005'
,p_display_order=>110
,p_column_identifier=>'Q'
,p_column_label=>'Si 17003 No En 17005'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(427579778351338370)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'1826492'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'COMPANIA:DOCUMENTO:ETIQUETA:BODEGA_ORIGEN:ADAIA_EN_17003:ADAIA_EN_17005:EN_AMBAS_BODEGAS:SI_17003_NO_EN_17005:'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(429261279543734975)
,p_plug_name=>unistr('TRANSFORMACIONES: TR CON COSTO UNITARIO DIFERENTE (FROM \2013TO)')
,p_parent_plug_id=>wwv_flow_imp.id(478616551125069403)
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(112813843178917343)
,p_plug_display_sequence=>200
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT',
'    ILDOC  AS DOCUMENTO,',
'    ILKCO  AS COMPANIA,',
'',
'    SUM(CASE',
'        WHEN ILFRTO = ''F''',
'        THEN NVL(ILPAID,0)/100',
'    END) AS COSTO_FROM,',
'',
'    SUM(CASE',
'        WHEN ILFRTO = ''T''',
'        THEN NVL(ILPAID,0)/100',
'    END) AS COSTO_TO,',
'',
'    SUM(NVL(ILPAID,0)/100) AS DIFERENCIA',
'',
'FROM PRODDTA.F4111@jdedtadl',
'',
'WHERE ',
'ILKCO = ''00001''',
'AND ILMCU = LPAD(:P603_BDG_PRODUCTIVA,12)',
'AND ILDCT = ''TR''',
'AND ILFRTO IN (''F'',''T'')',
'',
'AND ILTRDJ >= TO_NUMBER(TO_CHAR(TRUNC(SYSDATE,''MM''),''YYYYDDD'')) - 1900000',
'',
'GROUP BY',
'    ILDOC,',
'    ILKCO',
'',
'HAVING',
'    ABS(SUM(NVL(ILPAID,0)/100)) > 5',
'',
'ORDER BY',
'    ILDOC;'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_display_condition_type=>'EXPRESSION'
,p_plug_display_when_condition=>':P603_ID_REGION = 19'
,p_plug_display_when_cond2=>'PLSQL'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
,p_ai_enabled=>false
,p_updated_on=>wwv_flow_imp.dz('20260507203705Z')
,p_updated_by=>'JBALCAZAR'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(429261334450734976)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'MFERRIN'
,p_internal_uid=>429261334450734976
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(429261592288734978)
,p_db_column_name=>'DOCUMENTO'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Documento'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(430619190666493175)
,p_db_column_name=>'COMPANIA'
,p_display_order=>30
,p_column_identifier=>'E'
,p_column_label=>'Compania'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(430619259959493176)
,p_db_column_name=>'COSTO_FROM'
,p_display_order=>40
,p_column_identifier=>'F'
,p_column_label=>'Costo From'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G990D00'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(430619422052493177)
,p_db_column_name=>'COSTO_TO'
,p_display_order=>50
,p_column_identifier=>'G'
,p_column_label=>'Costo To'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G990D00'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(430619502377493178)
,p_db_column_name=>'DIFERENCIA'
,p_display_order=>60
,p_column_identifier=>'H'
,p_column_label=>'Diferencia'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G990D00'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(430626018875517946)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'1856954'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'DOCUMENTO:COSTO_FROM:COSTO_TO:DIFERENCIA:'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(429261912927734981)
,p_plug_name=>unistr('TRANSFORMACIONES: TR SIN AFECTACI\00D3N DE ASIENTO')
,p_parent_plug_id=>wwv_flow_imp.id(478616551125069403)
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(112813843178917343)
,p_plug_display_sequence=>210
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT 	ILDOC AS DOCUMENTO,',
'        ILDCT AS TIPO,',
'        ILDCTO AS TIPO_ORIGEN',
'FROM',
'PRODDTA.F4111@jdedtadl',
'WHERE',
'ILKCO = ''00001''',
'AND ILMCU = LPAD(:P603_BDG_PRODUCTIVA,12)',
'AND ILDCT = ''TR''',
'AND ILTRDJ >= TO_NUMBER(TO_CHAR(TRUNC(SYSDATE,''MM''),''YYYYDDD'')) - 1900000 AND ILDGL = 0',
'GROUP BY',
'        ILDOC,',
'        ILDCT,',
'        ILDCTO',
'ORDER BY',
'        ILDOC;'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_display_condition_type=>'EXPRESSION'
,p_plug_display_when_condition=>':P603_ID_REGION = 20'
,p_plug_display_when_cond2=>'PLSQL'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
,p_ai_enabled=>false
,p_updated_on=>wwv_flow_imp.dz('20260507203705Z')
,p_updated_by=>'JBALCAZAR'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(429262007276734982)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'MFERRIN'
,p_internal_uid=>429262007276734982
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(429262068422734983)
,p_db_column_name=>'TIPO'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Tipo'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(429262208405734984)
,p_db_column_name=>'DOCUMENTO'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Documento'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(429262445860734987)
,p_db_column_name=>'TIPO_ORIGEN'
,p_display_order=>30
,p_column_identifier=>'E'
,p_column_label=>'Tipo Origen'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(430602282985364151)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'1856717'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'DOCUMENTO:TIPO:TIPO_ORIGEN:'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(429262530481734988)
,p_plug_name=>'TRANSFORMACIONES: PRODUCTOS SIN COSTO PROMEDIO (02)'
,p_parent_plug_id=>wwv_flow_imp.id(478616551125069403)
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(112813843178917343)
,p_plug_display_sequence=>220
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT /*+ LEADING(b) */',
'       b.IBITM  AS CODIGO_CORTO,',
'       p.CODIGOPRODUCTO AS CODIGO_PRODUCTO,',
'       p.NOMBREPRODUCTO AS NOMBRE_PRODUCTO',
'FROM proddta.f4102@jdedtadl b',
'JOIN DATA.VT_JDE_PRODUCTOS p',
'     ON p.CODIGOCORTO = b.IBITM',
'WHERE b.IBMCU = LPAD(:P603_BDG_PRODUCTIVA,12)',
'AND IBSTKT =''P''',
'AND p.CODESTADO <> ''O''',
'AND NOT EXISTS (',
'        SELECT 1',
'        FROM proddta.f4105@jdedtadl c',
'        WHERE c.COITM = b.IBITM',
'          AND c.COMCU = b.IBMCU',
'          AND c.COLEDG = ''02''',
');'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_display_condition_type=>'EXPRESSION'
,p_plug_display_when_condition=>':P603_ID_REGION = 21'
,p_plug_display_when_cond2=>'PLSQL'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
,p_ai_enabled=>false
,p_updated_on=>wwv_flow_imp.dz('20260507203705Z')
,p_updated_by=>'JBALCAZAR'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(429262703183734989)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'TOP_AND_BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'MFERRIN'
,p_internal_uid=>429262703183734989
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(429263079137734993)
,p_db_column_name=>'CODIGO_CORTO'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Codigo Corto'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(429263185017734994)
,p_db_column_name=>'CODIGO_PRODUCTO'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Codigo Producto'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(429263309331734995)
,p_db_column_name=>'NOMBRE_PRODUCTO'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Nombre Producto'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(430609715367412256)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'1856791'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'CODIGO_CORTO:CODIGO_PRODUCTO:NOMBRE_PRODUCTO'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(437912603110301429)
,p_plug_name=>'DUPLICIDAD COSTO REPORTE HORAS -IH'
,p_parent_plug_id=>wwv_flow_imp.id(478616551125069403)
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(112813843178917343)
,p_plug_display_sequence=>130
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT IGCOST            tipocosto',
'     , IGDCTO            tipo',
'     , IGDOCO            orden',
'     , COSTOREAL',
'     , COSTOFINALIZADO   costoestandar',
'     , HORASREAL',
'     , HORASESTANDAR',
'     , FECHASOLICITUD',
'     , MAQUINA',
'     , NomMaquina',
'     , LISTA',
'     , RUTA',
'     , TIPOOP',
'     , ROUND(DECODE(CostoFinalizado, 0, 999, (costoreal - CostoFinalizado) * 100 / CostoFinalizado), 2) PrVariacion',
'     , (SELECT MAX(k.glicu) FROM f0911@jdedtadl k WHERE k.glsbl = doccont AND k.gldct = ''IH'')           NUMBACH',
'     , (SELECT MAX(k.gldoc) FROM f0911@jdedtadl k WHERE k.glsbl = doccont AND k.gldct = ''IH'')           documento',
'     ,WAMMCU BODEGA',
'FROM (SELECT c.igcost',
'           , c.igdcto',
'           , c.igdoco',
'           , c.igclat / 10000   CostoReal',
'           , c.igopat / 10000   CostoEstandar',
'           , c.igcpat / 10000   CostoFinalizado',
'           , c.igclun / 10000   HorasReal',
'           , c.igcccu / 10000   HorasEstandar',
'           , TO_DATE(o.wadrqj + 1900000, ''yyyyddd'')   FechaSolicitud',
'           , c.igmcu            Maquina',
'           , (SELECT TRIM(m.iwlocn) FROM f30006@jdedtadl m WHERE m.iwmcu = c.igmcu) NomMaquina',
'           , o.watbm            Lista',
'           , watrt              ruta',
'           , watyps             tipoop',
'           , ''0'' || IGDOCO      doccont',
'           ,WAMMCU',
'      FROM f3102@jdedtadl c,',
'           f4801@jdedtadl o',
'      WHERE c.igdoco = o.wadoco',
'        AND o.wasrst = ''82''',
'        AND c.igcost IN (''B1'', ''B3'')',
'        AND o.WAMMCU = LPAD(:P603_BDG_PRODUCTIVA,12)',
'        AND o.watrt = ''M  ''',
'        AND NOT TRIM(c.igcost) IS NULL',
'        AND EXISTS(SELECT 1 FROM f0911@jdedtadl k WHERE k.glsbl = ''0'' || c.igdoco AND k.gldct = ''IH'')',
'',
'      ) d1',
'WHERE ROUND(DECODE(CostoFinalizado, 0, 999, (costoreal - CostoFinalizado) * 100 / CostoFinalizado), 2) >= 100',
'ORDER BY igdoco;'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_display_condition_type=>'EXPRESSION'
,p_plug_display_when_condition=>':P603_ID_REGION = 12'
,p_plug_display_when_cond2=>'PLSQL'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
,p_created_on=>wwv_flow_imp.dz('20260423140808Z')
,p_updated_on=>wwv_flow_imp.dz('20260507203708Z')
,p_created_by=>'JBALCAZAR'
,p_updated_by=>'JBALCAZAR'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(437912713761301430)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'JBALCAZAR'
,p_internal_uid=>437912713761301430
,p_created_on=>wwv_flow_imp.dz('20260423140810Z')
,p_updated_on=>wwv_flow_imp.dz('20260427192030Z')
,p_created_by=>'JBALCAZAR'
,p_updated_by=>'JBALCAZAR'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(437912881480301431)
,p_db_column_name=>'DOCUMENTO'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Documento'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20260423140810Z')
,p_updated_on=>wwv_flow_imp.dz('20260423140810Z')
,p_created_by=>'JBALCAZAR'
,p_updated_by=>'JBALCAZAR'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(437912917256301432)
,p_db_column_name=>'TIPOCOSTO'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Tipocosto'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20260423140810Z')
,p_updated_on=>wwv_flow_imp.dz('20260423140810Z')
,p_created_by=>'JBALCAZAR'
,p_updated_by=>'JBALCAZAR'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(437913006039301433)
,p_db_column_name=>'TIPO'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Tipo'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20260423140810Z')
,p_updated_on=>wwv_flow_imp.dz('20260423140810Z')
,p_created_by=>'JBALCAZAR'
,p_updated_by=>'JBALCAZAR'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(437913164331301434)
,p_db_column_name=>'ORDEN'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Orden'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20260423140810Z')
,p_updated_on=>wwv_flow_imp.dz('20260423140810Z')
,p_created_by=>'JBALCAZAR'
,p_updated_by=>'JBALCAZAR'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(437913275780301435)
,p_db_column_name=>'COSTOREAL'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Costoreal'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20260423140810Z')
,p_updated_on=>wwv_flow_imp.dz('20260423140810Z')
,p_created_by=>'JBALCAZAR'
,p_updated_by=>'JBALCAZAR'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(437913345692301436)
,p_db_column_name=>'COSTOESTANDAR'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'Costoestandar'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20260423140810Z')
,p_updated_on=>wwv_flow_imp.dz('20260423140810Z')
,p_created_by=>'JBALCAZAR'
,p_updated_by=>'JBALCAZAR'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(437913485430301437)
,p_db_column_name=>'HORASREAL'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>'Horasreal'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20260423140810Z')
,p_updated_on=>wwv_flow_imp.dz('20260423140810Z')
,p_created_by=>'JBALCAZAR'
,p_updated_by=>'JBALCAZAR'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(437913527186301438)
,p_db_column_name=>'HORASESTANDAR'
,p_display_order=>80
,p_column_identifier=>'H'
,p_column_label=>'Horasestandar'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20260423140810Z')
,p_updated_on=>wwv_flow_imp.dz('20260423140810Z')
,p_created_by=>'JBALCAZAR'
,p_updated_by=>'JBALCAZAR'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(437913632745301439)
,p_db_column_name=>'FECHASOLICITUD'
,p_display_order=>90
,p_column_identifier=>'I'
,p_column_label=>'Fechasolicitud'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20260423140810Z')
,p_updated_on=>wwv_flow_imp.dz('20260423140810Z')
,p_created_by=>'JBALCAZAR'
,p_updated_by=>'JBALCAZAR'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(437913747691301440)
,p_db_column_name=>'MAQUINA'
,p_display_order=>100
,p_column_identifier=>'J'
,p_column_label=>'Maquina'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20260423140810Z')
,p_updated_on=>wwv_flow_imp.dz('20260423140810Z')
,p_created_by=>'JBALCAZAR'
,p_updated_by=>'JBALCAZAR'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(437913820484301441)
,p_db_column_name=>'NOMMAQUINA'
,p_display_order=>110
,p_column_identifier=>'K'
,p_column_label=>'Nommaquina'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20260423140810Z')
,p_updated_on=>wwv_flow_imp.dz('20260423140810Z')
,p_created_by=>'JBALCAZAR'
,p_updated_by=>'JBALCAZAR'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(437913984588301442)
,p_db_column_name=>'LISTA'
,p_display_order=>120
,p_column_identifier=>'L'
,p_column_label=>'Lista'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20260423140811Z')
,p_updated_on=>wwv_flow_imp.dz('20260423140811Z')
,p_created_by=>'JBALCAZAR'
,p_updated_by=>'JBALCAZAR'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(437914096728301443)
,p_db_column_name=>'RUTA'
,p_display_order=>130
,p_column_identifier=>'M'
,p_column_label=>'Ruta'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20260423140811Z')
,p_updated_on=>wwv_flow_imp.dz('20260423140811Z')
,p_created_by=>'JBALCAZAR'
,p_updated_by=>'JBALCAZAR'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(437914144113301444)
,p_db_column_name=>'TIPOOP'
,p_display_order=>140
,p_column_identifier=>'N'
,p_column_label=>'Tipoop'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20260423140811Z')
,p_updated_on=>wwv_flow_imp.dz('20260423140811Z')
,p_created_by=>'JBALCAZAR'
,p_updated_by=>'JBALCAZAR'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(437914267544301445)
,p_db_column_name=>'PRVARIACION'
,p_display_order=>150
,p_column_identifier=>'O'
,p_column_label=>'Prvariacion'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20260423140811Z')
,p_updated_on=>wwv_flow_imp.dz('20260423140811Z')
,p_created_by=>'JBALCAZAR'
,p_updated_by=>'JBALCAZAR'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(437914373582301446)
,p_db_column_name=>'NUMBACH'
,p_display_order=>160
,p_column_identifier=>'P'
,p_column_label=>'Numbach'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20260423140811Z')
,p_updated_on=>wwv_flow_imp.dz('20260423140811Z')
,p_created_by=>'JBALCAZAR'
,p_updated_by=>'JBALCAZAR'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(437914431391301447)
,p_db_column_name=>'BODEGA'
,p_display_order=>170
,p_column_identifier=>'Q'
,p_column_label=>'Bodega'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20260423140811Z')
,p_updated_on=>wwv_flow_imp.dz('20260423140811Z')
,p_created_by=>'JBALCAZAR'
,p_updated_by=>'JBALCAZAR'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(438621561462432926)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'4386216'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'DOCUMENTO:TIPOCOSTO:TIPO:ORDEN:COSTOREAL:COSTOESTANDAR:HORASREAL:HORASESTANDAR:FECHASOLICITUD:MAQUINA:NOMMAQUINA:LISTA:RUTA:TIPOOP:PRVARIACION:NUMBACH:BODEGA:'
,p_created_on=>wwv_flow_imp.dz('20260423142544Z')
,p_updated_on=>wwv_flow_imp.dz('20260423143742Z')
,p_created_by=>'PSUNTAXI'
,p_updated_by=>'PSUNTAXI'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(446746167890575777)
,p_plug_name=>'TRANSFORMACIONES: DIFERENCIA SUMA COSTO CONSUMO IM-VS REPORTE-IC'
,p_parent_plug_id=>wwv_flow_imp.id(478616551125069403)
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(112813843178917343)
,p_plug_display_sequence=>230
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'WITH WO_COMPONENTES AS (',
'   SELECT DISTINCT',
'       WMDOCO',
'   FROM PRODDTA.F3111@jdedtadl',
'   WHERE WMCOBY != ''C''',
'),',
'IM AS (',
'   SELECT DISTINCT',
'       im.ILDOC,',
'       im.ILDCTO,',
'       SUM(NVL(im.ILPAID,0))/100 AS COSTO_IM',
'   FROM PRODDTA.F4111@jdedtadl im',
'   JOIN WO_COMPONENTES w',
'       ON w.WMDOCO = im.ILDOC',
'   WHERE im.ILDCT = ''IM''',
'     AND im.ILMCU = LPAD(:P603_BDG_PRODUCTIVA,12)',
'     AND im.ILRCD != ''PM1''',
'     AND (',
'        (im.ILTRDJ BETWEEN :P603_INICIO_MES_JDE AND :P603_HOY_JDE AND :P603_EN_VENT_ANT = 0)',
'        OR',
'        (im.ILTRDJ BETWEEN :P603_INICIO_MES_ANTERIOR_JDE AND :P603_FIN_MES_ANTERIOR_JDE AND :P603_EN_VENT_ANT = 1)',
'     )',
'   GROUP BY',
'       im.ILDOC,',
'       im.ILDCTO',
'),',
'-- ;',
'IC AS (',
'   SELECT',
'       ic.ILDOC,',
'       SUM(NVL(ic.ILPAID,0))/100 AS COSTO_IC',
'   FROM PRODDTA.F4111@jdedtadl ic',
'   WHERE ic.ILDCT = ''IC''',
'     AND (',
'        (ic.ILTRDJ BETWEEN :P603_INICIO_MES_JDE AND :P603_HOY_JDE AND :P603_EN_VENT_ANT = 0)',
'        OR',
'        (ic.ILTRDJ BETWEEN :P603_INICIO_MES_ANTERIOR_JDE AND :P603_FIN_MES_ANTERIOR_JDE AND :P603_EN_VENT_ANT = 1)',
'     )',
'   GROUP BY',
'       ic.ILDOC',
')',
'SELECT',
'   im.ILDOC AS DOCUMENTO,',
'   im.ILDCTO AS TIPO_ORIGEN,',
'   im.COSTO_IM,',
'   NVL(ic.COSTO_IC,0) AS COSTO_IC,',
'   im.COSTO_IM + NVL(ic.COSTO_IC,0) AS DIFERENCIA',
'FROM IM im',
'LEFT JOIN IC ic',
'      ON ic.ILDOC = im.ILDOC',
'WHERE ABS(im.COSTO_IM + NVL(ic.COSTO_IC,0)) > 0',
'ORDER BY im.ILDOC;'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_display_condition_type=>'EXPRESSION'
,p_plug_display_when_condition=>':P603_ID_REGION = 22'
,p_plug_display_when_cond2=>'PLSQL'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
,p_ai_enabled=>false
,p_updated_on=>wwv_flow_imp.dz('20260513180447Z')
,p_updated_by=>'JBALCAZAR'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(446746234628575778)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'MFERRIN'
,p_internal_uid=>446746234628575778
,p_updated_on=>wwv_flow_imp.dz('20260513180447Z')
,p_updated_by=>'JBALCAZAR'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(446746341037575779)
,p_db_column_name=>'DOCUMENTO'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Documento'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(446746512490575780)
,p_db_column_name=>'TIPO_ORIGEN'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Tipo Origen'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(446746609893575781)
,p_db_column_name=>'COSTO_IM'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Costo Im'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G990D00'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(446746659585575782)
,p_db_column_name=>'COSTO_IC'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Costo Ic'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G990D00'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(446746789028575783)
,p_db_column_name=>'DIFERENCIA'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Diferencia'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G990D00'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(446781022997690403)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'2018504'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'DOCUMENTO:TIPO_ORIGEN:COSTO_IM:COSTO_IC:DIFERENCIA'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(478616699988069404)
,p_plug_name=>'Documentos no contabilizados'
,p_parent_plug_id=>wwv_flow_imp.id(478616551125069403)
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(112813843178917343)
,p_plug_display_sequence=>20
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT',
'    ic.ILDOC Documento,',
'    ic.ILDCT Tipo,',
'    ic.ILMCU Bodega,',
'    TO_DATE(TO_CHAR(NULLIF(ic.ILCRDJ, 0) + 1900000), ''YYYYDDD'') Fecha_Creacion_Documento,',
'    ILICU Numero_Batch',
'FROM proddta.F4111@jdedtadl ic',
'WHERE ic.ILKCO = ''00001''',
'  AND ic.ILDCT IN (''IC'',''IM'')',
'  AND ic.ILMCU = LPAD(:P603_BDG_PRODUCTIVA,12)',
'',
'  -- Solo hoy y ayer',
'  AND (',
'    (ic.ILCRDJ BETWEEN :P603_AYER_JDE AND :P603_HOY_JDE AND :P603_EN_VENT_ANT = 0)',
'    OR',
'    (ic.ILCRDJ BETWEEN :P603_INICIO_MES_ANTERIOR_JDE AND :P603_FIN_MES_ANTERIOR_JDE AND :P603_EN_VENT_ANT = 1)',
'  )',
'  --AND ic.ILDGL BETWEEN (:P603_AYER_JDE -1) AND (:P603_HOY_JDE + 1)',
'  --AND ic.ILICU > 0',
'  AND ic.ILIPCD <> ''X''',
'',
'  AND NOT EXISTS (',
'        SELECT 1',
'        FROM proddta.F0911@jdedtadl im',
'        WHERE im.GLDCT = ic.ILDCT',
'          AND im.GLSBL = LPAD(ic.ILDOC,8,''0'')',
'          AND im.GLKCO = ic.ILKCO',
'          --AND im.GLMCU = ic.ILMCU',
'          AND im.GLICU = ic.ILICU',
'          AND im.GLDGJ = ic.ILDGL',
'  )',
'GROUP BY',
'    ic.ILDOC,',
'    ic.ILDCT,',
'    ic.ILMCU,',
'    ic.ILCRDJ,ILICU',
'',
'UNION ALL',
'',
'SELECT',
'    ic.ILDOC Documento,',
'    ic.ILDCT Tipo,',
'    ic.ILMCU Bodega,',
'    TO_DATE(TO_CHAR(NULLIF(ic.ILCRDJ, 0) + 1900000), ''YYYYDDD'') Fecha_Creacion_Documento,',
'    ILICU Numero_Batch',
'FROM proddta.F4111@jdedtadl ic',
'WHERE ic.ILKCO = ''00001''',
'  AND ic.ILDCT NOT IN (''IC'',''IM'')',
'  AND ic.ILMCU = LPAD(:P603_BDG_PRODUCTIVA,12)',
'',
'  -- Solo hoy y ayer',
'  AND (',
'    (ic.ILCRDJ BETWEEN :P603_AYER_JDE AND :P603_HOY_JDE AND :P603_EN_VENT_ANT = 0)',
'    OR',
'    (ic.ILCRDJ BETWEEN :P603_INICIO_MES_ANTERIOR_JDE AND :P603_FIN_MES_ANTERIOR_JDE AND :P603_EN_VENT_ANT = 1)',
'  )',
'  --AND ic.ILDGL BETWEEN (:P603_AYER_JDE -1) AND (:P603_HOY_JDE + 1)',
'  --AND ic.ILICU > 0',
'  AND ic.ILIPCD <> ''X''',
'',
'  AND NOT EXISTS (',
'        SELECT 1',
'        FROM proddta.F0911@jdedtadl im',
'        WHERE im.GLDCT = ic.ILDCT',
'          AND im.GLDOC = ic.ILDOC',
'          AND im.GLKCO = ic.ILKCO',
'          --AND im.GLMCU = ic.ILMCU',
'          AND im.GLICU = ic.ILICU',
'          AND im.GLDGJ = ic.ILDGL',
'  )',
'GROUP BY',
'    ic.ILDOC,',
'    ic.ILDCT,',
'    ic.ILMCU,',
'    ic.ILCRDJ,ILICU'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_display_condition_type=>'EXPRESSION'
,p_plug_display_when_condition=>':P603_ID_REGION = 2'
,p_plug_display_when_cond2=>'PLSQL'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
,p_ai_enabled=>false
,p_updated_on=>wwv_flow_imp.dz('20260604134754Z')
,p_updated_by=>'JBALCAZAR'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(478616755623069405)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'TOP_AND_BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'MFERRIN'
,p_internal_uid=>478616755623069405
,p_updated_on=>wwv_flow_imp.dz('20260604134754Z')
,p_updated_by=>'JBALCAZAR'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(478616872154069406)
,p_db_column_name=>'TIPO'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Tipo'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(478616993744069407)
,p_db_column_name=>'DOCUMENTO'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Documento'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(478617032743069408)
,p_db_column_name=>'BODEGA'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Bodega'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(437914630134301449)
,p_db_column_name=>'FECHA_CREACION_DOCUMENTO'
,p_display_order=>40
,p_column_identifier=>'E'
,p_column_label=>unistr('Fecha Creaci\00F3n Documento')
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20260423171850Z')
,p_updated_on=>wwv_flow_imp.dz('20260423171850Z')
,p_created_by=>'JBALCAZAR'
,p_updated_by=>'JBALCAZAR'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(440583829535170148)
,p_db_column_name=>'NUMERO_BATCH'
,p_display_order=>50
,p_column_identifier=>'G'
,p_column_label=>'Numero Batch'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20260424210443Z')
,p_updated_on=>wwv_flow_imp.dz('20260424210443Z')
,p_created_by=>'JBALCAZAR'
,p_updated_by=>'JBALCAZAR'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(486549840537991159)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'2416193'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'TIPO:DOCUMENTO:BODEGA:FECHA_CREACION_DOCUMENTO:NUMERO_BATCH:'
,p_updated_on=>wwv_flow_imp.dz('20260505150302Z')
,p_updated_by=>'MMATANGO'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(486544791633968472)
,p_plug_name=>'Etiquetas duplicadas'
,p_parent_plug_id=>wwv_flow_imp.id(478616551125069403)
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(112813843178917343)
,p_plug_display_sequence=>50
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'WITH BASE AS (',
'    SELECT',
'        ic.ILDOC,',
'        ic.ILDCT,',
'        ic.ILMCU,',
'        ic.ILTREX,',
'        ic.ILTRDJ',
'    FROM proddta.F4111@jdedtadl ic',
'    WHERE ic.ILDCT = ''IT''',
'      AND ic.ILMCU IN (LPAD(:P603_BDG_PRODUCTIVA,12), LPAD(''17003'',12))',
'      AND ic.ILTRDJ BETWEEN',
'            (TO_NUMBER(TO_CHAR(SYSDATE-1,''YYYYDDD'')) - 1900000)',
'        AND (TO_NUMBER(TO_CHAR(SYSDATE,''YYYYDDD'')) - 1900000)',
'),',
'ETIQUETAS AS (',
'    SELECT DISTINCT ILTREX',
'    FROM BASE',
'    WHERE ILMCU = LPAD(:P603_BDG_PRODUCTIVA,12) AND ILTREX LIKE ''ETIQUETA%''',
'),',
'CNT AS (',
'    SELECT',
'        ILTREX,',
'        ILMCU,',
'        COUNT(*) AS CANTIDAD_BODEGA',
'    FROM BASE',
'    GROUP BY ILTREX, ILMCU',
')',
'',
'SELECT',
'    b.ILDOC  AS Documento,',
'    b.ILDCT  AS Tipo,',
'    b.ILMCU  AS Bodega,',
'    c.CANTIDAD_BODEGA AS Cantidad,',
'    b.ILTREX AS Etiqueta',
'FROM BASE b',
'JOIN ETIQUETAS e',
'  ON e.ILTREX = b.ILTREX',
'JOIN CNT c',
'  ON c.ILTREX = b.ILTREX',
' AND c.ILMCU  = b.ILMCU',
'WHERE c.CANTIDAD_BODEGA > 1',
'ORDER BY b.ILTREX, b.ILMCU;'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_display_condition_type=>'EXPRESSION'
,p_plug_display_when_condition=>':P603_ID_REGION = 4'
,p_plug_display_when_cond2=>'PLSQL'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
,p_ai_enabled=>false
,p_updated_on=>wwv_flow_imp.dz('20260507203706Z')
,p_updated_by=>'JBALCAZAR'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(486544878523968473)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'MFERRIN'
,p_internal_uid=>486544878523968473
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(486544973243968474)
,p_db_column_name=>'TIPO'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Tipo'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(486545086972968475)
,p_db_column_name=>'DOCUMENTO'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Documento'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(486545214757968476)
,p_db_column_name=>'BODEGA'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Bodega'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(486545270547968477)
,p_db_column_name=>'ETIQUETA'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Etiqueta'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(486545396029968478)
,p_db_column_name=>'CANTIDAD'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Cantidad'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(486581744048321371)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'2416512'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'ETIQUETA:CANTIDAD:BODEGA:DOCUMENTO:TIPO:'
,p_break_on=>'ETIQUETA'
,p_break_enabled_on=>'ETIQUETA'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(486545476359968479)
,p_plug_name=>'REPORTE-IC SIN CONSUMO-IM'
,p_parent_plug_id=>wwv_flow_imp.id(478616551125069403)
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(112813843178917343)
,p_plug_display_sequence=>60
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT *',
'FROM (',
'    SELECT',
'        ic.ILLITM AS Item_Produccion,',
'        ic.ILDOC AS Documento,',
'        wo.WASRST AS Estado_Orden,',
'        ic.ILDCTO AS Tipo_Orden,',
'        COUNT(ic.ILLITM) AS Cantidad_IC, --cuento los movimientos del articulo producido',
'        (',
'            SELECT COUNT(im.ILLITM) --cuento los movimientos de la lista de materiales',
'            FROM PRODDTA.F4111@jdedtadl im',
'            WHERE im.ILDOC = ic.ILDOC',
'              AND im.ILDCTO = ic.ILDCTO',
'              AND (',
'                (im.ILTRDJ BETWEEN :P603_INICIO_MES_JDE AND :P603_HOY_JDE AND :P603_EN_VENT_ANT = 0)',
'                OR',
'                (im.ILTRDJ BETWEEN :P603_INICIO_MES_ANTERIOR_JDE AND :P603_FIN_MES_ANTERIOR_JDE AND :P603_EN_VENT_ANT = 1)',
'              )',
'              AND im.ILDCT = ''IM''',
'              AND im.ILRCD != ''PM1''',
'              AND im.ILLITM = (',
'                    SELECT WMCPIL',
'                    FROM PRODDTA.F3111@jdedtadl',
'                    WHERE WMDOCO = ic.ILDOC',
'                      AND WMCOBY != ''C''',
'                      AND WMITC = ''B''',
'                      AND WMBSEQ = 1',
'                      FETCH FIRST 1 ROW ONLY --tomo el primer articulo de la lista de materiales',
'              )',
'        ) AS Cantidad_IM,',
'        (',
unistr('            SELECT MAX(im.ILLOCN) --tomo la m\00E1quina de referencia de la lista de materiales'),
'            FROM PRODDTA.F4111@jdedtadl im',
'            WHERE im.ILDOC = ic.ILDOC',
'              AND im.ILDCTO = ic.ILDCTO',
'              AND im.ILDCT = ''IM''',
'              AND im.ILRCD != ''PM1''',
'              AND (',
'                (im.ILTRDJ BETWEEN :P603_INICIO_MES_JDE AND :P603_HOY_JDE AND :P603_EN_VENT_ANT = 0)',
'                OR',
'                (im.ILTRDJ BETWEEN :P603_INICIO_MES_ANTERIOR_JDE AND :P603_FIN_MES_ANTERIOR_JDE AND :P603_EN_VENT_ANT = 1)',
'              )',
'              AND im.ILLITM = (',
'                    SELECT WMCPIL',
'                    FROM PRODDTA.F3111@jdedtadl',
'                    WHERE WMDOCO = ic.ILDOC',
'                      AND WMCOBY != ''C''',
'                      AND WMITC = ''B''',
'                      AND WMBSEQ = 1',
'                      FETCH FIRST 1 ROW ONLY --tomo el primer articulo de la lista de materiales',
'              )',
'        ) AS Maquina',
'',
'    FROM proddta.F4111@jdedtadl ic',
'    INNER JOIN proddta.F4801@jdedtadl wo ON ic.ILDOC = wo.WADOCO AND ic.ILDCTO = wo.WADCTO',
'    WHERE ic.ILDCT = ''IC''',
'      AND ic.ILMCU = LPAD(:P603_BDG_PRODUCTIVA,12)',
'      AND (',
'        (ic.ILTRDJ BETWEEN :P603_INICIO_MES_JDE AND :P603_HOY_JDE AND :P603_EN_VENT_ANT = 0)',
'        OR',
'        (ic.ILTRDJ BETWEEN :P603_INICIO_MES_ANTERIOR_JDE AND :P603_FIN_MES_ANTERIOR_JDE AND :P603_EN_VENT_ANT = 1)',
'      )',
'      AND wo.WATYPS <> ''P''',
'',
'    GROUP BY',
'        ic.ILDOC,',
'        ic.ILDCTO,',
'        ic.ILLITM,',
'        ic.ILLOCN,',
'        wo.WASRST',
')',
'WHERE Cantidad_IC <> Cantidad_IM',
'ORDER BY Documento'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_display_condition_type=>'EXPRESSION'
,p_plug_display_when_condition=>':P603_ID_REGION = 5'
,p_plug_display_when_cond2=>'PLSQL'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
,p_ai_enabled=>false
,p_updated_on=>wwv_flow_imp.dz('20260513154709Z')
,p_updated_by=>'JBALCAZAR'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(486545622244968480)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'MFERRIN'
,p_internal_uid=>486545622244968480
,p_updated_on=>wwv_flow_imp.dz('20260513154709Z')
,p_updated_by=>'JBALCAZAR'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(486545672174968481)
,p_db_column_name=>'DOCUMENTO'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Documento'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(486545768395968482)
,p_db_column_name=>'TIPO_ORDEN'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Tipo Orden'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(486545873191968483)
,p_db_column_name=>'CANTIDAD_IC'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Cantidad Ic'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(486545973860968484)
,p_db_column_name=>'CANTIDAD_IM'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Cantidad Im'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(486546067335968485)
,p_db_column_name=>'ITEM_PRODUCCION'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Item Produccion'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(486546133360968486)
,p_db_column_name=>'MAQUINA'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'Maquina'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(437914734687301450)
,p_db_column_name=>'ESTADO_ORDEN'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>'Estado Orden'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20260423193015Z')
,p_updated_on=>wwv_flow_imp.dz('20260423193015Z')
,p_created_by=>'JBALCAZAR'
,p_updated_by=>'JBALCAZAR'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(486595198122436945)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'2416646'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'DOCUMENTO:TIPO_ORDEN:ESTADO_ORDEN:CANTIDAD_IC:CANTIDAD_IM:ITEM_PRODUCCION:MAQUINA:'
,p_updated_on=>wwv_flow_imp.dz('20260423193430Z')
,p_updated_by=>'PSUNTAXI'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(486547039680968495)
,p_plug_name=>'DESPERDICIO PM1 EN REPORTE PRIMERA'
,p_parent_plug_id=>wwv_flow_imp.id(478616551125069403)
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(112813843178917343)
,p_plug_display_sequence=>70
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT *',
'FROM (',
'    SELECT',
'        ic.ILLITM AS Item_Produccion,',
'        ic.ILDOC AS Documento,',
'        ic.ILDCTO AS Tipo_Orden,',
'        wo.WASRST AS Estado_Orden,',
'        COUNT(ic.ILLITM) AS Cantidad_IC,',
'',
'        (',
'            SELECT MAX(COUNT(im.ILLITM))',
'            FROM PRODDTA.F4111@jdedtadl im',
'            WHERE im.ILDOC = ic.ILDOC',
'              AND im.ILDCTO = ic.ILDCTO',
'              AND iM.ILTRDJ BETWEEN :P603_INICIO_MES_JDE AND :P603_HOY_JDE',
'              AND im.ILDCT = ''IM''',
'              AND im.ILRCD = ''PM1''',
'              ',
'              AND im.ILLITM = (',
'                    SELECT DISTINCT WMCPIL',
'                    FROM PRODDTA.F3111@jdedtadl',
'                    WHERE WMDOCO = ic.ILDOC',
'                      AND WMCOBY != ''C''',
'                      AND WMITC = ''B''',
'                      AND WMBSEQ = 1',
'                      AND WMCPIL = im.ILLITM',
'              )',
'              GROUP BY im.ILLITM',
'        ) AS Cantidad_IM,',
'        (',
unistr('            SELECT MAX(im.ILLOCN) --tomo la m\00E1quina de referencia de la lista de materiales'),
'            FROM PRODDTA.F4111@jdedtadl im',
'            WHERE im.ILDOC = ic.ILDOC',
'              AND im.ILDCTO = ic.ILDCTO',
'              AND iM.ILTRDJ BETWEEN :P603_INICIO_MES_JDE AND :P603_HOY_JDE',
'              AND im.ILDCT = ''IM''',
'              AND im.ILRCD = ''PM1''',
'              AND im.ILLITM = (',
'                    SELECT WMCPIL',
'                    FROM PRODDTA.F3111@jdedtadl',
'                    WHERE WMDOCO = ic.ILDOC',
'                      AND WMCOBY != ''C''',
'                      AND WMBSEQ = 1',
'                    ORDER BY WMCPIL DESC',
'                      FETCH FIRST 1 ROW ONLY --tomo el primer articulo de la lista de materiales',
'              )',
unistr('        ) AS M\00E1quina'),
'',
'    FROM proddta.F4111@jdedtadl ic',
'    INNER JOIN proddta.F4801@jdedtadl wo ON ic.ILDOC = wo.WADOCO AND ic.ILDCTO = wo.WADCTO',
'    WHERE ic.ILDCT = ''IS''',
'      AND ic.ILMCU = LPAD(:P603_BDG_PRODUCTIVA,12)',
'      AND ic.ILTRDJ BETWEEN :P603_INICIO_MES_JDE AND :P603_HOY_JDE',
'      --and 1 = 0',
'',
'    GROUP BY',
'        ic.ILDOC,',
'        ic.ILDCTO,',
'        ic.ILLITM,',
'        ic.ILLOCN,',
'        wo.WASRST',
')',
'-- Cantidad_IC <> Cantidad_IM',
'WHERE Cantidad_IC <> Cantidad_IM -- and 1 = 0',
'ORDER BY Documento'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_display_condition_type=>'EXPRESSION'
,p_plug_display_when_condition=>':P603_ID_REGION = 6'
,p_plug_display_when_cond2=>'PLSQL'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
,p_ai_enabled=>false
,p_updated_on=>wwv_flow_imp.dz('20260521182408Z')
,p_updated_by=>'JBALCAZAR'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(486547202313968496)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'MFERRIN'
,p_internal_uid=>486547202313968496
,p_updated_on=>wwv_flow_imp.dz('20260521182408Z')
,p_updated_by=>'JBALCAZAR'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(486547227655968497)
,p_db_column_name=>'DOCUMENTO'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Documento'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(486547386303968498)
,p_db_column_name=>'TIPO_ORDEN'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Tipo Orden'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(486547480449968499)
,p_db_column_name=>'CANTIDAD_IM'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Cantidad Im'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(486547547618968500)
,p_db_column_name=>'CANTIDAD_IC'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Cantidad Is'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
,p_updated_on=>wwv_flow_imp.dz('20260423180941Z')
,p_updated_by=>'JBALCAZAR'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(486547625681968501)
,p_db_column_name=>'ITEM_PRODUCCION'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Item Produccion'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(486547748966968502)
,p_db_column_name=>unistr('M\00C1QUINA')
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>unistr('M\00E1quina')
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(439143080333296601)
,p_db_column_name=>'ESTADO_ORDEN'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>'Estado Orden'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20260423193624Z')
,p_updated_on=>wwv_flow_imp.dz('20260423193624Z')
,p_created_by=>'JBALCAZAR'
,p_updated_by=>'JBALCAZAR'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(486627954759015243)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'2416974'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>unistr('DOCUMENTO:TIPO_ORDEN:ESTADO_ORDEN:CANTIDAD_IM:CANTIDAD_IC:ITEM_PRODUCCION:M\00C1QUINA:')
,p_updated_on=>wwv_flow_imp.dz('20260423194306Z')
,p_updated_by=>'PSUNTAXI'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(486547899662968503)
,p_plug_name=>unistr('\00D3RDENES CON ESTADO <= 30')
,p_parent_plug_id=>wwv_flow_imp.id(478616551125069403)
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(112813843178917343)
,p_plug_display_sequence=>80
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT',
'    wa.WADOCO Documento,',
'    wa.WADCTO Tipo,',
'    wa.WASRST Estado,',
'    wa.WAMMCU Bodega,',
'    TO_DATE(TO_CHAR(NULLIF(wa.WAUPMJ, 0) + 1900000), ''YYYYDDD'') Fecha_Documento,',
'    TO_DATE(TO_CHAR(NULLIF(wa.WADRQJ, 0) + 1900000), ''YYYYDDD'') Fecha_Actualizacion_Documento',
'FROM proddta.F4801@jdedtadl wa',
'WHERE wa.WAMMCU = LPAD(:P603_BDG_PRODUCTIVA,12) AND wa.WASRST <= ''30''-- AND TRUNC(SYSDATE) >= (SELECT FECHA FROM ULTIMO_DIA_HABIL) --DEBE SER ULTIMOS DOS DIAS ANTES DEL FIND DE MES',
'AND (',
'    (wa.WAUPMJ BETWEEN :P603_INICIO_MES_JDE AND :P603_FIN_MES_JDE AND :P603_EN_VENT_ANT = 0)',
'    OR',
'    (wa.WAUPMJ BETWEEN :P603_INICIO_MES_ANTERIOR_JDE AND :P603_FIN_MES_ANTERIOR_JDE AND :P603_EN_VENT_ANT = 1)',
' )',
'ORDER BY wa.WADOCO DESC'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_display_condition_type=>'EXPRESSION'
,p_plug_display_when_condition=>':P603_ID_REGION = 7'
,p_plug_display_when_cond2=>'PLSQL'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
,p_ai_enabled=>false
,p_updated_on=>wwv_flow_imp.dz('20260514212607Z')
,p_updated_by=>'JBALCAZAR'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(486547944388968504)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'TOP_AND_BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'MFERRIN'
,p_internal_uid=>486547944388968504
,p_updated_on=>wwv_flow_imp.dz('20260514212607Z')
,p_updated_by=>'JBALCAZAR'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(486548065757968505)
,p_db_column_name=>'DOCUMENTO'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Documento'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(486548160781968506)
,p_db_column_name=>'TIPO'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Tipo'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(486548298235968507)
,p_db_column_name=>'ESTADO'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Estado'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(486548413428968508)
,p_db_column_name=>'BODEGA'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Bodega'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(486548452810968509)
,p_db_column_name=>'FECHA_DOCUMENTO'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Fecha Documento'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(486548541926968510)
,p_db_column_name=>'FECHA_ACTUALIZACION_DOCUMENTO'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'Fecha Actualizacion Documento'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(486647773230098549)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'2417172'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'DOCUMENTO:TIPO:ESTADO:BODEGA:FECHA_DOCUMENTO:FECHA_ACTUALIZACION_DOCUMENTO'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(486663623032272961)
,p_plug_name=>'PROCESOS DE INVENTARIOS ABIERTOS'
,p_parent_plug_id=>wwv_flow_imp.id(478616551125069403)
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(112813843178917343)
,p_plug_display_sequence=>90
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT distinct CORTE_ID,UBICACION,USUARIO',
'FROM data.t_invc_itemcorte',
'WHERE ESTADO < 6 ',
'AND UNIDADNEGOCIO = TO_NUMBER(TRIM(:P603_BDG_PRODUCTIVA))',
unistr('  -- L\00D3GICA DE VISIBILIDAD DE MESES (Qu\00E9 meses puedo ver)'),
'  AND (',
'      -- Escenario A: Siempre traemos los documentos del MES ACTUAL, SOLO SE PUEDEN VER EL ULTIMO DIA DEL MES',
'      (',
'        :P603_ES_ULTIMO_DIA_H = 1',
'        AND FECHACREACION >= TRUNC(SYSDATE, ''MM'')',
'      )',
'      ',
'      OR ',
'      ',
unistr('      -- Escenario B: Traemos TODO el MES ANTERIOR, SOLO si han pasado 5 d\00EDas h\00E1biles o menos'),
'      (',
'          :P603_EN_VENT_ANT = 1',
'          AND FECHACREACION BETWEEN ADD_MONTHS(TRUNC(SYSDATE, ''MM''), -1) AND TRUNC(SYSDATE, ''MM'')',
'      )',
'  )',
'ORDER BY CORTE_ID'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_display_condition_type=>'EXPRESSION'
,p_plug_display_when_condition=>':P603_ID_REGION = 8'
,p_plug_display_when_cond2=>'PLSQL'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
,p_ai_enabled=>false
,p_updated_on=>wwv_flow_imp.dz('20260507203707Z')
,p_updated_by=>'JBALCAZAR'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(486663632017272962)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'TOP_AND_BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'MFERRIN'
,p_internal_uid=>486663632017272962
,p_updated_on=>wwv_flow_imp.dz('20260505143904Z')
,p_updated_by=>'JBALCAZAR'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(486663794693272963)
,p_db_column_name=>'CORTE_ID'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Corte Id'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(486663881560272964)
,p_db_column_name=>'UBICACION'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Ubicacion'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(486663998666272965)
,p_db_column_name=>'USUARIO'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Usuario'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(486676399847378012)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'2417458'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'CORTE_ID:UBICACION:USUARIO'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(486664045202272966)
,p_plug_name=>'DUPLICIDAD TRANSFERENCIA ENTRE BODEGAS'
,p_parent_plug_id=>wwv_flow_imp.id(478616551125069403)
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(112813843178917343)
,p_plug_display_sequence=>100
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'WITH',
'MT_OT AS (',
unistr('    -- 1. Contamos cu\00E1ntas L\00CDNEAS tiene cada producto en la Orden de Compra'),
'    SELECT /*+ DRIVING_SITE(po) INDEX(po F4311_4) */',
'        PO.PDDOCO AS DOCUMENTO,',
'        PO.PDDCTO AS TIPO,',
'        PO.PDITM AS PRODUCTO_CORTO,',
'        po.PDLITM AS PRODUCTO,',
'        po.PDRORN AS RELACIONADO,',
'        po.PDMCU AS BODEGA,',
'        COUNT(*) AS LINEAS',
'    FROM PRODDTA.F4311@jdedtadl po',
'    WHERE PO.PDDCTO IN (''MT'',''OT'')',
'      AND PO.PDTRDJ >= :P603_AYER_JDE',
'      AND PO.PDMCU = LPAD(:P603_BDG_PRODUCTIVA,12)',
'    GROUP BY',
'        PO.PDDOCO,',
'        PO.PDDCTO,',
'        PO.PDITM,',
'        PO.PDLITM,',
'        PO.PDRORN,',
'        PO.PDMCU',
'),',
'DT_ST AS (',
unistr('    -- 2. Contamos cu\00E1ntas L\00CDNEAS tiene el mismo producto en la Orden de Venta'),
'    SELECT /*+ DRIVING_SITE(SO) INDEX(SO F4211_0) */',
'        SO.SDRORN AS RELACIONADO,',
'        SO.SDDOCO AS DOCUMENTO,',
'        SO.SDDCTO AS TIPO,',
'        SO.SDITM AS PRODUCTO_CORTO,',
'        SO.SDLITM AS PRODUCTO,',
'        SO.SDMCU AS BODEGA,',
'        COUNT(SO.SDLNID) AS LINEAS',
'    FROM PRODDTA.F4211@jdedtadl SO',
'    WHERE SO.SDDOCO IN (SELECT DISTINCT RELACIONADO FROM MT_OT)',
'        AND SO.SDDCTO IN (''DT'',''ST'')',
'        AND SO.SDKCOO = ''00001''',
'        AND SO.SDTRDJ >= :P603_AYER_JDE',
'    GROUP BY',
'        SO.SDRORN,',
'        SO.SDDOCO,',
'        SO.SDDCTO,',
'        SO.SDITM,',
'        SO.SDLITM,',
'        SO.SDMCU',
')',
unistr('-- 3. Cruzamos los conteos de l\00EDneas por producto y mostramos los descuadres'),
'SELECT',
'    C.DOCUMENTO,',
'    C.TIPO,',
'    C.BODEGA,',
'    C.RELACIONADO,',
'    NVL(V.TIPO, ''N/A'') AS TIPO_RELACIONADO,',
'    V.BODEGA AS BODEGA_RELACIONAD,',
'    C.PRODUCTO,',
'    C.LINEAS,',
'    NVL(V.LINEAS, 0) AS LINEAS_RELACIONADO,',
'    (C.LINEAS - NVL(V.LINEAS, 0)) AS DIFERENCIA_DE_LINEAS',
'FROM DT_ST C',
'JOIN MT_OT V ON C.DOCUMENTO = V.RELACIONADO AND C.PRODUCTO_CORTO = V.PRODUCTO_CORTO',
'WHERE (C.LINEAS - NVL(V.LINEAS, 0)) <> 0',
'ORDER BY C.DOCUMENTO, C.PRODUCTO;'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_display_condition_type=>'EXPRESSION'
,p_plug_display_when_condition=>':P603_ID_REGION = 9'
,p_plug_display_when_cond2=>'PLSQL'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
,p_ai_enabled=>false
,p_updated_on=>wwv_flow_imp.dz('20260507203707Z')
,p_updated_by=>'JBALCAZAR'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(486664192108272967)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'MFERRIN'
,p_internal_uid=>486664192108272967
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(486664277187272968)
,p_db_column_name=>'BODEGA'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Bodega'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(486664363407272969)
,p_db_column_name=>'DOCUMENTO'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Documento'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(486664454904272970)
,p_db_column_name=>'TIPO'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Tipo'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(486664583871272971)
,p_db_column_name=>'PRODUCTO'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Producto'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(486664657254272972)
,p_db_column_name=>'RELACIONADO'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Relacionado'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(486664814127272973)
,p_db_column_name=>'LINEAS'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'Lineas'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(486664889561272974)
,p_db_column_name=>'TIPO_RELACIONADO'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>'Tipo Relacionado'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(486665023695272975)
,p_db_column_name=>'BODEGA_RELACIONAD'
,p_display_order=>80
,p_column_identifier=>'H'
,p_column_label=>'Bodega Relacionad'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(486665085685272976)
,p_db_column_name=>'LINEAS_RELACIONADO'
,p_display_order=>90
,p_column_identifier=>'I'
,p_column_label=>'Lineas Relacionado'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(486665198024272977)
,p_db_column_name=>'DIFERENCIA_DE_LINEAS'
,p_display_order=>100
,p_column_identifier=>'J'
,p_column_label=>'Diferencia De Lineas'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(486689546787483711)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'2417590'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'BODEGA:DOCUMENTO:TIPO:PRODUCTO:RELACIONADO:LINEAS:TIPO_RELACIONADO:BODEGA_RELACIONAD:LINEAS_RELACIONADO:DIFERENCIA_DE_LINEAS'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(486665237196272978)
,p_plug_name=>unistr('ESPERA DE CONFIRMACI\00D3N CONTRAPARTIDA DE TRANSFERENCIA ENTRE BODEGAS')
,p_parent_plug_id=>wwv_flow_imp.id(478616551125069403)
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(112813843178917343)
,p_plug_display_sequence=>110
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT',
'    so.SDDOCO        AS DOC_ORIGEN,',
'    so.SDDCTO        AS TIPO_ORIGEN,',
'    so.SDLITM        AS ITEM,',
'    so.SDNXTR        AS ESTADO_ORIGEN,',
'    po.PDDOCO        AS DOC_DESTINO,',
'    po.PDDCTO        AS TIPO_DESTINO,',
'    po.PDNXTR        AS ESTADO_DESTINO,',
'',
'    CASE',
'        WHEN po.PDDOCO IS NULL',
'            THEN ''SIN CONTRAPARTE''',
'',
'        WHEN so.SDNXTR = ''580'' AND po.PDNXTR <> ''400''',
'            THEN ''ESTADO MT/OT INCORRECTO''',
'    END AS VALIDACION',
'',
'FROM PRODDTA.F4211@jdedtadl so',
'',
'LEFT JOIN PRODDTA.F4311@jdedtadl po',
'       ON TRIM(po.PDRORN) = TO_CHAR(so.SDDOCO)',
'      AND so.SDLNID = po.PDLNID',
'      AND so.SDKCOO = po.PDKCOO',
'      AND so.SDLITM = po.PDLITM',
'      AND (',
'              (so.SDDCTO = ''DT'' AND po.PDDCTO = ''MT'')',
'           OR (so.SDDCTO = ''ST'' AND po.PDDCTO = ''OT'')',
'          )',
'',
'WHERE ',
'  so.SDKCOO = ''00001''',
'  AND so.SDMCU = LPAD(:P603_BDG_PRODUCTIVA,12)',
'  AND so.SDDCTO IN (''DT'',''ST'')',
'  AND so.SDNXTR = ''580''',
'  AND so.SDTRDJ BETWEEN :P603_HOY_JDE AND :P603_HOY_JDE +1',
'  AND (',
'        po.PDDOCO IS NULL',
'        OR po.PDNXTR <> ''400''',
'      )',
'',
'ORDER BY',
'    so.SDDCTO,',
'    so.SDDOCO,',
'    so.SDLNID;'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_display_condition_type=>'EXPRESSION'
,p_plug_display_when_condition=>':P603_ID_REGION = 10'
,p_plug_display_when_cond2=>'PLSQL'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
,p_ai_enabled=>false
,p_updated_on=>wwv_flow_imp.dz('20260507203707Z')
,p_updated_by=>'JBALCAZAR'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(486665338978272979)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'MFERRIN'
,p_internal_uid=>486665338978272979
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(486665428585272980)
,p_db_column_name=>'DOC_ORIGEN'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Doc Origen'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(486665555879272981)
,p_db_column_name=>'TIPO_ORIGEN'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Tipo Origen'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(486665664320272982)
,p_db_column_name=>'ITEM'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Item'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(486665810114272983)
,p_db_column_name=>'ESTADO_ORIGEN'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Estado Origen'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(486665866546272984)
,p_db_column_name=>'DOC_DESTINO'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Doc Destino'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(486666018850272985)
,p_db_column_name=>'TIPO_DESTINO'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'Tipo Destino'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(486666119987272986)
,p_db_column_name=>'ESTADO_DESTINO'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>'Estado Destino'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(486666148356272987)
,p_db_column_name=>'VALIDACION'
,p_display_order=>80
,p_column_identifier=>'H'
,p_column_label=>'Validacion'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(486714618430612298)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'2417840'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'DOC_ORIGEN:TIPO_ORIGEN:ITEM:ESTADO_ORIGEN:DOC_DESTINO:TIPO_DESTINO:ESTADO_DESTINO:VALIDACION'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(486666249610272988)
,p_plug_name=>'ESTADO MENOR A 620 DE TRANSFERENCIA ENTRE BODEGAS'
,p_parent_plug_id=>wwv_flow_imp.id(478616551125069403)
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(112813843178917343)
,p_plug_display_sequence=>120
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT',
'    --''F4211''            AS TABLA,',
'    so.SDDOCO          AS DOCUMENTO,',
'    so.SDDCTO          AS TIPO_DOC,',
'    so.SDLITM          AS ITEM,',
'    so.SDNXTR          AS NEXT_STATUS,',
'    so.SDLTTR          AS LAST_STATUS',
'FROM PRODDTA.F4211@jdedtadl so',
'WHERE so.SDDCTO IN (''DT'',''ST'')',
'  AND so.SDMCU = LPAD(:P603_BDG_PRODUCTIVA,12)',
'  AND so.SDNXTR < ''620''',
'  AND :P603_ES_ULTIMO_DIA_H = 1',
'',
'UNION ALL',
'',
'SELECT',
'    --''F4311''            AS TABLA,',
'    po.PDDOCO          AS DOCUMENTO,',
'    po.PDDCTO          AS TIPO_DOC,',
'    po.PDLITM          AS ITEM,',
'    po.PDNXTR          AS NEXT_STATUS,',
'    po.PDLTTR          AS LAST_STATUS',
'FROM PRODDTA.F4311@jdedtadl po',
'WHERE po.PDDCTO IN (''MT'',''OT'')',
'  AND po.PDMCU = LPAD(:P603_BDG_PRODUCTIVA,12)',
'  AND po.PDNXTR < ''620''',
'  AND :P603_ES_ULTIMO_DIA_H = 1',
'ORDER BY',
'    TIPO_DOC,',
'    DOCUMENTO'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_display_condition_type=>'EXPRESSION'
,p_plug_display_when_condition=>':P603_ID_REGION = 11'
,p_plug_display_when_cond2=>'PLSQL'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
,p_ai_enabled=>false
,p_updated_on=>wwv_flow_imp.dz('20260507203707Z')
,p_updated_by=>'JBALCAZAR'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(486666362924272989)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'MFERRIN'
,p_internal_uid=>486666362924272989
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(486666429606272990)
,p_db_column_name=>'ITEM'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Item'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(486666617160272991)
,p_db_column_name=>'DOCUMENTO'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Documento'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(486666659640272992)
,p_db_column_name=>'TIPO_DOC'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Tipo Doc'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(486666753809272993)
,p_db_column_name=>'NEXT_STATUS'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Next Status'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(486666868833272994)
,p_db_column_name=>'LAST_STATUS'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Last Status'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(486732997777730353)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'2418024'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'ITEM:DOCUMENTO:TIPO_DOC:NEXT_STATUS:LAST_STATUS'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(486743921267511367)
,p_plug_name=>'SOBREGIROS COSTO DESPERDICIO- IS'
,p_parent_plug_id=>wwv_flow_imp.id(478616551125069403)
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(112813843178917343)
,p_plug_display_sequence=>140
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT 	ILDOC AS DOCUMENTO,',
'        ILDCT AS TIPO,',
'        ILDCTO AS TIPO_ORIGEN,',
'        SUM(ILPAID)/100 AS TOTAL_MOVIMIENTOS',
'FROM',
'PRODDTA.F4111@jdedtadl',
'WHERE ',
'ILKCO = ''00001''',
'AND ILDCT = ''IM'' ',
'AND ILDCTO = ''WO''',
'AND ILMCU = LPAD(:P603_BDG_PRODUCTIVA,12)',
'AND ILTRDJ >= :P603_INICIO_MES_JDE',
'AND ILRCD = ''PM1''',
'GROUP BY',
'        ILDOC,',
'        ILDCT,',
'        ILDCTO',
'HAVING SUM(ILPAID) > 0',
'ORDER BY',
'        ILDOC;'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_display_condition_type=>'EXPRESSION'
,p_plug_display_when_condition=>':P603_ID_REGION = 13'
,p_plug_display_when_cond2=>'PLSQL'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
,p_ai_enabled=>false
,p_updated_on=>wwv_flow_imp.dz('20260507203707Z')
,p_updated_by=>'JBALCAZAR'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(486743978420511368)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'MFERRIN'
,p_internal_uid=>486743978420511368
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(486744045462511369)
,p_db_column_name=>'DOCUMENTO'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Documento'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(486744165394511370)
,p_db_column_name=>'TIPO'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Tipo'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(486744268014511371)
,p_db_column_name=>'TIPO_ORIGEN'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Tipo Origen'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(486744361866511372)
,p_db_column_name=>'TOTAL_MOVIMIENTOS'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Total Movimientos'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(487169865394710458)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'2422393'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'DOCUMENTO:TIPO:TIPO_ORIGEN:TOTAL_MOVIMIENTOS'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(486744466617511373)
,p_plug_name=>unistr('SALDOS NEGATIVOS EN M\00C1QUINA')
,p_parent_plug_id=>wwv_flow_imp.id(478616551125069403)
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(112813843178917343)
,p_plug_display_sequence=>150
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT lp.LIITM CODIGO_CORTO,p.CODIGOPRODUCTO CODIGO_PRODUCTO,p.NOMBREPRODUCTO NOMBRE_PRODUCTO,lp.LIPQOH/10000 CANTIDAD,LILOCN UBICACION,LILOTN LOTE',
'FROM proddta.F41021@jdedtadl lp',
'INNER JOIN DATA.VT_JDE_PRODUCTOS p ON p.CODIGOCORTO=lp.LIITM',
'WHERE lp.LIMCU= LPAD(:P603_BDG_PRODUCTIVA,12) and round(lp.LIPQOH/10000,4)<0'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_display_condition_type=>'EXPRESSION'
,p_plug_display_when_condition=>':P603_ID_REGION = 14'
,p_plug_display_when_cond2=>'PLSQL'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
,p_ai_enabled=>false
,p_updated_on=>wwv_flow_imp.dz('20260507203707Z')
,p_updated_by=>'JBALCAZAR'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(486744599887511374)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'MFERRIN'
,p_internal_uid=>486744599887511374
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(486744695458511375)
,p_db_column_name=>'CODIGO_CORTO'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Codigo Corto'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(486744752550511376)
,p_db_column_name=>'NOMBRE_PRODUCTO'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Nombre Producto'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(486744919893511377)
,p_db_column_name=>'CODIGO_PRODUCTO'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Codigo Producto'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(486745022821511378)
,p_db_column_name=>'UBICACION'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Ubicacion'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(486745049312511379)
,p_db_column_name=>'LOTE'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Lote'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(486745127763511380)
,p_db_column_name=>'CANTIDAD'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'Cantidad'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D0000'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(487179348925850929)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'2422488'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'CODIGO_CORTO:CODIGO_PRODUCTO:NOMBRE_PRODUCTO:CANTIDAD:UBICACION:LOTE:'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(486745310652511381)
,p_plug_name=>unistr('PRODUCTOS SIN COSTEO EST\00C1NDAR (07)')
,p_parent_plug_id=>wwv_flow_imp.id(478616551125069403)
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(112813843178917343)
,p_plug_display_sequence=>160
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT /*+ LEADING(b) */',
'       b.IBITM  AS CODIGO_CORTO,',
'       p.CODIGOPRODUCTO AS CODIGO_PRODUCTO,',
'       p.NOMBREPRODUCTO AS NOMBRE_PRODUCTO',
'FROM proddta.f4102@jdedtadl b',
'JOIN DATA.VT_JDE_PRODUCTOS p',
'     ON p.CODIGOCORTO = b.IBITM',
'WHERE b.IBMCU = LPAD(:P603_BDG_PRODUCTIVA,12) ',
'AND IBSTKT =''M''',
'AND p.CODESTADO <> ''O''',
'AND NOT EXISTS (',
'        SELECT 1',
'        FROM proddta.f4105@jdedtadl c',
'        WHERE c.COITM = b.IBITM',
'          AND c.COMCU = b.IBMCU',
'          AND c.COLEDG = ''07''',
');'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_display_condition_type=>'EXPRESSION'
,p_plug_display_when_condition=>':P603_ID_REGION = 15'
,p_plug_display_when_cond2=>'PLSQL'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
,p_ai_enabled=>false
,p_updated_on=>wwv_flow_imp.dz('20260507203708Z')
,p_updated_by=>'JBALCAZAR'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(486745347858511382)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'TOP_AND_BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'MFERRIN'
,p_internal_uid=>486745347858511382
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(486745457460511383)
,p_db_column_name=>'CODIGO_CORTO'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Codigo Corto'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(486745542731511384)
,p_db_column_name=>'NOMBRE_PRODUCTO'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Nombre Producto'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(486745675537511385)
,p_db_column_name=>'CODIGO_PRODUCTO'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Codigo Producto'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(487190128256966471)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'2422596'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'CODIGO_CORTO:CODIGO_PRODUCTO:NOMBRE_PRODUCTO:'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(486745814947511386)
,p_plug_name=>'MATERIA PRIMA SIN COSTO PROMEDIO (02)'
,p_parent_plug_id=>wwv_flow_imp.id(478616551125069403)
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(112813843178917343)
,p_plug_display_sequence=>170
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT /*+ LEADING(b) */',
'       b.IBITM  AS CODIGO_CORTO,',
'       p.CODIGOPRODUCTO AS CODIGO_PRODUCTO,',
'       p.NOMBREPRODUCTO AS NOMBRE_PRODUCTO',
'FROM proddta.f4102@jdedtadl b',
'JOIN DATA.VT_JDE_PRODUCTOS p',
'     ON p.CODIGOCORTO = b.IBITM',
'WHERE b.IBMCU = LPAD(:P603_BDG_PRODUCTIVA,12)',
'AND IBSTKT =''P''',
'AND p.TEXTOBUSQUEDA = ''MATERIA PRIMA'' AND p.CODESTADO <> ''O''',
'AND NOT EXISTS (',
'        SELECT 1',
'        FROM proddta.f4105@jdedtadl c',
'        WHERE c.COITM = b.IBITM',
'          AND c.COMCU = b.IBMCU',
'          AND c.COLEDG = ''02''',
')'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_display_condition_type=>'EXPRESSION'
,p_plug_display_when_condition=>':P603_ID_REGION = 16'
,p_plug_display_when_cond2=>'PLSQL'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
,p_ai_enabled=>false
,p_updated_on=>wwv_flow_imp.dz('20260507203708Z')
,p_updated_by=>'JBALCAZAR'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(486745909060511387)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'TOP_AND_BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'MFERRIN'
,p_internal_uid=>486745909060511387
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(486745951079511388)
,p_db_column_name=>'CODIGO_CORTO'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Codigo Corto'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(486746068668511389)
,p_db_column_name=>'NOMBRE_PRODUCTO'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Nombre Producto'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(486746172709511390)
,p_db_column_name=>'CODIGO_PRODUCTO'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Codigo Producto'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(487200978285116022)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'2422704'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'CODIGO_CORTO:CODIGO_PRODUCTO:NOMBRE_PRODUCTO:'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(486746309346511391)
,p_plug_name=>'SALDOS DE STOCK CON VALOR 0'
,p_parent_plug_id=>wwv_flow_imp.id(478616551125069403)
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(112813843178917343)
,p_plug_display_sequence=>180
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'WITH HISTORIAL_MENSUAL AS (',
'    SELECT',
'        INDCT AS TIPO,',
'        INMCU AS BODEGA,',
'        INITM AS CODIGO_INTERNO,',
'        CODIGOPRODUCTO CODIGO_PRODUCTO,',
'',
unistr('        -- Selecci\00F3n din\00E1mica del Monto (Amount - Net Posting) seg\00FAn el mes actual'),
'        SUM(CASE EXTRACT(MONTH FROM SYSDATE)',
'            WHEN 1 THEN INAN01 WHEN 2 THEN INAN02 WHEN 3 THEN INAN03',
'            WHEN 4 THEN INAN04 WHEN 5 THEN INAN05 WHEN 6 THEN INAN06',
'            WHEN 7 THEN INAN07 WHEN 8 THEN INAN08 WHEN 9 THEN INAN09',
'            WHEN 10 THEN INAN10 WHEN 11 THEN INAN11 WHEN 12 THEN INAN12',
'        END)/100 AS MONTO_NETO,',
'',
unistr('        -- Selecci\00F3n din\00E1mica de la Cantidad (Net Quantity) seg\00FAn el mes actual'),
'        SUM(CASE EXTRACT(MONTH FROM SYSDATE)',
'            WHEN 1 THEN INNQ01 WHEN 2 THEN INNQ02 WHEN 3 THEN INNQ03',
'            WHEN 4 THEN INNQ04 WHEN 5 THEN INNQ05 WHEN 6 THEN INNQ06',
'            WHEN 7 THEN INNQ07 WHEN 8 THEN INNQ08 WHEN 9 THEN INNQ09',
'            WHEN 10 THEN INNQ10 WHEN 11 THEN INNQ11 WHEN 12 THEN INNQ12',
'        END) AS CANTIDAD_NETA',
'',
'    FROM',
'        PRODDTA.F41112@jdedtadl',
'    INNER JOIN ',
'        DATA.VT_JDE_PRODUCTOS ON INITM = CODIGOCORTO',
'    WHERE',
unistr('        -- Extrae los \00FAltimos 2 d\00EDgitos del a\00F1o actual (Ej. 2026 -> 26)'),
'        INFY = TO_NUMBER(TO_CHAR(SYSDATE, ''YY''))',
'        AND INMCU = LPAD(:P603_BDG_PRODUCTIVA,12)',
'    GROUP BY',
'        INDCT, INMCU, INITM, CODIGOPRODUCTO',
')',
'',
unistr('-- Filtramos buscando la anomal\00EDa: Hubo valor financiero, pero cero unidades movidas'),
'SELECT * FROM HISTORIAL_MENSUAL',
'WHERE',
'    CANTIDAD_NETA = 0',
'    AND MONTO_NETO <> 0;'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_display_condition_type=>'EXPRESSION'
,p_plug_display_when_condition=>':P603_ID_REGION = 17'
,p_plug_display_when_cond2=>'PLSQL'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
,p_ai_enabled=>false
,p_updated_on=>wwv_flow_imp.dz('20260507203708Z')
,p_updated_by=>'JBALCAZAR'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(486746423197511392)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'TOP_AND_BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'MFERRIN'
,p_internal_uid=>486746423197511392
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(486746444833511393)
,p_db_column_name=>'TIPO'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Tipo'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(486746585940511394)
,p_db_column_name=>'BODEGA'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Bodega'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(486746716335511395)
,p_db_column_name=>'CODIGO_INTERNO'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Codigo Interno'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(486746765614511396)
,p_db_column_name=>'MONTO_NETO'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Monto Neto'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G990D00'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(486746872241511397)
,p_db_column_name=>'CANTIDAD_NETA'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Cantidad Neta'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D0000'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(486747013532511398)
,p_db_column_name=>'CODIGO_PRODUCTO'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'Codigo Producto'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(487209896090204057)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'2422793'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'CODIGO_PRODUCTO:BODEGA:MONTO_NETO:CANTIDAD_NETA:'
,p_sum_columns_on_break=>'CANTIDAD_NETA:MONTO_NETO'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(486747086916511399)
,p_plug_name=>unistr('SEMIELABORADOS SIN CATEGOR\00CDA M01')
,p_parent_plug_id=>wwv_flow_imp.id(478616551125069403)
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(112813843178917343)
,p_plug_display_sequence=>190
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT b.IBITM CODIGO_CORTO, p.CODIGOPRODUCTO CODIGO_PRODUCTO, p.NOMBREPRODUCTO NOMBRE_PRODUCTO',
'FROM proddta.f4102@jdedtadl b',
'INNER JOIN DATA.VT_JDE_PRODUCTOS p ON p.CODIGOCORTO=b.IBITM',
'WHERE ibmcu=LPAD(:P603_BDG_PRODUCTIVA,12) and ibsrp3!=''M01'' AND p.TEXTOBUSQUEDA = ''SEMIELABORADO'' AND p.CODESTADO <> ''O'';'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_display_condition_type=>'EXPRESSION'
,p_plug_display_when_condition=>':P603_ID_REGION = 18'
,p_plug_display_when_cond2=>'PLSQL'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
,p_ai_enabled=>false
,p_updated_on=>wwv_flow_imp.dz('20260507203708Z')
,p_updated_by=>'JBALCAZAR'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(486747179524511400)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'TOP_AND_BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'MFERRIN'
,p_internal_uid=>486747179524511400
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(486747317584511401)
,p_db_column_name=>'CODIGO_CORTO'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Codigo Corto'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(486747381684511402)
,p_db_column_name=>'CODIGO_PRODUCTO'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Codigo Producto'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(486747452609511403)
,p_db_column_name=>'NOMBRE_PRODUCTO'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Nombre Producto'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(487631048061383548)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'2427005'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'CODIGO_CORTO:CODIGO_PRODUCTO:NOMBRE_PRODUCTO'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(244995834240140836)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(424610536325923187)
,p_button_name=>'NOTIFICAR'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860056812106557)
,p_button_image_alt=>'Notificar'
,p_icon_css_classes=>'fa-send'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(369570675701034123)
,p_name=>'P603_MODULO'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(369551547832034092)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(424628646537923208)
,p_name=>'P603_ID_REGION'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(369551547832034092)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(478633659663069414)
,p_name=>'P603_EN_VENT_ANT'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_imp.id(369551547832034092)
,p_prompt=>'New'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_03=>'left'
,p_attribute_04=>'decimal'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(478633723410069415)
,p_name=>'P603_ES_ULTIMO_DIA_H'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(369551547832034092)
,p_prompt=>'New'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_03=>'left'
,p_attribute_04=>'decimal'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(478633897773069416)
,p_name=>'P603_INICIO_MES_JDE'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(369551547832034092)
,p_prompt=>'New'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_03=>'left'
,p_attribute_04=>'decimal'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(478633992024069417)
,p_name=>'P603_FIN_MES_JDE'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(369551547832034092)
,p_prompt=>'New'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_03=>'left'
,p_attribute_04=>'decimal'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(478634460343069422)
,p_name=>'P603_FIN_MES_ANTERIOR_JDE'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(369551547832034092)
,p_prompt=>'New'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_03=>'left'
,p_attribute_04=>'decimal'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(478634507975069423)
,p_name=>'P603_INICIO_MES_ANTERIOR_JDE'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(369551547832034092)
,p_prompt=>'New'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_03=>'left'
,p_attribute_04=>'decimal'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(478635053076069428)
,p_name=>'P603_HOY_JDE'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(369551547832034092)
,p_prompt=>'Hoy JDE'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_03=>'left'
,p_attribute_04=>'decimal'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(478635338728069431)
,p_name=>'P603_AYER_JDE'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(369551547832034092)
,p_prompt=>'New'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_03=>'left'
,p_attribute_04=>'decimal'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(478636259573069440)
,p_name=>'P603_PRODUCTIVA'
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_imp.id(369551547832034092)
,p_prompt=>'New'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_03=>'left'
,p_attribute_04=>'decimal'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(486562656186968491)
,p_name=>'P603_BDG_PRODUCTIVA'
,p_item_sequence=>120
,p_item_plug_id=>wwv_flow_imp.id(369551547832034092)
,p_prompt=>'New'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_03=>'left'
,p_attribute_04=>'decimal'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(486766646912511435)
,p_name=>'P603_LOGISTICA'
,p_item_sequence=>130
,p_item_plug_id=>wwv_flow_imp.id(369551547832034092)
,p_prompt=>'New'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_03=>'left'
,p_attribute_04=>'decimal'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(486766769882511436)
,p_name=>'P603_BDG_LOGISTICA'
,p_item_sequence=>140
,p_item_plug_id=>wwv_flow_imp.id(369551547832034092)
,p_prompt=>'New'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(245064242123140911)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_region_id=>wwv_flow_imp.id(455202512374233884)
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>unistr('FACTURAS RETENCI\00D3N - EJECUTIVOS - Save Interactive Grid Data')
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'UPDATE TESTDTA.F03B11@JDECTLDL SET RPRMR1 = :SIG_MES WHERE RPDOC = :FACTURA AND RPAN8 = :NUMERO_CLIENTE AND RPDCT = :RPDCT;',
'-- apex_error.add_error(',
'--     p_message          => ''Registro(s) actualizado(s)''||:SIG_MES,',
'--     p_display_location => apex_error.c_inline_in_notification',
'-- );'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>245064242123140911
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(245001412423140852)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_region_id=>wwv_flow_imp.id(461466187021089388)
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>unistr('NOTAS DE CR\00C9DITO QUE NO SE HAN CRUZADO CON FACTURAS - Save Interactive Grid Data')
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'UPDATE TESTDTA.F03B11@JDECTLDL SET RPRMR1 = :SIG_MES WHERE RPDOC = :FACTURA AND RPAN8 = :NUMERO_CLIENTE AND RPDCT = :RPDCT;',
'-- apex_error.add_error(',
'--     p_message          => ''Registro(s) actualizado(s)''||:SIG_MES,',
'--     p_display_location => apex_error.c_inline_in_notification',
'-- );'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>245001412423140852
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(245253606666141098)
,p_process_sequence=>30
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'NOTIFICAR'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'PK_FINZ_CIERRE_MES.SP_NOTIFICAR_RESPONSABLE(:P603_MODULO,:P603_ID_REGION);',
'apex_application.g_print_success_message := ''Exitoso''||:P603_MODULO||'' ''||:P603_ID_REGION;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(244995834240140836)
,p_internal_uid=>245253606666141098
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(245253270950141097)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Precarga'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE ',
'    V_D_HAB_TRANS NUMBER := 0;',
'    V_ULTIMO_DIA_H DATE;',
'BEGIN',
':P603_INICIO_MES_JDE := TO_NUMBER(TO_CHAR(TRUNC(SYSDATE, ''MM''), ''YYYYDDD'')) - 1900000;',
':P603_AYER_JDE := TO_NUMBER(TO_CHAR(SYSDATE-1, ''YYYYDDD'')) - 1900000;',
':P603_HOY_JDE := TO_NUMBER(TO_CHAR(SYSDATE, ''YYYYDDD'')) - 1900000;',
':P603_FIN_MES_JDE := TO_NUMBER(TO_CHAR(LAST_DAY(SYSDATE), ''YYYYDDD'')) - 1900000;',
'',
':P603_INICIO_MES_ANTERIOR_JDE := TO_NUMBER(TO_CHAR(ADD_MONTHS(TRUNC(SYSDATE, ''MM''), -1), ''YYYYDDD'')) - 1900000;',
':P603_FIN_MES_ANTERIOR_JDE := TO_NUMBER(TO_CHAR(TRUNC(SYSDATE,''MM'')-1,''YYYYDDD''))  - 1900000;',
'',
'',
'',
'    WITH FERIADOS AS (',
'        SELECT TO_DATE(LPAD(TRIM(VALOR), 2, ''0'') || ''/'' || LPAD(TRIM(VALOR2), 2, ''0'') || ''/'' || TO_CHAR(SYSDATE, ''YYYY''), ''DD/MM/YYYY'') AS FECHA',
'        FROM DATA.T_CORP_UDC',
'        WHERE ID_CABECERA = ''ADT_FERIAD'' AND CODIGOCOMPANIA = ''00001'' AND ACTIVO = 1',
'    ),',
'    CALENDARIO AS (',
'        SELECT TRUNC(SYSDATE, ''MM'') + LEVEL - 1 AS FECHA_EVAL',
'        FROM DUAL CONNECT BY TRUNC(SYSDATE, ''MM'') + LEVEL - 1 <= TRUNC(SYSDATE)',
'    ),',
'    ULTIMO_DIA_H AS (',
'        SELECT MAX(FECHA_EVAL) AS FECHA',
'        FROM (SELECT TRUNC(LAST_DAY(SYSDATE)) - LEVEL + 1 AS FECHA_EVAL FROM DUAL CONNECT BY LEVEL <= 31)',
'        WHERE TO_CHAR(FECHA_EVAL,''DY'',''NLS_DATE_LANGUAGE=ENGLISH'') NOT IN (''SAT'',''SUN'')',
'        AND FECHA_EVAL NOT IN (SELECT FECHA FROM FERIADOS)',
'    )',
'    SELECT',
'        (SELECT COUNT(*) FROM CALENDARIO WHERE TO_CHAR(FECHA_EVAL, ''DY'', ''NLS_DATE_LANGUAGE=ENGLISH'') NOT IN (''SAT'', ''SUN'') AND FECHA_EVAL NOT IN (SELECT FECHA FROM FERIADOS)),',
'        (SELECT FECHA FROM ULTIMO_DIA_H)',
'    INTO V_D_HAB_TRANS, V_ULTIMO_DIA_H',
'    FROM DUAL;',
'',
'    :P603_ES_ULTIMO_DIA_H := 0;',
'    IF TRUNC(SYSDATE) = V_ULTIMO_DIA_H THEN',
'        :P603_ES_ULTIMO_DIA_H := 1;',
'    END IF;',
'',
'    :P603_EN_VENT_ANT := 0;',
'    IF V_D_HAB_TRANS <= 5 THEN',
'        :P603_EN_VENT_ANT := 1;',
'    END IF;',
'',
'    :P603_PRODUCTIVA := 0;',
'    IF :P603_MODULO IN (''DMA430'',''DMA510'',''COSME'',''TRANS'') THEN',
'        :P603_PRODUCTIVA := 1;',
'        CASE :P603_MODULO',
'            WHEN ''DMA430'' THEN :P603_BDG_PRODUCTIVA := 17005; --Absorbente',
'            WHEN ''DMA510'' THEN :P603_BDG_PRODUCTIVA := 17016; --Envases',
'            WHEN ''COSME'' THEN :P603_BDG_PRODUCTIVA := 17009; --Cosmetica',
'            WHEN ''TRANS'' THEN :P603_BDG_PRODUCTIVA := 17022; --Transformaciones',
'        END CASE;',
'    END IF;',
'',
'    :P603_LOGISTICA := 0;',
'    IF :P603_MODULO IN (''DOP340'',''DOP339'',''DOP347'') THEN',
'        :P603_LOGISTICA := 1;',
'        CASE :P603_MODULO',
'            WHEN ''DOP340'' THEN :P603_BDG_LOGISTICA:= ''01 ''; --PT',
'            WHEN ''DOP339'' THEN :P603_BDG_LOGISTICA := ''02 ''; --MP',
'            WHEN ''DOP347'' THEN :P603_BDG_LOGISTICA := ''04 ''; --Menores',
'        END CASE;',
'    END IF;',
'',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>245253270950141097
);
wwv_flow_imp.component_end;
end;
/
