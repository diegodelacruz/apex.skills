prompt --application/pages/page_02014
begin
--   Manifest
--     PAGE: 02014
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>109
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_page.create_page(
 p_id=>2014
,p_name=>'Transacciones NO Contabilizadas'
,p_alias=>'TRANSACCIONES-NO-CONTABILIZADAS'
,p_step_title=>'Transacciones NO Contabilizadas'
,p_reload_on_submit=>'A'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_page_component_map=>'18'
,p_created_on=>wwv_flow_imp.dz('20240520133704Z')
,p_last_updated_on=>wwv_flow_imp.dz('20250602201629Z')
,p_last_updated_by=>'JBALCAZAR'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(197066780143512405)
,p_plug_name=>'Transacciones'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(112813843178917343)
,p_plug_display_sequence=>60
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'with prm as (',
'	select to_date(:p2014_anio||:p2014_mes,''yyyymm'') fecha',
'		, pk_commons.f_g2jde(to_date(:p2014_anio||:p2014_mes,''yyyymm'')) jdedsd',
'		, pk_commons.f_g2jde(last_day(to_date(:p2014_anio||:p2014_mes,''yyyymm''))) jdehst',
'	from dual',
') , kdx as (',
'	select decode(ildoco,0,ildoc,ildoco) ildoco',
'		, decode(ildcto,''  '',ildct,ildcto) ildcto',
'		, illnid',
'		, ilitm',
'		, illitm',
'		, ilmcu',
'		, ilglpt',
'		, ilpaid/100 ilpaid',
'		, iltrqt/10000 iltrqt',
'		, iltrum',
'		, ilcrdj',
'		, iluser',
'	from f4111@jdedtadl,prm',
'	where 1 = 1',
'		and ildoc = ildoc',
'		and ildct = ildct',
'		and ilkco = ilkco',
'		and ildgl = 0',
'		and iljeln = iljeln',
'		and ilicu = 0',
'		and ilcrdj between jdedsd and jdehst',
'		and (ilmcu = lpad(:p2014_bodega,12,'' '') or :p2014_bodega is null)',
'		and (ilglpt = lpad(:p2014_tipo,4,'' '') or :p2014_tipo is null)',
'), vta as (',
'	select sddoco',
'		, sddcto',
'		, sdlnid',
'		, sditm',
'		, sdlitm',
'		, sdnxtr',
'		, sdlttr',
'		, sddoc',
'		, sddct',
'		, shhold',
'	from f4211@jdedtadl',
'	left join f4201@jdedtadl on sddoco = shdoco and sddcto = shdcto and sdkcoo = shkcoo and sdlnid = sdlnid',
') select kdx.ildoco',
'	, kdx.ildcto',
'	, kdx.illnid',
'	, kdx.ilitm',
'	, trim(kdx.illitm) illitm',
'	, trim(kdx.ilmcu) ilmcu',
'	, kdx.ilglpt',
'	, kdx.ilpaid',
'	, kdx.iltrqt',
'	, kdx.iltrum',
'	, prd.imuom1 imuom1',
'	, pk_commons.f_jde2g(kdx.ilcrdj) ilcrdj',
'	, kdx.iluser',
'	, vta.sddoco',
'	, vta.sddcto',
'	, vta.sdlnid',
'	, vta.sditm',
'	, trim(vta.sdlitm) sdlitm',
'	, vta.sdnxtr',
'	, vta.sdlttr',
'	, vta.sddoc',
'	, vta.sddct',
'	, trim(vta.shhold) shhold',
'	, case when kdx.iltrum = prd.imuom1 then kdx.iltrqt else pk_invc_inventariocronograma.f_trasnformacionunidades(kdx.illitm,kdx.iltrqt,kdx.iltrum,prd.imuom1) end cantprm',
'from kdx',
'left join vta on ildoco = sddoco and ildcto = sddcto and illnid = sdlnid',
'inner join f4101@jdedtadl prd on ilitm = imitm',
'where 1 = 1',
'	and :p2014_bandera = 1'))
,p_plug_source_type=>'NATIVE_IR'
,p_ajax_items_to_submit=>'P2014_ANIO,P2014_MES,P2014_BODEGA,P2014_TIPO,P2014_BANDERA'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'Transacciones'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
,p_updated_on=>wwv_flow_imp.dz('20240821211358Z')
,p_updated_by=>'JBALCAZAR'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(197067313438512411)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_control_break=>'N'
,p_show_highlight=>'N'
,p_show_computation=>'N'
,p_show_aggregate=>'N'
,p_show_chart=>'N'
,p_show_group_by=>'N'
,p_show_pivot=>'N'
,p_show_flashback=>'N'
,p_show_help=>'N'
,p_download_formats=>'XLSX'
,p_enable_mail_download=>'Y'
,p_owner=>'EMASABANDA'
,p_internal_uid=>197067313438512411
,p_updated_on=>wwv_flow_imp.dz('20240821211358Z')
,p_updated_by=>'JBALCAZAR'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(197067714872512415)
,p_db_column_name=>'ILGLPT'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Tipo Inv.'
,p_column_type=>'STRING'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_rpt_named_lov=>wwv_flow_imp.id(114135955609459248)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(330855341916165840)
,p_db_column_name=>'ILDOCO'
,p_display_order=>50
,p_column_identifier=>'S'
,p_column_label=>'Orden'
,p_column_type=>'NUMBER'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20240705173704Z')
,p_updated_on=>wwv_flow_imp.dz('20240705174117Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(330855486525165841)
,p_db_column_name=>'ILDCTO'
,p_display_order=>60
,p_column_identifier=>'T'
,p_column_label=>'Tipo'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20240705173704Z')
,p_updated_on=>wwv_flow_imp.dz('20240705174117Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(330855543137165842)
,p_db_column_name=>'ILLNID'
,p_display_order=>70
,p_column_identifier=>'U'
,p_column_label=>unistr('L\00EDn.')
,p_column_type=>'NUMBER'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20240705173704Z')
,p_updated_on=>wwv_flow_imp.dz('20240705174117Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(330855631783165843)
,p_db_column_name=>'ILITM'
,p_display_order=>80
,p_column_identifier=>'V'
,p_column_label=>unistr('C\00F3d. Corto')
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20240705173704Z')
,p_updated_on=>wwv_flow_imp.dz('20240705174117Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(330855705574165844)
,p_db_column_name=>'ILLITM'
,p_display_order=>90
,p_column_identifier=>'W'
,p_column_label=>unistr('C\00F3d. Producto')
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20240705173704Z')
,p_updated_on=>wwv_flow_imp.dz('20240705174117Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(330855848248165845)
,p_db_column_name=>'ILMCU'
,p_display_order=>100
,p_column_identifier=>'X'
,p_column_label=>'Bodega'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20240705173704Z')
,p_updated_on=>wwv_flow_imp.dz('20240705174117Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(330855931455165846)
,p_db_column_name=>'ILPAID'
,p_display_order=>110
,p_column_identifier=>'Y'
,p_column_label=>'Costo'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20240705173704Z')
,p_updated_on=>wwv_flow_imp.dz('20240705174117Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(330856057045165847)
,p_db_column_name=>'ILTRQT'
,p_display_order=>120
,p_column_identifier=>'Z'
,p_column_label=>'Cantidad'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20240705173704Z')
,p_updated_on=>wwv_flow_imp.dz('20240705174117Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(330856150695165848)
,p_db_column_name=>'ILTRUM'
,p_display_order=>130
,p_column_identifier=>'AA'
,p_column_label=>'UM'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20240705173704Z')
,p_updated_on=>wwv_flow_imp.dz('20240705174117Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(330856278508165849)
,p_db_column_name=>'ILCRDJ'
,p_display_order=>140
,p_column_identifier=>'AB'
,p_column_label=>'Fecha'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20240705173704Z')
,p_updated_on=>wwv_flow_imp.dz('20240705174117Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(330856331471165850)
,p_db_column_name=>'ILUSER'
,p_display_order=>150
,p_column_identifier=>'AC'
,p_column_label=>'Usuario'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20240705173704Z')
,p_updated_on=>wwv_flow_imp.dz('20240705175327Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(371019225638652401)
,p_db_column_name=>'SDDOCO'
,p_display_order=>160
,p_column_identifier=>'AD'
,p_column_label=>'Sddoco'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20240705173704Z')
,p_updated_on=>wwv_flow_imp.dz('20240705173704Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(371019301343652402)
,p_db_column_name=>'SDDCTO'
,p_display_order=>170
,p_column_identifier=>'AE'
,p_column_label=>'Sddcto'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20240705173704Z')
,p_updated_on=>wwv_flow_imp.dz('20240705173704Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(371019421217652403)
,p_db_column_name=>'SDLNID'
,p_display_order=>180
,p_column_identifier=>'AF'
,p_column_label=>'Sdlnid'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20240705173704Z')
,p_updated_on=>wwv_flow_imp.dz('20240705173704Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(371019546803652404)
,p_db_column_name=>'SDITM'
,p_display_order=>190
,p_column_identifier=>'AG'
,p_column_label=>'Sditm'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20240705173704Z')
,p_updated_on=>wwv_flow_imp.dz('20240705173704Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(371019679736652405)
,p_db_column_name=>'SDLITM'
,p_display_order=>200
,p_column_identifier=>'AH'
,p_column_label=>'Sdlitm'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20240705173704Z')
,p_updated_on=>wwv_flow_imp.dz('20240705173704Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(371019750582652406)
,p_db_column_name=>'SDNXTR'
,p_display_order=>210
,p_column_identifier=>'AI'
,p_column_label=>'Est. Sig.'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20240705174429Z')
,p_updated_on=>wwv_flow_imp.dz('20240705175124Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(371019871639652407)
,p_db_column_name=>'SDLTTR'
,p_display_order=>220
,p_column_identifier=>'AJ'
,p_column_label=>'Est. Ant.'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20240705174429Z')
,p_updated_on=>wwv_flow_imp.dz('20240705175124Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(371019939284652408)
,p_db_column_name=>'SDDOC'
,p_display_order=>230
,p_column_identifier=>'AK'
,p_column_label=>'Documento'
,p_column_type=>'NUMBER'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20240705174429Z')
,p_updated_on=>wwv_flow_imp.dz('20240705175124Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(371020011455652409)
,p_db_column_name=>'SDDCT'
,p_display_order=>240
,p_column_identifier=>'AL'
,p_column_label=>'Tipo Doc.'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20240705174429Z')
,p_updated_on=>wwv_flow_imp.dz('20240705175124Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(371020113052652410)
,p_db_column_name=>'SHHOLD'
,p_display_order=>250
,p_column_identifier=>'AM'
,p_column_label=>unistr('C\00F3d. Ret.')
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20240705174429Z')
,p_updated_on=>wwv_flow_imp.dz('20240705175124Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(371020200253652411)
,p_db_column_name=>'IMUOM1'
,p_display_order=>260
,p_column_identifier=>'AN'
,p_column_label=>'UMP'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20240705183214Z')
,p_updated_on=>wwv_flow_imp.dz('20240705183214Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(371020388096652412)
,p_db_column_name=>'CANTPRM'
,p_display_order=>270
,p_column_identifier=>'AO'
,p_column_label=>'Cant. UM Prim.'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20240705183214Z')
,p_updated_on=>wwv_flow_imp.dz('20240705183214Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(198184898015801840)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'1981849'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'ILCRDJ:ILMCU:ILDCTO:ILDOCO:SDDCT:SDDOC:SDLTTR:SDNXTR:SHHOLD:ILLNID:ILLITM:ILTRUM:ILTRQT:IMUOM1:CANTPRM:ILPAID:'
,p_sort_column_1=>'TIPO_ORDEN'
,p_sort_direction_1=>'ASC'
,p_sort_column_2=>'NUMERO_ORDEN'
,p_sort_direction_2=>'ASC'
,p_sort_column_3=>'0'
,p_sort_direction_3=>'ASC'
,p_sort_column_4=>'0'
,p_sort_direction_4=>'ASC'
,p_sort_column_5=>'0'
,p_sort_direction_5=>'ASC'
,p_sort_column_6=>'0'
,p_sort_direction_6=>'ASC'
,p_created_on=>wwv_flow_imp.dz('20240520133704Z')
,p_updated_on=>wwv_flow_imp.dz('20240705184010Z')
,p_created_by=>'ATOPON'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(332202912581713061)
,p_application_user=>'APXWS_ALTERNATIVE'
,p_name=>'Doc. Retenidos'
,p_report_seq=>10
,p_report_alias=>'3322030'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'ILCRDJ:ILMCU:ILDCTO:ILDOCO:SDDCT:SDDOC:SHHOLD:SDLTTR:SDNXTR:ILLNID:ILLITM:ILPAID:ILTRQT:ILTRUM:ILGLPT:ILUSER:'
,p_sort_column_1=>'TIPO_ORDEN'
,p_sort_direction_1=>'ASC'
,p_sort_column_2=>'NUMERO_ORDEN'
,p_sort_direction_2=>'ASC'
,p_sort_column_3=>'0'
,p_sort_direction_3=>'ASC'
,p_sort_column_4=>'0'
,p_sort_direction_4=>'ASC'
,p_sort_column_5=>'0'
,p_sort_direction_5=>'ASC'
,p_sort_column_6=>'0'
,p_sort_direction_6=>'ASC'
,p_created_on=>wwv_flow_imp.dz('20240530183435Z')
,p_updated_on=>wwv_flow_imp.dz('20240821211358Z')
,p_created_by=>'JBALCAZAR'
,p_updated_by=>'JBALCAZAR'
);
wwv_flow_imp_page.create_worksheet_condition(
 p_id=>wwv_flow_imp.id(416904017200681156)
,p_report_id=>wwv_flow_imp.id(332202912581713061)
,p_condition_type=>'FILTER'
,p_allow_delete=>'Y'
,p_column_name=>'SHHOLD'
,p_operator=>'is not null'
,p_condition_sql=>'"SHHOLD" is not null'
,p_condition_display=>'#APXWS_COL_NAME# #APXWS_OP_NAME#'
,p_enabled=>'Y'
,p_created_on=>wwv_flow_imp.dz('20240821211358Z')
,p_updated_on=>wwv_flow_imp.dz('20240821211358Z')
,p_created_by=>'JBALCAZAR'
,p_updated_by=>'JBALCAZAR'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(197066805890512406)
,p_plug_name=>'Filtros'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(38289867500120143)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
,p_updated_on=>wwv_flow_imp.dz('20240530180301Z')
,p_updated_by=>'JBALCAZAR'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(331318917454309912)
,p_plug_name=>'Barra de accion'
,p_region_template_options=>'#DEFAULT#:t-Form--stretchInputs'
,p_plug_template=>wwv_flow_imp.id(38289497777120142)
,p_plug_display_sequence=>20
,p_plug_display_point=>'REGION_POSITION_01'
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
,p_created_on=>wwv_flow_imp.dz('20240530180301Z')
,p_updated_on=>wwv_flow_imp.dz('20240530180301Z')
,p_created_by=>'JBALCAZAR'
,p_updated_by=>'JBALCAZAR'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(362609851494005432)
,p_plug_name=>'Transacciones no contabilizadas'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(38290610465120145)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'REGION_POSITION_01'
,p_location=>null
,p_menu_id=>wwv_flow_imp.id(37761271469106475)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(37860983999106559)
,p_created_on=>wwv_flow_imp.dz('20240710192507Z')
,p_updated_on=>wwv_flow_imp.dz('20240710192507Z')
,p_created_by=>'JBALCAZAR'
,p_updated_by=>'JBALCAZAR'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(197066624367512404)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(331318917454309912)
,p_button_name=>'Buscar'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860056812106557)
,p_button_image_alt=>'Buscar'
,p_icon_css_classes=>'fa-search'
,p_updated_on=>wwv_flow_imp.dz('20240530180301Z')
,p_updated_by=>'JBALCAZAR'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(331320060420309923)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(197066780143512405)
,p_button_name=>'RETENCION'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860056812106557)
,p_button_image_alt=>'Quitar Retencion'
,p_button_position=>'COPY'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-ban'
,p_created_on=>wwv_flow_imp.dz('20240530183614Z')
,p_updated_on=>wwv_flow_imp.dz('20240705180228Z')
,p_created_by=>'JBALCAZAR'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(197066930339512407)
,p_name=>'P2014_BODEGA'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(197066805890512406)
,p_prompt=>'Bodega'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'LOV_JDE_BODEGAS'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select CODUNIDAD ||'' - ''||DESCRIPCION , CODUNIDAD from vt_jde_bodegas',
'order by 1'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'Todo'
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_updated_on=>wwv_flow_imp.dz('20240705181143Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(197067059325512408)
,p_name=>'P2014_TIPO'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(197066805890512406)
,p_prompt=>'Tipo Producto'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select drky||'' - ''||drdl01 d,drky r',
'from vt_jde_udcjde@datadl',
'where drsy = ''41'' and drrt = ''9'' and instr(drky,''IN'') > 0',
'order by 1'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'Todo'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_updated_on=>wwv_flow_imp.dz('20240705181143Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(197067191493512409)
,p_name=>'P2014_ANIO'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(197066805890512406)
,p_prompt=>unistr('A\00F1o')
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'with lov as (',
'	select to_number(to_char(sysdate,''yyyy'')) - level + 1 anno from dual connect by level < 6',
') select anno d, anno r from lov order by 1 desc'))
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'NONE'
,p_updated_on=>wwv_flow_imp.dz('20240705181143Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(197067226075512410)
,p_name=>'P2014_MES'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(197066805890512406)
,p_item_default=>'to_number(to_char(sysdate,''mm''))'
,p_item_default_type=>'EXPRESSION'
,p_item_default_language=>'PLSQL'
,p_prompt=>'Mes'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'with lov as (',
'	select to_char(to_date(level,''mm''),''month'') mes, level num from dual connect by level < 13',
') select mes, num from lov order by num'))
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'NONE'
,p_updated_on=>wwv_flow_imp.dz('20240705181143Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(201722867492546819)
,p_name=>'P2014_BANDERA'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(197066805890512406)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
,p_updated_on=>wwv_flow_imp.dz('20240710192554Z')
,p_updated_by=>'JBALCAZAR'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(331320193455309924)
,p_name=>unistr('Quitar retenci\00F3n')
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(331320060420309923)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
,p_created_on=>wwv_flow_imp.dz('20240530184208Z')
,p_updated_on=>wwv_flow_imp.dz('20240530184713Z')
,p_created_by=>'JBALCAZAR'
,p_updated_by=>'JBALCAZAR'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(331320291954309925)
,p_event_id=>wwv_flow_imp.id(331320193455309924)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_CONFIRM'
,p_attribute_01=>unistr('\00BFEsta seguro de quitar el c\00F3digo de retenci\00F3n de las DS?')
,p_created_on=>wwv_flow_imp.dz('20240530184208Z')
,p_updated_on=>wwv_flow_imp.dz('20240530184208Z')
,p_created_by=>'JBALCAZAR'
,p_updated_by=>'JBALCAZAR'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(331320436067309927)
,p_event_id=>wwv_flow_imp.id(331320193455309924)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_01=>'RETENCION'
,p_attribute_02=>'Y'
,p_created_on=>wwv_flow_imp.dz('20240530184208Z')
,p_updated_on=>wwv_flow_imp.dz('20240530184713Z')
,p_created_by=>'JBALCAZAR'
,p_updated_by=>'JBALCAZAR'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(362609571940005429)
,p_name=>'Page Load'
,p_event_sequence=>20
,p_bind_type=>'bind'
,p_bind_event_type=>'ready'
,p_created_on=>wwv_flow_imp.dz('20240710192212Z')
,p_updated_on=>wwv_flow_imp.dz('20240710192212Z')
,p_created_by=>'JBALCAZAR'
,p_updated_by=>'JBALCAZAR'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(362609642296005430)
,p_event_id=>wwv_flow_imp.id(362609571940005429)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>':P2014_BANDERA :=1;'
,p_attribute_02=>'P2014_BANDERA'
,p_attribute_03=>'P2014_BANDERA'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
,p_created_on=>wwv_flow_imp.dz('20240710192212Z')
,p_updated_on=>wwv_flow_imp.dz('20240710192212Z')
,p_created_by=>'JBALCAZAR'
,p_updated_by=>'JBALCAZAR'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(362609721682005431)
,p_event_id=>wwv_flow_imp.id(362609571940005429)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(197066780143512405)
,p_created_on=>wwv_flow_imp.dz('20240710192212Z')
,p_updated_on=>wwv_flow_imp.dz('20240710192212Z')
,p_created_by=>'JBALCAZAR'
,p_updated_by=>'JBALCAZAR'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(331320562846309928)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Quitar Retencion'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'update f4201@jdedtadl set shhold = '' ''',
'where shdcto = ''DS''	and trim(shhold) is not null 	and to_date(shtrdj + 1900000, ''yyyyddd'')  > sysdate-45;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(331320060420309923)
,p_internal_uid=>331320562846309928
,p_created_on=>wwv_flow_imp.dz('20240530184529Z')
,p_updated_on=>wwv_flow_imp.dz('20250602201629Z')
,p_created_by=>'JBALCAZAR'
,p_updated_by=>'JBALCAZAR'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(362609400839005428)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Cargar datos'
,p_process_sql_clob=>':P2014_BANDERA :=0;'
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>362609400839005428
,p_created_on=>wwv_flow_imp.dz('20240710192117Z')
,p_updated_on=>wwv_flow_imp.dz('20240710192117Z')
,p_created_by=>'JBALCAZAR'
,p_updated_by=>'JBALCAZAR'
);
wwv_flow_imp.component_end;
end;
/
