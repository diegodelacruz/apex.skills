prompt --application/pages/page_5200230
begin
--   Manifest
--     PAGE: 5200230
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>109
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_page.create_page(
 p_id=>5200230
,p_tab_set=>'TS1'
,p_name=>'Gastos por Marca'
,p_step_title=>'Gastos por Marca'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_page_component_map=>'03'
,p_created_on=>wwv_flow_imp.dz('20230705164636Z')
,p_last_updated_on=>wwv_flow_imp.dz('20260723203929Z')
,p_last_updated_by=>'CVACA'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(5966564807289096)
,p_plug_name=>'Filtros'
,p_region_template_options=>'#DEFAULT#'
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(5966682527289096)
,p_name=>'Gastos por Marca'
,p_display_sequence=>20
,p_component_template_options=>'#DEFAULT#'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT X.*,Z.NOMBRE,Y.ID_PAIS,Y.ID_MARCASLEGAL',
'FROM dp.T_LEGAL_GASTOSPORMARCA X,dp.T_DETALLEMARCAS Y,dp.T_MARCASLEGAL Z',
'WHERE ID_DETALLEMARCAS=Y.ID',
'AND Z.ID=Y.MARCA',
'AND X.COMPANIA=:G_CIA',
'AND (ID_PAIS=:P5200230_PAIS OR :P5200230_PAIS=''Todos'')-- is null)',
'AND (PRIORIDAD=:P5200230_GRUPO OR :P5200230_GRUPO=''Todos'')-- is null)',
'AND (Y.MARCA=:P5200230_MARCA OR :P5200230_MARCA=''Todas'')-- is null)',
'AND FECHA_CREA BETWEEN :P5200230_FECDESDE AND :P5200230_FECHASTA'))
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_show_nulls_as=>'-'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'Y'
,p_csv_output_link_text=>'Exportar a CSV'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_exp_filename=>'Gastos por marca'
,p_plug_query_exp_separator=>';'
,p_plug_query_strip_html=>'N'
,p_updated_on=>wwv_flow_imp.dz('20260723203929Z')
,p_updated_by=>'CVACA'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(5966745298289096)
,p_query_column_id=>1
,p_column_alias=>'ID'
,p_column_display_sequence=>1
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(5966885013289096)
,p_query_column_id=>2
,p_column_alias=>'DETALLE'
,p_column_display_sequence=>4
,p_column_heading=>'Detalle'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(5966981146289096)
,p_query_column_id=>3
,p_column_alias=>'VALOR'
,p_column_display_sequence=>5
,p_column_heading=>'Valor'
,p_use_as_row_header=>'N'
,p_column_format=>'999G999G999G999G990D00'
,p_disable_sort_column=>'N'
,p_sum_column=>'Y'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(5967075301289096)
,p_query_column_id=>4
,p_column_alias=>'ID_DETALLEMARCAS'
,p_column_display_sequence=>6
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(5967151096289096)
,p_query_column_id=>5
,p_column_alias=>'FECHA_CREA'
,p_column_display_sequence=>7
,p_column_heading=>'Fecha Gasto'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(5967205869289096)
,p_query_column_id=>6
,p_column_alias=>'USER_CREA'
,p_column_display_sequence=>8
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(5967327376289098)
,p_query_column_id=>7
,p_column_alias=>'FECHA_MODIFICA'
,p_column_display_sequence=>9
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(5967439683289098)
,p_query_column_id=>8
,p_column_alias=>'USER_MODIFICA'
,p_column_display_sequence=>10
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(5967502486289098)
,p_query_column_id=>9
,p_column_alias=>'COMPANIA'
,p_column_display_sequence=>11
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(5967645048289098)
,p_query_column_id=>10
,p_column_alias=>'NOMBRE'
,p_column_display_sequence=>2
,p_column_heading=>'Marca'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(5967788855289098)
,p_query_column_id=>11
,p_column_alias=>'ID_PAIS'
,p_column_display_sequence=>12
,p_column_heading=>'Pais'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_display_as=>'TEXT_FROM_LOV_ESC'
,p_named_lov=>wwv_flow_imp.id(107473624465608868)
,p_derived_column=>'N'
,p_include_in_export=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20260723203301Z')
,p_updated_by=>'CVACA'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(5967860926289098)
,p_query_column_id=>12
,p_column_alias=>'ID_MARCASLEGAL'
,p_column_display_sequence=>3
,p_column_heading=>'Sub Marca'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_display_as=>'TEXT_FROM_LOV_ESC'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(5967903384289098)
,p_plug_name=>'Breadcrumb'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_source_type=>'NATIVE_BREADCRUMB'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(5968136355289113)
,p_button_sequence=>10
,p_button_name=>'RESUMEN'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(5968079975289099)
,p_button_image_alt=>'Resumen'
,p_button_position=>'LEGACY_ORPHAN_COMPONENTS'
,p_button_alignment=>'RIGHT'
,p_button_condition_type=>'NEVER'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(5968270943289113)
,p_name=>'P5200230_PAIS'
,p_item_sequence=>10
,p_item_display_point=>'LEGACY_ORPHAN_COMPONENTS'
,p_prompt=>unistr('Pa\00EDs: ')
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'LOV_FINZ_PAISES'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select DESCRIPCION, CODIGO',
'  from VT_LEG_PAISES'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'Todos'
,p_lov_null_value=>'Todos'
,p_cHeight=>1
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'NONE'
,p_updated_on=>wwv_flow_imp.dz('20260723203301Z')
,p_updated_by=>'CVACA'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(5968363236289113)
,p_name=>'P5200230_GRUPO'
,p_item_sequence=>10
,p_item_display_point=>'LEGACY_ORPHAN_COMPONENTS'
,p_prompt=>'Grupo: '
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'LOV_GRUPO_CLIENTES'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'  select DISTINCT CODIGOGRUPO||''-''||GRUPO  as d,',
'       CODIGOGRUPO as r',
'  from VT_JDE_CLIENTE',
' order by 1'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'Todos'
,p_lov_null_value=>'Todos'
,p_cHeight=>1
,p_lov_display_extra=>'YES'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'NONE'
,p_updated_on=>wwv_flow_imp.dz('20260723203617Z')
,p_updated_by=>'CVACA'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(5968440444289113)
,p_name=>'P5200230_MARCA'
,p_item_sequence=>10
,p_item_display_point=>'LEGACY_ORPHAN_COMPONENTS'
,p_prompt=>'Marca: '
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_updated_on=>wwv_flow_imp.dz('20260723203735Z')
,p_updated_by=>'CVACA'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(5968534929289113)
,p_name=>'P5200230_FECDESDE'
,p_item_sequence=>10
,p_item_display_point=>'LEGACY_ORPHAN_COMPONENTS'
,p_prompt=>'Fecha desde: '
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_label_alignment=>'RIGHT-CENTER'
,p_field_alignment=>'LEFT-CENTER'
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(5968612027289115)
,p_name=>'P5200230_FECHASTA'
,p_item_sequence=>10
,p_item_display_point=>'LEGACY_ORPHAN_COMPONENTS'
,p_prompt=>'Fecha hasta: '
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_label_alignment=>'RIGHT-CENTER'
,p_field_alignment=>'LEFT-CENTER'
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_imp.component_end;
end;
/
