prompt --application/pages/page_00452
begin
--   Manifest
--     PAGE: 00452
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>109
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_page.create_page(
 p_id=>452
,p_name=>'PYG INDUSTRIALES - DLG - BASE DISTRIBUCION'
,p_alias=>'PYG-INDUSTRIALES-DLG-BASE-DISTRIBUCION1'
,p_page_mode=>'MODAL'
,p_step_title=>unistr('Otros Rubros - Condicionantes de Distribuci\00F3n')
,p_autocomplete_on_off=>'OFF'
,p_javascript_code_onload=>wwv_flow_string.join(wwv_flow_t_varchar2(
'var regiones = [',
'    "tbCondicDistribucion"',
'];',
'for (var i = 0; i < regiones.length; i++) {',
'    var region = apex.region(regiones[i]);',
'',
'    if (region) {',
'        let grid = region.widget();',
'        let actions = grid.interactiveGrid("getActions");',
'        actions.hide("save");',
'    }',
'}',
'',
'$(secItems).hide();'))
,p_step_template=>wwv_flow_imp.id(37774372912106498)
,p_page_template_options=>'#DEFAULT#:t-Dialog--noPadding'
,p_dialog_width=>'60%'
,p_dialog_chained=>'N'
,p_protection_level=>'C'
,p_page_component_map=>'21'
,p_created_on=>wwv_flow_imp.dz('20260309194649Z')
,p_last_updated_on=>wwv_flow_imp.dz('20260325195333Z')
,p_created_by=>'DDELACRUZ'
,p_last_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(752499759650936835)
,p_plug_name=>'Barra de Accion'
,p_region_template_options=>'#DEFAULT#:t-Form--stretchInputs'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(38289497777120142)
,p_plug_display_sequence=>40
,p_plug_display_point=>'REGION_POSITION_01'
,p_location=>null
,p_menu_id=>wwv_flow_imp.id(37761271469106475)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(37860983999106559)
,p_ai_enabled=>false
,p_created_on=>wwv_flow_imp.dz('20260309200849Z')
,p_updated_on=>wwv_flow_imp.dz('20260325195333Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(761074696915535604)
,p_plug_name=>'Items'
,p_region_name=>'secItems'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(38289867500120143)
,p_plug_display_sequence=>20
,p_location=>null
,p_ai_enabled=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
,p_created_on=>wwv_flow_imp.dz('20260309194649Z')
,p_updated_on=>wwv_flow_imp.dz('20260325194806Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(773628386536423416)
,p_plug_name=>'Botones'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(38290276266120143)
,p_plug_display_sequence=>50
,p_plug_display_point=>'REGION_POSITION_03'
,p_location=>null
,p_ai_enabled=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
,p_created_on=>wwv_flow_imp.dz('20260311162725Z')
,p_updated_on=>wwv_flow_imp.dz('20260311162853Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1129655119978953900)
,p_plug_name=>'OTROS_GASTOS_MODU'
,p_title=>'OTROS_GASTOS'
,p_region_name=>'tbCondicDistribucion'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(37806762584106520)
,p_plug_display_sequence=>10
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select     SEQ_ID,  ',
'    C001, ',
'    C002, ',
'    C003, ',
'    C004, ',
'    C005, ',
'    C006,',
'    C007,',
'    C008,   ',
'    C009,',
'    C010,',
'    C011,',
'    C012,',
'    C013,',
'    C014,',
'    C020',
'FROM APEX_COLLECTIONS ',
'WHERE COLLECTION_NAME = ''COLECCION_REGLASCOND''',
' '))
,p_plug_source_type=>'NATIVE_IG'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'OTROS_GASTOS'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
,p_ai_enabled=>false
,p_created_on=>wwv_flow_imp.dz('20260309194650Z')
,p_updated_on=>wwv_flow_imp.dz('20260325195333Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(1129655306722953902)
,p_name=>'APEX$ROW_SELECTOR'
,p_session_state_data_type=>'VARCHAR2'
,p_item_type=>'NATIVE_ROW_SELECTOR'
,p_display_sequence=>10
,p_attribute_01=>'Y'
,p_attribute_02=>'Y'
,p_attribute_03=>'N'
,p_updated_on=>wwv_flow_imp.dz('20260309194650Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(1129655467521953903)
,p_name=>'APEX$ROW_ACTION'
,p_session_state_data_type=>'VARCHAR2'
,p_item_type=>'NATIVE_ROW_ACTION'
,p_display_sequence=>20
,p_updated_on=>wwv_flow_imp.dz('20260309194650Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(1129655551205953904)
,p_name=>'SEQ_ID'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'SEQ_ID'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_DISPLAY_ONLY'
,p_heading=>'Seq Id'
,p_heading_alignment=>'CENTER'
,p_display_sequence=>30
,p_value_alignment=>'LEFT'
,p_attribute_02=>'VALUE'
,p_attribute_05=>'PLAIN'
,p_enable_filter=>false
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_enable_hide=>false
,p_is_primary_key=>true
,p_duplicate_value=>true
,p_include_in_export=>false
,p_updated_on=>wwv_flow_imp.dz('20260309194650Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(1129655652834953905)
,p_name=>'C001'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'C001'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_SELECT_LIST'
,p_heading=>'Tipo Venta'
,p_heading_alignment=>'CENTER'
,p_display_sequence=>40
,p_value_alignment=>'LEFT'
,p_is_required=>true
,p_lov_type=>'SHARED'
,p_lov_id=>wwv_flow_imp.id(121710145807591205)
,p_lov_display_extra=>true
,p_lov_display_null=>true
,p_lov_null_text=>'Seleccione'
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'LOV'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
,p_updated_on=>wwv_flow_imp.dz('20260309194650Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(1129655742614953906)
,p_name=>'C002'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'C002'
,p_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_SELECT_LIST'
,p_heading=>'Nivel 01'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>50
,p_value_alignment=>'LEFT'
,p_is_required=>false
,p_lov_type=>'SHARED'
,p_lov_id=>wwv_flow_imp.id(119193859528059131)
,p_lov_display_extra=>true
,p_lov_display_null=>true
,p_enable_filter=>false
,p_filter_is_required=>false
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
,p_updated_on=>wwv_flow_imp.dz('20260310175911Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(1129655835403953907)
,p_name=>'C003'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'C003'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_CHECKBOX'
,p_heading=>'Nivel 02'
,p_heading_alignment=>'CENTER'
,p_display_sequence=>60
,p_value_alignment=>'LEFT'
,p_attribute_01=>'1'
,p_is_required=>false
,p_lov_type=>'SHARED'
,p_lov_id=>wwv_flow_imp.id(119194387269080626)
,p_lov_display_extra=>true
,p_multi_value_type=>'SEPARATED'
,p_multi_value_separator=>','
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'LOV'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
,p_escape_on_http_output=>true
,p_updated_on=>wwv_flow_imp.dz('20260309194650Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(1129655953856953908)
,p_name=>'C004'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'C004'
,p_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_CHECKBOX'
,p_heading=>'Cta. Contable MCU'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>70
,p_value_alignment=>'LEFT'
,p_attribute_01=>'2'
,p_is_required=>false
,p_lov_type=>'SQL_QUERY'
,p_lov_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select distinct MCMCU||'' - ''||trim(MCDL01)MCDL01,trim(MCMCU)MCMCU',
'from f0006@jdedtadl',
'order by 2;'))
,p_lov_display_extra=>true
,p_multi_value_type=>'SEPARATED'
,p_multi_value_separator=>','
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'LOV'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
,p_escape_on_http_output=>true
,p_updated_on=>wwv_flow_imp.dz('20260310185715Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(1129656143108953910)
,p_name=>'C006'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'C006'
,p_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_SELECT_LIST'
,p_heading=>'Cta. Contable AUX'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>90
,p_value_alignment=>'LEFT'
,p_is_required=>false
,p_lov_type=>'SQL_QUERY'
,p_lov_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT distinct',
'     trim(GMSUB)||'' - ''|| trim(GMDL01) d, trim(GMSUB) r',
'FROM f0901@jdedtadl a',
'WHERE 1=1',
'and trim(GMSUB) is NOT null',
'and trim(GMOBJ) in (select item from table(pk_commons.f_dividirtexto(:C005,'','')))',
'and trim(GMMCU) in (select item from table(pk_commons.f_dividirtexto(:C004,'','')))',
'order by 1'))
,p_lov_display_extra=>true
,p_lov_display_null=>true
,p_lov_cascade_parent_items=>'C005,C004'
,p_ajax_optimize_refresh=>true
,p_filter_is_required=>false
,p_use_as_row_header=>false
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
,p_updated_on=>wwv_flow_imp.dz('20260310175334Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(1130837096578320964)
,p_name=>'C020'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'C020'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>'Comentario (Opcional)'
,p_heading_alignment=>'CENTER'
,p_display_sequence=>190
,p_value_alignment=>'LEFT'
,p_attribute_05=>'BOTH'
,p_attribute_06=>'UPPER'
,p_is_required=>false
,p_max_length=>4000
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
,p_updated_on=>wwv_flow_imp.dz('20260309194650Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(1130838663653320979)
,p_name=>'C009'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'C009'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>'MCU Cliente'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>130
,p_value_alignment=>'LEFT'
,p_attribute_05=>'BOTH'
,p_is_required=>false
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>false
,p_updated_on=>wwv_flow_imp.dz('20260309194650Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(1130839224366320985)
,p_name=>'C005'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'C005'
,p_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_SELECT_LIST'
,p_heading=>'Cta. Contable OBJ'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>80
,p_value_alignment=>'LEFT'
,p_is_required=>false
,p_lov_type=>'SQL_QUERY'
,p_lov_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT distinct',
'     trim(GMOBJ)||'' - ''|| trim(GMDL01) d, trim(GMOBJ) r',
'FROM f0901@jdedtadl a',
'WHERE 1=1',
'and trim(GMSUB) is null',
'and trim(GMMCU) in (select item from table(pk_commons.f_dividirtexto(:C004,'','')))',
'order by 1'))
,p_lov_display_extra=>true
,p_lov_display_null=>true
,p_lov_cascade_parent_items=>'C004'
,p_ajax_items_to_submit=>'C004'
,p_ajax_optimize_refresh=>true
,p_filter_is_required=>false
,p_use_as_row_header=>false
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
,p_updated_on=>wwv_flow_imp.dz('20260310175334Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(1136831107047438292)
,p_name=>'C010'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'C010'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>'Rp7'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>140
,p_value_alignment=>'LEFT'
,p_attribute_05=>'BOTH'
,p_is_required=>false
,p_max_length=>4000
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
,p_updated_on=>wwv_flow_imp.dz('20260309194650Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(1136831239387438293)
,p_name=>'C011'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'C011'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>'C011'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>150
,p_value_alignment=>'LEFT'
,p_attribute_05=>'BOTH'
,p_is_required=>false
,p_max_length=>4000
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
,p_updated_on=>wwv_flow_imp.dz('20260309194650Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(1136831308973438294)
,p_name=>'C012'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'C012'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>'C012'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>160
,p_value_alignment=>'LEFT'
,p_attribute_05=>'BOTH'
,p_is_required=>false
,p_max_length=>4000
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
,p_updated_on=>wwv_flow_imp.dz('20260309194650Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(1136831469755438295)
,p_name=>'C013'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'C013'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>'C013'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>170
,p_value_alignment=>'LEFT'
,p_attribute_05=>'BOTH'
,p_is_required=>false
,p_max_length=>4000
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
,p_updated_on=>wwv_flow_imp.dz('20260309194650Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(1136831476962438296)
,p_name=>'C014'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'C014'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>'C014'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>180
,p_value_alignment=>'LEFT'
,p_attribute_05=>'BOTH'
,p_is_required=>false
,p_max_length=>4000
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
,p_updated_on=>wwv_flow_imp.dz('20260309194650Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(1136831859522438299)
,p_name=>'C007'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'C007'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>'Origen'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>100
,p_value_alignment=>'LEFT'
,p_attribute_05=>'BOTH'
,p_is_required=>false
,p_max_length=>4000
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
,p_updated_on=>wwv_flow_imp.dz('20260309194650Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(1136831909715438300)
,p_name=>'C008'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'C008'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>'Canal'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>110
,p_value_alignment=>'LEFT'
,p_attribute_05=>'BOTH'
,p_is_required=>false
,p_max_length=>4000
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
,p_updated_on=>wwv_flow_imp.dz('20260309194650Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_interactive_grid(
 p_id=>wwv_flow_imp.id(1129655206459953901)
,p_internal_uid=>1129655206459953901
,p_is_editable=>true
,p_edit_operations=>'i:u:d'
,p_lost_update_check_type=>'VALUES'
,p_add_row_if_empty=>false
,p_submit_checked_rows=>false
,p_lazy_loading=>false
,p_requires_filter=>false
,p_select_first_row=>true
,p_fixed_row_height=>true
,p_pagination_type=>'SET'
,p_show_total_row_count=>true
,p_show_toolbar=>true
,p_enable_save_public_report=>false
,p_enable_subscriptions=>true
,p_enable_flashback=>true
,p_define_chart_view=>false
,p_enable_download=>false
,p_download_formats=>null
,p_fixed_header=>'PAGE'
,p_show_icon_view=>false
,p_show_detail_view=>false
,p_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'function (config) {',
'	return cargarToolbar(config);',
'}'))
,p_updated_on=>wwv_flow_imp.dz('20260310141946Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_ig_report(
 p_id=>wwv_flow_imp.id(1130843977284323385)
,p_interactive_grid_id=>wwv_flow_imp.id(1129655206459953901)
,p_static_id=>'3616081'
,p_type=>'PRIMARY'
,p_default_view=>'GRID'
,p_rows_per_page=>1000
,p_show_row_number=>false
,p_settings_area_expanded=>true
,p_updated_on=>wwv_flow_imp.dz('20260309165402Z')
,p_updated_by=>'EMASABANDA'
);
wwv_flow_imp_page.create_ig_report_view(
 p_id=>wwv_flow_imp.id(1130844241753323391)
,p_report_id=>wwv_flow_imp.id(1130843977284323385)
,p_view_type=>'GRID'
,p_stretch_columns=>true
,p_srv_exclude_null_values=>false
,p_srv_only_display_columns=>true
,p_edit_mode=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(1130845100967323411)
,p_view_id=>wwv_flow_imp.id(1130844241753323391)
,p_display_seq=>1
,p_column_id=>wwv_flow_imp.id(1129655467521953903)
,p_is_visible=>true
,p_is_frozen=>true
,p_width=>40
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(1130845974463323416)
,p_view_id=>wwv_flow_imp.id(1130844241753323391)
,p_display_seq=>2
,p_column_id=>wwv_flow_imp.id(1129655551205953904)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>53
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(1130846922051323419)
,p_view_id=>wwv_flow_imp.id(1130844241753323391)
,p_display_seq=>3
,p_column_id=>wwv_flow_imp.id(1129655652834953905)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>100
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(1130847703714323422)
,p_view_id=>wwv_flow_imp.id(1130844241753323391)
,p_display_seq=>4
,p_column_id=>wwv_flow_imp.id(1129655742614953906)
,p_is_visible=>false
,p_is_frozen=>false
,p_width=>370
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(1130848624392323427)
,p_view_id=>wwv_flow_imp.id(1130844241753323391)
,p_display_seq=>5
,p_column_id=>wwv_flow_imp.id(1129655835403953907)
,p_is_visible=>false
,p_is_frozen=>false
,p_width=>205
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(1130849521162323432)
,p_view_id=>wwv_flow_imp.id(1130844241753323391)
,p_display_seq=>6
,p_column_id=>wwv_flow_imp.id(1129655953856953908)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(1130851333742323440)
,p_view_id=>wwv_flow_imp.id(1130844241753323391)
,p_display_seq=>8
,p_column_id=>wwv_flow_imp.id(1129656143108953910)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>124
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(1130854932040323455)
,p_view_id=>wwv_flow_imp.id(1130844241753323391)
,p_display_seq=>13
,p_column_id=>wwv_flow_imp.id(1130837096578320964)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(1131495233444429459)
,p_view_id=>wwv_flow_imp.id(1130844241753323391)
,p_display_seq=>9
,p_column_id=>wwv_flow_imp.id(1130838663653320979)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(1132872679249941280)
,p_view_id=>wwv_flow_imp.id(1130844241753323391)
,p_display_seq=>7
,p_column_id=>wwv_flow_imp.id(1130839224366320985)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>101
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(1137516607358012558)
,p_view_id=>wwv_flow_imp.id(1130844241753323391)
,p_display_seq=>12
,p_column_id=>wwv_flow_imp.id(1136831107047438292)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(1137517471583012562)
,p_view_id=>wwv_flow_imp.id(1130844241753323391)
,p_display_seq=>14
,p_column_id=>wwv_flow_imp.id(1136831239387438293)
,p_is_visible=>false
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(1137518418177012565)
,p_view_id=>wwv_flow_imp.id(1130844241753323391)
,p_display_seq=>15
,p_column_id=>wwv_flow_imp.id(1136831308973438294)
,p_is_visible=>false
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(1137519277240012569)
,p_view_id=>wwv_flow_imp.id(1130844241753323391)
,p_display_seq=>16
,p_column_id=>wwv_flow_imp.id(1136831469755438295)
,p_is_visible=>false
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(1137520235690012572)
,p_view_id=>wwv_flow_imp.id(1130844241753323391)
,p_display_seq=>17
,p_column_id=>wwv_flow_imp.id(1136831476962438296)
,p_is_visible=>false
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(1137660839208407345)
,p_view_id=>wwv_flow_imp.id(1130844241753323391)
,p_display_seq=>10
,p_column_id=>wwv_flow_imp.id(1136831859522438299)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(1137661745790407352)
,p_view_id=>wwv_flow_imp.id(1130844241753323391)
,p_display_seq=>11
,p_column_id=>wwv_flow_imp.id(1136831909715438300)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(384903077877090986)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(773628386536423416)
,p_button_name=>'Cerrar'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860181880106559)
,p_button_image_alt=>'Cerrar'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-arrow-left'
,p_created_on=>wwv_flow_imp.dz('20260309200849Z')
,p_updated_on=>wwv_flow_imp.dz('20260311162907Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(376253366963576944)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(752499759650936835)
,p_button_name=>'Guardar'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860056812106557)
,p_button_image_alt=>'Guardar'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_icon_css_classes=>'fa-save'
,p_created_on=>wwv_flow_imp.dz('20260310141552Z')
,p_updated_on=>wwv_flow_imp.dz('20260310141552Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(404654179490870702)
,p_name=>'P452_NUMREGLA'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(761074696915535604)
,p_prompt=>'Numregla'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_created_on=>wwv_flow_imp.dz('20260325190829Z')
,p_updated_on=>wwv_flow_imp.dz('20260325190829Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(761075472510535940)
,p_name=>'P452_SEQ_ID'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(761074696915535604)
,p_prompt=>'Seq Id'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_ai_enabled=>false
,p_created_on=>wwv_flow_imp.dz('20260309194649Z')
,p_updated_on=>wwv_flow_imp.dz('20260309194649Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(761078269007535968)
,p_name=>'P452_TIPO'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(761074696915535604)
,p_prompt=>'Tipo'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_ai_enabled=>false
,p_created_on=>wwv_flow_imp.dz('20260309194649Z')
,p_updated_on=>wwv_flow_imp.dz('20260309194649Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(761078624733535972)
,p_name=>'P452_CLOB'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(761074696915535604)
,p_prompt=>'Clob'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_ai_enabled=>false
,p_created_on=>wwv_flow_imp.dz('20260309194649Z')
,p_updated_on=>wwv_flow_imp.dz('20260309194649Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(386065089475380810)
,p_name=>'Cerrar'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(384903077877090986)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
,p_created_on=>wwv_flow_imp.dz('20260310175423Z')
,p_updated_on=>wwv_flow_imp.dz('20260325194741Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(386065172426380811)
,p_event_id=>wwv_flow_imp.id(386065089475380810)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CLOSE'
,p_created_on=>wwv_flow_imp.dz('20260310175424Z')
,p_updated_on=>wwv_flow_imp.dz('20260310175424Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(384844154335959182)
,p_process_sequence=>10
,p_process_point=>'AFTER_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Setup Interface'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE ',
'	l_rec  apex_collections%ROWTYPE;',
'BEGIN',
'	:P452_NUMREGLA:=:G_VALORRGN;',
'	IF APEX_COLLECTION.COLLECTION_EXISTS(''COLECCION_REGLASCOND'') THEN APEX_COLLECTION.DELETE_COLLECTION(''COLECCION_REGLASCOND''); END IF;',
'	IF NOT  APEX_COLLECTION.COLLECTION_EXISTS(''COLECCION_REGLASCOND'') THEN APEX_COLLECTION.CREATE_COLLECTION  (''COLECCION_REGLASCOND''); END IF;',
'	IF      APEX_COLLECTION.COLLECTION_EXISTS(''COLECCION_REGLASCOND'') THEN APEX_COLLECTION.TRUNCATE_COLLECTION(''COLECCION_REGLASCOND''); END IF;',
'	begin',
'		SELECT *',
'		INTO   l_rec',
'		FROM   apex_collections',
'		WHERE  collection_name = ''COLECCION_REGLAS''||:P452_NUMREGLA||''DIST''',
'		AND    seq_id = :P452_SEQ_ID;',
'	end;',
'',
'	 FOR COLS IN ( ',
'	        SELECT ',
'	             ID',
'				,TIPOVENTA C001',
'				,NIVEL01	C002',
'				,NIVEL02	C003',
'				,CTACONMCU	C004',
'				,CTACONOBJ	C005',
'				,CTACONSUB	C006',
'				,ORIGEN	C007',
'				,CANAL	C008',
'				,CTAMCU	C009',
'				,RP7		C010',
'				,COMENTARI	C020',
'	        FROM JSON_TABLE( l_rec.C021,''$[*]''',
'            COLUMNS  (',
'	                ID          NUMBER         PATH ''$.ID''',
'	                ,TIPOVENTA  VARCHAR2(3999) PATH ''$.TIPOVENTA''',
'	                ,NIVEL01   	VARCHAR2(3999) PATH ''$.NIVEL01''',
'	                ,NIVEL02   	VARCHAR2(3999) PATH ''$.NIVEL02''',
'	                ,CTACONMCU  VARCHAR2(3999) PATH ''$.CTACONMCU''',
'	                ,CTACONOBJ  VARCHAR2(3999) PATH ''$.CTACONOBJ''',
'	                ,CTACONSUB  VARCHAR2(3999) PATH ''$.CTACONSUB'' ',
'	                ,ORIGEN       VARCHAR2(3999) PATH ''$.ORIGEN''',
'	                ,CANAL       VARCHAR2(3999) PATH ''$.CANAL''',
'	                ,CTAMCU       VARCHAR2(3999) PATH ''$.CTAMCU''',
'					,RP7       		VARCHAR2(3999) PATH ''$.RP7''	',
'	                ,COMENTARI  VARCHAR2(3999) PATH ''$.COMENTARI''',
'	            )',
'	        ) ORDER BY ID',
'	    )LOOP',
'	        APEX_COLLECTION.ADD_MEMBER(',
'	            p_collection_name =>''COLECCION_REGLASCOND'',',
'	            p_c001 => COLS.c001,',
'	            p_c002 => COLS.c002,',
'	            p_c003 => COLS.c003,',
'	            p_c004 => COLS.c004,',
'	            p_c005 => COLS.c005,',
'	            p_c006 => COLS.c006,',
'	            p_c007 => COLS.c007,',
'	            p_c008 => COLS.c008,',
'	            p_c009 => COLS.c009,',
'	            p_c010 => COLS.c010,',
'				p_c020 => COLS.c020',
'	        );',
'	    END LOOP;',
'',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>384844154335959182
,p_created_on=>wwv_flow_imp.dz('20260309194651Z')
,p_updated_on=>wwv_flow_imp.dz('20260325195318Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(384835261329959114)
,p_process_sequence=>40
,p_process_point=>'AFTER_SUBMIT'
,p_region_id=>wwv_flow_imp.id(1129655119978953900)
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'OTROS_GASTOS - MOD'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare ',
'    v_APEXROW_STATUS varchar2(399);',
'    v_nombrecoleccion varchar2(399):=''COLECCION_REGLASCOND'';',
'BEGIN',
'    v_APEXROW_STATUS:=:APEX$ROW_STATUS;',
'    case v_APEXROW_STATUS  ',
'        WHEN ''C'' THEN APEX_COLLECTION.ADD_MEMBER   (p_collection_name => v_nombrecoleccion                 ,p_C001=>trim(upper(:C001)),p_C002=>trim(upper(:C002)),p_C003=>trim(upper(:C003)),p_C004=>trim(upper(:C004)),p_C005=>trim(upper(:C005)),p_C006='
||'>trim(upper(:C006)),p_C007=>trim(upper(:C007)),p_C008=>trim(upper(:C008)),p_C009=>trim(upper(:C009)),p_C010=>trim(upper(:C010)),p_C011=>trim(upper(:C011)),p_C012=>trim(upper(:C012)),p_C013=>trim(upper(:C013)),p_C014=>trim(upper(:C014)),p_C020=>trim(u'
||'pper(:C020) ) );',
'        WHEN ''U'' THEN APEX_COLLECTION.UPDATE_MEMBER(p_collection_name => v_nombrecoleccion,p_seq => :seq_id,p_C001=>trim(upper(:C001)),p_C002=>trim(upper(:C002)),p_C003=>trim(upper(:C003)),p_C004=>trim(upper(:C004)),p_C005=>trim(upper(:C005)),p_C006='
||'>trim(upper(:C006)),p_C007=>trim(upper(:C007)),p_C008=>trim(upper(:C008)),p_C009=>trim(upper(:C009)),p_C010=>trim(upper(:C010)),p_C011=>trim(upper(:C011)),p_C012=>trim(upper(:C012)),p_C013=>trim(upper(:C013)),p_C014=>trim(upper(:C014)),p_C020=>trim(u'
||'pper(:C020) ) );',
'        WHEN ''D'' THEN APEX_COLLECTION.DELETE_MEMBER(p_collection_name => v_nombrecoleccion,p_seq => :seq_id);',
'    END CASE;',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_type=>'NEVER'
,p_only_for_changed_rows=>'N'
,p_internal_uid=>384835261329959114
,p_created_on=>wwv_flow_imp.dz('20260309194650Z')
,p_updated_on=>wwv_flow_imp.dz('20260325194706Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(376253087646576941)
,p_process_sequence=>50
,p_process_point=>'AFTER_SUBMIT'
,p_region_id=>wwv_flow_imp.id(1129655119978953900)
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Datos'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare ',
'    v_APEXROW_STATUS varchar2(399);',
'	l_rec  apex_collections%ROWTYPE;',
'	l_json_final CLOB;',
'	l_json  CLOB;',
'BEGIN',
' ',
'		SELECT JSON_ARRAYAGG(',
'           JSON_OBJECT(',
'             ''FLAG''      VALUE collection_name,',
'             ''ID''        VALUE seq_id,',
'             ''TIPOVENTA'' VALUE c001,',
'			 ''NIVEL01''   VALUE c002,',
'             ''NIVEL02''   VALUE c003,',
'			 ''CTACONMCU'' VALUE c004,',
'             ''CTACONOBJ'' VALUE c005,',
'			 ''CTACONSUB'' VALUE c006,',
'             ''ORIGEN''    VALUE c007,',
'			 ''CANAL''     VALUE c008,',
'             ''CTAMCU''    VALUE c009,',
'             ''RP7''       VALUE c010,',
'			 ''COMENTARI'' VALUE c020',
'           RETURNING CLOB)',
'         RETURNING CLOB',
'         )',
'	    INTO l_json_final',
'	    FROM apex_collections',
'	   WHERE collection_name = ''COLECCION_REGLASCOND'';',
'   SELECT *',
'   INTO   l_rec',
'   FROM   apex_collections',
'   WHERE  collection_name = ''COLECCION_REGLAS''||:P452_NUMREGLA||''DIST''',
'   AND    seq_id = :P452_SEQ_ID;',
'',
'',
'   APEX_COLLECTION.UPDATE_MEMBER(',
'       p_collection_name => ''COLECCION_REGLAS''||:P452_NUMREGLA||''DIST'',',
'       p_seq             => :P452_SEQ_ID,',
'       p_c001            => l_rec.c001,p_c002            => l_rec.c002,',
'       p_c003            => l_rec.c003,p_c004            => l_rec.c004,',
'       p_c005            => l_rec.c005,p_c006            => l_rec.c006,',
'       p_c007            => l_rec.c007,p_c008            => l_rec.c008,',
'       p_c009            => l_rec.c009,p_c010            => l_rec.c010,',
'       p_c011            => l_rec.c011,p_c012            => l_rec.c012,',
'       p_c013            => l_rec.c013,p_c014            => l_rec.c014,',
'       p_c015            => l_rec.c015,',
'	   p_clob001         =>  l_rec.clob001,',
'	   p_c021            => l_json_final',
'   );',
'	BEGIN',
'	    l_json:= pk_finz_distribucion.f_traer_jsonReglasDist(:P447_REGLANUMERO);',
'	    IF(:P452_NUMREGLA=1)THEN :G_VALOR1  := l_json;END IF;',
'	    IF(:P452_NUMREGLA=2)THEN :G_VALOR2  := l_json;END IF;',
'	    IF(:P452_NUMREGLA=3)THEN :G_VALOR3  := l_json;END IF;',
'	    IF(:P452_NUMREGLA=4)THEN :G_VALOR4  := l_json;END IF;',
'	    IF(:P452_NUMREGLA=5)THEN :G_VALOR5  := l_json;END IF;',
'	END;   ',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_type=>'NEVER'
,p_internal_uid=>376253087646576941
,p_created_on=>wwv_flow_imp.dz('20260309200237Z')
,p_updated_on=>wwv_flow_imp.dz('20260325194706Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp.component_end;
end;
/
