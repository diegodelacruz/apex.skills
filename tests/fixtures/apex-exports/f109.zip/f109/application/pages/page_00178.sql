prompt --application/pages/page_00178
begin
--   Manifest
--     PAGE: 00178
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>109
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_page.create_page(
 p_id=>178
,p_name=>unistr('Validaci\00F3n Pre-Orden')
,p_alias=>unistr('VALIDACI\00D3N-PRE-ORDEN')
,p_step_title=>unistr('Validaci\00F3n Pre-Orden')
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_page_component_map=>'21'
,p_created_on=>wwv_flow_imp.dz('20250619143808Z')
,p_last_updated_on=>wwv_flow_imp.dz('20250801184916Z')
,p_created_by=>'DBURBANO'
,p_last_updated_by=>'DBURBANO'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(74392842249550412)
,p_plug_name=>'Filtros'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(38289867500120143)
,p_plug_display_sequence=>10
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
,p_created_on=>wwv_flow_imp.dz('20250619144129Z')
,p_updated_on=>wwv_flow_imp.dz('20250619144455Z')
,p_created_by=>'DBURBANO'
,p_updated_by=>'DBURBANO'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(74393470642550418)
,p_plug_name=>'BarraHerramientas'
,p_region_template_options=>'#DEFAULT#:t-Form--stretchInputs'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(38289497777120142)
,p_plug_display_sequence=>20
,p_location=>null
,p_menu_id=>wwv_flow_imp.id(37761271469106475)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(37860983999106559)
,p_created_on=>wwv_flow_imp.dz('20250619175815Z')
,p_updated_on=>wwv_flow_imp.dz('20250619175815Z')
,p_created_by=>'DBURBANO'
,p_updated_by=>'DBURBANO'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(75141164521513982)
,p_plug_name=>'Breadcrumb'
,p_title=>unistr('Validaci\00F3n Pre-Orden Producci\00F3n')
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(37817215439106526)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_location=>null
,p_menu_id=>wwv_flow_imp.id(37761271469106475)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(37860983999106559)
,p_created_on=>wwv_flow_imp.dz('20250619143808Z')
,p_updated_on=>wwv_flow_imp.dz('20250619143903Z')
,p_created_by=>'DBURBANO'
,p_updated_by=>'DBURBANO'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(75141893368513988)
,p_plug_name=>unistr('Validaci\00F3n Pre-Orden')
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(37806762584106520)
,p_plug_display_sequence=>30
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT t.itm, TRIM(t.item) Item, TRIM(i.imdsc1) || '' '' || TRIM(i.imdsc2) Descripcion, MATRICULADO, COSTOGENERAL, COSTO_P, COSTO_I, COSTOCOMP',
'--     , MATRICULADO || COSTOGENERAL || COSTO_P || COSTO_I || COSTOCOMP AS valid',
'     , DECODE(t.codigoerror, ''OKOKOKOK'', ''OK'', ''NOVEDAD'') AS valid',
'  FROM data.t_manf_tmpvldcst t, f4101@jdedtadl i',
' WHERE t.usuario = :app_user',
'   AND t.programa = ''VLSCST''',
'   AND t.itm = i.imitm',
'   AND (:P178_SE = ''Y'' or t.codigoerror <> ''OKOKOKOK'') --:P178_SE marcado (Y) Mostrar todo, Desmarcado () Solo errores'))
,p_plug_source_type=>'NATIVE_IG'
,p_prn_page_header=>unistr('Validaci\00F3n Pre-Orden')
,p_created_on=>wwv_flow_imp.dz('20250619143808Z')
,p_updated_on=>wwv_flow_imp.dz('20250710153853Z')
,p_created_by=>'DBURBANO'
,p_updated_by=>'DBURBANO'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(75143144447514009)
,p_name=>'APEX$ROW_SELECTOR'
,p_item_type=>'NATIVE_ROW_SELECTOR'
,p_display_sequence=>10
,p_attribute_01=>'Y'
,p_attribute_02=>'Y'
,p_attribute_03=>'N'
,p_enable_hide=>true
,p_is_primary_key=>false
,p_updated_on=>wwv_flow_imp.dz('20250619143809Z')
,p_updated_by=>'DBURBANO'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(75143538365514009)
,p_name=>'APEX$ROW_ACTION'
,p_item_type=>'NATIVE_ROW_ACTION'
,p_label=>'Actions'
,p_heading_alignment=>'CENTER'
,p_display_sequence=>20
,p_value_alignment=>'CENTER'
,p_enable_hide=>true
,p_is_primary_key=>false
,p_updated_on=>wwv_flow_imp.dz('20250619143809Z')
,p_updated_by=>'DBURBANO'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(80192006458419513)
,p_name=>'ITEM'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'ITEM'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_DISPLAY_ONLY'
,p_heading=>'Item'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>40
,p_value_alignment=>'LEFT'
,p_attribute_02=>'VALUE'
,p_attribute_05=>'PLAIN'
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>true
,p_duplicate_value=>true
,p_include_in_export=>true
,p_updated_on=>wwv_flow_imp.dz('20250625162350Z')
,p_updated_by=>'DBURBANO'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(80192179370419514)
,p_name=>'DESCRIPCION'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'DESCRIPCION'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_DISPLAY_ONLY'
,p_heading=>'Descripcion'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>60
,p_value_alignment=>'LEFT'
,p_attribute_02=>'VALUE'
,p_attribute_05=>'PLAIN'
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
,p_updated_on=>wwv_flow_imp.dz('20250625163521Z')
,p_updated_by=>'DBURBANO'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(80192629025419519)
,p_name=>'MATRICULADO'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'MATRICULADO'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_DISPLAY_ONLY'
,p_heading=>'Matriculado'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>70
,p_value_alignment=>'LEFT'
,p_attribute_02=>'VALUE'
,p_attribute_05=>'PLAIN'
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
,p_updated_on=>wwv_flow_imp.dz('20250625163521Z')
,p_updated_by=>'DBURBANO'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(80192729982419520)
,p_name=>'COSTOGENERAL'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'COSTOGENERAL'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_DISPLAY_ONLY'
,p_heading=>'Costogeneral'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>80
,p_value_alignment=>'LEFT'
,p_attribute_02=>'VALUE'
,p_attribute_05=>'PLAIN'
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
,p_updated_on=>wwv_flow_imp.dz('20250625163521Z')
,p_updated_by=>'DBURBANO'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(80192862077419521)
,p_name=>'COSTO_P'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'COSTO_P'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_DISPLAY_ONLY'
,p_heading=>'Costo P'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>90
,p_value_alignment=>'LEFT'
,p_attribute_02=>'VALUE'
,p_attribute_05=>'PLAIN'
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
,p_updated_on=>wwv_flow_imp.dz('20250625163521Z')
,p_updated_by=>'DBURBANO'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(80192980914419522)
,p_name=>'COSTO_I'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'COSTO_I'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_DISPLAY_ONLY'
,p_heading=>'Costo I'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>100
,p_value_alignment=>'LEFT'
,p_attribute_02=>'VALUE'
,p_attribute_05=>'PLAIN'
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
,p_updated_on=>wwv_flow_imp.dz('20250625163521Z')
,p_updated_by=>'DBURBANO'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(80193057573419523)
,p_name=>'COSTOCOMP'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'COSTOCOMP'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>110
,p_attribute_01=>'Y'
,p_filter_is_required=>false
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>false
,p_updated_on=>wwv_flow_imp.dz('20250709213030Z')
,p_updated_by=>'DBURBANO'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(80193101272419524)
,p_name=>'ITM'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'ITM'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_DISPLAY_ONLY'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>30
,p_value_alignment=>'LEFT'
,p_attribute_02=>'VALUE'
,p_attribute_05=>'PLAIN'
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>false
,p_updated_on=>wwv_flow_imp.dz('20250709160832Z')
,p_updated_by=>'DBURBANO'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(80193385808419526)
,p_name=>'VALID'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'VALID'
,p_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>'Valid'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>120
,p_value_alignment=>'LEFT'
,p_attribute_05=>'BOTH'
,p_is_required=>false
,p_max_length=>100
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
,p_updated_on=>wwv_flow_imp.dz('20250625163521Z')
,p_updated_by=>'DBURBANO'
);
wwv_flow_imp_page.create_interactive_grid(
 p_id=>wwv_flow_imp.id(75142358610513989)
,p_internal_uid=>75142358610513989
,p_is_editable=>true
,p_lost_update_check_type=>'VALUES'
,p_submit_checked_rows=>false
,p_lazy_loading=>false
,p_requires_filter=>false
,p_select_first_row=>true
,p_fixed_row_height=>true
,p_pagination_type=>'SCROLL'
,p_show_total_row_count=>true
,p_show_toolbar=>true
,p_enable_save_public_report=>false
,p_enable_subscriptions=>true
,p_enable_flashback=>true
,p_define_chart_view=>true
,p_enable_download=>true
,p_enable_mail_download=>true
,p_fixed_header=>'PAGE'
,p_show_icon_view=>false
,p_show_detail_view=>false
,p_updated_on=>wwv_flow_imp.dz('20250710153853Z')
,p_updated_by=>'DBURBANO'
);
wwv_flow_imp_page.create_ig_report(
 p_id=>wwv_flow_imp.id(75142741244513990)
,p_interactive_grid_id=>wwv_flow_imp.id(75142358610513989)
,p_static_id=>'751428'
,p_type=>'PRIMARY'
,p_default_view=>'GRID'
,p_show_row_number=>false
,p_settings_area_expanded=>true
,p_updated_on=>wwv_flow_imp.dz('20250709211149Z')
,p_updated_by=>'DBURBANO'
);
wwv_flow_imp_page.create_ig_report_view(
 p_id=>wwv_flow_imp.id(75142934190513993)
,p_report_id=>wwv_flow_imp.id(75142741244513990)
,p_view_type=>'GRID'
,p_stretch_columns=>true
,p_srv_exclude_null_values=>false
,p_srv_only_display_columns=>true
,p_edit_mode=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(48387172196197)
,p_view_id=>wwv_flow_imp.id(75142934190513993)
,p_display_seq=>10
,p_column_id=>wwv_flow_imp.id(80193385808419526)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(75143994838514012)
,p_view_id=>wwv_flow_imp.id(75142934190513993)
,p_display_seq=>1
,p_column_id=>wwv_flow_imp.id(75143538365514009)
,p_is_visible=>true
,p_is_frozen=>true
,p_width=>40
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(81859017963694708)
,p_view_id=>wwv_flow_imp.id(75142934190513993)
,p_display_seq=>3
,p_column_id=>wwv_flow_imp.id(80192006458419513)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>99.851
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(81859985249694717)
,p_view_id=>wwv_flow_imp.id(75142934190513993)
,p_display_seq=>4
,p_column_id=>wwv_flow_imp.id(80192179370419514)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(82613025839847094)
,p_view_id=>wwv_flow_imp.id(75142934190513993)
,p_display_seq=>5
,p_column_id=>wwv_flow_imp.id(80192629025419519)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(82613889717847103)
,p_view_id=>wwv_flow_imp.id(75142934190513993)
,p_display_seq=>6
,p_column_id=>wwv_flow_imp.id(80192729982419520)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(82614765755847109)
,p_view_id=>wwv_flow_imp.id(75142934190513993)
,p_display_seq=>7
,p_column_id=>wwv_flow_imp.id(80192862077419521)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(82615679533847112)
,p_view_id=>wwv_flow_imp.id(75142934190513993)
,p_display_seq=>8
,p_column_id=>wwv_flow_imp.id(80192980914419522)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(82616534579847115)
,p_view_id=>wwv_flow_imp.id(75142934190513993)
,p_display_seq=>9
,p_column_id=>wwv_flow_imp.id(80193057573419523)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(82620437329857136)
,p_view_id=>wwv_flow_imp.id(75142934190513993)
,p_display_seq=>2
,p_column_id=>wwv_flow_imp.id(80193101272419524)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>76.983
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(74393560608550419)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(74393470642550418)
,p_button_name=>'Buscar'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860056812106557)
,p_button_image_alt=>'Buscar'
,p_icon_css_classes=>'fa-search'
,p_grid_new_row=>'Y'
,p_grid_column=>11
,p_created_on=>wwv_flow_imp.dz('20250619182943Z')
,p_updated_on=>wwv_flow_imp.dz('20250709211025Z')
,p_created_by=>'DBURBANO'
,p_updated_by=>'DBURBANO'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(80193651175419529)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(74393470642550418)
,p_button_name=>'Corregir'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860056812106557)
,p_button_image_alt=>'Corregir'
,p_icon_css_classes=>'fa-tools'
,p_grid_new_row=>'N'
,p_grid_column=>12
,p_created_on=>wwv_flow_imp.dz('20250708183201Z')
,p_updated_on=>wwv_flow_imp.dz('20250708183510Z')
,p_created_by=>'DBURBANO'
,p_updated_by=>'DBURBANO'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(74392946504550413)
,p_name=>'P178_DIVISION'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(74392842249550412)
,p_prompt=>unistr('Divisi\00F3n (componentes activos de toda la divisi\00F3n):')
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'STATIC:ABSORBENTE;17005,COSMETICA;17009,ENVASES;17016'
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_created_on=>wwv_flow_imp.dz('20250619144153Z')
,p_updated_on=>wwv_flow_imp.dz('20250619145410Z')
,p_created_by=>'DBURBANO'
,p_updated_by=>'DBURBANO'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(74393137253550415)
,p_name=>'P178_ITEM'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(74392842249550412)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
,p_created_on=>wwv_flow_imp.dz('20250619145641Z')
,p_updated_on=>wwv_flow_imp.dz('20250625165121Z')
,p_created_by=>'DBURBANO'
,p_updated_by=>'DBURBANO'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(74393284755550416)
,p_name=>'P178_OT'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(74392842249550412)
,p_prompt=>'Orden de trabajo:'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT o.wadcto || ''-'' || o.wadoco || ''-'' || o.wasrst || ''-'' || TRIM(o.wadl01) || ''-'' || TRIM(o.wamcu) || ''-'' || TRIM(m.iwlocn) || ''-'' || TO_CHAR(TO_DATE(o.wadcg + 1900000, ''yyyyddd''), ''DD/MM/YYYY'') D',
'     , o.wadoco R',
'  FROM f4801@jdedtadl o',
'  LEFT JOIN f30006@jdedtadl m ON m.iwmcu = o.wamcu ',
' WHERE o.wasrst <= ''80''',
'   AND o.wadcg > TO_CHAR(SYSDATE,''YYYYDDD'')-1900000 - 30 '))
,p_lov_display_null=>'YES'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'POPUP'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_04=>'N'
,p_attribute_05=>'N'
,p_created_on=>wwv_flow_imp.dz('20250619175011Z')
,p_updated_on=>wwv_flow_imp.dz('20250626124642Z')
,p_created_by=>'DBURBANO'
,p_updated_by=>'DBURBANO'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(74393309231550417)
,p_name=>'P178_OTCB'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(74392842249550412)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
,p_created_on=>wwv_flow_imp.dz('20250619175208Z')
,p_updated_on=>wwv_flow_imp.dz('20250723125605Z')
,p_created_by=>'DBURBANO'
,p_updated_by=>'DBURBANO'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(80192237544419515)
,p_name=>'P178_BODEGA'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(74392842249550412)
,p_prompt=>'Bodega'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
,p_created_on=>wwv_flow_imp.dz('20250624230724Z')
,p_updated_on=>wwv_flow_imp.dz('20250723125605Z')
,p_created_by=>'DBURBANO'
,p_updated_by=>'DBURBANO'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(80194089611419533)
,p_name=>'P178_SLC'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(74392842249550412)
,p_prompt=>unistr('Selecci\00F3n:')
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_created_on=>wwv_flow_imp.dz('20250708185308Z')
,p_updated_on=>wwv_flow_imp.dz('20250709195742Z')
,p_created_by=>'DBURBANO'
,p_updated_by=>'DBURBANO'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(80194155268419534)
,p_name=>'P178_SE'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(74392842249550412)
,p_prompt=>'Mostrar Todo:'
,p_display_as=>'NATIVE_SINGLE_CHECKBOX'
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_created_on=>wwv_flow_imp.dz('20250709195644Z')
,p_updated_on=>wwv_flow_imp.dz('20250723125647Z')
,p_created_by=>'DBURBANO'
,p_updated_by=>'DBURBANO'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(110121223056243141)
,p_name=>'P178_MT'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(74392842249550412)
,p_prompt=>'MT'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_created_on=>wwv_flow_imp.dz('20250723125605Z')
,p_updated_on=>wwv_flow_imp.dz('20250723130712Z')
,p_created_by=>'DBURBANO'
,p_updated_by=>'DBURBANO'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(80193814560419531)
,p_name=>'da_select'
,p_event_sequence=>10
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(75141893368513988)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'NATIVE_IG|REGION TYPE|interactivegridselectionchange'
,p_created_on=>wwv_flow_imp.dz('20250708185229Z')
,p_updated_on=>wwv_flow_imp.dz('20250708185809Z')
,p_created_by=>'DBURBANO'
,p_updated_by=>'DBURBANO'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(80193900779419532)
,p_event_id=>wwv_flow_imp.id(80193814560419531)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'var i, i_ids = ":", i_id,',
'model = this.data.model;',
'for ( i = 0; i < this.data.selectedRecords.length; i++ ) {',
'    i_id = model.getValue( this.data.selectedRecords[i], "ITEM");',
'    i_ids += model.getValue( this.data.selectedRecords[i], "ITEM") + ":";',
'}',
'apex.item( "P178_SLC" ).setValue (i_ids);',
''))
,p_created_on=>wwv_flow_imp.dz('20250708185229Z')
,p_updated_on=>wwv_flow_imp.dz('20250708185809Z')
,p_created_by=>'DBURBANO'
,p_updated_by=>'DBURBANO'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(80194220758419535)
,p_name=>'New'
,p_event_sequence=>20
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P178_SE'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
,p_created_on=>wwv_flow_imp.dz('20250709212716Z')
,p_updated_on=>wwv_flow_imp.dz('20250709212716Z')
,p_created_by=>'DBURBANO'
,p_updated_by=>'DBURBANO'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(80194308797419536)
,p_event_id=>wwv_flow_imp.id(80194220758419535)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_02=>'Y'
,p_created_on=>wwv_flow_imp.dz('20250709212716Z')
,p_updated_on=>wwv_flow_imp.dz('20250709212716Z')
,p_created_by=>'DBURBANO'
,p_updated_by=>'DBURBANO'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(80194548773419538)
,p_name=>'New_1'
,p_event_sequence=>30
,p_bind_type=>'bind'
,p_bind_event_type=>'ready'
,p_created_on=>wwv_flow_imp.dz('20250710184344Z')
,p_updated_on=>wwv_flow_imp.dz('20250710191141Z')
,p_created_by=>'DBURBANO'
,p_updated_by=>'DBURBANO'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(80194691814419539)
,p_event_id=>wwv_flow_imp.id(80194548773419538)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DELETE data.t_manf_tmpvldcst WHERE USUARIO = :app_user;',
'COMMIT;',
''))
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
,p_server_condition_type=>'EXPRESSION'
,p_server_condition_expr1=>'1=2'
,p_server_condition_expr2=>'PLSQL'
,p_created_on=>wwv_flow_imp.dz('20250710184345Z')
,p_updated_on=>wwv_flow_imp.dz('20250710191141Z')
,p_created_by=>'DBURBANO'
,p_updated_by=>'DBURBANO'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(75145512830514018)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_region_id=>wwv_flow_imp.id(75141893368513988)
,p_process_type=>'NATIVE_IG_DML'
,p_process_name=>unistr('Validaci\00F3n Pre-Orden - Save Interactive Grid Data')
,p_attribute_01=>'REGION_SOURCE'
,p_attribute_05=>'Y'
,p_attribute_06=>'Y'
,p_attribute_08=>'Y'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>75145512830514018
,p_created_on=>wwv_flow_imp.dz('20250619143809Z')
,p_updated_on=>wwv_flow_imp.dz('20250619143809Z')
,p_created_by=>'DBURBANO'
,p_updated_by=>'DBURBANO'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(74393778355550421)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Buscar'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'estorden VARCHAR2(10);',
'v_itml VARCHAR2(25);',
'v_itm NUMBER;',
'v_lm VARCHAR2(25); --Lista materiales',
'v_ruta VARCHAR2(25); ',
'v_bdg VARCHAR2(30);',
'v_mqn VARCHAR2(30);',
'',
'BEGIN',
'',
'DELETE data.t_manf_tmpvldcst WHERE USUARIO = :app_user;',
'COMMIT;',
'',
unistr('IF NOT :P178_DIVISION IS NULL THEN -- TODOS LOS COMPONENTES DE LA DIVISI\00D3N'),
'    INSERT INTO data.t_manf_tmpvldcst (USUARIO, PROGRAMA, ITEM, ITM)',
unistr('    SELECT DISTINCT :app_user, ''VLSCST'', L.ixlitm, L.ixitm --Componentes que est\00E1n en listas de materiales de productos activos dela divisi\00F3n elegida envase'),
'      FROM f3002@jdedtadl L',
'     WHERE TO_CHAR(sysdate,''YYYYDDD'')-1900000 BETWEEN L.ixefff AND L.ixefft',
'       AND L.ixkit IN (SELECT i.imitm',
'                         FROM f4101@jdedtadl i',
'                        WHERE i.imstkt NOT IN (''X'', ''O'') -- no Obsoleto + Producto terminado y semielaborado de la division',
'                          AND i.imglpt IN (SELECT ''IN30'' FROM DUAL WHERE :P178_DIVISION = ''17005'' UNION ALL',
'                                           SELECT ''IN40'' FROM DUAL WHERE :P178_DIVISION = ''17005'' UNION ALL',
'                                           SELECT ''IN60'' FROM DUAL WHERE :P178_DIVISION = ''17009'' UNION ALL',
'                                           SELECT ''IN80'' FROM DUAL WHERE :P178_DIVISION = ''17009'' UNION ALL',
'                                           SELECT ''IN65'' FROM DUAL WHERE :P178_DIVISION = ''17016'' UNION ALL',
'                                           SELECT ''IN85'' FROM DUAL WHERE :P178_DIVISION = ''17016''))',
'    ;',
'    COMMIT;',
'    :P178_BODEGA := LPAD(:P178_DIVISION, 12);',
unistr('    --apex_application.g_print_success_message :=''Consulta por Divisi\00F3n generada con \00E9xito!'';'),
'    :P178_OT := '''';',
'    PK_MANF_PREVOP.SP_REVISA(:app_user, :P178_BODEGA);',
'    RETURN;',
'END IF;',
'IF NOT :P178_OT IS NULL THEN ',
'    SELECT wasrst, waitm, walitm, wamcu, wammcu, watbm, watrt INTO estorden, v_itm, v_itml, v_mqn, v_bdg, v_lm, v_ruta',
'      FROM f4801@jdedtadl',
'      WHERE wadoco = :P178_OT;',
'    :P178_BODEGA := LPAD(v_bdg, 12);',
'    IF estorden = ''05'' THEN --SI LA ORDEN NO TIENE mp LOS INSERTO DESDE LA LISTA DE AMTERIALES',
'        INSERT INTO data.t_manf_tmpvldcst (USUARIO, PROGRAMA, ITEM, ITM)',
'        SELECT :app_user, ''VLSCST'', ixlitm, ixitm',
'          FROM f3002@jdedtadl l',
'         WHERE l.ixkit = v_itm',
'           AND l.ixtbm = v_lm',
'           AND l.ixmmcu = :P178_BODEGA',
'           AND l.ixcoby <> ''C''',
'           AND TO_CHAR(sysdate,''YYYYDDD'')-1900000 BETWEEN l.ixefff AND l.ixefft;',
'    ELSE --SI LA ORDEN YA TIENE mp LOS INSERTO DESDE MP POR ORDE',
'        INSERT INTO data.t_manf_tmpvldcst (USUARIO, PROGRAMA, ITEM, ITM)',
'        SELECT :app_user, ''VLSCST'', wmcpil, wmcpit',
'          FROM f3111@jdedtadl',
'         WHERE wmdoco = :P178_OT;',
'    END IF;',
'    PK_MANF_PREVOP.SP_REVISA(:app_user, :P178_BODEGA);',
'    RETURN;',
'END IF;',
'',
'IF NOT :P178_MT IS NULL THEN ',
'    SELECT phmcu INTO v_bdg',
'      FROM f4301@jdedtadl',
'      WHERE phdoco = :P178_MT AND phdcto = ''MT'';',
'    :P178_BODEGA := LPAD(v_bdg, 12);',
'    INSERT INTO data.t_manf_tmpvldcst (USUARIO, PROGRAMA, ITEM, ITM)',
'    SELECT :app_user, ''VLSCST'', pdlitm, pditm',
'      FROM f4311@jdedtadl ',
'     WHERE pddcto = ''MT''',
'       AND pddoco = :P178_MT;',
'    PK_MANF_PREVOP.SP_REVISA(:app_user, :P178_BODEGA);',
'    RETURN;',
'END IF;',
'END;',
''))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(74393560608550419)
,p_internal_uid=>74393778355550421
,p_created_on=>wwv_flow_imp.dz('20250619201911Z')
,p_updated_on=>wwv_flow_imp.dz('20250801184916Z')
,p_created_by=>'DBURBANO'
,p_updated_by=>'DBURBANO'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(80193753290419530)
,p_process_sequence=>40
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Corregir'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    l_string VARCHAR2(1000) := :P178_SLC;',
'    l_counter NUMBER := 1;',
'    v_itm VARCHAR2(25);',
'    v_coderr VARCHAR2(200);',
'    v_err1 VARCHAR2(1000) := '''';',
'    v_estado VARCHAR2(1000) := '''';',
'BEGIN',
'    LOOP',
'        v_itm := REGEXP_SUBSTR(l_string, ''[^:]+'', 1, l_counter);',
'        EXIT WHEN v_itm IS NULL;',
'        SELECT codigoerror INTO v_coderr FROM data.t_manf_tmpvldcst WHERE usuario = :app_user AND item = RPAD(v_itm, 25);',
'        v_estado := '''';',
'        PK_MANF_PREVOP.SP_CORRIJE(v_itm, :P178_BODEGA, v_coderr, v_estado);',
'        l_counter := l_counter + 1;',
'        v_err1 := v_err1 || '' '' || v_estado;',
'    END LOOP;',
'    v_err1 := REPLACE(v_err1, ''OK'', '''');',
'    IF TRIM(v_err1) IS NULL THEN ',
unistr('        apex_application.g_print_success_message := ''PROCESO TERMIN\00D3 SIN NOVEDADES.'';'),
'    ELSE',
'        apex_application.g_print_success_message := v_err1;',
'    END IF;',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(80193651175419529)
,p_internal_uid=>80193753290419530
,p_created_on=>wwv_flow_imp.dz('20250708183615Z')
,p_updated_on=>wwv_flow_imp.dz('20250710182034Z')
,p_created_by=>'DBURBANO'
,p_updated_by=>'DBURBANO'
);
wwv_flow_imp.component_end;
end;
/
