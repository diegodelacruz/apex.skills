prompt --application/pages/page_01100
begin
--   Manifest
--     PAGE: 01100
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>109
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_page.create_page(
 p_id=>1100
,p_name=>'Costeo'
,p_step_title=>'Costeo'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_page_component_map=>'18'
,p_created_on=>wwv_flow_imp.dz('20230705164635Z')
,p_last_updated_on=>wwv_flow_imp.dz('20250408184213Z')
,p_last_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(350296285366527464)
,p_plug_name=>'Reporte Costeo'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(38289867500120143)
,p_plug_display_sequence=>20
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'with var as (select distinct idcab from t_finz_costeodif)',
'select a.id',
'	, a.compania',
'	, a.anno',
'	, a.mes',
'	, a.numeroversion',
'	, a.codigoestado',
'	, a.codigoestadovar',
'	, a.ultimousuario',
'	, a.numerobatchjde',
unistr('	, decode(a.codigoestadovar,null,null,''<span title="Ver Variaci\00F3n" style="color: #CD5C5C;" class="fa fa-clipboard-chart"/><span>'') urlicon'),
'from t_finz_costeocab a left join var b on a.id = b.idcab',
'where compania = :g_compania-- and (anno = :p1100_anno or :p1100_anno is null) and (mes = :p1100_mes or :p1100_mes is null)',
'order by anno desc, mes desc, id desc'))
,p_plug_source_type=>'NATIVE_IR'
,p_updated_on=>wwv_flow_imp.dz('20250408184213Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(350296329113527464)
,p_name=>'Costeo'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'C'
,p_show_control_break=>'N'
,p_show_highlight=>'N'
,p_show_computation=>'N'
,p_show_aggregate=>'N'
,p_show_chart=>'N'
,p_show_group_by=>'N'
,p_show_pivot=>'N'
,p_show_flashback=>'N'
,p_show_help=>'N'
,p_download_formats=>'XLSX'
,p_enable_mail_download=>'N'
,p_detail_link=>'f?p=&APP_ID.:1102:&SESSION.::&DEBUG.:1102:P1102_ID,G_VARIABLE:#ID#,#ID#'
,p_detail_link_text=>'<span class="fa fa-edit" aria-hidden="true"></span>'
,p_owner=>'DDELACRUZ'
,p_internal_uid=>350296329113527464
,p_updated_on=>wwv_flow_imp.dz('20250408184213Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(350296749730527470)
,p_db_column_name=>'ID'
,p_display_order=>1
,p_column_identifier=>'A'
,p_column_label=>'Id'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(350297113359527471)
,p_db_column_name=>'ANNO'
,p_display_order=>2
,p_column_identifier=>'B'
,p_column_label=>unistr('A\00F1o')
,p_column_type=>'NUMBER'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(350297538604527473)
,p_db_column_name=>'MES'
,p_display_order=>3
,p_column_identifier=>'C'
,p_column_label=>'Mes'
,p_column_type=>'NUMBER'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(350297925920527473)
,p_db_column_name=>'NUMEROVERSION'
,p_display_order=>4
,p_column_identifier=>'D'
,p_column_label=>unistr('Versi\00F3n')
,p_column_type=>'NUMBER'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(350298399568527473)
,p_db_column_name=>'CODIGOESTADO'
,p_display_order=>5
,p_column_identifier=>'E'
,p_column_label=>'Estado Tasas'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
,p_updated_on=>wwv_flow_imp.dz('20250408175546Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(350298786255527475)
,p_db_column_name=>'ULTIMOUSUARIO'
,p_display_order=>6
,p_column_identifier=>'F'
,p_column_label=>unistr('\00DAlt. Usuario')
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
,p_updated_on=>wwv_flow_imp.dz('20250408175608Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(364565528633580142)
,p_db_column_name=>'COMPANIA'
,p_display_order=>20
,p_column_identifier=>'K'
,p_column_label=>'Compania'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(400605123716760102)
,p_db_column_name=>'CODIGOESTADOVAR'
,p_display_order=>40
,p_column_identifier=>'M'
,p_column_label=>'Estado var.'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
,p_updated_on=>wwv_flow_imp.dz('20250408175527Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(400605323081760104)
,p_db_column_name=>'URLICON'
,p_display_order=>60
,p_column_identifier=>'O'
,p_column_label=>unistr('Variaci\00F3n')
,p_column_link=>'f?p=&APP_ID.:1105:&SESSION.::&DEBUG.:RP,1105:P1105_IDCABECERA:#ID#'
,p_column_linktext=>'#URLICON#'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(480695300054152401)
,p_db_column_name=>'NUMEROBATCHJDE'
,p_display_order=>70
,p_column_identifier=>'P'
,p_column_label=>'Batch JDE'
,p_column_type=>'NUMBER'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
,p_updated_on=>wwv_flow_imp.dz('20250408175546Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(350300948428528253)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'3503010'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'URLICON:ANNO:MES:NUMEROVERSION:ULTIMOUSUARIO:CODIGOESTADO:CODIGOESTADOVAR:NUMEROBATCHJDE'
,p_sort_column_1=>'0'
,p_sort_direction_1=>'DESC'
,p_sort_column_2=>'0'
,p_sort_direction_2=>'ASC'
,p_sort_column_3=>'0'
,p_sort_direction_3=>'ASC'
,p_sort_column_4=>'0'
,p_sort_direction_4=>'ASC'
,p_sort_column_5=>'0'
,p_sort_direction_5=>'ASC'
,p_sort_column_6=>'0'
,p_sort_direction_6=>'ASC'
,p_created_on=>wwv_flow_imp.dz('20230705164635Z')
,p_updated_on=>wwv_flow_imp.dz('20230705164635Z')
,p_created_by=>'CVACA'
,p_updated_by=>'CVACA'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(350306055331572401)
,p_plug_name=>'Barra de Acciones'
,p_region_template_options=>'#DEFAULT#:t-Form--stretchInputs'
,p_plug_template=>wwv_flow_imp.id(38289497777120142)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'REGION_POSITION_01'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(364565220043580139)
,p_plug_name=>'Filtros'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(38289867500120143)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_location=>null
,p_plug_display_condition_type=>'NEVER'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
,p_updated_on=>wwv_flow_imp.dz('20250408175301Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(350306196422572402)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(350306055331572401)
,p_button_name=>'CREATE'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860056812106557)
,p_button_image_alt=>'Crear'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:1101:&SESSION.::&DEBUG.:1101::'
,p_button_condition=>'select ''x'' from t_corp_udc WHERE id_cabecera = ''705'' and valor = :app_user'
,p_button_condition_type=>'EXISTS'
,p_icon_css_classes=>'fa-plus'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(364564901065580136)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(350306055331572401)
,p_button_name=>'BUSCAR'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860056812106557)
,p_button_image_alt=>'Buscar'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_icon_css_classes=>'fa-search'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(364565355303580140)
,p_name=>'P1100_ANNO'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(364565220043580139)
,p_prompt=>unistr('A\00F1o')
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'LOV_ANNOS'
,p_lov=>'select to_char(sysdate,''yyyy'') + (level-3) d,to_char(sysdate,''yyyy'') + (level-3) r from dual connect by level <= 4'
,p_lov_display_null=>'YES'
,p_lov_null_text=>'Seleccione'
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'NONE'
,p_updated_on=>wwv_flow_imp.dz('20241231163952Z')
,p_updated_by=>'CVACA'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(364565469425580141)
,p_name=>'P1100_MES'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(364565220043580139)
,p_prompt=>'Mes'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'LOV_MESES'
,p_lov=>'select to_char(to_date(level,''MM''),''Month'') d, level r from dual connect by level <= 12'
,p_lov_display_null=>'YES'
,p_lov_null_text=>'Seleccione'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'NONE'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(350306947763572410)
,p_name=>'cierra1101'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(350306196422572402)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(350307049724572411)
,p_event_id=>wwv_flow_imp.id(350306947763572410)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(350296285366527464)
);
wwv_flow_imp.component_end;
end;
/
