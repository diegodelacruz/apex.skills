prompt --application/pages/page_00461
begin
--   Manifest
--     PAGE: 00461
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>109
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_page.create_page(
 p_id=>461
,p_name=>'Activos Fijos - Ficha'
,p_alias=>'FICHA-ACTIVO'
,p_step_title=>'Ficha Activo'
,p_autocomplete_on_off=>'OFF'
,p_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'function borrarArchivo( numeroArchivo ){',
'    ',
'    apex.item("P461_NUMEROARCHIVO_BORRAR").setValue(numeroArchivo);',
'    ',
'}',
'',
'function toggleClob(elem) {',
'    var toggle   = elem.querySelector(".clob-toggle");',
'    var shortTxt = elem.querySelector(".clob-short");',
'    var fullTxt  = elem.querySelector(".clob-full");',
'',
'    if (fullTxt.style.display === "none") {',
'        fullTxt.style.display = "block";',
'        shortTxt.style.display = "none";',
'        toggle.textContent = "Ver menos";',
'    } else {',
'        fullTxt.style.display = "none";',
'        shortTxt.style.display = "block";',
unistr('        toggle.textContent = "Ver m\00E1s";'),
'    }',
'}',
'',
'',
'',
''))
,p_javascript_code_onload=>wwv_flow_string.join(wwv_flow_t_varchar2(
'function calcularSuma() {',
'	// Construye el detalle de costo seleccionado por el usuario.',
'	// El JSON se guarda en P461_DETALLECOSTO y luego en DETALLECOSTO.',
unistr('	// Solo las l\00EDneas con fuente ''AC'' ser\00E1n usadas posteriormente'),
unistr('	// en sp_enviaractivojde para generar asientos de activaci\00F3n en JDE.'),
'    let total = 0;',
'    let ids = [];',
'    let detalle = [];',
'',
'    $(''.chkF01:checked'').each(function() {',
'        let fila = $(this).closest(''tr'');',
'        let valorRaw = fila.find(''.monto-glaa'').attr(''data-valor'');',
'        let valor = parseFloat(valorRaw) || 0;',
'',
'        let fuente = $(this).attr(''data-fuente'') || '''';',
'        let glaid  = $(this).attr(''data-glaid'') || '''';',
'',
'        total += valor;',
'        ids.push($(this).val());',
'',
'        detalle.push({',
'            fuente: fuente,',
'            glaid: glaid,',
'            valor: valor',
'        });',
'    });',
'',
'    $s(''P461_COSTO'', total.toFixed(2));',
'    $s(''P461_IDS_SELECCIONADOS'', ids.join('',''));',
'    $s(''P461_DETALLECOSTO'', JSON.stringify(detalle));',
'}',
'',
'// Eventos para disparar la suma',
'$(document).on(''change'', ''#select-all'', function() {',
'    $(''.chkF01'').prop(''checked'', this.checked);',
'    calcularSuma();',
'});',
'',
'$(document).on(''change'', ''.chkF01'', function() {',
'    // Si desmarcan uno, quitamos el check de la cabecera',
'    if (!this.checked) $(''#select-all'').prop(''checked'', false);',
'    // Si marcan todos, ponemos el check de la cabecera',
'    if ($(''.chkF01:checked'').length === $(''.chkF01'').length) $(''#select-all'').prop(''checked'', true);',
'    ',
'    calcularSuma();',
'});',
'// Oculta las regiones',
'$(regOcultos).hide();',
''))
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.hidden-region {',
'    display: none !important;',
'}',
'',
'.clob-toggle {',
'    color: #1a73e8; /* azul tipo Google/APEX */',
'    text-decoration: underline;',
'    cursor: pointer;',
'    font-weight: bold;',
'}',
'',
'.clob-preview {',
'    cursor: pointer;',
'    padding: 6px;',
'    border: 1px solid #ddd;',
'    border-radius: 4px;',
'    background: #fafafa;',
'}',
'',
'.clob-toggle {',
'    font-weight: bold;',
'    color: #0066cc;',
'    display: block;',
'    margin-bottom: 4px;',
'    user-select: none;',
'}',
'',
'.clob-full,',
'.clob-short {',
'    white-space: pre-wrap;',
'}',
''))
,p_page_template_options=>'#DEFAULT#'
,p_page_component_map=>'02'
,p_last_updated_on=>wwv_flow_imp.dz('20260522183508Z')
,p_last_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(98729018537340550)
,p_plug_name=>'Barra de acciones'
,p_region_template_options=>'#DEFAULT#:t-Form--stretchInputs'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(38289497777120142)
,p_plug_display_sequence=>10
,p_location=>null
,p_menu_id=>wwv_flow_imp.id(37761271469106475)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(37860983999106559)
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(99032403954282312)
,p_plug_name=>'Ocultos'
,p_region_name=>'regOcultos'
,p_region_css_classes=>'hidden-region'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(37807886111106520)
,p_plug_display_sequence=>30
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
,p_updated_on=>wwv_flow_imp.dz('20260130024356Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(336785279423176405)
,p_plug_name=>'Banderas Regiones'
,p_parent_plug_id=>wwv_flow_imp.id(99032403954282312)
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(38289867500120143)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
,p_created_on=>wwv_flow_imp.dz('20260130024601Z')
,p_updated_on=>wwv_flow_imp.dz('20260130024601Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(197737795791514641)
,p_plug_name=>'Ficha Activo'
,p_title=>'Ficha Activo'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(95503811913299190)
,p_plug_display_sequence=>20
,p_query_type=>'TABLE'
,p_query_table=>'T_FINZ_ACTIVOSFIJOS'
,p_include_rowid_column=>false
,p_is_editable=>true
,p_edit_operations=>'i:u:d'
,p_lost_update_check_type=>'VALUES'
,p_plug_source_type=>'NATIVE_FORM'
,p_plug_read_only_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_plug_read_only_when=>'P461_ESTADO'
,p_plug_read_only_when2=>'ENVIADO'
,p_ai_enabled=>false
,p_updated_on=>wwv_flow_imp.dz('20260211043746Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(99034679211282334)
,p_plug_name=>'Adjuntos'
,p_region_name=>'regAdjuntos'
,p_parent_plug_id=>wwv_flow_imp.id(197737795791514641)
,p_region_template_options=>'#DEFAULT#:is-collapsed:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(37796755046106514)
,p_plug_display_sequence=>60
,p_plug_display_point=>'SUB_REGIONS'
,p_location=>null
,p_plug_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_plug_display_when_condition=>'P461_ID'
,p_plug_read_only_when_type=>'EXPRESSION'
,p_plug_read_only_when=>':P461_ESTADO LIKE ''BAJA%'''
,p_plug_read_only_when2=>'PLSQL'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(101621566725473411)
,p_plug_name=>'Carga'
,p_parent_plug_id=>wwv_flow_imp.id(99034679211282334)
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(38289867500120143)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(101621816219473414)
,p_plug_name=>'Reporte'
,p_parent_plug_id=>wwv_flow_imp.id(99034679211282334)
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(37806762584106520)
,p_plug_display_sequence=>20
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select NUMEROARCHIVO,',
'       dbms_lob.getlength(BLOBCONTENT) BLOBCONTENT,',
'       FILENAME,',
'       MIMETYPE,',
'       TABLA,',
'       ID_TABLA,',
'       TIPO,',
'       OBSERVACION,',
'       ESTADO,',
'       FECHA,',
'       NOMBREUSUARIO,',
'       RIDE,',
'       ''<span class="fa fa-eye" title="Previsualizar" aria-hidden="true" style="color: #800080;"></span>'' ver,',
'       pk_commons.f_googledocview(numeroarchivo,mimetype) enlacearchivo,',
'       NUMEROARCHIVO AS BORRAR',
'  from FILES.T_APEX_ARCHIVOS',
' where TABLA=''T_FINZ_ACTIVOSFIJOS'' AND TIPO IS NULL AND id_tabla=:P461_ID'))
,p_plug_source_type=>'NATIVE_IR'
,p_ajax_items_to_submit=>'P461_ID'
,p_plug_display_condition_type=>'EXPRESSION'
,p_plug_display_when_condition=>':P461_ESTADO NOT LIKE ''BAJA%'''
,p_plug_display_when_cond2=>'PLSQL'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(101621951315473415)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'MALBAN'
,p_internal_uid=>101621951315473415
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(101622066312473416)
,p_db_column_name=>'NUMEROARCHIVO'
,p_display_order=>10
,p_is_primary_key=>'Y'
,p_column_identifier=>'A'
,p_column_label=>'Numeroarchivo'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(101622200001473418)
,p_db_column_name=>'FILENAME'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Nombre Archivo'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(101622331407473419)
,p_db_column_name=>'MIMETYPE'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Tipo'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(101622407972473420)
,p_db_column_name=>'TABLA'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Tabla'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(101622596220473421)
,p_db_column_name=>'ID_TABLA'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>unistr('C\00F3digo')
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(101622667060473422)
,p_db_column_name=>'TIPO'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>'Tipo'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(101622781649473423)
,p_db_column_name=>'OBSERVACION'
,p_display_order=>80
,p_column_identifier=>'H'
,p_column_label=>unistr('Observaci\00F3n')
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(101622851709473424)
,p_db_column_name=>'ESTADO'
,p_display_order=>90
,p_column_identifier=>'I'
,p_column_label=>'Estado'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(101622935445473425)
,p_db_column_name=>'FECHA'
,p_display_order=>100
,p_column_identifier=>'J'
,p_column_label=>'Fecha Crea'
,p_column_type=>'DATE'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(101623009222473426)
,p_db_column_name=>'NOMBREUSUARIO'
,p_display_order=>110
,p_column_identifier=>'K'
,p_column_label=>'Usuario Crea'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(101623103936473427)
,p_db_column_name=>'RIDE'
,p_display_order=>120
,p_column_identifier=>'L'
,p_column_label=>'Ride'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(101623501545473431)
,p_db_column_name=>'BLOBCONTENT'
,p_display_order=>130
,p_column_identifier=>'M'
,p_column_label=>'Documento'
,p_column_type=>'NUMBER'
,p_column_alignment=>'CENTER'
,p_format_mask=>'DOWNLOAD:T_APEX_ARCHIVOS:BLOBCONTENT:NUMEROARCHIVO::MIMETYPE:FILENAME:FECHA::inline:Descargar:FILES'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(101623806827473434)
,p_db_column_name=>'VER'
,p_display_order=>140
,p_column_identifier=>'N'
,p_column_label=>'Ver Documento'
,p_column_link=>'#ENLACEARCHIVO#'
,p_column_linktext=>'#VER#'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(101623972207473435)
,p_db_column_name=>'ENLACEARCHIVO'
,p_display_order=>150
,p_column_identifier=>'O'
,p_column_label=>'Enlacearchivo'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(101624163836473437)
,p_db_column_name=>'BORRAR'
,p_display_order=>160
,p_column_identifier=>'P'
,p_column_label=>'Borrar'
,p_column_link=>'javascript:borrarArchivo(#BORRAR#)'
,p_column_linktext=>'<span title="Eliminar" class="fa fa-trash"/>'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(101652304171649904)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'1016524'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'ID_TABLA:FILENAME:MIMETYPE:OBSERVACION:FECHA:NOMBREUSUARIO:BLOBCONTENT:VER:BORRAR:'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(104977647658980225)
,p_plug_name=>'ReporteBajas'
,p_parent_plug_id=>wwv_flow_imp.id(99034679211282334)
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(37806762584106520)
,p_plug_display_sequence=>30
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select NUMEROARCHIVO,',
'       dbms_lob.getlength(BLOBCONTENT) BLOBCONTENT,',
'       FILENAME,',
'       MIMETYPE,',
'       TABLA,',
'       ID_TABLA,',
'       TIPO,',
'       OBSERVACION,',
'       ESTADO,',
'       FECHA,',
'       NOMBREUSUARIO,',
'       RIDE,',
'       ''<span class="fa fa-eye" title="Previsualizar" aria-hidden="true" style="color: #800080;"></span>'' ver,',
'       pk_commons.f_googledocview(numeroarchivo,mimetype) enlacearchivo,',
'       NUMEROARCHIVO AS BORRAR',
'  from FILES.T_APEX_ARCHIVOS',
' where TABLA=''T_FINZ_ACTIVOSFIJOS'' AND TIPO=''BAJA_ACTIVO'' AND id_tabla=:P461_ID'))
,p_plug_source_type=>'NATIVE_IR'
,p_ajax_items_to_submit=>'P461_ID'
,p_plug_display_condition_type=>'EXPRESSION'
,p_plug_display_when_condition=>':P461_ESTADO LIKE ''BAJA%'''
,p_plug_display_when_cond2=>'PLSQL'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(104977727974980226)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'MALBAN'
,p_internal_uid=>104977727974980226
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(104977817345980227)
,p_db_column_name=>'NUMEROARCHIVO'
,p_display_order=>10
,p_is_primary_key=>'Y'
,p_column_identifier=>'A'
,p_column_label=>'Numeroarchivo'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(104977934781980228)
,p_db_column_name=>'FILENAME'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Nombre Archivo'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(104978041732980229)
,p_db_column_name=>'MIMETYPE'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Tipo'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(104978169942980230)
,p_db_column_name=>'TABLA'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Tabla'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(104978278491980231)
,p_db_column_name=>'ID_TABLA'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>unistr('C\00F3digo')
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(104978395798980232)
,p_db_column_name=>'TIPO'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'Tipo'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(104978407441980233)
,p_db_column_name=>'OBSERVACION'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>unistr('Observaci\00F3n')
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(104978531567980234)
,p_db_column_name=>'ESTADO'
,p_display_order=>80
,p_column_identifier=>'H'
,p_column_label=>'Estado'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(104978614233980235)
,p_db_column_name=>'FECHA'
,p_display_order=>90
,p_column_identifier=>'I'
,p_column_label=>'Fecha Crea'
,p_column_type=>'DATE'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(104978763713980236)
,p_db_column_name=>'NOMBREUSUARIO'
,p_display_order=>100
,p_column_identifier=>'J'
,p_column_label=>'Usuario Crea'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(104978882742980237)
,p_db_column_name=>'RIDE'
,p_display_order=>110
,p_column_identifier=>'K'
,p_column_label=>'Ride'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(104978944638980238)
,p_db_column_name=>'BLOBCONTENT'
,p_display_order=>120
,p_column_identifier=>'L'
,p_column_label=>'Documento'
,p_column_type=>'NUMBER'
,p_column_alignment=>'CENTER'
,p_format_mask=>'DOWNLOAD:T_APEX_ARCHIVOS:BLOBCONTENT:NUMEROARCHIVO::MIMETYPE:FILENAME:FECHA::inline:Descargar:FILES'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(104979077738980239)
,p_db_column_name=>'VER'
,p_display_order=>130
,p_column_identifier=>'M'
,p_column_label=>'Ver Documento'
,p_column_link=>'#ENLACEARCHIVO#'
,p_column_linktext=>'#VER#'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(104979109756980240)
,p_db_column_name=>'ENLACEARCHIVO'
,p_display_order=>140
,p_column_identifier=>'N'
,p_column_label=>'Enlacearchivo'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(104979201402980241)
,p_db_column_name=>'BORRAR'
,p_display_order=>150
,p_column_identifier=>'O'
,p_column_label=>'Borrar'
,p_column_link=>'javascript:borrarArchivo(#BORRAR#)'
,p_column_linktext=>'<span title="Eliminar" class="fa fa-trash"/>'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(105516548523099015)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'1055166'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'FILENAME:TIPO:OBSERVACION:FECHA:NOMBREUSUARIO:VER:'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(117852778452716942)
,p_plug_name=>'Historial'
,p_region_name=>'regHistorial'
,p_parent_plug_id=>wwv_flow_imp.id(197737795791514641)
,p_region_template_options=>'#DEFAULT#:is-collapsed:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(37796755046106514)
,p_plug_display_sequence=>70
,p_plug_display_point=>'SUB_REGIONS'
,p_location=>null
,p_plug_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_plug_display_when_condition=>'P461_ID'
,p_plug_read_only_when_type=>'EXPRESSION'
,p_plug_read_only_when=>':P461_ESTADO LIKE ''BAJA%'''
,p_plug_read_only_when2=>'PLSQL'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(117853019103716945)
,p_name=>'Historial Log'
,p_parent_plug_id=>wwv_flow_imp.id(117852778452716942)
,p_template=>wwv_flow_imp.id(38289867500120143)
,p_display_sequence=>10
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_display_point=>'SUB_REGIONS'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT FECHCREA, ORIGEN, PAGINA, EVENTO, MENSAJE, ',
'''<div class="clob-preview" onclick="toggleClob(this)">',
unistr('        <span class="clob-toggle">Ver m\00E1s</span>'),
'        <div class="clob-short">'' || SUBSTR(DETALLE, 1, 100) || ''...</div>',
'        <div class="clob-full" style="display:none;">'' || DETALLE || ''</div>',
'    </div>'' AS  DETALLE',
'FROM T_FINZ_ACTIVOSFIJOSLOG',
'WHERE IDACT=:P461_ID;'))
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(37830327650106535)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(117853154695716946)
,p_query_column_id=>1
,p_column_alias=>'FECHCREA'
,p_column_display_sequence=>10
,p_column_heading=>'Fecha Registro'
,p_use_as_row_header=>'N'
,p_column_alignment=>'CENTER'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(117853218963716947)
,p_query_column_id=>2
,p_column_alias=>'ORIGEN'
,p_column_display_sequence=>20
,p_use_as_row_header=>'N'
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(117853321637716948)
,p_query_column_id=>3
,p_column_alias=>'PAGINA'
,p_column_display_sequence=>30
,p_column_heading=>unistr('P\00E1gina')
,p_use_as_row_header=>'N'
,p_column_alignment=>'CENTER'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(117853439072716949)
,p_query_column_id=>4
,p_column_alias=>'EVENTO'
,p_column_display_sequence=>40
,p_use_as_row_header=>'N'
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(117853570702716950)
,p_query_column_id=>5
,p_column_alias=>'MENSAJE'
,p_column_display_sequence=>50
,p_column_heading=>'Mensaje'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(132271746154336901)
,p_query_column_id=>6
,p_column_alias=>'DETALLE'
,p_column_display_sequence=>60
,p_column_heading=>'Detalle'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(197640863484212597)
,p_plug_name=>unistr('Informaci\00F3n Contable')
,p_parent_plug_id=>wwv_flow_imp.id(197737795791514641)
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(95503811913299190)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_location=>null
,p_plug_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_plug_display_when_condition=>'P461_ID'
,p_plug_read_only_when_type=>'EXPRESSION'
,p_plug_read_only_when=>':P461_ESTADO LIKE ''BAJA%'''
,p_plug_read_only_when2=>'PLSQL'
,p_ai_enabled=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(197641005678212598)
,p_plug_name=>'Fechas'
,p_parent_plug_id=>wwv_flow_imp.id(197737795791514641)
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(95503811913299190)
,p_plug_display_sequence=>20
,p_plug_display_point=>'SUB_REGIONS'
,p_location=>null
,p_plug_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_plug_display_when_condition=>'P461_ID'
,p_plug_read_only_when_type=>'EXPRESSION'
,p_plug_read_only_when=>':P461_ESTADO LIKE ''BAJA%'''
,p_plug_read_only_when2=>'PLSQL'
,p_ai_enabled=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(197641100767212599)
,p_plug_name=>unistr('Custodio y Ubicaci\00F3n')
,p_parent_plug_id=>wwv_flow_imp.id(197737795791514641)
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(95503811913299190)
,p_plug_display_sequence=>30
,p_plug_display_point=>'SUB_REGIONS'
,p_location=>null
,p_plug_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_plug_display_when_condition=>'P461_ID'
,p_plug_read_only_when_type=>'EXPRESSION'
,p_plug_read_only_when=>':P461_ESTADO LIKE ''BAJA%'''
,p_plug_read_only_when2=>'PLSQL'
,p_ai_enabled=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(197641148181212600)
,p_plug_name=>'Proveedor / Documento de Compra'
,p_parent_plug_id=>wwv_flow_imp.id(197737795791514641)
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(95503811913299190)
,p_plug_display_sequence=>40
,p_plug_display_point=>'SUB_REGIONS'
,p_location=>null
,p_plug_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_plug_display_when_condition=>'P461_ID'
,p_plug_read_only_when_type=>'EXPRESSION'
,p_plug_read_only_when=>':P461_ESTADO LIKE ''BAJA%'''
,p_plug_read_only_when2=>'PLSQL'
,p_ai_enabled=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(197641257069212601)
,p_plug_name=>'Observaciones'
,p_parent_plug_id=>wwv_flow_imp.id(197737795791514641)
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(95503811913299190)
,p_plug_display_sequence=>50
,p_plug_display_point=>'SUB_REGIONS'
,p_location=>null
,p_plug_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_plug_display_when_condition=>'P461_ID'
,p_plug_read_only_when_type=>'EXPRESSION'
,p_plug_read_only_when=>':P461_ESTADO LIKE ''BAJA%'''
,p_plug_read_only_when2=>'PLSQL'
,p_ai_enabled=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(349045357192138627)
,p_plug_name=>'Asientos'
,p_parent_plug_id=>wwv_flow_imp.id(197737795791514641)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(37806762584106520)
,p_plug_display_sequence=>1
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'with cab as (',
'	select idcuenta, max(anno) anno, max(mes) mes, max(id) id',
'	from data.t_finz_pruebadepcab',
'	where idcuenta in (''00406422'',''00406570'',''00406588'',''00432057'')',
'	group by idcuenta',
')',
'select apex_item.checkbox2(',
'		p_idx        => 1,',
'		p_value      => det.id,',
'		p_attributes => ''class="chkF01" data-fuente="PD" data-glaid="'' || trim(cab.idcuenta) || ''"''',
'	) seleccion',
'	, ''PD'' origendato',
'	, trim(to_char(cab.idcuenta)) idcuenta',
'	, cab.idcuenta idcuentaoculto',
'	, det.glan8',
'	, trim(det.glpo) glpo',
'	, trim(det.glexr) glexr',
'	, ''<span class="monto-glaa" data-valor="''',
'		|| ltrim(to_char(det.glaa, ''999999999990.99'', ''NLS_NUMERIC_CHARACTERS=''''.,''''''))',
'		|| ''">'' || det.glaa || ''</span>'' glaa',
'from data.t_finz_pruebadepdet det',
'inner join cab on cab.id = det.idcab',
'where instr(det.estado, ''*'') = 0',
'union',
'select apex_item.checkbox2(',
'		p_idx        => 1,',
'		p_value      => f0911.glicu,',
'		p_attributes => ''class="chkF01" data-fuente="AC" data-glaid="'' || trim(to_char(f0911.glaid)) || ''"''',
'	) seleccion',
'	, ''AC'' origendato',
'	, trim(to_char(f0911.glaid)) idcuenta',
'	, trim(to_char(f0911.glaid)) idcuentaoculto',
'	, f0911.glan8',
'	, trim(to_char(f0911.glpo)) glpo',
'	, trim(to_char(f0911.glexr)) glexr',
'	, ''<span class="monto-glaa" data-valor="''',
'		|| ltrim(to_char(f0911.glaa / 100, ''999999999990.99'', ''NLS_NUMERIC_CHARACTERS=''''.,''''''))',
'		|| ''">'' || f0911.glaa / 100 || ''</span>'' glaa',
'from f0911@jdedtadl',
'where f0911.glaid in (''00406238'',''00406262'',''00406297'',''00406326'',''00406351'',''00406385'')',
'	and f0911.glasid = ''                         ''',
'	and f0911.glaa != 0'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_display_condition_type=>'ITEM_IS_NULL'
,p_plug_display_when_condition=>'P461_ID'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
,p_created_on=>wwv_flow_imp.dz('20260210194530Z')
,p_updated_on=>wwv_flow_imp.dz('20260408155410Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(349045457364138628)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'XLSX'
,p_enable_mail_download=>'N'
,p_owner=>'DDELACRUZ'
,p_internal_uid=>349045457364138628
,p_created_on=>wwv_flow_imp.dz('20260210194951Z')
,p_updated_on=>wwv_flow_imp.dz('20260408155410Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(349046034509138634)
,p_db_column_name=>'SELECCION'
,p_display_order=>10
,p_column_identifier=>'F'
,p_column_label=>'<input type="checkbox" id="select-all">'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20260210195935Z')
,p_updated_on=>wwv_flow_imp.dz('20260210201159Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(349045557701138629)
,p_db_column_name=>'IDCUENTA'
,p_display_order=>20
,p_column_identifier=>'A'
,p_column_label=>'Cuenta'
,p_column_type=>'STRING'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_rpt_named_lov=>wwv_flow_imp.id(532084568011346114)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20260210194951Z')
,p_updated_on=>wwv_flow_imp.dz('20260210195952Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(349045629685138630)
,p_db_column_name=>'GLAN8'
,p_display_order=>30
,p_column_identifier=>'B'
,p_column_label=>'Proveedor'
,p_column_type=>'NUMBER'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_heading_alignment=>'LEFT'
,p_rpt_named_lov=>wwv_flow_imp.id(336564499940306120)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20260210194952Z')
,p_updated_on=>wwv_flow_imp.dz('20260210195952Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(349045746472138631)
,p_db_column_name=>'GLPO'
,p_display_order=>40
,p_column_identifier=>'C'
,p_column_label=>'OC'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20260210194952Z')
,p_updated_on=>wwv_flow_imp.dz('20260210195952Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(349045817775138632)
,p_db_column_name=>'GLEXR'
,p_display_order=>50
,p_column_identifier=>'D'
,p_column_label=>unistr('Explicaci\00F3n')
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20260210194952Z')
,p_updated_on=>wwv_flow_imp.dz('20260210195952Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(349046177722138635)
,p_db_column_name=>'GLAA'
,p_display_order=>60
,p_column_identifier=>'G'
,p_column_label=>'Monto'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20260210200820Z')
,p_updated_on=>wwv_flow_imp.dz('20260210201604Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(355335156583124218)
,p_db_column_name=>'ORIGENDATO'
,p_display_order=>70
,p_column_identifier=>'H'
,p_column_label=>'OD'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20260227143933Z')
,p_updated_on=>wwv_flow_imp.dz('20260227143933Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(420266070109760201)
,p_db_column_name=>'IDCUENTAOCULTO'
,p_display_order=>80
,p_column_identifier=>'I'
,p_column_label=>'Idcuentaoculto'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20260408155410Z')
,p_updated_on=>wwv_flow_imp.dz('20260408155410Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(350944235667464092)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'3509443'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'SELECCION:ORIGENDATO:IDCUENTA:GLAN8:GLPO:GLEXR:GLAA:'
,p_sort_column_1=>'ORIGENDATO'
,p_sort_direction_1=>'ASC'
,p_sort_column_2=>'IDCUENTA'
,p_sort_direction_2=>'ASC'
,p_sort_column_3=>'GLAN8'
,p_sort_direction_3=>'ASC'
,p_sort_column_4=>'GLPO'
,p_sort_direction_4=>'ASC'
,p_sort_column_5=>'0'
,p_sort_direction_5=>'ASC'
,p_sort_column_6=>'0'
,p_sort_direction_6=>'ASC'
,p_created_on=>wwv_flow_imp.dz('20260210195126Z')
,p_updated_on=>wwv_flow_imp.dz('20260227144203Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(98913289050872063)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(98729018537340550)
,p_button_name=>'CANCEL'
,p_button_static_id=>'btnCancelar'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860056812106557)
,p_button_image_alt=>'Cancel'
,p_button_position=>'ABOVE_BOX'
,p_button_alignment=>'LEFT'
,p_button_redirect_url=>'f?p=&APP_ID.:460:&APP_SESSION.::&DEBUG.:::'
,p_icon_css_classes=>'fa-arrow-left'
,p_updated_on=>wwv_flow_imp.dz('20260210205755Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(98913658030872064)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(98729018537340550)
,p_button_name=>'DELETE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860056812106557)
,p_button_image_alt=>'Delete'
,p_button_position=>'ABOVE_BOX'
,p_button_alignment=>'RIGHT'
,p_button_execute_validations=>'N'
,p_confirm_message=>'&APP_TEXT$DELETE_MSG!RAW.'
,p_confirm_style=>'danger'
,p_button_condition=>':P461_ID IS NOT NULL AND :P461_ESTADO = ''CREADO'''
,p_button_condition2=>'PLSQL'
,p_button_condition_type=>'EXPRESSION'
,p_icon_css_classes=>'fa-trash-o'
,p_database_action=>'DELETE'
,p_updated_on=>wwv_flow_imp.dz('20260211043920Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(420269893213760239)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(98729018537340550)
,p_button_name=>'PRINT'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860056812106557)
,p_button_image_alt=>'Imprimir Etiqueta'
,p_button_position=>'ABOVE_BOX'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:470:&SESSION.::&DEBUG.:470:P470_COMPANIA,P470_CODACTIVO:&P461_COMPANIA.,&P461_CODACTIVO.'
,p_button_condition=>'P461_CODACTIVO'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_icon_css_classes=>'fa-print'
,p_created_on=>wwv_flow_imp.dz('20260408205838Z')
,p_updated_on=>wwv_flow_imp.dz('20260408210358Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(108680884598627641)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(98729018537340550)
,p_button_name=>'ENVIARJDE'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860056812106557)
,p_button_image_alt=>'Enviar a JDE'
,p_button_position=>'ABOVE_BOX'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
,p_button_condition=>':P461_ID IS NOT NULL AND :P461_ESTADO = ''CREADO'' AND :P461_CODERP IS NULL'
,p_button_condition2=>'PLSQL'
,p_button_condition_type=>'EXPRESSION'
,p_icon_css_classes=>'fa-play'
,p_updated_on=>wwv_flow_imp.dz('20260408205838Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(98914851397872064)
,p_button_sequence=>50
,p_button_plug_id=>wwv_flow_imp.id(98729018537340550)
,p_button_name=>'ADJUNTOS'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860056812106557)
,p_button_image_alt=>'Adjuntos'
,p_button_position=>'ABOVE_BOX'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
,p_button_condition=>':P461_ID IS NOT NULL'
,p_button_condition2=>'PLSQL'
,p_button_condition_type=>'EXPRESSION'
,p_icon_css_classes=>'fa-file-plus'
,p_updated_on=>wwv_flow_imp.dz('20260408205838Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(98915230663872064)
,p_button_sequence=>60
,p_button_plug_id=>wwv_flow_imp.id(98729018537340550)
,p_button_name=>'LOG'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860056812106557)
,p_button_image_alt=>'Historial'
,p_button_position=>'ABOVE_BOX'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
,p_button_condition=>'P461_ID'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_icon_css_classes=>'fa-history'
,p_updated_on=>wwv_flow_imp.dz('20260408205838Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(98915679553872065)
,p_button_sequence=>70
,p_button_plug_id=>wwv_flow_imp.id(98729018537340550)
,p_button_name=>'DEPRECIACION'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860056812106557)
,p_button_image_alt=>unistr('Depreciaci\00F3n')
,p_button_position=>'ABOVE_BOX'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:468:&SESSION.::&DEBUG.::P468_IDACTIVO,P468_TIPOACTIVO,P468_CODERP:&P461_ID.,&P461_CODTIPO.,&P461_CODERP.'
,p_button_condition=>':P461_ID IS NOT NULL AND :P461_ESTADO IN (''CREADO'',''ENVIADO'')'
,p_button_condition2=>'PLSQL'
,p_button_condition_type=>'EXPRESSION'
,p_icon_css_classes=>'fa-calculator'
,p_updated_on=>wwv_flow_imp.dz('20260408205838Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(98914099661872064)
,p_button_sequence=>80
,p_button_plug_id=>wwv_flow_imp.id(98729018537340550)
,p_button_name=>'SAVE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860056812106557)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Guardar Cambios'
,p_button_position=>'ABOVE_BOX'
,p_button_alignment=>'RIGHT'
,p_button_condition=>':P461_ID IS NOT NULL AND :P461_ESTADO = ''CREADO'''
,p_button_condition2=>'PLSQL'
,p_button_condition_type=>'EXPRESSION'
,p_icon_css_classes=>'fa-save'
,p_database_action=>'UPDATE'
,p_updated_on=>wwv_flow_imp.dz('20260211050748Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(98914476185872064)
,p_button_sequence=>90
,p_button_plug_id=>wwv_flow_imp.id(98729018537340550)
,p_button_name=>'CREATE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860056812106557)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Crear'
,p_button_position=>'ABOVE_BOX'
,p_button_alignment=>'RIGHT'
,p_button_condition=>'P461_ID'
,p_button_condition_type=>'ITEM_IS_NULL'
,p_icon_css_classes=>'fa-save'
,p_database_action=>'INSERT'
,p_updated_on=>wwv_flow_imp.dz('20260211050748Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(101623467641473430)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(99034679211282334)
,p_button_name=>'Cargar'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860056812106557)
,p_button_image_alt=>'Cargar'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_button_condition=>':P461_ESTADO NOT LIKE ''BAJA%'''
,p_button_condition2=>'PLSQL'
,p_button_condition_type=>'EXPRESSION'
,p_icon_css_classes=>'fa-file-arrow-up'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(99032605372282314)
,p_branch_action=>'f?p=&APP_ID.:460:&SESSION.::&DEBUG.:::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_imp.id(98913658030872064)
,p_branch_sequence=>10
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(99032364239282311)
,p_name=>'P461_DESCRI1'
,p_item_sequence=>570
,p_item_plug_id=>wwv_flow_imp.id(99032403954282312)
,p_prompt=>'Descri1'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(101621641711473412)
,p_name=>'P461_ARCHVIO'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(101621566725473411)
,p_prompt=>'Archvio'
,p_display_as=>'NATIVE_FILE'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'APEX_APPLICATION_TEMP_FILES'
,p_attribute_09=>'SESSION'
,p_attribute_10=>'N'
,p_attribute_12=>'INLINE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(101621764862473413)
,p_name=>'P461_ADJ_OBS'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(101621566725473411)
,p_prompt=>unistr('Observaci\00F3n: ')
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(101624205254473438)
,p_name=>'P461_NUMEROARCHIVO_BORRAR'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(101621816219473414)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(101625051150473446)
,p_name=>'P461_LABELUBICACION'
,p_item_sequence=>580
,p_item_plug_id=>wwv_flow_imp.id(99032403954282312)
,p_use_cache_before_default=>'NO'
,p_prompt=>unistr('bandera ubicaci\00F3n')
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(101625131965473447)
,p_name=>'P461_LABELCUSTODIO'
,p_item_sequence=>590
,p_item_plug_id=>wwv_flow_imp.id(99032403954282312)
,p_use_cache_before_default=>'NO'
,p_prompt=>'bandera custodio'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(117852096844716935)
,p_name=>'P461_EXITO'
,p_item_sequence=>600
,p_item_plug_id=>wwv_flow_imp.id(99032403954282312)
,p_use_cache_before_default=>'NO'
,p_prompt=>'bandera custodio'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(197742045116514663)
,p_name=>'P461_ID'
,p_source_data_type=>'NUMBER'
,p_is_primary_key=>true
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(197737795791514641)
,p_item_source_plug_id=>wwv_flow_imp.id(197737795791514641)
,p_source=>'ID'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_protection_level=>'S'
,p_attribute_01=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20260210212109Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(197742357367514667)
,p_name=>'P461_USERCREA'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(197737795791514641)
,p_item_source_plug_id=>wwv_flow_imp.id(197737795791514641)
,p_item_default=>':APP_USER'
,p_item_default_type=>'EXPRESSION'
,p_item_default_language=>'PLSQL'
,p_source=>'USERCREA'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(197742704656514670)
,p_name=>'P461_FECHCREA'
,p_source_data_type=>'TIMESTAMP'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(197737795791514641)
,p_item_source_plug_id=>wwv_flow_imp.id(197737795791514641)
,p_item_default=>'SYSDATE'
,p_item_default_type=>'EXPRESSION'
,p_item_default_language=>'PLSQL'
,p_source=>'FECHCREA'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(197743561093514680)
,p_name=>'P461_USERMODI'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(197737795791514641)
,p_item_source_plug_id=>wwv_flow_imp.id(197737795791514641)
,p_source=>'USERMODI'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(197743924372514680)
,p_name=>'P461_FECHMODI'
,p_source_data_type=>'TIMESTAMP'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(197737795791514641)
,p_item_source_plug_id=>wwv_flow_imp.id(197737795791514641)
,p_source=>'FECHMODI'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(197744700164514680)
,p_name=>'P461_COMPANIA'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(197737795791514641)
,p_item_source_plug_id=>wwv_flow_imp.id(197737795791514641)
,p_item_default=>':G_COMPANIA'
,p_item_default_type=>'EXPRESSION'
,p_item_default_language=>'PLSQL'
,p_source=>'COMPANIA'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(197745128365514681)
,p_name=>'P461_CODERP'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(197737795791514641)
,p_item_source_plug_id=>wwv_flow_imp.id(197737795791514641)
,p_prompt=>unistr('C\00F3digo JDE')
,p_source=>'CODERP'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(197745490019514681)
,p_name=>'P461_CODACTIVO'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(197737795791514641)
,p_item_source_plug_id=>wwv_flow_imp.id(197737795791514641)
,p_prompt=>unistr('C\00F3digo Activo')
,p_source=>'CODACTIVO'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(197745947911514681)
,p_name=>'P461_DESCRIPCION1'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>130
,p_item_plug_id=>wwv_flow_imp.id(197737795791514641)
,p_item_source_plug_id=>wwv_flow_imp.id(197737795791514641)
,p_prompt=>unistr('Descripci\00F3n 1')
,p_source=>'DESCRIPCION1'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
,p_updated_on=>wwv_flow_imp.dz('20260210201443Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(197746354060514681)
,p_name=>'P461_DESCRIPCION2'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>140
,p_item_plug_id=>wwv_flow_imp.id(197737795791514641)
,p_item_source_plug_id=>wwv_flow_imp.id(197737795791514641)
,p_prompt=>unistr('Descripci\00F3n 2')
,p_source=>'DESCRIPCION2'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
,p_updated_on=>wwv_flow_imp.dz('20260211043747Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(197746750267514681)
,p_name=>'P461_DESCRIPCION3'
,p_source_data_type=>'VARCHAR2'
,p_is_required=>true
,p_item_sequence=>150
,p_item_plug_id=>wwv_flow_imp.id(197737795791514641)
,p_item_source_plug_id=>wwv_flow_imp.id(197737795791514641)
,p_prompt=>unistr('Descripci\00F3n 3')
,p_source=>'DESCRIPCION3'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>32
,p_cMaxlength=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'NONE'
,p_updated_on=>wwv_flow_imp.dz('20260210201443Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(197747117064514682)
,p_name=>'P461_CODTIPO'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_imp.id(197737795791514641)
,p_item_source_plug_id=>wwv_flow_imp.id(197737795791514641)
,p_prompt=>'Tipo'
,p_source=>'CODTIPO'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'LOV_AFI_TIPO'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select DRDL01 D, DRKY R',
'from vt_jde_udcjde where drsy = ''12'' and drrt = ''21''',
'and DRKY is not null',
'order by 2;'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'Seleccione'
,p_lov_null_value=>'999'
,p_cHeight=>1
,p_read_only_when=>'P461_CODACTIVO'
,p_read_only_when_type=>'ITEM_NOT_NULL_OR_ZERO'
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(197747487571514682)
,p_name=>'P461_CODCATEGORIA'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_imp.id(197737795791514641)
,p_item_source_plug_id=>wwv_flow_imp.id(197737795791514641)
,p_prompt=>unistr('Categor\00EDa')
,p_source=>'CODCATEGORIA'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select DRDL01 D, DRKY R',
'from vt_jde_udcjde where drsy = ''12'' and drrt = ''22''',
'and substr(DRKY,1,1)=:P461_CODTIPO',
'order by 2;'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'Seleccione'
,p_lov_null_value=>'999'
,p_lov_cascade_parent_items=>'P461_CODTIPO'
,p_ajax_optimize_refresh=>'Y'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_read_only_when=>'P461_CODACTIVO'
,p_read_only_when_type=>'ITEM_NOT_NULL_OR_ZERO'
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(197747976283514682)
,p_name=>'P461_CODSUBCATEGORIA'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>120
,p_item_plug_id=>wwv_flow_imp.id(197737795791514641)
,p_item_source_plug_id=>wwv_flow_imp.id(197737795791514641)
,p_prompt=>unistr('Subcategor\00EDa')
,p_source=>'CODSUBCATEGORIA'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select DRDL01 D, DRKY R',
'from vt_jde_udcjde where drsy = ''12'' and drrt = ''23''',
'and substr(DRKY,1,4)=:P461_CODCATEGORIA',
'order by 2;'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'Seleccione'
,p_lov_null_value=>'999'
,p_lov_cascade_parent_items=>'P461_CODCATEGORIA'
,p_ajax_optimize_refresh=>'Y'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_read_only_when=>'P461_CODACTIVO'
,p_read_only_when_type=>'ITEM_NOT_NULL_OR_ZERO'
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_updated_on=>wwv_flow_imp.dz('20260210201443Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(197750714320514684)
,p_name=>'P461_ESTADO'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(197737795791514641)
,p_item_source_plug_id=>wwv_flow_imp.id(197737795791514641)
,p_item_default=>'SELECT ''CREADO'' FROM DUAL WHERE :P461_ID IS NULL'
,p_item_default_type=>'SQL_QUERY'
,p_prompt=>'Estado'
,p_source=>'ESTADO'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>32
,p_cMaxlength=>20
,p_begin_on_new_line=>'N'
,p_read_only_when_type=>'ALWAYS'
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'NONE'
,p_updated_on=>wwv_flow_imp.dz('20260210201443Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(197751911415514684)
,p_name=>'P461_IDFLUJO'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>170
,p_item_plug_id=>wwv_flow_imp.id(197737795791514641)
,p_item_source_plug_id=>wwv_flow_imp.id(197737795791514641)
,p_source=>'IDFLUJO'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(197752703460514685)
,p_name=>'P461_FECHAASIGNACION'
,p_source_data_type=>'DATE'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(197641005678212598)
,p_item_source_plug_id=>wwv_flow_imp.id(197737795791514641)
,p_item_default=>'to_char(sysdate,''dd/mm/yyyy'')'
,p_item_default_type=>'EXPRESSION'
,p_item_default_language=>'PLSQL'
,p_prompt=>unistr('Asignaci\00F3n')
,p_format_mask=>'dd/mm/yyyy'
,p_source=>'FECHAASIGNACION'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DATE_PICKER_APEX'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'POPUP'
,p_attribute_03=>'NONE'
,p_attribute_06=>'NONE'
,p_attribute_09=>'N'
,p_attribute_11=>'N'
,p_attribute_12=>'MONTH-PICKER:YEAR-PICKER'
,p_attribute_13=>'VISIBLE'
,p_attribute_15=>'FOCUS'
,p_updated_on=>wwv_flow_imp.dz('20260211044853Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(197754765363514686)
,p_name=>'P461_CODPADRE'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>180
,p_item_plug_id=>wwv_flow_imp.id(197737795791514641)
,p_item_source_plug_id=>wwv_flow_imp.id(197737795791514641)
,p_source=>'CODPADRE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(197757522444514688)
,p_name=>'P461_GL_LOTE'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>190
,p_item_plug_id=>wwv_flow_imp.id(197737795791514641)
,p_item_source_plug_id=>wwv_flow_imp.id(197737795791514641)
,p_source=>'GL_LOTE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(197757944189514688)
,p_name=>'P461_GL_TIPODOC'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>200
,p_item_plug_id=>wwv_flow_imp.id(197737795791514641)
,p_item_source_plug_id=>wwv_flow_imp.id(197737795791514641)
,p_source=>'GL_TIPODOC'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(197758331015514688)
,p_name=>'P461_GL_NUMDOC'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>210
,p_item_plug_id=>wwv_flow_imp.id(197737795791514641)
,p_item_source_plug_id=>wwv_flow_imp.id(197737795791514641)
,p_source=>'GL_NUMDOC'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(197758752167514688)
,p_name=>'P461_GL_LEYENDA'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>220
,p_item_plug_id=>wwv_flow_imp.id(197737795791514641)
,p_item_source_plug_id=>wwv_flow_imp.id(197737795791514641)
,p_source=>'GL_LEYENDA'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(197759078654514688)
,p_name=>'P461_GL_MONEDA'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>230
,p_item_plug_id=>wwv_flow_imp.id(197737795791514641)
,p_item_source_plug_id=>wwv_flow_imp.id(197737795791514641)
,p_source=>'GL_MONEDA'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(197759537192514689)
,p_name=>'P461_GL_TIPOCAMBIO'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>240
,p_item_plug_id=>wwv_flow_imp.id(197737795791514641)
,p_item_source_plug_id=>wwv_flow_imp.id(197737795791514641)
,p_source=>'GL_TIPOCAMBIO'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(197759949202514689)
,p_name=>'P461_GL_ANNO'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>250
,p_item_plug_id=>wwv_flow_imp.id(197737795791514641)
,p_item_source_plug_id=>wwv_flow_imp.id(197737795791514641)
,p_source=>'GL_ANNO'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(197760351125514689)
,p_name=>'P461_GL_PERIODO'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>270
,p_item_plug_id=>wwv_flow_imp.id(197737795791514641)
,p_item_source_plug_id=>wwv_flow_imp.id(197737795791514641)
,p_source=>'GL_PERIODO'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20260210201444Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(197760689773514689)
,p_name=>'P461_GL_FECHA'
,p_source_data_type=>'DATE'
,p_item_sequence=>280
,p_item_plug_id=>wwv_flow_imp.id(197737795791514641)
,p_item_source_plug_id=>wwv_flow_imp.id(197737795791514641)
,p_source=>'GL_FECHA'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20260210201444Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(197761113416514689)
,p_name=>'P461_GL_REFERENCIA'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>290
,p_item_plug_id=>wwv_flow_imp.id(197737795791514641)
,p_item_source_plug_id=>wwv_flow_imp.id(197737795791514641)
,p_source=>'GL_REFERENCIA'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20260210201444Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(197761575697514690)
,p_name=>'P461_GL_SUBLEDGER'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>300
,p_item_plug_id=>wwv_flow_imp.id(197737795791514641)
,p_item_source_plug_id=>wwv_flow_imp.id(197737795791514641)
,p_source=>'GL_SUBLEDGER'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20260210201444Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(197761896916514690)
,p_name=>'P461_GL_TIPOSUBLEDGER'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>310
,p_item_plug_id=>wwv_flow_imp.id(197737795791514641)
,p_item_source_plug_id=>wwv_flow_imp.id(197737795791514641)
,p_source=>'GL_TIPOSUBLEDGER'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20260210201444Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(197762298791514690)
,p_name=>'P461_GL_CTA_ACTIVO_OBJ'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>320
,p_item_plug_id=>wwv_flow_imp.id(197737795791514641)
,p_item_source_plug_id=>wwv_flow_imp.id(197737795791514641)
,p_source=>'GL_CTA_ACTIVO_OBJ'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20260210201444Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(197762704225514690)
,p_name=>'P461_GL_CTA_ACTIVO_SUB'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>330
,p_item_plug_id=>wwv_flow_imp.id(197737795791514641)
,p_item_source_plug_id=>wwv_flow_imp.id(197737795791514641)
,p_source=>'GL_CTA_ACTIVO_SUB'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20260210201444Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(197763098204514690)
,p_name=>'P461_GL_CTA_DEPACUM_OBJ'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>340
,p_item_plug_id=>wwv_flow_imp.id(197737795791514641)
,p_item_source_plug_id=>wwv_flow_imp.id(197737795791514641)
,p_source=>'GL_CTA_GTODEP_OBJ'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20260210201444Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(197763568656514691)
,p_name=>'P461_GL_CTA_DEPACUM_SUB'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>350
,p_item_plug_id=>wwv_flow_imp.id(197737795791514641)
,p_item_source_plug_id=>wwv_flow_imp.id(197737795791514641)
,p_source=>'GL_CTA_GTODEP_SUB'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20260210201444Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(197763947586514691)
,p_name=>'P461_GL_CTA_GASTODEP_OBJ'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>360
,p_item_plug_id=>wwv_flow_imp.id(197737795791514641)
,p_item_source_plug_id=>wwv_flow_imp.id(197737795791514641)
,p_source=>'GL_CTA_GTODEP_OBJ'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20260210201444Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(197764303927514691)
,p_name=>'P461_GL_CTA_GASTODEP_SUB'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>370
,p_item_plug_id=>wwv_flow_imp.id(197737795791514641)
,p_item_source_plug_id=>wwv_flow_imp.id(197737795791514641)
,p_source=>'GL_CTA_GTODEP_SUB'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20260210201444Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(197778201021514708)
,p_name=>'P461_COSTO'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>160
,p_item_plug_id=>wwv_flow_imp.id(197737795791514641)
,p_item_source_plug_id=>wwv_flow_imp.id(197737795791514641)
,p_prompt=>'Costo'
,p_source=>'COSTO'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>32
,p_cMaxlength=>255
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
,p_attribute_04=>'decimal'
,p_updated_on=>wwv_flow_imp.dz('20260210204716Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(197778248080514708)
,p_name=>'P461_CODUBICACION'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>220
,p_item_plug_id=>wwv_flow_imp.id(197641100767212599)
,p_item_source_plug_id=>wwv_flow_imp.id(197737795791514641)
,p_prompt=>unistr('C\00F3digo Ubicaci\00F3n')
,p_source=>'CODUBICACION'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>32
,p_cMaxlength=>50
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(197778408282514706)
,p_name=>'P461_CODPROVEEDOR'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(197641148181212600)
,p_item_source_plug_id=>wwv_flow_imp.id(197737795791514641)
,p_prompt=>'Proveedor(es)'
,p_source=>'CODPROVEEDOR'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_named_lov=>'LOV_MAESTRO_PROVEEDORES'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select DESCRIPCION as d,',
'       CODIGOPROVEEDOR as r',
'  from VT_JDE_MAESTROPROVEEDOR',
' order by 1'))
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'POPUP'
,p_attribute_02=>'NO_FETCH'
,p_attribute_04=>'N'
,p_attribute_05=>'Y'
,p_attribute_06=>'2'
,p_multi_value_type=>'SEPARATED'
,p_multi_value_separator=>':'
,p_updated_on=>wwv_flow_imp.dz('20260211043430Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(197778545614514708)
,p_name=>'P461_DEPRECIABLE'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(197640863484212597)
,p_item_source_plug_id=>wwv_flow_imp.id(197737795791514641)
,p_item_default=>'S'
,p_prompt=>'Depreciable (S/N)'
,p_source=>'DEPRECIABLE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>unistr('STATIC:S\00CD;S,NO;N')
,p_cHeight=>1
,p_colspan=>6
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'NONE'
,p_updated_on=>wwv_flow_imp.dz('20260211042825Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(197778828815514706)
,p_name=>'P461_NUMEROFACTURA'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(197641148181212600)
,p_item_source_plug_id=>wwv_flow_imp.id(197737795791514641)
,p_prompt=>unistr('N\00FAm. Factura')
,p_source=>'NUMEROFACTURA'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>32
,p_cMaxlength=>100
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'NONE'
,p_updated_on=>wwv_flow_imp.dz('20260211043430Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(197778970194514708)
,p_name=>'P461_METODODEP'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(197640863484212597)
,p_item_source_plug_id=>wwv_flow_imp.id(197737795791514641)
,p_source=>'METODODEP'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20260211042825Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(197779193012514707)
,p_name=>'P461_TIPOORDEN'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(197641148181212600)
,p_item_source_plug_id=>wwv_flow_imp.id(197737795791514641)
,p_prompt=>'Tipo Orden'
,p_source=>'TIPOORDEN'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>32
,p_cMaxlength=>2
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'NONE'
,p_updated_on=>wwv_flow_imp.dz('20260211043430Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(197779491667514708)
,p_name=>'P461_CODCUSTODIO'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>250
,p_item_plug_id=>wwv_flow_imp.id(197641100767212599)
,p_item_source_plug_id=>wwv_flow_imp.id(197737795791514641)
,p_prompt=>'Custodio'
,p_source=>'CODCUSTODIO'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_named_lov=>'LOV_CODDIRECCIONUSUARIO'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select compania, coderp, trim(apellidos)||'' ''||trim(nombres) usuario',
'from data.vt_corp_usuario',
'where coderp is not null',
'order by 2'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'Seleccione'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'POPUP'
,p_attribute_02=>'NO_FETCH'
,p_attribute_04=>'N'
,p_attribute_05=>'Y'
,p_attribute_06=>'2'
,p_updated_on=>wwv_flow_imp.dz('20260129211942Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(197779589088514707)
,p_name=>'P461_ORDENCOMPRA'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(197641148181212600)
,p_item_source_plug_id=>wwv_flow_imp.id(197737795791514641)
,p_prompt=>'Orden Compra'
,p_source=>'ORDENCOMPRA'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>32
,p_cMaxlength=>25
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'NONE'
,p_updated_on=>wwv_flow_imp.dz('20260211043430Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(197781776877514710)
,p_name=>'P461_CENTROCOSTO'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(197640863484212597)
,p_item_source_plug_id=>wwv_flow_imp.id(197737795791514641)
,p_prompt=>'Centro de Costo'
,p_source=>'CENTROCOSTO'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>32
,p_cMaxlength=>12
,p_colspan=>6
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'NONE'
,p_updated_on=>wwv_flow_imp.dz('20260211042825Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(197782162217514710)
,p_name=>'P461_MESESVIDAUTIL'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(197640863484212597)
,p_item_source_plug_id=>wwv_flow_imp.id(197737795791514641)
,p_prompt=>unistr('Meses Vida \00DAtil')
,p_source=>'MESESVIDAUTIL'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>32
,p_cMaxlength=>255
,p_begin_on_new_line=>'N'
,p_colspan=>6
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'left'
,p_attribute_04=>'decimal'
,p_updated_on=>wwv_flow_imp.dz('20260211042825Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(197782284363514712)
,p_name=>'P461_FECHACOMPRA'
,p_source_data_type=>'DATE'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(197641005678212598)
,p_item_source_plug_id=>wwv_flow_imp.id(197737795791514641)
,p_prompt=>'Compra'
,p_format_mask=>'dd/mm/yyyy'
,p_source=>'FECHACOMPRA'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DATE_PICKER_APEX'
,p_cSize=>32
,p_cMaxlength=>255
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'POPUP'
,p_attribute_03=>'NONE'
,p_attribute_06=>'NONE'
,p_attribute_09=>'N'
,p_attribute_11=>'N'
,p_attribute_12=>'MONTH-PICKER:YEAR-PICKER'
,p_attribute_13=>'VISIBLE'
,p_attribute_15=>'FOCUS'
,p_updated_on=>wwv_flow_imp.dz('20260211043429Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(197782547999514711)
,p_name=>'P461_CONVENSIONDEP'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(197640863484212597)
,p_item_source_plug_id=>wwv_flow_imp.id(197737795791514641)
,p_source=>'CONVENSIONDEP'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20260211042825Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(197782648632514713)
,p_name=>'P461_FECHAINIDEP'
,p_source_data_type=>'DATE'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(197641005678212598)
,p_item_source_plug_id=>wwv_flow_imp.id(197737795791514641)
,p_prompt=>unistr('Inicio Depreciaci\00F3n')
,p_format_mask=>'dd/mm/yyyy'
,p_source=>'FECHAINIDEP'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DATE_PICKER_APEX'
,p_cSize=>32
,p_cMaxlength=>255
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'POPUP'
,p_attribute_03=>'NONE'
,p_attribute_06=>'NONE'
,p_attribute_09=>'N'
,p_attribute_11=>'N'
,p_attribute_12=>'MONTH-PICKER:YEAR-PICKER'
,p_attribute_13=>'VISIBLE'
,p_attribute_15=>'FOCUS'
,p_updated_on=>wwv_flow_imp.dz('20260211043429Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(197782924696514711)
,p_name=>'P461_VALORRESIDUAL'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(197640863484212597)
,p_item_source_plug_id=>wwv_flow_imp.id(197737795791514641)
,p_prompt=>'Valor Resisual'
,p_format_mask=>'FML999G999G999G999G990D00'
,p_source=>'VALORRESIDUAL'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>32
,p_begin_on_new_line=>'N'
,p_colspan=>6
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'left'
,p_attribute_04=>'decimal'
,p_updated_on=>wwv_flow_imp.dz('20260211042825Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(197783079713514713)
,p_name=>'P461_FECHAFINDEP'
,p_source_data_type=>'DATE'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(197641005678212598)
,p_item_source_plug_id=>wwv_flow_imp.id(197737795791514641)
,p_prompt=>unistr('Fin Depreciaci\00F3n')
,p_format_mask=>'dd/mm/yyyy'
,p_source=>'FECHAFINDEP'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DATE_PICKER_APEX'
,p_cSize=>32
,p_cMaxlength=>255
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'POPUP'
,p_attribute_03=>'NONE'
,p_attribute_06=>'NONE'
,p_attribute_09=>'N'
,p_attribute_11=>'N'
,p_attribute_12=>'MONTH-PICKER:YEAR-PICKER'
,p_attribute_13=>'VISIBLE'
,p_attribute_15=>'FOCUS'
,p_updated_on=>wwv_flow_imp.dz('20260211043429Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(197783133422514709)
,p_name=>'P461_NOTAS'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>370
,p_item_plug_id=>wwv_flow_imp.id(197641257069212601)
,p_item_source_plug_id=>wwv_flow_imp.id(197737795791514641)
,p_prompt=>'Notas'
,p_source=>'NOTAS'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>60
,p_cMaxlength=>1000
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_updated_on=>wwv_flow_imp.dz('20260211010347Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(197785352515514712)
,p_name=>'P461_CODLIBRO'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(197640863484212597)
,p_item_source_plug_id=>wwv_flow_imp.id(197737795791514641)
,p_source=>'CODLIBRO'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20260211042825Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(197785439465514714)
,p_name=>'P461_FECHAUBICACION'
,p_source_data_type=>'DATE'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(197641005678212598)
,p_item_source_plug_id=>wwv_flow_imp.id(197737795791514641)
,p_item_default=>'to_char(sysdate,''dd/mm/yyyy'')'
,p_item_default_type=>'EXPRESSION'
,p_item_default_language=>'PLSQL'
,p_prompt=>unistr('Ubicaci\00F3n')
,p_format_mask=>'dd/mm/yyyy'
,p_source=>'FECHAUBICACION'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DATE_PICKER_APEX'
,p_cSize=>32
,p_cMaxlength=>255
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'POPUP'
,p_attribute_03=>'NONE'
,p_attribute_06=>'NONE'
,p_attribute_09=>'N'
,p_attribute_11=>'N'
,p_attribute_12=>'MONTH-PICKER:YEAR-PICKER'
,p_attribute_13=>'VISIBLE'
,p_attribute_15=>'FOCUS'
,p_updated_on=>wwv_flow_imp.dz('20260211043429Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(336785320541176406)
,p_name=>'P461_FICHAACTIVO'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(336785279423176405)
,p_prompt=>'Fichaactivo'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_created_on=>wwv_flow_imp.dz('20260130024601Z')
,p_updated_on=>wwv_flow_imp.dz('20260130024601Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(336785474145176407)
,p_name=>'P461_INFOCONTABLE'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(336785279423176405)
,p_prompt=>'Infocontable'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_created_on=>wwv_flow_imp.dz('20260130024601Z')
,p_updated_on=>wwv_flow_imp.dz('20260130024601Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(336785567413176408)
,p_name=>'P461_DEPRECIACION'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(336785279423176405)
,p_prompt=>'Depreciacion'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_created_on=>wwv_flow_imp.dz('20260130024601Z')
,p_updated_on=>wwv_flow_imp.dz('20260130024601Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(336785671716176409)
,p_name=>'P461_CUSTODIO'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(336785279423176405)
,p_prompt=>'Custodio'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_created_on=>wwv_flow_imp.dz('20260130024601Z')
,p_updated_on=>wwv_flow_imp.dz('20260130024601Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(349046407912138638)
,p_name=>'P461_IDS_SELECCIONADOS'
,p_item_sequence=>610
,p_item_plug_id=>wwv_flow_imp.id(99032403954282312)
,p_prompt=>'Ids Seleccionados'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_created_on=>wwv_flow_imp.dz('20260210205222Z')
,p_updated_on=>wwv_flow_imp.dz('20260210205222Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(351292863340162504)
,p_name=>'P461_IDPROYECTO'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>380
,p_item_plug_id=>wwv_flow_imp.id(197641257069212601)
,p_item_source_plug_id=>wwv_flow_imp.id(197737795791514641)
,p_prompt=>'ID Proyecto(s)'
,p_source=>'IDPROYECTO'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_cMaxlength=>100
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_created_on=>wwv_flow_imp.dz('20260211010347Z')
,p_updated_on=>wwv_flow_imp.dz('20260211010347Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(351292952273162505)
,p_name=>'P461_OBSADICIONA1'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>390
,p_item_plug_id=>wwv_flow_imp.id(197641257069212601)
,p_item_source_plug_id=>wwv_flow_imp.id(197737795791514641)
,p_prompt=>'Obs. Adicional 1'
,p_source=>'OBSADICIONA1'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_cMaxlength=>100
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_created_on=>wwv_flow_imp.dz('20260211010347Z')
,p_updated_on=>wwv_flow_imp.dz('20260211010347Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(351293096874162506)
,p_name=>'P461_OBSADICIONA2'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>400
,p_item_plug_id=>wwv_flow_imp.id(197641257069212601)
,p_item_source_plug_id=>wwv_flow_imp.id(197737795791514641)
,p_prompt=>'Obs. Adicional 2'
,p_source=>'OBSADICIONA2'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_cMaxlength=>100
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_created_on=>wwv_flow_imp.dz('20260211010347Z')
,p_updated_on=>wwv_flow_imp.dz('20260211010347Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(351293127659162507)
,p_name=>'P461_OBSADICIONA3'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>410
,p_item_plug_id=>wwv_flow_imp.id(197641257069212601)
,p_item_source_plug_id=>wwv_flow_imp.id(197737795791514641)
,p_prompt=>'Obs. Adicional 3'
,p_source=>'OBSADICIONA3'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_cMaxlength=>100
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_created_on=>wwv_flow_imp.dz('20260211010347Z')
,p_updated_on=>wwv_flow_imp.dz('20260211010347Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(398590099482320640)
,p_name=>'P461_DETALLECOSTO'
,p_source_data_type=>'CLOB'
,p_item_sequence=>380
,p_item_plug_id=>wwv_flow_imp.id(197737795791514641)
,p_item_source_plug_id=>wwv_flow_imp.id(197737795791514641)
,p_source=>'DETALLECOSTO'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_created_on=>wwv_flow_imp.dz('20260326220302Z')
,p_updated_on=>wwv_flow_imp.dz('20260407205759Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(98955460588872113)
,p_validation_name=>'P461_FECHCREA must be timestamp'
,p_validation_sequence=>20
,p_validation=>'P461_FECHCREA'
,p_validation_type=>'ITEM_IS_TIMESTAMP'
,p_error_message=>'#LABEL# must be a valid timestamp.'
,p_associated_item=>wwv_flow_imp.id(197742704656514670)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(98955896092872114)
,p_validation_name=>'P461_FECHMODI must be timestamp'
,p_validation_sequence=>40
,p_validation=>'P461_FECHMODI'
,p_validation_type=>'ITEM_IS_TIMESTAMP'
,p_error_message=>'#LABEL# must be a valid timestamp.'
,p_associated_item=>wwv_flow_imp.id(197743924372514680)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(138315109973755903)
,p_validation_name=>'Valida fecha ini'
,p_validation_sequence=>50
,p_validation=>'TO_CHAR(TO_DATE(:P461_FECHAINIDEP,''DD/MM/YYYY''),''YYYYDDD'')-1900000<=TO_CHAR(TO_DATE(:P461_FECHAFINDEP,''DD/MM/YYYY''),''YYYYDDD'')-1900000'
,p_validation2=>'SQL'
,p_validation_type=>'EXPRESSION'
,p_error_message=>unistr('Inicio Depreciaci\00F3n no puede ser mayor a Fin Depreciaci\00F3n')
,p_always_execute=>'Y'
,p_validation_condition=>':P461_FECHAFINDEP is not null and :P461_FECHAINIDEP is not null'
,p_validation_condition2=>'PLSQL'
,p_validation_condition_type=>'EXPRESSION'
,p_associated_item=>wwv_flow_imp.id(197782648632514713)
,p_error_display_location=>'INLINE_WITH_FIELD'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(99031653720282304)
,p_name=>'Valida ID'
,p_event_sequence=>10
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P461_ID'
,p_condition_element=>'P461_ID'
,p_triggering_condition_type=>'NULL'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(99031728323282305)
,p_event_id=>wwv_flow_imp.id(99031653720282304)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P461_ESTADO'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(99031858433282306)
,p_event_id=>wwv_flow_imp.id(99031653720282304)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P461_ESTADO'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(99032726461282315)
,p_name=>'Calcula Descripcion1'
,p_event_sequence=>20
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P461_CODCATEGORIA,P461_CODSUBCATEGORIA'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
,p_display_when_type=>'EXPRESSION'
,p_display_when_cond=>'1=2'
,p_display_when_cond2=>'PLSQL'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(99032843049282316)
,p_event_id=>wwv_flow_imp.id(99032726461282315)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P461_DESCRIPCION1'
,p_attribute_01=>'FUNCTION_BODY'
,p_attribute_06=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'  DESC1 VARCHAR2(100) := '''';',
'  DESC2 VARCHAR2(100) := '''';',
'BEGIN',
'  BEGIN',
'    SELECT TRIM(DRDL01)',
'    INTO DESC1',
'    FROM VT_JDE_UDC',
'    WHERE DRSY = ''12''',
'      AND DRRT = ''22''',
'      AND TRIM(DRKY) = :P461_CODCATEGORIA;',
'  EXCEPTION',
'    WHEN NO_DATA_FOUND THEN',
'      DESC1 := ''SIN CATEGORIA'';',
'  END;',
'',
'  BEGIN',
'    SELECT TRIM(DRDL01)',
'    INTO DESC2',
'    FROM VT_JDE_UDC',
'    WHERE DRSY = ''12''',
'      AND DRRT = ''23''',
'      AND TRIM(DRKY) = :P461_CODSUBCATEGORIA;',
'  EXCEPTION',
'    WHEN NO_DATA_FOUND THEN',
'      DESC2 := ''SIN SUBCATEGORIA'';',
'  END;',
'',
'  IF DESC1 <> DESC2 THEN',
'    RETURN SUBSTR(DESC1 || '' '' || DESC2,1,30);',
'  ELSE',
'    RETURN DESC1;',
'  END IF;',
'END;',
''))
,p_attribute_07=>'P461_CODCATEGORIA,P461_CODSUBCATEGORIA'
,p_attribute_08=>'Y'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(101623633518473432)
,p_name=>'New'
,p_event_sequence=>30
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(98914851397872064)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(101623776254473433)
,p_event_id=>wwv_flow_imp.id(101623633518473432)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
unistr('// Forzar que la regi\00F3n collapsible "ADJUNTOS" se expanda'),
'$("#regAdjuntos").collapsible("expand");',
'setTimeout(function () {',
'    document.querySelector("#regAdjuntos").scrollIntoView({',
'        behavior: "smooth",',
'        block: "start"',
'    });',
'}, 300);',
'',
''))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(101624301300473439)
,p_name=>'EjecutarBorradoArchivo'
,p_event_sequence=>40
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P461_NUMEROARCHIVO_BORRAR'
,p_condition_element=>'P461_NUMEROARCHIVO_BORRAR'
,p_triggering_condition_type=>'NOT_NULL'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(101624416611473440)
,p_event_id=>wwv_flow_imp.id(101624301300473439)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_CONFIRM'
,p_attribute_01=>unistr('\00BFDeseas eliminar el archivo seleccionado? Esta acci\00F3n no se puede deshacer.')
,p_attribute_03=>'danger'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(101624587053473441)
,p_event_id=>wwv_flow_imp.id(101624301300473439)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DELETE FROM FILES.T_APEX_ARCHIVOS ',
'WHERE NUMEROARCHIVO = :P461_NUMEROARCHIVO_BORRAR;'))
,p_attribute_02=>'P461_NUMEROARCHIVO_BORRAR'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(101624861428473444)
,p_event_id=>wwv_flow_imp.id(101624301300473439)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(101621816219473414)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(101624980919473445)
,p_event_id=>wwv_flow_imp.id(101624301300473439)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P461_NUMEROARCHIVO_BORRAR'
,p_attribute_01=>'FUNCTION_BODY'
,p_attribute_06=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
'    :P461_NUMEROARCHIVO_BORRAR := NULL;',
'END;'))
,p_attribute_08=>'Y'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(101625274684473448)
,p_name=>'CambiaUbicacion'
,p_event_sequence=>50
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P461_CODUBICACION'
,p_condition_element=>'P461_CODUBICACION'
,p_triggering_condition_type=>'NOT_NULL'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(101625317587473449)
,p_event_id=>wwv_flow_imp.id(101625274684473448)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>':P461_LABELUBICACION:=''S'';'
,p_attribute_03=>'P461_LABELUBICACION'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(101625478606473450)
,p_name=>'CambiaCustodio'
,p_event_sequence=>60
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P461_CODCUSTODIO'
,p_condition_element=>'P461_CODCUSTODIO'
,p_triggering_condition_type=>'NOT_NULL'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(101709889131016601)
,p_event_id=>wwv_flow_imp.id(101625478606473450)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>':P461_LABELCUSTODIO:=''S'';'
,p_attribute_03=>'P461_LABELCUSTODIO'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(101710031797016603)
,p_name=>'HabilitaCampos'
,p_event_sequence=>70
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P461_DEPRECIABLE'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(101710164108016604)
,p_event_id=>wwv_flow_imp.id(101710031797016603)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'if ($v("P461_DEPRECIABLE")=="S")',
'   {',
'    apex.item("P461_METODODEP").enable();',
'    apex.item("P461_MESESVIDAUTIL").enable();',
'    apex.item("P461_CONVENSIONDEP").enable();',
'    apex.item("P461_CODLIBRO").enable();',
'   };',
'if ($v("P461_DEPRECIABLE")=="N")',
'   {',
'    apex.item("P461_METODODEP").disable();',
'    apex.item("P461_MESESVIDAUTIL").disable();',
'    apex.item("P461_CONVENSIONDEP").disable();',
'    apex.item("P461_CODLIBRO").disable();',
'   };'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(106487790521337844)
,p_name=>'Calc. Fecha fin dep.'
,p_event_sequence=>80
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P461_FECHACOMPRA,P461_MESESVIDAUTIL'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
,p_updated_on=>wwv_flow_imp.dz('20260218211233Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(106487830530337845)
,p_event_id=>wwv_flow_imp.id(106487790521337844)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>'SELECT ADD_MONTHS(:P461_FECHACOMPRA,NVL(:P461_MESESVIDAUTIL,0)) INTO :P461_FECHAFINDEP  FROM DUAL;'
,p_attribute_02=>'P461_FECHACOMPRA,P461_MESESVIDAUTIL'
,p_attribute_03=>'P461_FECHAFINDEP'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(117850907594716924)
,p_name=>'Procesar Carga'
,p_event_sequence=>90
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(108680884598627641)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
,p_updated_on=>wwv_flow_imp.dz('20260522183508Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(117851082969716925)
,p_event_id=>wwv_flow_imp.id(117850907594716924)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'mostrarBarra();',
''))
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(117851106879716926)
,p_event_id=>wwv_flow_imp.id(117850907594716924)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'v_coderp number;',
'v_mensaje varchar2(999) := '''';',
'v_existe varchar2(1) := '''';',
'v_codactivo varchar2(30) := '''';',
'begin',
'	data.pk_finz_activosfijos.sp_enviaractivojde(:g_compania,:app_user,:p461_id,v_coderp,v_codactivo,v_mensaje);',
'	:p461_coderp	:= v_coderp;',
'	:p461_codactivo	:= v_codactivo;',
'	commit;',
'end;'))
,p_attribute_02=>'P461_ID,P461_CODTIPO,P461_CODCATEGORIA,P461_CODSUBCATEGORIA'
,p_attribute_03=>'P461_CODERP,P461_CODACTIVO'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20260522183508Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(117851651060716931)
,p_event_id=>wwv_flow_imp.id(117850907594716924)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>'DBMS_LOCK.SLEEP(10);'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20260522183508Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(117851585742716930)
,p_event_id=>wwv_flow_imp.id(117850907594716924)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'v_existe varchar2(1);',
'begin',
'	if length(:p461_coderp) > 0 then',
unistr('		-- verifico si se cre\00F3 el activo fijo en JDE'),
'		begin',
'			select ''S'' into v_existe from f1201@jdedtadl',
'			where 1 = 1 and fanumb = :p461_coderp;',
'',
'			exception when no_data_found then v_existe := ''N'';',
'		end;',
'',
'		if v_existe = ''S'' then',
'			-- Genero el LOG',
'			-- pk_finz_activosfijos.sp_log(:g_compania, ''T_FINZ_ACTIVOSFIJOS'', :p461_id, '''', '''', ''BEFORE_MODIFICAR'', :app_page_id, '''', ''CREACION ACTIVO FIJO EN JDE'');',
'',
'			update data.t_finz_activosfijos x set',
'				x.coderp	= :p461_coderp,',
'				x.codactivo	= :p461_codactivo,',
'				x.estado	= ''ENVIADO''',
'			where 1 = 1 and id = :p461_id;',
'',
'			-- Genero el LOG',
'			-- pk_finz_activosfijos.sp_log(:g_compania, ''T_FINZ_ACTIVOSFIJOS'', :p461_id, :p461_coderp, :p461_codactivo, ''AFTER_MODIFICAR'', :app_page_id, '''', ''CREACION ACTIVO FIJO EN JDE'');',
'',
'			:p461_exito := ''S'';',
'		else',
'			:p461_exito := ''N'';',
'		end if;',
'	else',
'		:p461_exito := ''N'';',
'	end if;',
'end;'))
,p_attribute_02=>'P461_ID,P461_CODERP,P461_CODACTIVO'
,p_attribute_03=>'P461_EXITO'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20260522183047Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(117851282820716927)
,p_event_id=>wwv_flow_imp.id(117850907594716924)
,p_event_result=>'TRUE'
,p_action_sequence=>50
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'ocultarBarra();'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(117852230952716937)
,p_event_id=>wwv_flow_imp.id(117850907594716924)
,p_event_result=>'TRUE'
,p_action_sequence=>60
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(197737795791514641)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(117851980529716934)
,p_event_id=>wwv_flow_imp.id(117850907594716924)
,p_event_result=>'TRUE'
,p_action_sequence=>70
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'var exito = $v("P461_EXITO"); // Obtiene el valor del item',
'',
'if (exito === "S") {',
unistr('    // Si se cre\00F3 el AF'),
'    apex.message.showPageSuccess("Activo Fijo creado satisfactoriamente");',
'} else {',
unistr('    // NO se cre\00F3 el AF'),
unistr('    apex.message.showPageSuccess("ERROR al crear Activo Fijo. Comun\00EDquese con el Administrador");'),
'}',
'$(''#btnCancelar'').trigger("click");',
'',
'',
''))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(117852866669716943)
,p_name=>'New_1'
,p_event_sequence=>100
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(98915230663872064)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(117852995965716944)
,p_event_id=>wwv_flow_imp.id(117852866669716943)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
unistr('// Forzar que la regi\00F3n collapsible "HISTORIAL" se expanda'),
'$("#regHistorial").collapsible("expand");',
'setTimeout(function () {',
'    document.querySelector("#regHistorial").scrollIntoView({',
'        behavior: "smooth",',
'        block: "start"',
'    });',
'}, 300);'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(349046271899138636)
,p_name=>'Actualiza Costo'
,p_event_sequence=>110
,p_triggering_element_type=>'JQUERY_SELECTOR'
,p_triggering_element=>'.chkF01, #select-all'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
,p_created_on=>wwv_flow_imp.dz('20260210201158Z')
,p_updated_on=>wwv_flow_imp.dz('20260210201158Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(349046344665138637)
,p_event_id=>wwv_flow_imp.id(349046271899138636)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
unistr('// Funci\00F3n para calcular la suma'),
'function calcularSuma() {',
'    let total = 0;',
'',
'    // Recorremos cada fila del reporte',
'    $(''input[name="f01"]'').each(function() {',
unistr('        // Si el checkbox de esta fila est\00E1 marcado'),
'        if ($(this).is('':checked'')) {',
'            // Buscamos el valor en la misma fila (clase monto-glaa)',
'            // Usamos parseFloat y reemplazamos comas si es necesario',
'            let valorTexto = $(this).closest(''tr'').find(''.monto-glaa'').text();',
'            let valor = parseFloat(valorTexto.replace(/,/g, '''')) || 0;',
'            total += valor;',
'        }',
'    });',
'',
unistr('    // Asignamos el total al campo de la p\00E1gina (con 2 decimales)'),
'    $s(''P461_COSTO'', total.toFixed(2));',
'}',
'',
'// Ejecutamos la suma',
'calcularSuma();'))
,p_created_on=>wwv_flow_imp.dz('20260210201158Z')
,p_updated_on=>wwv_flow_imp.dz('20260210201158Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(355333711192124204)
,p_name=>'Calc. MVU'
,p_event_sequence=>120
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P461_CODTIPO'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
,p_created_on=>wwv_flow_imp.dz('20260218211233Z')
,p_updated_on=>wwv_flow_imp.dz('20260218211233Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(355333852847124205)
,p_event_id=>wwv_flow_imp.id(355333711192124204)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'	select json_value(valor, ''$.vida_util_meses'') into :p461_mesesvidautil',
'	from data.t_corp_udc where id_cabecera = ''FINZ_AFDEP'' and id_tabla = :p461_codtipo;',
'end;'))
,p_attribute_02=>'P461_CODTIPO'
,p_attribute_03=>'P461_MESESVIDAUTIL'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
,p_created_on=>wwv_flow_imp.dz('20260218211233Z')
,p_updated_on=>wwv_flow_imp.dz('20260218211233Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(398589882692320638)
,p_name=>'Obs. 3'
,p_event_sequence=>130
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P461_CODPROVEEDOR'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
,p_created_on=>wwv_flow_imp.dz('20260326210154Z')
,p_updated_on=>wwv_flow_imp.dz('20260326210154Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(398589985420320639)
,p_event_id=>wwv_flow_imp.id(398589882692320638)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'	select trim(abalph) into :p461_obsadiciona3',
'	from f0101@jdedtadl',
'	where aban8 = :p461_codproveedor;',
'',
unistr('	exception when others then :p461_obsadiciona3 := ''SIN INFORMACI\00D3N'';'),
'',
'end;'))
,p_attribute_02=>'P461_CODPROVEEDOR'
,p_attribute_03=>'P461_OBSADICIONA3'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
,p_created_on=>wwv_flow_imp.dz('20260326210154Z')
,p_updated_on=>wwv_flow_imp.dz('20260326210154Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(99032584978282313)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>unistr('Asigna Descripci\00F3n')
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'desc1 varchar2(100) := '''';',
'desc2 varchar2(100) := '''';',
'desc3 varchar2(100) := '''';',
'begin',
'	begin',
'		select drdl01 into desc1',
'		from data.vt_jde_udcjde',
'		where 1 = 1',
'			and drsy = ''12''',
'			and drrt = ''21''',
'			and drky = :p461_codtipo;',
'',
'		exception when no_data_found then desc1 := ''SIN TIPO'';',
'	end;',
'',
'	:p461_descripcion1 := upper(desc1);',
'',
'	begin',
'		select drdl01 into desc2',
'		from data.vt_jde_udcjde',
'		where 1 = 1',
'			and drsy = ''12''',
'			and drrt = ''22''',
'			and drky = :p461_codcategoria;',
'',
unistr('		exception when no_data_found then desc2 := ''SIN CATEGOR\00CDA'';'),
'	end;',
'',
'	begin',
'		select drdl01 into desc3',
'		from vt_jde_udc',
'		where 1 = 1',
'			and drsy = ''12''',
'			and drrt = ''23''',
'			and drky = :p461_codsubcategoria;',
'',
unistr('		exception when no_data_found then desc3 := ''SIN SUBCATEGOR\00CDA'';'),
'	end;',
'',
'	if desc1 != desc2 then',
'		:p461_descripcion2 := upper(substr(desc1 || '' '' || desc2,1,30));',
'	else',
'		:p461_descripcion2 := upper(substr(desc1,1,30));',
'	end if;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>99032584978282313
,p_updated_on=>wwv_flow_imp.dz('20260211050907Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(101709916771016602)
,p_process_sequence=>30
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Custodio, Ubicacion'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
unistr('-- si se cambia UBICACI\00D3N o CUSTODIO'),
'-- se actualiza con SYSDATE el campo de fecha correspondiente',
'if trim(:p461_labelcustodio) is not null then',
'	:p461_fechaasignacion := sysdate;',
'	:p461_labelcustodio := '''';',
'end if;',
'',
'if trim(:p461_labelubicacion) is not null then',
'	:p461_fechaubicacion := sysdate;',
'	:p461_labelubicacion := '''';',
'end if;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>101709916771016602
,p_updated_on=>wwv_flow_imp.dz('20260211033358Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(117852515596716940)
,p_process_sequence=>40
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Log Antes'
,p_process_sql_clob=>'data.PK_FINZ_ACTIVOSFIJOS.SP_LOG(:G_COMPANIA,''T_FINZ_ACTIVOSFIJOS'',:P461_ID,'''','''',''BEFORE_MODIFICAR'',:APP_PAGE_ID,'''',''ACTUALIZACION ACTIVO FIJO'');'
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(98914099661872064)
,p_internal_uid=>117852515596716940
,p_updated_on=>wwv_flow_imp.dz('20260211033358Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(98939087502872095)
,p_process_sequence=>60
,p_process_point=>'AFTER_SUBMIT'
,p_region_id=>wwv_flow_imp.id(197737795791514641)
,p_process_type=>'NATIVE_FORM_DML'
,p_process_name=>'Process form FICHA ACTIVO'
,p_attribute_01=>'REGION_SOURCE'
,p_attribute_05=>'Y'
,p_attribute_06=>'Y'
,p_attribute_08=>'Y'
,p_process_error_message=>'Error al crear o actualizar el registro'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_success_message=>'Registro grabado o actualizado correctamente'
,p_internal_uid=>98939087502872095
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(117852453564716939)
,p_process_sequence=>70
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Log Despues'
,p_process_sql_clob=>'data.PK_FINZ_ACTIVOSFIJOS.SP_LOG(:G_COMPANIA,''T_FINZ_ACTIVOSFIJOS'',:P461_ID,'''','''',''AFTER'',:APP_PAGE_ID,'''',''CREACION ACTIVO FIJO'');'
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(98914476185872064)
,p_internal_uid=>117852453564716939
,p_updated_on=>wwv_flow_imp.dz('20260211033358Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(117852650336716941)
,p_process_sequence=>80
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Log DEspues UPD'
,p_process_sql_clob=>'data.PK_FINZ_ACTIVOSFIJOS.SP_LOG(:G_COMPANIA,''T_FINZ_ACTIVOSFIJOS'',:P461_ID,'''','''',''AFTER_MODIFICAR'',:APP_PAGE_ID,'''',''ACTUALIZACION ACTIVO FIJO'');'
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(98914099661872064)
,p_internal_uid=>117852650336716941
,p_updated_on=>wwv_flow_imp.dz('20260211033358Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(101624037504473436)
,p_process_sequence=>90
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Archivos'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'-- cargo archivo a la tabla definitiva',
'declare v_valor number;',
'begin',
'	data.pk_apex_archivos.sp_creararchivo(',
'		:P461_ARCHVIO',
'		, ''T_FINZ_ACTIVOSFIJOS''',
'		, :P461_ID',
'		, ''''',
'		, :P461_ADJ_OBS',
'		, :app_user',
'		, v_valor',
'	);',
'',
'	update files.t_apex_archivos set estado = 1 where numeroarchivo = v_valor;',
'end;',
''))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(101623467641473430)
,p_internal_uid=>101624037504473436
,p_updated_on=>wwv_flow_imp.dz('20260211033358Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(349046543528138639)
,p_process_sequence=>100
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Cargar ID PD'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'	for i in (',
'		select column_value as id_det',
'		from table(apex_string.split(:p461_ids_seleccionados, '',''))',
'	)',
'	loop',
'		update data.t_finz_pruebadepdet',
'		set estado = estado || ''*'', glsbl = :p461_id',
'		where 1 = 1',
'			and id = i.id_det;',
'	end loop;',
'	:p461_ids_seleccionados := null;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>':p461_id is not null and :P461_IDS_SELECCIONADOS is not null'
,p_process_when_type=>'EXPRESSION'
,p_process_when2=>'PLSQL'
,p_internal_uid=>349046543528138639
,p_created_on=>wwv_flow_imp.dz('20260210210559Z')
,p_updated_on=>wwv_flow_imp.dz('20260224172401Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(355334442644124211)
,p_process_sequence=>110
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Complemento Borrar Registro'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'	update data.t_finz_pruebadepdet',
'	set estado = replace(estado,''*'',null), glsbl = null',
'	where 1 = 1 and trim(glsbl) = :p461_id;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_process_error_message=>'Error la borrar el registro.'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(98913658030872064)
,p_process_success_message=>'Registro Borrado.'
,p_internal_uid=>355334442644124211
,p_created_on=>wwv_flow_imp.dz('20260224171728Z')
,p_updated_on=>wwv_flow_imp.dz('20260224172401Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(98938628681872095)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_region_id=>wwv_flow_imp.id(197737795791514641)
,p_process_type=>'NATIVE_FORM_INIT'
,p_process_name=>'Initialize form FICHA ACTIVO'
,p_internal_uid=>98938628681872095
);
wwv_flow_imp.component_end;
end;
/
