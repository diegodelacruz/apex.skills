prompt --application/pages/page_00445
begin
--   Manifest
--     PAGE: 00445
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>109
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_page.create_page(
 p_id=>445
,p_name=>'PYG INDUSTRIALES - DLG - CRITERIOS DISTRIBUCION (UR)'
,p_alias=>'PYG-INDUSTRIALES-CRITERIOS-DISTRIBUCION'
,p_page_mode=>'MODAL'
,p_step_title=>'CRITERIOS DISTRIBUCION'
,p_autocomplete_on_off=>'OFF'
,p_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'$(document).on("click", ".btn-subir, .btn-bajar", function () {',
'    mostrarBarra();',
'    var region = apex.region("tblCriteriosDist"); // Static ID correcto',
'    var view = region.call("getCurrentView");',
'    var model = view.model;',
'    var $td = $(this).closest("td");',
'    var record = view.getContextRecord($td)[0];',
'',
'    if (!record){ ocultarBarra();return;}',
'    var ordenActual = Number(model.getValue(record, "C020"));',
'    var seqActual   = model.getValue(record, "SEQ_ID");',
'    var direccion   = $(this).hasClass("btn-subir") ? -1 : 1;',
'console.log(ordenActual);',
'    // Reemplazo correcto del getRecords',
'    var allRecords = [];',
'    model.forEach(function(rec) {allRecords.push(rec);});',
'',
'    var index = allRecords.findIndex(r => model.getValue(r, "SEQ_ID") === seqActual);',
'',
'    var indexDestino = index + direccion;',
'    if (indexDestino < 0 || indexDestino >= allRecords.length){ ocultarBarra();return;}',
'',
'    var recordDestino = allRecords[indexDestino];',
'',
'    var seqDestino = model.getValue(recordDestino, "SEQ_ID");',
'',
'    f_llamarInterCambiarOrden(seqActual,seqDestino	).then((resultado) => {',
'        console.log("resultado:"+resultado);',
'        if(resultado=="OK"){',
'          ',
'            region.refresh();',
'        }',
'    }).catch((error) => {',
'       console.log("Hubo un error: " + error);',
'    });',
'    ocultarBarra();',
'});',
'function f_llamarInterCambiarOrden (seqActual, seqDestino){',
'    var result = null;',
'    // Llamada al proceso en el servidor',
'',
'    return new Promise((resolve, reject) => {',
'        apex.server.process(',
'            ''INTERCAMBIAR_ORDEN'', // Nombre del proceso',
'            {',
'                x01:seqActual,',
'                x02:seqDestino,',
'            }, // variables del proceso',
'            {',
'                dataType: "json",',
'                success: function(pData)',
'                {',
'                    result = pData.result;',
'                    resolve(result);  // Resuelve la promesa con los datos del servidor',
'                }',
'                ,error: function(err) {',
'                    // Manejo de errores',
'                    console.error("Error INTERCAMBIAR_ORDEN:", err);',
'                        reject(err);  // Rechaza la promesa en caso de error',
'                }',
'            }',
'        );',
'    });',
'}',
'',
'function f_mostrarocultarcolumnas() {',
'  var regionStaticId = "tblCriteriosDist"; // cambia si es necesario',
'',
'  var map = {',
'    P445_CHK1: "C003",',
'    P445_CHK2: "C004",',
'    P445_CHK3: "C005",',
'    P445_CHK4: "C006",',
'    P445_CHK5: "C007",',
'    P445_CHK6: "C008",',
'    P445_CHK7: "C009",',
'    P445_CHK8: "C010"',
'  };',
'',
'  var region = apex.region(regionStaticId);',
'  if (!region) {',
unistr('    //console.log("No existe la regi\00F3n:", regionStaticId);'),
'    return;',
'  }',
'',
'  var gridView = region.call("getCurrentView");',
'  if (!gridView || !gridView.view$ || !gridView.view$.grid) {',
unistr('    console.log("No se encontr\00F3 la vista de grid para", regionStaticId);'),
'    return;',
'  }',
'',
'  var grid$ = gridView.view$;',
'',
'  Object.entries(map).forEach(function ([itemId, colId]) {',
'    var val = $v(itemId);',
'    var hide = !(val !== "0" && val !== "");',
'',
'    if (hide) {',
'      grid$.grid("hideColumn", colId);',
'    } else {',
'      grid$.grid("showColumn", colId);',
'    }',
'  });',
'',
'  grid$.grid("refreshColumns");',
'}',
''))
,p_javascript_code_onload=>wwv_flow_string.join(wwv_flow_t_varchar2(
'moverToolbar();',
'var existe = !!apex.region("tblCriteriosDist");',
'if (existe){',
'    let grid1 = apex.region("tblCriteriosDist").widget();',
'    let actions1 = grid1.interactiveGrid("getActions");',
'    actions1.hide("save"); ',
'}',
'$(secItems).hide();',
''))
,p_step_template=>wwv_flow_imp.id(37774372912106498)
,p_page_template_options=>'#DEFAULT#'
,p_overwrite_navigation_list=>'Y'
,p_page_component_map=>'21'
,p_last_updated_on=>wwv_flow_imp.dz('20260220144848Z')
,p_last_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(118412996320294010)
,p_plug_name=>'Barra de Acccion'
,p_region_template_options=>'#DEFAULT#:t-Form--stretchInputs'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(38289497777120142)
,p_plug_display_sequence=>20
,p_plug_display_point=>'REGION_POSITION_01'
,p_location=>null
,p_menu_id=>wwv_flow_imp.id(37761271469106475)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(37860983999106559)
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(118413171862294012)
,p_plug_name=>'Items'
,p_region_name=>'secItems'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(38289867500120143)
,p_plug_display_sequence=>50
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(118416126698294042)
,p_plug_name=>unistr('Informaci\00F3n General')
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(38289867500120143)
,p_plug_display_sequence=>20
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(118602213018247909)
,p_plug_name=>'CRITERIOS_DISTRIBUCION'
,p_region_name=>'tblCriteriosDist'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(112813843178917343)
,p_plug_display_sequence=>40
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT',
'SEQ_ID,C001,N001,N002,N003,N004,C002,C003,C004,C005,C006,C007,C008,C009,C010,C011,',
'  to_number(C020)C020,',
'  decode(SEQ_ID,1,null,''subir'') subir,',
'  decode(SEQ_ID,max(seq_id)over(),null,''bajar'') bajar',
'FROM APEX_COLLECTIONS ',
'WHERE COLLECTION_NAME = ''COLECCION_CRITERIOSDIST''',
'AND C001 = :P445_TIPO;'))
,p_plug_source_type=>'NATIVE_IG'
,p_ajax_items_to_submit=>'P445_TIPO'
,p_plug_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_plug_display_when_condition=>'P445_TIPO'
,p_prn_page_header=>'PYG INDUSTRIALES - CRITERIOS DISTRIBIUCION'
);
wwv_flow_imp_page.create_region_column_group(
 p_id=>wwv_flow_imp.id(129167981850853442)
,p_heading=>'OBJETOS DE COSTO'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(118413812003294019)
,p_name=>'APEX$ROW_ACTION'
,p_session_state_data_type=>'VARCHAR2'
,p_item_type=>'NATIVE_ROW_ACTION'
,p_display_sequence=>20
,p_use_as_row_header=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(118413954013294020)
,p_name=>'APEX$ROW_SELECTOR'
,p_session_state_data_type=>'VARCHAR2'
,p_item_type=>'NATIVE_ROW_SELECTOR'
,p_display_sequence=>10
,p_attribute_01=>'Y'
,p_attribute_02=>'Y'
,p_attribute_03=>'N'
,p_use_as_row_header=>false
,p_display_condition_type=>'NEVER'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(118603589565247936)
,p_name=>'SEQ_ID'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'SEQ_ID'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>30
,p_attribute_01=>'Y'
,p_filter_is_required=>false
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_enable_pivot=>false
,p_is_primary_key=>true
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(118986281527315705)
,p_name=>'C010'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'C010'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_YES_NO'
,p_heading=>'&P445_ABT8.'
,p_heading_alignment=>'CENTER'
,p_display_sequence=>310
,p_value_alignment=>'CENTER'
,p_group_id=>wwv_flow_imp.id(129167981850853442)
,p_use_group_for=>'BOTH'
,p_attribute_01=>'N'
,p_attribute_02=>'X'
,p_attribute_03=>unistr('S\00CD')
,p_attribute_04=>'0'
,p_attribute_05=>'NO'
,p_is_required=>false
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_default_type=>'STATIC'
,p_default_expression=>'X'
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(118986399153315706)
,p_name=>'C001'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'C001'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>'FLAG'
,p_heading_alignment=>'CENTER'
,p_display_sequence=>180
,p_value_alignment=>'CENTER'
,p_attribute_05=>'BOTH'
,p_is_required=>false
,p_max_length=>4000
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(118986464578315707)
,p_name=>'N001'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'N001'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_YES_NO'
,p_heading=>'Estado'
,p_heading_alignment=>'CENTER'
,p_display_sequence=>190
,p_value_alignment=>'CENTER'
,p_attribute_01=>'N'
,p_attribute_02=>'1'
,p_attribute_03=>'Activo'
,p_attribute_04=>'0'
,p_attribute_05=>'Inactivo'
,p_is_required=>false
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_lov_type=>'LOV'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_default_type=>'STATIC'
,p_default_expression=>'1'
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(118986575751315708)
,p_name=>'N002'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'N002'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_YES_NO'
,p_heading=>'Ingresos'
,p_heading_alignment=>'CENTER'
,p_display_sequence=>200
,p_value_alignment=>'CENTER'
,p_attribute_01=>'N'
,p_attribute_02=>'1'
,p_attribute_03=>unistr('S\00ED')
,p_attribute_04=>'0'
,p_attribute_05=>'NO'
,p_is_required=>false
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_lov_type=>'LOV'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_default_type=>'STATIC'
,p_default_expression=>'1'
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(118986656992315709)
,p_name=>'N003'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'N003'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_YES_NO'
,p_heading=>'Gastos'
,p_heading_alignment=>'CENTER'
,p_display_sequence=>210
,p_value_alignment=>'CENTER'
,p_attribute_01=>'N'
,p_attribute_02=>'1'
,p_attribute_03=>unistr('S\00ED')
,p_attribute_04=>'0'
,p_attribute_05=>'NO'
,p_is_required=>false
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_lov_type=>'LOV'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_default_type=>'STATIC'
,p_default_expression=>'1'
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(118986793708315710)
,p_name=>'N004'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'N004'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_NUMBER_FIELD'
,p_heading=>'Orden'
,p_heading_alignment=>'RIGHT'
,p_display_sequence=>220
,p_value_alignment=>'RIGHT'
,p_attribute_03=>'left'
,p_attribute_04=>'decimal'
,p_is_required=>false
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(118986859296315711)
,p_name=>'C002'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'C002'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_DISPLAY_ONLY'
,p_heading=>'Referencia'
,p_heading_alignment=>'CENTER'
,p_display_sequence=>230
,p_value_alignment=>'CENTER'
,p_attribute_02=>'VALUE'
,p_attribute_05=>'PLAIN'
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(118986917430315712)
,p_name=>'C003'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'C003'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_YES_NO'
,p_heading=>'&P445_ABT1.'
,p_heading_alignment=>'CENTER'
,p_display_sequence=>240
,p_value_alignment=>'CENTER'
,p_group_id=>wwv_flow_imp.id(129167981850853442)
,p_use_group_for=>'BOTH'
,p_attribute_01=>'N'
,p_attribute_02=>'X'
,p_attribute_03=>unistr('S\00CD')
,p_attribute_04=>'0'
,p_attribute_05=>'NO'
,p_is_required=>false
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_default_type=>'STATIC'
,p_default_expression=>'X'
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(118987023889315713)
,p_name=>'C004'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'C004'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_YES_NO'
,p_heading=>'&P445_ABT2.'
,p_heading_alignment=>'CENTER'
,p_display_sequence=>250
,p_value_alignment=>'CENTER'
,p_group_id=>wwv_flow_imp.id(129167981850853442)
,p_use_group_for=>'BOTH'
,p_attribute_01=>'N'
,p_attribute_02=>'X'
,p_attribute_03=>unistr('S\00CD')
,p_attribute_04=>'0'
,p_attribute_05=>'NO'
,p_is_required=>false
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_default_type=>'STATIC'
,p_default_expression=>'X'
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(118987108698315714)
,p_name=>'C005'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'C005'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_YES_NO'
,p_heading=>'&P445_ABT3.'
,p_heading_alignment=>'CENTER'
,p_display_sequence=>260
,p_value_alignment=>'CENTER'
,p_group_id=>wwv_flow_imp.id(129167981850853442)
,p_use_group_for=>'BOTH'
,p_attribute_01=>'N'
,p_attribute_02=>'X'
,p_attribute_03=>unistr('S\00CD')
,p_attribute_04=>'0'
,p_attribute_05=>'NO'
,p_is_required=>false
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_default_type=>'STATIC'
,p_default_expression=>'X'
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(118987212226315715)
,p_name=>'C006'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'C006'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_YES_NO'
,p_heading=>'&P445_ABT4.'
,p_heading_alignment=>'CENTER'
,p_display_sequence=>270
,p_value_alignment=>'CENTER'
,p_group_id=>wwv_flow_imp.id(129167981850853442)
,p_use_group_for=>'BOTH'
,p_attribute_01=>'N'
,p_attribute_02=>'X'
,p_attribute_03=>unistr('S\00CD')
,p_attribute_04=>'0'
,p_attribute_05=>'NO'
,p_is_required=>false
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_default_type=>'STATIC'
,p_default_expression=>'X'
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(118987397680315716)
,p_name=>'C007'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'C007'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_YES_NO'
,p_heading=>'&P445_ABT5.'
,p_heading_alignment=>'CENTER'
,p_display_sequence=>280
,p_value_alignment=>'CENTER'
,p_group_id=>wwv_flow_imp.id(129167981850853442)
,p_use_group_for=>'BOTH'
,p_attribute_01=>'N'
,p_attribute_02=>'X'
,p_attribute_03=>unistr('S\00CD')
,p_attribute_04=>'0'
,p_attribute_05=>'NO'
,p_is_required=>false
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_default_type=>'STATIC'
,p_default_expression=>'X'
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(118987412536315717)
,p_name=>'C008'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'C008'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_YES_NO'
,p_heading=>'&P445_ABT6.'
,p_heading_alignment=>'CENTER'
,p_display_sequence=>290
,p_value_alignment=>'CENTER'
,p_group_id=>wwv_flow_imp.id(129167981850853442)
,p_use_group_for=>'BOTH'
,p_attribute_01=>'N'
,p_attribute_02=>'X'
,p_attribute_03=>unistr('S\00CD')
,p_attribute_04=>'0'
,p_attribute_05=>'NO'
,p_is_required=>false
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_default_type=>'STATIC'
,p_default_expression=>'X'
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(118987503478315718)
,p_name=>'C009'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'C009'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_YES_NO'
,p_heading=>'&P445_ABT7.'
,p_heading_alignment=>'CENTER'
,p_display_sequence=>300
,p_value_alignment=>'CENTER'
,p_group_id=>wwv_flow_imp.id(129167981850853442)
,p_use_group_for=>'BOTH'
,p_attribute_01=>'N'
,p_attribute_02=>'X'
,p_attribute_03=>unistr('S\00CD')
,p_attribute_04=>'0'
,p_attribute_05=>'NO'
,p_is_required=>false
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_default_type=>'STATIC'
,p_default_expression=>'X'
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(118987866168315721)
,p_name=>'C020'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'C020'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_NUMBER_FIELD'
,p_heading=>'C020'
,p_heading_alignment=>'CENTER'
,p_display_sequence=>320
,p_value_alignment=>'CENTER'
,p_attribute_03=>'left'
,p_attribute_04=>'decimal'
,p_is_required=>false
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(118987920408315722)
,p_name=>'SUBIR'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'SUBIR'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>true
,p_item_type=>'NATIVE_LINK'
,p_heading=>'<span class="fa fa-chevron-circle-up"  title="Subir" aria-hidden="true">'
,p_heading_alignment=>'CENTER'
,p_display_sequence=>330
,p_value_alignment=>'CENTER'
,p_link_target=>'javascript:void(0);'
,p_link_text=>'<span aria-hidden="true" class="fa fa-angle-double-up"></span>'
,p_link_attributes=>'class="btn-subir"'
,p_enable_filter=>false
,p_filter_is_required=>false
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_enable_hide=>false
,p_is_primary_key=>false
,p_include_in_export=>false
,p_escape_on_http_output=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(118988064224315723)
,p_name=>'BAJAR'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'BAJAR'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>true
,p_item_type=>'NATIVE_LINK'
,p_heading=>'<span class="fa fa-chevron-circle-down" title="Bajar" aria-hidden="true"></span>'
,p_heading_alignment=>'CENTER'
,p_display_sequence=>340
,p_value_alignment=>'CENTER'
,p_link_target=>'javascript:void(0);'
,p_link_text=>'<span aria-hidden="true" class="fa fa-angle-double-down"></span>'
,p_link_attributes=>'class="btn-bajar"'
,p_enable_filter=>false
,p_filter_is_required=>false
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_enable_hide=>false
,p_is_primary_key=>false
,p_include_in_export=>false
,p_escape_on_http_output=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(118989148806315734)
,p_name=>'C011'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'C011'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>'texto'
,p_heading_alignment=>'CENTER'
,p_display_sequence=>350
,p_value_alignment=>'CENTER'
,p_attribute_05=>'BOTH'
,p_is_required=>false
,p_max_length=>4000
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_interactive_grid(
 p_id=>wwv_flow_imp.id(118602793561247913)
,p_internal_uid=>118602793561247913
,p_is_editable=>true
,p_edit_operations=>'i:u'
,p_lost_update_check_type=>'VALUES'
,p_add_row_if_empty=>true
,p_submit_checked_rows=>false
,p_lazy_loading=>false
,p_requires_filter=>false
,p_select_first_row=>true
,p_fixed_row_height=>true
,p_pagination_type=>'SCROLL'
,p_show_total_row_count=>true
,p_show_toolbar=>true
,p_enable_save_public_report=>false
,p_enable_subscriptions=>true
,p_enable_flashback=>true
,p_define_chart_view=>true
,p_enable_download=>true
,p_enable_mail_download=>true
,p_fixed_header=>'PAGE'
,p_show_icon_view=>false
,p_show_detail_view=>false
,p_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'function (config) {',
'	return cargarToolbar(config);',
'}'))
);
wwv_flow_imp_page.create_ig_report(
 p_id=>wwv_flow_imp.id(118603160449247915)
,p_interactive_grid_id=>wwv_flow_imp.id(118602793561247913)
,p_static_id=>'1186032'
,p_type=>'PRIMARY'
,p_default_view=>'GRID'
,p_show_row_number=>false
,p_settings_area_expanded=>true
);
wwv_flow_imp_page.create_ig_report_view(
 p_id=>wwv_flow_imp.id(118603331404247919)
,p_report_id=>wwv_flow_imp.id(118603160449247915)
,p_view_type=>'GRID'
,p_stretch_columns=>true
,p_srv_exclude_null_values=>false
,p_srv_only_display_columns=>true
,p_edit_mode=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(118603928308247942)
,p_view_id=>wwv_flow_imp.id(118603331404247919)
,p_display_seq=>3
,p_column_id=>wwv_flow_imp.id(118603589565247936)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>40
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(118634668503370406)
,p_view_id=>wwv_flow_imp.id(118603331404247919)
,p_display_seq=>1
,p_column_id=>wwv_flow_imp.id(118413812003294019)
,p_is_visible=>false
,p_is_frozen=>true
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(118997481513372893)
,p_view_id=>wwv_flow_imp.id(118603331404247919)
,p_display_seq=>15
,p_column_id=>wwv_flow_imp.id(118986281527315705)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>88
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(118999896197377370)
,p_view_id=>wwv_flow_imp.id(118603331404247919)
,p_display_seq=>2
,p_column_id=>wwv_flow_imp.id(118986399153315706)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>64.84699999999998
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(119000858348377376)
,p_view_id=>wwv_flow_imp.id(118603331404247919)
,p_display_seq=>16
,p_column_id=>wwv_flow_imp.id(118986464578315707)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>76
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(119001831927377381)
,p_view_id=>wwv_flow_imp.id(118603331404247919)
,p_display_seq=>6
,p_column_id=>wwv_flow_imp.id(118986575751315708)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>88
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(119002828771377385)
,p_view_id=>wwv_flow_imp.id(118603331404247919)
,p_display_seq=>7
,p_column_id=>wwv_flow_imp.id(118986656992315709)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>86
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(119003765351377390)
,p_view_id=>wwv_flow_imp.id(118603331404247919)
,p_display_seq=>4
,p_column_id=>wwv_flow_imp.id(118986793708315710)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>59
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(119004765617377395)
,p_view_id=>wwv_flow_imp.id(118603331404247919)
,p_display_seq=>5
,p_column_id=>wwv_flow_imp.id(118986859296315711)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>76
,p_sort_order=>1
,p_sort_direction=>'ASC'
,p_sort_nulls=>'LAST'
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(119005788403377401)
,p_view_id=>wwv_flow_imp.id(118603331404247919)
,p_display_seq=>8
,p_column_id=>wwv_flow_imp.id(118986917430315712)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>88
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(119006783198377406)
,p_view_id=>wwv_flow_imp.id(118603331404247919)
,p_display_seq=>9
,p_column_id=>wwv_flow_imp.id(118987023889315713)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>88
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(119007763099377410)
,p_view_id=>wwv_flow_imp.id(118603331404247919)
,p_display_seq=>10
,p_column_id=>wwv_flow_imp.id(118987108698315714)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>88
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(119008756005377415)
,p_view_id=>wwv_flow_imp.id(118603331404247919)
,p_display_seq=>11
,p_column_id=>wwv_flow_imp.id(118987212226315715)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>88
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(119009795534377420)
,p_view_id=>wwv_flow_imp.id(118603331404247919)
,p_display_seq=>12
,p_column_id=>wwv_flow_imp.id(118987397680315716)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>88
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(119010786689377424)
,p_view_id=>wwv_flow_imp.id(118603331404247919)
,p_display_seq=>13
,p_column_id=>wwv_flow_imp.id(118987412536315717)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>88
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(119011784714377428)
,p_view_id=>wwv_flow_imp.id(118603331404247919)
,p_display_seq=>14
,p_column_id=>wwv_flow_imp.id(118987503478315718)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>88
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(120875543625230049)
,p_view_id=>wwv_flow_imp.id(118603331404247919)
,p_display_seq=>19
,p_column_id=>wwv_flow_imp.id(118987866168315721)
,p_is_visible=>false
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(120876491971230058)
,p_view_id=>wwv_flow_imp.id(118603331404247919)
,p_display_seq=>17
,p_column_id=>wwv_flow_imp.id(118987920408315722)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>40
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(120877332402230062)
,p_view_id=>wwv_flow_imp.id(118603331404247919)
,p_display_seq=>18
,p_column_id=>wwv_flow_imp.id(118988064224315723)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>46
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(120980237110645522)
,p_view_id=>wwv_flow_imp.id(118603331404247919)
,p_display_seq=>20
,p_column_id=>wwv_flow_imp.id(118989148806315734)
,p_is_visible=>false
,p_is_frozen=>false
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(118413012654294011)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(118412996320294010)
,p_button_name=>'Atras'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860056812106557)
,p_button_image_alt=>'Atras'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'LEFT'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-arrow-left'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(118986188328315704)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(118602213018247909)
,p_button_name=>'Grabar'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860056812106557)
,p_button_image_alt=>'Grabar'
,p_button_position=>'COPY'
,p_show_processing=>'Y'
,p_button_css_classes=>'btnAccion'
,p_icon_css_classes=>'fa-save'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(129163880832853401)
,p_branch_name=>'Go To Page 444'
,p_branch_action=>'f?p=&APP_ID.:444:&SESSION.::&DEBUG.:444:P444_ID:&G_VALORMTD.&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'BEFORE_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_sequence=>10
,p_branch_condition_type=>'REQUEST_EQUALS_CONDITION'
,p_branch_condition=>'SENDTOLEAVE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(118416201055294043)
,p_name=>'P445_TIPO'
,p_item_sequence=>30
,p_prompt=>'Tipo'
,p_display_as=>'NATIVE_RADIOGROUP'
,p_lov=>'STATIC2:VN;VN,GV;GV'
,p_grid_label_column_span=>1
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--stretchInputs:t-Form-fieldContainer--large:t-Form-fieldContainer--preTextBlock:t-Form-fieldContainer--radioButtonGroup'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'2'
,p_attribute_02=>'SUBMIT'
,p_attribute_03=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(129163946120853402)
,p_name=>'P445_ABT1'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(118413171862294012)
,p_prompt=>'Abt1'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(129164015984853403)
,p_name=>'P445_ABT2'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(118413171862294012)
,p_prompt=>'Abt2'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(129164254453853405)
,p_name=>'P445_ABT3'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(118413171862294012)
,p_prompt=>'Abt3'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(129164373111853406)
,p_name=>'P445_ABT4'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(118413171862294012)
,p_prompt=>'Abt4'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(129164422780853407)
,p_name=>'P445_ABT5'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(118413171862294012)
,p_prompt=>'Abt5'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(129164516396853408)
,p_name=>'P445_ABT6'
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_imp.id(118413171862294012)
,p_prompt=>'Abt6'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(129164610602853409)
,p_name=>'P445_ABT7'
,p_item_sequence=>130
,p_item_plug_id=>wwv_flow_imp.id(118413171862294012)
,p_prompt=>'Abt7'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(129164707466853410)
,p_name=>'P445_ABT8'
,p_item_sequence=>150
,p_item_plug_id=>wwv_flow_imp.id(118413171862294012)
,p_prompt=>'Abt8'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(129165237834853415)
,p_name=>'P445_MENSAJE'
,p_item_sequence=>180
,p_item_plug_id=>wwv_flow_imp.id(118413171862294012)
,p_prompt=>'Mensaje'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(129166781987853430)
,p_name=>'P445_CHK1'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(118413171862294012)
,p_prompt=>'Chk1'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(129166888766853431)
,p_name=>'P445_CHK2'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(118413171862294012)
,p_prompt=>'Chk2'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(129166934088853432)
,p_name=>'P445_CHK3'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(118413171862294012)
,p_prompt=>'Chk3'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(129167097267853433)
,p_name=>'P445_CHK4'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(118413171862294012)
,p_prompt=>'Chk4'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(129167147077853434)
,p_name=>'P445_CHK5'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_imp.id(118413171862294012)
,p_prompt=>'Chk5'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(129167224267853435)
,p_name=>'P445_CHK6'
,p_item_sequence=>120
,p_item_plug_id=>wwv_flow_imp.id(118413171862294012)
,p_prompt=>'Chk6'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(129167314742853436)
,p_name=>'P445_CHK7'
,p_item_sequence=>140
,p_item_plug_id=>wwv_flow_imp.id(118413171862294012)
,p_prompt=>'Chk7'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(129167492823853437)
,p_name=>'P445_CHK8'
,p_item_sequence=>160
,p_item_plug_id=>wwv_flow_imp.id(118413171862294012)
,p_prompt=>'Chk8'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(153934101121255116)
,p_name=>'P445_CARGARPAGINA'
,p_item_sequence=>190
,p_item_plug_id=>wwv_flow_imp.id(118413171862294012)
,p_prompt=>'Cargarpagina'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(126487123123870418)
,p_name=>'Detectar cambios'
,p_event_sequence=>20
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(118602213018247909)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'NATIVE_IG|REGION TYPE|interactivegridselectionchange'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(126487299294870419)
,p_event_id=>wwv_flow_imp.id(126487123123870418)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'var ig$ = apex.region("tblCriteriosDist").widget();',
'var model = ig$.interactiveGrid("getViews", "grid").model;',
'',
'// Cada vez que el modelo cambia, evaluamos si hay datos sin guardar',
'',
'if (model.isChanged()) {',
'    apex.item("P445_TIPO").disable();',
'} else {',
'    apex.item("P445_TIPO").enable();',
'}',
''))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(118414713488294028)
,p_name=>'Save InteractiveGrid'
,p_event_sequence=>30
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(118602213018247909)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'NATIVE_IG|REGION TYPE|interactivegridsave'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(126487379196870420)
,p_event_id=>wwv_flow_imp.id(118414713488294028)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'apex.item("P445_TIPO").enable();'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(118414886710294029)
,p_event_id=>wwv_flow_imp.id(118414713488294028)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    l_tipo  VARCHAR2(50) := :P445_TIPO;',
'    l_json  CLOB;',
'begin',
'   l_json:= pk_finz_distribucion.f_traer_jsonCriteriosDist(l_tipo,''COLECCION_CRITERIOSDIST'');',
'   :G_CRITERIOSDIST := l_json;',
'end;'))
,p_attribute_03=>'G_CRITERIOSDIST'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(118416633565294047)
,p_event_id=>wwv_flow_imp.id(118414713488294028)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(118602213018247909)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(126487459352870421)
,p_name=>'Cambio Tipo'
,p_event_sequence=>40
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P445_TIPO'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
,p_updated_on=>wwv_flow_imp.dz('20260220144703Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(126487518321870422)
,p_event_id=>wwv_flow_imp.id(126487459352870421)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>':G_VALORTCRT:=:P445_TIPO;'
,p_attribute_02=>'P445_TIPO'
,p_attribute_03=>'G_VALORTCRT'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20260220144703Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(129165399111853416)
,p_event_id=>wwv_flow_imp.id(126487459352870421)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_01=>'cambio_tipo'
,p_attribute_02=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(128918387868329347)
,p_name=>'ATRAS'
,p_event_sequence=>50
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(118413012654294011)
,p_triggering_condition_type=>'JAVASCRIPT_EXPRESSION'
,p_triggering_expression=>'apex.page.isChanged()'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(128918455267329348)
,p_event_id=>wwv_flow_imp.id(128918387868329347)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'(function(){',
'  if (!apex.page.isChanged()) return;',
'',
unistr('  // toma hasta 5 \00EDtems cambiados y convierte a label legible'),
'  const ids = Array.from(window._chgP445 || []);',
'  function getLabel(id){',
'    const el = document.querySelector(''label[for="''+id+''"]'');',
'    return el ? el.textContent.trim() : id;',
'  }',
unistr('  const lista = ids.slice(0,5).map(getLabel).join('', '') || ''la p\00E1gina'';'),
'',
'  apex.message.clearErrors();',
'  apex.message.showErrors([{',
'    type: "error",',
'    location: ["page"],',
'    message: "Hay cambios sin guardar en: " + lista + ".",',
'    unsafe: false',
'  }]);',
'',
'  window._blockSubmit = true;',
'})();',
''))
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(128918687814329350)
,p_event_id=>wwv_flow_imp.id(128918387868329347)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_01=>'SENDTOLEAVE'
,p_attribute_02=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(128918527045329349)
,p_event_id=>wwv_flow_imp.id(128918387868329347)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_CANCEL_EVENT'
,p_client_condition_type=>'JAVASCRIPT_EXPRESSION'
,p_client_condition_expression=>'window._blockSubmit === true'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(129167521702853438)
,p_name=>'LoadPage'
,p_event_sequence=>60
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'ready'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(129167643506853439)
,p_event_id=>wwv_flow_imp.id(129167521702853438)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>' f_mostrarocultarcolumnas();'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(153933946357255114)
,p_event_id=>wwv_flow_imp.id(129167521702853438)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_01=>'cargarPagina'
,p_attribute_02=>'Y'
,p_client_condition_type=>'NULL'
,p_client_condition_element=>'P445_CARGARPAGINA'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(153934084359255115)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'CargarPagina'
,p_process_sql_clob=>':P445_CARGARPAGINA:=1;'
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>'cargarPagina'
,p_process_when_type=>'REQUEST_EQUALS_CONDITION'
,p_internal_uid=>153934084359255115
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(118414050250294021)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_region_id=>wwv_flow_imp.id(118602213018247909)
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'CRITERIOS DISTRIBIUCION - Save Interactive Grid Data'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'-- SEQ_ID,C001 BANDERA,N001 ESTADO,N002 INGRESOS,N003 GASTOS,N004 ORDEN,C002 REFERENCIA,C003 ABT1,C004 ABT2,C005 ABT3,C006 ABT4,C007 ABT5,C008 ABT6,C009 ABT7,C010 ABT8 ',
'-- WHERE COLLECTION_NAME = ''COLECCION_CRITERIOSDIST''',
'declare ',
'    V_BANDERA varchar2(399);',
'',
'    V_ESTADO number;',
'    V_INGRESOS number;',
'    V_GASTOS number;',
'    V_ORDEN number;',
'',
'    V_REFERENCIA varchar2(399);',
'    V_ABT1 varchar2(399);',
'    V_ABT2 varchar2(399);',
'    V_ABT3 varchar2(399);',
'    V_ABT4 varchar2(399);',
'    V_ABT5 varchar2(399);',
'    V_ABT6 varchar2(399);',
'    V_ABT7 varchar2(399);',
'    V_ABT8 varchar2(399);',
'',
'    v_cont  number;',
'    v_indx number;',
'    v_APEXROW_STATUS varchar2(399);',
'BEGIN',
'    v_APEXROW_STATUS:=:APEX$ROW_STATUS;',
'    	',
'    V_BANDERA :=trim(upper(:C001));',
'',
'    V_ESTADO :=:N001;',
'    V_INGRESOS :=:N002;',
'    V_GASTOS :=:N003;',
'    V_ORDEN :=:N004;',
'',
'    V_REFERENCIA :=trim(upper(:C002));',
'    V_ABT1 :=trim(upper(:C003));',
'    V_ABT2 :=trim(upper(:C004));',
'    V_ABT3 :=trim(upper(:C005));',
'    V_ABT4 :=trim(upper(:C006));',
'    V_ABT5 :=trim(upper(:C007));',
'    V_ABT6 :=trim(upper(:C008));',
'    V_ABT7 :=trim(upper(:C009));',
'    V_ABT8 :=trim(upper(:C010));',
'    if (:G_VALORTCRT is null)then return;end if;',
'    case v_APEXROW_STATUS  ',
'        WHEN ''C'' THEN',
'           APEX_COLLECTION.ADD_MEMBER   (p_collection_name => ''COLECCION_CRITERIOSDIST''                  ,p_C001=>V_BANDERA,p_N001=>V_ESTADO,p_N002=>V_INGRESOS,p_N003=>V_GASTOS,p_N004=>V_ORDEN,p_C002=>V_REFERENCIA,p_C003=>V_ABT1,p_C004=>V_ABT2,p_C005'
||'=>V_ABT3,p_C006=>V_ABT4,p_C007=>V_ABT5,p_C008=>V_ABT6,p_C009=>V_ABT7,p_C010=>V_ABT8,p_C011=>trim(upper(:C011)),p_C020=>trim(upper(:C020)));',
'        WHEN ''U'' THEN',
'            APEX_COLLECTION.UPDATE_MEMBER(p_collection_name => ''COLECCION_CRITERIOSDIST'',p_seq => :seq_id,p_C001=>V_BANDERA,p_N001=>V_ESTADO,p_N002=>V_INGRESOS,p_N003=>V_GASTOS,p_N004=>V_ORDEN,p_C002=>V_REFERENCIA,p_C003=>V_ABT1,p_C004=>V_ABT2,p_C005'
||'=>V_ABT3,p_C006=>V_ABT4,p_C007=>V_ABT5,p_C008=>V_ABT6,p_C009=>V_ABT7,p_C010=>V_ABT8,p_C011=>trim(upper(:C011)),p_C020=>trim(upper(:C020)));',
'        WHEN ''D'' THEN',
'            APEX_COLLECTION.DELETE_MEMBER(p_collection_name => ''COLECCION_CRITERIOSDIST'',p_seq => :seq_id);',
'            ',
'    END CASE;',
'-- EXCEPTION WHEN OTHERS THEN ',
'--     apex_error.add_error (',
'--     p_message          => ''ERROR::''||v_APEXROW_STATUS||'' ''||SQLERRM  ,',
'--     p_display_location =>apex_error.c_inline_in_notification );',
'END;',
''))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(118986188328315704)
,p_only_for_changed_rows=>'N'
,p_internal_uid=>118414050250294021
,p_updated_on=>wwv_flow_imp.dz('20260220144817Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(118414459859294025)
,p_process_sequence=>30
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'CargarColeccion'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    l_tipo  VARCHAR2(50) := :G_VALORTCRT;',
'    l_json  CLOB;',
'begin',
'    l_json:= pk_finz_distribucion.f_traer_jsonCriteriosDist(l_tipo,''COLECCION_CRITERIOSDIST'');',
'    :G_CRITERIOSDIST:= l_json;',
'    UPDATE  data.t_finz_distribucionmtd SET criterio= l_json WHERE ID=:G_VALORMTD;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_process_error_message=>unistr('Ocurri\00F3 un error al procesar la informaci\00F3n.')
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(118986188328315704)
,p_process_success_message=>'Los datos se han actualizado correctamente.'
,p_internal_uid=>118414459859294025
,p_updated_on=>wwv_flow_imp.dz('20260220144727Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(118414198690294022)
,p_process_sequence=>20
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'SetupPage'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare V_NUMOBJCST number:=0;',
'begin',
'    IF APEX_COLLECTION.COLLECTION_EXISTS(''COLECCION_CRITERIOSDIST'') THEN',
'        APEX_COLLECTION.DELETE_COLLECTION(''COLECCION_CRITERIOSDIST'');',
'        :P445_MENSAJE:=''DELETE_COLLECTION - COLECCION_CRITERIOSDIST'';',
'    END IF;',
'    IF NOT APEX_COLLECTION.COLLECTION_EXISTS(''COLECCION_CRITERIOSDIST'') THEN ',
'        APEX_COLLECTION.CREATE_COLLECTION  (''COLECCION_CRITERIOSDIST''); ',
'        :P445_MENSAJE:=:P445_MENSAJE||''    |   CREATE_COLLECTION - COLECCION_CRITERIOSDIST'';',
'    END IF;',
'',
'    IF (:P445_TIPO IS NULL)THEN ',
'        :P445_TIPO :=:G_VALORTCRT;',
'    END IF;',
'',
'',
'    FOR coltab IN ( ',
'        SELECT  jt.tipo,jt.id,jt.bandera,jt.referencia,jt.estado,jt.flag,jt.ingresos,jt.gastos,jt.orden,jt.ABT1,jt.ABT2,jt.ABT3,jt.ABT4,jt.ABT5,jt.ABT6,jt.ABT7,jt.ABT8,jt.TXT11,jt.TXT20',
'        FROM dual, JSON_TABLE(',
'            :G_CRITERIOSDIST,''$[*]''',
'            COLUMNS (    tipo VARCHAR2(10) PATH ''$.TIPO'',NESTED PATH ''$.DETALLE[*]''',
'                COLUMNS (',
'                        id          NUMBER        PATH ''$.ID'',          bandera     VARCHAR2(10)  PATH ''$.BANDERA'',',
'                        flag        VARCHAR2(10)  PATH ''$.FLAG'',        estado      NUMBER        PATH ''$.ESTADO'',',
'                        ingresos    NUMBER        PATH ''$.INGRESOS'',    gastos      NUMBER        PATH ''$.GASTOS'',',
'                        orden       NUMBER        PATH ''$.ORDEN'',       referencia  VARCHAR2(10)  PATH ''$.REFERENCIA'', ',
'                        ABT1        VARCHAR2(10)  PATH ''$.ABT1'',        ABT2        VARCHAR2(10)  PATH ''$.ABT2'',',
'                        ABT3        VARCHAR2(10)  PATH ''$.ABT3'',        ABT4        VARCHAR2(10)  PATH ''$.ABT4'',',
'                        ABT5        VARCHAR2(10)  PATH ''$.ABT5'',        ABT6        VARCHAR2(10)  PATH ''$.ABT6'',',
'                        ABT7        VARCHAR2(10)  PATH ''$.ABT7'',        ABT8        VARCHAR2(10)  PATH ''$.ABT8'',',
'                        TXT11        VARCHAR2(10)  PATH ''$.TXT11'',      TXT20        VARCHAR2(10)  PATH ''$.TXT20''',
'                )',
'           )',
'         ) jt',
'        ORDER BY ID',
'    )',
'    LOOP',
'        BEGIN',
'            APEX_COLLECTION.ADD_MEMBER(',
'                 p_collection_name =>''COLECCION_CRITERIOSDIST''',
'                ,p_c001 => coltab.BANDERA',
'                ,p_N001 => coltab.ESTADO',
'                ,p_N002 => coltab.INGRESOS',
'                ,p_N003 => coltab.GASTOS',
'                ,p_N004 => coltab.ORDEN',
'                ,p_c002 => coltab.REFERENCIA',
'                ,p_c003 => coltab.ABT1',
'                ,p_c004 => coltab.ABT2',
'                ,p_c005 => coltab.ABT3',
'                ,p_c006 => coltab.ABT4',
'                ,p_c007 => coltab.ABT5',
'                ,p_c008 => coltab.ABT6',
'                ,p_c009 => coltab.ABT7',
'                ,p_c010 => coltab.ABT8',
'                ,p_c011 => coltab.TXT11',
'                ,p_c020 => coltab.id',
'            );        ',
'        EXCEPTION WHEN OTHERS THEN',
'            :P445_MENSAJE:=:P445_MENSAJE||'',ID:''||coltab.ID;',
'        END; ',
'',
'    END LOOP;',
'    ',
'end;',
'',
'begin',
'    FOR     DIMEN IN (SELECT * FROM TABLE( PK_FINZ_DISTRIBUCION.f_auxcfg_tab(:G_COMPANIADIST)))',
'    LOOP',
'        IF (DIMEN.ID=1)THEN :P445_CHK1:=DIMEN.CHK;:P445_ABT1:=NVL(DIMEN.DESCRIP,DIMEN.TIPO_OBJC);DBMS_OUTPUT.PUT_LINE(''P445_CHK1:''||:P445_CHK1||'',P445_ABT1:''||:P445_ABT1||CHR(10)||RPAD(''*'',180,''*''));END IF;',
'        IF (DIMEN.ID=2)THEN :P445_CHK2:=DIMEN.CHK;:P445_ABT2:=NVL(DIMEN.DESCRIP,DIMEN.TIPO_OBJC);DBMS_OUTPUT.PUT_LINE(''P445_CHK2:''||:P445_CHK2||'',P445_ABT2:''||:P445_ABT2||CHR(10)||RPAD(''*'',180,''*''));END IF;',
'        IF (DIMEN.ID=3)THEN :P445_CHK3:=DIMEN.CHK;:P445_ABT3:=NVL(DIMEN.DESCRIP,DIMEN.TIPO_OBJC);DBMS_OUTPUT.PUT_LINE(''P445_CHK3:''||:P445_CHK3||'',P445_ABT3:''||:P445_ABT3||CHR(10)||RPAD(''*'',180,''*''));END IF;',
'        IF (DIMEN.ID=4)THEN :P445_CHK4:=DIMEN.CHK;:P445_ABT4:=NVL(DIMEN.DESCRIP,DIMEN.TIPO_OBJC);DBMS_OUTPUT.PUT_LINE(''P445_CHK4:''||:P445_CHK4||'',P445_ABT4:''||:P445_ABT4||CHR(10)||RPAD(''*'',180,''*''));END IF;',
'        IF (DIMEN.ID=5)THEN :P445_CHK5:=DIMEN.CHK;:P445_ABT5:=NVL(DIMEN.DESCRIP,DIMEN.TIPO_OBJC);DBMS_OUTPUT.PUT_LINE(''P445_CHK5:''||:P445_CHK5||'',P445_ABT5:''||:P445_ABT5||CHR(10)||RPAD(''*'',180,''*''));END IF;',
'        IF (DIMEN.ID=6)THEN :P445_CHK6:=DIMEN.CHK;:P445_ABT6:=NVL(DIMEN.DESCRIP,DIMEN.TIPO_OBJC);DBMS_OUTPUT.PUT_LINE(''P445_CHK6:''||:P445_CHK6||'',P445_ABT6:''||:P445_ABT6||CHR(10)||RPAD(''*'',180,''*''));END IF;',
'        IF (DIMEN.ID=7)THEN :P445_CHK7:=DIMEN.CHK;:P445_ABT7:=NVL(DIMEN.DESCRIP,DIMEN.TIPO_OBJC);DBMS_OUTPUT.PUT_LINE(''P445_CHK7:''||:P445_CHK7||'',P445_ABT7:''||:P445_ABT7||CHR(10)||RPAD(''*'',180,''*''));END IF;',
'        IF (DIMEN.ID=8)THEN :P445_CHK8:=DIMEN.CHK;:P445_ABT8:=NVL(DIMEN.DESCRIP,DIMEN.TIPO_OBJC);DBMS_OUTPUT.PUT_LINE(''P445_CHK8:''||:P445_CHK8||'',P445_ABT8:''||:P445_ABT8||CHR(10)||RPAD(''*'',180,''*''));END IF;',
'        ',
'    END LOOP;',
'END;',
'',
''))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>118414198690294022
,p_updated_on=>wwv_flow_imp.dz('20260220144848Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(118988868869315731)
,p_process_sequence=>10
,p_process_point=>'ON_DEMAND'
,p_region_id=>wwv_flow_imp.id(118602213018247909)
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'INTERCAMBIAR_ORDEN'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    v_orden1  apex_collections%ROWTYPE;',
'    v_orden2  apex_collections%ROWTYPE;',
'    l_json  CLOB;',
'BEGIN',
'    apex_json.open_object;',
unistr('    -- Llama a la funci\00F3n con los par\00E1metros que recibir\00E1 del lado del cliente'),
'    apex_json.write( p_name => ''X01'', p_value => apex_application.g_x01);',
'    apex_json.write( p_name => ''X02'', p_value => apex_application.g_x02);',
'    apex_json.write( p_name => ''X03'', p_value => apex_application.g_x03);',
'',
'    SELECT * INTO v_orden1 ',
'    FROM APEX_COLLECTIONS WHERE COLLECTION_NAME = ''COLECCION_CRITERIOSDIST'' AND SEQ_ID = TO_NUMBER(apex_application.g_x01);',
'    SELECT * INTO v_orden2 ',
'    FROM APEX_COLLECTIONS WHERE COLLECTION_NAME = ''COLECCION_CRITERIOSDIST'' AND SEQ_ID = TO_NUMBER(apex_application.g_x02);',
'',
'    APEX_COLLECTION.UPDATE_MEMBER(p_collection_name => ''COLECCION_CRITERIOSDIST'',p_seq => TO_NUMBER(apex_application.g_x01),',
'    p_n001 => v_orden2.n001,',
'    p_n002 => v_orden2.n002,',
'    p_n003 => v_orden2.n003,',
'    p_n004 => v_orden2.n004,',
'    p_c001 => v_orden2.c001,',
'    p_c002 => v_orden2.c002,',
'    p_c003 => v_orden2.c003,',
'    p_c004 => v_orden2.c004,',
'    p_c005 => v_orden2.c005,',
'    p_c006 => v_orden2.c006,',
'    p_c007 => v_orden2.c007,',
'    p_c008 => v_orden2.c008,',
'    p_c009 => v_orden2.c009,',
'    p_c010 => v_orden2.c010,',
'    p_c011 => v_orden2.c011,',
'    p_c020 => TO_CHAR(v_orden2.c020));',
'    APEX_COLLECTION.UPDATE_MEMBER(p_collection_name => ''COLECCION_CRITERIOSDIST'',p_seq => TO_NUMBER(apex_application.g_x02),',
'    p_n001 => v_orden1.n001,',
'    p_n002 => v_orden1.n002,',
'    p_n003 => v_orden1.n003,',
'    p_n004 => v_orden1.n004,',
'    p_c001 => v_orden1.c001,',
'    p_c002 => v_orden1.c002,',
'    p_c003 => v_orden1.c003,',
'    p_c004 => v_orden1.c004,',
'    p_c005 => v_orden1.c005,',
'    p_c006 => v_orden1.c006,',
'    p_c007 => v_orden1.c007,',
'    p_c008 => v_orden1.c008,',
'    p_c009 => v_orden1.c009,',
'    p_c010 => v_orden1.c010,',
'    p_c011 => v_orden1.c011,',
'    p_c020 => TO_CHAR(v_orden1.c020));',
'        ',
'    -- l_json:= pk_finz_distribucion.f_traer_jsonCriteriosDist(apex_application.g_x03,''COLECCION_CRITERIOSDIST'');',
'',
'    -- Devuelve el resultado para el lado del cliente',
'    apex_json.write( p_name => ''result'', p_value => ''OK'');',
'    -- apex_json.write( p_name => ''l_json'', p_value => l_json);',
'    ',
'    apex_json.close_object;',
'',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>118988868869315731
);
wwv_flow_imp.component_end;
end;
/
