prompt --application/pages/page_00510
begin
--   Manifest
--     PAGE: 00510
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>109
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_page.create_page(
 p_id=>510
,p_name=>unistr('Variaci\00F3n STD')
,p_alias=>unistr('VARIACI\00D3N-STD')
,p_step_title=>unistr('Variaci\00F3n STD')
,p_autocomplete_on_off=>'OFF'
,p_javascript_code_onload=>wwv_flow_string.join(wwv_flow_t_varchar2(
'$(".t-Button.t-Button--icon.t-Button--header.t-Button--headerTree.is-active").click();',
''))
,p_page_template_options=>'#DEFAULT#'
,p_page_component_map=>'18'
,p_created_on=>wwv_flow_imp.dz('20240917194820Z')
,p_last_updated_on=>wwv_flow_imp.dz('20260219123857Z')
,p_created_by=>'MALBAN'
,p_last_updated_by=>'DBURBANO'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(340403637023329201)
,p_plug_name=>unistr('Par\00E1metros')
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(38289867500120143)
,p_plug_display_sequence=>50
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
,p_created_on=>wwv_flow_imp.dz('20260202145343Z')
,p_updated_on=>wwv_flow_imp.dz('20260202145344Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(443469331314771338)
,p_plug_name=>'Barra de acciones'
,p_region_template_options=>'#DEFAULT#:t-Form--stretchInputs'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(38289497777120142)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'REGION_POSITION_01'
,p_location=>null
,p_menu_id=>wwv_flow_imp.id(37761271469106475)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(37860983999106559)
,p_created_on=>wwv_flow_imp.dz('20240917195107Z')
,p_updated_on=>wwv_flow_imp.dz('20240917195107Z')
,p_created_by=>'MALBAN'
,p_updated_by=>'MALBAN'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(459101802315371633)
,p_plug_name=>'Datos'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(37806762584106520)
,p_plug_display_sequence=>60
,p_include_in_reg_disp_sel_yn=>'Y'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT N1',
'	, PRODUCTOLITM',
'	, UM',
'	, N2',
'	, N3',
'	, N4',
'	, N5',
'	, N2*N10*N4 MONTO_PERIODO',
'	, N2*N10*N5 MONTO_ATERIOR',
'	, (N2*N10*N4)-(N2*N10*N5) DIFERENCIA',
'	, N10',
'	, N9',
'	, ROUND(N9/N10,4) COSTO_UNITARIO',
'	, MAQUINA',
'	, N2*N10 TOTAL_UNIDADES',
'	, TRIM(VC1) BODEGA',
'	, DT1 FECHA_LM',
'FROM TEMPORAL',
'WHERE 1 = 1',
'	and COMPANIA = :G_COMPANIA',
'	AND PROGRAMA = ''VARIACION STD''',
'	AND USUARIO = :APP_USER',
'	AND TIPON = 1',
'ORDER BY 1;'))
,p_plug_source_type=>'NATIVE_IR'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'Datos'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
,p_created_on=>wwv_flow_imp.dz('20240930195144Z')
,p_updated_on=>wwv_flow_imp.dz('20260202145343Z')
,p_created_by=>'MALBAN'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(459101999128371634)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'MALBAN'
,p_internal_uid=>459101999128371634
,p_created_on=>wwv_flow_imp.dz('20240930195144Z')
,p_updated_on=>wwv_flow_imp.dz('20260202141458Z')
,p_created_by=>'MALBAN'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(459102010056371635)
,p_db_column_name=>'N1'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Orden Prod.'
,p_column_type=>'NUMBER'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20240930195144Z')
,p_updated_on=>wwv_flow_imp.dz('20260202141458Z')
,p_created_by=>'MALBAN'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(459102107643371636)
,p_db_column_name=>'PRODUCTOLITM'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>unistr('C\00F3d. Producto')
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20240930195144Z')
,p_updated_on=>wwv_flow_imp.dz('20260202141458Z')
,p_created_by=>'MALBAN'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(459102252508371637)
,p_db_column_name=>'UM'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'UM'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20240930195144Z')
,p_updated_on=>wwv_flow_imp.dz('20260202141458Z')
,p_created_by=>'MALBAN'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(459102361799371638)
,p_db_column_name=>'N2'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Cant.'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20240930195144Z')
,p_updated_on=>wwv_flow_imp.dz('20260202141458Z')
,p_created_by=>'MALBAN'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(459102465804371639)
,p_db_column_name=>'N3'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Valor'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_created_on=>wwv_flow_imp.dz('20240930195144Z')
,p_updated_on=>wwv_flow_imp.dz('20241002170453Z')
,p_created_by=>'MALBAN'
,p_updated_by=>'MALBAN'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(459102983437371644)
,p_db_column_name=>'N4'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>unistr('Costo Uni.<br>Per\00EDodo ')
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20241001144849Z')
,p_updated_on=>wwv_flow_imp.dz('20260202141458Z')
,p_created_by=>'MALBAN'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(459103041282371645)
,p_db_column_name=>'N5'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>'Costo Uni.<br> Per. Anterior'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20241001144849Z')
,p_updated_on=>wwv_flow_imp.dz('20260202141458Z')
,p_created_by=>'MALBAN'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(459103531117371650)
,p_db_column_name=>'MONTO_PERIODO'
,p_display_order=>80
,p_column_identifier=>'H'
,p_column_label=>'Monto Per.'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D0099'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20241002170744Z')
,p_updated_on=>wwv_flow_imp.dz('20260202141458Z')
,p_created_by=>'MALBAN'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(462180061918489201)
,p_db_column_name=>'MONTO_ATERIOR'
,p_display_order=>90
,p_column_identifier=>'I'
,p_column_label=>'Monto Ant.'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D0099'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20241002170744Z')
,p_updated_on=>wwv_flow_imp.dz('20260202141458Z')
,p_created_by=>'MALBAN'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(462180131002489202)
,p_db_column_name=>'DIFERENCIA'
,p_display_order=>100
,p_column_identifier=>'J'
,p_column_label=>'Diferencia'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D0099'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20241002170744Z')
,p_updated_on=>wwv_flow_imp.dz('20241002170846Z')
,p_created_by=>'MALBAN'
,p_updated_by=>'MALBAN'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(462184412607489245)
,p_db_column_name=>'N10'
,p_display_order=>110
,p_column_identifier=>'K'
,p_column_label=>'Prst.'
,p_column_type=>'NUMBER'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20241009150219Z')
,p_updated_on=>wwv_flow_imp.dz('20260202141458Z')
,p_created_by=>'MALBAN'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(462184508545489246)
,p_db_column_name=>'N9'
,p_display_order=>120
,p_column_identifier=>'L'
,p_column_label=>'Costo UM'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20241009151555Z')
,p_updated_on=>wwv_flow_imp.dz('20260202141458Z')
,p_created_by=>'MALBAN'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(462184625014489247)
,p_db_column_name=>'COSTO_UNITARIO'
,p_display_order=>130
,p_column_identifier=>'M'
,p_column_label=>'Costo Uni.'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20241009151805Z')
,p_updated_on=>wwv_flow_imp.dz('20260202141458Z')
,p_created_by=>'MALBAN'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(462184772621489248)
,p_db_column_name=>'MAQUINA'
,p_display_order=>140
,p_column_identifier=>'N'
,p_column_label=>unistr('M\00E1quina')
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20241009152226Z')
,p_updated_on=>wwv_flow_imp.dz('20260202141458Z')
,p_created_by=>'MALBAN'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(462184888489489249)
,p_db_column_name=>'TOTAL_UNIDADES'
,p_display_order=>150
,p_column_identifier=>'O'
,p_column_label=>'Total Und.'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20241009153752Z')
,p_updated_on=>wwv_flow_imp.dz('20260202141458Z')
,p_created_by=>'MALBAN'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(469054119141883601)
,p_db_column_name=>'BODEGA'
,p_display_order=>160
,p_column_identifier=>'Q'
,p_column_label=>'Bodega'
,p_column_type=>'STRING'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_rpt_named_lov=>wwv_flow_imp.id(460590899797760795)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20241009165359Z')
,p_updated_on=>wwv_flow_imp.dz('20260202141458Z')
,p_created_by=>'MALBAN'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(492350401388277408)
,p_db_column_name=>'FECHA_LM'
,p_display_order=>170
,p_column_identifier=>'R'
,p_column_label=>'Fecha LM'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_format_mask=>'dd/mm/yyyy'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20241122140621Z')
,p_updated_on=>wwv_flow_imp.dz('20260202141458Z')
,p_created_by=>'MALBAN'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(459706936533193618)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'4597070'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_display_rows=>100000
,p_report_columns=>'N1:PRODUCTOLITM:UM:N10:N2:TOTAL_UNIDADES:N4:MONTO_PERIODO:N5:MONTO_ATERIOR:DIFERENCIA:N9:MAQUINA:BODEGA:FECHA_LM:'
,p_created_on=>wwv_flow_imp.dz('20240930195147Z')
,p_updated_on=>wwv_flow_imp.dz('20260202140924Z')
,p_created_by=>'MALBAN'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_condition(
 p_id=>wwv_flow_imp.id(340385024226291921)
,p_report_id=>wwv_flow_imp.id(459706936533193618)
,p_name=>'Row text contains ''464F040100'''
,p_condition_type=>'SEARCH'
,p_allow_delete=>'Y'
,p_expr=>'464F040100'
,p_enabled=>'Y'
,p_created_on=>wwv_flow_imp.dz('20260202140924Z')
,p_updated_on=>wwv_flow_imp.dz('20260202140924Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(443469867238771343)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(443469331314771338)
,p_button_name=>'BUSCAR'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860056812106557)
,p_button_image_alt=>'Buscar'
,p_icon_css_classes=>'fa-search'
,p_created_on=>wwv_flow_imp.dz('20240917212016Z')
,p_updated_on=>wwv_flow_imp.dz('20241002172629Z')
,p_created_by=>'MALBAN'
,p_updated_by=>'MALBAN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(443469536778771340)
,p_name=>'P510_FECDESDE'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(340403637023329201)
,p_item_default=>'to_char(sysdate,''mm-yyyy'')'
,p_item_default_type=>'EXPRESSION'
,p_item_default_language=>'PLSQL'
,p_prompt=>'Periodo: '
,p_format_mask=>'MM-YYYY'
,p_display_as=>'NATIVE_DATE_PICKER_APEX'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'POPUP'
,p_attribute_03=>'NONE'
,p_attribute_06=>'NONE'
,p_attribute_09=>'N'
,p_attribute_11=>'Y'
,p_created_on=>wwv_flow_imp.dz('20240917211839Z')
,p_updated_on=>wwv_flow_imp.dz('20260202145535Z')
,p_created_by=>'MALBAN'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(443469640802771341)
,p_name=>'P510_FECHASTA'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(340403637023329201)
,p_prompt=>'Fecha hasta: '
,p_display_as=>'NATIVE_DATE_PICKER_APEX'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_display_when=>'1=2'
,p_display_when2=>'PLSQL'
,p_display_when_type=>'EXPRESSION'
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'POPUP'
,p_attribute_03=>'NONE'
,p_attribute_06=>'NONE'
,p_attribute_09=>'N'
,p_attribute_11=>'Y'
,p_created_on=>wwv_flow_imp.dz('20240917211839Z')
,p_updated_on=>wwv_flow_imp.dz('20260202145344Z')
,p_created_by=>'MALBAN'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(459102507435371640)
,p_name=>'P510_DIAS'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(340403637023329201)
,p_prompt=>unistr('# D\00EDas : ')
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_display_when=>'1=2'
,p_display_when2=>'PLSQL'
,p_display_when_type=>'EXPRESSION'
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_03=>'left'
,p_attribute_04=>'decimal'
,p_created_on=>wwv_flow_imp.dz('20240930211555Z')
,p_updated_on=>wwv_flow_imp.dz('20260202145344Z')
,p_created_by=>'MALBAN'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(459102871186371643)
,p_name=>'P510_BODEGA'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(340403637023329201)
,p_prompt=>'Bodega: '
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'LOV_JDE_BODPRODUCTIVAS'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT DESCRIPCION , CODUNIDAD ',
'FROM VT_JDE_BODEGAS',
'WHERE CODUNIDAD IN (''17005'',''17009'',''17016'',''17022'')',
'ORDER BY 1'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'Seleccione'
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'NONE'
,p_created_on=>wwv_flow_imp.dz('20241001140232Z')
,p_updated_on=>wwv_flow_imp.dz('20260202145535Z')
,p_created_by=>'MALBAN'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(443469491701771339)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Datos'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'V_FECDESDE  NUMBER :=0;',
'V_FECHASTA  NUMBER :=0;',
'V_FECHASTA2  NUMBER :=0;',
'FECHA DATE;',
'V_ANIO NUMBER :=0;',
'V_MES NUMBER :=0;',
'BEGIN',
'	-- convierto a juliano',
'	V_FECDESDE:=TO_CHAR(TO_DATE(''01''||:P510_FECDESDE,''DD/MM/YYYY''),''YYYYDDD'')-1900000 ;',
'	--V_FECHASTA:=V_FECDESDE+:P510_DIAS;',
'	V_FECHASTA2:=TO_CHAR(LAST_DAY(TO_DATE(''01''||:P510_FECDESDE,''DD/MM/YYYY'')),''YYYYDDD'')-1900000 ;',
'',
'	--raise_application_error (-20001,''LAST_DAY: ''||LAST_DAY(TO_DATE(''01''||:P510_FECDESDE,''DD/MM/YYYY'')));',
'	-- borro tabla temporal',
'	DELETE FROM TEMPORAL WHERE COMPANIA=:G_COMPANIA AND PROGRAMA=''VARIACION STD'' AND USUARIO=:APP_USER;',
'',
'	--- inserto lo registros de la F4111 tipo IC y se encuentren entre las fechas ingresadas',
'',
'	INSERT INTO TEMPORAL(COMPANIA,PROGRAMA,USUARIO,N1,PRODUCTOITM,PRODUCTOLITM,UM,N2,N3,MAQUINA,TIPON,N10,N9,VC1,DT1)',
'	SELECT :G_COMPANIA',
'		, ''VARIACION STD''',
'		, :APP_USER',
'		, ILDOCO',
'		, ILITM',
'		, ILLITM',
'		, ILTRUM --um',
'		, SUM(ILTRQT)/10000 --n2',
'		, SUM(ILPAID)/100 --n3',
'		, TRIM(WAMCU) -- maquina',
'		, 1',
'		, 0',
'		, ILUNCS/10000',
'		, ILMCU',
'		, TO_DATE(ILDGL + 1900000,''YYYYDDD'')',
'	FROM F4111@JDEDTADL, F4801@JDEDTADL',
'	WHERE 1 = 1',
'		and ILDCT = ''IC''',
'		AND ILKCO = :G_COMPANIA',
'		AND (ILMCU = LPAD(:P510_BODEGA,12,'' '') or :P510_BODEGA IS NULL)',
'		AND ILDOCO = WADOCO',
'		AND ILDGL BETWEEN V_FECDESDE AND V_FECHASTA2',
'	GROUP BY ILDOCO,ILITM,ILLITM,ILTRUM,TRIM(WAMCU),ILUNCS,ILMCU,TO_DATE(ILDGL + 1900000,''YYYYDDD'');',
'',
unistr('	-- actualizo la presentaci\00F3n'),
'	-- UPDATE TEMPORAL',
'	-- SET N10 = (',
'	-- 	SELECT DECODE(TRIM(UM),''UN'',1,''KG'',1,DECODE(TRIM(IMSRP7),''044'',1,''001'',1,TO_NUMBER(REGEXP_SUBSTR(TRIM(DRDL01), ''[[:digit:].]+''))))',
'	-- 	FROM F0005@jdectldl,F4101@JDEDTADL',
'	-- 	WHERE PRODUCTOITM = IMITM AND DRSY = ''41'' AND DRRT = ''07'' AND TRIM(IMSRP7) = TRIM(DRKY))',
'	-- WHERE 1 = 1',
'	-- 	and COMPANIA=:G_COMPANIA',
'	-- 	AND PROGRAMA = ''VARIACION STD''',
'	-- 	AND USUARIO = :APP_USER',
'	-- 	AND EXISTS (',
'	-- 		SELECT ''X''',
'	-- 		FROM F0005@jdectldl,F4101@JDEDTADL',
'	-- 		WHERE PRODUCTOITM=IMITM AND DRSY=''41'' AND DRRT=''07'' AND TRIM(IMSRP7)=TRIM(DRKY));',
'',
'    UPDATE data.temporal t',
'       SET t.n10 = CASE t.um',
'                   WHEN ''KG'' THEN 1',
'                   WHEN ''UN'' THEN 1',
'                   ELSE (SELECT umconv/10000000 FROM f41002@jdedtadl WHERE umitm = t.productoitm AND umum = t.um AND umrum = ''UN'')',
'                   END ',
'     WHERE t.compania = :g_compania',
'	   AND t.programa = ''VARIACION STD''',
'       AND t.usuario = :app_user',
';',
unistr('    -- obtengo a\00F1o y mes para obtener el st\00E1ndar aprobado'),
'	V_ANIO	:= TO_CHAR(TO_DATE(''01''||:P510_FECDESDE,''DD/MM/YYYY''),''YYYY'');',
'	V_MES	:= TO_CHAR(TO_DATE(''01''||:P510_FECDESDE,''DD/MM/YYYY''),''MM'');',
'',
unistr('	-- Actualizo en N20 el ID de la tabla de est\00E1ndares aprobado de acuerdo a la m\00E1quina'),
'	UPDATE TEMPORAL',
'	SET N20 = (',
'		SELECT IDCAB ',
'		FROM VT_FINZ_COSTEO',
'		WHERE 1 = 1',
'			and ANNO=V_ANIO',
'			AND MES=V_MES',
'			AND TRIM(CODIGOMAQUINA)=TRIM(MAQUINA)',
'			AND ESTADO = ''CONFIRMADO''',
'			AND CODIGOESTADO = ''APROBADO''',
'			AND NUMEROVERSION = (',
'				SELECT MAX(NUMEROVERSION)',
'				FROM VT_FINZ_COSTEO',
'				WHERE 1 = 1',
'					and ANNO = V_ANIO',
'					AND MES = V_MES',
'					AND TRIM(CODIGOMAQUINA) = TRIM(MAQUINA)',
'					AND ESTADO = ''CONFIRMADO''',
'					AND CODIGOESTADO=''APROBADO''',
'				)',
'			)',
'	WHERE 1 = 1',
'		and COMPANIA = :G_COMPANIA',
'		AND PROGRAMA = ''VARIACION STD''',
'		AND USUARIO = :APP_USER',
'		AND EXISTS (',
'			SELECT ''X''',
'			FROM VT_FINZ_COSTEO',
'			WHERE 1 = 1',
'				and ANNO=V_ANIO',
'				AND MES = V_MES',
'				AND TRIM(CODIGOMAQUINA)=TRIM(MAQUINA)',
'				AND ESTADO=''CONFIRMADO''',
'				AND CODIGOESTADO=''APROBADO''',
'				AND NUMEROVERSION = (',
'					SELECT MAX(NUMEROVERSION)',
'					FROM VT_FINZ_COSTEO',
'					WHERE 1 = 1',
'						and ANNO = V_ANIO',
'						AND MES = V_MES',
'						AND TRIM(CODIGOMAQUINA) = TRIM(MAQUINA)',
'						AND ESTADO = ''CONFIRMADO''',
'						AND CODIGOESTADO = ''APROBADO''',
'                    )',
'				);',
'',
unistr('	-- Actualizo en N21 el ID de la tabla de est\00E1ndares aprobado del mes anterior de acuerdo a la m\00E1quina'),
'	UPDATE TEMPORAL',
'	SET N21 = (SELECT IDAPR FROM VT_FINZ_COSTEOPER WHERE ID = N20)',
'	WHERE COMPANIA = :G_COMPANIA AND PROGRAMA = ''VARIACION STD'' AND USUARIO = :APP_USER AND EXISTS (SELECT ''X'' FROM VT_FINZ_COSTEOPER WHERE ID = N20);',
'',
unistr('	-- Actualizo el costo unitario por m\00E1quina para el periodo ingresado'),
'	UPDATE TEMPORAL',
'	SET N4 = (SELECT ROUND(COSTOUNITARIO,4) FROM VT_FINZ_COSTEOTSA WHERE IDCAB = N20 AND TRIM(CODIGOMAQUINA)=TRIM(MAQUINA))',
'	WHERE COMPANIA = :G_COMPANIA AND PROGRAMA = ''VARIACION STD'' AND USUARIO = :APP_USER AND EXISTS (SELECT ''X'' FROM VT_FINZ_COSTEOTSA WHERE IDCAB = N20 AND TRIM(CODIGOMAQUINA) = TRIM(MAQUINA));',
'',
unistr('	-- Actualizo el costo unitario por m\00E1quina para el periodo anterior'),
'	UPDATE TEMPORAL',
'	SET N5 = (SELECT ROUND(COSTOUNITARIO,4) FROM VT_FINZ_COSTEOTSA WHERE IDCAB = N21 AND TRIM(CODIGOMAQUINA) = TRIM(MAQUINA))',
'	WHERE COMPANIA = :G_COMPANIA AND PROGRAMA = ''VARIACION STD'' AND USUARIO = :APP_USER AND EXISTS (SELECT ''X'' FROM VT_FINZ_COSTEOTSA WHERE IDCAB = N21 AND TRIM(CODIGOMAQUINA) = TRIM(MAQUINA));',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>443469491701771339
,p_created_on=>wwv_flow_imp.dz('20240917201952Z')
,p_updated_on=>wwv_flow_imp.dz('20260219123857Z')
,p_created_by=>'MALBAN'
,p_updated_by=>'DBURBANO'
);
wwv_flow_imp.component_end;
end;
/
