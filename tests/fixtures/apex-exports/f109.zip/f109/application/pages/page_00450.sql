prompt --application/pages/page_00450
begin
--   Manifest
--     PAGE: 00450
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>109
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_page.create_page(
 p_id=>450
,p_name=>'PYG INDUSTRIALES - DLG - DETALLE DE DISTRIBUCION'
,p_alias=>'PYG-INDUSTRIALES-DLG-DETALLE-DE-DISTRIBUCION'
,p_page_mode=>'MODAL'
,p_step_title=>unistr('DETALLE DE DISTRIBUCI\00D3N')
,p_autocomplete_on_off=>'OFF'
,p_javascript_code_onload=>'$(secItems).hide();'
,p_step_template=>wwv_flow_imp.id(37774372912106498)
,p_page_template_options=>'#DEFAULT#'
,p_dialog_width=>'1200px'
,p_protection_level=>'C'
,p_page_component_map=>'18'
,p_last_updated_on=>wwv_flow_imp.dz('20260219163705Z')
,p_last_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(153935687758255131)
,p_plug_name=>'Items'
,p_region_name=>'secItems'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(38289867500120143)
,p_plug_display_sequence=>40
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(153935790488255132)
,p_plug_name=>'Cabecera'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(38289867500120143)
,p_plug_display_sequence=>10
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(153936709050255142)
,p_plug_name=>'Reporte'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(37806762584106520)
,p_plug_display_sequence=>30
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ',
'     num01 gllv1',
'    ,num02 gllv2',
'    ,num03 glfy',
'    ,num04 glan8',
'    ,txt01 gllitm',
'    ,txt02 glmcu',
'    ,txt03 globj',
'    ,txt04 glsub',
'    ,txt05 glcta',
'    ,num05 glaa ',
'from t_tmp_b ;'))
,p_plug_source_type=>'NATIVE_IR'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
,p_updated_on=>wwv_flow_imp.dz('20260219163705Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(153936884901255143)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'EMASABANDA'
,p_internal_uid=>153936884901255143
,p_updated_on=>wwv_flow_imp.dz('20260219163705Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(153936998695255144)
,p_db_column_name=>'GLLV1'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Nivel 1'
,p_column_type=>'NUMBER'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_rpt_named_lov=>wwv_flow_imp.id(119193859528059131)
,p_rpt_show_filter_lov=>'1'
,p_display_condition_type=>'ITEM_IS_NULL'
,p_display_condition=>'P450_OPCION'
,p_use_as_row_header=>'N'
,p_updated_on=>wwv_flow_imp.dz('20260219163705Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(153937035396255145)
,p_db_column_name=>'GLLV2'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Nivel 2'
,p_column_type=>'NUMBER'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_rpt_named_lov=>wwv_flow_imp.id(119194387269080626)
,p_rpt_show_filter_lov=>'1'
,p_display_condition_type=>'ITEM_IS_NULL'
,p_display_condition=>'P450_OPCION'
,p_use_as_row_header=>'N'
,p_updated_on=>wwv_flow_imp.dz('20260219163705Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(153937187445255146)
,p_db_column_name=>'GLFY'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Glfy'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(153937223756255147)
,p_db_column_name=>'GLAN8'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Direccion'
,p_column_type=>'NUMBER'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_rpt_named_lov=>wwv_flow_imp.id(92685403493351092)
,p_rpt_show_filter_lov=>'1'
,p_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_display_condition=>'P450_ESCLIENTE'
,p_display_condition2=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(153937397868255148)
,p_db_column_name=>'GLLITM'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Producto'
,p_column_type=>'STRING'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_rpt_named_lov=>wwv_flow_imp.id(464664643734590584)
,p_rpt_show_filter_lov=>'1'
,p_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_display_condition=>'P450_ESPRODUCTO'
,p_display_condition2=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(153937433867255149)
,p_db_column_name=>'GLMCU'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'M.C.U.'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_display_condition=>'P450_ESCUENTA'
,p_display_condition2=>'2'
,p_use_as_row_header=>'N'
,p_updated_on=>wwv_flow_imp.dz('20260219162625Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(153937597499255150)
,p_db_column_name=>'GLOBJ'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>'Objeto'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_display_condition=>'P450_ESCUENTA'
,p_display_condition2=>'2'
,p_use_as_row_header=>'N'
,p_updated_on=>wwv_flow_imp.dz('20260219162625Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(168141036835781701)
,p_db_column_name=>'GLSUB'
,p_display_order=>80
,p_column_identifier=>'H'
,p_column_label=>'Sub'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_display_condition=>'P450_ESCUENTA'
,p_display_condition2=>'2'
,p_use_as_row_header=>'N'
,p_updated_on=>wwv_flow_imp.dz('20260219162625Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(292380041244702236)
,p_db_column_name=>'GLCTA'
,p_display_order=>90
,p_column_identifier=>'J'
,p_column_label=>'Cuenta Contable'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_display_condition=>'P450_ESCUENTA'
,p_display_condition2=>'1'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20260219162322Z')
,p_updated_on=>wwv_flow_imp.dz('20260219163539Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(168141177637781702)
,p_db_column_name=>'GLAA'
,p_display_order=>100
,p_column_identifier=>'I'
,p_column_label=>'Total'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G990D00'
,p_use_as_row_header=>'N'
,p_updated_on=>wwv_flow_imp.dz('20260219162625Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(168150210158787409)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'1681503'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_display_rows=>100000
,p_report_columns=>'GLLV1:GLLV2:GLCTA:GLAN8:GLLITM:GLAA:'
,p_updated_on=>wwv_flow_imp.dz('20260219163645Z')
,p_updated_by=>'EMASABANDA'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(168142590608781716)
,p_plug_name=>'Botones'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(38290276266120143)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_03'
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(168142672220781717)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(168142590608781716)
,p_button_name=>'Cerrar'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860181880106559)
,p_button_image_alt=>'Cerrar'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(153935882215255133)
,p_name=>'P450_LVL1'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(153935687758255131)
,p_prompt=>'Lvl1'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(153935902211255134)
,p_name=>'P450_LVL2'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(153935687758255131)
,p_prompt=>'Lvl2'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(153936074899255135)
,p_name=>'P450_ANIO'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(153935687758255131)
,p_prompt=>'Anio'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(153936184494255136)
,p_name=>'P450_MES'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(153935687758255131)
,p_prompt=>'Mes'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(153936284417255137)
,p_name=>'P450_PERIODO'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(153935790488255132)
,p_prompt=>'Periodo'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(153936345322255138)
,p_name=>'P450_NIVEL_1'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(153935790488255132)
,p_prompt=>'Nivel 1'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_named_lov=>'LOV_PYG_NIVEL01'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT  TRIM(DRKY) || '' - '' || DRDL01 D, TRIM(DRKY) R ',
'FROM VT_JDE_UDC ',
'WHERE DRSY=''09'' AND DRRT IN (''41'') AND TRIM(DRKY) IS NOT NULL ',
'ORDER BY DRRT, TO_NUMBER(TRIM(DRKY))'))
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'Y'
,p_attribute_02=>'LOV'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(153936450645255139)
,p_name=>'P450_NIVEL_2'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(153935790488255132)
,p_prompt=>'Nivel 2'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_named_lov=>'LOV_PYG_NIVEL02'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT  TRIM(DRKY) || '' - '' || DRDL01 D, TRIM(DRKY) R ',
'FROM VT_JDE_UDC ',
'WHERE DRSY=''09'' AND DRRT IN (''42'') AND TRIM(DRKY) IS NOT NULL ',
'ORDER BY DRRT, TO_NUMBER(TRIM(DRKY))'))
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'Y'
,p_attribute_02=>'LOV'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(153936628882255141)
,p_name=>'P450_OPCION'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(153935790488255132)
,p_prompt=>'Agrupado Por'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>'STATIC2:Cliente;C,Producto;P,Cuenta Contable;Q'
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--stretchInputs:t-Form-fieldContainer--radioButtonGroup'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'5'
,p_multi_value_type=>'SEPARATED'
,p_multi_value_separator=>':'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(168141426319781705)
,p_name=>'P450_QRY'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(153935687758255131)
,p_prompt=>'Qry'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(168141812039781709)
,p_name=>'P450_ESCLIENTE'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(153935687758255131)
,p_prompt=>'Escliente'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(168141924194781710)
,p_name=>'P450_ESPRODUCTO'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(153935687758255131)
,p_prompt=>'Esproducto'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(168142069342781711)
,p_name=>'P450_ESCUENTA'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(153935687758255131)
,p_prompt=>'Escuenta'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(168142249705781713)
,p_name=>'CambioOpcion'
,p_event_sequence=>10
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P450_OPCION'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(168142375807781714)
,p_event_id=>wwv_flow_imp.id(168142249705781713)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_01=>'CAMBIO'
,p_attribute_02=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(168142761002781718)
,p_name=>'Cerrar'
,p_event_sequence=>20
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(168142672220781717)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(168142831663781719)
,p_event_id=>wwv_flow_imp.id(168142761002781718)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CLOSE'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(153935525837255130)
,p_process_sequence=>20
,p_process_point=>'AFTER_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Setup Page'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE ',
'    V_ANIO NUMBER:=:P450_ANIO;',
'    V_MES  NUMBER:=:P450_MES;',
'    V_LVL1 VARCHAR2(9):=:P450_LVL1;',
'    V_LVL2 VARCHAR2(9):=:P450_LVL2;',
'    V_OPCION VARCHAR2(39):=REPLACE(:P450_OPCION,'':'','','');',
'    V_PERIODO VARCHAR2(39):=TO_CHAR(to_date(V_ANIO||to_char(V_MES,''00''),''YYMM''),''Month-yyyy'');',
'    V_SQL CLOB:='''';',
'  BEGIN',
'    :P450_NIVEL_1:=:P450_LVL1;',
'    :P450_NIVEL_2:=:P450_LVL2;',
'    :P450_PERIODO:=V_PERIODO;',
'    EXECUTE IMMEDIATE ''truncate table t_tmp_b drop storage'';',
'    V_SQL:=:P450_QRY;',
'    IF (V_SQL IS NULL)THEN ',
'        :P450_OPCION:=''C:P:Q'';',
'        :P450_ESCLIENTE:=1;',
'        :P450_ESPRODUCTO:=1;',
'        :P450_ESCUENTA:=1;',
'        V_SQL:=''insert into t_tmp_b(num01,num02,num03,num04,txt01,txt02,txt03,txt04,txt05,num05)'';',
'        V_SQL:=V_SQL||'' select gllv1,gllv2,glfy,glan8,TRIM(gllitm)gllitm,TRIM(glmcu)glmcu,TRIM(globj)globj,TRIM(glsub)glsub,rtrim(TRIM(glmcu)||''''.''''||TRIM(globj)||''''.''''||TRIM(glsub),''''.'''')glcta,abs(SUM(glaa))glaa'';',
'        V_SQL:=V_SQL||'' from vt_finz_distribucion'' ||CHR(10);',
'        V_SQL:=V_SQL||'' where glfy =''||V_ANIO||'' AND glpn= ''||V_MES||',
' 	 	case when V_LVL1 is not null then '' and gllv1 =''||V_LVL1 else '' '' end  ||',
' 	 	case when V_LVL2 is not null then '' and gllv2 =''||V_LVL2 else '' '' end ||',
' 	 	CHR(10);',
'        V_SQL:=V_SQL||'' group by  gllv1,gllv2,glfy,glan8,TRIM(gllitm),TRIM(glmcu),TRIM(globj),TRIM(glsub),rtrim(TRIM(glmcu)||''''.''''||TRIM(globj)||''''.''''||TRIM(glsub),''''.'''')''||CHR(10);',
'        V_SQL:=V_SQL||'' having sum(glaa)!=0''||CHR(10);',
'        :P450_QRY:=V_SQL;',
'    END IF;',
'EXECUTE IMMEDIATE V_SQL;',
'    ',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>153935525837255130
,p_updated_on=>wwv_flow_imp.dz('20260219163214Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(168142110654781712)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'CONSULTA'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE ',
'    V_ANIO NUMBER:=:P450_ANIO;',
'    V_MES  NUMBER:=:P450_MES;',
'    V_LVL1 VARCHAR2(9):=:P450_LVL1;',
'    V_LVL2 VARCHAR2(9):=:P450_LVL2;',
'    V_OPCION VARCHAR2(39):=REPLACE(:P450_OPCION,'':'','','');',
'    V_PERIODO VARCHAR2(39):=TO_CHAR(to_date(V_ANIO||to_char(V_MES,''00''),''YYMM''),''Month-yyyy'');',
'',
'    V_SQL CLOB:='''';',
'    P_CAMPOS VARCHAR2(3999);',
'    P_GROUPBY  VARCHAR2(3999);',
'    P_INSERT  VARCHAR2(3999);',
'BEGIN',
'',
'    V_OPCION:=V_OPCION;',
'    DBMS_OUTPUT.PUT_LINE(''V_OPCION:''||V_OPCION);',
'    P_CAMPOS :=V_OPCION;',
'    P_GROUPBY  :=V_OPCION;',
'    P_INSERT  :=V_OPCION;',
'',
'    P_CAMPOS:=replace(P_CAMPOS,''C'',''glan8'');',
'    P_CAMPOS:=replace(P_CAMPOS,''P'',''trim(gllitm)gllitm'');',
'    P_CAMPOS:=replace(P_CAMPOS,''Q'',''trim(glmcu)glmcu,trim(globj)globj,trim(glsub)glsub,rtrim(TRIM(glmcu)||''''.''''||TRIM(globj)||''''.''''||TRIM(glsub),''''.'''')glcta'');',
'',
'    :P450_QRY:=P_CAMPOS;',
'',
'    P_GROUPBY:=replace(P_GROUPBY,''C'',''glan8'');',
'    P_GROUPBY:=replace(P_GROUPBY,''P'',''trim(gllitm)'');',
'    P_GROUPBY:=replace(P_GROUPBY,''Q'',''trim(glmcu),trim(globj),trim(glsub),rtrim(TRIM(glmcu)||''''.''''||TRIM(globj)||''''.''''||TRIM(glsub),''''.'''')'');',
'',
'    P_INSERT:=replace(P_INSERT,''C'',''num04'');',
'    P_INSERT:=replace(P_INSERT,''P'',''txt01'');',
'    P_INSERT:=replace(P_INSERT,''Q'',''txt02,txt03,txt04,txt05'');',
'    ',
'    P_INSERT:=''num01,num02,num03''||CASE WHEN P_INSERT IS NULL THEN '' '' ELSE '',''||P_INSERT END ||'',num05''; ',
'    V_SQL :=''insert into t_tmp_b (''||P_INSERT||'')''||CHR(10)||',
'    '' select gllv1,gllv2,glfy''||CASE WHEN P_CAMPOS IS NULL THEN '' '' ELSE '',''||P_CAMPOS END ||'',abs(sum(glaa)) glaa''||CHR(10)||',
'    '' from vt_finz_distribucion''||CHR(10)||',
'    '' where glfy =''||V_ANIO||'' AND glpn= ''||V_MES||',
' 	 	case when V_LVL1 is not null then '' and gllv1 =''||V_LVL1 else '' '' end  ||',
' 	 	case when V_LVL2 is not null then '' and gllv2 =''||V_LVL2 else '' '' end ||',
' 	 	CHR(10)||',
'    '' group by  gllv1,gllv2,glfy''||CASE WHEN P_GROUPBY IS NULL THEN '' '' ELSE '',''||P_GROUPBY END||CHR(10)||''having sum(glaa)!=0'';',
'    DBMS_OUTPUT.PUT_LINE(V_SQL);',
'    :P450_QRY:=V_SQL;',
'    :P450_ESCLIENTE:= CASE WHEN regexp_like (:P450_OPCION,''C'') THEN 1 else 0 END;',
'    :P450_ESPRODUCTO:= CASE WHEN regexp_like (:P450_OPCION,''P'') THEN 1 else 0 END;',
'    :P450_ESCUENTA:= CASE WHEN regexp_like (:P450_OPCION,''Q'') THEN 1 else 0 END;',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>'CAMBIO'
,p_process_when_type=>'REQUEST_EQUALS_CONDITION'
,p_internal_uid=>168142110654781712
,p_updated_on=>wwv_flow_imp.dz('20260219163149Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp.component_end;
end;
/
