prompt --application/pages/page_00406
begin
--   Manifest
--     PAGE: 00406
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>109
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_page.create_page(
 p_id=>406
,p_name=>'DOCUMENTOS ELECTRONICOS - DLG - VER ERROR DESCRIPCION'
,p_alias=>'DOCUMENTOS-ELECTRONICOS-DLG-VER-ERROR-DESCRIPCION'
,p_page_mode=>'MODAL'
,p_step_title=>'ERROR DESCRIPCION'
,p_autocomplete_on_off=>'OFF'
,p_javascript_code_onload=>'$(secItems).hide();'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.contenedor {border: 1px solid #b3b3b347;color:#615d75;border-radius: 8px;width: 100%;text-align: left;font-size: x-large; font-family: monospace;}',
'.titulo {font-size: 12px;color: rgb(164, 183, 229);margin-bottom: 0px;background-color: #b3b3b347;text-align: center;border: 1px solid #b3b3b347;border-top-right-radius:8px;border-top-left-radius: 8px; }',
''))
,p_step_template=>wwv_flow_imp.id(37774372912106498)
,p_page_template_options=>'#DEFAULT#:t-Dialog--noPadding'
,p_protection_level=>'C'
,p_page_component_map=>'10'
,p_last_updated_on=>wwv_flow_imp.dz('20260212173524Z')
,p_last_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(194809280200733926)
,p_plug_name=>'Items'
,p_region_name=>'secItems'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(38289867500120143)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(194810769982733941)
,p_plug_name=>'New'
,p_region_template_options=>'#DEFAULT#:t-Form--stretchInputs'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(38289497777120142)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(37761271469106475)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(37860983999106559)
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(313857307467180666)
,p_plug_name=>'Errores'
,p_region_template_options=>'#DEFAULT#:t-Form--slimPadding:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(38289867500120143)
,p_plug_display_sequence=>30
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'  -- Normaliza escapes y tabulaciones para que el JSON parsee bien en el cliente',
'  function norm(p_txt clob) return clob is',
'    v clob := p_txt;',
'  begin',
'    -- Maneja "\n" y "\\n" que vienen como texto',
'    v := replace(v, ''\n'', chr(10));',
'    v := replace(v, ''\\n'', chr(10));',
'    v := replace(v, ''\t'', ''  '');',
'    v := replace(v, ''\\t'', ''  '');',
'    return v;',
'  end;',
'begin',
'  htp.p(''<style>',
'    pre.json{white-space:pre-wrap;font:12px/1.45 ui-monospace,Consolas,monospace;',
'    padding:8px;border:1px solid #ccc;border-radius:6px;background:#f8f9fa;margin:8px 0}',
'    .contenedor{margin:10px 0}',
'    .titulo{font-weight:600;margin-bottom:4px}',
'  </style>'');',
'',
'  -- Divide :P406_ERRORES por "|" y pinta cada intento',
'  for r in (',
'    with parts as (',
'      select level idx,',
'             regexp_substr(:P406_ERRORES, ''[^''||''|''||'']+'', 1, level) item',
'        from dual',
'      connect by regexp_substr(:P406_ERRORES, ''[^''||''|''||'']+'', 1, level) is not null',
'    )',
'    select idx, item',
'      from parts',
'     where PK_FINZ_SRI_GESTION.f_trimetiqueta(item) is not null',
'     order by idx',
'  ) loop',
'    htp.p(''<div class="contenedor"><div class="titulo">Intento ''||r.idx||''</div>'');',
unistr('    -- Se env\00EDa crudo en data-raw; el JS har\00E1 pretty print como en versi\00F3n 1'),
'    htp.p(''<pre class="json" data-raw="''||',
'            apex_escape.html_attribute( norm(r.item) )||',
'          ''"></pre></div>'');',
'  end loop;',
'',
unistr('  -- Pretty print en cliente (JSON.stringify + indentaci\00F3n). Fallback a texto plano.'),
'  htp.p(''<script>',
'  (function(){',
'    document.querySelectorAll("pre.json").forEach(function(el){',
'      var raw = el.getAttribute("data-raw") || "";',
'      try {',
'        el.textContent = JSON.stringify(JSON.parse(raw), null, 2);',
'      } catch(e) {',
unistr('        // No es JSON v\00E1lido: mostrar legible sin romper'),
'        el.textContent = raw.replace(/[{},\[\]]/g, "").replace(/\r?\n/g, "\n");',
'      }',
'    });',
'  })();',
'  </script>'');',
'end;',
''))
,p_plug_source_type=>'NATIVE_PLSQL'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(194810829538733942)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(194810769982733941)
,p_button_name=>'New'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860056812106557)
,p_button_image_alt=>'New'
,p_button_alignment=>'RIGHT'
,p_icon_css_classes=>'fa-refresh'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(194808052906733914)
,p_name=>'P406_ID'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(194809280200733926)
,p_prompt=>'Id'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(194809319878733927)
,p_name=>'P406_ERRORES'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(194809280200733926)
,p_prompt=>'Errores'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(194809445038733928)
,p_process_sequence=>10
,p_process_point=>'AFTER_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'SetupPage'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'SELECT ERRORDESCRIPCION into :P406_ERRORES FROM T_FINZ_DOCUMENTO_ELECTRONICO WHERE ID = :P406_ID;',
':P406_ERRORES := replace(:P406_ERRORES,''--------------------------------------------'',''|'');',
'exception when others then',
'	:P406_ERRORES:=''ERROR en SQLERRM: ''||SQLERRM;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>194809445038733928
,p_updated_on=>wwv_flow_imp.dz('20260212173524Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp.component_end;
end;
/
