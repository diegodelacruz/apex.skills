prompt --application/pages/page_01109
begin
--   Manifest
--     PAGE: 01109
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>109
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_page.create_page(
 p_id=>1109
,p_name=>unistr('Reporte Hist\00F3rico de Variaciones')
,p_step_title=>unistr('Reporte Hist\00F3rico de Variaciones')
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_page_component_map=>'18'
,p_created_on=>wwv_flow_imp.dz('20230705164635Z')
,p_last_updated_on=>wwv_flow_imp.dz('20241231163952Z')
,p_last_updated_by=>'CVACA'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(480773420544542810)
,p_plug_name=>'Reporte'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(37806762584106520)
,p_plug_display_sequence=>30
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_new_grid_row=>false
,p_plug_new_grid_column=>false
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'with',
'w_periodo as (',
'	select :p1109_anno anno, :p1109_mes mes',
'		, pk_commons.f_g2jde(to_date(:p1109_anno||:p1109_mes,''yyyymm'')) fjde',
'		, to_char(add_months(to_date(:p1109_anno||:p1109_mes,''yyyymm''),-1),''yyyy'') annoa',
'		, to_number(to_char(add_months(to_date(:p1109_anno||:p1109_mes,''yyyymm''),-1),''mm'')) mesa',
'		, pk_commons.f_g2jde(add_months(to_date(:p1109_anno||:p1109_mes,''yyyymm''),-1)) fjdea',
'		from dual),',
'w_f4101 as (',
'	select * from w_periodo,f4101@jdedtadl where trim(imsrtx) in (''SEMIELABORADO'',''TERMINADO'')',
unistr(') select distinct imitm,''\00AC''||trim(imlitm) imlitm, trim(imdsc1) imdsc1'),
', case when :p1109_planta = ''17005'' then a.ixitm else imitm end ixitm',
', case when :p1109_planta = ''17005'' then trim(a.ixlitm) else trim(imlitm) end ixlitm',
', a.ixcmcu',
', a.ixopsq',
', a1.iexscr costomp',
', b1.iexscr costomo',
', b3.iexscr costocf',
', a1a.iexscr costompa',
', b1a.iexscr costomoa',
', b3a.iexscr costocfa',
', a1.iexscr - a1a.iexscr varmp',
', b1.iexscr - b1a.iexscr varmo',
', b3.iexscr - b3a.iexscr varcf',
', decode(nvl(a1a.iexscr,0),0,0,((a1.iexscr/a1a.iexscr) - 1)*100) pvarmp',
', decode(nvl(b1a.iexscr,0),0,0,((b1.iexscr/b1a.iexscr) - 1)*100) pvarmo',
', decode(nvl(b3a.iexscr,0),0,0,((b3.iexscr/b3a.iexscr) - 1)*100) pvarcf',
'from w_f4101 z',
'--Mes Actual',
'inner join f3002@jdedtadl a on z.imitm = a.ixkit and a.ixtbm = ''M  ''',
'left join dp.t_hist_f30026 a1 on z.anno = (a1.iefy + 2000) and z.mes = a1.iepn and a.ixkit = a1.ieitm and a.ixmmcu = a1.iemmcu and a1.iecost = ''A1''',
'left join dp.t_hist_f30026 b1 on z.anno = (b1.iefy + 2000) and z.mes = b1.iepn and a.ixkit = b1.ieitm and a.ixmmcu = b1.iemmcu and b1.iecost = ''B1''',
'left join dp.t_hist_f30026 b3 on z.anno = (b3.iefy + 2000) and z.mes = b3.iepn and a.ixkit = b3.ieitm and a.ixmmcu = b3.iemmcu and b3.iecost = ''B3''',
'--Mes Anterior',
'left join f3002@jdedtadl b on z.imitm = b.ixkit and b.ixtbm = ''M  '' and a.ixopsq = b.ixopsq',
'left join dp.t_hist_f30026 a1a on z.annoa = (a1a.iefy + 2000) and z.mesa = a1a.iepn and b.ixkit = a1a.ieitm and b.ixmmcu = a1a.iemmcu and a1a.iecost = ''A1''',
'left join dp.t_hist_f30026 b1a on z.annoa = (b1a.iefy + 2000) and z.mesa = b1a.iepn and b.ixkit = b1a.ieitm and b.ixmmcu = b1a.iemmcu and b1a.iecost = ''B1''',
'left join dp.t_hist_f30026 b3a on z.annoa = (b3a.iefy + 2000) and z.mesa = b3a.iepn and b.ixkit = b3a.ieitm and b.ixmmcu = b3a.iemmcu and b3a.iecost = ''B3''',
'where fjde between a.ixefff and decode(nvl(a.ixefft,0),0,140366,a.ixefft) and a.ixmmcu = lpad(:p1109_planta,12,'' '')',
'and fjdea between b.ixefff and decode(nvl(b.ixefft,0),0,140366,b.ixefft) and b.ixmmcu = lpad(:p1109_planta,12,'' '');'))
,p_plug_source_type=>'NATIVE_IR'
,p_ajax_items_to_submit=>'P1109_ANNO,P1109_MES,P1109_PLANTA'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>210
,p_prn_height=>297
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(480774596533542821)
,p_max_row_count=>'1000000'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'DDELACRUZ'
,p_internal_uid=>480774596533542821
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(493784314878765049)
,p_db_column_name=>'IMITM'
,p_display_order=>150
,p_column_identifier=>'AK'
,p_column_label=>unistr('C\00F3d. Corto')
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(493784472846765050)
,p_db_column_name=>'IMLITM'
,p_display_order=>160
,p_column_identifier=>'AL'
,p_column_label=>unistr('C\00F3d. Producto')
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(494055924565929901)
,p_db_column_name=>'IMDSC1'
,p_display_order=>170
,p_column_identifier=>'AM'
,p_column_label=>'Producto'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(494057656221929918)
,p_db_column_name=>'IXITM'
,p_display_order=>180
,p_column_identifier=>'AO'
,p_column_label=>unistr('C\00F3d. Corto Proceso')
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(494056032936929902)
,p_db_column_name=>'IXLITM'
,p_display_order=>190
,p_column_identifier=>'AN'
,p_column_label=>unistr('C\00F3d. Proceso')
,p_column_link=>'f?p=&APP_ID.:1110:&SESSION.::&DEBUG.:RP:P1110_ANNO,P1110_MES,P1110_CODCORTOPROCESO,P1110_PLANTA,P1110_OPERACION:&P1109_ANNO.,&P1109_MES.,#IXITM#,#IXCMCU#,#IXOPSQ#'
,p_column_linktext=>'#IXLITM#'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(494058658545929928)
,p_db_column_name=>'IXCMCU'
,p_display_order=>200
,p_column_identifier=>'AP'
,p_column_label=>'Ixcmcu'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(494059958133929941)
,p_db_column_name=>'IXOPSQ'
,p_display_order=>210
,p_column_identifier=>'AQ'
,p_column_label=>'Ixopsq'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(493612003065562712)
,p_db_column_name=>'COSTOMP'
,p_display_order=>220
,p_column_identifier=>'V'
,p_column_label=>'Costo MP'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D0000'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(493612198319562713)
,p_db_column_name=>'COSTOMO'
,p_display_order=>230
,p_column_identifier=>'W'
,p_column_label=>'Costo MO'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D0000'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(493612228301562714)
,p_db_column_name=>'COSTOCF'
,p_display_order=>240
,p_column_identifier=>'X'
,p_column_label=>'Costo CF'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D0000'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(494060403097929946)
,p_db_column_name=>'COSTOMPA'
,p_display_order=>250
,p_column_identifier=>'AR'
,p_column_label=>'Costo MP (ant)'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D0000'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(494060523634929947)
,p_db_column_name=>'COSTOMOA'
,p_display_order=>260
,p_column_identifier=>'AS'
,p_column_label=>'Costo MO (ant)'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D0000'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(494060630265929948)
,p_db_column_name=>'COSTOCFA'
,p_display_order=>270
,p_column_identifier=>'AT'
,p_column_label=>'Costo CF (ant)'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D0000'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(495169718258187202)
,p_db_column_name=>'VARMP'
,p_display_order=>280
,p_column_identifier=>'AU'
,p_column_label=>'Var. MP'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D0000'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(495169801821187203)
,p_db_column_name=>'VARMO'
,p_display_order=>290
,p_column_identifier=>'AV'
,p_column_label=>'Var. MO'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D0000'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(495169913665187204)
,p_db_column_name=>'VARCF'
,p_display_order=>300
,p_column_identifier=>'AW'
,p_column_label=>'Var. CF'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D0000'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(495871854667498228)
,p_db_column_name=>'PVARMP'
,p_display_order=>310
,p_column_identifier=>'AX'
,p_column_label=>'% Var. MP'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(495871930845498229)
,p_db_column_name=>'PVARMO'
,p_display_order=>320
,p_column_identifier=>'AY'
,p_column_label=>'% Var. MO'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(495872099050498230)
,p_db_column_name=>'PVARCF'
,p_display_order=>330
,p_column_identifier=>'AZ'
,p_column_label=>'% Var. CF'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(480826213057264353)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_type=>'REPORT'
,p_report_alias=>'4808263'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_view_mode=>'REPORT'
,p_report_columns=>'IMITM:IMLITM:IMDSC1:IXLITM:COSTOMP:COSTOMO:COSTOCF::IXITM:IXCMCU:IXOPSQ:COSTOMPA:COSTOMOA:COSTOCFA:VARMP:VARMO:VARCF:PVARMP:PVARMO:PVARCF'
,p_sort_column_1=>'IMLITM'
,p_sort_direction_1=>'ASC'
,p_sort_column_2=>'IXLITM'
,p_sort_direction_2=>'ASC'
,p_sort_column_3=>'0'
,p_sort_direction_3=>'ASC'
,p_sort_column_4=>'0'
,p_sort_direction_4=>'ASC'
,p_sort_column_5=>'0'
,p_sort_direction_5=>'ASC'
,p_sort_column_6=>'0'
,p_sort_direction_6=>'ASC'
,p_created_on=>wwv_flow_imp.dz('20230705164635Z')
,p_updated_on=>wwv_flow_imp.dz('20230705164635Z')
,p_created_by=>'CVACA'
,p_updated_by=>'CVACA'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(831011907149607365)
,p_plug_name=>unistr('Reporte Hist\00F3rico de Variaciones')
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(38290610465120145)
,p_plug_display_sequence=>5
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(37761271469106475)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(37860983999106559)
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(831019850582644099)
,p_plug_name=>'Barra de Acciones'
,p_region_template_options=>'#DEFAULT#:t-Form--stretchInputs'
,p_plug_template=>wwv_flow_imp.id(38289497777120142)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'REGION_POSITION_01'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(845283483429670945)
,p_plug_name=>'Filtros'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(38289867500120143)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(480714437651071698)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(831019850582644099)
,p_button_name=>'BUSCAR'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860056812106557)
,p_button_image_alt=>'Buscar'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_icon_css_classes=>'fa-search'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(480718590281090806)
,p_name=>'P1109_ANNO'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(845283483429670945)
,p_prompt=>unistr('A\00F1o')
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'LOV_ANNOS'
,p_lov=>'select to_char(sysdate,''yyyy'') + (level-3) d,to_char(sysdate,''yyyy'') + (level-3) r from dual connect by level <= 4'
,p_lov_display_null=>'YES'
,p_lov_null_text=>'Seleccione'
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'NONE'
,p_updated_on=>wwv_flow_imp.dz('20241231163952Z')
,p_updated_by=>'CVACA'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(480718969580090807)
,p_name=>'P1109_MES'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(845283483429670945)
,p_prompt=>'Mes'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'LOV_MESES'
,p_lov=>'select to_char(to_date(level,''MM''),''Month'') d, level r from dual connect by level <= 12'
,p_lov_display_null=>'YES'
,p_lov_null_text=>'Seleccione'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(480800461542045623)
,p_name=>'P1109_PLANTA'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(845283483429670945)
,p_prompt=>'Planta'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'LOV_RELCENTROCOSTROS_UN'
,p_lov=>'select descripcion d,valor2 r from t_corp_udc where codigocompania = :g_compania and id_cabecera = ''701'' and activo = 1;'
,p_lov_display_null=>'YES'
,p_lov_null_text=>'Seleccione'
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'NONE'
);
wwv_flow_imp.component_end;
end;
/
