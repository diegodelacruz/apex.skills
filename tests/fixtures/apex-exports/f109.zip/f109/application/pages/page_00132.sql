prompt --application/pages/page_00132
begin
--   Manifest
--     PAGE: 00132
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>109
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_page.create_page(
 p_id=>132
,p_name=>'ISD/FH - Nuevo Registro'
,p_page_mode=>'MODAL'
,p_step_title=>'Nuevo Registro'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_page_component_map=>'02'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(101743633330167252)
,p_plug_name=>'Nuevo Registro'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(37786313898106507)
,p_plug_display_sequence=>10
,p_query_type=>'TABLE'
,p_query_table=>'T_FINZ_CALCULOISD'
,p_include_rowid_column=>false
,p_is_editable=>true
,p_edit_operations=>'i:u:d'
,p_lost_update_check_type=>'VALUES'
,p_plug_source_type=>'NATIVE_FORM'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(101751894945167268)
,p_plug_name=>'Buttons'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(37787379178106507)
,p_plug_display_sequence=>20
,p_plug_display_point=>'REGION_POSITION_03'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'TEXT',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(101752237396167268)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(101751894945167268)
,p_button_name=>'CANCEL'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860181880106559)
,p_button_image_alt=>'Cancelar'
,p_button_position=>'CLOSE'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(101754402527167272)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(101751894945167268)
,p_button_name=>'CREATE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860181880106559)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Crear'
,p_button_position=>'NEXT'
,p_button_execute_validations=>'N'
,p_button_condition=>'P132_ID'
,p_button_condition_type=>'ITEM_IS_NULL'
,p_database_action=>'INSERT'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(85321676995939442)
,p_name=>'P132_FECHALIQ'
,p_item_sequence=>120
,p_item_plug_id=>wwv_flow_imp.id(101743633330167252)
,p_prompt=>'Fecha Liq.'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(101640334306829813)
,p_name=>'P132_COD_PROVEEDOR'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(101743633330167252)
,p_item_source_plug_id=>wwv_flow_imp.id(101743633330167252)
,p_source=>'CODPROVEEDOR'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(101640465025829814)
,p_name=>'P132_MONTOOC'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(101743633330167252)
,p_item_source_plug_id=>wwv_flow_imp.id(101743633330167252)
,p_source=>'MONTOOC'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(101744059361167254)
,p_name=>'P132_ID'
,p_source_data_type=>'NUMBER'
,p_is_primary_key=>true
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(101743633330167252)
,p_item_source_plug_id=>wwv_flow_imp.id(101743633330167252)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Id'
,p_source=>'ID'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_label_alignment=>'RIGHT'
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_protection_level=>'S'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(101744404157167259)
,p_name=>'P132_ORDENCOMPRA'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(101743633330167252)
,p_item_source_plug_id=>wwv_flow_imp.id(101743633330167252)
,p_prompt=>unistr('N\00FAmero de Orden')
,p_source=>'ORDENCOMPRA'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select phdoco d, phdoco r',
'from f4301@jdedtadl',
'where phan8 = phan8 ',
'and (phdoco,phdcto) not in (select distinct a.ordencompra,''OI'' from t_finz_calculoisdfac a inner join t_finz_calculoisd b on a.idcab = b.id)',
'and phdcto = ''OI''',
'and phtrdj >= pk_commons.f_g2jde(trunc(add_months(sysdate,-6),''month''))',
'order by 1 desc'))
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'POPUP'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_04=>'N'
,p_attribute_05=>'Y'
,p_attribute_06=>'0'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(101744873740167262)
,p_name=>'P132_TIPO_ORDEN'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(101743633330167252)
,p_item_source_plug_id=>wwv_flow_imp.id(101743633330167252)
,p_prompt=>'Tipo de Orden'
,p_source=>'TIPOOC'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>32
,p_cMaxlength=>10
,p_begin_on_new_line=>'N'
,p_read_only_when_type=>'ALWAYS'
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(101745272405167262)
,p_name=>'P132_INCOTERM'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(101743633330167252)
,p_item_source_plug_id=>wwv_flow_imp.id(101743633330167252)
,p_source=>'INCOTERM'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(101745688016167262)
,p_name=>'P132_PAISORIGEN'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_imp.id(101743633330167252)
,p_item_source_plug_id=>wwv_flow_imp.id(101743633330167252)
,p_source=>'PAISORIGEN'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(102663813119249105)
,p_name=>'P132_MONTOOC_D'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(101743633330167252)
,p_prompt=>'Monto OC'
,p_format_mask=>'FML999G999G999G999G990D00'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(102664129757249108)
,p_name=>'P132_INCOTERM_D'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(101743633330167252)
,p_prompt=>'Incoterm'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(102664421680249111)
,p_name=>'P132_COD_PROVEEDOR_D'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(101743633330167252)
,p_prompt=>'Proveedor'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(117299670639208302)
,p_name=>'P132_PAISORIGEN_D'
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_imp.id(101743633330167252)
,p_prompt=>unistr('Pa\00EDs Origen')
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_lov=>'select drdl01,drky from f0116@jdedtadl inner join vt_jde_udcjde on drsy = ''00'' and drrt = ''CN'' and trim(alctr) = drky'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'N'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(125700192322728808)
,p_name=>'P132_NUMLIQUIDACION'
,p_item_sequence=>130
,p_item_plug_id=>wwv_flow_imp.id(101743633330167252)
,p_prompt=>unistr('N\00FAm. Liquidaci\00F3n')
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_warn_on_unsaved_changes=>'I'
,p_is_persistent=>'N'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(125700291723728809)
,p_name=>'P132_REFRENDO'
,p_item_sequence=>140
,p_item_plug_id=>wwv_flow_imp.id(101743633330167252)
,p_prompt=>'Refrendo'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_warn_on_unsaved_changes=>'I'
,p_is_persistent=>'N'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(101640013733829810)
,p_validation_name=>'VAL_NOT_REPAT'
,p_validation_sequence=>90
,p_validation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'V_EXIST NUMBER;',
'BEGIN',
'',
'BEGIN',
'    SELECT 1 INTO V_EXIST',
'    FROM t_finz_calculoisd where ordencompra = :p132_ordencompra;',
'EXCEPTION WHEN NO_DATA_FOUND THEN',
'    V_EXIST := 0;',
'END;',
'',
'IF V_EXIST = 1 THEN',
'    RETURN FALSE;',
'ELSE',
'    RETURN TRUE;',
'END IF;',
'',
'END;'))
,p_validation2=>'PLSQL'
,p_validation_type=>'FUNC_BODY_RETURNING_BOOLEAN'
,p_error_message=>unistr('Este n\00FAmero de orden ya fu\00E9 ingresado')
,p_associated_item=>wwv_flow_imp.id(101744404157167259)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(102664892549249115)
,p_validation_name=>'VAL_COD_ORDEN'
,p_validation_sequence=>110
,p_validation=>'P132_ORDENCOMPRA'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>unistr('Debe seleccionar un n\00FAmero de orden')
,p_always_execute=>'Y'
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(101752344900167268)
,p_name=>'Cancel Dialog'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(101752237396167268)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(101753114150167270)
,p_event_id=>wwv_flow_imp.id(101752344900167268)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CANCEL'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(101640131985829811)
,p_name=>'Setear Valores'
,p_event_sequence=>20
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P132_ORDENCOMPRA'
,p_condition_element=>'P132_ORDENCOMPRA'
,p_triggering_condition_type=>'NOT_NULL'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(101640212392829812)
,p_event_id=>wwv_flow_imp.id(101640131985829811)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'v_tipo	varchar2(2);',
'v_orden	number;',
'v_oc	varchar2(25);',
'begin',
'	v_tipo	:= :p132_tipo_orden;',
'	v_orden := :p132_ordencompra;',
'	v_oc 	:= v_tipo||''-''||v_orden;',
'',
'	begin',
'		select phan8, trim(phfrth) phfrth, photot/100 photot',
'		into :p132_cod_proveedor,:p132_incoterm,:p132_montooc',
'		from f4301@jdedtadl',
'		where phan8 = phan8 and phdcto = v_tipo and phdoco = v_orden;',
'	end;',
'',
'	begin',
'		select drky into :p132_paisorigen',
'		from f0116@jdedtadl inner join vt_jde_udcjde on drsy = ''00'' and drrt = ''CN'' and trim(alctr) = drky',
'		where alan8 = :p132_cod_proveedor and rownum = 1;',
'	end;',
'',
'	begin',
'		select nvl(to_char(fechaliq,''dd/mm/yyyy''),''NA''),nvl(numeroliquidacion,''NA''),nvl(refrendo,''NA'')',
'        into :p132_fechaliq,:p132_numliquidacion,:p132_refrendo',
'        from data.vt_cmex_mesaimpexp where orden = v_oc and rownum = 1;',
'',
'		exception when others then :p132_fechaliq := ''NA''; :p132_numliquidacion := ''NA''; :p132_refrendo := ''NA'';',
'	end;',
'end;'))
,p_attribute_02=>'P132_TIPO_ORDEN,P132_ORDENCOMPRA'
,p_attribute_03=>'P132_COD_PROVEEDOR,P132_INCOTERM,P132_MONTOOC,P132_PAISORIGEN,P132_NUMLIQUIDACION,P132_REFRENDO,P132_FECHALIQ'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(102664917842249116)
,p_event_id=>wwv_flow_imp.id(101640131985829811)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_name=>'Limpiar Datos'
,p_action=>'NATIVE_CLEAR'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P132_COD_PROVEEDOR,P132_INCOTERM,P132_MONTOOC,P132_PAISORIGEN'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(102663919857249106)
,p_name=>'CAMBIO_MONTOOC'
,p_event_sequence=>30
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P132_MONTOOC'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(102664041181249107)
,p_event_id=>wwv_flow_imp.id(102663919857249106)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P132_MONTOOC_D'
,p_attribute_01=>'PLSQL_EXPRESSION'
,p_attribute_04=>':P132_MONTOOC'
,p_attribute_07=>'P132_MONTOOC'
,p_attribute_08=>'Y'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(102664211489249109)
,p_name=>'Cambio Incoterm'
,p_event_sequence=>40
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P132_INCOTERM'
,p_condition_element=>'P132_INCOTERM'
,p_triggering_condition_type=>'NOT_NULL'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(102664341644249110)
,p_event_id=>wwv_flow_imp.id(102664211489249109)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P132_INCOTERM_D'
,p_attribute_01=>'SQL_STATEMENT'
,p_attribute_03=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select DRKY ||'' - ''||upper(DRDL01)',
'from vt_jde_udcjde ',
'where drsy=''42'' and drrt=''FR'' and drky is not null and DRKY = :P132_INCOTERM;'))
,p_attribute_07=>'P132_INCOTERM'
,p_attribute_08=>'Y'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(102665023512249117)
,p_event_id=>wwv_flow_imp.id(102664211489249109)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_CLEAR'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P132_INCOTERM_D'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(102664581059249112)
,p_name=>'Proveedor'
,p_event_sequence=>50
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P132_COD_PROVEEDOR'
,p_condition_element=>'P132_COD_PROVEEDOR'
,p_triggering_condition_type=>'NOT_NULL'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(102664610459249113)
,p_event_id=>wwv_flow_imp.id(102664581059249112)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P132_COD_PROVEEDOR_D'
,p_attribute_01=>'SQL_STATEMENT'
,p_attribute_03=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select codigo || '' - '' || nombres',
'FROM',
'    (',
'        SELECT',
'            codigo,',
'            nombres',
'        FROM',
'            vt_jde_librodirecciones',
'        GROUP BY',
'            codigo,',
'            nombres',
'    ) a where a.codigo = :P132_COD_PROVEEDOR'))
,p_attribute_07=>'P132_COD_PROVEEDOR'
,p_attribute_08=>'N'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(102665198335249118)
,p_event_id=>wwv_flow_imp.id(102664581059249112)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_CLEAR'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P132_COD_PROVEEDOR_D'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(117299778886208303)
,p_name=>unistr('Pa\00EDs')
,p_event_sequence=>60
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P132_PAISORIGEN'
,p_condition_element=>'P132_PAISORIGEN'
,p_triggering_condition_type=>'NOT_NULL'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(117299810566208304)
,p_event_id=>wwv_flow_imp.id(117299778886208303)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P132_PAISORIGEN_D'
,p_attribute_01=>'SQL_STATEMENT'
,p_attribute_03=>'select drdl01 from vt_jde_udcjde where drsy = ''00'' and drrt = ''CN'' and drky = :p132_paisorigen'
,p_attribute_07=>'P132_PAISORIGEN'
,p_attribute_08=>'N'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(117299929911208305)
,p_event_id=>wwv_flow_imp.id(117299778886208303)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_CLEAR'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P132_PAISORIGEN_D'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(101755216622167273)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_region_id=>wwv_flow_imp.id(101743633330167252)
,p_process_type=>'NATIVE_FORM_DML'
,p_process_name=>unistr('Process form Formulario C\00E1lculo ISD cabecera')
,p_attribute_01=>'REGION_SOURCE'
,p_attribute_05=>'Y'
,p_attribute_06=>'Y'
,p_attribute_08=>'N'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>101755216622167273
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(101755620609167273)
,p_process_sequence=>50
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_CLOSE_WINDOW'
,p_process_name=>'Close Dialog'
,p_attribute_02=>'N'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>'CREATE,SAVE,DELETE'
,p_process_when_type=>'REQUEST_IN_CONDITION'
,p_internal_uid=>101755620609167273
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(101754838854167273)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_region_id=>wwv_flow_imp.id(101743633330167252)
,p_process_type=>'NATIVE_FORM_INIT'
,p_process_name=>unistr('Initialize form Formulario C\00E1lculo ISD cabecera')
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>101754838854167273
);
wwv_flow_imp.component_end;
end;
/
