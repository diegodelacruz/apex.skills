prompt --application/pages/page_00181
begin
--   Manifest
--     PAGE: 00181
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>109
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_page.create_page(
 p_id=>181
,p_name=>unistr('GESTION TRIBUTARIA - A\00D1ADIR/ EDITAR PERIODO')
,p_alias=>unistr('GESTION-TRIBUTARIA-A\00D1ADIR-EDITAR-PERIODO')
,p_page_mode=>'MODAL'
,p_step_title=>unistr('A\00F1adir/Editar Periodo')
,p_autocomplete_on_off=>'OFF'
,p_javascript_code_onload=>'$(secItems).hide();'
,p_step_template=>wwv_flow_imp.id(37774372912106498)
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'02'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(540051484187066005)
,p_plug_name=>'Botones'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(38290276266120143)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(540052902156066020)
,p_plug_name=>'Items'
,p_region_name=>'secItems'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(38289867500120143)
,p_plug_display_sequence=>30
,p_include_in_reg_disp_sel_yn=>'Y'
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(540060364925144533)
,p_plug_name=>'GESTION TRIBUTARIA - FORMULARIO PERIODO'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(38289867500120143)
,p_plug_display_sequence=>10
,p_query_type=>'TABLE'
,p_query_table=>'T_FINZ_GESTIONTRIBUTARIA'
,p_include_rowid_column=>false
,p_is_editable=>true
,p_edit_operations=>'i:u:d'
,p_lost_update_check_type=>'VALUES'
,p_plug_source_type=>'NATIVE_FORM'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(540069516558144549)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(540051484187066005)
,p_button_name=>'CERRAR'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860181880106559)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Cerrar'
,p_button_position=>'NEXT'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(540070589311144550)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(540051484187066005)
,p_button_name=>'GUARDAR'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860181880106559)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Guardar'
,p_button_position=>'NEXT'
,p_button_condition=>':P181_ID is not null'
,p_button_condition2=>'PLSQL'
,p_button_condition_type=>'EXPRESSION'
,p_database_action=>'UPDATE'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(540070148995144549)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(540051484187066005)
,p_button_name=>'BORRAR'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860181880106559)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Borrar'
,p_button_position=>'NEXT'
,p_button_execute_validations=>'N'
,p_show_processing=>'Y'
,p_confirm_message=>'&APP_TEXT$DELETE_MSG!RAW.'
,p_confirm_style=>'danger'
,p_button_condition=>':P181_ID is not null and ( :P181_ESTADO in (0,1))'
,p_button_condition2=>'PLSQL'
,p_button_condition_type=>'EXPRESSION'
,p_database_action=>'DELETE'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(540070948964144550)
,p_button_sequence=>50
,p_button_plug_id=>wwv_flow_imp.id(540051484187066005)
,p_button_name=>'CREAR'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860181880106559)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Guardar'
,p_button_position=>'NEXT'
,p_button_condition=>'P181_ID'
,p_button_condition_type=>'ITEM_IS_NULL'
,p_database_action=>'INSERT'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(34445573587782338)
,p_name=>'P181_EDITAR'
,p_item_sequence=>170
,p_item_plug_id=>wwv_flow_imp.id(540052902156066020)
,p_prompt=>'Editar'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(540052177211066012)
,p_name=>'P181_USERCREA'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_imp.id(540052902156066020)
,p_item_source_plug_id=>wwv_flow_imp.id(540060364925144533)
,p_prompt=>'Usercrea'
,p_source=>'USERCREA'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_cMaxlength=>25
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(540052201337066013)
,p_name=>'P181_FECHCREA'
,p_source_data_type=>'TIMESTAMP'
,p_item_sequence=>120
,p_item_plug_id=>wwv_flow_imp.id(540052902156066020)
,p_item_source_plug_id=>wwv_flow_imp.id(540060364925144533)
,p_prompt=>'Fechcrea'
,p_source=>'FECHCREA'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DATE_PICKER_APEX'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'POPUP'
,p_attribute_03=>'NONE'
,p_attribute_06=>'NONE'
,p_attribute_09=>'N'
,p_attribute_11=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(540052371719066014)
,p_name=>'P181_USERMODI'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>130
,p_item_plug_id=>wwv_flow_imp.id(540052902156066020)
,p_item_source_plug_id=>wwv_flow_imp.id(540060364925144533)
,p_prompt=>'Usermodi'
,p_source=>'USERMODI'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_cMaxlength=>25
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(540052404023066015)
,p_name=>'P181_FECHMODI'
,p_source_data_type=>'TIMESTAMP'
,p_item_sequence=>140
,p_item_plug_id=>wwv_flow_imp.id(540052902156066020)
,p_item_source_plug_id=>wwv_flow_imp.id(540060364925144533)
,p_prompt=>'Fechmodi'
,p_source=>'FECHMODI'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DATE_PICKER_APEX'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'POPUP'
,p_attribute_03=>'NONE'
,p_attribute_06=>'NONE'
,p_attribute_09=>'N'
,p_attribute_11=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(540052552185066016)
,p_name=>'P181_FECHACIERRE'
,p_source_data_type=>'TIMESTAMP'
,p_item_sequence=>150
,p_item_plug_id=>wwv_flow_imp.id(540052902156066020)
,p_item_source_plug_id=>wwv_flow_imp.id(540060364925144533)
,p_prompt=>'Fechacierre'
,p_source=>'FECHACIERRE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DATE_PICKER_APEX'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'POPUP'
,p_attribute_03=>'NONE'
,p_attribute_06=>'NONE'
,p_attribute_09=>'N'
,p_attribute_11=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(540052612312066017)
,p_name=>'P181_IDRUTA'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>160
,p_item_plug_id=>wwv_flow_imp.id(540052902156066020)
,p_item_source_plug_id=>wwv_flow_imp.id(540060364925144533)
,p_prompt=>'Idruta'
,p_source=>'IDRUTA'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'left'
,p_attribute_04=>'decimal'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(540060651104144536)
,p_name=>'P181_ID'
,p_source_data_type=>'NUMBER'
,p_is_primary_key=>true
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(540052902156066020)
,p_item_source_plug_id=>wwv_flow_imp.id(540060364925144533)
,p_prompt=>'Id'
,p_source=>'ID'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_protection_level=>'S'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(540063481007144545)
,p_name=>'P181_COMPANIA'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(540060364925144533)
,p_item_source_plug_id=>wwv_flow_imp.id(540060364925144533)
,p_prompt=>unistr('Compa\00F1ia')
,p_source=>'COMPANIA'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_lov=>'SELECT DESCRIPCION,CODIGO FROM DATA.t_admi_compania where estado=''1'''
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'Y'
,p_attribute_02=>'LOV'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(540063863262144545)
,p_name=>'P181_PERIODO'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(540060364925144533)
,p_item_source_plug_id=>wwv_flow_imp.id(540060364925144533)
,p_prompt=>'Periodo'
,p_source=>'PERIODO'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'LOV_FINZ_GTPERIODOS'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT  ',
'    TO_CHAR(ADD_MONTHS(TRUNC(ADD_MONTHS(SYSDATE,NVL(:G_GT_MESESADELANTE,1)), ''MM''), -LEVEL + 1), ''Month YYYY'', ''NLS_DATE_LANGUAGE=SPANISH'') AS mes_nombre,',
'    TO_CHAR(ADD_MONTHS(TRUNC(ADD_MONTHS(SYSDATE,NVL(:G_GT_MESESADELANTE,1)), ''MM''), -LEVEL + 1), ''YYYYMM'') AS mes_valor',
'FROM DUAL',
'CONNECT BY LEVEL <= NVL(:G_GT_MESESTRAS+:G_GT_MESESADELANTE,1);'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'Seleccione'
,p_cHeight=>1
,p_read_only_when=>'P181_ID'
,p_read_only_when_type=>'ITEM_IS_NOT_NULL'
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(540064257404144545)
,p_name=>'P181_ESTADO'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(540060364925144533)
,p_item_source_plug_id=>wwv_flow_imp.id(540060364925144533)
,p_prompt=>'Estado'
,p_source=>'ESTADO'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_named_lov=>'LOV_FINZ_GTESTADOS'
,p_lov=>'SELECT DESCRIPCION D, VALOR R FROM T_CORP_UDC WHERE ID_CABECERA=''FINZ_GT05'' AND DESCRIPCION2=''ESTADOS DE PERIODOS''  AND ACTIVO=''1'' ;'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'Y'
,p_attribute_02=>'LOV'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(540065889912144546)
,p_name=>'P181_OBSERVACION'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(540060364925144533)
,p_item_source_plug_id=>wwv_flow_imp.id(540060364925144533)
,p_prompt=>'Observacion'
,p_source=>'OBSERVACION'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>60
,p_cMaxlength=>2500
,p_cHeight=>4
,p_tag_attributes=>'style="resize: none;text-transform: uppercase;"'
,p_read_only_when=>'P181_ESTADO'
,p_read_only_when2=>'3'
,p_read_only_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_field_template=>wwv_flow_imp.id(37859556976106557)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(540149181303116708)
,p_name=>'P181_ACTIVIDADES'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(540060364925144533)
,p_item_source_plug_id=>wwv_flow_imp.id(540060364925144533)
,p_prompt=>'Procesos'
,p_source=>'ACTIVIDADES'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_CHECKBOX'
,p_named_lov=>'LOV_FINZ_GTACTIVIDADES'
,p_lov=>'SELECT ID_TABLA||'' - ''||DESCRIPCION DESCRIPCION,ID_TABLA FROM "DATA"."T_CORP_UDC" WHERE ID_CABECERA=''FINZ_GT01'' AND ID_TABLA!=''000''  AND ACTIVO=''1'' ORDER BY TO_NUMBER(VALOR3);'
,p_tag_attributes2=>'style="color:red;"'
,p_grid_label_column_span=>0
,p_read_only_when=>'P181_ESTADO'
,p_read_only_when2=>'3'
,p_read_only_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'2'
,p_multi_value_type=>'SEPARATED'
,p_multi_value_separator=>':'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(540150100224116718)
,p_name=>'P181_TODO_ACTIVIDAD'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(540060364925144533)
,p_prompt=>'Todo Procesos'
,p_display_as=>'NATIVE_SINGLE_CHECKBOX'
,p_grid_label_column_span=>0
,p_read_only_when=>'P181_ESTADO'
,p_read_only_when2=>'3'
,p_read_only_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--radioButtonGroup'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(540053317395066024)
,p_validation_name=>'Periodo no se repite'
,p_validation_sequence=>10
,p_validation=>'SELECT * FROM T_FINZ_GESTIONTRIBUTARIA where periodo = :P181_PERIODO and compania=:G_COMPANIA;'
,p_validation_type=>'NOT_EXISTS'
,p_error_message=>'#LABEL# seleccionado ya se encuentra registrado'
,p_always_execute=>'Y'
,p_when_button_pressed=>wwv_flow_imp.id(540070948964144550)
,p_associated_item=>wwv_flow_imp.id(540063863262144545)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(540149271459116709)
,p_validation_name=>'Actividades No vacio'
,p_validation_sequence=>20
,p_validation=>'P181_ACTIVIDADES'
,p_validation_type=>'ITEM_NOT_NULL_OR_ZERO'
,p_error_message=>unistr('#LABEL# debe tener alg\00FAn valor')
,p_always_execute=>'Y'
,p_when_button_pressed=>wwv_flow_imp.id(540070948964144550)
,p_associated_item=>wwv_flow_imp.id(540149181303116708)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(540054069378066031)
,p_validation_name=>'Observacion No vacio'
,p_validation_sequence=>30
,p_validation=>'P181_OBSERVACION'
,p_validation_type=>'ITEM_NOT_NULL_OR_ZERO'
,p_error_message=>unistr('#LABEL# debe tener alg\00FAn valor')
,p_always_execute=>'Y'
,p_validation_condition_type=>'NEVER'
,p_when_button_pressed=>wwv_flow_imp.id(540070948964144550)
,p_associated_item=>wwv_flow_imp.id(540065889912144546)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(540150396218116720)
,p_name=>'CambioActividad'
,p_event_sequence=>10
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P181_TODO_ACTIVIDAD'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(540150447985116721)
,p_event_id=>wwv_flow_imp.id(540150396218116720)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
':P181_ACTIVIDADES:=NULL;',
'if (:P181_TODO_ACTIVIDAD=''Y'')THEN',
'    SELECT LISTAGG(ID_TABLA, '':'') WITHIN GROUP (ORDER BY valor3,ID_TABLA) into :P181_ACTIVIDADES',
'    FROM "DATA"."T_CORP_UDC" ',
'    WHERE ID_CABECERA=''FINZ_GT01'' AND ID_TABLA!=''000'' ;',
'END IF;'))
,p_attribute_02=>'P181_TODO_ACTIVIDAD'
,p_attribute_03=>'P181_ACTIVIDADES'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(540053177058066022)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Previo a Crear'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'IF (:P181_ESTADO=0)THEN',
'    :P181_ESTADO:=1;',
'END IF;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(540070948964144550)
,p_internal_uid=>540053177058066022
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(540072161269144552)
,p_process_sequence=>30
,p_process_point=>'AFTER_SUBMIT'
,p_region_id=>wwv_flow_imp.id(540060364925144533)
,p_process_type=>'NATIVE_FORM_DML'
,p_process_name=>'GESTION TRIBUTARIA - AGREGAR PERIODO'
,p_attribute_01=>'REGION_SOURCE'
,p_attribute_05=>'Y'
,p_attribute_06=>'Y'
,p_attribute_08=>'Y'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(540070948964144550)
,p_process_success_message=>'Registro creado correctamente'
,p_internal_uid=>540072161269144552
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(279526203855148419)
,p_process_sequence=>40
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'post a Crea'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'PK_FINZ_GESTIONTRIBUTARIA.sp_cargalocalAreasfiscales (',
'         p_tipo =>0 ,p_periodo =>:P181_PERIODO',
');'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(540070948964144550)
,p_internal_uid=>279526203855148419
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(540053837854066029)
,p_process_sequence=>50
,p_process_point=>'AFTER_SUBMIT'
,p_region_id=>wwv_flow_imp.id(540060364925144533)
,p_process_type=>'NATIVE_FORM_DML'
,p_process_name=>'GESTION TRIBUTARIA - MODIFICAR PERIODO'
,p_attribute_01=>'REGION_SOURCE'
,p_attribute_05=>'Y'
,p_attribute_06=>'Y'
,p_attribute_08=>'Y'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(540070589311144550)
,p_process_success_message=>'Registro almacenado correctamente'
,p_internal_uid=>540053837854066029
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(13873360604746242)
,p_process_sequence=>60
,p_process_point=>'AFTER_SUBMIT'
,p_region_id=>wwv_flow_imp.id(540060364925144533)
,p_process_type=>'NATIVE_FORM_DML'
,p_process_name=>'GESTION TRIBUTARIA - ELIMINAR PERIODO'
,p_attribute_01=>'REGION_SOURCE'
,p_attribute_05=>'Y'
,p_attribute_06=>'Y'
,p_attribute_08=>'Y'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(540070148995144549)
,p_process_success_message=>'Registro almacenado correctamente'
,p_internal_uid=>13873360604746242
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(540053057620066021)
,p_process_sequence=>70
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_CLOSE_WINDOW'
,p_process_name=>'Close Dialog '
,p_attribute_02=>'N'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(540069516558144549)
,p_internal_uid=>540053057620066021
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(13873400850746243)
,p_process_sequence=>80
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_CLOSE_WINDOW'
,p_process_name=>'Close Dialog _1'
,p_attribute_02=>'N'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(540070148995144549)
,p_internal_uid=>13873400850746243
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(540051361588066004)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Setup Interface'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
'    :P181_COMPANIA:=:G_COMPANIA;',
'    :P181_ESTADO:=NVL(:P181_ESTADO,0);',
'    select  VALOR,VALOR2 ',
'    INTO :G_GT_MESESTRAS,:G_GT_MESESADELANTE',
'    from data.T_CORP_UDC',
'    where (ID_CABECERA=''FINZ_GT05'' AND ID_TABLA!=''000'' AND DESCRIPCION2=''MESES DE CONSULTA DE LOS PERIODOS'')',
'    ',
'    ORDER BY ID_CABECERA, ID_TABLA;',
'',
'    :P181_PERIODO:=TO_NUMBER(TO_CHAR(ADD_MONTHS(TRUNC(SYSDATE, ''MM''), 0), ''YYYYMM'')); ',
'    if (:P181_ID is null) then :P181_TODO_ACTIVIDAD:=''Y''; END IF;',
'    ',
'    if (:P181_TODO_ACTIVIDAD=''Y'')THEN',
'        SELECT LISTAGG(ID_TABLA, '':'') WITHIN GROUP (ORDER BY valor3,ID_TABLA) into :P181_ACTIVIDADES',
'        FROM "DATA"."T_CORP_UDC" ',
'        WHERE ID_CABECERA=''FINZ_GT01'' AND ID_TABLA!=''000'' ;',
'    END IF;',
'END;',
'-- :P181_EDITAR:=pk_admi_gestionparametros.f_admi_accesoacciones(:app_modulo,:app_user,180,''EDITAR'');',
'-- IF NOT(:P181_EDITAR=1 )THEN    ',
'--     IF not ( :P181_ESTADO in (0,1)) THEN',
'--         :P181_EDITAR=1',
'--     END IF;',
'-- END IF;',
' '))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>540051361588066004
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(540071794010144551)
,p_process_sequence=>20
,p_process_point=>'BEFORE_HEADER'
,p_region_id=>wwv_flow_imp.id(540060364925144533)
,p_process_type=>'NATIVE_FORM_INIT'
,p_process_name=>'Initialize form GESTION TRIBUTARIA - AGREGAR PERIODO'
,p_process_when_button_id=>wwv_flow_imp.id(540070948964144550)
,p_internal_uid=>540071794010144551
);
wwv_flow_imp.component_end;
end;
/
