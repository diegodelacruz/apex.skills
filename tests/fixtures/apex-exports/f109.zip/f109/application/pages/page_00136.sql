prompt --application/pages/page_00136
begin
--   Manifest
--     PAGE: 00136
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>109
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_page.create_page(
 p_id=>136
,p_name=>'ISD/FH - Parametros ISD'
,p_alias=>'ISD-FH-PARAMETROS-ISD1'
,p_step_title=>'ISD/FH - Parametros ISD'
,p_autocomplete_on_off=>'OFF'
,p_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'$(document).on("change", ".rdCodigoISD", function () {',
'    var vIdCodigo = $(this).val();',
'    $s("P136_IDS_CODIGOISD",vIdCodigo);',
'});',
'',
'',
'function setearProceso (p_proceso,p_id){',
'    if (p_proceso===''BORRAR''){',
'        borrarRelacion(p_proceso,p_id);',
'    }',
'}',
'',
'function borrarRelacion(p_proceso,p_id){',
'    var prc   = p_proceso;',
'    var id    = p_id;',
'    console.log("BORRAR_RELACION.prc",prc);',
'    console.log("BORRAR_RELACION.id",id);',
'',
'    apex.server.process(',
'        "BORRAR_RELACION",',
'        {',
'            x01: prc,',
'            x02: id',
'        },',
'        {',
'            dataType: "json",',
'            success: function(pData) {',
'                if (pData.success) {',
'                    apex.message.showPageSuccess("eliminado correctamente.");',
'                } else {',
'                    apex.message.clearErrors();',
'                    apex.message.showErrors([',
'                        {',
'                            type: "error",',
'                            location: ["page"],',
'                            message: pData.message,',
'                            unsafe: false',
'                        }',
'                    ]);',
'                }',
'            },',
'            error: function(jqXHR, textStatus, errorThrown) {',
'                apex.message.clearErrors();',
'                apex.message.showErrors([',
'                    {',
'                        type: "error",',
'                        location: ["page"],',
'                        message: "Error al eliminar el registro: " + errorThrown,',
'                        unsafe: false',
'                    }',
'                ]);',
'            }',
'        }',
'    );',
'    apex.region("rptPartidasCodigos").refresh();',
'',
'}',
''))
,p_javascript_code_onload=>'$(secItems).hide();'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'18'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(228904432823347537)
,p_plug_name=>'Barra de Acciones'
,p_region_template_options=>'#DEFAULT#:t-Form--stretchInputs'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(38289497777120142)
,p_plug_display_sequence=>60
,p_plug_display_point=>'REGION_POSITION_01'
,p_location=>null
,p_menu_id=>wwv_flow_imp.id(37761271469106475)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(37860983999106559)
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(449436767128876108)
,p_plug_name=>'Codigos ISD'
,p_region_name=>'regCodigosISD'
,p_region_template_options=>'#DEFAULT#:js-dialog-autoheight:js-dialog-size720x480'
,p_plug_template=>wwv_flow_imp.id(37804699672106518)
,p_plug_display_sequence=>20
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select  ',
'    case  ',
'        when trim(activo) =''1'' and trunc(sysdate) between to_date(VIGENCIADESDE) and  to_date(VIGENCIAHASTA)then 0',
'        else 1',
'    end estad,',
'ID_TABLA, DESCRIPCION, VALOR, VIGENCIADESDE, VIGENCIAHASTA,activo,',
'    apex_item.radiogroup(',
'        p_idx            => 2,',
'        p_value          => trim(id_tabla||''|''||trim(VALOR)),',
'        p_selected_value => null,',
'        p_attributes     => (case  ',
'        when trim(activo) =''1'' and trunc(sysdate) between to_date(VIGENCIADESDE) and  to_date(VIGENCIAHASTA)then ''''',
'        else ''disabled''',
'    end )||'' class="rdCodigoISD"''',
'    ) AS seleccionar',
'  from T_CORP_UDC',
' where ID_CABECERA=''FINZ_VISD'' and id_tabla!=''S/N'' ',
' ORDER BY ESTAD ,activo desc, ID_TABLA,DESCRIPCION'))
,p_plug_source_type=>'NATIVE_IR'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(453337510586585975)
,p_max_row_count=>'1000000'
,p_allow_report_saving=>'N'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_show_finder_drop_down=>'N'
,p_report_list_mode=>'NONE'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_select_columns=>'N'
,p_show_control_break=>'N'
,p_show_highlight=>'N'
,p_show_computation=>'N'
,p_show_aggregate=>'N'
,p_show_chart=>'N'
,p_show_group_by=>'N'
,p_show_pivot=>'N'
,p_show_flashback=>'N'
,p_show_help=>'N'
,p_download_formats=>'XLSX'
,p_enable_mail_download=>'N'
,p_owner=>'EMASABANDA'
,p_internal_uid=>453337510586585975
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(453337648447585976)
,p_db_column_name=>'ID_TABLA'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>unistr('C\00F3digo')
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(453337744180585977)
,p_db_column_name=>'DESCRIPCION'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>unistr('Descripci\00F3n')
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(453337818920585978)
,p_db_column_name=>'VALOR'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Valor'
,p_column_type=>'STRING'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(453337944587585979)
,p_db_column_name=>'VIGENCIADESDE'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Vig. Desde'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_format_mask=>'DD/MM/YYYY'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(453337991280585980)
,p_db_column_name=>'VIGENCIAHASTA'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Vig. Hasta'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_format_mask=>'DD/MM/YYYY'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(453338733430585987)
,p_db_column_name=>'SELECCIONAR'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'-'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(453339373002585994)
,p_db_column_name=>'ACTIVO'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>'Activo'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(453339846535585998)
,p_db_column_name=>'ESTAD'
,p_display_order=>110
,p_column_identifier=>'K'
,p_column_label=>'Estad'
,p_column_type=>'NUMBER'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(453348887739795036)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'2202408'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'SELECCIONAR:ID_TABLA:DESCRIPCION:VALOR:VIGENCIADESDE:VIGENCIAHASTA'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(449437383009876114)
,p_plug_name=>'Items'
,p_region_name=>'secItems'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(38289867500120143)
,p_plug_display_sequence=>50
,p_location=>null
,p_ai_enabled=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(462010962155623291)
,p_plug_name=>'Mesa de trabajo'
,p_region_template_options=>'#DEFAULT#:js-useLocalStorage:t-TabsRegion-mod--fillLabels:t-TabsRegion-mod--pill:t-TabsRegion-mod--large'
,p_plug_template=>wwv_flow_imp.id(37814656137106525)
,p_plug_display_sequence=>10
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(245338589249657138)
,p_plug_name=>'Impuestos + Partidas Arancelarias'
,p_parent_plug_id=>wwv_flow_imp.id(462010962155623291)
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(38289867500120143)
,p_plug_display_sequence=>20
,p_plug_display_point=>'SUB_REGIONS'
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(447806762532600373)
,p_plug_name=>'Partidas + Codigos ISD'
,p_region_name=>'rptPartidasCodigos'
,p_parent_plug_id=>wwv_flow_imp.id(245338589249657138)
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:js-useLocalStorage:is-collapsed:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(37796755046106514)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ID,',
'       a.TASISD,',
'       a.HSTISD,',
'       a.DESCRIPCION,',
'       a.PARARC,',
'       a.CODISD,',
'       apex_item.checkbox(',
'            p_idx=>1,',
'            p_value=>id||''|''||trim(a.PARARC),',
'            p_attributes=>CASE WHEN a.ACTIVO=0 THEN ''disabled'' ELSE '''' END ||'' class="chkF01"''  ',
'        )   selpart,',
'        apex_item.checkbox(',
'            p_idx=>2,',
'            p_value=>a.ID,',
'            p_attributes=>'' class="chkF02"''  ',
'        )   selcodi,',
'       ',
'        apex_item.checkbox(',
'        p_idx        => 3,',
'        p_value      => a.ID,',
'        p_attributes => ',
'            CASE a.ACTIVO ',
'                WHEN ''1'' THEN ''checked="checked"'' ',
'                ELSE '''' ',
'            END || '' class="chkF03"''',
'        ) AS ACTIVO',
'        ,a.ACTIVO ACTIVOval',
'        ,''<span class="fa fa-trash-o" aria-hidden="true"></span>'' borrar,',
'         isd.ISDDESCRIPCION,',
'    isd.valor,',
'    isd.vigenciadesde,',
'    isd.vigenciahasta',
'  from T_FINZ_CALCULOISDPRT  A',
'   LEFT JOIN (',
'        SELECT',
'            id_tabla,',
'            descripcion ISDDESCRIPCION,',
'            valor,',
'            vigenciadesde,',
'            vigenciahasta,',
'            CASE',
'                WHEN trunc(sysdate) < trunc(vigenciadesde)                                THEN',
'                    ''''',
'                WHEN trunc(sysdate) > trunc(vigenciahasta)                                THEN',
'                    ''CADUCADO''',
'                WHEN trunc(sysdate) BETWEEN trunc(vigenciadesde) AND trunc(vigenciahasta)',
'                     AND trunc(vigenciahasta) - trunc(sysdate) <= 30 THEN',
unistr('                    ''PR\00D3XIMO A CADUCAR'''),
'                WHEN trunc(sysdate) BETWEEN trunc(vigenciadesde) AND trunc(vigenciahasta) THEN',
'                    ''VIGENTE''',
'                ELSE',
'                    ''SIN DEFINIR''',
'            END AS estado_vigencia,',
'            CASE',
'                WHEN trunc(sysdate) BETWEEN trunc(vigenciadesde) AND trunc(vigenciahasta)',
'                     AND trunc(vigenciahasta) - trunc(sysdate) <= 30 THEN',
'                    2',
'                WHEN trunc(sysdate) BETWEEN trunc(vigenciadesde) AND trunc(vigenciahasta) THEN',
'                    1',
'                WHEN trunc(sysdate) < trunc(vigenciadesde)                                THEN',
'                    3',
'                WHEN trunc(sysdate) > trunc(vigenciahasta)                                THEN',
'                    4',
'                ELSE',
'                    5',
'            END orden_estado_vigencia',
'        FROM',
'            t_corp_udc',
'        WHERE',
'                id_cabecera = ''FINZ_VISD''',
'            AND id_tabla != ''S/N''',
'    ) isd on codisd= id_tabla',
'  order by activoval desc, id',
' '))
,p_plug_source_type=>'NATIVE_IR'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(447808600316600391)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_control_break=>'N'
,p_show_highlight=>'N'
,p_show_computation=>'N'
,p_show_aggregate=>'N'
,p_show_chart=>'N'
,p_show_group_by=>'N'
,p_show_pivot=>'N'
,p_show_flashback=>'N'
,p_show_help=>'N'
,p_download_formats=>'XLSX'
,p_enable_mail_download=>'N'
,p_owner=>'EMASABANDA'
,p_internal_uid=>447808600316600391
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(447808699248600392)
,p_db_column_name=>'ID'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Id'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(447809217217600397)
,p_db_column_name=>'ACTIVO'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'Activo'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(447809465100600400)
,p_db_column_name=>'TASISD'
,p_display_order=>100
,p_column_identifier=>'I'
,p_column_label=>'Porcentaje'
,p_column_html_expression=>'#TASISD# %'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(447809586774600401)
,p_db_column_name=>'HSTISD'
,p_display_order=>110
,p_column_identifier=>'J'
,p_column_label=>'Hstisd'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(447809739170600402)
,p_db_column_name=>'DESCRIPCION'
,p_display_order=>120
,p_column_identifier=>'K'
,p_column_label=>'Descripcion'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(449434906419876089)
,p_db_column_name=>'SELPART'
,p_display_order=>130
,p_column_identifier=>'M'
,p_column_label=>'<input type="checkbox" id="selectallpar">'
,p_sync_form_label=>'N'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(449434986184876090)
,p_db_column_name=>'SELCODI'
,p_display_order=>140
,p_column_identifier=>'N'
,p_column_label=>'<input type="checkbox" id="selectallocs">'
,p_sync_form_label=>'N'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_column_alignment=>'CENTER'
,p_display_condition_type=>'NEVER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(449435316299876093)
,p_db_column_name=>'PARARC'
,p_display_order=>160
,p_column_identifier=>'O'
,p_column_label=>'Partidas Arancelarias'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_rpt_named_lov=>wwv_flow_imp.id(216498906088861323)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(449435392527876094)
,p_db_column_name=>'CODISD'
,p_display_order=>170
,p_column_identifier=>'P'
,p_column_label=>'Impuesto ISD'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_rpt_named_lov=>wwv_flow_imp.id(214708572085569954)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(453339267864585993)
,p_db_column_name=>'ACTIVOVAL'
,p_display_order=>180
,p_column_identifier=>'Q'
,p_column_label=>'Activoval'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(245338733638657140)
,p_db_column_name=>'BORRAR'
,p_display_order=>190
,p_column_identifier=>'S'
,p_column_label=>'-'
,p_column_link=>'javascript:setearProceso(''BORRAR'',''#ID#'')'
,p_column_linktext=>'#BORRAR#'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_column_alignment=>'CENTER'
,p_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_display_condition=>'APP_USER'
,p_display_condition2=>'EMASABANDA'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(252654975975595222)
,p_db_column_name=>'ISDDESCRIPCION'
,p_display_order=>200
,p_column_identifier=>'T'
,p_column_label=>'Isddescripcion'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(252655019568595223)
,p_db_column_name=>'VALOR'
,p_display_order=>210
,p_column_identifier=>'U'
,p_column_label=>'Valor'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(252655191388595224)
,p_db_column_name=>'VIGENCIADESDE'
,p_display_order=>220
,p_column_identifier=>'V'
,p_column_label=>'Vig. Desde'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_format_mask=>'DD/MM/YYYY'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(252655238287595225)
,p_db_column_name=>'VIGENCIAHASTA'
,p_display_order=>230
,p_column_identifier=>'W'
,p_column_label=>'Vig. Hasta'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_format_mask=>'DD/MM/YYYY'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(447854208354012885)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'2147461'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_display_rows=>15
,p_report_columns=>'ACTIVO:SELPART:PARARC:CODISD:SELCODI:TASISD:DESCRIPCION:VIGENCIADESDE:VIGENCIAHASTA:BORRAR:'
,p_sort_column_1=>'ACTIVOVAL'
,p_sort_direction_1=>'DESC'
,p_sort_column_2=>'ID'
,p_sort_direction_2=>'DESC'
,p_sort_column_3=>'0'
,p_sort_direction_3=>'ASC'
,p_sort_column_4=>'0'
,p_sort_direction_4=>'ASC'
,p_sort_column_5=>'0'
,p_sort_direction_5=>'ASC'
,p_sort_column_6=>'0'
,p_sort_direction_6=>'ASC'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(453340194785586002)
,p_plug_name=>'Partidas Arancelarias'
,p_region_name=>'rptPartidas'
,p_parent_plug_id=>wwv_flow_imp.id(245338589249657138)
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:js-useLocalStorage:is-collapsed:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(37796755046106514)
,p_plug_display_sequence=>20
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ',
'    vt_cat.drky , vt_cat.drdl01, vt_cat.drdl02,',
unistr('    --, decode(trim(vt_cat.drsphd),''S'',''S\00CD'',''NO'') ct'),
'       apex_item.checkbox(',
'            p_idx=>11,',
'            p_value=>-1||''|''||trim(vt_cat.drky),',
'            p_attributes=>'' class="chkF11"''  ',
'        )   selpart',
'        ,CASE WHEN PARARC IS NULL THEN 0 ELSE 1 END VALIDA',
'    from data.vt_jde_udcjde vt_cat ',
'    LEFT JOIN T_FINZ_CALCULOISDPRT ON drky=PARARC',
'    where vt_cat.drsy = ''41'' and vt_cat.drrt = ''10'' and DRKY is not null --and DRKY!=''N/A''',
'    order by 1,2,3',
''))
,p_plug_source_type=>'NATIVE_IR'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(453340357911586003)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_control_break=>'N'
,p_show_highlight=>'N'
,p_show_computation=>'N'
,p_show_aggregate=>'N'
,p_show_chart=>'N'
,p_show_group_by=>'N'
,p_show_pivot=>'N'
,p_show_flashback=>'N'
,p_show_help=>'N'
,p_download_formats=>'XLSX'
,p_enable_mail_download=>'N'
,p_owner=>'EMASABANDA'
,p_internal_uid=>453340357911586003
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(453340904608586009)
,p_db_column_name=>'SELPART'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'<input type="checkbox" id="selectallpart">'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(453341703517586017)
,p_db_column_name=>'DRKY'
,p_display_order=>70
,p_column_identifier=>'K'
,p_column_label=>unistr('C\00F3digo')
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(453341858704586018)
,p_db_column_name=>'DRDL01'
,p_display_order=>80
,p_column_identifier=>'L'
,p_column_label=>'Partida Arancelaria'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(453341953997586019)
,p_db_column_name=>'DRDL02'
,p_display_order=>90
,p_column_identifier=>'M'
,p_column_label=>unistr('Descripci\00F3n')
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(252654887368595221)
,p_db_column_name=>'VALIDA'
,p_display_order=>100
,p_column_identifier=>'N'
,p_column_label=>'Valida'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(462007332267576293)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'2288992'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_display_rows=>15
,p_report_columns=>'SELPART:DRKY:DRDL01:DRDL02'
);
wwv_flow_imp_page.create_worksheet_condition(
 p_id=>wwv_flow_imp.id(252690455608503992)
,p_report_id=>wwv_flow_imp.id(462007332267576293)
,p_name=>'Part. con impuesto'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'VALIDA'
,p_operator=>'='
,p_expr=>'1'
,p_condition_sql=>' (case when ("VALIDA" = to_number(#APXWS_EXPR#)) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_row_bg_color=>'#f6e5d670'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(680903959104816130)
,p_plug_name=>'ISD/FH - Parametros ISD'
,p_title=>'Impuestos'
,p_parent_plug_id=>wwv_flow_imp.id(462010962155623291)
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(37806762584106520)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ID,',
'       ID_CABECERA,',
'       ID_TABLA,',
'       DESCRIPCION,',
'       VALOR,',
'       VALOR2,',
'       ACTIVO,',
'       DESCRIPCION2,',
'       CODIGOCOMPANIA,',
'       VIGENCIADESDE,',
'       VIGENCIAHASTA,',
'       DESCRIPCION3,',
'       VALOR3,',
'       case',
'           when trunc(sysdate) < trunc(VIGENCIADESDE) then ''''',
'           when trunc(sysdate) > trunc(VIGENCIAHASTA) then ''CADUCADO''',
unistr('           when trunc(sysdate) between trunc(VIGENCIADESDE) and trunc(VIGENCIAHASTA) and trunc(VIGENCIAHASTA) - trunc(sysdate) <= 30 then ''PR\00D3XIMO A CADUCAR'''),
'           when trunc(sysdate) between trunc(VIGENCIADESDE) and trunc(VIGENCIAHASTA) then ''VIGENTE''',
'           else ''SIN DEFINIR''',
'       end as ESTADO_VIGENCIA',
'       ,case',
'        when trunc(sysdate) between trunc(VIGENCIADESDE) and trunc(VIGENCIAHASTA) and trunc(VIGENCIAHASTA) - trunc(sysdate) <= 30 then 2',
'        when trunc(sysdate) between trunc(VIGENCIADESDE) and trunc(VIGENCIAHASTA) then 1',
'        when trunc(sysdate) < trunc(VIGENCIADESDE) then 3',
'        when trunc(sysdate) > trunc(VIGENCIAHASTA) then 4',
'        else 5',
'    end orden_estado_vigencia',
'  from T_CORP_UDC',
' where ID_CABECERA=''FINZ_VISD'' and id_tabla!=''S/N''',
' order by orden_estado_vigencia,',
'    VIGENCIADESDE,',
'       VIGENCIAHASTA'))
,p_plug_source_type=>'NATIVE_IR'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'Impuestos'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(682527037300091796)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'C'
,p_show_select_columns=>'N'
,p_show_rows_per_page=>'N'
,p_show_control_break=>'N'
,p_show_highlight=>'N'
,p_show_computation=>'N'
,p_show_aggregate=>'N'
,p_show_chart=>'N'
,p_show_group_by=>'N'
,p_show_pivot=>'N'
,p_show_flashback=>'N'
,p_show_reset=>'N'
,p_show_help=>'N'
,p_download_formats=>'XLSX'
,p_enable_mail_download=>'N'
,p_detail_link=>'f?p=&APP_ID.:137:&SESSION.::&DEBUG.:137:P137_ID,P137_ID_TABLA:#ID#,#ID_TABLA#'
,p_detail_link_text=>'<span role="img" aria-label="Edit" class="fa fa-edit" title="Edit"></span>'
,p_owner=>'EMASABANDA'
,p_internal_uid=>682527037300091796
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(682527202262091797)
,p_db_column_name=>'ID'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Id'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(682527331397091799)
,p_db_column_name=>'ID_TABLA'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>unistr('C\00F3digos ISD')
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(682527474799091800)
,p_db_column_name=>'DESCRIPCION'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>unistr('Descripci\00F3n')
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(682527581126091801)
,p_db_column_name=>'VALOR'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Porcentaje'
,p_column_html_expression=>'#VALOR# %'
,p_column_type=>'STRING'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
,p_help_text=>'Valor de porcentaje de la partida arancelaria'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(682527787752091803)
,p_db_column_name=>'ACTIVO'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>'Activo'
,p_column_type=>'STRING'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_column_alignment=>'CENTER'
,p_rpt_named_lov=>wwv_flow_imp.id(105205170216064959)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(682528101402091806)
,p_db_column_name=>'VIGENCIADESDE'
,p_display_order=>80
,p_column_identifier=>'J'
,p_column_label=>'Vig. Desde'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(682528150218091807)
,p_db_column_name=>'VIGENCIAHASTA'
,p_display_order=>90
,p_column_identifier=>'K'
,p_column_label=>'Vig. Hasta'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(682527229254091798)
,p_db_column_name=>'ID_CABECERA'
,p_display_order=>100
,p_column_identifier=>'B'
,p_column_label=>'Id Cabecera'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(682527699955091802)
,p_db_column_name=>'VALOR2'
,p_display_order=>110
,p_column_identifier=>'F'
,p_column_label=>'Valor2'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(682527876194091804)
,p_db_column_name=>'DESCRIPCION2'
,p_display_order=>120
,p_column_identifier=>'H'
,p_column_label=>'Descripcion2'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(682528009884091805)
,p_db_column_name=>'CODIGOCOMPANIA'
,p_display_order=>130
,p_column_identifier=>'I'
,p_column_label=>'Codigocompania'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(682528301294091808)
,p_db_column_name=>'DESCRIPCION3'
,p_display_order=>140
,p_column_identifier=>'L'
,p_column_label=>'Descripcion3'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(682528360407091809)
,p_db_column_name=>'VALOR3'
,p_display_order=>150
,p_column_identifier=>'M'
,p_column_label=>'Valor3'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(695102988559838996)
,p_db_column_name=>'ESTADO_VIGENCIA'
,p_display_order=>160
,p_column_identifier=>'N'
,p_column_label=>'Estado Vigencia'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(695103112467838997)
,p_db_column_name=>'ORDEN_ESTADO_VIGENCIA'
,p_display_order=>170
,p_column_identifier=>'O'
,p_column_label=>'Orden Estado Vigencia'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(682537918606120060)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'2163360'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'ID_TABLA:DESCRIPCION:VALOR:ACTIVO:VIGENCIADESDE:VIGENCIAHASTA:ESTADO_VIGENCIA:'
,p_sort_column_1=>'ID'
,p_sort_direction_1=>'DESC'
,p_sort_column_2=>'ORDEN_ESTADO_VIGENCIA'
,p_sort_direction_2=>'DESC'
,p_sort_column_3=>'VIGENCIADESDE'
,p_sort_direction_3=>'ASC'
,p_sort_column_4=>'VIGENCIAHASTA'
,p_sort_direction_4=>'ASC'
,p_sort_column_5=>'0'
,p_sort_direction_5=>'ASC'
,p_sort_column_6=>'0'
,p_sort_direction_6=>'ASC'
);
wwv_flow_imp_page.create_worksheet_condition(
 p_id=>wwv_flow_imp.id(252689265342497600)
,p_report_id=>wwv_flow_imp.id(682537918606120060)
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'ESTADO_VIGENCIA'
,p_operator=>'='
,p_expr=>'CADUCADO'
,p_condition_sql=>' (case when ("ESTADO_VIGENCIA" = #APXWS_EXPR#) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# = ''CADUCADO''  '
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_row_bg_color=>'#fec7cc69'
);
wwv_flow_imp_page.create_worksheet_condition(
 p_id=>wwv_flow_imp.id(252689617179497601)
,p_report_id=>wwv_flow_imp.id(682537918606120060)
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'ESTADO_VIGENCIA'
,p_operator=>'='
,p_expr=>unistr('PR\00D3XIMO A CADUCAR')
,p_condition_sql=>' (case when ("ESTADO_VIGENCIA" = #APXWS_EXPR#) then #APXWS_HL_ID# end) '
,p_condition_display=>unistr('#APXWS_COL_NAME# = ''PR\00D3XIMO A CADUCAR''  ')
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_row_bg_color=>'#f6e5d670'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(233127822796275828)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(228904432823347537)
,p_button_name=>'Atras'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860056812106557)
,p_button_image_alt=>'Atras'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'LEFT'
,p_button_redirect_url=>'f?p=&APP_ID.:131:&SESSION.::&DEBUG.:RR,131::'
,p_icon_css_classes=>'fa-arrow-left'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(233127078036275828)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(449436767128876108)
,p_button_name=>'Cerrar'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860181880106559)
,p_button_image_alt=>'Cerrar'
,p_button_position=>'CLOSE'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-times-square'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(233126653290275827)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(449436767128876108)
,p_button_name=>'Aceptar'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860181880106559)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Aceptar'
,p_button_position=>'CREATE'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(233112738381275810)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(447806762532600373)
,p_button_name=>'Reasignar'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860056812106557)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Reasignar'
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-ai-sparkle-generate-list'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(233122861697275824)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(680903959104816130)
,p_button_name=>'CREATE'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860056812106557)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Create'
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
,p_button_redirect_url=>'f?p=&APP_ID.:137:&SESSION.::&DEBUG.:RR,137::'
,p_button_css_classes=>'btnAccion'
,p_icon_css_classes=>'fa-plus'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(233115353539275813)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(453340194785586002)
,p_button_name=>'Asignar'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860056812106557)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Asignar'
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-ai-sparkle-generate-list'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(449458045695876174)
,p_name=>'P136_TIPO'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(449437383009876114)
,p_prompt=>'Tipo'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_warn_on_unsaved_changes=>'I'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(453359080343586045)
,p_name=>'P136_IDS_PARTIDAS'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(449437383009876114)
,p_prompt=>'Ids Partidas'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_warn_on_unsaved_changes=>'I'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(453359582803586050)
,p_name=>'P136_IDS_CODIGOISD'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(449437383009876114)
,p_prompt=>'Ids Codigoisd'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_warn_on_unsaved_changes=>'I'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(233131173637275838)
,p_name=>'Selecciona Todo PartidasCodigos'
,p_event_sequence=>10
,p_triggering_element_type=>'JQUERY_SELECTOR'
,p_triggering_element=>'#selectallpar'
,p_bind_type=>'live'
,p_bind_delegate_to_selector=>'#rptPartidasCodigos'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(233131619919275839)
,p_event_id=>wwv_flow_imp.id(233131173637275838)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'if ($(''#rptPartidasCodigos #selectallpar'').is('':checked'')) {',
'    $(''#rptPartidasCodigos input[type=checkbox][name=f01]:not(:disabled)'').prop(''checked'', true);',
'} else {',
'    $(''#rptPartidasCodigos input[type=checkbox][name=f01]:not(:disabled)'').prop(''checked'', false);',
'}'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(233133843588275841)
,p_name=>'Selecciona Todo Partidas'
,p_event_sequence=>20
,p_triggering_element_type=>'JQUERY_SELECTOR'
,p_triggering_element=>'#selectallpart'
,p_bind_type=>'live'
,p_bind_delegate_to_selector=>'#rptPartidas'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(233134397757275841)
,p_event_id=>wwv_flow_imp.id(233133843588275841)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'if ($(''#rptPartidas #selectallpart'').is('':checked'')) {',
'    $(''#rptPartidas input[type=checkbox][name=f11]:not(:disabled)'').prop(''checked'', true);',
'} else {',
'    $(''#rptPartidas input[type=checkbox][name=f11]:not(:disabled)'').prop(''checked'', false);',
'}'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(233132987279275841)
,p_name=>'Cambiar Estado'
,p_event_sequence=>30
,p_triggering_element_type=>'JQUERY_SELECTOR'
,p_triggering_element=>'.chkF03'
,p_bind_type=>'live'
,p_bind_delegate_to_selector=>'#rptPartidasCodigos'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(233133460278275841)
,p_event_id=>wwv_flow_imp.id(233132987279275841)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'var chk   = this.triggeringElement;',
'var id    = chk.value;',
'var valor = chk.checked ? ''1'' : ''0'';',
'',
'apex.server.process(',
'    "ACTUALIZA_ACTIVO_RELACION",',
'    {',
'        x01: valor,',
'        x02: id',
'    },',
'    {',
'        dataType: "json",',
'        success: function(pData) {',
'            if (pData.success) {',
'                apex.message.showPageSuccess("Estado actualizado correctamente.");',
'            } else {',
'                apex.message.clearErrors();',
'                apex.message.showErrors([',
'                    {',
'                        type: "error",',
'                        location: ["page"],',
'                        message: pData.message,',
'                        unsafe: false',
'                    }',
'                ]);',
'            }',
'        },',
'        error: function(jqXHR, textStatus, errorThrown) {',
'            apex.message.clearErrors();',
'            apex.message.showErrors([',
'                {',
'                    type: "error",',
'                    location: ["page"],',
'                    message: "Error al actualizar el registro: " + errorThrown,',
'                    unsafe: false',
'                }',
'            ]);',
'        }',
'    }',
');',
'apex.region("rptPartidasCodigos").refresh();'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(233137926513275843)
,p_name=>'ASIGNA PARTIDACODIGO'
,p_event_sequence=>40
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(233112738381275810)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(233138467303275843)
,p_event_id=>wwv_flow_imp.id(233137926513275843)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'var arr = [];',
'',
'$(".chkF01:checked").each(function () {',
'    arr.push($(this).val());',
'});',
'',
'if (arr.length === 0) {',
'    apex.message.alert("Debe seleccionar al menos una partida arancelaria para continuar con el proceso.");',
'    return;',
'}',
'',
'$s("P136_IDS_PARTIDAS", arr.join(":"));',
'',
'apex.theme.openRegion("regCodigosISD");'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(233134742396275842)
,p_name=>'ASIGNA PARTIDA'
,p_event_sequence=>50
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(233115353539275813)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(233135284476275842)
,p_event_id=>wwv_flow_imp.id(233134742396275842)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'var arr = [];',
' ',
'$(".chkF11:checked").each(function () {',
'    arr.push($(this).val());',
'});',
'',
'if (arr.length === 0) {',
'    apex.message.alert("Debe seleccionar al menos una partida arancelaria para continuar con el proceso.");',
'    return;',
'}',
'',
'$s("P136_IDS_PARTIDAS", arr.join(":"));',
'',
'apex.theme.openRegion("regCodigosISD");'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(233135616066275842)
,p_name=>'CloseDialog'
,p_event_sequence=>60
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(233127078036275828)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(233136162890275842)
,p_event_id=>wwv_flow_imp.id(233135616066275842)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'apex.theme.closeRegion("regCodigosISD");'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(233136525607275842)
,p_name=>'ASIGNAR_CODIGO_ISD'
,p_event_sequence=>70
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(233126653290275827)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(233137028051275843)
,p_event_id=>wwv_flow_imp.id(233136525607275842)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_CONFIRM'
,p_attribute_01=>unistr('Esta seguro de asignar este c\00F3digo ISD a las partidas arancelarias seleccionadas?')
,p_attribute_02=>unistr('Asignaci\00F3n de C\00F3digo ISD')
,p_attribute_03=>'warning'
,p_attribute_04=>'fa-warning'
,p_attribute_06=>unistr('S\00CD')
,p_attribute_07=>'NO'
,p_client_condition_type=>'NOT_NULL'
,p_client_condition_element=>'P136_IDS_CODIGOISD'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(233137507906275843)
,p_event_id=>wwv_flow_imp.id(233136525607275842)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'var vIdCodigo=$v("P136_IDS_CODIGOISD");',
'var vIdsPartidas = $v("P136_IDS_PARTIDAS");',
'    var arrPartidas = vIdsPartidas ? vIdsPartidas.split(":") : [];',
'    var vTipoMasivo = arrPartidas.length > 1 ? 1 : 0;',
'',
'    if (!vIdCodigo) {',
unistr('        apex.message.alert("No ha seleccionado un c\00F3digo ISD a ser asigando.");'),
'        return;',
'    }',
'    ',
'    apex.server.process(',
'        "ASIGNAR_CODIGO_ISD",',
'        {',
'            x01: vIdsPartidas,',
'            x02: vIdCodigo,',
'            x03: vTipoMasivo',
'        },',
'        {',
'            dataType: "json",',
'            success: function (pData) {',
'                if (pData.resultado === "OK") {',
'                    apex.theme.closeRegion("regCodigosISD");',
'                    apex.region("rptPartidasCodigos").refresh();',
'                    apex.message.showPageSuccess(pData.mensaje);',
'                } else {',
'                    apex.message.alert(pData.mensaje);',
'                }',
'            },',
'            error: function () {',
'                apex.message.alert("Error al ejecutar el proceso.");',
'            }',
'        }',
'    );'))
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(245339252115657145)
,p_event_id=>wwv_flow_imp.id(233136525607275842)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_02=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(233132022291275839)
,p_name=>'Close Dialog'
,p_event_sequence=>80
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(233122861697275824)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosecanceldialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(233132566401275840)
,p_event_id=>wwv_flow_imp.id(233132022291275839)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_02=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(245339062992657143)
,p_name=>'CLOSE DIALOG'
,p_event_sequence=>90
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(680903959104816130)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosecanceldialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(245339179079657144)
,p_event_id=>wwv_flow_imp.id(245339062992657143)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(680903959104816130)
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(233130318700275835)
,p_process_sequence=>10
,p_process_point=>'ON_DEMAND'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'ACTUALIZA_ACTIVO_RELACION'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    v_activo NUMBER;',
'    v_id     NUMBER;',
'    ',
'BEGIN',
'    v_activo := TO_NUMBER(APEX_APPLICATION.G_X01);',
'    v_id     := TO_NUMBER(APEX_APPLICATION.G_X02);',
'',
'',
'    UPDATE T_FINZ_CALCULOISDPRT',
'       SET ACTIVO = v_activo',
'     WHERE ID = v_id;',
'',
'    COMMIT;',
'',
'    apex_json.open_object;',
'    apex_json.write(''success'', true);',
'    apex_json.write(''id'', v_id);',
'    apex_json.write(''activo'', v_activo);',
'    apex_json.close_object;',
'',
'EXCEPTION',
'    WHEN OTHERS THEN',
'        ROLLBACK;',
'        apex_json.open_object;',
'        apex_json.write(''success'', false);',
'        apex_json.write(''message'', SQLERRM);',
'        apex_json.close_object;',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>233130318700275835
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(245338829748657141)
,p_process_sequence=>20
,p_process_point=>'ON_DEMAND'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'BORRAR_RELACION'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    v_proceso VARCHAR2(399);',
'    v_id     NUMBER;',
'    ',
'BEGIN',
'    v_proceso:= (APEX_APPLICATION.G_X01);',
'    v_id     := TO_NUMBER(APEX_APPLICATION.G_X02);',
'',
'',
'    delete T_FINZ_CALCULOISDPRT WHERE ID = v_id; ',
'    COMMIT;',
'',
'    apex_json.open_object;',
'    apex_json.write(''success'', true);',
'    apex_json.write(''id'', v_id);',
'    apex_json.write(''activo'', v_proceso);',
'    apex_json.close_object;',
'',
'-- EXCEPTION',
'--     WHEN OTHERS THEN',
'--         ROLLBACK;',
'--         apex_json.open_object;',
'--         apex_json.write(''success'', false);',
'--         apex_json.write(''message'', SQLERRM);',
'--         apex_json.close_object;',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>245338829748657141
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(233130787170275838)
,p_process_sequence=>30
,p_process_point=>'ON_DEMAND'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'ASIGNAR_CODIGO_ISD'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_ids_partidas  varchar2(32767) := apex_application.g_x01;',
'    l_id_codigo     varchar2(100)   := apex_application.g_x02;',
'    l_tipo_masivo   number          := nvl(to_number(apex_application.g_x03), 0);',
'    l_resultado     number;',
'begin',
'    for r in (SELECT a.CAMPO1 id, a.CAMPO2 pararac,b.CAMPO1 codisd, b.CAMPO2 valor ',
'        FROM table(pk_commons.f_split2table(l_ids_partidas,''|'' ,'':'' ))a  ',
'        cross join table(pk_commons.f_split2table(l_id_codigo,''|'' ,'':'' )) b',
'    )loop',
unistr('        pk_finz_factorhumedad.sp_historialisd(r.id,r.pararac,r.codisd,r.valor,''Reasignaci\00F3n'',l_resultado);'),
'    end loop;',
'',
'    apex_json.open_object;',
'    apex_json.write(''resultado'', ''OK'');',
unistr('    apex_json.write(''mensaje'', ''C\00F3digo asignado correctamente.'');'),
'    apex_json.close_object;',
'',
'exception',
'    when others then',
'        apex_json.open_object;',
'        apex_json.write(''resultado'', ''ERROR'');',
'        apex_json.write(''mensaje'', sqlerrm);',
'        apex_json.close_object;',
'end;',
''))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>233130787170275838
);
wwv_flow_imp.component_end;
end;
/
