prompt --application/pages/page_00114
begin
--   Manifest
--     PAGE: 00114
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>109
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_page.create_page(
 p_id=>114
,p_name=>'Informe Rechazo'
,p_step_title=>'Informe Rechazo'
,p_autocomplete_on_off=>'OFF'
,p_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'function mostrarReporteFechas()',
'{',
'myID = $v2("P114_URL");',
'window.open(''http://jasper.zaimella.com:8080/ReportesZAI/report?_repName=Calidad/rpt_ProductoRechazado&_repFormat=pdf&_dataSource=default&_outFilename=&_repLocale=en_US&_repEncoding=UTF-8&prmID=''+myID, "newWindow","status=1,toolbar=1, width=1000,heig'
||'ht=600");',
'};',
''))
,p_page_template_options=>'#DEFAULT#'
,p_page_component_map=>'17'
,p_created_on=>wwv_flow_imp.dz('20230705164634Z')
,p_last_updated_on=>wwv_flow_imp.dz('20210913155555Z')
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(337502063263323029)
,p_plug_name=>'Informe'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(37807886111106520)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(337501902739323028)
,p_name=>'P114_URL'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(337502063263323029)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp.component_end;
end;
/
