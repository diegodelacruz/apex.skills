prompt --application/pages/page_00444
begin
--   Manifest
--     PAGE: 00444
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>109
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_page.create_page(
 p_id=>444
,p_name=>'PYG INDUSTRIALES - DLG - METODOS DISTRIBUCION (CRUD)'
,p_alias=>'PYG-INDUSTRIALES-CRUD-METODOS-DISTRIBUCION'
,p_page_mode=>'MODAL'
,p_step_title=>'PYG INDUSTRIALES - CRUD - METODOS DISTRIBUCION'
,p_autocomplete_on_off=>'OFF'
,p_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'function f_setpopup(p_idform,p_idticrt){',
'    $s("P444_TIPOCRITERIODIS","");',
'	console.log("p_idform",p_idform);',
'	console.log("p_idticrt",p_idticrt);',
'    switch(p_idform){',
'            case 0 : if (p_idticrt===1){$s("P444_TIPOCRITERIODIS","VN");}',
'                     if (p_idticrt===2){$s("P444_TIPOCRITERIODIS","GV");}',
'                     break;',
'            case 1 : $(''#btnDimensionDist'').trigger("click");',
'                     break;',
'    }',
'	console.log("P444_TIPOCRITERIODIS",$v("P444_TIPOCRITERIODIS"));',
'}'))
,p_javascript_code_onload=>'$(secItems).hide();'
,p_step_template=>wwv_flow_imp.id(37774372912106498)
,p_page_template_options=>'#DEFAULT#:t-Dialog--noPadding'
,p_dialog_width=>'1200'
,p_dialog_css_classes=>'dlg-sin-cerrar'
,p_protection_level=>'C'
,p_page_component_map=>'02'
,p_last_updated_on=>wwv_flow_imp.dz('20260304160103Z')
,p_last_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(126487655289870423)
,p_plug_name=>'Barra de Acciones'
,p_region_template_options=>'#DEFAULT#:t-Form--stretchInputs'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(38289497777120142)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_location=>null
,p_menu_id=>wwv_flow_imp.id(37761271469106475)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(37860983999106559)
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(249848962489026442)
,p_plug_name=>'Items'
,p_region_name=>'secItems'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(38289867500120143)
,p_plug_display_sequence=>40
,p_location=>null
,p_ai_enabled=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(252348354147293367)
,p_plug_name=>'PYG INDUSTRIALES - CRUD - METODOS DISTRIBUCION - CFG'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(38289867500120143)
,p_plug_display_sequence=>10
,p_query_type=>'TABLE'
,p_query_table=>'T_FINZ_DISTRIBUCIONMTD'
,p_include_rowid_column=>false
,p_is_editable=>true
,p_edit_operations=>'i:u:d'
,p_lost_update_check_type=>'VALUES'
,p_plug_source_type=>'NATIVE_FORM'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(253178698897651547)
,p_plug_name=>'TabsReporte '
,p_region_template_options=>'#DEFAULT#:t-TabsRegion-mod--fillLabels:t-TabsRegion-mod--pill:t-TabsRegion-mod--large'
,p_plug_template=>wwv_flow_imp.id(37814656137106525)
,p_plug_display_sequence=>30
,p_location=>null
,p_plug_source_type=>'NATIVE_DISPLAY_SELECTOR'
,p_plug_display_condition_type=>'EXPRESSION'
,p_plug_display_when_condition=>':P444_ID is not null and :G_DIMENSIONDIST is not null'
,p_plug_display_when_cond2=>'PLSQL'
,p_ai_enabled=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'display_region_icons', 'N',
  'include_show_all', 'N',
  'rds_mode', 'STANDARD',
  'remember_selection', 'USER')).to_clob
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(252531795232082531)
,p_name=>unistr('CRITERIOS DE DISTRIBUCI\00D3N VN')
,p_title=>unistr('CRITERIOS DE DISTRIBUCI\00D3N VN<button type=''button'' id=''btnRegCriterioDist'' onclick=''f_setpopup(0,1);'' class=''t-Button t-Button--noLabel t-Button--icon js-ignoreChange''><span class=''fa fa-tasks-alt fam-information fam-is-info''></span></button></label>')
,p_region_name=>'regionDistribucionVN'
,p_parent_plug_id=>wwv_flow_imp.id(253178698897651547)
,p_template=>wwv_flow_imp.id(38289867500120143)
,p_display_sequence=>20
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_component_template_options=>'#DEFAULT#:t-Report--stretch:t-Report--altRowsDefault:t-Report--rowHighlight:t-Report--inline'
,p_display_point=>'SUB_REGIONS'
,p_item_display_point=>'BELOW'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT * FROM ',
'(',
'    SELECT',
'    SEQ_ID,C001,N001,N002,N003,N004,C002,C003,C004,C005,C006,C007,C008,C009,C010',
'    FROM APEX_COLLECTIONS ',
'    WHERE COLLECTION_NAME =''COLECCION_CRITERIOSDIST''',
'    and C001=''VN''',
'ORDER BY C001,N004,C002',
'',
')'))
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(37830327650106535)
,p_query_num_rows=>1500
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_break_cols=>'1'
,p_break_type_flag=>'REPEAT_HEADINGS_ON_BREAK_1'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(126790111434999866)
,p_query_column_id=>1
,p_column_alias=>'SEQ_ID'
,p_column_display_sequence=>180
,p_use_as_row_header=>'N'
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(126793314191999869)
,p_query_column_id=>2
,p_column_alias=>'C001'
,p_column_display_sequence=>10
,p_column_heading=>'FLAG'
,p_use_as_row_header=>'N'
,p_column_alignment=>'CENTER'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(126791323926999867)
,p_query_column_id=>3
,p_column_alias=>'N001'
,p_column_display_sequence=>60
,p_column_heading=>'Estado'
,p_use_as_row_header=>'N'
,p_column_alignment=>'CENTER'
,p_display_as=>'TEXT_FROM_LOV'
,p_named_lov=>wwv_flow_imp.id(103334473958064327)
,p_derived_column=>'N'
,p_include_in_export=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(126791741111999868)
,p_query_column_id=>4
,p_column_alias=>'N002'
,p_column_display_sequence=>70
,p_column_heading=>'Ingresos'
,p_use_as_row_header=>'N'
,p_column_alignment=>'CENTER'
,p_display_as=>'TEXT_FROM_LOV'
,p_named_lov=>wwv_flow_imp.id(105205170216064959)
,p_derived_column=>'N'
,p_include_in_export=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(126792195704999868)
,p_query_column_id=>5
,p_column_alias=>'N003'
,p_column_display_sequence=>80
,p_column_heading=>'Gastos'
,p_use_as_row_header=>'N'
,p_column_alignment=>'CENTER'
,p_display_as=>'TEXT_FROM_LOV'
,p_named_lov=>wwv_flow_imp.id(105205170216064959)
,p_derived_column=>'N'
,p_include_in_export=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(126790539365999867)
,p_query_column_id=>6
,p_column_alias=>'N004'
,p_column_display_sequence=>40
,p_column_heading=>'Orden'
,p_use_as_row_header=>'N'
,p_column_alignment=>'CENTER'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(126790947456999867)
,p_query_column_id=>7
,p_column_alias=>'C002'
,p_column_display_sequence=>50
,p_column_heading=>'Referencia'
,p_use_as_row_header=>'N'
,p_column_alignment=>'CENTER'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(126792512973999868)
,p_query_column_id=>8
,p_column_alias=>'C003'
,p_column_display_sequence=>90
,p_column_heading=>'&P444_ABT1.'
,p_use_as_row_header=>'N'
,p_column_hit_highlight=>'X'
,p_column_alignment=>'CENTER'
,p_display_when_cond_type=>'EXPRESSION'
,p_display_when_condition=>':P444_CHK1!=0'
,p_display_when_condition2=>'PLSQL'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(126792996379999869)
,p_query_column_id=>9
,p_column_alias=>'C004'
,p_column_display_sequence=>100
,p_column_heading=>'&P444_ABT2.'
,p_use_as_row_header=>'N'
,p_column_hit_highlight=>'X'
,p_column_alignment=>'CENTER'
,p_display_when_cond_type=>'EXPRESSION'
,p_display_when_condition=>':P444_CHK2!=0'
,p_display_when_condition2=>'PLSQL'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(126793710415999869)
,p_query_column_id=>10
,p_column_alias=>'C005'
,p_column_display_sequence=>110
,p_column_heading=>'&P444_ABT3.'
,p_use_as_row_header=>'N'
,p_column_hit_highlight=>'X'
,p_column_alignment=>'CENTER'
,p_display_when_cond_type=>'EXPRESSION'
,p_display_when_condition=>':P444_CHK3!=0'
,p_display_when_condition2=>'PLSQL'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(126794148710999869)
,p_query_column_id=>11
,p_column_alias=>'C006'
,p_column_display_sequence=>120
,p_column_heading=>'&P444_ABT4.'
,p_use_as_row_header=>'N'
,p_column_hit_highlight=>'X'
,p_column_alignment=>'CENTER'
,p_display_when_cond_type=>'EXPRESSION'
,p_display_when_condition=>':P444_CHK4!=0'
,p_display_when_condition2=>'PLSQL'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(126794564556999869)
,p_query_column_id=>12
,p_column_alias=>'C007'
,p_column_display_sequence=>140
,p_column_heading=>'&P444_ABT5.'
,p_use_as_row_header=>'N'
,p_column_hit_highlight=>'X'
,p_column_alignment=>'CENTER'
,p_display_when_cond_type=>'EXPRESSION'
,p_display_when_condition=>':P444_CHK5!=0'
,p_display_when_condition2=>'PLSQL'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(126794922237999870)
,p_query_column_id=>13
,p_column_alias=>'C008'
,p_column_display_sequence=>150
,p_column_heading=>'&P444_ABT6.'
,p_use_as_row_header=>'N'
,p_column_hit_highlight=>'X'
,p_column_alignment=>'CENTER'
,p_display_when_cond_type=>'EXPRESSION'
,p_display_when_condition=>':P444_CHK6!=0'
,p_display_when_condition2=>'PLSQL'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(126795365439999870)
,p_query_column_id=>14
,p_column_alias=>'C009'
,p_column_display_sequence=>160
,p_column_heading=>'&P444_ABT7.'
,p_use_as_row_header=>'N'
,p_column_hit_highlight=>'X'
,p_column_alignment=>'CENTER'
,p_display_when_cond_type=>'EXPRESSION'
,p_display_when_condition=>':P444_CHK7!=0'
,p_display_when_condition2=>'PLSQL'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(126795713406999870)
,p_query_column_id=>15
,p_column_alias=>'C010'
,p_column_display_sequence=>170
,p_column_heading=>'&P444_ABT8.'
,p_use_as_row_header=>'N'
,p_column_hit_highlight=>'X'
,p_column_alignment=>'CENTER'
,p_display_when_cond_type=>'EXPRESSION'
,p_display_when_condition=>':P444_CHK8!=0'
,p_display_when_condition2=>'PLSQL'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'N'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(253176825167651528)
,p_name=>unistr('CRITERIOS DE DISTRIBUCI\00D3N GV')
,p_title=>unistr('CRITERIOS DE DISTRIBUCI\00D3N GV<button type=''button'' id=''btnRegCriterioDist'' onclick=''f_setpopup(0,2);'' class=''t-Button t-Button--noLabel t-Button--icon js-ignoreChange''><span class=''fa fa-tasks-alt fam-information fam-is-info''></span></button></label>')
,p_region_name=>'regionDistribucionGV'
,p_parent_plug_id=>wwv_flow_imp.id(253178698897651547)
,p_template=>wwv_flow_imp.id(38289867500120143)
,p_display_sequence=>40
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_component_template_options=>'#DEFAULT#:t-Report--stretch:t-Report--altRowsDefault:t-Report--rowHighlight:t-Report--inline'
,p_display_point=>'SUB_REGIONS'
,p_item_display_point=>'BELOW'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT * FROM ',
'(',
'    SELECT',
'    SEQ_ID,C001,N001,N002,N003,N004,C002,C003,C004,C005,C006,C007,C008,C009,C010',
'    FROM APEX_COLLECTIONS ',
'    WHERE COLLECTION_NAME =''COLECCION_CRITERIOSDIST''',
'    and C001=''GV''',
'ORDER BY C001,N004,C002',
'',
')'))
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(37830327650106535)
,p_query_num_rows=>1500
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_break_cols=>'1'
,p_break_type_flag=>'REPEAT_HEADINGS_ON_BREAK_1'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(126800585743999873)
,p_query_column_id=>1
,p_column_alias=>'SEQ_ID'
,p_column_display_sequence=>160
,p_use_as_row_header=>'N'
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(126796504758999871)
,p_query_column_id=>2
,p_column_alias=>'C001'
,p_column_display_sequence=>10
,p_column_heading=>'FLAG'
,p_use_as_row_header=>'N'
,p_column_alignment=>'CENTER'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(126797754279999871)
,p_query_column_id=>3
,p_column_alias=>'N001'
,p_column_display_sequence=>40
,p_column_heading=>'Estado'
,p_use_as_row_header=>'N'
,p_column_alignment=>'CENTER'
,p_display_as=>'TEXT_FROM_LOV'
,p_named_lov=>wwv_flow_imp.id(103334473958064327)
,p_derived_column=>'N'
,p_include_in_export=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(126798178493999872)
,p_query_column_id=>4
,p_column_alias=>'N002'
,p_column_display_sequence=>50
,p_column_heading=>'Ingresos'
,p_use_as_row_header=>'N'
,p_column_alignment=>'CENTER'
,p_display_as=>'TEXT_FROM_LOV'
,p_named_lov=>wwv_flow_imp.id(105205170216064959)
,p_derived_column=>'N'
,p_include_in_export=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(126798505543999872)
,p_query_column_id=>5
,p_column_alias=>'N003'
,p_column_display_sequence=>60
,p_column_heading=>'Gastos'
,p_use_as_row_header=>'N'
,p_column_alignment=>'CENTER'
,p_display_as=>'TEXT_FROM_LOV'
,p_named_lov=>wwv_flow_imp.id(105205170216064959)
,p_derived_column=>'N'
,p_include_in_export=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(126796973467999871)
,p_query_column_id=>6
,p_column_alias=>'N004'
,p_column_display_sequence=>20
,p_column_heading=>'Orden'
,p_use_as_row_header=>'N'
,p_column_alignment=>'CENTER'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(126797363408999871)
,p_query_column_id=>7
,p_column_alias=>'C002'
,p_column_display_sequence=>30
,p_column_heading=>'Referencia'
,p_use_as_row_header=>'N'
,p_column_alignment=>'CENTER'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(126798918035999872)
,p_query_column_id=>8
,p_column_alias=>'C003'
,p_column_display_sequence=>70
,p_column_heading=>'&P444_ABT1.'
,p_use_as_row_header=>'N'
,p_column_hit_highlight=>'X'
,p_column_alignment=>'CENTER'
,p_display_when_cond_type=>'EXPRESSION'
,p_display_when_condition=>':P444_CHK1!=0'
,p_display_when_condition2=>'PLSQL'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(126799391503999872)
,p_query_column_id=>9
,p_column_alias=>'C004'
,p_column_display_sequence=>80
,p_column_heading=>'&P444_ABT2.'
,p_use_as_row_header=>'N'
,p_column_hit_highlight=>'X'
,p_column_alignment=>'CENTER'
,p_display_when_cond_type=>'EXPRESSION'
,p_display_when_condition=>':P444_CHK2!=0'
,p_display_when_condition2=>'PLSQL'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(126799704956999872)
,p_query_column_id=>10
,p_column_alias=>'C005'
,p_column_display_sequence=>90
,p_column_heading=>'&P444_ABT3.'
,p_use_as_row_header=>'N'
,p_column_hit_highlight=>'X'
,p_column_alignment=>'CENTER'
,p_display_when_cond_type=>'EXPRESSION'
,p_display_when_condition=>':P444_CHK3!=0'
,p_display_when_condition2=>'PLSQL'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(126800146307999873)
,p_query_column_id=>11
,p_column_alias=>'C006'
,p_column_display_sequence=>100
,p_column_heading=>'&P444_ABT4.'
,p_use_as_row_header=>'N'
,p_column_hit_highlight=>'X'
,p_column_alignment=>'CENTER'
,p_display_when_cond_type=>'EXPRESSION'
,p_display_when_condition=>':P444_CHK4!=0'
,p_display_when_condition2=>'PLSQL'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(126800911024999873)
,p_query_column_id=>12
,p_column_alias=>'C007'
,p_column_display_sequence=>120
,p_column_heading=>'&P444_ABT5.'
,p_use_as_row_header=>'N'
,p_column_hit_highlight=>'X'
,p_column_alignment=>'CENTER'
,p_display_when_cond_type=>'EXPRESSION'
,p_display_when_condition=>':P444_CHK5!=0'
,p_display_when_condition2=>'PLSQL'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(126801305512999873)
,p_query_column_id=>13
,p_column_alias=>'C008'
,p_column_display_sequence=>130
,p_column_heading=>'&P444_ABT6.'
,p_use_as_row_header=>'N'
,p_column_hit_highlight=>'X'
,p_column_alignment=>'CENTER'
,p_display_when_cond_type=>'EXPRESSION'
,p_display_when_condition=>':P444_CHK6!=0'
,p_display_when_condition2=>'PLSQL'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(126801720080999874)
,p_query_column_id=>14
,p_column_alias=>'C009'
,p_column_display_sequence=>140
,p_column_heading=>'&P444_ABT7.'
,p_use_as_row_header=>'N'
,p_column_hit_highlight=>'X'
,p_column_alignment=>'CENTER'
,p_display_when_cond_type=>'EXPRESSION'
,p_display_when_condition=>':P444_CHK7!=0'
,p_display_when_condition2=>'PLSQL'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(126802122064999874)
,p_query_column_id=>15
,p_column_alias=>'C010'
,p_column_display_sequence=>150
,p_column_heading=>'&P444_ABT8.'
,p_use_as_row_header=>'N'
,p_column_hit_highlight=>'X'
,p_column_alignment=>'CENTER'
,p_display_when_cond_type=>'EXPRESSION'
,p_display_when_condition=>':P444_CHK8!=0'
,p_display_when_condition2=>'PLSQL'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'N'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(253179117560651551)
,p_plug_name=>'botones'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(38290276266120143)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_03'
,p_location=>null
,p_ai_enabled=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(126788960473999864)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(126487655289870423)
,p_button_name=>'DELETE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860056812106557)
,p_button_image_alt=>'Delete'
,p_button_execute_validations=>'N'
,p_confirm_message=>unistr('\00BFEsta seguro de acci\00F3n de eliminaci\00F3n??')
,p_confirm_style=>'danger'
,p_button_condition=>'P444_ID'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_icon_css_classes=>'fa-trash-o'
,p_database_action=>'DELETE'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(126788197378999863)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(126487655289870423)
,p_button_name=>'SAVE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860056812106557)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Apply Changes'
,p_button_condition=>'P444_ID'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_icon_css_classes=>'fa-save'
,p_database_action=>'UPDATE'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(126788547203999864)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(126487655289870423)
,p_button_name=>'CREATE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860056812106557)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Create'
,p_button_condition=>'P444_ID'
,p_button_condition_type=>'ITEM_IS_NULL'
,p_icon_css_classes=>'fa-save-as'
,p_database_action=>'INSERT'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(126775367319999826)
,p_button_sequence=>100
,p_button_plug_id=>wwv_flow_imp.id(249848962489026442)
,p_button_name=>'Criterios'
,p_button_static_id=>'btnCriteriosDist'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860181880106559)
,p_button_image_alt=>'Criterios'
,p_button_position=>'COPY'
,p_show_processing=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(127437958032147917)
,p_button_sequence=>120
,p_button_plug_id=>wwv_flow_imp.id(249848962489026442)
,p_button_name=>'Dimensiones'
,p_button_static_id=>'btnDimensionDist'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860181880106559)
,p_button_image_alt=>'Dimensiones'
,p_button_position=>'COPY'
,p_show_processing=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(126802991956999874)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(253179117560651551)
,p_button_name=>'Cerrar'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860181880106559)
,p_button_image_alt=>'Cerrar'
,p_button_position=>'NEXT'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(128917292202329336)
,p_branch_name=>'Go To Page 445'
,p_branch_action=>'f?p=&APP_ID.:445:&SESSION.::&DEBUG.:RR,445::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'BEFORE_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_imp.id(126775367319999826)
,p_branch_sequence=>20
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(128917397415329337)
,p_branch_name=>'Go To Page 448'
,p_branch_action=>'f?p=&APP_ID.:448:&SESSION.::&DEBUG.:RR,448::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'BEFORE_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_imp.id(127437958032147917)
,p_branch_sequence=>30
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(128917072976329334)
,p_name=>'P444_DIMENSIONES_1'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_imp.id(252348354147293367)
,p_prompt=>'Dimensiones <button type=''button'' id=''btnRegCriterioDist'' onclick=''f_setpopup(1,1);'' class=''t-Button t-Button--noLabel t-Button--icon js-ignoreChange''><span class=''fa fa-tasks-alt fam-information fam-is-info''></span></button></label>'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_display_when=>'P444_ID'
,p_display_when_type=>'ITEM_IS_NOT_NULL'
,p_field_template=>wwv_flow_imp.id(37859556976106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_04=>'N'
,p_attribute_05=>'HTML'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(128917519626329339)
,p_name=>'P444_ABT1'
,p_item_sequence=>120
,p_item_plug_id=>wwv_flow_imp.id(249848962489026442)
,p_prompt=>'Abt1'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(128917607325329340)
,p_name=>'P444_ABT2'
,p_item_sequence=>140
,p_item_plug_id=>wwv_flow_imp.id(249848962489026442)
,p_prompt=>'Abt2'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(128917720076329341)
,p_name=>'P444_ABT3'
,p_item_sequence=>160
,p_item_plug_id=>wwv_flow_imp.id(249848962489026442)
,p_prompt=>'Abt3'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(128917893001329342)
,p_name=>'P444_ABT4'
,p_item_sequence=>180
,p_item_plug_id=>wwv_flow_imp.id(249848962489026442)
,p_prompt=>'Abt4'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(128917932787329343)
,p_name=>'P444_ABT5'
,p_item_sequence=>200
,p_item_plug_id=>wwv_flow_imp.id(249848962489026442)
,p_prompt=>'Abt5'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(128918028788329344)
,p_name=>'P444_ABT6'
,p_item_sequence=>220
,p_item_plug_id=>wwv_flow_imp.id(249848962489026442)
,p_prompt=>'Abt6'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(128918109417329345)
,p_name=>'P444_ABT7'
,p_item_sequence=>240
,p_item_plug_id=>wwv_flow_imp.id(249848962489026442)
,p_prompt=>'Abt7'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(128918210438329346)
,p_name=>'P444_ABT8'
,p_item_sequence=>260
,p_item_plug_id=>wwv_flow_imp.id(249848962489026442)
,p_prompt=>'Abt8'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(129164929908853412)
,p_name=>'P444_NUMOBJCTS'
,p_item_sequence=>280
,p_item_plug_id=>wwv_flow_imp.id(249848962489026442)
,p_prompt=>'Numobjcts'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(129165489734853417)
,p_name=>'P444_CHK1'
,p_item_sequence=>130
,p_item_plug_id=>wwv_flow_imp.id(249848962489026442)
,p_prompt=>'Chk1'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(129165596919853418)
,p_name=>'P444_CHK2'
,p_item_sequence=>150
,p_item_plug_id=>wwv_flow_imp.id(249848962489026442)
,p_prompt=>'Chk2'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(129165690336853419)
,p_name=>'P444_CHK3'
,p_item_sequence=>170
,p_item_plug_id=>wwv_flow_imp.id(249848962489026442)
,p_prompt=>'Chk3'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(129165779502853420)
,p_name=>'P444_CHK4'
,p_item_sequence=>190
,p_item_plug_id=>wwv_flow_imp.id(249848962489026442)
,p_prompt=>'Chk4'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(129165865057853421)
,p_name=>'P444_CHK5'
,p_item_sequence=>210
,p_item_plug_id=>wwv_flow_imp.id(249848962489026442)
,p_prompt=>'Chk5'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(129165910884853422)
,p_name=>'P444_CHK6'
,p_item_sequence=>230
,p_item_plug_id=>wwv_flow_imp.id(249848962489026442)
,p_prompt=>'Chk6'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(129166058745853423)
,p_name=>'P444_CHK7'
,p_item_sequence=>250
,p_item_plug_id=>wwv_flow_imp.id(249848962489026442)
,p_prompt=>'Chk7'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(129166159137853424)
,p_name=>'P444_CHK8'
,p_item_sequence=>270
,p_item_plug_id=>wwv_flow_imp.id(249848962489026442)
,p_prompt=>'Chk8'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(129168207551853445)
,p_name=>'P444_CAMBIOESTADO'
,p_item_sequence=>290
,p_item_plug_id=>wwv_flow_imp.id(249848962489026442)
,p_prompt=>'Cambioestado'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(249850832363026475)
,p_name=>'P444_MENSAJE'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(249848962489026442)
,p_prompt=>'Mensaje'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(249856489092026498)
,p_name=>'P444_VERSION1'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(252348354147293367)
,p_prompt=>unistr('Versi\00F3n')
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(252349686657293393)
,p_name=>'P444_ID'
,p_source_data_type=>'NUMBER'
,p_is_primary_key=>true
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(249848962489026442)
,p_item_source_plug_id=>wwv_flow_imp.id(252348354147293367)
,p_prompt=>'Id'
,p_source=>'ID'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_protection_level=>'S'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(252350058685293402)
,p_name=>'P444_USERCREA'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(249848962489026442)
,p_item_source_plug_id=>wwv_flow_imp.id(252348354147293367)
,p_prompt=>'Usercrea'
,p_source=>'USERCREA'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>32
,p_cMaxlength=>25
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'NONE'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(252350495252293403)
,p_name=>'P444_FECHCREA'
,p_source_data_type=>'TIMESTAMP'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(249848962489026442)
,p_item_source_plug_id=>wwv_flow_imp.id(252348354147293367)
,p_prompt=>'Fechcrea'
,p_source=>'FECHCREA'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DATE_PICKER_APEX'
,p_cSize=>32
,p_cMaxlength=>255
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'POPUP'
,p_attribute_03=>'NONE'
,p_attribute_06=>'NONE'
,p_attribute_09=>'N'
,p_attribute_11=>'Y'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(252351205133293417)
,p_name=>'P444_USERMODI'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(249848962489026442)
,p_item_source_plug_id=>wwv_flow_imp.id(252348354147293367)
,p_prompt=>'Usermodi'
,p_source=>'USERMODI'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>32
,p_cMaxlength=>25
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'NONE'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(252351550996293417)
,p_name=>'P444_FECHMODI'
,p_source_data_type=>'TIMESTAMP'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(249848962489026442)
,p_item_source_plug_id=>wwv_flow_imp.id(252348354147293367)
,p_prompt=>'Fechmodi'
,p_source=>'FECHMODI'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DATE_PICKER_APEX'
,p_cSize=>32
,p_cMaxlength=>255
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'POPUP'
,p_attribute_03=>'NONE'
,p_attribute_06=>'NONE'
,p_attribute_09=>'N'
,p_attribute_11=>'Y'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(252353213753293418)
,p_name=>'P444_VERSION'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(249848962489026442)
,p_item_source_plug_id=>wwv_flow_imp.id(252348354147293367)
,p_prompt=>'Version BD'
,p_source=>'VERSION'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(252353568557293418)
,p_name=>'P444_ESTADO'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(252348354147293367)
,p_item_source_plug_id=>wwv_flow_imp.id(252348354147293367)
,p_prompt=>'Estado'
,p_source=>'ESTADO'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_YES_NO'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'Activo'
,p_attribute_03=>'Activo'
,p_attribute_04=>'Inactivo'
,p_attribute_05=>'Inactivo'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(252354754380293419)
,p_name=>'P444_CRITERIO'
,p_data_type=>'CLOB'
,p_source_data_type=>'CLOB'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(249848962489026442)
,p_item_source_plug_id=>wwv_flow_imp.id(252348354147293367)
,p_prompt=>'Criterio'
,p_source=>'CRITERIO'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>60
,p_cHeight=>4
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(252358251326293442)
,p_name=>'P444_IDCFG'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(252348354147293367)
,p_item_source_plug_id=>wwv_flow_imp.id(252348354147293367)
,p_prompt=>unistr('Configuraci\00F3n')
,p_source=>'IDCFG'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_named_lov=>'LOV_FINZ_PGI_CONFIGURACION'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'WITH ',
'CPN AS (SELECT DESCRIPCION CPNDESCRIPCION,ID_TABLA CPNID FROM t_corp_udc where id_cabecera=''COMP_CGZCM'' and ID_TABLA!=''00000'' /*and ACTIVO=''1''*/),',
'TOB AS (SELECT DESCRIPCION TOBDESCRIPCION,ID_TABLA TOBID FROM T_CORP_UDC WHERE ID_CABECERA=''FINZ_GT02'' AND ID_TABLA  in(''001'')  AND ACTIVO=''1''  ),',
'SQM AS (SELECT DESCRIPCION SQMDESCRIPCION,ID_TABLA SQMID FROM T_CORP_UDC WHERE ID_CABECERA=''FINZ_GT04'' AND ID_TABLA!=''000''  AND ACTIVO=''1''),',
'erp as (SELECT DESCRIPCION ERPDESCRIPCION,ID_TABLA ERPID FROM T_CORP_UDC WHERE ID_CABECERA=''FINZ_GT03'' AND ID_TABLA!=''000'' AND ACTIVO=''1''  order by to_number(ID_TABLA)',
')',
'select ID,',
'    CPNDESCRIPCION COMPANIA,',
'    DECODE(UPPER(TABLAPROCESO),''T_FINZ_DISTRIBUCIONASC'',''ASIENTOS CONTABLES'',''T_FINZ_DISTRIBUCIONVTA'',''VENTAS'') TABLAPROCESO,  ',
'    DESCRIPCION,',
'    ESTADO,',
'    ERPDESCRIPCION ERP,',
'    SQMDESCRIPCION ESQUEMA,',
'    TOBDESCRIPCION TIPOOBJETO,',
'    OBJETO    ',
'from T_FINZ_DISTRIBUCIONCFG',
'LEFT JOIN TOB ON TIPOOBJETO=TOBID',
'LEFT JOIN SQM ON ESQUEMA=SQMID',
'LEFT JOIN CPN ON COMPANIA=CPNID',
'LEFT JOIN ERP ON ERP=ERPID',
'WHERE (COMPANIA= :G_COMPANIADIST)',
'order by CPNDESCRIPCION,DESCRIPCION'))
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'Y'
,p_attribute_02=>'LOV'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(252358600144293442)
,p_name=>'P444_IDREF'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(249848962489026442)
,p_item_source_plug_id=>wwv_flow_imp.id(252348354147293367)
,p_prompt=>'Referencia'
,p_source=>'IDREF'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_named_lov=>'LOV_FINZ_PGI_METODOSDISTRIBUCION'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'with cfg as (',
'    SELECT ID, case TABLAPROCESO ',
'when ''t_finz_distribucionasc'' then ''ASIENTOS CONTABLES'' ',
'when ''t_finz_distribucionvta'' then ''VENTAS'' ',
'end proceso, DESCRIPCION, ESTADO FROM T_FINZ_DISTRIBUCIONcfg where UPPER(ESTADO)=''ACTIVO''',
'order by proceso desc',
')--SELECT * FROM cfg  ;',
unistr(',METS AS (SELECT a.ID id,b.DESCRIPCION,b.PROCESO,a.IDREF REFERENCIA,''V''||TRIM(to_char(a.VERSION,''00000'')) VERSION, a.TIPO,a.DIMENSIONES , CASE WHEN a.criterio IS NULL THEN ''No'' ELSE ''S\00ED'' END CRITERIO'),
', b.PROCESO ||''/''|| b.DESCRIPCION||''/''||''V''||TRIM(to_char(a.VERSION,''00000''))||''(''||UPPER(a.ESTADO)||'')'' RETDESCRIPCION',
'FROM t_finz_distribucionmtd a ',
'left join cfg b on a.idcfg=b.id',
'where (a.id !=:G_VALORMTD or :G_VALORMTD is null) and a.IDCFG=:G_VALORCFG  ',
' order by version',
' )',
' SELECT a.ID, a.DESCRIPCION, a.PROCESO, B.RETDESCRIPCION REFERENCIA, a.VERSION, a.TIPO, a.DIMENSIONES, a.CRITERIO, a.RETDESCRIPCION',
' FROM METS A LEFT JOIN METS B ON A.REFERENCIA = B.ID'))
,p_lov_display_null=>'YES'
,p_cSize=>32
,p_cMaxlength=>255
,p_field_template=>wwv_flow_imp.id(37859556976106557)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'POPUP'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_04=>'N'
,p_attribute_05=>'Y'
,p_attribute_06=>'0'
,p_updated_on=>wwv_flow_imp.dz('20260223163403Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(252359771224293443)
,p_name=>'P444_TIPO'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(249848962489026442)
,p_item_source_plug_id=>wwv_flow_imp.id(252348354147293367)
,p_prompt=>'Tipo'
,p_source=>'TIPO'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'LOV_FINZ_PGI_TIPOMETODODISTRIBUCION'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ID_TABLA||'' - ''||DESCRIPCION DESCRIPCION,ID_TABLA ',
'FROM DATA.T_CORP_UDC ',
'WHERE ID_CABECERA = ''FINZ_PGI01'' ',
'AND ACTIVO =''1'' ',
'ORDER BY TO_NUMBER(NVL(VALOR3,0))'))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_updated_on=>wwv_flow_imp.dz('20260223163314Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(252360195440293443)
,p_name=>'P444_DIMENSIONES'
,p_source_data_type=>'CLOB'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(249848962489026442)
,p_item_source_plug_id=>wwv_flow_imp.id(252348354147293367)
,p_prompt=>'Dimensiones'
,p_source=>'DIMENSIONES'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_cMaxlength=>32767
,p_field_template=>wwv_flow_imp.id(37859556976106557)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large:t-Form-fieldContainer--radioButtonGroup'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(253179373824651568)
,p_name=>'P444_TIPOCRITERIODIS'
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_imp.id(249848962489026442)
,p_prompt=>'Tipocriteriodis'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(126805684803999880)
,p_validation_name=>'tipo no vacio'
,p_validation_sequence=>50
,p_validation=>'P444_TIPO'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>'Se requiere un valor para #LABEL#.'
,p_associated_item=>wwv_flow_imp.id(252359771224293443)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(126806013422999880)
,p_validation_name=>'Estado no vacio'
,p_validation_sequence=>60
,p_validation=>'P444_ESTADO'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>'Se requiere un valor para #LABEL#.'
,p_associated_item=>wwv_flow_imp.id(252353568557293418)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(126806465119999880)
,p_validation_name=>'Referencia no vacio'
,p_validation_sequence=>70
,p_validation=>'P444_IDREF'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>'Se requiere un valor para #LABEL#.'
,p_validation_condition_type=>'NEVER'
,p_associated_item=>wwv_flow_imp.id(252358600144293442)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(126806818895999880)
,p_validation_name=>'Dimensiones no vacio'
,p_validation_sequence=>80
,p_validation=>'P444_DIMENSIONES'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>'Se requiere un valor para #LABEL#.'
,p_when_button_pressed=>wwv_flow_imp.id(126788197378999863)
,p_associated_item=>wwv_flow_imp.id(252360195440293443)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(126807278456999881)
,p_validation_name=>'Criterio no vacio'
,p_validation_sequence=>90
,p_validation=>'P444_CRITERIO'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>unistr('No se ha definido ning\00FAn criterio. Ingrese al menos uno.')
,p_when_button_pressed=>wwv_flow_imp.id(126788197378999863)
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(126809153125999882)
,p_name=>'Cerrar Dialog'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(126802991956999874)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(126809666186999883)
,p_event_id=>wwv_flow_imp.id(126809153125999882)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CLOSE'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(126810957103999884)
,p_name=>'cambia tipocriterio'
,p_event_sequence=>40
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P444_TIPOCRITERIODIS'
,p_condition_element=>'P444_TIPOCRITERIODIS'
,p_triggering_condition_type=>'NOT_NULL'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
,p_updated_on=>wwv_flow_imp.dz('20260220144549Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(126811909631999884)
,p_event_id=>wwv_flow_imp.id(126810957103999884)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>':G_VALORTCRT:=:P444_TIPOCRITERIODIS;'
,p_attribute_02=>'P444_TIPOCRITERIODIS'
,p_attribute_03=>'G_VALORTCRT'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20260220144119Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(126811485060999884)
,p_event_id=>wwv_flow_imp.id(126810957103999884)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'$(''#btnCriteriosDist'').trigger("click");'
,p_updated_on=>wwv_flow_imp.dz('20260220144549Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(126812356914999885)
,p_name=>'es Activo?'
,p_event_sequence=>50
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P444_ESTADO'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(129168018765853443)
,p_event_id=>wwv_flow_imp.id(126812356914999885)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_name=>'CAMBIO ESTADO'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>':P444_CAMBIOESTADO:=0;'
,p_attribute_03=>'P444_CAMBIOESTADO'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(126812877748999885)
,p_event_id=>wwv_flow_imp.id(126812356914999885)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_CONFIRM'
,p_attribute_01=>unistr('Est\00E9 seguro que el estado del m\00E9todo en pantalla es correcto, solo puede existir un solo metodo activo')
,p_attribute_02=>'Cambio de Estado'
,p_client_condition_type=>'JAVASCRIPT_EXPRESSION'
,p_client_condition_expression=>'$v("P444_ESTADO").toUpperCase()==="ACTIVO"'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(129168105858853444)
,p_event_id=>wwv_flow_imp.id(126812356914999885)
,p_event_result=>'TRUE'
,p_action_sequence=>50
,p_execute_on_page_init=>'N'
,p_name=>'CAMBIO ESTADO'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>':P444_CAMBIOESTADO:=1;'
,p_attribute_03=>'P444_CAMBIOESTADO'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(129167791248853440)
,p_name=>'loadpage'
,p_event_sequence=>60
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'ready'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(129167852796853441)
,p_event_id=>wwv_flow_imp.id(129167791248853440)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_name=>'vn'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'setTimeout(function(){',
'',
unistr('  // --- tu c\00F3digo aqu\00ED ---'),
'  (function(){',
'    var regionStaticId = "regionDistribucionVN";',
'    var map = {',
'      P444_CHK1: "C003",',
'      P444_CHK2: "C004",',
'      P444_CHK3: "C005",',
'      P444_CHK4: "C006",',
'      P444_CHK5: "C007",',
'      P444_CHK6: "C008",',
'      P444_CHK7: "C009",',
'      P444_CHK8: "C010"',
'    };',
'',
'    var $region = $("#"+regionStaticId);',
'    if (!$region.length) {',
unistr('      console.log("No se encontr\00F3 la regi\00F3n", regionStaticId);'),
'      return;',
'    }',
'',
'    Object.entries(map).forEach(function(entry){',
'      var itemId = entry[0];',
'      var colId  = entry[1];',
'',
'      var val  = $v(itemId);',
'      var activo = (val !== "0" && val !== "");',
'',
'      var $th = $region.find(''th#''+colId);',
'      var $td = $region.find(''td[headers="''+colId+''"]'');',
'',
'      if (activo) {',
'        $th.css(''background-color'', ''#ffcccc'');',
'        $td.css(''background-color'', ''#ffcccc'');',
'        //$th.show();',
'        //$td.show();',
'      } else {',
'        $th.css(''background-color'', '''');',
'        $td.css(''background-color'', '''');',
'        //$th.hide();',
'        //$td.hide();',
'      }',
'    });',
'  })();',
'  // --- fin ---',
'',
'}, 150);   // retardo de 150ms',
''))
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(126787442469999863)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_region_id=>wwv_flow_imp.id(252348354147293367)
,p_process_type=>'NATIVE_FORM_DML'
,p_process_name=>'Process form PYG INDUSTRIALES - CRUD - METODOS DISTRIBUCION - CFG'
,p_attribute_01=>'REGION_SOURCE'
,p_attribute_05=>'Y'
,p_attribute_06=>'Y'
,p_attribute_08=>'Y'
,p_process_error_message=>unistr('Ocurri\00F3 un error al procesar la informaci\00F3n.')
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_success_message=>'Los datos se han actualizado correctamente.'
,p_internal_uid=>126787442469999863
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(126808745910999881)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Process form PYG INDUSTRIALES - CRUD - METODOS DISTRIBUCION - CFG_1'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'if (upper(:P444_CAMBIOESTADO)=''1'')then',
'    update t_finz_distribucionmtd set ESTADO=''Inactivo'' where id !=:P444_ID AND IDCFG=:G_VALORCFG;',
'end if;',
'',
':G_VALORMTD:=:P444_ID;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>126808745910999881
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(126808323402999881)
,p_process_sequence=>30
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_CLOSE_WINDOW'
,p_process_name=>'Close Dialog'
,p_attribute_02=>'Y'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>'DELETE'
,p_process_when_type=>'REQUEST_IN_CONDITION'
,p_internal_uid=>126808323402999881
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(126807561516999881)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'SetupProcess'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
':P444_ID:=NVL(:G_VALORMTD,:P444_ID);',
':P444_IDCFG:=NVL(:G_VALORCFG,:P444_IDCFG);'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>126807561516999881
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(126787029042999861)
,p_process_sequence=>20
,p_process_point=>'BEFORE_HEADER'
,p_region_id=>wwv_flow_imp.id(252348354147293367)
,p_process_type=>'NATIVE_FORM_INIT'
,p_process_name=>'Initialize form PYG INDUSTRIALES - CRUD - METODOS DISTRIBUCION - CFG'
,p_internal_uid=>126787029042999861
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(126807919234999881)
,p_process_sequence=>30
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Setup Interface'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE V_VERSION NUMBER;',
'BEGIN',
'    if (:G_VALORMTD is null)then',
'        select nvl(max(VERSION) ,0)+1 into V_VERSION FROM t_finz_distribucionmtd where IDCFG=:G_VALORCFG;',
'        :P444_VERSION:=V_VERSION;',
'    end if;',
'END;',
':P444_VERSION1:=''V''||trim(to_char(:P444_VERSION,''00000''));',
':G_CRITERIOSDIST:=:P444_CRITERIO;',
':G_DIMENSIONDIST:=:P444_DIMENSIONES;',
'',
'IF NOT APEX_COLLECTION.COLLECTION_EXISTS(''COLECCION_CRITERIOSDIST'') THEN APEX_COLLECTION.CREATE_COLLECTION  (''COLECCION_CRITERIOSDIST''); END IF;',
'IF     APEX_COLLECTION.COLLECTION_EXISTS(''COLECCION_CRITERIOSDIST'') THEN APEX_COLLECTION.TRUNCATE_COLLECTION(''COLECCION_CRITERIOSDIST''); END IF;',
'',
'',
'DECLARE ',
'    v_dimensiones varchar2(3999);',
'    V_GPID  NUMBER:=1;',
'    v_numobjcst number:=0;',
'    l_tipos  VARCHAR2(50) := ''VN,GV'';',
'    l_tipo  VARCHAR2(50);',
'    l_json  CLOB;',
'BEGIN',
'    v_dimensiones:=pk_finz_distribucion.f_trae_dimensiones2varchar(:G_COMPANIADIST, :G_DIMENSIONDIST,'','');',
'    v_numobjcst:=to_number(regexp_substr(v_dimensiones,''\|(\d+)'',1,1,null,1)) ;',
'    v_dimensiones:=regexp_replace(regexp_replace(v_dimensiones,''\|\d+$'',''''),''((<br\s*/?>)|,)+$'','''') ;',
'        ',
'   BEGIN',
'    FOR     DIMEN IN (SELECT * FROM TABLE( PK_FINZ_DISTRIBUCION.f_auxcfg_tab(:G_COMPANIADIST)))',
'    LOOP',
'        IF (DIMEN.ID=1)THEN :P444_CHK1:=DIMEN.CHK;:P444_ABT1:=DIMEN.DESCRIP;DBMS_OUTPUT.PUT_LINE(''P444_CHK1:''||:P444_CHK1||'',P444_ABT1:''||:P444_ABT1||CHR(10)||RPAD(''*'',180,''*''));END IF;',
'        IF (DIMEN.ID=2)THEN :P444_CHK2:=DIMEN.CHK;:P444_ABT2:=DIMEN.DESCRIP;DBMS_OUTPUT.PUT_LINE(''P444_CHK2:''||:P444_CHK2||'',P444_ABT2:''||:P444_ABT2||CHR(10)||RPAD(''*'',180,''*''));END IF;',
'        IF (DIMEN.ID=3)THEN :P444_CHK3:=DIMEN.CHK;:P444_ABT3:=DIMEN.DESCRIP;DBMS_OUTPUT.PUT_LINE(''P444_CHK3:''||:P444_CHK3||'',P444_ABT3:''||:P444_ABT3||CHR(10)||RPAD(''*'',180,''*''));END IF;',
'        IF (DIMEN.ID=4)THEN :P444_CHK4:=DIMEN.CHK;:P444_ABT4:=DIMEN.DESCRIP;DBMS_OUTPUT.PUT_LINE(''P444_CHK4:''||:P444_CHK4||'',P444_ABT4:''||:P444_ABT4||CHR(10)||RPAD(''*'',180,''*''));END IF;',
'        IF (DIMEN.ID=5)THEN :P444_CHK5:=DIMEN.CHK;:P444_ABT5:=DIMEN.DESCRIP;DBMS_OUTPUT.PUT_LINE(''P444_CHK5:''||:P444_CHK5||'',P444_ABT5:''||:P444_ABT5||CHR(10)||RPAD(''*'',180,''*''));END IF;',
'        IF (DIMEN.ID=6)THEN :P444_CHK6:=DIMEN.CHK;:P444_ABT6:=DIMEN.DESCRIP;DBMS_OUTPUT.PUT_LINE(''P444_CHK6:''||:P444_CHK6||'',P444_ABT6:''||:P444_ABT6||CHR(10)||RPAD(''*'',180,''*''));END IF;',
'        IF (DIMEN.ID=7)THEN :P444_CHK7:=DIMEN.CHK;:P444_ABT7:=DIMEN.DESCRIP;DBMS_OUTPUT.PUT_LINE(''P444_CHK7:''||:P444_CHK7||'',P444_ABT7:''||:P444_ABT7||CHR(10)||RPAD(''*'',180,''*''));END IF;',
'        IF (DIMEN.ID=8)THEN :P444_CHK8:=DIMEN.CHK;:P444_ABT8:=DIMEN.DESCRIP;DBMS_OUTPUT.PUT_LINE(''P444_CHK8:''||:P444_CHK8||'',P444_ABT8:''||:P444_ABT8||CHR(10)||RPAD(''*'',180,''*''));END IF;',
'        ',
'    END LOOP;',
'END;',
'',
'',
'',
'    --v_numobjcst :=case when v_numobjcst >0 then 1 else 0 end ;',
'    :P444_DIMENSIONES_1:=v_dimensiones;',
'    :P444_NUMOBJCTS:=v_numobjcst;',
'',
'    if (v_numobjcst>0) then',
'        IF (:G_CRITERIOSDIST IS NULL)THEN',
'            FOR i IN 1..(v_numobjcst+1) LOOP',
'                FOR BAND IN (SELECT ITEM BANDERA FROM TABLE(DATA.pk_commons.f_dividirtexto(''VN,GV'','','')))',
'                LOOP ',
'                    APEX_COLLECTION.ADD_MEMBER(',
'                    p_collection_name =>''COLECCION_CRITERIOSDIST''',
'                        ,p_c001 => BAND.BANDERA ',
'                        ,p_N001 => 1    ,p_N002 => 1',
'                        ,p_N003 => 1    ,p_N004 => i',
'                        ,p_c002 => CHR( i+64 ) ',
'                        ,p_c003 => CASE WHEN i<=v_numobjcst then ''X'' else ''0''end    ,p_c004 => CASE WHEN i<=v_numobjcst then ''X'' else ''0'' end',
'                        ,p_c005 => CASE WHEN i<=v_numobjcst then ''X'' else ''0''end    ,p_c006 => CASE WHEN i<=v_numobjcst then ''X'' else ''0'' end',
'                        ,p_c007 => CASE WHEN i<=v_numobjcst then ''X'' else ''0''end    ,p_c008 => CASE WHEN i<=v_numobjcst then ''X'' else ''0'' end',
'                        ,p_c009 => CASE WHEN i<=v_numobjcst then ''X'' else ''0''end    ,p_c010 => CASE WHEN i<=v_numobjcst then ''X'' else ''0'' end',
'                    );        ',
'                END LOOP;            ',
'            END LOOP;',
'            l_json:= pk_finz_distribucion.f_traer_jsonCriteriosDist(NULL,''COLECCION_CRITERIOSDIST'');',
'            --UPDATE  data.t_finz_distribucionmtd SET criterio= l_json WHERE ID=:G_VALORMTD;',
'            :G_CRITERIOSDIST:= l_json;',
'            :P444_CRITERIO:=l_json;',
'        ELSE',
'            FOR coltab IN ( ',
'                SELECT  jt.tipo,jt.id,jt.bandera,jt.referencia,jt.estado,jt.flag,jt.ingresos,jt.gastos,jt.orden,jt.ABT1,jt.ABT2,jt.ABT3,jt.ABT4,jt.ABT5,jt.ABT6,jt.ABT7,jt.ABT8',
'                FROM dual, JSON_TABLE(',
'                    :G_CRITERIOSDIST,''$[*]''',
'                    COLUMNS (    tipo VARCHAR2(10) PATH ''$.TIPO'',NESTED PATH ''$.DETALLE[*]''',
'                        COLUMNS (',
'                            id          NUMBER        PATH ''$.ID'',          bandera     VARCHAR2(10)  PATH ''$.BANDERA'',',
'                            flag        VARCHAR2(10)  PATH ''$.FLAG'',        estado      NUMBER        PATH ''$.ESTADO'',',
'                            ingresos    NUMBER        PATH ''$.INGRESOS'',    gastos      NUMBER        PATH ''$.GASTOS'',',
'                            orden       NUMBER        PATH ''$.ORDEN'',       referencia  VARCHAR2(10)  PATH ''$.REFERENCIA'', ',
'                            ABT1        VARCHAR2(10)  PATH ''$.ABT1'',        ABT2        VARCHAR2(10)  PATH ''$.ABT2'',',
'                            ABT3        VARCHAR2(10)  PATH ''$.ABT3'',        ABT4        VARCHAR2(10)  PATH ''$.ABT4'',',
'                            ABT5        VARCHAR2(10)  PATH ''$.ABT5'',        ABT6        VARCHAR2(10)  PATH ''$.ABT6'',',
'                            ABT7        VARCHAR2(10)  PATH ''$.ABT7'',        ABT8        VARCHAR2(10)  PATH ''$.ABT8'',',
'                            TXT11       VARCHAR2(10)  PATH ''$.TXT11'',       TXT20       VARCHAR2(10)  PATH ''$.TXT20''',
'                        )',
'                    )',
'                ) jt',
'                ORDER BY ID',
'            )',
'            LOOP ',
'                APEX_COLLECTION.ADD_MEMBER(',
'                     p_collection_name =>''COLECCION_CRITERIOSDIST''',
'                    ,p_c001 => coltab.BANDERA',
'                    ,p_N001 => coltab.ESTADO    ,p_N002 => coltab.INGRESOS',
'                    ,p_N003 => coltab.GASTOS    ,p_N004 => coltab.ORDEN',
'                    ,p_c002 => coltab.REFERENCIA    ',
'                    ,p_c003 => coltab.ABT1  ,p_c004 => coltab.ABT2  ',
'                    ,p_c005 => coltab.ABT3  ,p_c006 => coltab.ABT4  ',
'                    ,p_c007 => coltab.ABT5  ,p_c008 => coltab.ABT6  ',
'                    ,p_c009 => coltab.ABT7  ,p_c010 => coltab.ABT8',
'                );        ',
'            END LOOP;',
'        END IF;      ',
'    end if;  ',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>126807919234999881
);
wwv_flow_imp.component_end;
end;
/
