prompt --application/pages/page_00121
begin
--   Manifest
--     PAGE: 00121
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>109
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_page.create_page(
 p_id=>121
,p_name=>unistr('Gesti\00F3n Datos JDE')
,p_alias=>unistr('GESTI\00D3N-DATOS-JDE')
,p_step_title=>unistr('Gesti\00F3n Datos JDE')
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'17'
,p_created_on=>wwv_flow_imp.dz('20230814143038Z')
,p_last_updated_on=>wwv_flow_imp.dz('20230814143333Z')
,p_created_by=>'DDELACRUZ'
,p_last_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(37860813182753935)
,p_plug_name=>unistr('Par\00E1metros')
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(38289867500120143)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
,p_created_on=>wwv_flow_imp.dz('20230814143333Z')
,p_updated_on=>wwv_flow_imp.dz('20230814143333Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(37860924834753936)
,p_name=>'P121_TABLA'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(37860813182753935)
,p_prompt=>'Tabla'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'STATIC:F4111 - Kardex;f4111,F0911 - Libro Mayor;f0911'
,p_lov_display_null=>'YES'
,p_lov_null_text=>'Seleccione'
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'NONE'
,p_created_on=>wwv_flow_imp.dz('20230814143333Z')
,p_updated_on=>wwv_flow_imp.dz('20230814143333Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp.component_end;
end;
/
