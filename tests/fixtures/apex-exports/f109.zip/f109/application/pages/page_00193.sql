prompt --application/pages/page_00193
begin
--   Manifest
--     PAGE: 00193
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>109
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_page.create_page(
 p_id=>193
,p_name=>'GESTION TRIBUTARIA - Excel a Tabla'
,p_alias=>'GESTION-TRIBUTARIA-'
,p_page_mode=>'MODAL'
,p_step_title=>'Excel a Tabla'
,p_autocomplete_on_off=>'OFF'
,p_javascript_code_onload=>'$(secItems).hide();'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.apex-item-file {',
'    opacity: 1 !important;',
'    border: 1px solid #ccced1;',
'}'))
,p_step_template=>wwv_flow_imp.id(37774372912106498)
,p_page_template_options=>'#DEFAULT#:t-Dialog--noPadding'
,p_dialog_width=>'85%'
,p_dialog_chained=>'N'
,p_page_is_public_y_n=>'Y'
,p_page_component_map=>'18'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(188715408378518969)
,p_plug_name=>'Formulario'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(38289867500120143)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_ai_enabled=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(34442465480782307)
,p_plug_name=>'Items'
,p_region_name=>'secItems'
,p_parent_plug_id=>wwv_flow_imp.id(188715408378518969)
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(38289867500120143)
,p_plug_display_sequence=>40
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(321253062495356129)
,p_plug_name=>'Datos'
,p_parent_plug_id=>wwv_flow_imp.id(188715408378518969)
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(38289867500120143)
,p_plug_display_sequence=>30
,p_location=>null
,p_ai_enabled=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(321434738837064047)
,p_plug_name=>'Botones'
,p_parent_plug_id=>wwv_flow_imp.id(188715408378518969)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(38290276266120143)
,p_plug_display_sequence=>60
,p_location=>null
,p_ai_enabled=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(321630019993067140)
,p_plug_name=>'Resultado'
,p_parent_plug_id=>wwv_flow_imp.id(188715408378518969)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(37806762584106520)
,p_plug_display_sequence=>50
,p_query_type=>'TABLE'
,p_query_table=>'VT_APEX_EXCEL'
,p_include_rowid_column=>false
,p_plug_source_type=>'NATIVE_IR'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>210
,p_prn_height=>297
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(321652024102098342)
,p_max_row_count=>'1000000'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_fixed_header=>'REGION'
,p_fixed_header_max_height=>300
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'JBALCAZAR'
,p_internal_uid=>321652024102098342
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(321652261080098344)
,p_db_column_name=>'C01'
,p_display_order=>20
,p_column_identifier=>'A'
,p_column_label=>'&P193_C0_1.'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(321652303614098345)
,p_db_column_name=>'C02'
,p_display_order=>30
,p_column_identifier=>'B'
,p_column_label=>'&P193_C0_2.'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(321652412650098346)
,p_db_column_name=>'C03'
,p_display_order=>40
,p_column_identifier=>'C'
,p_column_label=>'&P193_C0_3.'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(321652549832098347)
,p_db_column_name=>'C04'
,p_display_order=>50
,p_column_identifier=>'D'
,p_column_label=>'&P193_C0_4.'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(321652603687098348)
,p_db_column_name=>'C05'
,p_display_order=>60
,p_column_identifier=>'E'
,p_column_label=>'&P193_C0_5.'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(321652714954098349)
,p_db_column_name=>'C06'
,p_display_order=>70
,p_column_identifier=>'F'
,p_column_label=>'&P193_C0_6.'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(321652847462098350)
,p_db_column_name=>'C07'
,p_display_order=>80
,p_column_identifier=>'G'
,p_column_label=>'&P193_C0_7.'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(321652899529098351)
,p_db_column_name=>'C08'
,p_display_order=>90
,p_column_identifier=>'H'
,p_column_label=>'&P193_C0_8.'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(321652983369098352)
,p_db_column_name=>'C09'
,p_display_order=>100
,p_column_identifier=>'I'
,p_column_label=>'&P193_C0_9.'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(321653077450098353)
,p_db_column_name=>'C10'
,p_display_order=>110
,p_column_identifier=>'J'
,p_column_label=>'&P193_C0_10.'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(321653251362098354)
,p_db_column_name=>'C11'
,p_display_order=>120
,p_column_identifier=>'K'
,p_column_label=>'&P193_C0_11.'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(321653367072098355)
,p_db_column_name=>'C12'
,p_display_order=>130
,p_column_identifier=>'L'
,p_column_label=>'&P193_C0_12.'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(321653462168098356)
,p_db_column_name=>'C13'
,p_display_order=>140
,p_column_identifier=>'M'
,p_column_label=>'&P193_C0_13.'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(321653520721098357)
,p_db_column_name=>'C14'
,p_display_order=>150
,p_column_identifier=>'N'
,p_column_label=>'&P193_C0_14.'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(321653604169098358)
,p_db_column_name=>'C15'
,p_display_order=>160
,p_column_identifier=>'O'
,p_column_label=>'&P193_C0_15.'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(321653677757098359)
,p_db_column_name=>'C16'
,p_display_order=>170
,p_column_identifier=>'P'
,p_column_label=>'&P193_C0_16.'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(321653834359098360)
,p_db_column_name=>'C17'
,p_display_order=>180
,p_column_identifier=>'Q'
,p_column_label=>'&P193_C0_17.'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(321653916666098361)
,p_db_column_name=>'C18'
,p_display_order=>190
,p_column_identifier=>'R'
,p_column_label=>'&P193_C0_18.'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(321654059837098362)
,p_db_column_name=>'C19'
,p_display_order=>200
,p_column_identifier=>'S'
,p_column_label=>'&P193_C0_19.'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(321654162154098363)
,p_db_column_name=>'C20'
,p_display_order=>210
,p_column_identifier=>'T'
,p_column_label=>'&P193_C0_20.'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(321654212590098364)
,p_db_column_name=>'C21'
,p_display_order=>220
,p_column_identifier=>'U'
,p_column_label=>'C21'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(321654341583098365)
,p_db_column_name=>'C22'
,p_display_order=>230
,p_column_identifier=>'V'
,p_column_label=>'C22'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(321654401854098366)
,p_db_column_name=>'C23'
,p_display_order=>240
,p_column_identifier=>'W'
,p_column_label=>'C23'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(321654493505098367)
,p_db_column_name=>'C24'
,p_display_order=>250
,p_column_identifier=>'X'
,p_column_label=>'C24'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(321654621571098368)
,p_db_column_name=>'C25'
,p_display_order=>260
,p_column_identifier=>'Y'
,p_column_label=>'C25'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(321654730492098369)
,p_db_column_name=>'C26'
,p_display_order=>270
,p_column_identifier=>'Z'
,p_column_label=>'C26'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(321654768158098370)
,p_db_column_name=>'C27'
,p_display_order=>280
,p_column_identifier=>'AA'
,p_column_label=>'C27'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(321654881823098371)
,p_db_column_name=>'C28'
,p_display_order=>290
,p_column_identifier=>'AB'
,p_column_label=>'C28'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(321655024712098372)
,p_db_column_name=>'C29'
,p_display_order=>300
,p_column_identifier=>'AC'
,p_column_label=>'C29'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(321655086965098373)
,p_db_column_name=>'C30'
,p_display_order=>310
,p_column_identifier=>'AD'
,p_column_label=>'C30'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(321655192701098374)
,p_db_column_name=>'C31'
,p_display_order=>320
,p_column_identifier=>'AE'
,p_column_label=>'C31'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(321655337170098375)
,p_db_column_name=>'C32'
,p_display_order=>330
,p_column_identifier=>'AF'
,p_column_label=>'C32'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(321703079133385326)
,p_db_column_name=>'C33'
,p_display_order=>340
,p_column_identifier=>'AG'
,p_column_label=>'C33'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(321703191723385327)
,p_db_column_name=>'C34'
,p_display_order=>350
,p_column_identifier=>'AH'
,p_column_label=>'C34'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(321703353628385328)
,p_db_column_name=>'C35'
,p_display_order=>360
,p_column_identifier=>'AI'
,p_column_label=>'C35'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(321703428329385329)
,p_db_column_name=>'C36'
,p_display_order=>370
,p_column_identifier=>'AJ'
,p_column_label=>'C36'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(321703514714385330)
,p_db_column_name=>'C37'
,p_display_order=>380
,p_column_identifier=>'AK'
,p_column_label=>'C37'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(321703651857385331)
,p_db_column_name=>'C38'
,p_display_order=>390
,p_column_identifier=>'AL'
,p_column_label=>'C38'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(321703725666385332)
,p_db_column_name=>'C39'
,p_display_order=>400
,p_column_identifier=>'AM'
,p_column_label=>'C39'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(321703819185385333)
,p_db_column_name=>'C40'
,p_display_order=>410
,p_column_identifier=>'AN'
,p_column_label=>'C40'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(321703946997385334)
,p_db_column_name=>'C41'
,p_display_order=>420
,p_column_identifier=>'AO'
,p_column_label=>'C41'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(321704038937385335)
,p_db_column_name=>'C42'
,p_display_order=>430
,p_column_identifier=>'AP'
,p_column_label=>'C42'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(321704103127385336)
,p_db_column_name=>'C43'
,p_display_order=>440
,p_column_identifier=>'AQ'
,p_column_label=>'C43'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(321704201934385337)
,p_db_column_name=>'C44'
,p_display_order=>450
,p_column_identifier=>'AR'
,p_column_label=>'C44'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(321704288652385338)
,p_db_column_name=>'C45'
,p_display_order=>460
,p_column_identifier=>'AS'
,p_column_label=>'C45'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(321704425120385339)
,p_db_column_name=>'C46'
,p_display_order=>470
,p_column_identifier=>'AT'
,p_column_label=>'C46'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(321704533007385340)
,p_db_column_name=>'C47'
,p_display_order=>480
,p_column_identifier=>'AU'
,p_column_label=>'C47'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(321704634991385341)
,p_db_column_name=>'C48'
,p_display_order=>490
,p_column_identifier=>'AV'
,p_column_label=>'C48'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(321704714491385342)
,p_db_column_name=>'C49'
,p_display_order=>500
,p_column_identifier=>'AW'
,p_column_label=>'C49'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(321704815158385343)
,p_db_column_name=>'C50'
,p_display_order=>510
,p_column_identifier=>'AX'
,p_column_label=>'C50'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(191419481690983227)
,p_db_column_name=>'ID'
,p_display_order=>520
,p_column_identifier=>'AY'
,p_column_label=>'#'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(321738904817399143)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'2871655'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_display_rows=>1000
,p_report_columns=>'C01:C02:C03:C04:C05:C06:C07:C08:C09:C10:C11:C12:C13:C14:C15:C16:C17:C18:C19:C20:C21:C22:C23:C24:C25:C26:C27:C28:C29:C30:C31:C32:C33:C34:C35:C36:C37:C38:C39:C40:C41:C42:C43:C44:C45:C46:C47:C48:C49:C50'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(34583213218043533)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(321434738837064047)
,p_button_name=>'CARGAR'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860181880106559)
,p_button_image_alt=>'Cargar'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_button_execute_validations=>'N'
,p_button_condition=>':P193_PAGINA IS NULL AND :P193_APP IS NULL'
,p_button_condition2=>'PLSQL'
,p_button_condition_type=>'EXPRESSION'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(34583635977043533)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(321434738837064047)
,p_button_name=>'SIGUIENTE'
,p_button_action=>'REDIRECT_APP'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860181880106559)
,p_button_image_alt=>'Siguiente'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&P193_APP.:&P193_PAGINA.:&SESSION.::&DEBUG.:RP::'
,p_button_condition=>':P193_PAGINA IS NOT NULL AND :P193_APP IS NOT NULL'
,p_button_condition2=>'SQL'
,p_button_condition_type=>'EXPRESSION'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(188716444322518971)
,p_name=>'P193_TIPO'
,p_is_required=>true
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(321253062495356129)
,p_item_default=>'1'
,p_prompt=>'Tipo:'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'STATIC2(,):.XLS,.XLSX1.CSV,.TXT2'
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(37859675292106557)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(188716669845518973)
,p_name=>'P193_SEPARADOR'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(321253062495356129)
,p_prompt=>'Separador:'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'STATIC2:Tabulacion;tab,Espacio;esp,Coma;com,Punto y Coma;pco'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(37859675292106557)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(205827642882767027)
,p_name=>'P193_CABECERA'
,p_item_sequence=>500
,p_item_plug_id=>wwv_flow_imp.id(34442465480782307)
,p_prompt=>'Cabecera'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(321254060359356131)
,p_name=>'P193_ARCHIVO'
,p_is_required=>true
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(321253062495356129)
,p_prompt=>'Archivo:'
,p_display_as=>'NATIVE_FILE'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_grid_label_column_span=>0
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_is_persistent=>'U'
,p_attribute_01=>'APEX_APPLICATION_TEMP_FILES'
,p_attribute_09=>'REQUEST'
,p_attribute_10=>'N'
,p_attribute_12=>'NATIVE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(321473017331085670)
,p_name=>'P193_CARGA'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(34442465480782307)
,p_prompt=>'Carga'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(321597992392019170)
,p_name=>'P193_C0'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(34442465480782307)
,p_prompt=>'C0'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_grid_label_column_span=>0
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(321598013500019171)
,p_name=>'P193_C0_1'
,p_item_sequence=>270
,p_item_plug_id=>wwv_flow_imp.id(34442465480782307)
,p_prompt=>'C0_1'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_grid_label_column_span=>0
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(321598177714019172)
,p_name=>'P193_C0_2'
,p_item_sequence=>280
,p_item_plug_id=>wwv_flow_imp.id(34442465480782307)
,p_prompt=>'C0_2'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_grid_label_column_span=>0
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(321598270286019173)
,p_name=>'P193_C0_3'
,p_item_sequence=>290
,p_item_plug_id=>wwv_flow_imp.id(34442465480782307)
,p_prompt=>'C0_3'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_grid_label_column_span=>0
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(321598404456019174)
,p_name=>'P193_C0_4'
,p_item_sequence=>300
,p_item_plug_id=>wwv_flow_imp.id(34442465480782307)
,p_prompt=>'C0_4'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_grid_label_column_span=>0
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(321598477714019175)
,p_name=>'P193_C0_5'
,p_item_sequence=>310
,p_item_plug_id=>wwv_flow_imp.id(34442465480782307)
,p_prompt=>'C0_5'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_grid_label_column_span=>0
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(321598524657019176)
,p_name=>'P193_C0_6'
,p_item_sequence=>320
,p_item_plug_id=>wwv_flow_imp.id(34442465480782307)
,p_prompt=>'C0_6'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_grid_label_column_span=>0
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(321629591977067127)
,p_name=>'P193_C0_7'
,p_item_sequence=>330
,p_item_plug_id=>wwv_flow_imp.id(34442465480782307)
,p_prompt=>'C0_7'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_grid_label_column_span=>0
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(321629674257067128)
,p_name=>'P193_C0_8'
,p_item_sequence=>340
,p_item_plug_id=>wwv_flow_imp.id(34442465480782307)
,p_prompt=>'C0_8'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_grid_label_column_span=>0
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(321629737188067129)
,p_name=>'P193_C0_9'
,p_item_sequence=>350
,p_item_plug_id=>wwv_flow_imp.id(34442465480782307)
,p_prompt=>'C0_9'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_grid_label_column_span=>0
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(321629868148067130)
,p_name=>'P193_C0_10'
,p_item_sequence=>360
,p_item_plug_id=>wwv_flow_imp.id(34442465480782307)
,p_prompt=>'C0_10'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_grid_label_column_span=>0
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(321629948546067131)
,p_name=>'P193_C0_11'
,p_item_sequence=>370
,p_item_plug_id=>wwv_flow_imp.id(34442465480782307)
,p_prompt=>'C0_11'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_grid_label_column_span=>0
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(321630100993067132)
,p_name=>'P193_C0_12'
,p_item_sequence=>380
,p_item_plug_id=>wwv_flow_imp.id(34442465480782307)
,p_prompt=>'C0_12'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_grid_label_column_span=>0
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(321630204854067133)
,p_name=>'P193_C0_13'
,p_item_sequence=>390
,p_item_plug_id=>wwv_flow_imp.id(34442465480782307)
,p_prompt=>'C0_13'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_grid_label_column_span=>0
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(321630225504067134)
,p_name=>'P193_C0_14'
,p_item_sequence=>400
,p_item_plug_id=>wwv_flow_imp.id(34442465480782307)
,p_prompt=>'C0_14'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_grid_label_column_span=>0
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(321630404136067135)
,p_name=>'P193_C0_15'
,p_item_sequence=>410
,p_item_plug_id=>wwv_flow_imp.id(34442465480782307)
,p_prompt=>'C0_15'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_grid_label_column_span=>0
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(321630511882067136)
,p_name=>'P193_C0_16'
,p_item_sequence=>420
,p_item_plug_id=>wwv_flow_imp.id(34442465480782307)
,p_prompt=>'C0_16'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_grid_label_column_span=>0
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(321630595999067137)
,p_name=>'P193_C0_17'
,p_item_sequence=>430
,p_item_plug_id=>wwv_flow_imp.id(34442465480782307)
,p_prompt=>'C0_17'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_grid_label_column_span=>0
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(321630616125067138)
,p_name=>'P193_C0_18'
,p_item_sequence=>440
,p_item_plug_id=>wwv_flow_imp.id(34442465480782307)
,p_prompt=>'C0_18'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_grid_label_column_span=>0
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(321630783332067139)
,p_name=>'P193_C0_19'
,p_item_sequence=>450
,p_item_plug_id=>wwv_flow_imp.id(34442465480782307)
,p_prompt=>'C0_19'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_grid_label_column_span=>0
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(321630843241067140)
,p_name=>'P193_C0_20'
,p_item_sequence=>460
,p_item_plug_id=>wwv_flow_imp.id(34442465480782307)
,p_prompt=>'C0_20'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_grid_label_column_span=>0
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(321707795541385364)
,p_name=>'P193_APP'
,p_item_sequence=>480
,p_item_plug_id=>wwv_flow_imp.id(34442465480782307)
,p_prompt=>'App'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(321707827299385365)
,p_name=>'P193_PAGINA'
,p_item_sequence=>490
,p_item_plug_id=>wwv_flow_imp.id(34442465480782307)
,p_prompt=>'Pagina'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(34600637360043545)
,p_computation_sequence=>10
,p_computation_item=>'P193_CARGA'
,p_computation_type=>'STATIC_ASSIGNMENT'
,p_computation=>'1'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(34442553848782308)
,p_validation_name=>'Separador no vacio'
,p_validation_sequence=>10
,p_validation=>'P193_SEPARADOR'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>'#LABEL# debe tener un valor'
,p_validation_condition=>'P193_TIPO'
,p_validation_condition2=>'2'
,p_validation_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_associated_item=>wwv_flow_imp.id(188716669845518973)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(34602549876043547)
,p_name=>'Actualizar'
,p_event_sequence=>10
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P193_ARCHIVO'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(34603014093043547)
,p_event_id=>wwv_flow_imp.id(34602549876043547)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_02=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(34603410094043547)
,p_name=>'Cambiar Tipo'
,p_event_sequence=>20
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P193_TIPO'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(34603997006043548)
,p_event_id=>wwv_flow_imp.id(34603410094043547)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P193_SEPARADOR'
,p_client_condition_type=>'EQUALS'
,p_client_condition_element=>'P193_TIPO'
,p_client_condition_expression=>'1'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(34604400104043548)
,p_event_id=>wwv_flow_imp.id(34603410094043547)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P193_SEPARADOR'
,p_client_condition_type=>'EQUALS'
,p_client_condition_element=>'P193_TIPO'
,p_client_condition_expression=>'2'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(57498600159306244)
,p_name=>'New'
,p_event_sequence=>30
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'ready'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(57498728649306245)
,p_event_id=>wwv_flow_imp.id(57498600159306244)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'console.log("G_PAGINA >> P193_PAGINA:"+$v("P193_PAGINA"));',
'console.log("G_MODULO >> P193_APP:"+$v("P193_APP"));',
'console.log("G_VALOR1 >> P193_CABECERA:"+$v("P193_CABECERA"));',
'console.log("G_VALOR2 >> P193_TIPO:"+$v("P193_TIPO"));',
'console.log("G_VALOR3 >> P193_SEPARADOR:"+$v("P193_SEPARADOR"));',
'console.log("         >> P193_ARCHIVO:"+$v("P193_ARCHIVO"));',
'',
' '))
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(34600905667043545)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Cargar datos'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    V_HOJA varchar2(1000);',
'    v_blob BLOB;',
'    v_clob CLOB;',
'    v_query clob;',
'    v_query2 clob;',
'    v_file_clob clob;',
'    v_file_size integer := dbms_lob.lobmaxsize;',
'    v_dest_offset integer := 1;',
'    v_src_offset integer := 1;',
'    v_blob_csid number := dbms_lob.default_csid;',
'    v_lang_context number := dbms_lob.default_lang_ctx;',
'    v_warning integer;',
'    v_length number;',
'    l_vc_arr2    APEX_APPLICATION_GLOBAL.VC_ARR2;',
'    v_separador varchar2(5);',
'    v_rowid rowid;',
'begin',
'    v_separador:=',
'    case :P193_SEPARADOR ',
'        when ''tab'' then ''	'' ',
'        when ''esp'' then '' '' ',
'        when ''com'' then '','' ',
'        when ''pco'' then '';'' ',
'        else '';''',
'    end;',
'    IF  APEX_COLLECTION.COLLECTION_EXISTS (p_collection_name => ''TABLA_EXCEL'') THEN',
'        APEX_COLLECTION.DELETE_COLLECTION(p_collection_name => ''TABLA_EXCEL'');',
'    END IF;',
'',
'    IF(:P193_TIPO=1) THEN --- EXCEL',
'        SELECT column_value INTO V_HOJA FROM TABLE( PK_APEX_XLS.get_worksheets( p_xlsx_name => :P193_ARCHIVO )) WHERE ROWNUM=1;',
'        V_QUERY := ''SELECT * FROM table( ',
'                    PK_APEX_XLS.parse( ',
'                        p_xlsx_name      => ''''''||:P193_ARCHIVO||'''''', ',
'                        p_worksheet_name => ''''''||''sheet1''||''''''',
'                    ))'';         ',
'    ELSE -- .CSV',
'        DELETE DATA.T_TMP_B;',
'',
unistr('        -- Dividir la cadena en l\00EDneas Para recorrer las lineas'),
'        SELECT COUNT(1) INTO v_length FROM APEX_APPLICATION_TEMP_FILES;',
'',
'        FOR ARCHIVOS IN (',
'            SELECT ROWNUM IDROW,ID,APPLICATION_ID,NAME,FILENAME,MIME_TYPE,CREATED_ON,BLOB_CONTENT',
'            FROM APEX_APPLICATION_TEMP_FILES',
'            WHERE NAME = :P193_ARCHIVO',
'            order by CREATED_ON, FILENAME ',
'        )',
'        LOOP',
'            v_blob:=NULL;',
'            v_clob:=NULL;',
'            v_blob:=ARCHIVOS.BLOB_CONTENT;',
'            v_clob:=pk_commons.f_blob_to_clob(v_blob);',
'            PK_FINZ_GESTIONTRIBUTARIA.sp_log(p_tipo      => 1,p_linea         =>  $$PLSQL_LINE,p_mensaje		=> ''FILENAME:''||ARCHIVOS.FILENAME);',
'            PK_FINZ_GESTIONTRIBUTARIA.sp_log(p_tipo      => 1,p_linea         =>  $$PLSQL_LINE,p_mensaje		=> ''process:''||v_length,p_query=>v_clob);',
'',
'            FOR line IN (',
'                SELECT REGEXP_SUBSTR(v_clob, ''[^''||CHR(10)||CHR(13)||'']+'', 1, LEVEL) AS line, rownum numero',
'                FROM dual',
'                CONNECT BY LEVEL <= REGEXP_COUNT(v_clob, ''[^''||CHR(10)||CHR(13)||'']+'')',
'            )',
'            LOOP',
'                v_query := ''INSERT INTO DATA.T_TMP_B (NUM01,NUM02'';',
'                v_query2 := '' VALUES (''''''||line.numero||''''''''||'',''''''||ARCHIVOS.IDROW||'''''''';',
'',
'                l_vc_arr2:= APEX_UTIL.STRING_TO_TABLE( p_string => line.line, p_separator => v_separador);',
'',
'                FOR i IN 1..l_vc_arr2.count LOOP',
'                    IF (i<50) THEN ',
'                        v_query := v_query||'', TXT''||lpad(i,2,''0'');',
'                        v_query2 := v_query2||'',''''''||replace(l_vc_arr2(i),'''''''','''''''''''')||'''''''';',
'                    END IF;',
'                END loop;',
'                v_query := v_query||'' ) ''||v_query2||'') '';',
'            ',
'                EXECUTE IMMEDIATE v_query; commit;',
'            end loop;',
'        END LOOP;',
'        IF (v_length>1)THEN ',
'            select rowid into v_rowid from DATA.T_TMP_B a where rownum=1 AND NUM01=1 AND NUM02=1;   ',
'            update DATA.T_TMP_B a set num01=-1 where rowid =v_rowid;',
'            delete FROM DATA.T_TMP_B a WHERE num01=1 ;',
'            update DATA.T_TMP_B a set num01=1 where rowid =v_rowid;',
'            commit;',
'        END IF;',
'',
'        -- Liberar el CLOB temporal',
'        DBMS_LOB.FREETEMPORARY(v_clob);',
'        v_query := ''select TO_CHAR(case when NUM01=1 and  NUM02= 1 then 1 else rownum end)NUM01, TXT01,TXT02,TXT03,TXT04,TXT05,TXT06,TXT07,TXT08,TXT09,TXT10 ',
'                           ,TXT11,TXT12,TXT13,TXT14,TXT15,TXT16,TXT17,TXT18,TXT19,TXT20 ',
'                           ,TXT21,TXT22,TXT23,TXT24,TXT25,TXT26,TXT27,TXT28,TXT29,TXT30 ',
'                           ,TXT31,TXT32,TXT33,TXT34,TXT35,TXT36,TXT37,TXT38,TXT39,TXT40 ',
'                           ,TXT41,TXT42,TXT43,TXT44,TXT45,TXT46,TXT47,TXT48,TXT49 ',
'                    from (SELECT * FROM data.t_tmp_b',
'                    order by num02,num01)'';',
'    END IF;  ',
'',
'    APEX_COLLECTION.CREATE_COLLECTION_FROM_QUERY (',
'            p_collection_name => ''TABLA_EXCEL'', ',
'            p_query => V_QUERY,',
'            p_generate_md5 => ''YES'');',
'            ',
'    SELECT NVL(C01,''C01''),NVL(C02,''C02''),NVL(C03,''C03''),NVL(C04,''C04''),NVL(C05,''C05''),NVL(C06,''C06''),NVL(C07,''C07''),NVL(C08,''C08''),NVL(C09,''C09''),NVL(C10,''C10''),',
'               NVL(C11,''C11''),NVL(C12,''C12''),NVL(C13,''C13''),NVL(C14,''C14''),NVL(C15,''C15''),NVL(C16,''C16''),NVL(C17,''C17''),NVL(C18,''C18''),NVL(C19,''C19''),NVL(C20,''C20'')',
'    INTO',
'        :P193_C0_1,:P193_C0_2,:P193_C0_3,:P193_C0_4,:P193_C0_5,:P193_C0_6,:P193_C0_7,:P193_C0_8,:P193_C0_9,:P193_C0_10,',
'        :P193_C0_11,:P193_C0_12,:P193_C0_13,:P193_C0_14,:P193_C0_15,:P193_C0_16,:P193_C0_17,:P193_C0_18,:P193_C0_19,:P193_C0_20',
'    FROM VT_APEX_EXCEL where ID =1;',
'        ',
'        ',
'    IF(NVL(:P193_CABECERA, 1) = 1 ) THEN  ',
'      ',
'',
'        SELECT NVL(C01,''C01''),NVL(C02,''C02''),NVL(C03,''C03''),NVL(C04,''C04''),NVL(C05,''C05''),NVL(C06,''C06''),NVL(C07,''C07''),NVL(C08,''C08''),NVL(C09,''C09''),NVL(C10,''C10''),',
'               NVL(C11,''C11''),NVL(C12,''C12''),NVL(C13,''C13''),NVL(C14,''C14''),NVL(C15,''C15''),NVL(C16,''C16''),NVL(C17,''C17''),NVL(C18,''C18''),NVL(C19,''C19''),NVL(C20,''C20'')',
'        INTO',
'            :P193_C0_1,:P193_C0_2,:P193_C0_3,:P193_C0_4,:P193_C0_5,:P193_C0_6,:P193_C0_7,:P193_C0_8,:P193_C0_9,:P193_C0_10,',
'            :P193_C0_11,:P193_C0_12,:P193_C0_13,:P193_C0_14,:P193_C0_15,:P193_C0_16,:P193_C0_17,:P193_C0_18,:P193_C0_19,:P193_C0_20',
'        FROM VT_APEX_EXCEL where ID =1;',
'',
'         APEX_COLLECTION.DELETE_MEMBER(',
'        p_collection_name => ''TABLA_EXCEL'',',
'        p_seq => ''1'');',
'',
'    ELSE ',
'',
'        SELECT ''C01'',''C02'',''C03'',''C04'',''C05'',''C06'',''C07'',''C08'',''C09'',''C10'',',
'               ''C11'',''C12'',''C13'',''C14'',''C15'',''C16'',''C17'',''C18'',''C19'',''C20''',
'        INTO',
'            :P193_C0_1,:P193_C0_2,:P193_C0_3,:P193_C0_4,:P193_C0_5,:P193_C0_6,:P193_C0_7,:P193_C0_8,:P193_C0_9,:P193_C0_10,',
'            :P193_C0_11,:P193_C0_12,:P193_C0_13,:P193_C0_14,:P193_C0_15,:P193_C0_16,:P193_C0_17,:P193_C0_18,:P193_C0_19,:P193_C0_20',
'        FROM VT_APEX_EXCEL where ID =1;',
'    ',
'    END IF;   ',
'     DELETE FROM DATA.t_apex_temporal  WHERE  FLAG= ''GT_109.193'' AND CONTROL01= ''VT_APEX_EXCEL'';COMMIT;',
'    insert into DATA.t_apex_temporal (FLAG, CONTROL01, TXT01, TXT02, TXT03, TXT04, TXT05, TXT06, TXT07, TXT08, TXT09, TXT10, TXT11, TXT12, TXT13, TXT14, TXT15, TXT16, TXT17, TXT18, TXT19, TXT20, TXT21, TXT22, TXT23, TXT24, TXT25, TXT26, TXT27, TXT28,'
||' TXT29, TXT30, TXT31, TXT32, TXT33, TXT34, TXT35, TXT36, TXT37, TXT38, TXT39, TXT40, TXT41, TXT42, TXT43, TXT44, TXT45, TXT46, TXT47, TXT48, TXT49, TXT50)',
'    SELECT ''GT_109.193'',''VT_APEX_EXCEL'',C01,C02,C03,C04,C05,C06,C07,C08,C09,C10,C11,C12,C13,C14,C15,C16,C17,C18,C19,C20,C21,C22,C23,C24,C25,C26,C27,C28,C29,C30,C31,C32,C33,C34,C35,C36,C37,C38,C39,C40,C41,C42,C43,C44,C45,C46,C47,C48,C49,C50 FROM VT_AP'
||'EX_EXCEL;',
'    COMMIT;',
'End;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>'P193_ARCHIVO'
,p_process_when_type=>'ITEM_IS_NOT_NULL'
,p_internal_uid=>34600905667043545
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(34443267135782315)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Limpiar Datos'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
':P193_CARGA:=null;',
':P193_ARCHIVO:=null;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(34583213218043533)
,p_internal_uid=>34443267135782315
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(34601370670043546)
,p_process_sequence=>30
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_CLOSE_WINDOW'
,p_process_name=>'Cerra dialogo'
,p_attribute_02=>'N'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(34583213218043533)
,p_internal_uid=>34601370670043546
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(34602160250043546)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Cargar datos url'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
':P193_PAGINA    := :G_PAGINA;',
':P193_APP       := :G_MODULO;',
':P193_CABECERA  := :G_VALOR1;',
':P193_TIPO      := :G_VALOR2;',
':P193_SEPARADOR := :G_VALOR3;',
':P193_ARCHIVO   :=null;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>34602160250043546
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(34601784433043546)
,p_process_sequence=>20
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Borrar Coleccion'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
' IF  APEX_COLLECTION.COLLECTION_EXISTS (p_collection_name => ''TABLA_EXCEL'') THEN',
'       ',
'           APEX_COLLECTION.DELETE_COLLECTION(p_collection_name => ''TABLA_EXCEL'');',
'       ',
'     END IF;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>'P193_CARGA'
,p_process_when_type=>'ITEM_IS_NULL'
,p_internal_uid=>34601784433043546
);
wwv_flow_imp.component_end;
end;
/
