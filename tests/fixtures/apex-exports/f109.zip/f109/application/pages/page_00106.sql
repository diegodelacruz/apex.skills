prompt --application/pages/page_00106
begin
--   Manifest
--     PAGE: 00106
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>109
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_page.create_page(
 p_id=>106
,p_name=>'Hist. Liquidaciones'
,p_step_title=>'Hist. Liquidaciones'
,p_autocomplete_on_off=>'OFF'
,p_javascript_code_onload=>'$(".t-Button.t-Button--icon.t-Button--header.t-Button--headerTree.is-active").click();'
,p_page_template_options=>'#DEFAULT#'
,p_page_component_map=>'18'
,p_created_on=>wwv_flow_imp.dz('20230705164634Z')
,p_last_updated_on=>wwv_flow_imp.dz('20250317214244Z')
,p_last_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(274410059371425840)
,p_plug_name=>'Reporte'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(37806762584106520)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'with w_cmpb as (',
'	select numeroliquidacion',
'		, count(1) registros',
'		, sum(subtotalcero) subtotalcero',
'		, sum(subtotaldoce) subtotaldoce ',
'		, sum(iva) iva',
'		, sum(valortotal) valortotal',
'	from vt_corp_datoscomprobantes',
'	where 1 = 1 and codigomodulo = ''GLIQ''',
'	group by numeroliquidacion',
')',
'select a.id',
'	, ''Liquidacion'' objeto',
'	, a.id objeto_id',
'	, a.usuariocrea',
'	, a.centrocostos',
'	, a.codigoproveedor',
'	, a.compania',
'	, a.detalle',
'	, a.estado',
'	-- , a.estadoaprobacion',
'	, a.factura',
'	, a.fechacreacion',
'	, a.idflujo',
'	, a.monto',
'	, case when nvl(b.valortotal,0) = 0 then 0 else b.valortotal end valorliquidado',
'	, case when nvl(b.valortotal,0) > nvl(monto,0) then nvl(b.valortotal,0) - nvl(monto,0) else 0 end valorpagar',
'	, case when nvl(b.valortotal,0) < nvl(monto,0) then nvl(monto,0) - nvl(b.valortotal,0) else 0 end valordescontar',
'	, case',
'		when a.estadoaprobacion = ''F'' then ''LIQUIDADO''  ',
'		when a.usuarioflujo is not null then ''RUTA DE APROBACION'' ',
'		when a.estadoaprobacion = ''E'' then ''ELIMINADO FINANZAS'' ',
'		when a.estadoaprobacion = ''R'' then ''RECHAZADO''',
'		else ''PENDIENTE LIQUIDAR'' end estadoaprobacion',
'	, a.numeroliquidacion',
'	, a.objetivo',
'	, a.tipo',
'	, a.tipoliquidacion',
'	, a.usuarioflujo',
'	, case when a.estado = 0 or nvl(b.registros,0) = 0 then null else ''<span title="Respaldos" class="fa fa-file-check" style="color: #CD5C5C;"></span>'' end respaldos',
unistr('	, case when a.usuarioflujo is not null or a.estadoaprobacion = ''F'' then ''<span title="Ruta de Aprobaci\00F3n" class="fa fa-road" style="color: #000080;"></span>'' else null end rutaaprobacion'),
'	, b.registros',
'	, b.subtotalcero',
'	, b.subtotaldoce',
'	, b.iva',
'	, b.valortotal',
'from t_gliq_liquidacion a',
'left join w_cmpb b on a.id = b.numeroliquidacion',
'where 1 = 1',
'	and nvl(a.id,0) > 0',
'	and nvl(a.estado,0) >= 0',
'	and trim(a.tipo) = nvl(:p106_tipo,trim(a.tipo))',
'	and a.fechacreacion between :p106_desde and :p106_hasta'))
,p_plug_source_type=>'NATIVE_IR'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>210
,p_prn_height=>297
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_updated_on=>wwv_flow_imp.dz('20250317214244Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(274410128193425841)
,p_max_row_count=>'1000000'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_control_break=>'N'
,p_show_highlight=>'N'
,p_show_computation=>'N'
,p_show_aggregate=>'N'
,p_show_chart=>'N'
,p_show_group_by=>'N'
,p_show_flashback=>'N'
,p_download_formats=>'XLSX'
,p_enable_mail_download=>'N'
,p_owner=>'DDELACRUZ'
,p_internal_uid=>274410128193425841
,p_updated_on=>wwv_flow_imp.dz('20250317214244Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(274410291666425842)
,p_db_column_name=>'ID'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'ID'
,p_column_type=>'NUMBER'
,p_column_alignment=>'CENTER'
,p_format_mask=>'00000'
,p_use_as_row_header=>'N'
,p_updated_on=>wwv_flow_imp.dz('20250317201959Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(274410306777425843)
,p_db_column_name=>'USUARIOCREA'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Usuario'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
,p_updated_on=>wwv_flow_imp.dz('20250317161135Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(274410486388425844)
,p_db_column_name=>'CENTROCOSTOS'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Cent. Costo'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(274410580621425845)
,p_db_column_name=>'CODIGOPROVEEDOR'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Proveedor'
,p_column_type=>'NUMBER'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_rpt_named_lov=>wwv_flow_imp.id(92685403493351092)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
,p_updated_on=>wwv_flow_imp.dz('20250317214244Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(274410629224425846)
,p_db_column_name=>'COMPANIA'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Compania'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(274410784001425847)
,p_db_column_name=>'DETALLE'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'Detalle'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(274410823491425848)
,p_db_column_name=>'ESTADO'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>'Estado'
,p_column_type=>'NUMBER'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(274410989982425849)
,p_db_column_name=>'ESTADOAPROBACION'
,p_display_order=>80
,p_column_identifier=>'H'
,p_column_label=>'Est. Aprob.'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(274411019186425850)
,p_db_column_name=>'FACTURA'
,p_display_order=>90
,p_column_identifier=>'I'
,p_column_label=>'Factura'
,p_column_type=>'NUMBER'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(288717467386113101)
,p_db_column_name=>'FECHACREACION'
,p_display_order=>100
,p_column_identifier=>'J'
,p_column_label=>'Fec. Crea'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_format_mask=>'dd/mm/yyyy'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(288717521342113102)
,p_db_column_name=>'IDFLUJO'
,p_display_order=>110
,p_column_identifier=>'K'
,p_column_label=>'ID Flujo'
,p_column_type=>'NUMBER'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(288717606765113103)
,p_db_column_name=>'MONTO'
,p_display_order=>120
,p_column_identifier=>'L'
,p_column_label=>'Monto'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G990D00'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(288717770422113104)
,p_db_column_name=>'NUMEROLIQUIDACION'
,p_display_order=>130
,p_column_identifier=>'M'
,p_column_label=>unistr('N\00FAm. Liq.')
,p_column_type=>'NUMBER'
,p_column_alignment=>'CENTER'
,p_format_mask=>'000000'
,p_use_as_row_header=>'N'
,p_updated_on=>wwv_flow_imp.dz('20250317161729Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(288717820451113105)
,p_db_column_name=>'OBJETIVO'
,p_display_order=>140
,p_column_identifier=>'N'
,p_column_label=>'Objetivo'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(288718079596113107)
,p_db_column_name=>'TIPO'
,p_display_order=>160
,p_column_identifier=>'P'
,p_column_label=>'Tipo'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(288718171837113108)
,p_db_column_name=>'TIPOLIQUIDACION'
,p_display_order=>170
,p_column_identifier=>'Q'
,p_column_label=>'Tipo Liq.'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(288718230389113109)
,p_db_column_name=>'USUARIOFLUJO'
,p_display_order=>180
,p_column_identifier=>'R'
,p_column_label=>'Usr. Flujo'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(637865793461994207)
,p_db_column_name=>'RESPALDOS'
,p_display_order=>190
,p_column_identifier=>'T'
,p_column_label=>'-'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20250317163515Z')
,p_updated_on=>wwv_flow_imp.dz('20250317163532Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(288717930390113106)
,p_db_column_name=>'RUTAAPROBACION'
,p_display_order=>200
,p_column_identifier=>'O'
,p_column_label=>'-'
,p_column_link=>'f?p=100:104:&SESSION.::&DEBUG.::G_OBJETO,G_OBJETO_ID,G_TODO:#OBJETO#,#OBJETO_ID#,TRUE'
,p_column_linktext=>'#RUTAAPROBACION#'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
,p_updated_on=>wwv_flow_imp.dz('20250317202044Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(637865803626994208)
,p_db_column_name=>'VALORLIQUIDADO'
,p_display_order=>210
,p_column_identifier=>'U'
,p_column_label=>'Val. Liq.'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G990D00'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20250317195455Z')
,p_updated_on=>wwv_flow_imp.dz('20250317195455Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(637865969688994209)
,p_db_column_name=>'VALORPAGAR'
,p_display_order=>220
,p_column_identifier=>'V'
,p_column_label=>'Val. Pagar'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G990D00'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20250317195455Z')
,p_updated_on=>wwv_flow_imp.dz('20250317195455Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(637866094397994210)
,p_db_column_name=>'VALORDESCONTAR'
,p_display_order=>230
,p_column_identifier=>'W'
,p_column_label=>'Val. Desc.'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G990D00'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20250317195455Z')
,p_updated_on=>wwv_flow_imp.dz('20250317195455Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(637866176197994211)
,p_db_column_name=>'REGISTROS'
,p_display_order=>240
,p_column_identifier=>'X'
,p_column_label=>'Registros'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G990D00'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20250317195455Z')
,p_updated_on=>wwv_flow_imp.dz('20250317195455Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(637866260988994212)
,p_db_column_name=>'SUBTOTALCERO'
,p_display_order=>250
,p_column_identifier=>'Y'
,p_column_label=>'Sub. Total 0%'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G990D00'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20250317195455Z')
,p_updated_on=>wwv_flow_imp.dz('20250317195455Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(637866345151994213)
,p_db_column_name=>'SUBTOTALDOCE'
,p_display_order=>260
,p_column_identifier=>'Z'
,p_column_label=>'Sub Total IVA'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G990D00'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20250317195455Z')
,p_updated_on=>wwv_flow_imp.dz('20250317195455Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(637866444138994214)
,p_db_column_name=>'IVA'
,p_display_order=>270
,p_column_identifier=>'AA'
,p_column_label=>'IVA'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20250317195455Z')
,p_updated_on=>wwv_flow_imp.dz('20250317195808Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(637866562892994215)
,p_db_column_name=>'VALORTOTAL'
,p_display_order=>280
,p_column_identifier=>'AB'
,p_column_label=>'Val. Total'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G990D00'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20250317195455Z')
,p_updated_on=>wwv_flow_imp.dz('20250317195808Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(637866633843994216)
,p_db_column_name=>'OBJETO'
,p_display_order=>290
,p_column_identifier=>'AC'
,p_column_label=>'Objeto'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_created_on=>wwv_flow_imp.dz('20250317201959Z')
,p_updated_on=>wwv_flow_imp.dz('20250317201959Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(637866765349994217)
,p_db_column_name=>'OBJETO_ID'
,p_display_order=>300
,p_column_identifier=>'AD'
,p_column_label=>'Objeto Id'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_created_on=>wwv_flow_imp.dz('20250317201959Z')
,p_updated_on=>wwv_flow_imp.dz('20250317201959Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(288734911740115995)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'2887350'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'ID:TIPO:TIPOLIQUIDACION:USUARIOCREA:FECHACREACION:CENTROCOSTOS:CODIGOPROVEEDOR:ESTADO:ESTADOAPROBACION:MONTO:NUMEROLIQUIDACION:OBJETIVO'
,p_sort_column_1=>'ID'
,p_sort_direction_1=>'DESC'
,p_sort_column_2=>'0'
,p_sort_direction_2=>'ASC'
,p_sort_column_3=>'0'
,p_sort_direction_3=>'ASC'
,p_sort_column_4=>'0'
,p_sort_direction_4=>'ASC'
,p_sort_column_5=>'0'
,p_sort_direction_5=>'ASC'
,p_sort_column_6=>'0'
,p_sort_direction_6=>'ASC'
,p_created_on=>wwv_flow_imp.dz('20230705164634Z')
,p_updated_on=>wwv_flow_imp.dz('20250317163515Z')
,p_created_by=>'CVACA'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(637865184377994201)
,p_plug_name=>unistr('Par\00E1metros')
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(38289867500120143)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
,p_created_on=>wwv_flow_imp.dz('20250317155620Z')
,p_updated_on=>wwv_flow_imp.dz('20250317155657Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(743841927849926466)
,p_plug_name=>'Barra de acciones'
,p_region_template_options=>'#DEFAULT#:t-Form--stretchInputs'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(38289497777120142)
,p_plug_display_sequence=>5
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'REGION_POSITION_01'
,p_location=>null
,p_menu_id=>wwv_flow_imp.id(37761271469106475)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(37860983999106559)
,p_created_on=>wwv_flow_imp.dz('20250317160350Z')
,p_updated_on=>wwv_flow_imp.dz('20250317203029Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(637865587220994205)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(743841927849926466)
,p_button_name=>'BUSCAR'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860056812106557)
,p_button_image_alt=>'Buscar'
,p_icon_css_classes=>'fa-search'
,p_created_on=>wwv_flow_imp.dz('20250317160446Z')
,p_updated_on=>wwv_flow_imp.dz('20250317203029Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(637865237352994202)
,p_name=>'P106_TIPO'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(637865184377994201)
,p_prompt=>'Tipo'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'select distinct trim(tipo) ret, trim(tipo) dis from t_gliq_liquidacion where tipo is not null order by 1'
,p_lov_display_null=>'YES'
,p_lov_null_text=>'Seleccione'
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'NONE'
,p_created_on=>wwv_flow_imp.dz('20250317155620Z')
,p_updated_on=>wwv_flow_imp.dz('20250317155620Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(637865331920994203)
,p_name=>'P106_DESDE'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(637865184377994201)
,p_item_default=>'trunc(add_months(sysdate,-2),''month'')'
,p_item_default_type=>'EXPRESSION'
,p_item_default_language=>'PLSQL'
,p_prompt=>'Desde'
,p_display_as=>'NATIVE_DATE_PICKER_APEX'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'POPUP'
,p_attribute_03=>'NONE'
,p_attribute_06=>'NONE'
,p_attribute_09=>'N'
,p_attribute_11=>'N'
,p_attribute_13=>'VISIBLE'
,p_attribute_15=>'FOCUS'
,p_created_on=>wwv_flow_imp.dz('20250317155620Z')
,p_updated_on=>wwv_flow_imp.dz('20250317155924Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(637865416323994204)
,p_name=>'P106_HASTA'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(637865184377994201)
,p_item_default=>'sysdate'
,p_item_default_type=>'EXPRESSION'
,p_item_default_language=>'PLSQL'
,p_prompt=>'Hasta'
,p_display_as=>'NATIVE_DATE_PICKER_APEX'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'POPUP'
,p_attribute_03=>'NONE'
,p_attribute_06=>'NONE'
,p_attribute_09=>'N'
,p_attribute_11=>'N'
,p_attribute_13=>'VISIBLE'
,p_attribute_15=>'FOCUS'
,p_created_on=>wwv_flow_imp.dz('20250317155905Z')
,p_updated_on=>wwv_flow_imp.dz('20250317155924Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp.component_end;
end;
/
