prompt --application/pages/page_00124
begin
--   Manifest
--     PAGE: 00124
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>109
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_page.create_page(
 p_id=>124
,p_name=>unistr('Nueva Depuraci\00F3n')
,p_alias=>unistr('NUEVA-DEPURACI\00D3N')
,p_step_title=>unistr('Nueva Depuraci\00F3n')
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'18'
,p_created_on=>wwv_flow_imp.dz('20230929213028Z')
,p_last_updated_on=>wwv_flow_imp.dz('20230929212621Z')
,p_last_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(93759704996724815)
,p_plug_name=>'Datos'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(38289867500120143)
,p_plug_display_sequence=>30
,p_include_in_reg_disp_sel_yn=>'Y'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(94982084121588528)
,p_plug_name=>unistr('Par\00E1metros')
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(38289867500120143)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_plug_display_when_condition=>'APP_USER'
,p_plug_display_when_cond2=>'DDELACRUZ'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(94983903528588547)
,p_plug_name=>'Reportes'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(38289867500120143)
,p_plug_display_sequence=>40
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_plug_display_when_condition=>'P124_SECUENCIA'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(94984079867588548)
,p_plug_name=>'F0911'
,p_region_name=>'rptRegistros'
,p_parent_plug_id=>wwv_flow_imp.id(94983903528588547)
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(37806762584106520)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select apex_item.checkbox(p_idx => 1,p_value => x.glflag,p_item_id => x.rowid,p_attributes => case when x.glflag = ''1'' then ''CHECKED class = "CK01"'' else ''class = "CK01"'' end) seleccion, x.*',
'from t_finz_t0911 x where glseq = :p124_secuencia and :p124_tabla = ''F0911''',
unistr('and (case when :p124_estado in (''APROBACI\00D3N'',''APROBADO'') and x.glflag = ''1'' then 1 else 0 end) = (case when :p124_estado in (''APROBACI\00D3N'',''APROBADO'') then 1 else 0 end)')))
,p_plug_source_type=>'NATIVE_IR'
,p_ajax_items_to_submit=>'P124_SECUENCIA'
,p_plug_display_condition_type=>'EXISTS'
,p_plug_display_when_condition=>'select ''x'' from t_finz_t0911 x where glseq = :p124_secuencia and :p124_tabla = ''F0911'''
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'F0911'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(102153119855114102)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_control_break=>'N'
,p_show_highlight=>'N'
,p_show_computation=>'N'
,p_show_aggregate=>'N'
,p_show_chart=>'N'
,p_show_group_by=>'N'
,p_show_pivot=>'N'
,p_show_flashback=>'N'
,p_show_help=>'N'
,p_download_formats=>'XLSX'
,p_enable_mail_download=>'N'
,p_owner=>'DDELACRUZ'
,p_internal_uid=>102153119855114102
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(102153241344114103)
,p_db_column_name=>'SELECCION'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'-'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_column_alignment=>'CENTER'
,p_display_condition_type=>'NOT_EXISTS'
,p_display_condition=>unistr('select * from dual where :p124_estado in (''APROBACI\00D3N'',''APROBADO'')')
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(102153315087114104)
,p_db_column_name=>'GLFLAG'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Glflag'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(102153450144114105)
,p_db_column_name=>'GLSEQ'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Glseq'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(102153553056114106)
,p_db_column_name=>'GLRID'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Glrid'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(102153698008114107)
,p_db_column_name=>'GLKCO'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Glkco'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(102153719115114108)
,p_db_column_name=>'GLDCT'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'Gldct'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(102153897581114109)
,p_db_column_name=>'GLDOC'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>'Gldoc'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(102153979078114110)
,p_db_column_name=>'GLDGJ'
,p_display_order=>80
,p_column_identifier=>'H'
,p_column_label=>'Gldgj'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(102154050330114111)
,p_db_column_name=>'GLJELN'
,p_display_order=>90
,p_column_identifier=>'I'
,p_column_label=>'Gljeln'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(102154193663114112)
,p_db_column_name=>'GLEXTL'
,p_display_order=>100
,p_column_identifier=>'J'
,p_column_label=>'Glextl'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(102154201901114113)
,p_db_column_name=>'GLPOST'
,p_display_order=>110
,p_column_identifier=>'K'
,p_column_label=>'Glpost'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(102154394910114114)
,p_db_column_name=>'GLICU'
,p_display_order=>120
,p_column_identifier=>'L'
,p_column_label=>'Glicu'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(102154403193114115)
,p_db_column_name=>'GLICUT'
,p_display_order=>130
,p_column_identifier=>'M'
,p_column_label=>'Glicut'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(102154507283114116)
,p_db_column_name=>'GLDICJ'
,p_display_order=>140
,p_column_identifier=>'N'
,p_column_label=>'Gldicj'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(102154673090114117)
,p_db_column_name=>'GLDSYJ'
,p_display_order=>150
,p_column_identifier=>'O'
,p_column_label=>'Gldsyj'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(102154738339114118)
,p_db_column_name=>'GLTICU'
,p_display_order=>160
,p_column_identifier=>'P'
,p_column_label=>'Glticu'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(102154801021114119)
,p_db_column_name=>'GLCO'
,p_display_order=>170
,p_column_identifier=>'Q'
,p_column_label=>'Glco'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(102154924360114120)
,p_db_column_name=>'GLANI'
,p_display_order=>180
,p_column_identifier=>'R'
,p_column_label=>'Glani'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(102155016576114121)
,p_db_column_name=>'GLAM'
,p_display_order=>190
,p_column_identifier=>'S'
,p_column_label=>'Glam'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(102155136557114122)
,p_db_column_name=>'GLAID'
,p_display_order=>200
,p_column_identifier=>'T'
,p_column_label=>'Glaid'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(102155249520114123)
,p_db_column_name=>'GLMCU'
,p_display_order=>210
,p_column_identifier=>'U'
,p_column_label=>'Glmcu'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(102155381502114124)
,p_db_column_name=>'GLOBJ'
,p_display_order=>220
,p_column_identifier=>'V'
,p_column_label=>'Globj'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(102155446199114125)
,p_db_column_name=>'GLSUB'
,p_display_order=>230
,p_column_identifier=>'W'
,p_column_label=>'Glsub'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(102155508237114126)
,p_db_column_name=>'GLSBL'
,p_display_order=>240
,p_column_identifier=>'X'
,p_column_label=>'Glsbl'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(102155651380114127)
,p_db_column_name=>'GLSBLT'
,p_display_order=>250
,p_column_identifier=>'Y'
,p_column_label=>'Glsblt'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(102155710403114128)
,p_db_column_name=>'GLLT'
,p_display_order=>260
,p_column_identifier=>'Z'
,p_column_label=>'Gllt'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(102155850554114129)
,p_db_column_name=>'GLPN'
,p_display_order=>270
,p_column_identifier=>'AA'
,p_column_label=>'Glpn'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(102155989799114130)
,p_db_column_name=>'GLCTRY'
,p_display_order=>280
,p_column_identifier=>'AB'
,p_column_label=>'Glctry'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(102156062573114131)
,p_db_column_name=>'GLFY'
,p_display_order=>290
,p_column_identifier=>'AC'
,p_column_label=>'Glfy'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(102156141970114132)
,p_db_column_name=>'GLFQ'
,p_display_order=>300
,p_column_identifier=>'AD'
,p_column_label=>'Glfq'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(102156266032114133)
,p_db_column_name=>'GLCRCD'
,p_display_order=>310
,p_column_identifier=>'AE'
,p_column_label=>'Glcrcd'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(102156369210114134)
,p_db_column_name=>'GLCRR'
,p_display_order=>320
,p_column_identifier=>'AF'
,p_column_label=>'Glcrr'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(102156469083114135)
,p_db_column_name=>'GLHCRR'
,p_display_order=>330
,p_column_identifier=>'AG'
,p_column_label=>'Glhcrr'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(102156577192114136)
,p_db_column_name=>'GLHDGJ'
,p_display_order=>340
,p_column_identifier=>'AH'
,p_column_label=>'Glhdgj'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(102156691281114137)
,p_db_column_name=>'GLAA'
,p_display_order=>350
,p_column_identifier=>'AI'
,p_column_label=>'Glaa'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(102156735805114138)
,p_db_column_name=>'GLU'
,p_display_order=>360
,p_column_identifier=>'AJ'
,p_column_label=>'Glu'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(102156841779114139)
,p_db_column_name=>'GLUM'
,p_display_order=>370
,p_column_identifier=>'AK'
,p_column_label=>'Glum'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(102156923486114140)
,p_db_column_name=>'GLGLC'
,p_display_order=>380
,p_column_identifier=>'AL'
,p_column_label=>'Glglc'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(102157014359114141)
,p_db_column_name=>'GLRE'
,p_display_order=>390
,p_column_identifier=>'AM'
,p_column_label=>'Glre'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(102157185376114142)
,p_db_column_name=>'GLEXA'
,p_display_order=>400
,p_column_identifier=>'AN'
,p_column_label=>'Glexa'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(102157256195114143)
,p_db_column_name=>'GLEXR'
,p_display_order=>410
,p_column_identifier=>'AO'
,p_column_label=>'Glexr'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(102157318499114144)
,p_db_column_name=>'GLR1'
,p_display_order=>420
,p_column_identifier=>'AP'
,p_column_label=>'Glr1'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(102157414476114145)
,p_db_column_name=>'GLR2'
,p_display_order=>430
,p_column_identifier=>'AQ'
,p_column_label=>'Glr2'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(102157532634114146)
,p_db_column_name=>'GLR3'
,p_display_order=>440
,p_column_identifier=>'AR'
,p_column_label=>'Glr3'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(102157681139114147)
,p_db_column_name=>'GLSFX'
,p_display_order=>450
,p_column_identifier=>'AS'
,p_column_label=>'Glsfx'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(102157791569114148)
,p_db_column_name=>'GLODOC'
,p_display_order=>460
,p_column_identifier=>'AT'
,p_column_label=>'Glodoc'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(102157827927114149)
,p_db_column_name=>'GLODCT'
,p_display_order=>470
,p_column_identifier=>'AU'
,p_column_label=>'Glodct'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(102157929484114150)
,p_db_column_name=>'GLOSFX'
,p_display_order=>480
,p_column_identifier=>'AV'
,p_column_label=>'Glosfx'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(102158028749118101)
,p_db_column_name=>'GLPKCO'
,p_display_order=>490
,p_column_identifier=>'AW'
,p_column_label=>'Glpkco'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(102158159737118102)
,p_db_column_name=>'GLOKCO'
,p_display_order=>500
,p_column_identifier=>'AX'
,p_column_label=>'Glokco'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(102158220071118103)
,p_db_column_name=>'GLPDCT'
,p_display_order=>510
,p_column_identifier=>'AY'
,p_column_label=>'Glpdct'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(102158337746118104)
,p_db_column_name=>'GLAN8'
,p_display_order=>520
,p_column_identifier=>'AZ'
,p_column_label=>'Glan8'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(102158458743118105)
,p_db_column_name=>'GLCN'
,p_display_order=>530
,p_column_identifier=>'BA'
,p_column_label=>'Glcn'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(102158553180118106)
,p_db_column_name=>'GLDKJ'
,p_display_order=>540
,p_column_identifier=>'BB'
,p_column_label=>'Gldkj'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(102158668160118107)
,p_db_column_name=>'GLDKC'
,p_display_order=>550
,p_column_identifier=>'BC'
,p_column_label=>'Gldkc'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(102158713499118108)
,p_db_column_name=>'GLASID'
,p_display_order=>560
,p_column_identifier=>'BD'
,p_column_label=>'Glasid'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(102158875024118109)
,p_db_column_name=>'GLBRE'
,p_display_order=>570
,p_column_identifier=>'BE'
,p_column_label=>'Glbre'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(102158944088118110)
,p_db_column_name=>'GLRCND'
,p_display_order=>580
,p_column_identifier=>'BF'
,p_column_label=>'Glrcnd'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(102159092634118111)
,p_db_column_name=>'GLSUMM'
,p_display_order=>590
,p_column_identifier=>'BG'
,p_column_label=>'Glsumm'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(102159120280118112)
,p_db_column_name=>'GLPRGE'
,p_display_order=>600
,p_column_identifier=>'BH'
,p_column_label=>'Glprge'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(102159253709118113)
,p_db_column_name=>'GLTNN'
,p_display_order=>610
,p_column_identifier=>'BI'
,p_column_label=>'Gltnn'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(102159335094118114)
,p_db_column_name=>'GLALT1'
,p_display_order=>620
,p_column_identifier=>'BJ'
,p_column_label=>'Glalt1'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(102159432319118115)
,p_db_column_name=>'GLALT2'
,p_display_order=>630
,p_column_identifier=>'BK'
,p_column_label=>'Glalt2'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(102159521595118116)
,p_db_column_name=>'GLALT3'
,p_display_order=>640
,p_column_identifier=>'BL'
,p_column_label=>'Glalt3'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(102159650547118117)
,p_db_column_name=>'GLALT4'
,p_display_order=>650
,p_column_identifier=>'BM'
,p_column_label=>'Glalt4'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(102159761607118118)
,p_db_column_name=>'GLALT5'
,p_display_order=>660
,p_column_identifier=>'BN'
,p_column_label=>'Glalt5'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(102159859724118119)
,p_db_column_name=>'GLALT6'
,p_display_order=>670
,p_column_identifier=>'BO'
,p_column_label=>'Glalt6'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(102159986190118120)
,p_db_column_name=>'GLALT7'
,p_display_order=>680
,p_column_identifier=>'BP'
,p_column_label=>'Glalt7'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(102160085441118121)
,p_db_column_name=>'GLALT8'
,p_display_order=>690
,p_column_identifier=>'BQ'
,p_column_label=>'Glalt8'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(102160179606118122)
,p_db_column_name=>'GLALT9'
,p_display_order=>700
,p_column_identifier=>'BR'
,p_column_label=>'Glalt9'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(102160229552118123)
,p_db_column_name=>'GLALT0'
,p_display_order=>710
,p_column_identifier=>'BS'
,p_column_label=>'Glalt0'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(102160337706118124)
,p_db_column_name=>'GLALTT'
,p_display_order=>720
,p_column_identifier=>'BT'
,p_column_label=>'Glaltt'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(102160497375118125)
,p_db_column_name=>'GLALTU'
,p_display_order=>730
,p_column_identifier=>'BU'
,p_column_label=>'Glaltu'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(102160592899118126)
,p_db_column_name=>'GLALTV'
,p_display_order=>740
,p_column_identifier=>'BV'
,p_column_label=>'Glaltv'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(102160690236118127)
,p_db_column_name=>'GLALTW'
,p_display_order=>750
,p_column_identifier=>'BW'
,p_column_label=>'Glaltw'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(102160799767118128)
,p_db_column_name=>'GLALTX'
,p_display_order=>760
,p_column_identifier=>'BX'
,p_column_label=>'Glaltx'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(102160861210118129)
,p_db_column_name=>'GLALTZ'
,p_display_order=>770
,p_column_identifier=>'BY'
,p_column_label=>'Glaltz'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(102160978225118130)
,p_db_column_name=>'GLDLNA'
,p_display_order=>780
,p_column_identifier=>'BZ'
,p_column_label=>'Gldlna'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(102161032569118131)
,p_db_column_name=>'GLCFF1'
,p_display_order=>790
,p_column_identifier=>'CA'
,p_column_label=>'Glcff1'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(102161116126118132)
,p_db_column_name=>'GLCFF2'
,p_display_order=>800
,p_column_identifier=>'CB'
,p_column_label=>'Glcff2'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(102161222071118133)
,p_db_column_name=>'GLASM'
,p_display_order=>810
,p_column_identifier=>'CC'
,p_column_label=>'Glasm'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(102161367118118134)
,p_db_column_name=>'GLBC'
,p_display_order=>820
,p_column_identifier=>'CD'
,p_column_label=>'Glbc'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(102161465970118135)
,p_db_column_name=>'GLVINV'
,p_display_order=>830
,p_column_identifier=>'CE'
,p_column_label=>'Glvinv'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(102161564409118136)
,p_db_column_name=>'GLIVD'
,p_display_order=>840
,p_column_identifier=>'CF'
,p_column_label=>'Glivd'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(102161646828118137)
,p_db_column_name=>'GLWR01'
,p_display_order=>850
,p_column_identifier=>'CG'
,p_column_label=>'Glwr01'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(102161739479118138)
,p_db_column_name=>'GLPO'
,p_display_order=>860
,p_column_identifier=>'CH'
,p_column_label=>'Glpo'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(102161891662118139)
,p_db_column_name=>'GLPSFX'
,p_display_order=>870
,p_column_identifier=>'CI'
,p_column_label=>'Glpsfx'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(102161978408118140)
,p_db_column_name=>'GLDCTO'
,p_display_order=>880
,p_column_identifier=>'CJ'
,p_column_label=>'Gldcto'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(102162086777118141)
,p_db_column_name=>'GLLNID'
,p_display_order=>890
,p_column_identifier=>'CK'
,p_column_label=>'Gllnid'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(102162115499118142)
,p_db_column_name=>'GLWY'
,p_display_order=>900
,p_column_identifier=>'CL'
,p_column_label=>'Glwy'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(102162271466118143)
,p_db_column_name=>'GLWN'
,p_display_order=>910
,p_column_identifier=>'CM'
,p_column_label=>'Glwn'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(102162380596118144)
,p_db_column_name=>'GLFNLP'
,p_display_order=>920
,p_column_identifier=>'CN'
,p_column_label=>'Glfnlp'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(102162413583118145)
,p_db_column_name=>'GLOPSQ'
,p_display_order=>930
,p_column_identifier=>'CO'
,p_column_label=>'Glopsq'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(102162505156118146)
,p_db_column_name=>'GLJBCD'
,p_display_order=>940
,p_column_identifier=>'CP'
,p_column_label=>'Gljbcd'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(102162691190118147)
,p_db_column_name=>'GLJBST'
,p_display_order=>950
,p_column_identifier=>'CQ'
,p_column_label=>'Gljbst'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(102162796420118148)
,p_db_column_name=>'GLHMCU'
,p_display_order=>960
,p_column_identifier=>'CR'
,p_column_label=>'Glhmcu'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(102162828255118149)
,p_db_column_name=>'GLDOI'
,p_display_order=>970
,p_column_identifier=>'CS'
,p_column_label=>'Gldoi'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(102162982737118150)
,p_db_column_name=>'GLALID'
,p_display_order=>980
,p_column_identifier=>'CT'
,p_column_label=>'Glalid'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(102163045831118101)
,p_db_column_name=>'GLALTY'
,p_display_order=>990
,p_column_identifier=>'CU'
,p_column_label=>'Glalty'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(102163154332118102)
,p_db_column_name=>'GLDSVJ'
,p_display_order=>1000
,p_column_identifier=>'CV'
,p_column_label=>'Gldsvj'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(102163267828118103)
,p_db_column_name=>'GLTORG'
,p_display_order=>1010
,p_column_identifier=>'CW'
,p_column_label=>'Gltorg'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(102163396241118104)
,p_db_column_name=>'GLREG#'
,p_display_order=>1020
,p_column_identifier=>'CX'
,p_column_label=>'Glreg#'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(102163400128118105)
,p_db_column_name=>'GLPYID'
,p_display_order=>1030
,p_column_identifier=>'CY'
,p_column_label=>'Glpyid'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(102163513098118106)
,p_db_column_name=>'GLUSER'
,p_display_order=>1040
,p_column_identifier=>'CZ'
,p_column_label=>'Gluser'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(102163618054118107)
,p_db_column_name=>'GLPID'
,p_display_order=>1050
,p_column_identifier=>'DA'
,p_column_label=>'Glpid'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(102163745298118108)
,p_db_column_name=>'GLJOBN'
,p_display_order=>1060
,p_column_identifier=>'DB'
,p_column_label=>'Gljobn'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(102163810837118109)
,p_db_column_name=>'GLUPMJ'
,p_display_order=>1070
,p_column_identifier=>'DC'
,p_column_label=>'Glupmj'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(102163969867118110)
,p_db_column_name=>'GLUPMT'
,p_display_order=>1080
,p_column_identifier=>'DD'
,p_column_label=>'Glupmt'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(102164012301118111)
,p_db_column_name=>'GLABR1'
,p_display_order=>1090
,p_column_identifier=>'DE'
,p_column_label=>'Glabr1'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(102164198973118112)
,p_db_column_name=>'GLABR2'
,p_display_order=>1100
,p_column_identifier=>'DF'
,p_column_label=>'Glabr2'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(102164268673118113)
,p_db_column_name=>'GLABR3'
,p_display_order=>1110
,p_column_identifier=>'DG'
,p_column_label=>'Glabr3'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(102164338997118114)
,p_db_column_name=>'GLABR4'
,p_display_order=>1120
,p_column_identifier=>'DH'
,p_column_label=>'Glabr4'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(102164478793118115)
,p_db_column_name=>'GLABT1'
,p_display_order=>1130
,p_column_identifier=>'DI'
,p_column_label=>'Glabt1'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(102164509891118116)
,p_db_column_name=>'GLABT2'
,p_display_order=>1140
,p_column_identifier=>'DJ'
,p_column_label=>'Glabt2'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(102164660512118117)
,p_db_column_name=>'GLABT3'
,p_display_order=>1150
,p_column_identifier=>'DK'
,p_column_label=>'Glabt3'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(102164720699118118)
,p_db_column_name=>'GLABT4'
,p_display_order=>1160
,p_column_identifier=>'DL'
,p_column_label=>'Glabt4'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(102164847812118119)
,p_db_column_name=>'GLITM'
,p_display_order=>1170
,p_column_identifier=>'DM'
,p_column_label=>'Glitm'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(102164951091118120)
,p_db_column_name=>'GLPM01'
,p_display_order=>1180
,p_column_identifier=>'DN'
,p_column_label=>'Glpm01'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(102165077732118121)
,p_db_column_name=>'GLPM02'
,p_display_order=>1190
,p_column_identifier=>'DO'
,p_column_label=>'Glpm02'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(102165145452118122)
,p_db_column_name=>'GLPM03'
,p_display_order=>1200
,p_column_identifier=>'DP'
,p_column_label=>'Glpm03'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(102165295162118123)
,p_db_column_name=>'GLPM04'
,p_display_order=>1210
,p_column_identifier=>'DQ'
,p_column_label=>'Glpm04'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(102165308530118124)
,p_db_column_name=>'GLPM05'
,p_display_order=>1220
,p_column_identifier=>'DR'
,p_column_label=>'Glpm05'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(102165461779118125)
,p_db_column_name=>'GLPM06'
,p_display_order=>1230
,p_column_identifier=>'DS'
,p_column_label=>'Glpm06'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(102165587420118126)
,p_db_column_name=>'GLPM07'
,p_display_order=>1240
,p_column_identifier=>'DT'
,p_column_label=>'Glpm07'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(102165652714118127)
,p_db_column_name=>'GLPM08'
,p_display_order=>1250
,p_column_identifier=>'DU'
,p_column_label=>'Glpm08'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(102165741110118128)
,p_db_column_name=>'GLPM09'
,p_display_order=>1260
,p_column_identifier=>'DV'
,p_column_label=>'Glpm09'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(102165839311118129)
,p_db_column_name=>'GLPM10'
,p_display_order=>1270
,p_column_identifier=>'DW'
,p_column_label=>'Glpm10'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(102165981112118130)
,p_db_column_name=>'GLBCRC'
,p_display_order=>1280
,p_column_identifier=>'DX'
,p_column_label=>'Glbcrc'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(102166065921118131)
,p_db_column_name=>'GLCRRM'
,p_display_order=>1290
,p_column_identifier=>'DY'
,p_column_label=>'Glcrrm'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(102166193652118132)
,p_db_column_name=>'GLPRGF'
,p_display_order=>1300
,p_column_identifier=>'DZ'
,p_column_label=>'Glprgf'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(102166281303118133)
,p_db_column_name=>'GLTXA1'
,p_display_order=>1310
,p_column_identifier=>'EA'
,p_column_label=>'Gltxa1'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(102166331117118134)
,p_db_column_name=>'GLEXR1'
,p_display_order=>1320
,p_column_identifier=>'EB'
,p_column_label=>'Glexr1'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(102166451466118135)
,p_db_column_name=>'GLTXITM'
,p_display_order=>1330
,p_column_identifier=>'EC'
,p_column_label=>'Gltxitm'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(102166538042118136)
,p_db_column_name=>'GLACTB'
,p_display_order=>1340
,p_column_identifier=>'ED'
,p_column_label=>'Glactb'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(102166679203118137)
,p_db_column_name=>'GLGPF1'
,p_display_order=>1350
,p_column_identifier=>'EE'
,p_column_label=>'Glgpf1'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(102166788015118138)
,p_db_column_name=>'GLACR'
,p_display_order=>1360
,p_column_identifier=>'EF'
,p_column_label=>'Glacr'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(102166865107118139)
,p_db_column_name=>'GLDLNID'
,p_display_order=>1370
,p_column_identifier=>'EG'
,p_column_label=>'Gldlnid'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(102166918972118140)
,p_db_column_name=>'GLCKNU'
,p_display_order=>1380
,p_column_identifier=>'EH'
,p_column_label=>'Glcknu'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(102167011233118141)
,p_db_column_name=>'GLBUPC'
,p_display_order=>1390
,p_column_identifier=>'EI'
,p_column_label=>'Glbupc'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(102167113127118142)
,p_db_column_name=>'GLAHBU'
,p_display_order=>1400
,p_column_identifier=>'EJ'
,p_column_label=>'Glahbu'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(102167245169118143)
,p_db_column_name=>'GLEPGC'
,p_display_order=>1410
,p_column_identifier=>'EK'
,p_column_label=>'Glepgc'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(102167338027118144)
,p_db_column_name=>'GLJPGC'
,p_display_order=>1420
,p_column_identifier=>'EL'
,p_column_label=>'Gljpgc'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(102167453569118145)
,p_db_column_name=>'GLRC5'
,p_display_order=>1430
,p_column_identifier=>'EM'
,p_column_label=>'Glrc5'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(102167532430118146)
,p_db_column_name=>'GLSFXE'
,p_display_order=>1440
,p_column_identifier=>'EN'
,p_column_label=>'Glsfxe'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(102167677072118147)
,p_db_column_name=>'GLOFM'
,p_display_order=>1450
,p_column_identifier=>'EO'
,p_column_label=>'Glofm'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(102213080280123837)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'1022131'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'SELECCION:GLKCO:GLDCT:GLDOC:GLDGJ:GLJELN:GLEXTL:GLPOST:GLICU:GLICUT:GLDICJ:GLDSYJ:GLTICU:GLCO:GLANI:GLAM:GLAID:GLMCU:GLOBJ:GLSUB:GLSBL:GLSBLT:GLLT:GLPN:GLCTRY:GLFY:GLFQ:GLCRCD:GLCRR:GLHCRR:GLHDGJ:GLAA:GLU:GLUM:GLGLC:GLRE:GLEXA:GLEXR:GLR1:GLR2:GLR3:GL'
||'SFX:GLODOC:GLODCT:GLOSFX:GLPKCO:GLOKCO:GLPDCT:GLAN8:GLCN:GLDKJ:GLDKC:GLASID:GLBRE:GLRCND:GLSUMM:GLPRGE:GLTNN:GLALT1:GLALT2:GLALT3:GLALT4:GLALT5:GLALT6:GLALT7:GLALT8:GLALT9:GLALT0:GLALTT:GLALTU:GLALTV:GLALTW:GLALTX:GLALTZ:GLDLNA:GLCFF1:GLCFF2:GLASM:GL'
||'BC:GLVINV:GLIVD:GLWR01:GLPO:GLPSFX:GLDCTO:GLLNID:GLWY:GLWN:GLFNLP:GLOPSQ:GLJBCD:GLJBST:GLHMCU:GLDOI:GLALID:GLALTY:GLDSVJ:GLTORG:GLREG#:GLPYID:GLUSER:GLPID:GLJOBN:GLUPMJ:GLUPMT:GLABR1:GLABR2:GLABR3:GLABR4:GLABT1:GLABT2:GLABT3:GLABT4:GLITM:GLPM01:GLPM0'
||'2:GLPM03:GLPM04:GLPM05:GLPM06:GLPM07:GLPM08:GLPM09:GLPM10:GLBCRC:GLCRRM:GLPRGF:GLTXA1:GLEXR1:GLTXITM:GLACTB:GLGPF1:GLACR:GLDLNID:GLCKNU:GLBUPC:GLAHBU:GLEPGC:GLJPGC:GLRC5:GLSFXE:GLOFM:'
,p_created_on=>wwv_flow_imp.dz('20230929213028Z')
,p_updated_on=>wwv_flow_imp.dz('20230929213028Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(102223901809387031)
,p_plug_name=>'F4111'
,p_parent_plug_id=>wwv_flow_imp.id(94983903528588547)
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(37806762584106520)
,p_plug_display_sequence=>20
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select apex_item.checkbox(p_idx => 1,p_value => x.ilflag,p_item_id => x.rowid,p_attributes => case when x.ilflag = ''1'' then ''CHECKED class = "CK01"'' else ''class = "CK01"'' end) seleccion, x.*',
'from t_finz_t4111 x where ilseq = :p124_secuencia and :p124_tabla = ''F4111''',
unistr('and (case when :p124_estado in (''APROBACI\00D3N'',''APROBADO'') and x.ilflag = ''1'' then 1 else 0 end) = (case when :p124_estado in (''APROBACI\00D3N'',''APROBADO'') then 1 else 0 end)')))
,p_plug_source_type=>'NATIVE_IR'
,p_ajax_items_to_submit=>'P124_SECUENCIA'
,p_plug_display_condition_type=>'EXISTS'
,p_plug_display_when_condition=>'select ''x'' from t_finz_t4111 x where ilseq = :p124_secuencia and :p124_tabla = ''F4111'''
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'F4111'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(102224072713387032)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_control_break=>'N'
,p_show_highlight=>'N'
,p_show_computation=>'N'
,p_show_aggregate=>'N'
,p_show_chart=>'N'
,p_show_group_by=>'N'
,p_show_pivot=>'N'
,p_show_flashback=>'N'
,p_show_help=>'N'
,p_download_formats=>'XLSX'
,p_enable_mail_download=>'N'
,p_owner=>'DDELACRUZ'
,p_internal_uid=>102224072713387032
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(102224169348387033)
,p_db_column_name=>'SELECCION'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'-'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_column_alignment=>'CENTER'
,p_display_condition_type=>'NOT_EXISTS'
,p_display_condition=>unistr('select * from dual where :p124_estado in (''APROBACI\00D3N'',''APROBADO'')')
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(104396372130040128)
,p_db_column_name=>'ILFLAG'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Ilflag'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(104396408573040129)
,p_db_column_name=>'ILSEQ'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Ilseq'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(104396529516040130)
,p_db_column_name=>'ILRID'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Ilrid'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(104396665176040131)
,p_db_column_name=>'ILNLIN'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Ilnlin'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(104396782240040132)
,p_db_column_name=>'ILITM'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'Ilitm'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(104396842159040133)
,p_db_column_name=>'ILLITM'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>'Illitm'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(104396957247040134)
,p_db_column_name=>'ILAITM'
,p_display_order=>80
,p_column_identifier=>'H'
,p_column_label=>'Ilaitm'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(104397089123040135)
,p_db_column_name=>'ILMCU'
,p_display_order=>90
,p_column_identifier=>'I'
,p_column_label=>'Ilmcu'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(104397132232040136)
,p_db_column_name=>'ILLOCN'
,p_display_order=>100
,p_column_identifier=>'J'
,p_column_label=>'Illocn'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(104397261339040137)
,p_db_column_name=>'ILLOTN'
,p_display_order=>110
,p_column_identifier=>'K'
,p_column_label=>'Illotn'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(104397383488040138)
,p_db_column_name=>'ILPLOT'
,p_display_order=>120
,p_column_identifier=>'L'
,p_column_label=>'Ilplot'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(104397461183040139)
,p_db_column_name=>'ILSTUN'
,p_display_order=>130
,p_column_identifier=>'M'
,p_column_label=>'Ilstun'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(104397563692040140)
,p_db_column_name=>'ILLDSQ'
,p_display_order=>140
,p_column_identifier=>'N'
,p_column_label=>'Illdsq'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(104397660615040141)
,p_db_column_name=>'ILTRNO'
,p_display_order=>150
,p_column_identifier=>'O'
,p_column_label=>'Iltrno'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(104397789527040142)
,p_db_column_name=>'ILFRTO'
,p_display_order=>160
,p_column_identifier=>'P'
,p_column_label=>'Ilfrto'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(104397830873040143)
,p_db_column_name=>'ILLMCX'
,p_display_order=>170
,p_column_identifier=>'Q'
,p_column_label=>'Illmcx'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(104397911668040144)
,p_db_column_name=>'ILLOTS'
,p_display_order=>180
,p_column_identifier=>'R'
,p_column_label=>'Illots'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(104398096681040145)
,p_db_column_name=>'ILLOTP'
,p_display_order=>190
,p_column_identifier=>'S'
,p_column_label=>'Illotp'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(104398158652040146)
,p_db_column_name=>'ILLOTG'
,p_display_order=>200
,p_column_identifier=>'T'
,p_column_label=>'Illotg'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(104398219689040147)
,p_db_column_name=>'ILKIT'
,p_display_order=>210
,p_column_identifier=>'U'
,p_column_label=>'Ilkit'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(104398339666040148)
,p_db_column_name=>'ILMMCU'
,p_display_order=>220
,p_column_identifier=>'V'
,p_column_label=>'Ilmmcu'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(104398431564040149)
,p_db_column_name=>'ILDMCT'
,p_display_order=>230
,p_column_identifier=>'W'
,p_column_label=>'Ildmct'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(104398589615040150)
,p_db_column_name=>'ILDMCS'
,p_display_order=>240
,p_column_identifier=>'X'
,p_column_label=>'Ildmcs'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(104398818214045201)
,p_db_column_name=>'ILKCO'
,p_display_order=>250
,p_column_identifier=>'Y'
,p_column_label=>'Ilkco'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(104398971373045202)
,p_db_column_name=>'ILDOC'
,p_display_order=>260
,p_column_identifier=>'Z'
,p_column_label=>'Ildoc'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(104399035240045203)
,p_db_column_name=>'ILDCT'
,p_display_order=>270
,p_column_identifier=>'AA'
,p_column_label=>'Ildct'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(104399154112045204)
,p_db_column_name=>'ILSFX'
,p_display_order=>280
,p_column_identifier=>'AB'
,p_column_label=>'Ilsfx'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(104399201532045205)
,p_db_column_name=>'ILJELN'
,p_display_order=>290
,p_column_identifier=>'AC'
,p_column_label=>'Iljeln'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(104399370380045206)
,p_db_column_name=>'ILICU'
,p_display_order=>300
,p_column_identifier=>'AD'
,p_column_label=>'Ilicu'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(104399476570045207)
,p_db_column_name=>'ILDGL'
,p_display_order=>310
,p_column_identifier=>'AE'
,p_column_label=>'Ildgl'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(104399534786045208)
,p_db_column_name=>'ILGLPT'
,p_display_order=>320
,p_column_identifier=>'AF'
,p_column_label=>'Ilglpt'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(104399684676045209)
,p_db_column_name=>'ILDCTO'
,p_display_order=>330
,p_column_identifier=>'AG'
,p_column_label=>'Ildcto'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(104399704041045210)
,p_db_column_name=>'ILDOCO'
,p_display_order=>340
,p_column_identifier=>'AH'
,p_column_label=>'Ildoco'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(104399815541045211)
,p_db_column_name=>'ILKCOO'
,p_display_order=>350
,p_column_identifier=>'AI'
,p_column_label=>'Ilkcoo'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(104399993299045212)
,p_db_column_name=>'ILLNID'
,p_display_order=>360
,p_column_identifier=>'AJ'
,p_column_label=>'Illnid'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(104400082114045213)
,p_db_column_name=>'ILIPCD'
,p_display_order=>370
,p_column_identifier=>'AK'
,p_column_label=>'Ilipcd'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(104400150591045214)
,p_db_column_name=>'ILTRDJ'
,p_display_order=>380
,p_column_identifier=>'AL'
,p_column_label=>'Iltrdj'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(104400209502045215)
,p_db_column_name=>'ILTRUM'
,p_display_order=>390
,p_column_identifier=>'AM'
,p_column_label=>'Iltrum'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(104400338511045216)
,p_db_column_name=>'ILAN8'
,p_display_order=>400
,p_column_identifier=>'AN'
,p_column_label=>'Ilan8'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(104400489556045217)
,p_db_column_name=>'ILTREX'
,p_display_order=>410
,p_column_identifier=>'AO'
,p_column_label=>'Iltrex'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(104400580409045218)
,p_db_column_name=>'ILTREF'
,p_display_order=>420
,p_column_identifier=>'AP'
,p_column_label=>'Iltref'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(104400622086045219)
,p_db_column_name=>'ILRCD'
,p_display_order=>430
,p_column_identifier=>'AQ'
,p_column_label=>'Ilrcd'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(104400714846045220)
,p_db_column_name=>'ILTRQT'
,p_display_order=>440
,p_column_identifier=>'AR'
,p_column_label=>'Iltrqt'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(104400879598045221)
,p_db_column_name=>'ILUNCS'
,p_display_order=>450
,p_column_identifier=>'AS'
,p_column_label=>'Iluncs'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(104400912562045222)
,p_db_column_name=>'ILPAID'
,p_display_order=>460
,p_column_identifier=>'AT'
,p_column_label=>'Ilpaid'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(104401030345045223)
,p_db_column_name=>'ILTERM'
,p_display_order=>470
,p_column_identifier=>'AU'
,p_column_label=>'Ilterm'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(104401153841045224)
,p_db_column_name=>'ILUKID'
,p_display_order=>480
,p_column_identifier=>'AV'
,p_column_label=>'Ilukid'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(104401277706045225)
,p_db_column_name=>'ILTDAY'
,p_display_order=>490
,p_column_identifier=>'AW'
,p_column_label=>'Iltday'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(104401354545045226)
,p_db_column_name=>'ILUSER'
,p_display_order=>500
,p_column_identifier=>'AX'
,p_column_label=>'Iluser'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(104401462415045227)
,p_db_column_name=>'ILPID'
,p_display_order=>510
,p_column_identifier=>'AY'
,p_column_label=>'Ilpid'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(104401529389045228)
,p_db_column_name=>'ILCRDJ'
,p_display_order=>520
,p_column_identifier=>'AZ'
,p_column_label=>'Ilcrdj'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(104401604838045229)
,p_db_column_name=>'ILAID'
,p_display_order=>530
,p_column_identifier=>'BA'
,p_column_label=>'Ilaid'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(104401709871045230)
,p_db_column_name=>'ILASID'
,p_display_order=>540
,p_column_identifier=>'BB'
,p_column_label=>'Ilasid'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(104401871976045231)
,p_db_column_name=>'ILMCUZ'
,p_display_order=>550
,p_column_identifier=>'BC'
,p_column_label=>'Ilmcuz'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(104401967139045232)
,p_db_column_name=>'ILOBJ'
,p_display_order=>560
,p_column_identifier=>'BD'
,p_column_label=>'Ilobj'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(104402062377045233)
,p_db_column_name=>'ILSBL'
,p_display_order=>570
,p_column_identifier=>'BE'
,p_column_label=>'Ilsbl'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(104402112208045234)
,p_db_column_name=>'ILSUB'
,p_display_order=>580
,p_column_identifier=>'BF'
,p_column_label=>'Ilsub'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(104402294517045235)
,p_db_column_name=>'ILUOM2'
,p_display_order=>590
,p_column_identifier=>'BG'
,p_column_label=>'Iluom2'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(104402315949045236)
,p_db_column_name=>'ILCMOO'
,p_display_order=>600
,p_column_identifier=>'BH'
,p_column_label=>'Ilcmoo'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(104402446686045237)
,p_db_column_name=>'ILRE'
,p_display_order=>610
,p_column_identifier=>'BI'
,p_column_label=>'Ilre'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(104402584794045238)
,p_db_column_name=>'ILSBLT'
,p_display_order=>620
,p_column_identifier=>'BJ'
,p_column_label=>'Ilsblt'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(104402667825045239)
,p_db_column_name=>'ILSQOR'
,p_display_order=>630
,p_column_identifier=>'BK'
,p_column_label=>'Ilsqor'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(104402743170045240)
,p_db_column_name=>'ILVPEJ'
,p_display_order=>640
,p_column_identifier=>'BL'
,p_column_label=>'Ilvpej'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(104402858202045241)
,p_db_column_name=>'ILHDGJ'
,p_display_order=>650
,p_column_identifier=>'BM'
,p_column_label=>'Ilhdgj'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(104402934750045242)
,p_db_column_name=>'ILSHAN'
,p_display_order=>660
,p_column_identifier=>'BN'
,p_column_label=>'Ilshan'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(104403030154045243)
,p_db_column_name=>'ILOPSQ'
,p_display_order=>670
,p_column_identifier=>'BO'
,p_column_label=>'Ilopsq'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(104403115676045244)
,p_db_column_name=>'ILRFLN'
,p_display_order=>680
,p_column_identifier=>'BP'
,p_column_label=>'Ilrfln'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(104403246561045245)
,p_db_column_name=>'ILTGN'
,p_display_order=>690
,p_column_identifier=>'BQ'
,p_column_label=>'Iltgn'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(104403378642045246)
,p_db_column_name=>'ILLOTC'
,p_display_order=>700
,p_column_identifier=>'BR'
,p_column_label=>'Illotc'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(104403428553045247)
,p_db_column_name=>'ILSVDT'
,p_display_order=>710
,p_column_identifier=>'BS'
,p_column_label=>'Ilsvdt'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(104403594269045248)
,p_db_column_name=>'ILLRCD'
,p_display_order=>720
,p_column_identifier=>'BT'
,p_column_label=>'Illrcd'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(104403663720045249)
,p_db_column_name=>'ILRLOT'
,p_display_order=>730
,p_column_identifier=>'BU'
,p_column_label=>'Ilrlot'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(104403764519045250)
,p_db_column_name=>'ILLPNU'
,p_display_order=>740
,p_column_identifier=>'BV'
,p_column_label=>'Illpnu'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(104428655378079509)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'1044287'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'SELECCION:ILNLIN:ILITM:ILLITM:ILAITM:ILMCU:ILLOCN:ILLOTN:ILPLOT:ILSTUN:ILLDSQ:ILTRNO:ILFRTO:ILLMCX:ILLOTS:ILLOTP:ILLOTG:ILKIT:ILMMCU:ILDMCT:ILDMCS:ILKCO:ILDOC:ILDCT:ILSFX:ILJELN:ILICU:ILDGL:ILGLPT:ILDCTO:ILDOCO:ILKCOO:ILLNID:ILIPCD:ILTRDJ:ILTRUM:ILAN'
||'8:ILTREX:ILTREF:ILRCD:ILTRQT:ILUNCS:ILPAID:ILTERM:ILUKID:ILTDAY:ILUSER:ILPID:ILCRDJ:ILAID:ILASID:ILMCUZ:ILOBJ:ILSBL:ILSUB:ILUOM2:ILCMOO:ILRE:ILSBLT:ILSQOR:ILVPEJ:ILHDGJ:ILSHAN:ILOPSQ:ILRFLN:ILTGN:ILLOTC:ILSVDT:ILLRCD:ILRLOT:ILLPNU:'
,p_created_on=>wwv_flow_imp.dz('20230929213029Z')
,p_updated_on=>wwv_flow_imp.dz('20230929213029Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1603171513210923185)
,p_plug_name=>'Barra de Acciones'
,p_region_template_options=>'#DEFAULT#:t-Form--stretchInputs'
,p_plug_template=>wwv_flow_imp.id(38289497777120142)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'REGION_POSITION_01'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(93759900884724817)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(1603171513210923185)
,p_button_name=>'REGRESAR'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860056812106557)
,p_button_image_alt=>'Regresar'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'LEFT'
,p_button_redirect_url=>'f?p=&APP_ID.:123:&SESSION.::&DEBUG.:123::'
,p_icon_css_classes=>'fa-arrow-left'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(111974545129981950)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(1603171513210923185)
,p_button_name=>'GUARDAR'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860056812106557)
,p_button_image_alt=>'Guardar'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_button_condition=>'select * from dual where :p124_estado in (''PENDIENTE'',''INGRESADO'');'
,p_button_condition_type=>'EXISTS'
,p_icon_css_classes=>'fa-save'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(94982933398588537)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(1603171513210923185)
,p_button_name=>'PROCESAR'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860056812106557)
,p_button_image_alt=>'Procesar'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
,p_button_condition=>'select * from dual where :p124_secuencia is not null and :p124_estado in (''PENDIENTE'',''INGRESADO'')'
,p_button_condition_type=>'EXISTS'
,p_icon_css_classes=>'fa-wrench'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(102221988534387011)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(1603171513210923185)
,p_button_name=>'ENVIAR'
,p_button_action=>'REDIRECT_APP'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860056812106557)
,p_button_image_alt=>'Enviar'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=100:107:&SESSION.::&DEBUG.:::'
,p_button_condition=>'select * from dual where :p124_secuencia is not null and :p124_estado in (''PENDIENTE'')'
,p_button_condition_type=>'EXISTS'
,p_icon_css_classes=>'fa-send-o'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(102222525428387017)
,p_button_sequence=>50
,p_button_plug_id=>wwv_flow_imp.id(1603171513210923185)
,p_button_name=>'APROBAR'
,p_button_action=>'REDIRECT_APP'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860056812106557)
,p_button_image_alt=>'Aprobar'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=100:102:&SESSION.::&DEBUG.::G_COMPANIA,G_MODULO,G_USUARIO,G_OBJETO,G_OBJETO_ID,G_USUARIO_FLUJO:&G_COMPANIA.,&APP_MODULO.,&APP_USER.,DEPURADATOS,&P124_SECUENCIA.,&APP_USER.'
,p_button_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ''x'' from t_flujo_aprobacion_cab',
'where codmodulo = ''FINZ'' and estado = ''EN_PROCESO'' and entidad_clase = ''DEPURADATOS'' and entidad_id = :p124_secuencia and usuarioactual = :app_user'))
,p_button_condition_type=>'EXISTS'
,p_icon_css_classes=>'fa-thumbs-o-up'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(102223219056387024)
,p_button_sequence=>60
,p_button_plug_id=>wwv_flow_imp.id(1603171513210923185)
,p_button_name=>'RECHAZAR'
,p_button_action=>'REDIRECT_APP'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860056812106557)
,p_button_image_alt=>'Rechazar'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=100:103:&SESSION.::&DEBUG.::G_COMPANIA,G_MODULO,G_USUARIO,G_OBJETO,G_OBJETO_ID,G_USUARIO_FLUJO:&G_COMPANIA.,&APP_MODULO.,&APP_USER.,DEPURADATOS,&P124_SECUENCIA.,&APP_USER.'
,p_button_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ''x'' from t_flujo_aprobacion_cab',
'where codmodulo = ''FINZ'' and estado = ''EN_PROCESO'' and entidad_clase = ''DEPURADATOS'' and entidad_id = :p124_secuencia and usuarioactual = :app_user'))
,p_button_condition_type=>'EXISTS'
,p_icon_css_classes=>'fa-thumbs-o-down'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(102167769643118148)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(94983903528588547)
,p_button_name=>'SELECCION'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860056812106557)
,p_button_image_alt=>unistr('Guardar Selecci\00F3n')
,p_button_alignment=>'RIGHT'
,p_icon_css_classes=>'fa-table-plus'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(93759891942724816)
,p_name=>'P124_TABLA'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(93759704996724815)
,p_prompt=>'Tabla'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'STATIC:F0911 - Libro Mayor;F0911,F4111 - Kardex;F4111'
,p_lov_display_null=>'YES'
,p_lov_null_text=>'Seleccione'
,p_cHeight=>1
,p_read_only_when=>unistr('select * from dual where :p124_secuencia is not null and :p124_estado in (''APROBACI\00D3N'',''APROBADO'')')
,p_read_only_when_type=>'EXISTS'
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(93760094364724818)
,p_name=>'P124_FECHA'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(93759704996724815)
,p_prompt=>'Fecha'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select column_name dis, column_name ret',
'from all_tab_cols@jdedtadl where column_id is not null and table_name = :p124_tabla and data_type = ''NUMBER'' and data_precision = 6',
'order by column_id'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'Seleccione'
,p_lov_cascade_parent_items=>'P124_TABLA'
,p_ajax_items_to_submit=>'P124_TABLA'
,p_ajax_optimize_refresh=>'Y'
,p_cHeight=>1
,p_read_only_when=>unistr('select * from dual where :p124_secuencia is not null and :p124_estado in (''APROBACI\00D3N'',''APROBADO'')')
,p_read_only_when_type=>'EXISTS'
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(93760104451724819)
,p_name=>'P124_OPERACION'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(93759704996724815)
,p_prompt=>unistr('Operaci\00F3n')
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'STATIC2:Entre;BTW,Mayor que;MQ,Menor que;mQ,Mayor o Igual;MOI,Menor o Igual;mOI,Diferente;DIF'
,p_lov_display_null=>'YES'
,p_lov_null_text=>'Seleccione'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_read_only_when=>unistr('select * from dual where :p124_secuencia is not null and :p124_estado in (''APROBACI\00D3N'',''APROBADO'')')
,p_read_only_when_type=>'EXISTS'
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(93760286769724820)
,p_name=>'P124_DESDE'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(93759704996724815)
,p_item_default=>'trunc(add_months(sysdate,-1),''month'')'
,p_item_default_type=>'EXPRESSION'
,p_item_default_language=>'PLSQL'
,p_prompt=>'Desde'
,p_format_mask=>'dd/mm/yyyy'
,p_display_as=>'NATIVE_DATE_PICKER_APEX'
,p_cSize=>30
,p_read_only_when=>unistr('select * from dual where :p124_secuencia is not null and :p124_estado in (''APROBACI\00D3N'',''APROBADO'')')
,p_read_only_when_type=>'EXISTS'
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'POPUP'
,p_attribute_03=>'NONE'
,p_attribute_06=>'NONE'
,p_attribute_09=>'N'
,p_attribute_11=>'N'
,p_attribute_13=>'VISIBLE'
,p_attribute_15=>'IMAGE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(93760384761724821)
,p_name=>'P124_HASTA'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(93759704996724815)
,p_item_default=>'last_day(add_months(sysdate,-1))'
,p_item_default_type=>'EXPRESSION'
,p_item_default_language=>'PLSQL'
,p_prompt=>'Hasta'
,p_format_mask=>'dd/mm/yyyy'
,p_display_as=>'NATIVE_DATE_PICKER_APEX'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_read_only_when=>unistr('select * from dual where :p124_secuencia is not null and :p124_estado in (''APROBACI\00D3N'',''APROBADO'')')
,p_read_only_when_type=>'EXISTS'
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'POPUP'
,p_attribute_03=>'NONE'
,p_attribute_06=>'NONE'
,p_attribute_09=>'N'
,p_attribute_11=>'N'
,p_attribute_13=>'VISIBLE'
,p_attribute_15=>'IMAGE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(93760481463724822)
,p_name=>'P124_PARAMETRO1'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(93759704996724815)
,p_prompt=>unistr('Par\00E1metro 1')
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select column_name dis, column_name ret',
'from all_tab_cols@jdedtadl where column_id is not null and table_name = :p124_tabla and column_name != :p124_fecha',
'order by 1'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'Seleccione'
,p_lov_cascade_parent_items=>'P124_FECHA,P124_TABLA'
,p_ajax_items_to_submit=>'P124_FECHA,P124_TABLA'
,p_ajax_optimize_refresh=>'Y'
,p_cHeight=>1
,p_read_only_when=>unistr('select * from dual where :p124_secuencia is not null and :p124_estado in (''APROBACI\00D3N'',''APROBADO'')')
,p_read_only_when_type=>'EXISTS'
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(93760590830724823)
,p_name=>'P124_PARAMETRO2'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(93759704996724815)
,p_prompt=>unistr('Par\00E1metro 2')
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select column_name dis, column_name ret',
'from all_tab_cols@jdedtadl where column_id is not null and table_name = :p124_tabla and column_name != :p124_fecha',
'order by 1'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'Seleccione'
,p_lov_cascade_parent_items=>'P124_FECHA,P124_TABLA'
,p_ajax_items_to_submit=>'P124_FECHA,P124_TABLA'
,p_ajax_optimize_refresh=>'Y'
,p_cHeight=>1
,p_read_only_when=>unistr('select * from dual where :p124_secuencia is not null and :p124_estado in (''APROBACI\00D3N'',''APROBADO'')')
,p_read_only_when_type=>'EXISTS'
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(93760629781724824)
,p_name=>'P124_PARAMETRO3'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_imp.id(93759704996724815)
,p_prompt=>unistr('Par\00E1metro 3')
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select column_name dis, column_name ret',
'from all_tab_cols@jdedtadl where column_id is not null and table_name = :p124_tabla and column_name != :p124_fecha',
'order by 1'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'Seleccione'
,p_lov_cascade_parent_items=>'P124_FECHA,P124_TABLA'
,p_ajax_items_to_submit=>'P124_FECHA,P124_TABLA'
,p_ajax_optimize_refresh=>'Y'
,p_cHeight=>1
,p_read_only_when=>unistr('select * from dual where :p124_secuencia is not null and :p124_estado in (''APROBACI\00D3N'',''APROBADO'')')
,p_read_only_when_type=>'EXISTS'
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(93760779935724825)
,p_name=>'P124_PARAMETRO4'
,p_item_sequence=>120
,p_item_plug_id=>wwv_flow_imp.id(93759704996724815)
,p_prompt=>unistr('Par\00E1metro 4')
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select column_name dis, column_name ret',
'from all_tab_cols@jdedtadl where column_id is not null and table_name = :p124_tabla and column_name != :p124_fecha',
'order by 1'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'Seleccione'
,p_lov_cascade_parent_items=>'P124_FECHA,P124_TABLA'
,p_ajax_items_to_submit=>'P124_FECHA,P124_TABLA'
,p_ajax_optimize_refresh=>'Y'
,p_cHeight=>1
,p_read_only_when=>unistr('select * from dual where :p124_secuencia is not null and :p124_estado in (''APROBACI\00D3N'',''APROBADO'')')
,p_read_only_when_type=>'EXISTS'
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(93760866496724826)
,p_name=>'P124_PARAMETRO5'
,p_item_sequence=>140
,p_item_plug_id=>wwv_flow_imp.id(93759704996724815)
,p_prompt=>unistr('Par\00E1metro 5')
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select column_name dis, column_name ret',
'from all_tab_cols@jdedtadl where column_id is not null and table_name = :p124_tabla and column_name != :p124_fecha',
'order by 1'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'Seleccione'
,p_lov_cascade_parent_items=>'P124_FECHA,P124_TABLA'
,p_ajax_items_to_submit=>'P124_FECHA,P124_TABLA'
,p_ajax_optimize_refresh=>'Y'
,p_cHeight=>1
,p_read_only_when=>unistr('select * from dual where :p124_secuencia is not null and :p124_estado in (''APROBACI\00D3N'',''APROBADO'')')
,p_read_only_when_type=>'EXISTS'
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(93760974031724827)
,p_name=>'P124_VALOR1'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(93759704996724815)
,p_prompt=>'Valor 1'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_read_only_when=>unistr('select * from dual where :p124_secuencia is not null and :p124_estado in (''APROBACI\00D3N'',''APROBADO'')')
,p_read_only_when_type=>'EXISTS'
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(93761016245724828)
,p_name=>'P124_VALOR5'
,p_item_sequence=>160
,p_item_plug_id=>wwv_flow_imp.id(93759704996724815)
,p_prompt=>'Valor 5'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_read_only_when=>unistr('select * from dual where :p124_secuencia is not null and :p124_estado in (''APROBACI\00D3N'',''APROBADO'')')
,p_read_only_when_type=>'EXISTS'
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(93761104169724829)
,p_name=>'P124_VALOR4'
,p_item_sequence=>130
,p_item_plug_id=>wwv_flow_imp.id(93759704996724815)
,p_prompt=>'Valor 4'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_read_only_when=>unistr('select * from dual where :p124_secuencia is not null and :p124_estado in (''APROBACI\00D3N'',''APROBADO'')')
,p_read_only_when_type=>'EXISTS'
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(93761262635724830)
,p_name=>'P124_VALOR3'
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_imp.id(93759704996724815)
,p_prompt=>'Valor 3'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_read_only_when=>unistr('select * from dual where :p124_secuencia is not null and :p124_estado in (''APROBACI\00D3N'',''APROBADO'')')
,p_read_only_when_type=>'EXISTS'
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(93761393400724831)
,p_name=>'P124_VALOR2'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(93759704996724815)
,p_prompt=>'Valor 2'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_read_only_when=>unistr('select * from dual where :p124_secuencia is not null and :p124_estado in (''APROBACI\00D3N'',''APROBADO'')')
,p_read_only_when_type=>'EXISTS'
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(93761424109724832)
,p_name=>'P124_QUERY'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(94982084121588528)
,p_prompt=>'Query'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(94982167724588529)
,p_name=>'P124_SECUENCIA'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(94982084121588528)
,p_prompt=>'Secuencia'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(94982639601588534)
,p_name=>'P124_ESTADO'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(94982084121588528)
,p_prompt=>'Estado'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(102167955748118150)
,p_name=>'P124_TABLAID'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(94983903528588547)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(102220923949387001)
,p_name=>'P124_TABLAVALOR'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(94983903528588547)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(102221869036387010)
,p_name=>'P124_CANTIDAD'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(94982084121588528)
,p_prompt=>'Cantidad'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'with w0911 as (',
'    select count(1) qty from t_finz_t0911 where glseq = :p124_secuencia and glflag = 1',
'), w4111 as (',
'    select count(1) qty from t_finz_t4111 where ilseq = :p124_secuencia and ilflag = 1',
') select nvl(a.qty,0) + nvl(b.qty,0) from w0911 a, w4111 b'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(94979325132588501)
,p_name=>'PR'
,p_event_sequence=>10
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P124_OPERACION'
,p_condition_element=>'P124_OPERACION'
,p_triggering_condition_type=>'NULL'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(94979455011588502)
,p_event_id=>wwv_flow_imp.id(94979325132588501)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P124_DESDE,P124_HASTA'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(94981165675588519)
,p_event_id=>wwv_flow_imp.id(94979325132588501)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P124_DESDE,P124_HASTA'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(94979536767588503)
,p_name=>'P5'
,p_event_sequence=>20
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P124_PARAMETRO5'
,p_condition_element=>'P124_PARAMETRO5'
,p_triggering_condition_type=>'NULL'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(94979685361588504)
,p_event_id=>wwv_flow_imp.id(94979536767588503)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P124_VALOR5'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(94979702337588505)
,p_event_id=>wwv_flow_imp.id(94979536767588503)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P124_VALOR5'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(94980790645588515)
,p_name=>'P4'
,p_event_sequence=>30
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P124_PARAMETRO4'
,p_condition_element=>'P124_PARAMETRO4'
,p_triggering_condition_type=>'NULL'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(94980839220588516)
,p_event_id=>wwv_flow_imp.id(94980790645588515)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P124_VALOR4'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(94980909196588517)
,p_event_id=>wwv_flow_imp.id(94980790645588515)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P124_VALOR4'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(94980447894588512)
,p_name=>'P3'
,p_event_sequence=>40
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P124_PARAMETRO3'
,p_condition_element=>'P124_PARAMETRO3'
,p_triggering_condition_type=>'NULL'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(94980535869588513)
,p_event_id=>wwv_flow_imp.id(94980447894588512)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P124_VALOR3'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(94980608885588514)
,p_event_id=>wwv_flow_imp.id(94980447894588512)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P124_VALOR3'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(94980135120588509)
,p_name=>'P2'
,p_event_sequence=>50
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P124_PARAMETRO2'
,p_condition_element=>'P124_PARAMETRO2'
,p_triggering_condition_type=>'NULL'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(94980299106588510)
,p_event_id=>wwv_flow_imp.id(94980135120588509)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P124_VALOR2'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(94980341985588511)
,p_event_id=>wwv_flow_imp.id(94980135120588509)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P124_VALOR2'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(94979864973588506)
,p_name=>'P1'
,p_event_sequence=>60
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P124_PARAMETRO1'
,p_condition_element=>'P124_PARAMETRO1'
,p_triggering_condition_type=>'NULL'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(94979913981588507)
,p_event_id=>wwv_flow_imp.id(94979864973588506)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P124_VALOR1'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(94980075382588508)
,p_event_id=>wwv_flow_imp.id(94979864973588506)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P124_VALOR1'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(94981261571588520)
,p_name=>'FC'
,p_event_sequence=>70
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P124_FECHA'
,p_condition_element=>'P124_FECHA'
,p_triggering_condition_type=>'NULL'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(94981382445588521)
,p_event_id=>wwv_flow_imp.id(94981261571588520)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P124_OPERACION'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(94981484339588522)
,p_event_id=>wwv_flow_imp.id(94981261571588520)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P124_OPERACION'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(94981573067588523)
,p_name=>'OP'
,p_event_sequence=>80
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P124_OPERACION'
,p_condition_element=>'P124_OPERACION'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'BTW'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(94981622358588524)
,p_event_id=>wwv_flow_imp.id(94981573067588523)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P124_HASTA'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(94981851644588526)
,p_event_id=>wwv_flow_imp.id(94981573067588523)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P124_HASTA'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(94983002727588538)
,p_name=>'Procesar'
,p_event_sequence=>90
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(94982933398588537)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(94983527659588543)
,p_event_id=>wwv_flow_imp.id(94983002727588538)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'mostrarBarra();'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(94983155965588539)
,p_event_id=>wwv_flow_imp.id(94983002727588538)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'	pk_finz_reportes.sp_depuradatosjde(:g_compania,:app_user,:p124_secuencia);',
'end;'))
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(102221373178387005)
,p_event_id=>wwv_flow_imp.id(94983002727588538)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(94984079867588548)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(94983406997588542)
,p_event_id=>wwv_flow_imp.id(94983002727588538)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'ocultarBarra();'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(102221029661387002)
,p_name=>'Guarda Checkbox'
,p_event_sequence=>100
,p_triggering_element_type=>'JQUERY_SELECTOR'
,p_triggering_element=>'.CK01'
,p_condition_element=>'P124_ESTADO'
,p_triggering_condition_type=>'NOT_IN_LIST'
,p_triggering_expression=>unistr('APROBACI\00D3N,APROBADO')
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(102221134205387003)
,p_event_id=>wwv_flow_imp.id(102221029661387002)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'var i=$(this.triggeringElement).attr(''id'');',
'var v=$(this.triggeringElement).val();',
'console.log("cambio id:"+i+" valor:"+v)',
'apex.item("P124_TABLAVALOR").setValue(v);',
'apex.item("P124_TABLAID").setValue(i);',
'mensajeExito(''Cambios guardados'');'))
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(102221208131387004)
,p_event_id=>wwv_flow_imp.id(102221029661387002)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'    if :p124_tabla = ''F0911'' then',
'        update t_finz_t0911 x set x.glflag = case when x.glflag = 1 then null else 1 end where rowid = :p124_tablaid;',
'    elsif :p124_tabla = ''F4111'' then',
'        update t_finz_t4111 x set x.ilflag = case when x.ilflag = 1 then null else 1 end where rowid = :p124_tablaid;',
'    end if;',
'end;'))
,p_attribute_02=>'P124_TABLA,P124_TABLAID'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(102222045123387012)
,p_name=>unistr('Env\00EDa Aprobaci\00F3n')
,p_event_sequence=>110
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(102221988534387011)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(102222187050387013)
,p_event_id=>wwv_flow_imp.id(102222045123387012)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'mostrarBarra();'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(102222367832387015)
,p_event_id=>wwv_flow_imp.id(102222045123387012)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'v_secuencia	number;',
'v_app_usr	varchar2(10);',
'v_log_app	varchar2(50);',
'v_log_cia	varchar2(5);',
'v_app_mod	varchar2(5);',
'v_exito 	number;',
'v_id_error 	varchar(500);',
'v_id_exito 	varchar(500);',
'v_contador 	number := 0;',
'v_log_dsc 	varchar2(999);',
'v_cantidad	number;',
'v_tabla		varchar2(25);',
'begin',
'	v_log_app	:= ''apex.109.124.ruta'';',
'	v_secuencia := :p124_secuencia;',
'	v_log_cia	:= :g_compania;',
'	v_app_mod	:= :app_modulo;',
'	v_app_usr	:= :app_user;',
'	v_tabla		:= :p124_tabla;',
'	v_log_app := ''data.pk_finz_reportes.sp_depuradatosjde'';',
'',
'	v_log_dsc := ''v_secuencia: ''||v_secuencia||'', v_app_usr: ''||v_app_usr||'', v_tabla: ''||v_tabla;',
'	pk_commons.sp_apex_log(v_log_app,0,v_log_dsc,null,null,null); commit;',
'',
'	begin',
'		if v_tabla = ''F0911'' then',
'			select count(1) into v_cantidad from data.t_finz_t0911',
'			where glseq = v_secuencia and nvl(glflag,0) = 1;',
'		elsif v_tabla = ''F4111'' then',
'			select count(1) into v_cantidad from data.t_finz_t4111',
'			where ilseq = v_secuencia and nvl(ilflag,0) = 1;',
'		end if;',
'',
'		if nvl(v_cantidad,0) = 0 then',
'			raise_application_error(-20000,''No hay registros seleccionados para depurar.'');',
'			return;',
'		end if;',
'	end;',
'',
'	pk_corp_flujoaprobacion.sp_flujoenviar(',
'		p_id 					=> v_secuencia',
'		, p_objeto				=> ''DEPURADATOS''',
unistr('		, p_objetodescripcion	=> ''Depuraci\00F3n de Datos en JDE: ''||v_tabla'),
'		, p_usuario				=> v_app_usr',
'		, p_modulo				=> v_app_mod',
'		, p_compania			=> v_log_cia',
'		, p_comentario			=> null',
'		, p_tipo1				=> ''DEPURADATOS''',
'		, p_exito				=> v_exito',
'	);',
'',
'	if v_exito = 1 then',
unistr('		update data.t_apex_temporal x set control05 = ''APROBACI\00D3N'''),
'		where flag = ''CAB''',
'			and control01 = v_log_cia',
'			and control02 = v_app_mod',
'			and control03 = v_app_usr',
'			and control04 = v_log_app',
'			and num01 = v_secuencia;',
'',
unistr('		:p124_estado := ''APROBACI\00D3N'';'),
'	else',
unistr('		raise_application_error(-20000,''Error al env\00EDar a Ruta de Aprobaci\00F3n: ''||v_exito);'),
'	end if;',
'end;'))
,p_attribute_02=>'P124_SECUENCIA,P124_TABLA'
,p_attribute_03=>'P124_ESTADO'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(102222491917387016)
,p_event_id=>wwv_flow_imp.id(102222045123387012)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_02=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(102222275232387014)
,p_event_id=>wwv_flow_imp.id(102222045123387012)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'ocultarBarra();'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(102222661727387018)
,p_name=>unistr('Di\00E1logo Aprobar')
,p_event_sequence=>120
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(102222525428387017)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(102222952526387021)
,p_event_id=>wwv_flow_imp.id(102222661727387018)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'mostrarBarra();'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(102223026332387022)
,p_event_id=>wwv_flow_imp.id(102222661727387018)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'v_secuencia	number;',
'v_app_usr	varchar2(10);',
'v_log_app	varchar2(50);',
'v_log_cia	varchar2(5);',
'v_app_mod	varchar2(5);',
'begin',
'	v_secuencia := :p124_secuencia;',
'	v_log_cia := :g_compania;',
'	v_app_mod := :app_modulo;',
'	v_app_usr := :app_user;',
'	v_log_app := ''data.pk_finz_reportes.sp_depuradatosjde'';',
'',
'	--if nvl(:p124_cantidad,0) > 0 then',
'		update data.t_apex_temporal x set control05 = ''APROBADO''',
'		where flag = ''CAB''',
'			and control01 = v_log_cia',
'			and control02 = v_app_mod',
'			and control04 = v_log_app',
'			and num01 = v_secuencia;',
'',
'        if :p124_tabla = ''F0911'' then',
'		    delete from f0911@jdedtadl where rowid in (select glrid from t_finz_t0911 where glseq = v_secuencia and glflag = ''1'');',
'            delete from t_finz_t0911 where glseq = v_secuencia;',
'        elsif :p124_tabla = ''F4111'' then',
'            delete from f4111@jdedtadl where rowid in (select ilrid from t_finz_t4111 where ilseq = v_secuencia and ilflag = ''1'');',
'            delete from t_finz_t4111 where ilseq = v_secuencia;',
'        end if;',
'',
'		:p124_estado := ''APROBADO'';',
'	--end if;',
'end;'))
,p_attribute_02=>'P124_SECUENCIA,P124_CANTIDAD,P124_TABLA'
,p_attribute_03=>'P124_ESTADO'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(102223152880387023)
,p_event_id=>wwv_flow_imp.id(102222661727387018)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_02=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(102223361172387025)
,p_name=>unistr('Di\00E1logo Rechazar')
,p_event_sequence=>130
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(102223219056387024)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(102223489011387026)
,p_event_id=>wwv_flow_imp.id(102223361172387025)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'mostrarBarra();'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(102223584204387027)
,p_event_id=>wwv_flow_imp.id(102223361172387025)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'v_secuencia	number;',
'v_app_usr	varchar2(10);',
'v_log_app	varchar2(50);',
'v_log_cia	varchar2(5);',
'v_app_mod	varchar2(5);',
'begin',
'	v_secuencia := :p124_secuencia;',
'	v_log_cia := :g_compania;',
'	v_app_mod := :app_modulo;',
'	v_app_usr := :app_user;',
'	v_log_app := ''data.pk_finz_reportes.sp_depuradatosjde'';',
'',
'	if nvl(:p124_cantidad,0) > 0 then',
'		update data.t_apex_temporal x set control05 = ''RECHAZADO''',
'		where flag = ''CAB''',
'			and control01 = v_log_cia',
'			and control02 = v_app_mod',
'			and control04 = v_log_app',
'			and num01 = v_secuencia;',
'',
'		:p124_estado := ''RECHAZADO'';',
'	end if;',
'end;'))
,p_attribute_02=>'P124_SECUENCIA,P124_CANTIDAD'
,p_attribute_03=>'P124_ESTADO'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(102223691808387028)
,p_event_id=>wwv_flow_imp.id(102223361172387025)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_02=>'Y'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(102221438618387006)
,p_process_sequence=>10
,p_process_point=>'AFTER_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Cargar Datos'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'v_secuencia number;',
'begin',
'	v_secuencia := :p124_secuencia;',
'',
'	select txt01, txt02',
'		, txt03, txt04',
'		, txt05, txt06',
'		, txt07, txt08',
'		, txt09, txt10',
'		, txt11',
'		, txt12, txt13, data.pk_commons.f_jde2g(num02), data.pk_commons.f_jde2g(num03)',
'		, txt14',
'		, control05',
'	into ',
'		:p124_parametro1,:p124_valor1,',
'		:p124_parametro2,:p124_valor2,',
'		:p124_parametro3,:p124_valor3,',
'		:p124_parametro4,:p124_valor4,',
'		:p124_parametro5,:p124_valor5,',
'		:p124_query,',
'		:p124_fecha,:p124_operacion,:p124_desde,:p124_hasta,',
'		:p124_tabla,',
'		:p124_estado',
'	from data.t_apex_temporal where flag = ''CAB''',
'		and control01 = :g_compania',
'		and control02 = :app_modulo',
'		and control04 = ''data.pk_finz_reportes.sp_depuradatosjde''',
'		and num01 = v_secuencia;',
'',
'	exception when others then null;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>102221438618387006
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(111974476866981949)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Query'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'v_query varchar2(4000);',
'v_operacion varchar2(5);',
'v_jde_desde number;',
'v_jde_hasta number;',
'v_prm1		varchar2(25);',
'v_prm2		varchar2(25);',
'v_prm3		varchar2(25);',
'v_prm4		varchar2(25);',
'v_prm5		varchar2(25);',
'v_vlr1		varchar2(25);',
'v_vlr2		varchar2(25);',
'v_vlr3		varchar2(25);',
'v_vlr4		varchar2(25);',
'v_vlr5		varchar2(25);',
'begin',
'	v_operacion := :p124_operacion;',
'	v_jde_desde := data.pk_commons.f_g2jde(:p124_desde);',
'	v_jde_hasta := data.pk_commons.f_g2jde(:p124_hasta);',
'',
'	v_prm1 := lower(:p124_parametro1);',
'	v_prm2 := lower(:p124_parametro2);',
'	v_prm3 := lower(:p124_parametro3);',
'	v_prm4 := lower(:p124_parametro4);',
'	v_prm5 := lower(:p124_parametro5);',
'	v_vlr1 := :p124_valor1;',
'	v_vlr2 := :p124_valor2;',
'	v_vlr3 := :p124_valor3;',
'	v_vlr4 := :p124_valor4;',
'	v_vlr5 := :p124_valor5;',
'',
'	v_query := ''select * from ''||:p124_tabla||''@jdedtadl where ''||:p124_fecha||'' '';',
'	if v_operacion = ''BTW'' then',
'		v_query := v_query || ''between ''||v_jde_desde||'' and ''||v_jde_hasta || '' and '';',
'	elsif v_operacion = ''MQ'' then',
'		v_query := v_query || ''> ''||v_jde_desde || '' and '';',
'	elsif v_operacion = ''mQ'' then',
'		v_query := v_query || ''< ''||v_jde_desde || '' and '';',
'	elsif v_operacion = ''MOI'' then',
'		v_query := v_query || ''>= ''||v_jde_desde || '' and '';',
'	elsif v_operacion = ''mOI'' then',
'		v_query := v_query || ''<= ''||v_jde_desde || '' and '';',
'	elsif v_operacion = ''DIF'' then',
'		v_query := v_query || ''!= ''||v_jde_desde || '' and '';',
'	end if;',
'',
'	if v_prm1 is not null and v_vlr1 is not null then',
'		v_query := v_query || v_prm1 ||'' = "''||v_vlr1||''" and '';',
'	end if;',
'',
'	if v_prm2 is not null and v_vlr2 is not null then',
'		v_query := v_query || v_prm2 ||'' = "''||v_vlr2||''" and '';',
'	end if;',
'',
'	if v_prm3 is not null and v_vlr3 is not null then',
'		v_query := v_query || v_prm3 ||'' = "''||v_vlr3||''" and '';',
'	end if;',
'',
'	if v_prm4 is not null and v_vlr4 is not null then',
'		v_query := v_query || v_prm4 ||'' = "''||v_vlr4||''" and '';',
'	end if;',
'',
'	if v_prm5 is not null and v_vlr5 is not null then',
'		v_query := v_query || v_prm5 ||'' = "''||v_vlr5||''" and '';',
'	end if;',
'',
'	v_query := v_query || '' 1 = 1'';',
'',
'	v_query := replace(v_query,''"'','''''''');',
'',
'	data.pk_commons.sp_apex_log(''apex.109.124.query'',1,v_query,null,null,null); commit;',
'',
'	:p124_query := v_query;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(111974545129981950)
,p_internal_uid=>111974476866981949
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(94982273266588530)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Nuevo'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'--Crea el registro',
'declare',
'v_query varchar2(4000);',
'v_operacion varchar2(5);',
'v_secuencia	number;',
'v_app_seq	number;',
'v_app_usr	varchar2(10);',
'v_log_app	varchar2(50);',
'v_log_cia	varchar2(5);',
'v_app_mod	varchar2(5);',
'v_app_rid	rowid;',
'v_jde_desde number;',
'v_jde_hasta number;',
'v_estado	varchar2(10);',
'',
'v_tabla		varchar2(10);',
'v_fech		varchar2(25);',
'v_prm1		varchar2(25);',
'v_prm2		varchar2(25);',
'v_prm3		varchar2(25);',
'v_prm4		varchar2(25);',
'v_prm5		varchar2(25);',
'v_vlr1		varchar2(25);',
'v_vlr2		varchar2(25);',
'v_vlr3		varchar2(25);',
'v_vlr4		varchar2(25);',
'v_vlr5		varchar2(25);',
'begin',
'	v_secuencia := :p124_secuencia;',
'	v_log_cia := :g_compania;',
'	v_app_mod := :app_modulo;',
'	v_app_usr := :app_user;',
'	v_log_app := ''data.pk_finz_reportes.sp_depuradatosjde'';',
'',
'	v_operacion := :p124_operacion;',
'	v_jde_desde := data.pk_commons.f_g2jde(:p124_desde);',
'	v_jde_hasta := data.pk_commons.f_g2jde(:p124_hasta);',
'',
'	v_tabla := :p124_tabla;',
'	v_fech := :p124_fecha;',
'	v_prm1 := :p124_parametro1;',
'	v_prm2 := :p124_parametro2;',
'	v_prm3 := :p124_parametro3;',
'	v_prm4 := :p124_parametro4;',
'	v_prm5 := :p124_parametro5;',
'	v_vlr1 := :p124_valor1;',
'	v_vlr2 := :p124_valor2;',
'	v_vlr3 := :p124_valor3;',
'	v_vlr4 := :p124_valor4;',
'	v_vlr5 := :p124_valor5;',
'',
'	v_query := :p124_query;',
'',
'	if nvl(v_secuencia,0) = 0 then',
'		select seq_apex_secuencia.nextval, ''INGRESADO'' into v_secuencia, v_estado from dual;',
'',
'		insert into data.t_apex_temporal (flag,control01,control02,control03,control04,control05',
'			, num01',
'			, txt01, txt02',
'			, txt03, txt04',
'			, txt05, txt06',
'			, txt07, txt08',
'			, txt09, txt10',
'			, txt11',
'			, txt12, txt13, num02, num03',
'			, txt14',
'			)',
'		select ''CAB''',
'			, v_log_cia',
'			, v_app_mod',
'			, v_app_usr',
'			, v_log_app',
'			, v_estado',
'			, v_secuencia',
'			, v_prm1, v_vlr1',
'			, v_prm2, v_vlr2',
'			, v_prm3, v_vlr3',
'			, v_prm4, v_vlr4',
'			, v_prm5, v_vlr5',
'			, v_query',
'			, v_fech, v_operacion, v_jde_desde, v_jde_hasta',
'			, v_tabla',
'		from dual;',
'		:p124_secuencia := v_secuencia;',
'		:p124_estado	:= v_estado;',
'	else',
'		update data.t_apex_temporal x set',
'			txt01 = v_prm1',
'			, txt02 = v_vlr1',
'			, txt03 = v_prm2',
'			, txt04 = v_vlr2',
'			, txt05 = v_prm3',
'			, txt06 = v_vlr3',
'			, txt07 = v_prm4',
'			, txt08 = v_vlr4',
'			, txt09 = v_prm5',
'			, txt10 = v_vlr5',
'			, txt11 = v_query',
'			, txt12 = v_fech',
'			, txt13 = v_operacion',
'			, num02 = v_jde_desde',
'			, num03 = v_jde_hasta',
'			, txt14 = v_tabla',
'			, control05 = ''INGRESADO''',
'		where flag = ''CAB''',
'			and control01 = v_log_cia',
'			and control02 = v_app_mod',
'			and control03 = v_app_usr',
'			and control04 = v_log_app',
'			and num01 = v_secuencia;',
'	end if;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(111974545129981950)
,p_internal_uid=>94982273266588530
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(102221662426387008)
,p_process_sequence=>30
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>unistr('Guardar Selecci\00F3n')
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'v_secuencia	number;',
'v_app_usr	varchar2(10);',
'v_log_app	varchar2(50);',
'v_log_cia	varchar2(5);',
'v_app_mod	varchar2(5);',
'begin',
'	v_secuencia := :p124_secuencia;',
'	v_log_cia := :g_compania;',
'	v_app_mod := :app_modulo;',
'	v_app_usr := :app_user;',
'	v_log_app := ''data.pk_finz_reportes.sp_depuradatosjde'';',
'',
'	if nvl(:p124_cantidad,0) > 0 then',
'		update data.t_apex_temporal x set control05 = ''PENDIENTE''',
'		where flag = ''CAB''',
'			and control01 = v_log_cia',
'			and control02 = v_app_mod',
'			and control04 = v_log_app',
'			and num01 = v_secuencia;',
'',
'		:p124_estado := ''PENDIENTE'';',
'	end if;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(102167769643118148)
,p_internal_uid=>102221662426387008
);
wwv_flow_imp.component_end;
end;
/
