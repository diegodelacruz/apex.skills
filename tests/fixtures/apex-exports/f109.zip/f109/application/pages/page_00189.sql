prompt --application/pages/page_00189
begin
--   Manifest
--     PAGE: 00189
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>109
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_page.create_page(
 p_id=>189
,p_name=>'GESTION TRIBUTARIA - PARAMETRIZACION VALIDACIONES'
,p_alias=>'GESTION-TRIBUTARIA-PARAMETRIZACION-VALIDACIONES'
,p_page_mode=>'MODAL'
,p_step_title=>unistr('Configuraci\00F3n de Validaciones')
,p_autocomplete_on_off=>'OFF'
,p_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'function removeFreezeColumnOption() {',
'    $(".a-IG-headerMenu-item:contains(''Freeze Column'')").hide();',
'}',
''))
,p_javascript_code_onload=>wwv_flow_string.join(wwv_flow_t_varchar2(
'$(secItems).hide();',
'moverToolbar();',
'removeFreezeColumnOption();'))
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.ui-dialog .ui-dialog-titlebar-close {',
'    position: absolute;',
'    right: 12px;',
'    top: 12px;',
'    width: 24px;',
'    margin: 0;',
'    padding: 0;',
'    height: 24px;',
'    border-radius: 100%;',
'    display: none;',
'}'))
,p_page_template_options=>'#DEFAULT#:ui-dialog--stretch'
,p_protection_level=>'C'
,p_page_component_map=>'21'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1101431528807767184)
,p_plug_name=>'Validaciones'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(37806762584106520)
,p_plug_display_sequence=>10
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
unistr('    SEQ_ID,  -- ID \00FAnico de la colecci\00F3n'),
'    C001, ',
'    C002, ',
'    C003, ',
'    C004, ',
'    C005, ',
'    C006',
'FROM APEX_COLLECTIONS ',
'WHERE COLLECTION_NAME = ''COLECCION_VALIDACIONES'''))
,p_plug_source_type=>'NATIVE_IG'
,p_plug_read_only_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_plug_read_only_when=>'P189_READONLY'
,p_plug_read_only_when2=>'1'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'Condiciones v2'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(554594929111141610)
,p_name=>'C005'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'C005'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_SELECT_LIST'
,p_heading=>'Error'
,p_heading_alignment=>'CENTER'
,p_display_sequence=>80
,p_value_alignment=>'LEFT'
,p_is_required=>false
,p_lov_type=>'SQL_QUERY'
,p_lov_source=>'SELECT ID_TABLA ||'' - ''||DESCRIPCION DESCRIPCION , ID_TABLA FROM "DATA"."T_CORP_UDC" WHERE ID_CABECERA=''FINZ_GT06'' AND ID_TABLA liKE ''E%'' ORDER BY 1;'
,p_lov_display_extra=>true
,p_lov_display_null=>true
,p_lov_null_text=>'Seleccione'
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(554595010349141611)
,p_name=>'C006'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'C006'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_SELECT_LIST'
,p_heading=>'Advertencia'
,p_heading_alignment=>'CENTER'
,p_display_sequence=>90
,p_value_alignment=>'LEFT'
,p_is_required=>false
,p_lov_type=>'SQL_QUERY'
,p_lov_source=>'SELECT ID_TABLA ||'' - ''||DESCRIPCION DESCRIPCION , ID_TABLA FROM "DATA"."T_CORP_UDC" WHERE ID_CABECERA=''FINZ_GT06'' AND ID_TABLA liKE ''W%'' ORDER BY 1;'
,p_lov_display_extra=>true
,p_lov_display_null=>true
,p_lov_null_text=>'Seleccione'
,p_lov_cascade_parent_items=>'C004'
,p_ajax_optimize_refresh=>true
,p_filter_is_required=>false
,p_use_as_row_header=>false
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(1101431684388767186)
,p_name=>'SEQ_ID'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'SEQ_ID'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_DISPLAY_ONLY'
,p_heading=>'Seq Id'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>30
,p_value_alignment=>'LEFT'
,p_attribute_02=>'VALUE'
,p_attribute_05=>'PLAIN'
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>true
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(1101431820277767187)
,p_name=>'C001'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'C001'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_RADIOGROUP'
,p_heading=>unistr('Operador L\00F3gico')
,p_heading_alignment=>'CENTER'
,p_display_sequence=>40
,p_value_alignment=>'LEFT'
,p_attribute_01=>'2'
,p_is_required=>false
,p_lov_type=>'SHARED'
,p_lov_id=>wwv_flow_imp.id(542425739667048154)
,p_lov_display_extra=>false
,p_lov_display_null=>false
,p_enable_filter=>false
,p_filter_is_required=>false
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_enable_hide=>false
,p_is_primary_key=>false
,p_default_type=>'STATIC'
,p_default_expression=>'AND'
,p_duplicate_value=>true
,p_include_in_export=>false
,p_escape_on_http_output=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(1101431941882767188)
,p_name=>'C002'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'C002'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_POPUP_LOV'
,p_heading=>'Columna'
,p_heading_alignment=>'CENTER'
,p_display_sequence=>50
,p_value_alignment=>'CENTER'
,p_attribute_01=>'POPUP'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_04=>'Y'
,p_attribute_05=>'Y'
,p_attribute_06=>'0'
,p_attribute_08=>'400'
,p_is_required=>false
,p_max_length=>4000
,p_lov_type=>'SQL_QUERY'
,p_lov_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'with tablesObjetos as (SELECT  TO_CHAR(ITEM) TABLENAME FROM TABLE(PK_COMMONS.F_DIVIDIRTEXTO(:P189_OBJETO,'':'')))',
',tablesJDE as (',
'    SELECT DISTINCT C.TABLE_NAME||''.''||c.COLUMN_NAME D,C.TABLE_NAME||''.''||c.COLUMN_NAME R,C.TABLE_NAME, c.COLUMN_NAME,c.COLUMN_ID id FROM ALL_TAB_COLUMNS@JDEDTADL C INNER JOIN tablesObjetos  I ON C.TABLE_NAME =I.TABLENAME',
'    order by C.TABLE_NAME,c.COLUMN_ID',
')',
',tablesDTA as (',
'    SELECT DISTINCT C.TABLE_NAME||''.''||c.COLUMN_NAME D,C.TABLE_NAME||''.''||c.COLUMN_NAME R,C.TABLE_NAME, c.COLUMN_NAME,c.COLUMN_ID id FROM ALL_TAB_COLUMNS  C INNER JOIN tablesObjetos  I ON C.TABLE_NAME =I.TABLENAME',
'     order by C.TABLE_NAME,c.COLUMN_ID',
')',
'SELECT d,r FROM tablesJDE UNION ALL',
'SELECT d,r FROM tablesDTA;'))
,p_lov_display_extra=>true
,p_lov_display_null=>true
,p_enable_filter=>false
,p_filter_is_required=>false
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_enable_hide=>false
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(1101431981779767189)
,p_name=>'C003'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'C003'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_SELECT_LIST'
,p_heading=>'Operador Relacional'
,p_heading_alignment=>'CENTER'
,p_display_sequence=>60
,p_value_alignment=>'CENTER'
,p_is_required=>false
,p_lov_type=>'SQL_QUERY'
,p_lov_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT d,r FROM (SELECT CASE WHEN ID<=6 THEN CAMPO1 ||'' '' ELSE '''' END ||CAMPO2 d,campo1 r',
'FROM TABLE(PK_COMMONS.f_split2table(''=:IGUAL|<:MENOR|>:MAYOR|<=:MENOR IGUAL|>=:MAYOR IGUAL|<>:DIFERENTE|IS_NULL:ES NULO|IS_NOT_NULL:NO ES NULO|IN:DENTRO (SEPARADO POR COMAS)|NOT_IN:NO DENTRO (SEPARADO POR COMAS)|BETWEEN:ENTRE|NOT_BETWEEN:NO ENTRE|LIK'
||'E:CONTIENE|NOT_LIKE:NO CONTIENE'','':'',''|'') ) A order by id);'))
,p_lov_display_extra=>true
,p_lov_display_null=>true
,p_lov_null_text=>'Seleccione'
,p_enable_filter=>false
,p_filter_is_required=>false
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_enable_hide=>false
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(1101432090673767190)
,p_name=>'C004'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'C004'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_POPUP_LOV'
,p_heading=>'Valor'
,p_heading_alignment=>'CENTER'
,p_display_sequence=>70
,p_value_alignment=>'LEFT'
,p_attribute_01=>'POPUP'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_04=>'Y'
,p_attribute_05=>'Y'
,p_attribute_06=>'0'
,p_is_required=>false
,p_max_length=>4000
,p_lov_type=>'SQL_QUERY'
,p_lov_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'',
'',
' SELECT  NVL(PARAMETRO,''NO EXISTEN PARAMETROS CONFIGURADOS'')  D,PARAMETRO R',
'        FROM JSON_TABLE(',
'            :G_GT_PARAMETROS, -- tu variable o columna con el JSON',
'            ''$[*]'' -- indica que es un arreglo',
'            COLUMNS (',
'                PARAMETRO   VARCHAR2(3999) PATH ''$.PARAMETRO''',
'            )',
'        )',
'UNION ALL',
'select * from (',
'    with tablesObjetos as (SELECT  TO_CHAR(ITEM) TABLENAME FROM TABLE(PK_COMMONS.F_DIVIDIRTEXTO(:P189_OBJETO,'':''))  )',
'    ,tablesJDE as (',
'        SELECT DISTINCT C.TABLE_NAME||''.''||c.COLUMN_NAME D,C.TABLE_NAME||''.''||c.COLUMN_NAME R,C.TABLE_NAME, c.COLUMN_NAME,c.COLUMN_ID id FROM ALL_TAB_COLUMNS@JDEDTADL C INNER JOIN tablesObjetos  I ON C.TABLE_NAME =I.TABLENAME',
'        order by C.TABLE_NAME,c.COLUMN_ID',
'    )',
'    ,tablesDTA as (',
'        SELECT DISTINCT C.TABLE_NAME||''.''||c.COLUMN_NAME D,C.TABLE_NAME||''.''||c.COLUMN_NAME R,C.TABLE_NAME, c.COLUMN_NAME,c.COLUMN_ID id FROM ALL_TAB_COLUMNS  C INNER JOIN tablesObjetos  I ON C.TABLE_NAME =I.TABLENAME',
'         order by C.TABLE_NAME,c.COLUMN_ID',
'    )',
'    SELECT d,r FROM tablesJDE UNION ALL',
'    SELECT d,r FROM tablesDTA ',
')',
'',
''))
,p_lov_display_extra=>true
,p_lov_display_null=>true
,p_enable_filter=>false
,p_filter_is_required=>false
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_enable_hide=>false
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(1101432745277767196)
,p_name=>'APEX$ROW_ACTION'
,p_session_state_data_type=>'VARCHAR2'
,p_item_type=>'NATIVE_ROW_ACTION'
,p_display_sequence=>20
,p_use_as_row_header=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(1101432791896767197)
,p_name=>'APEX$ROW_SELECTOR'
,p_session_state_data_type=>'VARCHAR2'
,p_item_type=>'NATIVE_ROW_SELECTOR'
,p_display_sequence=>10
,p_attribute_01=>'Y'
,p_attribute_02=>'Y'
,p_attribute_03=>'N'
,p_use_as_row_header=>false
);
wwv_flow_imp_page.create_interactive_grid(
 p_id=>wwv_flow_imp.id(1101431672808767185)
,p_internal_uid=>1101431672808767185
,p_is_editable=>true
,p_edit_operations=>'i:u:d'
,p_lost_update_check_type=>'VALUES'
,p_add_row_if_empty=>false
,p_submit_checked_rows=>false
,p_lazy_loading=>false
,p_requires_filter=>false
,p_select_first_row=>true
,p_fixed_row_height=>true
,p_pagination_type=>'SET'
,p_show_total_row_count=>false
,p_show_toolbar=>true
,p_enable_save_public_report=>false
,p_enable_subscriptions=>true
,p_enable_flashback=>false
,p_define_chart_view=>false
,p_enable_download=>false
,p_download_formats=>null
,p_enable_mail_download=>true
,p_fixed_header=>'PAGE'
,p_show_icon_view=>false
,p_show_detail_view=>false
,p_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'function (config) {',
'	return cargarToolbar(config);',
'}'))
);
wwv_flow_imp_page.create_ig_report(
 p_id=>wwv_flow_imp.id(1102727696925292656)
,p_interactive_grid_id=>wwv_flow_imp.id(1101431672808767185)
,p_static_id=>'5480922'
,p_type=>'PRIMARY'
,p_default_view=>'GRID'
,p_show_row_number=>false
,p_settings_area_expanded=>true
);
wwv_flow_imp_page.create_ig_report_view(
 p_id=>wwv_flow_imp.id(1102727910251292657)
,p_report_id=>wwv_flow_imp.id(1102727696925292656)
,p_view_type=>'GRID'
,p_stretch_columns=>true
,p_srv_exclude_null_values=>false
,p_srv_only_display_columns=>true
,p_edit_mode=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(554648781666288956)
,p_view_id=>wwv_flow_imp.id(1102727910251292657)
,p_display_seq=>7
,p_column_id=>wwv_flow_imp.id(554594929111141610)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>247
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(554652667957411128)
,p_view_id=>wwv_flow_imp.id(1102727910251292657)
,p_display_seq=>8
,p_column_id=>wwv_flow_imp.id(554595010349141611)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>247
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(1102728420000292663)
,p_view_id=>wwv_flow_imp.id(1102727910251292657)
,p_display_seq=>2
,p_column_id=>wwv_flow_imp.id(1101431684388767186)
,p_is_visible=>false
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(1102729319854292668)
,p_view_id=>wwv_flow_imp.id(1102727910251292657)
,p_display_seq=>3
,p_column_id=>wwv_flow_imp.id(1101431820277767187)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>113
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(1102730254179292670)
,p_view_id=>wwv_flow_imp.id(1102727910251292657)
,p_display_seq=>4
,p_column_id=>wwv_flow_imp.id(1101431941882767188)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>171
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(1102731122960292673)
,p_view_id=>wwv_flow_imp.id(1102727910251292657)
,p_display_seq=>5
,p_column_id=>wwv_flow_imp.id(1101431981779767189)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>174
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(1102732055561292675)
,p_view_id=>wwv_flow_imp.id(1102727910251292657)
,p_display_seq=>6
,p_column_id=>wwv_flow_imp.id(1101432090673767190)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>247
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(1102740529192297150)
,p_view_id=>wwv_flow_imp.id(1102727910251292657)
,p_display_seq=>1
,p_column_id=>wwv_flow_imp.id(1101432745277767196)
,p_is_visible=>false
,p_is_frozen=>true
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1636274548292951845)
,p_plug_name=>'items'
,p_region_name=>'secItems'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(38289867500120143)
,p_plug_display_sequence=>40
,p_include_in_reg_disp_sel_yn=>'Y'
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1636276493725951864)
,p_plug_name=>'Botones'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(38290276266120143)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'REGION_POSITION_03'
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(554637652863267687)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(1636276493725951864)
,p_button_name=>'Cerrar'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860181880106559)
,p_button_image_alt=>'Cerrar'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(554641824825267696)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(1101431528807767184)
,p_button_name=>'Cancelar'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860056812106557)
,p_button_image_alt=>'Cancelar'
,p_button_position=>'RIGHT_OF_TITLE'
,p_confirm_message=>unistr('\00BFEst\00E1 seguro de que quiere revertir los cambios generados?')
,p_confirm_style=>'warning'
,p_button_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT distinct',
'1',
'FROM APEX_COLLECTIONS ',
'WHERE COLLECTION_NAME = ''COLECCION_VALIDACIONES'''))
,p_button_condition_type=>'EXISTS'
,p_button_css_classes=>'btnAccion'
,p_icon_css_classes=>'fa-undo-alt'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(554642234839267696)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(1101431528807767184)
,p_button_name=>'Limpiar'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860056812106557)
,p_button_image_alt=>'Limpiar'
,p_button_position=>'RIGHT_OF_TITLE'
,p_confirm_message=>unistr('\00BFEst\00E1 seguro de que quiere limpiar todas las condiciones generadas?')
,p_confirm_style=>'warning'
,p_button_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT distinct',
'1',
'FROM APEX_COLLECTIONS ',
'WHERE COLLECTION_NAME = ''COLECCION_VALIDACIONES'''))
,p_button_condition_type=>'EXISTS'
,p_button_css_classes=>'btnAccion'
,p_icon_css_classes=>'fa-window-ban'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(554636180407267686)
,p_name=>'P189_OBJETO'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(1636274548292951845)
,p_prompt=>'Objeto'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(554636513568267686)
,p_name=>'P189_READONLY'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(1636274548292951845)
,p_prompt=>'Readonly'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(554636907543267686)
,p_name=>'P189_LOADPAGE'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(1636274548292951845)
,p_prompt=>'Loadpage'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(554644249148267700)
,p_name=>'Carga Collection'
,p_event_sequence=>120
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(1101431528807767184)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'NATIVE_IG|REGION TYPE|interactivegridsave'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(554645242312267701)
,p_event_id=>wwv_flow_imp.id(554644249148267700)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    v_datos VARCHAR2(4000);',
'    v_contador number;',
'BEGIN',
'    v_datos := '''';',
' execute immediate ''',
'       SELECT ',
'          JSON_ARRAYAGG(JSON_OBJECT(*) RETURNING CLOB)',
'           FROM (',
'               SELECT seq_id ID',
'                    ,C001 OLOGICO',
'                    ,C002 COLUMNA',
'                    ,C003 ORELACIONAL',
'                    ,C004 VALOR',
'                    ,C005 MSJ_ERROR',
'                    ,C006 MSJ_ADVERTECNIA',
'                FROM APEX_COLLECTIONS WHERE COLLECTION_NAME = ''''COLECCION_VALIDACIONES'''' ORDER BY seq_id',
'           )',
'    '' into v_datos;',
'',
'    :G_GT_VALIDACIONES:=upper(v_datos);',
'END;',
''))
,p_attribute_02=>'G_GT_CONDICIONES'
,p_attribute_03=>'G_GT_CONDICIONES'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(554644755092267701)
,p_event_id=>wwv_flow_imp.id(554644249148267700)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_02=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(554645664208267701)
,p_name=>'LOADPAGE'
,p_event_sequence=>130
,p_condition_element=>'P189_LOADPAGE'
,p_triggering_condition_type=>'NOT_EQUALS'
,p_triggering_expression=>'1'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'ready'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(554646619922267702)
,p_event_id=>wwv_flow_imp.id(554645664208267701)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>':P189_LOADPAGE:=1;'
,p_attribute_02=>'P189_LOADPAGE'
,p_attribute_03=>'P189_LOADPAGE'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(554646148156267701)
,p_event_id=>wwv_flow_imp.id(554645664208267701)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_02=>'Y'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(554642662081267697)
,p_process_sequence=>30
,p_process_point=>'AFTER_SUBMIT'
,p_region_id=>wwv_flow_imp.id(1101431528807767184)
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Validaciones - Save Interactive Grid Data'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare ',
'    v_alias varchar2(399);',
'    v_columna varchar2(399);',
'BEGIN',
'    case :APEX$ROW_STATUS  ',
'     WHEN ''C'' THEN',
'        APEX_COLLECTION.ADD_MEMBER(',
'                p_collection_name =>''COLECCION_VALIDACIONES'',',
'                p_c001 =>:C001,',
'                p_c002 =>:C002,',
'                p_c003 =>:C003,',
'                p_c004 =>:C004,',
'                p_c005 =>:C005,',
'                p_c006 =>:C006',
'        );',
'     WHEN ''U'' THEN       ',
'        APEX_COLLECTION.UPDATE_MEMBER(',
'                 p_collection_name =>''COLECCION_VALIDACIONES''',
'                ,p_seq => :seq_id,',
'                p_c001 =>:C001,',
'                p_c002 =>:C002,',
'                p_c003 =>:C003,',
'                p_c004 =>:C004,',
'                p_c005 =>:C005,',
'                p_c006 =>:C006',
'        );',
'    WHEN ''D'' THEN',
'        APEX_COLLECTION.DELETE_MEMBER(p_collection_name =>''COLECCION_VALIDACIONES'',p_seq => :seq_id);',
'    END CASE;',
'EXCEPTION WHEN OTHERS THEN ',
'    apex_error.add_error (',
'    p_message          => ''ERROR::''||:APEX$ROW_STATUS||'' ''||SQLERRM  ,',
'    p_display_location =>apex_error.c_inline_in_notification );',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>554642662081267697
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(554643402446267699)
,p_process_sequence=>40
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_CLOSE_WINDOW'
,p_process_name=>'Close Dialog '
,p_attribute_02=>'N'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(554637652863267687)
,p_internal_uid=>554643402446267699
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(554643848655267699)
,p_process_sequence=>50
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Limpiar'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'IF APEX_COLLECTION.COLLECTION_EXISTS(''COLECCION_VALIDACIONES'') THEN',
'    APEX_COLLECTION.TRUNCATE_COLLECTION(''COLECCION_VALIDACIONES'');',
'END IF;',
':G_GT_VALIDACIONES:=null;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(554642234839267696)
,p_internal_uid=>554643848655267699
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(554643004790267699)
,p_process_sequence=>20
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'SetupPage'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'IF NOT APEX_COLLECTION.COLLECTION_EXISTS(''COLECCION_VALIDACIONES'') THEN',
'    APEX_COLLECTION.CREATE_COLLECTION(''COLECCION_VALIDACIONES'');',
'END IF;',
'IF APEX_COLLECTION.COLLECTION_EXISTS(''COLECCION_VALIDACIONES'') THEN',
'    APEX_COLLECTION.TRUNCATE_COLLECTION(''COLECCION_VALIDACIONES'');',
'END IF;',
'            ',
'IF(:G_GT_OBJETOS IS NOT NULL)THEN',
'   :P189_OBJETO:= :G_GT_OBJETOS ;',
'END IF;',
'IF(:G_GT_VALIDACIONES IS NOT NULL)THEN',
'    FOR COLS IN (',
'        SELECT OLOGICO CAMPO1,COLUMNA CAMPO2,ORELACIONAL CAMPO3,VALOR CAMPO4,MSJ_ERROR CAMPO5,MSJ_ADVERTECNIA CAMPO6',
'        FROM JSON_TABLE(',
'            :G_GT_VALIDACIONES, -- tu variable o columna con el JSON',
'            ''$[*]'' -- indica que es un arreglo',
'            COLUMNS (',
'                OLOGICO   VARCHAR2(3999) PATH ''$.OLOGICO'',',
'                COLUMNA     VARCHAR2(399) PATH ''$.COLUMNA'',',
'                ORELACIONAL   VARCHAR2(399)   PATH ''$.ORELACIONAL'',',
'                VALOR  VARCHAR2(399)  PATH ''$.VALOR'',',
'                MSJ_ERROR  VARCHAR2(100)  PATH ''$.MSJ_ERROR'',',
'                MSJ_ADVERTECNIA  VARCHAR2(100)  PATH ''$.MSJ_ADVERTECNIA''',
'            )',
'        )',
'    )',
'    LOOP',
'     APEX_COLLECTION.ADD_MEMBER(',
'                    p_collection_name => ''COLECCION_VALIDACIONES'',',
'                    p_c001 => COLS.CAMPO1,',
'                    p_c002 => COLS.CAMPO2,',
'                    p_c003 => COLS.CAMPO3,',
'                    p_c004 => COLS.CAMPO4,',
'                    p_c005 => COLS.CAMPO5,',
'                    p_c006 => COLS.CAMPO6',
'                );',
'    END LOOP;',
'END IF;',
' ',
'    ',
'',
''))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>554643004790267699
);
wwv_flow_imp.component_end;
end;
/
