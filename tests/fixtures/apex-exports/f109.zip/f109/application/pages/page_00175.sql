prompt --application/pages/page_00175
begin
--   Manifest
--     PAGE: 00175
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>109
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_page.create_page(
 p_id=>175
,p_name=>'Resumen ASD'
,p_alias=>'RESUMEN-ASD'
,p_page_mode=>'MODAL'
,p_step_title=>'Resumen ASD'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'03'
,p_created_on=>wwv_flow_imp.dz('20240808185053Z')
,p_last_updated_on=>wwv_flow_imp.dz('20240816195637Z')
,p_created_by=>'MALBAN'
,p_last_updated_by=>'MALBAN'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(402794838409207836)
,p_name=>'Resumen'
,p_template=>wwv_flow_imp.id(38289867500120143)
,p_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT VC1,N1, N2,N2-N1',
'FROM  T_FINZ_CARGASMANUALES',
'WHERE TIPO=''ASD'' AND ANIO=:P175_ANIO AND MES=:P175_MES AND ESTADO=1 AND COMPANIA=:G_COMPANIA AND N8<3;'))
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(37830327650106535)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
,p_created_on=>wwv_flow_imp.dz('20240808202512Z')
,p_updated_on=>wwv_flow_imp.dz('20240808215307Z')
,p_created_by=>'MALBAN'
,p_updated_by=>'MALBAN'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(402795374816207841)
,p_query_column_id=>1
,p_column_alias=>'VC1'
,p_column_display_sequence=>10
,p_use_as_row_header=>'N'
,p_column_alignment=>'CENTER'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20240808213555Z')
,p_updated_by=>'MALBAN'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(402795498940207842)
,p_query_column_id=>2
,p_column_alias=>'N1'
,p_column_display_sequence=>20
,p_column_heading=>'Balance'
,p_use_as_row_header=>'N'
,p_column_format=>'999G999G999G999G990D00'
,p_column_alignment=>'RIGHT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20240808214911Z')
,p_updated_by=>'MALBAN'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(402795590409207843)
,p_query_column_id=>3
,p_column_alias=>'N2'
,p_column_display_sequence=>30
,p_column_heading=>unistr('Conciliaci\00F3n')
,p_use_as_row_header=>'N'
,p_column_format=>'999G999G999G999G990D00'
,p_column_alignment=>'RIGHT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20240808214912Z')
,p_updated_by=>'MALBAN'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(402795663507207844)
,p_query_column_id=>4
,p_column_alias=>'N2-N1'
,p_column_display_sequence=>40
,p_column_heading=>'Diferencia'
,p_use_as_row_header=>'N'
,p_column_format=>'999G999G999G999G990D00'
,p_column_alignment=>'RIGHT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20240808215307Z')
,p_updated_by=>'MALBAN'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(402795816186207846)
,p_name=>'Resumen'
,p_template=>wwv_flow_imp.id(38289867500120143)
,p_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT VC1,VC2,N1, N2',
'FROM  T_FINZ_CARGASMANUALES',
'WHERE TIPO=''ASD'' AND ANIO=:P175_ANIO AND MES=:P175_MES AND ESTADO=1 AND COMPANIA=:G_COMPANIA  AND N8>2',
'ORDER BY N8;'))
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(37830327650106535)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
,p_created_on=>wwv_flow_imp.dz('20240808214623Z')
,p_updated_on=>wwv_flow_imp.dz('20240816195637Z')
,p_created_by=>'MALBAN'
,p_updated_by=>'MALBAN'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(402795990016207847)
,p_query_column_id=>1
,p_column_alias=>'VC1'
,p_column_display_sequence=>10
,p_use_as_row_header=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20240816195637Z')
,p_updated_by=>'MALBAN'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(405592621905549701)
,p_query_column_id=>2
,p_column_alias=>'VC2'
,p_column_display_sequence=>20
,p_column_heading=>'Cuenta'
,p_use_as_row_header=>'N'
,p_column_alignment=>'CENTER'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20240816195637Z')
,p_updated_by=>'MALBAN'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(402796094732207848)
,p_query_column_id=>3
,p_column_alias=>'N1'
,p_column_display_sequence=>30
,p_column_heading=>'Balance'
,p_use_as_row_header=>'N'
,p_column_format=>'999G999G999G999G990D00'
,p_column_alignment=>'RIGHT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20240816195637Z')
,p_updated_by=>'MALBAN'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(402796142356207849)
,p_query_column_id=>4
,p_column_alias=>'N2'
,p_column_display_sequence=>40
,p_column_heading=>unistr('Conciliaci\00F3n')
,p_use_as_row_header=>'N'
,p_column_format=>'999G999G999G999G990D00'
,p_column_alignment=>'RIGHT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20240816195637Z')
,p_updated_by=>'MALBAN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(402795181698207839)
,p_name=>'P175_ANIO'
,p_item_sequence=>30
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
,p_created_on=>wwv_flow_imp.dz('20240808202749Z')
,p_updated_on=>wwv_flow_imp.dz('20240808214623Z')
,p_created_by=>'MALBAN'
,p_updated_by=>'MALBAN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(402795256325207840)
,p_name=>'P175_MES'
,p_item_sequence=>40
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
,p_created_on=>wwv_flow_imp.dz('20240808202749Z')
,p_updated_on=>wwv_flow_imp.dz('20240808214623Z')
,p_created_by=>'MALBAN'
,p_updated_by=>'MALBAN'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(402794981319207837)
,p_process_sequence=>10
,p_process_point=>'AFTER_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Calculos'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'-- borro registros anteriores',
'DELETE FROM T_FINZ_CARGASMANUALES',
'WHERE TIPO=''ASD'' AND ANIO=:P175_ANIO AND MES=:P175_MES  AND ESTADO=1;',
'',
'-- obtengo el saldo de la cuenta contable',
'INSERT INTO T_FINZ_CARGASMANUALES(TIPO,ANIO,MES,VC1,N1,N8,ESTADO,COMPANIA)',
'SELECT ''ASD'',:P175_ANIO,:P175_MES,''16100.61101.14'',SUM(GLAA/100),1,1,:G_COMPANIA',
'FROM F0911@JDEDTADL X',
'WHERE GLLT = ''AA'' AND GLCTRY = 20 AND GLFY= :P175_ANIO-2000 AND GLPN  < :P175_MES  AND GLCO = ''00001''',
'AND GLAID IN (SELECT GMAID',
'              FROM F0901@JDEDTADL ',
'              WHERE GMSUB != ''        ''',
'              and GMMCU=''       16100'' AND GMOBJ=''61101 '' AND GMSUB=''14      '');',
'',
unistr('-- actualizo el valor de la conciliaci\00F3n'),
'',
'UPDATE T_FINZ_CARGASMANUALES ',
'  SET N2=(SELECT N3*-1',
'          FROM TEMPORAL',
'          WHERE COMPANIA=:G_COMPANIA AND PROGRAMA=''CONCILIA_TRIBUTARIA'' AND TIPON=''6020'')',
'WHERE TIPO=''ASD'' AND ANIO=:P175_ANIO AND MES=:P175_MES AND N8=1 AND ESTADO=1',
'AND EXISTS (SELECT ''X''',
'            FROM TEMPORAL',
'            WHERE COMPANIA=:G_COMPANIA AND PROGRAMA=''CONCILIA_TRIBUTARIA'' AND TIPON=''6020'');',
'',
'-- obtengo el saldo de la cuenta contable',
'INSERT INTO T_FINZ_CARGASMANUALES(TIPO,ANIO,MES,VC1,N1,N8,ESTADO,COMPANIA)',
'SELECT ''ASD'',:P175_ANIO,:P175_MES,''16100.62101.24'',SUM(GLAA/100),2,1,:G_COMPANIA',
'FROM F0911@JDEDTADL X',
'WHERE GLLT = ''AA'' AND GLCTRY = 20 AND GLFY= :P175_ANIO-2000 AND GLPN  < :P175_MES  AND GLCO = ''00001''',
'AND GLAID IN (SELECT GMAID',
'              FROM F0901@JDEDTADL ',
'              WHERE GMSUB != ''        ''',
'              and GMMCU=''       16100'' AND GMOBJ=''62101 '' AND GMSUB=''24      '');',
'',
unistr('-- actualizo el valor de la conciliaci\00F3n'),
'',
'UPDATE T_FINZ_CARGASMANUALES ',
'  SET N2=(SELECT N3',
'          FROM TEMPORAL',
'          WHERE COMPANIA=:G_COMPANIA AND PROGRAMA=''CONCILIA_TRIBUTARIA'' AND TIPON=''14010'')',
'WHERE TIPO=''ASD'' AND ANIO=:P175_ANIO AND MES=:P175_MES AND N8=2 AND ESTADO=1',
'AND EXISTS (SELECT ''X''',
'            FROM TEMPORAL',
'            WHERE COMPANIA=:G_COMPANIA AND PROGRAMA=''CONCILIA_TRIBUTARIA'' AND TIPON=''14010'');',
'',
'-- detalle asiento contable',
'-- DEBE',
'INSERT INTO T_FINZ_CARGASMANUALES (TIPO,ANIO,MES,VC1,VC2,N1,N2,N8,ESTADO,COMPANIA)',
'SELECT TIPO,ANIO,MES,''PARTICIPACION TRABAJADORES'',VC1,N2-N1,0,3,1,:G_COMPANIA',
'FROM T_FINZ_CARGASMANUALES',
'WHERE TIPO=''ASD'' AND ANIO=:P175_ANIO AND MES=:P175_MES AND N8=1 AND ESTADO=1;',
'',
'-- HABER',
'INSERT INTO T_FINZ_CARGASMANUALES (TIPO,ANIO,MES,VC1,VC2,N1,N2,N8,ESTADO,COMPANIA)',
'SELECT TIPO,ANIO,MES,''15% PARTICIPACION TRABAJADORES'',''11000.22402.01'',0,N2-N1,4,1,:G_COMPANIA',
'FROM T_FINZ_CARGASMANUALES',
'WHERE TIPO=''ASD'' AND ANIO=:P175_ANIO AND MES=:P175_MES AND N8=1 AND ESTADO=1;',
'',
'-- detalle asiento contable',
'-- DEBE',
'INSERT INTO T_FINZ_CARGASMANUALES (TIPO,ANIO,MES,VC1,VC2,N1,N2,N8,ESTADO,COMPANIA)',
'SELECT TIPO,ANIO,MES,''IMPUESTO A LA RENTA'',VC1,N2-N1,0,5,1,:G_COMPANIA',
'FROM T_FINZ_CARGASMANUALES',
'WHERE TIPO=''ASD'' AND ANIO=:P175_ANIO AND MES=:P175_MES AND N8=2 AND ESTADO=1;',
'',
'-- HABER',
'INSERT INTO T_FINZ_CARGASMANUALES (TIPO,ANIO,MES,VC1,VC2,N1,N2,N8,ESTADO,COMPANIA)',
'SELECT TIPO,ANIO,MES,''IMPUESTOS POR PAGAR'',''11000.22306.01'',0,N2-N1,6,1,:G_COMPANIA',
'FROM T_FINZ_CARGASMANUALES',
'WHERE TIPO=''ASD'' AND ANIO=:P175_ANIO AND MES=:P175_MES AND N8=2 AND ESTADO=1;',
''))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>402794981319207837
,p_created_on=>wwv_flow_imp.dz('20240808202512Z')
,p_updated_on=>wwv_flow_imp.dz('20240816195425Z')
,p_created_by=>'MALBAN'
,p_updated_by=>'MALBAN'
);
wwv_flow_imp.component_end;
end;
/
