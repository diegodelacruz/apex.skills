prompt --application/pages/page_00145
begin
--   Manifest
--     PAGE: 00145
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>109
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_page.create_page(
 p_id=>145
,p_name=>unistr('Cargas Manuales Conciliaci\00F3n')
,p_alias=>unistr('CARGAS-MANUALES-CONCILIACI\00D3N')
,p_step_title=>unistr('Cargas Manuales Conciliaci\00F3n')
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_page_component_map=>'21'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(211876613063446211)
,p_plug_name=>'Barra de acciones'
,p_region_template_options=>'#DEFAULT#:t-Form--stretchInputs'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(38289497777120142)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(37761271469106475)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(37860983999106559)
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(211876818334446213)
,p_plug_name=>'Gasto y Regalias'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(38289867500120143)
,p_plug_display_sequence=>40
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_plug_display_when_condition=>'P145_TIPOCARGA'
,p_plug_display_when_cond2=>'LI'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(211877046040446215)
,p_plug_name=>'Gasto y Regalias'
,p_parent_plug_id=>wwv_flow_imp.id(211876818334446213)
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(37806762584106520)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT *',
'FROM T_FINZ_CARGASMANUALES',
'WHERE TIPO=''LI'' AND ESTADO=1',
'AND ANIO=:P145_ANIO',
'AND (MES=:P145_MES OR :P145_MES IS NULL);',
'',
''))
,p_plug_source_type=>'NATIVE_IG'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'Gasto y Regalias'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(211877291085446217)
,p_name=>'ID'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'ID'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>30
,p_attribute_01=>'Y'
,p_filter_is_required=>false
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_is_primary_key=>true
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(211877328463446218)
,p_name=>'TIPO'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'TIPO'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>40
,p_attribute_01=>'Y'
,p_filter_is_required=>false
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_is_primary_key=>false
,p_default_type=>'ITEM'
,p_default_expression=>'P145_TIPOCARGA'
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(211877451636446219)
,p_name=>'ANIO'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'ANIO'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_NUMBER_FIELD'
,p_heading=>unistr('A\00F1o')
,p_heading_alignment=>'CENTER'
,p_display_sequence=>50
,p_value_alignment=>'CENTER'
,p_attribute_03=>'left'
,p_attribute_04=>'decimal'
,p_is_required=>false
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
,p_readonly_condition_type=>'ALWAYS'
,p_readonly_for_each_row=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(211877538083446220)
,p_name=>'MES'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'MES'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_SELECT_LIST'
,p_heading=>'Mes'
,p_heading_alignment=>'CENTER'
,p_display_sequence=>60
,p_value_alignment=>'CENTER'
,p_is_required=>false
,p_lov_type=>'SHARED'
,p_lov_id=>wwv_flow_imp.id(350337138530635159)
,p_lov_display_extra=>true
,p_lov_display_null=>true
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'LOV'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
,p_readonly_condition_type=>'ALWAYS'
,p_readonly_for_each_row=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(211877669732446221)
,p_name=>'N1'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'N1'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_SELECT_LIST'
,p_heading=>'Proveedor'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>70
,p_value_alignment=>'LEFT'
,p_is_required=>false
,p_lov_type=>'SHARED'
,p_lov_id=>wwv_flow_imp.id(336850420560858390)
,p_lov_display_extra=>true
,p_lov_display_null=>true
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'LOV'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(211877768034446222)
,p_name=>'N2'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'N2'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>80
,p_attribute_01=>'Y'
,p_filter_is_required=>false
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(211877890014446223)
,p_name=>'N3'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'N3'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>90
,p_attribute_01=>'Y'
,p_filter_is_required=>false
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(211877983747446224)
,p_name=>'VC1'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'VC1'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>'Factura'
,p_heading_alignment=>'CENTER'
,p_display_sequence=>100
,p_value_alignment=>'LEFT'
,p_attribute_05=>'BOTH'
,p_is_required=>false
,p_max_length=>150
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(211878088392446225)
,p_name=>'VC2'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'VC2'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>unistr('Descripci\00F3n')
,p_heading_alignment=>'CENTER'
,p_display_sequence=>110
,p_value_alignment=>'LEFT'
,p_attribute_05=>'BOTH'
,p_is_required=>false
,p_max_length=>100
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(211878104075446226)
,p_name=>'VC3'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'VC3'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>120
,p_attribute_01=>'Y'
,p_filter_is_required=>false
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(211878232424446227)
,p_name=>'DT1'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'DT1'
,p_data_type=>'DATE'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>130
,p_attribute_01=>'Y'
,p_filter_is_required=>false
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(211878317119446228)
,p_name=>'DT2'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'DT2'
,p_data_type=>'DATE'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>140
,p_attribute_01=>'Y'
,p_filter_is_required=>false
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(211878404033446229)
,p_name=>'DT3'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'DT3'
,p_data_type=>'DATE'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>150
,p_attribute_01=>'Y'
,p_filter_is_required=>false
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(211878526917446230)
,p_name=>'ESTADO'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'ESTADO'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>160
,p_attribute_01=>'Y'
,p_filter_is_required=>false
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(211878771629446232)
,p_name=>'APEX$ROW_ACTION'
,p_session_state_data_type=>'VARCHAR2'
,p_item_type=>'NATIVE_ROW_ACTION'
,p_display_sequence=>20
,p_use_as_row_header=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(211878878639446233)
,p_name=>'APEX$ROW_SELECTOR'
,p_session_state_data_type=>'VARCHAR2'
,p_item_type=>'NATIVE_ROW_SELECTOR'
,p_display_sequence=>10
,p_attribute_01=>'Y'
,p_attribute_02=>'Y'
,p_attribute_03=>'N'
,p_use_as_row_header=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(218460951830766612)
,p_name=>'N4'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'N4'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>170
,p_attribute_01=>'Y'
,p_filter_is_required=>false
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(269628269153797404)
,p_name=>'N5'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'N5'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>180
,p_attribute_01=>'Y'
,p_filter_is_required=>false
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(269628315132797405)
,p_name=>'N6'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'N6'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>190
,p_attribute_01=>'Y'
,p_filter_is_required=>false
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(269628455643797406)
,p_name=>'N7'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'N7'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>200
,p_attribute_01=>'Y'
,p_filter_is_required=>false
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(269628592689797407)
,p_name=>'N8'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'N8'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_NUMBER_FIELD'
,p_heading=>'Valor'
,p_heading_alignment=>'CENTER'
,p_display_sequence=>210
,p_value_alignment=>'RIGHT'
,p_attribute_03=>'left'
,p_attribute_04=>'decimal'
,p_format_mask=>'999G999G999G999G990D00'
,p_is_required=>false
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(269628639702797408)
,p_name=>'COMPANIA'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'COMPANIA'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>220
,p_attribute_01=>'Y'
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_is_primary_key=>false
,p_default_type=>'ITEM'
,p_default_expression=>'G_COMPANIA'
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_interactive_grid(
 p_id=>wwv_flow_imp.id(211877142577446216)
,p_internal_uid=>211877142577446216
,p_is_editable=>true
,p_edit_operations=>'i:u:d'
,p_lost_update_check_type=>'VALUES'
,p_add_row_if_empty=>false
,p_submit_checked_rows=>false
,p_lazy_loading=>false
,p_requires_filter=>false
,p_select_first_row=>true
,p_fixed_row_height=>true
,p_pagination_type=>'SCROLL'
,p_show_total_row_count=>true
,p_show_toolbar=>true
,p_enable_save_public_report=>false
,p_enable_subscriptions=>true
,p_enable_flashback=>true
,p_define_chart_view=>true
,p_enable_download=>true
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>true
,p_fixed_header=>'PAGE'
,p_show_icon_view=>false
,p_show_detail_view=>false
);
wwv_flow_imp_page.create_ig_report(
 p_id=>wwv_flow_imp.id(217823303580635094)
,p_interactive_grid_id=>wwv_flow_imp.id(211877142577446216)
,p_static_id=>'2178234'
,p_type=>'PRIMARY'
,p_default_view=>'GRID'
,p_show_row_number=>false
,p_settings_area_expanded=>true
);
wwv_flow_imp_page.create_ig_report_view(
 p_id=>wwv_flow_imp.id(217823541288635096)
,p_report_id=>wwv_flow_imp.id(217823303580635094)
,p_view_type=>'GRID'
,p_stretch_columns=>true
,p_srv_exclude_null_values=>false
,p_srv_only_display_columns=>true
,p_edit_mode=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(217824044760635102)
,p_view_id=>wwv_flow_imp.id(217823541288635096)
,p_display_seq=>2
,p_column_id=>wwv_flow_imp.id(211877291085446217)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(217824921997635108)
,p_view_id=>wwv_flow_imp.id(217823541288635096)
,p_display_seq=>3
,p_column_id=>wwv_flow_imp.id(211877328463446218)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(217825820767635110)
,p_view_id=>wwv_flow_imp.id(217823541288635096)
,p_display_seq=>4
,p_column_id=>wwv_flow_imp.id(211877451636446219)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>76
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(217826743454635112)
,p_view_id=>wwv_flow_imp.id(217823541288635096)
,p_display_seq=>5
,p_column_id=>wwv_flow_imp.id(211877538083446220)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>84
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(217827629073635114)
,p_view_id=>wwv_flow_imp.id(217823541288635096)
,p_display_seq=>6
,p_column_id=>wwv_flow_imp.id(211877669732446221)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>303
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(217828517882635116)
,p_view_id=>wwv_flow_imp.id(217823541288635096)
,p_display_seq=>7
,p_column_id=>wwv_flow_imp.id(211877768034446222)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>105.31200000000001
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(217829495523635118)
,p_view_id=>wwv_flow_imp.id(217823541288635096)
,p_display_seq=>8
,p_column_id=>wwv_flow_imp.id(211877890014446223)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(217830378755635120)
,p_view_id=>wwv_flow_imp.id(217823541288635096)
,p_display_seq=>9
,p_column_id=>wwv_flow_imp.id(211877983747446224)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(217831206619635122)
,p_view_id=>wwv_flow_imp.id(217823541288635096)
,p_display_seq=>10
,p_column_id=>wwv_flow_imp.id(211878088392446225)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(217832118024635124)
,p_view_id=>wwv_flow_imp.id(217823541288635096)
,p_display_seq=>11
,p_column_id=>wwv_flow_imp.id(211878104075446226)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(217833036851635126)
,p_view_id=>wwv_flow_imp.id(217823541288635096)
,p_display_seq=>12
,p_column_id=>wwv_flow_imp.id(211878232424446227)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(217833968740635128)
,p_view_id=>wwv_flow_imp.id(217823541288635096)
,p_display_seq=>13
,p_column_id=>wwv_flow_imp.id(211878317119446228)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(217834896400635130)
,p_view_id=>wwv_flow_imp.id(217823541288635096)
,p_display_seq=>14
,p_column_id=>wwv_flow_imp.id(211878404033446229)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(217835790412635133)
,p_view_id=>wwv_flow_imp.id(217823541288635096)
,p_display_seq=>15
,p_column_id=>wwv_flow_imp.id(211878526917446230)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(217838855619641318)
,p_view_id=>wwv_flow_imp.id(217823541288635096)
,p_display_seq=>1
,p_column_id=>wwv_flow_imp.id(211878771629446232)
,p_is_visible=>true
,p_is_frozen=>true
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(219418679113594378)
,p_view_id=>wwv_flow_imp.id(217823541288635096)
,p_display_seq=>16
,p_column_id=>wwv_flow_imp.id(218460951830766612)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(269650512356905318)
,p_view_id=>wwv_flow_imp.id(217823541288635096)
,p_display_seq=>17
,p_column_id=>wwv_flow_imp.id(269628269153797404)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(269651482313905320)
,p_view_id=>wwv_flow_imp.id(217823541288635096)
,p_display_seq=>18
,p_column_id=>wwv_flow_imp.id(269628315132797405)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(269652396381905321)
,p_view_id=>wwv_flow_imp.id(217823541288635096)
,p_display_seq=>19
,p_column_id=>wwv_flow_imp.id(269628455643797406)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(269653234793905323)
,p_view_id=>wwv_flow_imp.id(217823541288635096)
,p_display_seq=>20
,p_column_id=>wwv_flow_imp.id(269628592689797407)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(269654135679905325)
,p_view_id=>wwv_flow_imp.id(217823541288635096)
,p_display_seq=>21
,p_column_id=>wwv_flow_imp.id(269628639702797408)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(211876948854446214)
,p_plug_name=>'Marcas'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(38289867500120143)
,p_plug_display_sequence=>50
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_plug_display_when_condition=>'P145_TIPOCARGA'
,p_plug_display_when_cond2=>'MA'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(211880080677446245)
,p_name=>'Marcas'
,p_parent_plug_id=>wwv_flow_imp.id(211876948854446214)
,p_template=>wwv_flow_imp.id(37806762584106520)
,p_display_sequence=>10
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_display_point=>'SUB_REGIONS'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ANIO,MES,VC1,N1,N2,(N8*(N3/100) ) N3,N4,--(N8*(N4/100)) N4,',
'       N5,N6,N7,N8',
'FROM T_FINZ_CARGASMANUALES',
'WHERE TIPO=''MA'' AND ESTADO IN (1,2)',
'AND ANIO=:P145_ANIO',
'AND MES=:P145_MES;'))
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(37830327650106535)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(393685672359239049)
,p_query_column_id=>1
,p_column_alias=>'ANIO'
,p_column_display_sequence=>20
,p_use_as_row_header=>'N'
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(393685734568239050)
,p_query_column_id=>2
,p_column_alias=>'MES'
,p_column_display_sequence=>30
,p_column_heading=>'Mes'
,p_use_as_row_header=>'N'
,p_column_alignment=>'CENTER'
,p_disable_sort_column=>'N'
,p_display_as=>'TEXT_FROM_LOV_ESC'
,p_named_lov=>wwv_flow_imp.id(350337138530635159)
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(402259187968018901)
,p_query_column_id=>3
,p_column_alias=>'VC1'
,p_column_display_sequence=>40
,p_column_heading=>'Marca'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(402259296970018902)
,p_query_column_id=>4
,p_column_alias=>'N1'
,p_column_display_sequence=>50
,p_column_heading=>'Valor'
,p_use_as_row_header=>'N'
,p_column_format=>'999G999G999G999G990D00'
,p_column_alignment=>'RIGHT'
,p_disable_sort_column=>'N'
,p_sum_column=>'Y'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(402259321471018903)
,p_query_column_id=>5
,p_column_alias=>'N2'
,p_column_display_sequence=>60
,p_column_heading=>'%'
,p_use_as_row_header=>'N'
,p_column_format=>'999G999G999G999G990D00'
,p_column_alignment=>'RIGHT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(402259439391018904)
,p_query_column_id=>6
,p_column_alias=>'N3'
,p_column_display_sequence=>130
,p_column_heading=>unistr('25% Retenci\00F3n')
,p_use_as_row_header=>'N'
,p_column_format=>'999G999G999G999G990D00'
,p_column_alignment=>'RIGHT'
,p_disable_sort_column=>'N'
,p_sum_column=>'Y'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(402259569622018905)
,p_query_column_id=>7
,p_column_alias=>'N4'
,p_column_display_sequence=>140
,p_column_heading=>'ISD'
,p_use_as_row_header=>'N'
,p_column_format=>'999G999G999G999G990D00'
,p_column_alignment=>'RIGHT'
,p_disable_sort_column=>'N'
,p_sum_column=>'Y'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(402259622884018906)
,p_query_column_id=>8
,p_column_alias=>'N5'
,p_column_display_sequence=>90
,p_column_heading=>'Total &P145_ANIO.'
,p_use_as_row_header=>'N'
,p_column_format=>'999G999G999G999G990D00'
,p_column_alignment=>'RIGHT'
,p_disable_sort_column=>'N'
,p_sum_column=>'Y'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(402259735068018907)
,p_query_column_id=>9
,p_column_alias=>'N6'
,p_column_display_sequence=>100
,p_column_heading=>unistr('Regal\00EDas sin Dscto')
,p_use_as_row_header=>'N'
,p_column_format=>'999G999G999G999G990D00'
,p_column_alignment=>'RIGHT'
,p_disable_sort_column=>'N'
,p_sum_column=>'Y'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(402259852980018908)
,p_query_column_id=>10
,p_column_alias=>'N7'
,p_column_display_sequence=>110
,p_column_heading=>unistr('Dscto Regal\00EDas')
,p_use_as_row_header=>'N'
,p_column_format=>'999G999G999G999G990D00'
,p_column_alignment=>'RIGHT'
,p_disable_sort_column=>'N'
,p_sum_column=>'Y'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(402259901116018909)
,p_query_column_id=>11
,p_column_alias=>'N8'
,p_column_display_sequence=>120
,p_column_heading=>unistr('Regal\00EDas')
,p_use_as_row_header=>'N'
,p_column_format=>'999G999G999G999G990D00'
,p_column_alignment=>'RIGHT'
,p_disable_sort_column=>'N'
,p_sum_column=>'Y'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(217819376821373862)
,p_plug_name=>'Cargas Manuales'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(38290610465120145)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(37761271469106475)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(37860983999106559)
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(218461038149766613)
,p_plug_name=>unistr('Beneficio Econom\00EDa Popular')
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(38289867500120143)
,p_plug_display_sequence=>60
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_plug_display_when_condition=>'P145_TIPOCARGA'
,p_plug_display_when_cond2=>'BEP'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(218461383306766616)
,p_plug_name=>'Facturas'
,p_parent_plug_id=>wwv_flow_imp.id(218461038149766613)
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(37806762584106520)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ANIO,MES,N1,N2,N3,VC1,VC2,DT1,ESTADO,ROUND(N4,2) N4',
'FROM T_FINZ_CARGASMANUALES',
'WHERE TIPO=:P145_TIPOCARGA',
'AND ANIO=:P145_ANIO AND MES=:P145_MES',
';'))
,p_plug_source_type=>'NATIVE_IG'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'Facturas'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(218461545950766618)
,p_name=>'ANIO'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'ANIO'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_NUMBER_FIELD'
,p_heading=>unistr('A\00F1o')
,p_heading_alignment=>'CENTER'
,p_display_sequence=>10
,p_value_alignment=>'CENTER'
,p_attribute_03=>'left'
,p_attribute_04=>'decimal'
,p_is_required=>false
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(218461637428766619)
,p_name=>'MES'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'MES'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_NUMBER_FIELD'
,p_heading=>'Mes'
,p_heading_alignment=>'CENTER'
,p_display_sequence=>20
,p_value_alignment=>'CENTER'
,p_attribute_03=>'left'
,p_attribute_04=>'decimal'
,p_is_required=>false
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(218461742924766620)
,p_name=>'N1'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'N1'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_NUMBER_FIELD'
,p_heading=>'Base 0%'
,p_heading_alignment=>'CENTER'
,p_display_sequence=>30
,p_value_alignment=>'RIGHT'
,p_attribute_03=>'left'
,p_attribute_04=>'decimal'
,p_is_required=>false
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(218461862735766621)
,p_name=>'N2'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'N2'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_NUMBER_FIELD'
,p_heading=>unistr('N\00FAmero Orden')
,p_heading_alignment=>'CENTER'
,p_display_sequence=>40
,p_value_alignment=>'RIGHT'
,p_attribute_03=>'left'
,p_attribute_04=>'decimal'
,p_is_required=>false
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(218461960114766622)
,p_name=>'VC1'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'VC1'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>'# Factura'
,p_heading_alignment=>'CENTER'
,p_display_sequence=>50
,p_value_alignment=>'CENTER'
,p_attribute_05=>'BOTH'
,p_is_required=>false
,p_max_length=>50
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(218462012977766623)
,p_name=>'VC2'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'VC2'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>'RUC'
,p_heading_alignment=>'CENTER'
,p_display_sequence=>60
,p_value_alignment=>'CENTER'
,p_attribute_05=>'BOTH'
,p_is_required=>false
,p_max_length=>50
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(218462182182766624)
,p_name=>'DT1'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'DT1'
,p_data_type=>'DATE'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_DATE_PICKER_APEX'
,p_heading=>'Fecha LM'
,p_heading_alignment=>'CENTER'
,p_display_sequence=>70
,p_value_alignment=>'CENTER'
,p_attribute_01=>'N'
,p_attribute_02=>'POPUP'
,p_attribute_03=>'NONE'
,p_attribute_06=>'NONE'
,p_attribute_09=>'N'
,p_attribute_11=>'Y'
,p_is_required=>false
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_date_ranges=>'ALL'
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(218462251003766625)
,p_name=>'ESTADO'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'ESTADO'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>80
,p_attribute_01=>'Y'
,p_filter_is_required=>false
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(218462327094766626)
,p_name=>'N3'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'N3'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_NUMBER_FIELD'
,p_heading=>'% Beneficio'
,p_heading_alignment=>'CENTER'
,p_display_sequence=>90
,p_value_alignment=>'RIGHT'
,p_attribute_03=>'left'
,p_attribute_04=>'decimal'
,p_is_required=>false
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(218462490345766627)
,p_name=>'N4'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'N4'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_NUMBER_FIELD'
,p_heading=>unistr('Deducci\00F3n')
,p_heading_alignment=>'CENTER'
,p_display_sequence=>100
,p_value_alignment=>'RIGHT'
,p_attribute_03=>'left'
,p_attribute_04=>'decimal'
,p_is_required=>false
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_interactive_grid(
 p_id=>wwv_flow_imp.id(218461440632766617)
,p_internal_uid=>218461440632766617
,p_is_editable=>false
,p_lazy_loading=>false
,p_requires_filter=>false
,p_select_first_row=>true
,p_fixed_row_height=>true
,p_pagination_type=>'SCROLL'
,p_show_total_row_count=>true
,p_show_toolbar=>true
,p_enable_save_public_report=>false
,p_enable_subscriptions=>true
,p_enable_flashback=>true
,p_define_chart_view=>true
,p_enable_download=>true
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>true
,p_fixed_header=>'PAGE'
,p_show_icon_view=>false
,p_show_detail_view=>false
);
wwv_flow_imp_page.create_ig_report(
 p_id=>wwv_flow_imp.id(220620793664845101)
,p_interactive_grid_id=>wwv_flow_imp.id(218461440632766617)
,p_static_id=>'2206208'
,p_type=>'PRIMARY'
,p_default_view=>'GRID'
,p_show_row_number=>false
,p_settings_area_expanded=>false
);
wwv_flow_imp_page.create_ig_report_view(
 p_id=>wwv_flow_imp.id(220620951234845114)
,p_report_id=>wwv_flow_imp.id(220620793664845101)
,p_view_type=>'GRID'
,p_stretch_columns=>true
,p_srv_exclude_null_values=>false
,p_srv_only_display_columns=>true
,p_edit_mode=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(220621479976845172)
,p_view_id=>wwv_flow_imp.id(220620951234845114)
,p_display_seq=>1
,p_column_id=>wwv_flow_imp.id(218461545950766618)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>74
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(220622297094845231)
,p_view_id=>wwv_flow_imp.id(220620951234845114)
,p_display_seq=>3
,p_column_id=>wwv_flow_imp.id(218461637428766619)
,p_is_visible=>false
,p_is_frozen=>false
,p_width=>66
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(220623181529845237)
,p_view_id=>wwv_flow_imp.id(220620951234845114)
,p_display_seq=>4
,p_column_id=>wwv_flow_imp.id(218461742924766620)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(220624021855845245)
,p_view_id=>wwv_flow_imp.id(220620951234845114)
,p_display_seq=>6
,p_column_id=>wwv_flow_imp.id(218461862735766621)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(220624965796845248)
,p_view_id=>wwv_flow_imp.id(220620951234845114)
,p_display_seq=>7
,p_column_id=>wwv_flow_imp.id(218461960114766622)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(220625836146845252)
,p_view_id=>wwv_flow_imp.id(220620951234845114)
,p_display_seq=>2
,p_column_id=>wwv_flow_imp.id(218462012977766623)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(220626762558845255)
,p_view_id=>wwv_flow_imp.id(220620951234845114)
,p_display_seq=>9
,p_column_id=>wwv_flow_imp.id(218462182182766624)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(220627663686845270)
,p_view_id=>wwv_flow_imp.id(220620951234845114)
,p_display_seq=>8
,p_column_id=>wwv_flow_imp.id(218462251003766625)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(222222742274193063)
,p_view_id=>wwv_flow_imp.id(220620951234845114)
,p_display_seq=>5
,p_column_id=>wwv_flow_imp.id(218462327094766626)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>85
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(222224954182211593)
,p_view_id=>wwv_flow_imp.id(220620951234845114)
,p_display_seq=>10
,p_column_id=>wwv_flow_imp.id(218462490345766627)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_aggregate(
 p_id=>wwv_flow_imp.id(92813000000)
,p_view_id=>wwv_flow_imp.id(220620951234845114)
,p_function=>'SUM'
,p_column_id=>wwv_flow_imp.id(218461742924766620)
,p_show_grand_total=>false
,p_is_enabled=>true
);
wwv_flow_imp_page.create_ig_report_aggregate(
 p_id=>wwv_flow_imp.id(168282002390)
,p_view_id=>wwv_flow_imp.id(220620951234845114)
,p_function=>'SUM'
,p_column_id=>wwv_flow_imp.id(218462490345766627)
,p_show_grand_total=>true
,p_is_enabled=>true
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(218462519662766628)
,p_plug_name=>unistr('Depreciaci\00F3n ')
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(38289867500120143)
,p_plug_display_sequence=>70
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_plug_display_when_condition=>'P145_TIPOCARGA'
,p_plug_display_when_cond2=>'DD'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(218462798421766630)
,p_plug_name=>'DETALLE'
,p_parent_plug_id=>wwv_flow_imp.id(218462519662766628)
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(37806762584106520)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'TABLE'
,p_query_table=>'T_FINZ_CARGASMANUALES'
,p_query_where=>'TIPO=:P145_TIPOCARGA AND ANIO=:P145_ANIO AND MES=:P145_MES AND ESTADO=1'
,p_include_rowid_column=>false
,p_plug_source_type=>'NATIVE_IG'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'DETALLE'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(218462903392766632)
,p_name=>'ID'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'ID'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>30
,p_attribute_01=>'Y'
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_is_primary_key=>true
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(218463002322766633)
,p_name=>'TIPO'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'TIPO'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>40
,p_attribute_01=>'Y'
,p_filter_is_required=>false
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_is_primary_key=>false
,p_default_type=>'ITEM'
,p_default_expression=>'P145_TIPOCARGA'
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(218463116945766634)
,p_name=>'ANIO'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'ANIO'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>50
,p_attribute_01=>'Y'
,p_filter_is_required=>false
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_is_primary_key=>false
,p_default_type=>'ITEM'
,p_default_expression=>'P145_ANIO'
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(218463277248766635)
,p_name=>'MES'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'MES'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>60
,p_attribute_01=>'Y'
,p_filter_is_required=>false
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_is_primary_key=>false
,p_default_type=>'ITEM'
,p_default_expression=>'P145_MES'
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(218463377628766636)
,p_name=>'N1'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'N1'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_SELECT_LIST'
,p_heading=>'Nro. Activo'
,p_heading_alignment=>'CENTER'
,p_display_sequence=>70
,p_value_alignment=>'LEFT'
,p_is_required=>false
,p_lov_type=>'SHARED'
,p_lov_id=>wwv_flow_imp.id(410203256785688863)
,p_lov_display_extra=>true
,p_lov_display_null=>true
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'LOV'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(218463493807766637)
,p_name=>'N2'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'N2'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_NUMBER_FIELD'
,p_heading=>unistr('Depreciaci\00F3n')
,p_heading_alignment=>'CENTER'
,p_display_sequence=>80
,p_value_alignment=>'RIGHT'
,p_attribute_03=>'left'
,p_attribute_04=>'decimal'
,p_is_required=>false
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(218463598841766638)
,p_name=>'N3'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'N3'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_NUMBER_FIELD'
,p_heading=>'&P145_ANIO.'
,p_heading_alignment=>'CENTER'
,p_display_sequence=>90
,p_value_alignment=>'RIGHT'
,p_attribute_03=>'left'
,p_attribute_04=>'decimal'
,p_format_mask=>'999G999G999G999G990D00'
,p_is_required=>false
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(218463615292766639)
,p_name=>'VC1'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'VC1'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_DISPLAY_ONLY'
,p_heading=>unistr('Nro. Autorizaci\00F3n')
,p_heading_alignment=>'CENTER'
,p_display_sequence=>100
,p_value_alignment=>'LEFT'
,p_attribute_02=>'VALUE'
,p_attribute_05=>'PLAIN'
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(218463767549766640)
,p_name=>'VC2'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'VC2'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>110
,p_attribute_01=>'Y'
,p_filter_is_required=>false
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(218463844596766641)
,p_name=>'VC3'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'VC3'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>120
,p_attribute_01=>'Y'
,p_filter_is_required=>false
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(218463946798766642)
,p_name=>'DT1'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'DT1'
,p_data_type=>'DATE'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_DATE_PICKER_APEX'
,p_heading=>'Fec. Compra'
,p_heading_alignment=>'CENTER'
,p_display_sequence=>130
,p_value_alignment=>'CENTER'
,p_attribute_01=>'N'
,p_attribute_02=>'POPUP'
,p_attribute_03=>'NONE'
,p_attribute_06=>'NONE'
,p_attribute_09=>'N'
,p_attribute_11=>'Y'
,p_is_required=>false
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_date_ranges=>'ALL'
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(218464002916766643)
,p_name=>'DT2'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'DT2'
,p_data_type=>'DATE'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>140
,p_attribute_01=>'Y'
,p_filter_is_required=>false
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(218464197031766644)
,p_name=>'DT3'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'DT3'
,p_data_type=>'DATE'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>150
,p_attribute_01=>'Y'
,p_filter_is_required=>false
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(218464266914766645)
,p_name=>'ESTADO'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'ESTADO'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>160
,p_attribute_01=>'Y'
,p_filter_is_required=>false
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_is_primary_key=>false
,p_default_type=>'STATIC'
,p_default_expression=>'1'
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(218464385620766646)
,p_name=>'N4'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'N4'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>170
,p_attribute_01=>'Y'
,p_filter_is_required=>false
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(218464409196766647)
,p_name=>'APEX$ROW_ACTION'
,p_session_state_data_type=>'VARCHAR2'
,p_item_type=>'NATIVE_ROW_ACTION'
,p_display_sequence=>20
,p_use_as_row_header=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(218464562239766648)
,p_name=>'APEX$ROW_SELECTOR'
,p_session_state_data_type=>'VARCHAR2'
,p_item_type=>'NATIVE_ROW_SELECTOR'
,p_display_sequence=>10
,p_attribute_01=>'Y'
,p_attribute_02=>'Y'
,p_attribute_03=>'N'
,p_use_as_row_header=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(263194455282745849)
,p_name=>'N5'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'N5'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>180
,p_attribute_01=>'Y'
,p_filter_is_required=>false
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(263194577753745850)
,p_name=>'N6'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'N6'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>190
,p_attribute_01=>'Y'
,p_filter_is_required=>false
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(269627952576797401)
,p_name=>'N7'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'N7'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>200
,p_attribute_01=>'Y'
,p_filter_is_required=>false
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(269628051125797402)
,p_name=>'N8'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'N8'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>210
,p_attribute_01=>'Y'
,p_filter_is_required=>false
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(269628189713797403)
,p_name=>'COMPANIA'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'COMPANIA'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>220
,p_attribute_01=>'Y'
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_is_primary_key=>false
,p_default_type=>'ITEM'
,p_default_expression=>'G_COMPANIA'
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_interactive_grid(
 p_id=>wwv_flow_imp.id(218462820362766631)
,p_internal_uid=>218462820362766631
,p_is_editable=>true
,p_edit_operations=>'i:u:d'
,p_lost_update_check_type=>'VALUES'
,p_add_row_if_empty=>false
,p_submit_checked_rows=>false
,p_lazy_loading=>false
,p_requires_filter=>false
,p_select_first_row=>true
,p_fixed_row_height=>true
,p_pagination_type=>'SCROLL'
,p_show_total_row_count=>true
,p_show_toolbar=>true
,p_enable_save_public_report=>false
,p_enable_subscriptions=>true
,p_enable_flashback=>true
,p_define_chart_view=>true
,p_enable_download=>true
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>true
,p_fixed_header=>'PAGE'
,p_show_icon_view=>false
,p_show_detail_view=>false
);
wwv_flow_imp_page.create_ig_report(
 p_id=>wwv_flow_imp.id(222621600728575424)
,p_interactive_grid_id=>wwv_flow_imp.id(218462820362766631)
,p_static_id=>'2226217'
,p_type=>'PRIMARY'
,p_default_view=>'GRID'
,p_show_row_number=>false
,p_settings_area_expanded=>false
);
wwv_flow_imp_page.create_ig_report_view(
 p_id=>wwv_flow_imp.id(222621872569575424)
,p_report_id=>wwv_flow_imp.id(222621600728575424)
,p_view_type=>'GRID'
,p_stretch_columns=>true
,p_srv_exclude_null_values=>false
,p_srv_only_display_columns=>true
,p_edit_mode=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(222622370099575428)
,p_view_id=>wwv_flow_imp.id(222621872569575424)
,p_display_seq=>2
,p_column_id=>wwv_flow_imp.id(218462903392766632)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(222623210961575432)
,p_view_id=>wwv_flow_imp.id(222621872569575424)
,p_display_seq=>3
,p_column_id=>wwv_flow_imp.id(218463002322766633)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(222624108505575434)
,p_view_id=>wwv_flow_imp.id(222621872569575424)
,p_display_seq=>4
,p_column_id=>wwv_flow_imp.id(218463116945766634)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(222625099899575436)
,p_view_id=>wwv_flow_imp.id(222621872569575424)
,p_display_seq=>5
,p_column_id=>wwv_flow_imp.id(218463277248766635)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(222625951145575438)
,p_view_id=>wwv_flow_imp.id(222621872569575424)
,p_display_seq=>6
,p_column_id=>wwv_flow_imp.id(218463377628766636)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>339.3906
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(222626838206575440)
,p_view_id=>wwv_flow_imp.id(222621872569575424)
,p_display_seq=>9
,p_column_id=>wwv_flow_imp.id(218463493807766637)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>101.89099999999999
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(222627781425575442)
,p_view_id=>wwv_flow_imp.id(222621872569575424)
,p_display_seq=>12
,p_column_id=>wwv_flow_imp.id(218463598841766638)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(222628611521575444)
,p_view_id=>wwv_flow_imp.id(222621872569575424)
,p_display_seq=>7
,p_column_id=>wwv_flow_imp.id(218463615292766639)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>114.39100000000002
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(222629545311575445)
,p_view_id=>wwv_flow_imp.id(222621872569575424)
,p_display_seq=>10
,p_column_id=>wwv_flow_imp.id(218463767549766640)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(222630404414575447)
,p_view_id=>wwv_flow_imp.id(222621872569575424)
,p_display_seq=>11
,p_column_id=>wwv_flow_imp.id(218463844596766641)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(222631312996575449)
,p_view_id=>wwv_flow_imp.id(222621872569575424)
,p_display_seq=>8
,p_column_id=>wwv_flow_imp.id(218463946798766642)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>144.391
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(222632225586575451)
,p_view_id=>wwv_flow_imp.id(222621872569575424)
,p_display_seq=>13
,p_column_id=>wwv_flow_imp.id(218464002916766643)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(222633115498575453)
,p_view_id=>wwv_flow_imp.id(222621872569575424)
,p_display_seq=>14
,p_column_id=>wwv_flow_imp.id(218464197031766644)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(222634040126575454)
,p_view_id=>wwv_flow_imp.id(222621872569575424)
,p_display_seq=>15
,p_column_id=>wwv_flow_imp.id(218464266914766645)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(222634998194575456)
,p_view_id=>wwv_flow_imp.id(222621872569575424)
,p_display_seq=>16
,p_column_id=>wwv_flow_imp.id(218464385620766646)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(222635829992575458)
,p_view_id=>wwv_flow_imp.id(222621872569575424)
,p_display_seq=>1
,p_column_id=>wwv_flow_imp.id(218464409196766647)
,p_is_visible=>true
,p_is_frozen=>true
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(269646055229905307)
,p_view_id=>wwv_flow_imp.id(222621872569575424)
,p_display_seq=>17
,p_column_id=>wwv_flow_imp.id(263194455282745849)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(269646958367905310)
,p_view_id=>wwv_flow_imp.id(222621872569575424)
,p_display_seq=>18
,p_column_id=>wwv_flow_imp.id(263194577753745850)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(269647876642905312)
,p_view_id=>wwv_flow_imp.id(222621872569575424)
,p_display_seq=>19
,p_column_id=>wwv_flow_imp.id(269627952576797401)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(269648714884905314)
,p_view_id=>wwv_flow_imp.id(222621872569575424)
,p_display_seq=>20
,p_column_id=>wwv_flow_imp.id(269628051125797402)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(269649647885905316)
,p_view_id=>wwv_flow_imp.id(222621872569575424)
,p_display_seq=>21
,p_column_id=>wwv_flow_imp.id(269628189713797403)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_aggregate(
 p_id=>wwv_flow_imp.id(83374000006)
,p_view_id=>wwv_flow_imp.id(222621872569575424)
,p_function=>'SUM'
,p_column_id=>wwv_flow_imp.id(218463598841766638)
,p_show_grand_total=>false
,p_is_enabled=>true
);
wwv_flow_imp_page.create_ig_report_aggregate(
 p_id=>wwv_flow_imp.id(203240002364)
,p_view_id=>wwv_flow_imp.id(222621872569575424)
,p_function=>'SUM'
,p_column_id=>wwv_flow_imp.id(218463493807766637)
,p_show_grand_total=>true
,p_is_enabled=>true
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(218464720655766650)
,p_plug_name=>'Publicidad patrocinio'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(38289867500120143)
,p_plug_display_sequence=>80
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_plug_display_when_condition=>'P145_TIPOCARGA'
,p_plug_display_when_cond2=>'GP'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(222830976201009901)
,p_plug_name=>'Publicidad'
,p_parent_plug_id=>wwv_flow_imp.id(218464720655766650)
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(37806762584106520)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'TABLE'
,p_query_table=>'T_FINZ_CARGASMANUALES'
,p_query_where=>'TIPO=:P145_TIPOCARGA AND ANIO=:P145_ANIO AND MES=:P145_MES AND ESTADO=1'
,p_include_rowid_column=>false
,p_plug_source_type=>'NATIVE_IG'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'Publicidad'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(222831166512009903)
,p_name=>'ID'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'ID'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>30
,p_attribute_01=>'Y'
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_is_primary_key=>true
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(222831251549009904)
,p_name=>'TIPO'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'TIPO'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>40
,p_attribute_01=>'Y'
,p_filter_is_required=>false
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_is_primary_key=>false
,p_default_type=>'ITEM'
,p_default_expression=>'P145_TIPOCARGA'
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(222831387391009905)
,p_name=>'ANIO'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'ANIO'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>50
,p_attribute_01=>'Y'
,p_filter_is_required=>false
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_is_primary_key=>false
,p_default_type=>'ITEM'
,p_default_expression=>'P145_ANIO'
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(222831447803009906)
,p_name=>'MES'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'MES'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>60
,p_attribute_01=>'Y'
,p_filter_is_required=>false
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_is_primary_key=>false
,p_default_type=>'ITEM'
,p_default_expression=>'P145_MES'
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(222831574268009907)
,p_name=>'N1'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'N1'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_NUMBER_FIELD'
,p_heading=>'Valor<br>Acumulado'
,p_heading_alignment=>'CENTER'
,p_display_sequence=>70
,p_value_alignment=>'RIGHT'
,p_attribute_03=>'left'
,p_attribute_04=>'decimal'
,p_format_mask=>'999G999G999G999G990D00'
,p_is_required=>false
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(222831666299009908)
,p_name=>'N2'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'N2'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_NUMBER_FIELD'
,p_heading=>'Valor<br>Mes'
,p_heading_alignment=>'CENTER'
,p_display_sequence=>80
,p_value_alignment=>'RIGHT'
,p_attribute_03=>'left'
,p_attribute_04=>'decimal'
,p_is_required=>false
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(222831754755009909)
,p_name=>'N3'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'N3'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>90
,p_attribute_01=>'Y'
,p_filter_is_required=>false
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(222831879076009910)
,p_name=>'VC1'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'VC1'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>'Proveedor'
,p_heading_alignment=>'CENTER'
,p_display_sequence=>100
,p_value_alignment=>'LEFT'
,p_attribute_05=>'BOTH'
,p_is_required=>false
,p_max_length=>150
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(222831993460009911)
,p_name=>'VC2'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'VC2'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>110
,p_attribute_01=>'Y'
,p_filter_is_required=>false
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(222832057680009912)
,p_name=>'VC3'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'VC3'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>unistr('Descripci\00F3n')
,p_heading_alignment=>'CENTER'
,p_display_sequence=>120
,p_value_alignment=>'LEFT'
,p_attribute_05=>'BOTH'
,p_is_required=>false
,p_max_length=>100
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(222832126450009913)
,p_name=>'DT1'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'DT1'
,p_data_type=>'DATE'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>130
,p_attribute_01=>'Y'
,p_filter_is_required=>false
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(222832206482009914)
,p_name=>'DT2'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'DT2'
,p_data_type=>'DATE'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>140
,p_attribute_01=>'Y'
,p_filter_is_required=>false
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(222832314359009915)
,p_name=>'DT3'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'DT3'
,p_data_type=>'DATE'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>150
,p_attribute_01=>'Y'
,p_filter_is_required=>false
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(222832466174009916)
,p_name=>'ESTADO'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'ESTADO'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>160
,p_attribute_01=>'Y'
,p_filter_is_required=>false
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_is_primary_key=>false
,p_default_type=>'STATIC'
,p_default_expression=>'1'
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(222832589291009917)
,p_name=>'N4'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'N4'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>170
,p_attribute_01=>'Y'
,p_filter_is_required=>false
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_is_primary_key=>false
,p_default_type=>'ITEM'
,p_default_expression=>'P145_PORCENTAJE'
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(222832635536009918)
,p_name=>'APEX$ROW_ACTION'
,p_session_state_data_type=>'VARCHAR2'
,p_item_type=>'NATIVE_ROW_ACTION'
,p_display_sequence=>20
,p_use_as_row_header=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(222832747085009919)
,p_name=>'APEX$ROW_SELECTOR'
,p_session_state_data_type=>'VARCHAR2'
,p_item_type=>'NATIVE_ROW_SELECTOR'
,p_display_sequence=>10
,p_attribute_01=>'Y'
,p_attribute_02=>'Y'
,p_attribute_03=>'N'
,p_use_as_row_header=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(269628747220797409)
,p_name=>'N5'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'N5'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>180
,p_attribute_01=>'Y'
,p_filter_is_required=>false
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(269628848042797410)
,p_name=>'N6'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'N6'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>190
,p_attribute_01=>'Y'
,p_filter_is_required=>false
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(269628967331797411)
,p_name=>'N7'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'N7'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>200
,p_attribute_01=>'Y'
,p_filter_is_required=>false
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(269629046634797412)
,p_name=>'N8'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'N8'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>210
,p_attribute_01=>'Y'
,p_filter_is_required=>false
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(269629196210797413)
,p_name=>'COMPANIA'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'COMPANIA'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>220
,p_attribute_01=>'Y'
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_is_primary_key=>false
,p_default_type=>'ITEM'
,p_default_expression=>'G_COMPANIA'
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_interactive_grid(
 p_id=>wwv_flow_imp.id(222831085629009902)
,p_internal_uid=>222831085629009902
,p_is_editable=>true
,p_edit_operations=>'i:u:d'
,p_lost_update_check_type=>'VALUES'
,p_add_row_if_empty=>false
,p_submit_checked_rows=>false
,p_lazy_loading=>false
,p_requires_filter=>false
,p_select_first_row=>true
,p_fixed_row_height=>true
,p_pagination_type=>'SCROLL'
,p_show_total_row_count=>true
,p_show_toolbar=>true
,p_enable_save_public_report=>false
,p_enable_subscriptions=>true
,p_enable_flashback=>true
,p_define_chart_view=>true
,p_enable_download=>true
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>true
,p_fixed_header=>'PAGE'
,p_show_icon_view=>false
,p_show_detail_view=>false
);
wwv_flow_imp_page.create_ig_report(
 p_id=>wwv_flow_imp.id(222837314084063184)
,p_interactive_grid_id=>wwv_flow_imp.id(222831085629009902)
,p_static_id=>'2228374'
,p_type=>'PRIMARY'
,p_default_view=>'GRID'
,p_show_row_number=>false
,p_settings_area_expanded=>false
);
wwv_flow_imp_page.create_ig_report_view(
 p_id=>wwv_flow_imp.id(222837563680063186)
,p_report_id=>wwv_flow_imp.id(222837314084063184)
,p_view_type=>'GRID'
,p_stretch_columns=>true
,p_srv_exclude_null_values=>false
,p_srv_only_display_columns=>true
,p_edit_mode=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(222838045213063191)
,p_view_id=>wwv_flow_imp.id(222837563680063186)
,p_display_seq=>5
,p_column_id=>wwv_flow_imp.id(222831166512009903)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(222838917658063195)
,p_view_id=>wwv_flow_imp.id(222837563680063186)
,p_display_seq=>6
,p_column_id=>wwv_flow_imp.id(222831251549009904)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(222839864020063198)
,p_view_id=>wwv_flow_imp.id(222837563680063186)
,p_display_seq=>8
,p_column_id=>wwv_flow_imp.id(222831387391009905)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(222840782412063200)
,p_view_id=>wwv_flow_imp.id(222837563680063186)
,p_display_seq=>9
,p_column_id=>wwv_flow_imp.id(222831447803009906)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(222841641942063202)
,p_view_id=>wwv_flow_imp.id(222837563680063186)
,p_display_seq=>10
,p_column_id=>wwv_flow_imp.id(222831574268009907)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(222842558440063204)
,p_view_id=>wwv_flow_imp.id(222837563680063186)
,p_display_seq=>11
,p_column_id=>wwv_flow_imp.id(222831666299009908)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(222843479509063206)
,p_view_id=>wwv_flow_imp.id(222837563680063186)
,p_display_seq=>12
,p_column_id=>wwv_flow_imp.id(222831754755009909)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(222844367607063208)
,p_view_id=>wwv_flow_imp.id(222837563680063186)
,p_display_seq=>2
,p_column_id=>wwv_flow_imp.id(222831879076009910)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>306
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(222845267817063209)
,p_view_id=>wwv_flow_imp.id(222837563680063186)
,p_display_seq=>3
,p_column_id=>wwv_flow_imp.id(222831993460009911)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(222846159000063211)
,p_view_id=>wwv_flow_imp.id(222837563680063186)
,p_display_seq=>4
,p_column_id=>wwv_flow_imp.id(222832057680009912)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>207.188
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(222847009542063213)
,p_view_id=>wwv_flow_imp.id(222837563680063186)
,p_display_seq=>7
,p_column_id=>wwv_flow_imp.id(222832126450009913)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(222847936807063215)
,p_view_id=>wwv_flow_imp.id(222837563680063186)
,p_display_seq=>13
,p_column_id=>wwv_flow_imp.id(222832206482009914)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(222848893134063217)
,p_view_id=>wwv_flow_imp.id(222837563680063186)
,p_display_seq=>14
,p_column_id=>wwv_flow_imp.id(222832314359009915)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(222849795774063218)
,p_view_id=>wwv_flow_imp.id(222837563680063186)
,p_display_seq=>15
,p_column_id=>wwv_flow_imp.id(222832466174009916)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(222850636251063221)
,p_view_id=>wwv_flow_imp.id(222837563680063186)
,p_display_seq=>16
,p_column_id=>wwv_flow_imp.id(222832589291009917)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(222852406637085713)
,p_view_id=>wwv_flow_imp.id(222837563680063186)
,p_display_seq=>1
,p_column_id=>wwv_flow_imp.id(222832635536009918)
,p_is_visible=>true
,p_is_frozen=>true
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(269655025743905327)
,p_view_id=>wwv_flow_imp.id(222837563680063186)
,p_display_seq=>17
,p_column_id=>wwv_flow_imp.id(269628747220797409)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(269655904588905329)
,p_view_id=>wwv_flow_imp.id(222837563680063186)
,p_display_seq=>18
,p_column_id=>wwv_flow_imp.id(269628848042797410)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(269656818543905331)
,p_view_id=>wwv_flow_imp.id(222837563680063186)
,p_display_seq=>19
,p_column_id=>wwv_flow_imp.id(269628967331797411)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(269657683162905333)
,p_view_id=>wwv_flow_imp.id(222837563680063186)
,p_display_seq=>20
,p_column_id=>wwv_flow_imp.id(269629046634797412)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(269658572758905335)
,p_view_id=>wwv_flow_imp.id(222837563680063186)
,p_display_seq=>21
,p_column_id=>wwv_flow_imp.id(269629196210797413)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_aggregate(
 p_id=>wwv_flow_imp.id(160116000000)
,p_view_id=>wwv_flow_imp.id(222837563680063186)
,p_function=>'SUM'
,p_column_id=>wwv_flow_imp.id(222831574268009907)
,p_show_grand_total=>false
,p_is_enabled=>true
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(222833570233009927)
,p_plug_name=>'Incremento Neto Empleados'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(38289867500120143)
,p_plug_display_sequence=>90
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_plug_display_when_condition=>'P145_TIPOCARGA'
,p_plug_display_when_cond2=>'INE'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(222833948258009931)
,p_plug_name=>'Incremento'
,p_parent_plug_id=>wwv_flow_imp.id(222833570233009927)
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(37806762584106520)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'TABLE'
,p_query_table=>'T_FINZ_CARGASMANUALES'
,p_query_where=>'TIPO=:P145_TIPOCARGA AND ANIO=:P145_ANIO AND MES=:P145_MES AND ESTADO=1'
,p_query_order_by_type=>'STATIC'
,p_query_order_by=>'N4'
,p_include_rowid_column=>false
,p_plug_source_type=>'NATIVE_IG'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'Incremento'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(222834134950009933)
,p_name=>'ID'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'ID'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>30
,p_attribute_01=>'Y'
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_is_primary_key=>true
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(222834239768009934)
,p_name=>'TIPO'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'TIPO'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>40
,p_attribute_01=>'Y'
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_is_primary_key=>false
,p_default_type=>'ITEM'
,p_default_expression=>'P145_TIPOCARGA'
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(222834325873009935)
,p_name=>'ANIO'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'ANIO'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>50
,p_attribute_01=>'Y'
,p_filter_is_required=>false
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_is_primary_key=>false
,p_default_type=>'ITEM'
,p_default_expression=>'P145_ANIO'
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(222834495008009936)
,p_name=>'MES'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'MES'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>60
,p_attribute_01=>'Y'
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(222834578175009937)
,p_name=>'N1'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'N1'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_NUMBER_FIELD'
,p_heading=>'&P145_ANIO.'
,p_heading_alignment=>'CENTER'
,p_display_sequence=>70
,p_value_alignment=>'RIGHT'
,p_attribute_03=>'left'
,p_attribute_04=>'decimal'
,p_is_required=>false
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
,p_readonly_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_readonly_condition=>'VC2'
,p_readonly_condition2=>'SI'
,p_readonly_for_each_row=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(222834628079009938)
,p_name=>'N2'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'N2'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>80
,p_attribute_01=>'Y'
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(222834774246009939)
,p_name=>'N3'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'N3'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>90
,p_attribute_01=>'Y'
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(222834845272009940)
,p_name=>'VC1'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'VC1'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>unistr('Descripci\00F3n')
,p_heading_alignment=>'CENTER'
,p_display_sequence=>100
,p_value_alignment=>'LEFT'
,p_attribute_05=>'BOTH'
,p_is_required=>false
,p_max_length=>50
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(222834966339009941)
,p_name=>'VC2'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'VC2'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>110
,p_attribute_01=>'Y'
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(222835043109009942)
,p_name=>'VC3'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'VC3'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>120
,p_attribute_01=>'Y'
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(222835103564009943)
,p_name=>'DT1'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'DT1'
,p_data_type=>'DATE'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>130
,p_attribute_01=>'Y'
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(222835238101009944)
,p_name=>'DT2'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'DT2'
,p_data_type=>'DATE'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>140
,p_attribute_01=>'Y'
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(222835380340009945)
,p_name=>'DT3'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'DT3'
,p_data_type=>'DATE'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>150
,p_attribute_01=>'Y'
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(222835436856009946)
,p_name=>'ESTADO'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'ESTADO'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>160
,p_attribute_01=>'Y'
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_is_primary_key=>false
,p_default_type=>'STATIC'
,p_default_expression=>'1'
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(222835537558009947)
,p_name=>'N4'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'N4'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>170
,p_attribute_01=>'Y'
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(222835624678009948)
,p_name=>'APEX$ROW_ACTION'
,p_session_state_data_type=>'VARCHAR2'
,p_item_type=>'NATIVE_ROW_ACTION'
,p_display_sequence=>20
,p_use_as_row_header=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(222835708542009949)
,p_name=>'APEX$ROW_SELECTOR'
,p_session_state_data_type=>'VARCHAR2'
,p_item_type=>'NATIVE_ROW_SELECTOR'
,p_display_sequence=>10
,p_attribute_01=>'Y'
,p_attribute_02=>'Y'
,p_attribute_03=>'N'
,p_use_as_row_header=>false
);
wwv_flow_imp_page.create_interactive_grid(
 p_id=>wwv_flow_imp.id(222834009767009932)
,p_internal_uid=>222834009767009932
,p_is_editable=>true
,p_edit_operations=>'u:d'
,p_lost_update_check_type=>'VALUES'
,p_submit_checked_rows=>false
,p_lazy_loading=>false
,p_requires_filter=>false
,p_select_first_row=>true
,p_fixed_row_height=>true
,p_pagination_type=>'SCROLL'
,p_show_total_row_count=>true
,p_show_toolbar=>true
,p_toolbar_buttons=>'SEARCH_COLUMN:SEARCH_FIELD:ACTIONS_MENU'
,p_enable_save_public_report=>false
,p_enable_subscriptions=>true
,p_enable_flashback=>true
,p_define_chart_view=>true
,p_enable_download=>true
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>true
,p_fixed_header=>'PAGE'
,p_show_icon_view=>false
,p_show_detail_view=>false
);
wwv_flow_imp_page.create_ig_report(
 p_id=>wwv_flow_imp.id(225022699164216689)
,p_interactive_grid_id=>wwv_flow_imp.id(222834009767009932)
,p_static_id=>'2250227'
,p_type=>'PRIMARY'
,p_default_view=>'GRID'
,p_show_row_number=>false
,p_settings_area_expanded=>true
);
wwv_flow_imp_page.create_ig_report_view(
 p_id=>wwv_flow_imp.id(225022806477216695)
,p_report_id=>wwv_flow_imp.id(225022699164216689)
,p_view_type=>'GRID'
,p_stretch_columns=>true
,p_srv_exclude_null_values=>false
,p_srv_only_display_columns=>true
,p_edit_mode=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(225023325222216704)
,p_view_id=>wwv_flow_imp.id(225022806477216695)
,p_display_seq=>2
,p_column_id=>wwv_flow_imp.id(222834134950009933)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(225024295091216714)
,p_view_id=>wwv_flow_imp.id(225022806477216695)
,p_display_seq=>3
,p_column_id=>wwv_flow_imp.id(222834239768009934)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(225025161633216717)
,p_view_id=>wwv_flow_imp.id(225022806477216695)
,p_display_seq=>4
,p_column_id=>wwv_flow_imp.id(222834325873009935)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(225026077610216719)
,p_view_id=>wwv_flow_imp.id(225022806477216695)
,p_display_seq=>5
,p_column_id=>wwv_flow_imp.id(222834495008009936)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(225026956551216721)
,p_view_id=>wwv_flow_imp.id(225022806477216695)
,p_display_seq=>7
,p_column_id=>wwv_flow_imp.id(222834578175009937)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>151
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(225027811964216723)
,p_view_id=>wwv_flow_imp.id(225022806477216695)
,p_display_seq=>8
,p_column_id=>wwv_flow_imp.id(222834628079009938)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(225028782267216726)
,p_view_id=>wwv_flow_imp.id(225022806477216695)
,p_display_seq=>9
,p_column_id=>wwv_flow_imp.id(222834774246009939)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(225029622168216728)
,p_view_id=>wwv_flow_imp.id(225022806477216695)
,p_display_seq=>6
,p_column_id=>wwv_flow_imp.id(222834845272009940)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>640
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(225030505290216730)
,p_view_id=>wwv_flow_imp.id(225022806477216695)
,p_display_seq=>10
,p_column_id=>wwv_flow_imp.id(222834966339009941)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(225031481848216733)
,p_view_id=>wwv_flow_imp.id(225022806477216695)
,p_display_seq=>11
,p_column_id=>wwv_flow_imp.id(222835043109009942)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(225032326677216735)
,p_view_id=>wwv_flow_imp.id(225022806477216695)
,p_display_seq=>12
,p_column_id=>wwv_flow_imp.id(222835103564009943)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(225033262463216737)
,p_view_id=>wwv_flow_imp.id(225022806477216695)
,p_display_seq=>13
,p_column_id=>wwv_flow_imp.id(222835238101009944)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(225034171205216739)
,p_view_id=>wwv_flow_imp.id(225022806477216695)
,p_display_seq=>14
,p_column_id=>wwv_flow_imp.id(222835380340009945)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(225035017888216741)
,p_view_id=>wwv_flow_imp.id(225022806477216695)
,p_display_seq=>15
,p_column_id=>wwv_flow_imp.id(222835436856009946)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(225035934962216743)
,p_view_id=>wwv_flow_imp.id(225022806477216695)
,p_display_seq=>16
,p_column_id=>wwv_flow_imp.id(222835537558009947)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(225036815688216745)
,p_view_id=>wwv_flow_imp.id(225022806477216695)
,p_display_seq=>1
,p_column_id=>wwv_flow_imp.id(222835624678009948)
,p_is_visible=>true
,p_is_frozen=>true
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(225043166199262436)
,p_plug_name=>'Contratos Discapacidad'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(38289867500120143)
,p_plug_display_sequence=>110
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_plug_display_when_condition=>'P145_TIPOCARGA'
,p_plug_display_when_cond2=>'ECD'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(225043217624262437)
,p_plug_name=>'Discapacidad'
,p_parent_plug_id=>wwv_flow_imp.id(225043166199262436)
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(37806762584106520)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'TABLE'
,p_query_table=>'T_FINZ_CARGASMANUALES'
,p_query_where=>'TIPO=:P145_TIPOCARGA AND ANIO=:P145_ANIO AND VC2 IS NULL AND MES=:P145_MES AND ESTADO=1'
,p_include_rowid_column=>false
,p_plug_source_type=>'NATIVE_IG'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'Discapacidad'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(225043485237262439)
,p_name=>'ID'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'ID'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>30
,p_attribute_01=>'Y'
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_is_primary_key=>true
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(225043517011262440)
,p_name=>'TIPO'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'TIPO'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>40
,p_attribute_01=>'Y'
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_is_primary_key=>false
,p_default_type=>'ITEM'
,p_default_expression=>'P145_TIPOCARGA'
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(225043622314262441)
,p_name=>'ANIO'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'ANIO'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_NUMBER_FIELD'
,p_heading=>unistr('A\00F1o')
,p_heading_alignment=>'CENTER'
,p_display_sequence=>50
,p_value_alignment=>'CENTER'
,p_attribute_03=>'left'
,p_attribute_04=>'decimal'
,p_is_required=>false
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_default_type=>'ITEM'
,p_default_expression=>'P145_ANIO'
,p_duplicate_value=>true
,p_include_in_export=>true
,p_readonly_condition_type=>'ALWAYS'
,p_readonly_for_each_row=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(225043745438262442)
,p_name=>'MES'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'MES'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>60
,p_attribute_01=>'Y'
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_is_primary_key=>false
,p_default_type=>'ITEM'
,p_default_expression=>'P145_MES'
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(225043828954262443)
,p_name=>'N1'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'N1'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_NUMBER_FIELD'
,p_heading=>unistr('No. total<br>empleados bajo<br>relaci\00F3n de<br>dependencia')
,p_heading_alignment=>'CENTER'
,p_display_sequence=>70
,p_value_alignment=>'RIGHT'
,p_attribute_03=>'left'
,p_attribute_04=>'decimal'
,p_is_required=>false
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(225043934955262444)
,p_name=>'N2'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'N2'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_NUMBER_FIELD'
,p_heading=>unistr('% de inclusi\00F3n<br>laboral a personas<br>con discapacidad ')
,p_heading_alignment=>'CENTER'
,p_display_sequence=>80
,p_value_alignment=>'RIGHT'
,p_attribute_03=>'left'
,p_attribute_04=>'decimal'
,p_is_required=>false
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(225044038429262445)
,p_name=>'N3'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'N3'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_NUMBER_FIELD'
,p_heading=>unistr('No. m\00EDnimo de<br>inclusi\00F3n laboral<br>a personas<br>con discapacidad<br>en la empresa')
,p_heading_alignment=>'CENTER'
,p_display_sequence=>90
,p_value_alignment=>'RIGHT'
,p_attribute_03=>'left'
,p_attribute_04=>'decimal'
,p_is_required=>false
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
,p_readonly_condition_type=>'ALWAYS'
,p_readonly_for_each_row=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(225044101019262446)
,p_name=>'VC1'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'VC1'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_SELECT_LIST'
,p_heading=>'Mes'
,p_heading_alignment=>'CENTER'
,p_display_sequence=>100
,p_value_alignment=>'CENTER'
,p_is_required=>false
,p_lov_type=>'SHARED'
,p_lov_id=>wwv_flow_imp.id(350337138530635159)
,p_lov_display_extra=>false
,p_lov_display_null=>false
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'LOV'
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(225044289187262447)
,p_name=>'VC2'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'VC2'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>110
,p_attribute_01=>'Y'
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(225044326653262448)
,p_name=>'VC3'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'VC3'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>120
,p_attribute_01=>'Y'
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(225044478235262449)
,p_name=>'DT1'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'DT1'
,p_data_type=>'DATE'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>130
,p_attribute_01=>'Y'
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(225044596981262450)
,p_name=>'DT2'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'DT2'
,p_data_type=>'DATE'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>140
,p_attribute_01=>'Y'
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(231045439757818801)
,p_name=>'DT3'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'DT3'
,p_data_type=>'DATE'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>150
,p_attribute_01=>'Y'
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(231045596947818802)
,p_name=>'ESTADO'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'ESTADO'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>160
,p_attribute_01=>'Y'
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_is_primary_key=>false
,p_default_type=>'STATIC'
,p_default_expression=>'1'
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(231045630323818803)
,p_name=>'N4'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'N4'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_NUMBER_FIELD'
,p_heading=>'No. total de<br>personas con discapacidad<br>o sus sustitutos<br>que trabajan<br>en la empresa'
,p_heading_alignment=>'CENTER'
,p_display_sequence=>170
,p_value_alignment=>'RIGHT'
,p_attribute_03=>'left'
,p_attribute_04=>'decimal'
,p_is_required=>false
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(231045754546818804)
,p_name=>'N5'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'N5'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_NUMBER_FIELD'
,p_heading=>unistr('No. de personas<br>contratadas que<br>exceden el n\00FAmero<br>m\00EDnimo de inclusi\00F3n<br>laboral para personas<br>con discapacidad')
,p_heading_alignment=>'CENTER'
,p_display_sequence=>180
,p_value_alignment=>'RIGHT'
,p_attribute_03=>'left'
,p_attribute_04=>'decimal'
,p_is_required=>false
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
,p_readonly_condition_type=>'ALWAYS'
,p_readonly_for_each_row=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(231045817545818805)
,p_name=>'N6'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'N6'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_NUMBER_FIELD'
,p_heading=>'Valor total de<br>remuneraciones y beneficios<br>sociales pagados<br>a empleados<br>contratados con<br>discapacidad o<br>sus sustitutos'
,p_heading_alignment=>'CENTER'
,p_display_sequence=>190
,p_value_alignment=>'RIGHT'
,p_attribute_03=>'left'
,p_attribute_04=>'decimal'
,p_is_required=>false
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(231045939039818806)
,p_name=>'N7'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'N7'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_NUMBER_FIELD'
,p_heading_alignment=>'RIGHT'
,p_display_sequence=>200
,p_value_alignment=>'RIGHT'
,p_attribute_03=>'left'
,p_attribute_04=>'decimal'
,p_is_required=>false
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(231046043929818807)
,p_name=>'N8'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'N8'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_NUMBER_FIELD'
,p_heading=>unistr('Deducci\00F3n adicional<br>por pago a empleados<br>contratados con<br>discapacidad o sus<br>sustitutos')
,p_heading_alignment=>'CENTER'
,p_display_sequence=>210
,p_value_alignment=>'RIGHT'
,p_attribute_03=>'left'
,p_attribute_04=>'decimal'
,p_is_required=>false
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
,p_readonly_condition_type=>'ALWAYS'
,p_readonly_for_each_row=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(231046150631818808)
,p_name=>'APEX$ROW_ACTION'
,p_session_state_data_type=>'VARCHAR2'
,p_item_type=>'NATIVE_ROW_ACTION'
,p_display_sequence=>20
,p_use_as_row_header=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(231046216103818809)
,p_name=>'APEX$ROW_SELECTOR'
,p_session_state_data_type=>'VARCHAR2'
,p_item_type=>'NATIVE_ROW_SELECTOR'
,p_display_sequence=>10
,p_attribute_01=>'Y'
,p_attribute_02=>'Y'
,p_attribute_03=>'N'
,p_use_as_row_header=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(269629209719797414)
,p_name=>'COMPANIA'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'COMPANIA'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>220
,p_attribute_01=>'Y'
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_is_primary_key=>false
,p_default_type=>'ITEM'
,p_default_expression=>'G_COMPANIA'
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_interactive_grid(
 p_id=>wwv_flow_imp.id(225043315444262438)
,p_internal_uid=>225043315444262438
,p_is_editable=>true
,p_edit_operations=>'i:u:d'
,p_lost_update_check_type=>'VALUES'
,p_add_row_if_empty=>false
,p_submit_checked_rows=>false
,p_lazy_loading=>false
,p_requires_filter=>false
,p_select_first_row=>true
,p_fixed_row_height=>true
,p_pagination_type=>'SCROLL'
,p_show_total_row_count=>false
,p_show_toolbar=>true
,p_toolbar_buttons=>'SEARCH_COLUMN:SEARCH_FIELD:ACTIONS_MENU:RESET'
,p_enable_save_public_report=>false
,p_enable_subscriptions=>true
,p_enable_flashback=>true
,p_define_chart_view=>true
,p_enable_download=>true
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>true
,p_fixed_header=>'PAGE'
,p_show_icon_view=>false
,p_show_detail_view=>false
);
wwv_flow_imp_page.create_ig_report(
 p_id=>wwv_flow_imp.id(231051255048884524)
,p_interactive_grid_id=>wwv_flow_imp.id(225043315444262438)
,p_static_id=>'2310513'
,p_type=>'PRIMARY'
,p_default_view=>'GRID'
,p_show_row_number=>false
,p_settings_area_expanded=>true
);
wwv_flow_imp_page.create_ig_report_view(
 p_id=>wwv_flow_imp.id(231051468179884527)
,p_report_id=>wwv_flow_imp.id(231051255048884524)
,p_view_type=>'GRID'
,p_stretch_columns=>true
,p_srv_exclude_null_values=>false
,p_srv_only_display_columns=>true
,p_edit_mode=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(231051946495884533)
,p_view_id=>wwv_flow_imp.id(231051468179884527)
,p_display_seq=>2
,p_column_id=>wwv_flow_imp.id(225043485237262439)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(231052816834884539)
,p_view_id=>wwv_flow_imp.id(231051468179884527)
,p_display_seq=>4
,p_column_id=>wwv_flow_imp.id(225043517011262440)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(231053780598884541)
,p_view_id=>wwv_flow_imp.id(231051468179884527)
,p_display_seq=>3
,p_column_id=>wwv_flow_imp.id(225043622314262441)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>65
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(231054698372884543)
,p_view_id=>wwv_flow_imp.id(231051468179884527)
,p_display_seq=>6
,p_column_id=>wwv_flow_imp.id(225043745438262442)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(231055505533884545)
,p_view_id=>wwv_flow_imp.id(231051468179884527)
,p_display_seq=>7
,p_column_id=>wwv_flow_imp.id(225043828954262443)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>128
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(231056431030884547)
,p_view_id=>wwv_flow_imp.id(231051468179884527)
,p_display_seq=>8
,p_column_id=>wwv_flow_imp.id(225043934955262444)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>144
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(231057394211884549)
,p_view_id=>wwv_flow_imp.id(231051468179884527)
,p_display_seq=>9
,p_column_id=>wwv_flow_imp.id(225044038429262445)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>126
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(231058269891884551)
,p_view_id=>wwv_flow_imp.id(231051468179884527)
,p_display_seq=>5
,p_column_id=>wwv_flow_imp.id(225044101019262446)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>79
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(231059160750884553)
,p_view_id=>wwv_flow_imp.id(231051468179884527)
,p_display_seq=>10
,p_column_id=>wwv_flow_imp.id(225044289187262447)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(231060016948884555)
,p_view_id=>wwv_flow_imp.id(231051468179884527)
,p_display_seq=>11
,p_column_id=>wwv_flow_imp.id(225044326653262448)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(231060934354884557)
,p_view_id=>wwv_flow_imp.id(231051468179884527)
,p_display_seq=>12
,p_column_id=>wwv_flow_imp.id(225044478235262449)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(231061854270884559)
,p_view_id=>wwv_flow_imp.id(231051468179884527)
,p_display_seq=>13
,p_column_id=>wwv_flow_imp.id(225044596981262450)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(231062707116884561)
,p_view_id=>wwv_flow_imp.id(231051468179884527)
,p_display_seq=>14
,p_column_id=>wwv_flow_imp.id(231045439757818801)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(231063631342884563)
,p_view_id=>wwv_flow_imp.id(231051468179884527)
,p_display_seq=>15
,p_column_id=>wwv_flow_imp.id(231045596947818802)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(231064596673884565)
,p_view_id=>wwv_flow_imp.id(231051468179884527)
,p_display_seq=>16
,p_column_id=>wwv_flow_imp.id(231045630323818803)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>182
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(231065471075884567)
,p_view_id=>wwv_flow_imp.id(231051468179884527)
,p_display_seq=>17
,p_column_id=>wwv_flow_imp.id(231045754546818804)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>143
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(231066315976884569)
,p_view_id=>wwv_flow_imp.id(231051468179884527)
,p_display_seq=>18
,p_column_id=>wwv_flow_imp.id(231045817545818805)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>190
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(231067249120884571)
,p_view_id=>wwv_flow_imp.id(231051468179884527)
,p_display_seq=>19
,p_column_id=>wwv_flow_imp.id(231045939039818806)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(231068199960884573)
,p_view_id=>wwv_flow_imp.id(231051468179884527)
,p_display_seq=>20
,p_column_id=>wwv_flow_imp.id(231046043929818807)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>151
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(231068987450884575)
,p_view_id=>wwv_flow_imp.id(231051468179884527)
,p_display_seq=>1
,p_column_id=>wwv_flow_imp.id(231046150631818808)
,p_is_visible=>true
,p_is_frozen=>true
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(269659488895905337)
,p_view_id=>wwv_flow_imp.id(231051468179884527)
,p_display_seq=>21
,p_column_id=>wwv_flow_imp.id(269629209719797414)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(231046783632818814)
,p_plug_name=>'Fijos'
,p_parent_plug_id=>wwv_flow_imp.id(225043166199262436)
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(38289867500120143)
,p_plug_display_sequence=>20
,p_plug_display_point=>'SUB_REGIONS'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(231049471704818841)
,p_name=>'Discapacidad_resumen'
,p_parent_plug_id=>wwv_flow_imp.id(225043166199262436)
,p_template=>wwv_flow_imp.id(38289867500120143)
,p_display_sequence=>30
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_display_point=>'SUB_REGIONS'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT VC1,N8',
'FROM T_FINZ_CARGASMANUALES',
'WHERE TIPO=:P145_TIPOCARGA AND ANIO=:P145_ANIO AND VC2=''SI''',
'AND MES=:P145_MES AND ESTADO=1',
'ORDER BY ID'))
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(37830327650106535)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(231049593914818842)
,p_query_column_id=>1
,p_column_alias=>'VC1'
,p_column_display_sequence=>10
,p_use_as_row_header=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(231049634828818843)
,p_query_column_id=>2
,p_column_alias=>'N8'
,p_column_display_sequence=>20
,p_column_heading=>'&P145_ANIO.'
,p_use_as_row_header=>'N'
,p_column_alignment=>'RIGHT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(231049754922818844)
,p_plug_name=>'Adultos Mayores o Migrantes'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(38289867500120143)
,p_plug_display_sequence=>120
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_plug_display_when_condition=>'P145_TIPOCARGA'
,p_plug_display_when_cond2=>'AMM'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(231049887634818845)
,p_plug_name=>'Mayores_Migrantes'
,p_parent_plug_id=>wwv_flow_imp.id(231049754922818844)
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(37806762584106520)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'TABLE'
,p_query_table=>'T_FINZ_CARGASMANUALES'
,p_query_where=>wwv_flow_string.join(wwv_flow_t_varchar2(
'TIPO=:P145_TIPOCARGA AND ANIO=:P145_ANIO AND VC2 IS NULL',
'AND MES=:P145_MES AND ESTADO=1'))
,p_include_rowid_column=>false
,p_plug_source_type=>'NATIVE_IG'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'Mayores_Migrantes'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(231050004154818847)
,p_name=>'ID'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'ID'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>30
,p_attribute_01=>'Y'
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_is_primary_key=>true
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(231050179864818848)
,p_name=>'TIPO'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'TIPO'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>40
,p_attribute_01=>'Y'
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_is_primary_key=>false
,p_default_type=>'ITEM'
,p_default_expression=>'P145_TIPOCARGA'
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(231050210170818849)
,p_name=>'ANIO'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'ANIO'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_DISPLAY_ONLY'
,p_heading=>unistr('A\00F1o')
,p_heading_alignment=>'CENTER'
,p_display_sequence=>50
,p_value_alignment=>'LEFT'
,p_attribute_02=>'VALUE'
,p_attribute_05=>'PLAIN'
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_default_type=>'ITEM'
,p_default_expression=>'P145_ANIO'
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(231050380961818850)
,p_name=>'MES'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'MES'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_SELECT_LIST'
,p_heading=>'Mes'
,p_heading_alignment=>'CENTER'
,p_display_sequence=>60
,p_value_alignment=>'LEFT'
,p_is_required=>false
,p_lov_type=>'SHARED'
,p_lov_id=>wwv_flow_imp.id(350337138530635159)
,p_lov_display_extra=>false
,p_lov_display_null=>false
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'LOV'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(231924971722750401)
,p_name=>'N1'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'N1'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_NUMBER_FIELD'
,p_heading=>'No. total de empleados<br>adultos mayores'
,p_heading_alignment=>'RIGHT'
,p_display_sequence=>70
,p_value_alignment=>'RIGHT'
,p_attribute_03=>'left'
,p_attribute_04=>'decimal'
,p_is_required=>false
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(231925056279750402)
,p_name=>'N2'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'N2'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_NUMBER_FIELD'
,p_heading=>unistr('No. total de<br>empleados migrantes<br>retornados mayores<br>de 40 a\00F1os')
,p_heading_alignment=>'CENTER'
,p_display_sequence=>80
,p_value_alignment=>'RIGHT'
,p_attribute_03=>'left'
,p_attribute_04=>'decimal'
,p_is_required=>false
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(231925132294750403)
,p_name=>'N3'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'N3'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_NUMBER_FIELD'
,p_heading=>'Total remuneraciones y<br>beneficios sociales pagados<br>a empleados adultos<br>mayores'
,p_heading_alignment=>'CENTER'
,p_display_sequence=>90
,p_value_alignment=>'RIGHT'
,p_attribute_03=>'left'
,p_attribute_04=>'decimal'
,p_is_required=>false
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(231925278343750404)
,p_name=>'VC1'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'VC1'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>100
,p_attribute_01=>'Y'
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(231925330947750405)
,p_name=>'VC2'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'VC2'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>110
,p_attribute_01=>'Y'
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(231925436202750406)
,p_name=>'VC3'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'VC3'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>120
,p_attribute_01=>'Y'
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(231925550734750407)
,p_name=>'DT1'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'DT1'
,p_data_type=>'DATE'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>130
,p_attribute_01=>'Y'
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(231925631560750408)
,p_name=>'DT2'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'DT2'
,p_data_type=>'DATE'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>140
,p_attribute_01=>'Y'
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(231925774559750409)
,p_name=>'DT3'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'DT3'
,p_data_type=>'DATE'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>150
,p_attribute_01=>'Y'
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(231925825838750410)
,p_name=>'ESTADO'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'ESTADO'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>160
,p_attribute_01=>'Y'
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_is_primary_key=>false
,p_default_type=>'STATIC'
,p_default_expression=>'1'
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(231925954236750411)
,p_name=>'N4'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'N4'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_NUMBER_FIELD'
,p_heading=>unistr('Total remuneraciones<br>y beneficios sociales<br>pagados a empleados<br>migrantes retornados<br>mayores de 40 a\00F1os')
,p_heading_alignment=>'CENTER'
,p_display_sequence=>170
,p_value_alignment=>'RIGHT'
,p_attribute_03=>'left'
,p_attribute_04=>'decimal'
,p_is_required=>false
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(231926091424750412)
,p_name=>'N5'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'N5'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_NUMBER_FIELD'
,p_heading=>unistr('Total remuneraciones y<br>beneficios sociales pagados<br>a empleados adultos<br>mayores y migrantes<br>retornados mayores<br>a 40 a\00F1o')
,p_heading_alignment=>'CENTER'
,p_display_sequence=>180
,p_value_alignment=>'RIGHT'
,p_attribute_03=>'left'
,p_attribute_04=>'decimal'
,p_is_required=>false
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
,p_readonly_condition_type=>'ALWAYS'
,p_readonly_for_each_row=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(231926149059750413)
,p_name=>'N6'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'N6'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>190
,p_attribute_01=>'Y'
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(231926253763750414)
,p_name=>'N7'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'N7'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>200
,p_attribute_01=>'Y'
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(231926375960750415)
,p_name=>'N8'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'N8'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_NUMBER_FIELD'
,p_heading=>unistr('Deducci\00F3n adicional<br>por pago a empleados<br>adultos mayores<br>y migrantes retornados<br>mayores a 40 a\00F1os')
,p_heading_alignment=>'CENTER'
,p_display_sequence=>210
,p_value_alignment=>'RIGHT'
,p_attribute_03=>'left'
,p_attribute_04=>'decimal'
,p_is_required=>false
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
,p_readonly_condition_type=>'ALWAYS'
,p_readonly_for_each_row=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(231926493885750416)
,p_name=>'APEX$ROW_ACTION'
,p_session_state_data_type=>'VARCHAR2'
,p_item_type=>'NATIVE_ROW_ACTION'
,p_display_sequence=>20
,p_use_as_row_header=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(231926528911750417)
,p_name=>'APEX$ROW_SELECTOR'
,p_session_state_data_type=>'VARCHAR2'
,p_item_type=>'NATIVE_ROW_SELECTOR'
,p_display_sequence=>10
,p_attribute_01=>'Y'
,p_attribute_02=>'Y'
,p_attribute_03=>'N'
,p_use_as_row_header=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(269629337194797415)
,p_name=>'COMPANIA'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'COMPANIA'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>220
,p_attribute_01=>'Y'
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_is_primary_key=>false
,p_default_type=>'ITEM'
,p_default_expression=>'G_COMPANIA'
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_interactive_grid(
 p_id=>wwv_flow_imp.id(231049966647818846)
,p_internal_uid=>231049966647818846
,p_is_editable=>true
,p_edit_operations=>'i:u:d'
,p_lost_update_check_type=>'VALUES'
,p_add_row_if_empty=>false
,p_submit_checked_rows=>false
,p_lazy_loading=>false
,p_requires_filter=>false
,p_select_first_row=>true
,p_fixed_row_height=>true
,p_pagination_type=>'SCROLL'
,p_show_total_row_count=>true
,p_show_toolbar=>true
,p_toolbar_buttons=>'SEARCH_COLUMN:SEARCH_FIELD:ACTIONS_MENU'
,p_enable_save_public_report=>false
,p_enable_subscriptions=>true
,p_enable_flashback=>true
,p_define_chart_view=>true
,p_enable_download=>true
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>true
,p_fixed_header=>'PAGE'
,p_show_icon_view=>false
,p_show_detail_view=>false
);
wwv_flow_imp_page.create_ig_report(
 p_id=>wwv_flow_imp.id(231931221819781671)
,p_interactive_grid_id=>wwv_flow_imp.id(231049966647818846)
,p_static_id=>'2319313'
,p_type=>'PRIMARY'
,p_default_view=>'GRID'
,p_show_row_number=>false
,p_settings_area_expanded=>true
);
wwv_flow_imp_page.create_ig_report_view(
 p_id=>wwv_flow_imp.id(231931477456781671)
,p_report_id=>wwv_flow_imp.id(231931221819781671)
,p_view_type=>'GRID'
,p_stretch_columns=>true
,p_srv_exclude_null_values=>false
,p_srv_only_display_columns=>true
,p_edit_mode=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(231931821216781675)
,p_view_id=>wwv_flow_imp.id(231931477456781671)
,p_display_seq=>2
,p_column_id=>wwv_flow_imp.id(231050004154818847)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(231932738702781680)
,p_view_id=>wwv_flow_imp.id(231931477456781671)
,p_display_seq=>3
,p_column_id=>wwv_flow_imp.id(231050179864818848)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(231933632839781682)
,p_view_id=>wwv_flow_imp.id(231931477456781671)
,p_display_seq=>4
,p_column_id=>wwv_flow_imp.id(231050210170818849)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(231934541391781684)
,p_view_id=>wwv_flow_imp.id(231931477456781671)
,p_display_seq=>5
,p_column_id=>wwv_flow_imp.id(231050380961818850)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(231935445742781686)
,p_view_id=>wwv_flow_imp.id(231931477456781671)
,p_display_seq=>6
,p_column_id=>wwv_flow_imp.id(231924971722750401)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>149
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(231936315392781689)
,p_view_id=>wwv_flow_imp.id(231931477456781671)
,p_display_seq=>7
,p_column_id=>wwv_flow_imp.id(231925056279750402)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>147
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(231937229212781690)
,p_view_id=>wwv_flow_imp.id(231931477456781671)
,p_display_seq=>8
,p_column_id=>wwv_flow_imp.id(231925132294750403)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>181
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(231938106684781692)
,p_view_id=>wwv_flow_imp.id(231931477456781671)
,p_display_seq=>9
,p_column_id=>wwv_flow_imp.id(231925278343750404)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(231939026964781694)
,p_view_id=>wwv_flow_imp.id(231931477456781671)
,p_display_seq=>10
,p_column_id=>wwv_flow_imp.id(231925330947750405)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(231939944560781696)
,p_view_id=>wwv_flow_imp.id(231931477456781671)
,p_display_seq=>11
,p_column_id=>wwv_flow_imp.id(231925436202750406)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(231940834585781697)
,p_view_id=>wwv_flow_imp.id(231931477456781671)
,p_display_seq=>12
,p_column_id=>wwv_flow_imp.id(231925550734750407)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(231941727872781699)
,p_view_id=>wwv_flow_imp.id(231931477456781671)
,p_display_seq=>13
,p_column_id=>wwv_flow_imp.id(231925631560750408)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(231942683405781701)
,p_view_id=>wwv_flow_imp.id(231931477456781671)
,p_display_seq=>14
,p_column_id=>wwv_flow_imp.id(231925774559750409)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(231943565555781703)
,p_view_id=>wwv_flow_imp.id(231931477456781671)
,p_display_seq=>15
,p_column_id=>wwv_flow_imp.id(231925825838750410)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(231944479821781705)
,p_view_id=>wwv_flow_imp.id(231931477456781671)
,p_display_seq=>16
,p_column_id=>wwv_flow_imp.id(231925954236750411)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>148
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(231945368113781707)
,p_view_id=>wwv_flow_imp.id(231931477456781671)
,p_display_seq=>17
,p_column_id=>wwv_flow_imp.id(231926091424750412)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>182
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(231946257484781708)
,p_view_id=>wwv_flow_imp.id(231931477456781671)
,p_display_seq=>18
,p_column_id=>wwv_flow_imp.id(231926149059750413)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(231947184795781710)
,p_view_id=>wwv_flow_imp.id(231931477456781671)
,p_display_seq=>19
,p_column_id=>wwv_flow_imp.id(231926253763750414)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(231948042806781712)
,p_view_id=>wwv_flow_imp.id(231931477456781671)
,p_display_seq=>20
,p_column_id=>wwv_flow_imp.id(231926375960750415)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>177
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(231948937862781713)
,p_view_id=>wwv_flow_imp.id(231931477456781671)
,p_display_seq=>1
,p_column_id=>wwv_flow_imp.id(231926493885750416)
,p_is_visible=>true
,p_is_frozen=>true
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(269660368501905339)
,p_view_id=>wwv_flow_imp.id(231931477456781671)
,p_display_seq=>21
,p_column_id=>wwv_flow_imp.id(269629337194797415)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(231927042583750422)
,p_name=>'Migrantes resumen'
,p_parent_plug_id=>wwv_flow_imp.id(231049754922818844)
,p_template=>wwv_flow_imp.id(38289867500120143)
,p_display_sequence=>20
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_display_point=>'SUB_REGIONS'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT VC1,N8',
'FROM T_FINZ_CARGASMANUALES',
'WHERE TIPO=:P145_TIPOCARGA AND ANIO=:P145_ANIO AND VC2=''SI''',
'AND MES=:P145_MES AND ESTADO=1',
'ORDER BY ID'))
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(37830327650106535)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(231927140101750423)
,p_query_column_id=>1
,p_column_alias=>'VC1'
,p_column_display_sequence=>10
,p_use_as_row_header=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(231927278270750424)
,p_query_column_id=>2
,p_column_alias=>'N8'
,p_column_display_sequence=>20
,p_column_heading=>'&P145_ANIO.'
,p_use_as_row_header=>'N'
,p_column_alignment=>'RIGHT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(254257869559609436)
,p_plug_name=>'Desahucio y Jub patronal'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(38289867500120143)
,p_plug_display_sequence=>140
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_plug_display_when_condition=>'P145_TIPOCARGA'
,p_plug_display_when_cond2=>'DJP'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(254257933762609437)
,p_plug_name=>'Desahucio_JubPatronal'
,p_parent_plug_id=>wwv_flow_imp.id(254257869559609436)
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(37806762584106520)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'TABLE'
,p_query_table=>'T_FINZ_CARGASMANUALES'
,p_query_where=>'TIPO=:P145_TIPOCARGA AND ANIO=:P145_ANIO AND MES=:P145_MES AND ESTADO=1'
,p_query_order_by_type=>'STATIC'
,p_query_order_by=>'N8'
,p_include_rowid_column=>false
,p_plug_source_type=>'NATIVE_IG'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'Desahucio_JubPatronal'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(254258182617609439)
,p_name=>'ID'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'ID'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>30
,p_attribute_01=>'Y'
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_is_primary_key=>true
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(254258262115609440)
,p_name=>'TIPO'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'TIPO'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>40
,p_attribute_01=>'Y'
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(254258349175609441)
,p_name=>'ANIO'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'ANIO'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>50
,p_attribute_01=>'Y'
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(254258429908609442)
,p_name=>'MES'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'MES'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>60
,p_attribute_01=>'Y'
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(254258535897609443)
,p_name=>'N1'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'N1'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_NUMBER_FIELD'
,p_heading=>'Valor'
,p_heading_alignment=>'RIGHT'
,p_display_sequence=>70
,p_value_alignment=>'RIGHT'
,p_attribute_03=>'left'
,p_attribute_04=>'decimal'
,p_format_mask=>'999G999G999G999G990D00'
,p_is_required=>false
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(254258632129609444)
,p_name=>'N2'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'N2'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>80
,p_attribute_01=>'Y'
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(254258758220609445)
,p_name=>'N3'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'N3'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>90
,p_attribute_01=>'Y'
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(254258846520609446)
,p_name=>'VC1'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'VC1'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXTAREA'
,p_heading=>unistr('Seg\00FAn Informe Actuarial AID')
,p_heading_alignment=>'LEFT'
,p_display_sequence=>100
,p_value_alignment=>'LEFT'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
,p_is_required=>false
,p_max_length=>150
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(254258980896609447)
,p_name=>'VC2'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'VC2'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXTAREA'
,p_heading=>unistr('Descripci\00F3n')
,p_heading_alignment=>'LEFT'
,p_display_sequence=>110
,p_value_alignment=>'LEFT'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
,p_is_required=>false
,p_max_length=>100
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(254259014586609448)
,p_name=>'VC3'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'VC3'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>120
,p_attribute_01=>'Y'
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(254259193250609449)
,p_name=>'DT1'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'DT1'
,p_data_type=>'DATE'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>130
,p_attribute_01=>'Y'
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(254259292468609450)
,p_name=>'DT2'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'DT2'
,p_data_type=>'DATE'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>140
,p_attribute_01=>'Y'
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(254936223421743701)
,p_name=>'DT3'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'DT3'
,p_data_type=>'DATE'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>150
,p_attribute_01=>'Y'
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(254936370179743702)
,p_name=>'ESTADO'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'ESTADO'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>160
,p_attribute_01=>'Y'
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(254936463104743703)
,p_name=>'N4'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'N4'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>170
,p_attribute_01=>'Y'
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(254936505509743704)
,p_name=>'N5'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'N5'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>180
,p_attribute_01=>'Y'
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(254936604627743705)
,p_name=>'N6'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'N6'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>190
,p_attribute_01=>'Y'
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(254936790209743706)
,p_name=>'N7'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'N7'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>200
,p_attribute_01=>'Y'
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(254936821784743707)
,p_name=>'N8'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'N8'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>210
,p_attribute_01=>'Y'
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(254937380925743712)
,p_name=>'APEX$ROW_ACTION'
,p_session_state_data_type=>'VARCHAR2'
,p_item_type=>'NATIVE_ROW_ACTION'
,p_display_sequence=>20
,p_use_as_row_header=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(254937446920743713)
,p_name=>'APEX$ROW_SELECTOR'
,p_session_state_data_type=>'VARCHAR2'
,p_item_type=>'NATIVE_ROW_SELECTOR'
,p_display_sequence=>10
,p_attribute_01=>'Y'
,p_attribute_02=>'Y'
,p_attribute_03=>'N'
,p_use_as_row_header=>false
);
wwv_flow_imp_page.create_interactive_grid(
 p_id=>wwv_flow_imp.id(254258047650609438)
,p_internal_uid=>254258047650609438
,p_is_editable=>true
,p_edit_operations=>'u:d'
,p_lost_update_check_type=>'VALUES'
,p_submit_checked_rows=>false
,p_lazy_loading=>false
,p_requires_filter=>false
,p_select_first_row=>true
,p_fixed_row_height=>true
,p_pagination_type=>'SCROLL'
,p_show_total_row_count=>true
,p_show_toolbar=>true
,p_toolbar_buttons=>'SEARCH_COLUMN:SEARCH_FIELD:ACTIONS_MENU'
,p_enable_save_public_report=>false
,p_enable_subscriptions=>true
,p_enable_flashback=>true
,p_define_chart_view=>true
,p_enable_download=>true
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>true
,p_fixed_header=>'PAGE'
,p_show_icon_view=>false
,p_show_detail_view=>false
);
wwv_flow_imp_page.create_ig_report(
 p_id=>wwv_flow_imp.id(254942017470762405)
,p_interactive_grid_id=>wwv_flow_imp.id(254258047650609438)
,p_static_id=>'2549421'
,p_type=>'PRIMARY'
,p_default_view=>'GRID'
,p_show_row_number=>false
,p_settings_area_expanded=>true
);
wwv_flow_imp_page.create_ig_report_view(
 p_id=>wwv_flow_imp.id(254942282192762406)
,p_report_id=>wwv_flow_imp.id(254942017470762405)
,p_view_type=>'GRID'
,p_stretch_columns=>true
,p_srv_exclude_null_values=>false
,p_srv_only_display_columns=>true
,p_edit_mode=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(254942774998762409)
,p_view_id=>wwv_flow_imp.id(254942282192762406)
,p_display_seq=>2
,p_column_id=>wwv_flow_imp.id(254258182617609439)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(254943617971762413)
,p_view_id=>wwv_flow_imp.id(254942282192762406)
,p_display_seq=>3
,p_column_id=>wwv_flow_imp.id(254258262115609440)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(254944543512762415)
,p_view_id=>wwv_flow_imp.id(254942282192762406)
,p_display_seq=>5
,p_column_id=>wwv_flow_imp.id(254258349175609441)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(254945437972762417)
,p_view_id=>wwv_flow_imp.id(254942282192762406)
,p_display_seq=>7
,p_column_id=>wwv_flow_imp.id(254258429908609442)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(254946394633762419)
,p_view_id=>wwv_flow_imp.id(254942282192762406)
,p_display_seq=>8
,p_column_id=>wwv_flow_imp.id(254258535897609443)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(254947283114762421)
,p_view_id=>wwv_flow_imp.id(254942282192762406)
,p_display_seq=>9
,p_column_id=>wwv_flow_imp.id(254258632129609444)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(254948164485762423)
,p_view_id=>wwv_flow_imp.id(254942282192762406)
,p_display_seq=>10
,p_column_id=>wwv_flow_imp.id(254258758220609445)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(254949037684762424)
,p_view_id=>wwv_flow_imp.id(254942282192762406)
,p_display_seq=>4
,p_column_id=>wwv_flow_imp.id(254258846520609446)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>180.64100000000002
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(254949910332762426)
,p_view_id=>wwv_flow_imp.id(254942282192762406)
,p_display_seq=>6
,p_column_id=>wwv_flow_imp.id(254258980896609447)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>385.641
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(254950807650762428)
,p_view_id=>wwv_flow_imp.id(254942282192762406)
,p_display_seq=>11
,p_column_id=>wwv_flow_imp.id(254259014586609448)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(254951760664762430)
,p_view_id=>wwv_flow_imp.id(254942282192762406)
,p_display_seq=>12
,p_column_id=>wwv_flow_imp.id(254259193250609449)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(254952675978762431)
,p_view_id=>wwv_flow_imp.id(254942282192762406)
,p_display_seq=>13
,p_column_id=>wwv_flow_imp.id(254259292468609450)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(254953574721762433)
,p_view_id=>wwv_flow_imp.id(254942282192762406)
,p_display_seq=>14
,p_column_id=>wwv_flow_imp.id(254936223421743701)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(254954473240762435)
,p_view_id=>wwv_flow_imp.id(254942282192762406)
,p_display_seq=>15
,p_column_id=>wwv_flow_imp.id(254936370179743702)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(254955382427762436)
,p_view_id=>wwv_flow_imp.id(254942282192762406)
,p_display_seq=>16
,p_column_id=>wwv_flow_imp.id(254936463104743703)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(254956214318762438)
,p_view_id=>wwv_flow_imp.id(254942282192762406)
,p_display_seq=>17
,p_column_id=>wwv_flow_imp.id(254936505509743704)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(254957117382762440)
,p_view_id=>wwv_flow_imp.id(254942282192762406)
,p_display_seq=>18
,p_column_id=>wwv_flow_imp.id(254936604627743705)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(254958003345762442)
,p_view_id=>wwv_flow_imp.id(254942282192762406)
,p_display_seq=>19
,p_column_id=>wwv_flow_imp.id(254936790209743706)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(254958970276762443)
,p_view_id=>wwv_flow_imp.id(254942282192762406)
,p_display_seq=>20
,p_column_id=>wwv_flow_imp.id(254936821784743707)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(254972431465859183)
,p_view_id=>wwv_flow_imp.id(254942282192762406)
,p_display_seq=>0
,p_column_id=>wwv_flow_imp.id(254937380925743712)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(261584148254843625)
,p_plug_name=>'Reduccion Tarifa Impuesto'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(38289867500120143)
,p_plug_display_sequence=>150
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_plug_display_when_condition=>'P145_TIPOCARGA'
,p_plug_display_when_cond2=>'RTIR'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(261584284843843626)
,p_name=>'Calculos reduccion'
,p_parent_plug_id=>wwv_flow_imp.id(261584148254843625)
,p_template=>wwv_flow_imp.id(37806762584106520)
,p_display_sequence=>100
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_display_point=>'SUB_REGIONS'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'TABLE'
,p_query_table=>'T_FINZ_CARGASMANUALES'
,p_query_where=>wwv_flow_string.join(wwv_flow_t_varchar2(
'TIPO=:P145_TIPOCARGA AND ANIO<=:P145_ANIO AND MES=:P145_MES ',
'AND ESTADO=1 AND VC2=''SI'''))
,p_query_order_by_type=>'STATIC'
,p_query_order_by=>'n8'
,p_include_rowid_column=>false
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(37830327650106535)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(269630434488797426)
,p_query_column_id=>1
,p_column_alias=>'ID'
,p_column_display_sequence=>10
,p_use_as_row_header=>'N'
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(269630538076797427)
,p_query_column_id=>2
,p_column_alias=>'TIPO'
,p_column_display_sequence=>20
,p_use_as_row_header=>'N'
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(269630603168797428)
,p_query_column_id=>3
,p_column_alias=>'ANIO'
,p_column_display_sequence=>30
,p_use_as_row_header=>'N'
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(269630742604797429)
,p_query_column_id=>4
,p_column_alias=>'MES'
,p_column_display_sequence=>40
,p_use_as_row_header=>'N'
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(269630844863797430)
,p_query_column_id=>5
,p_column_alias=>'N1'
,p_column_display_sequence=>50
,p_column_heading=>'Valor'
,p_use_as_row_header=>'N'
,p_column_format=>'999G999G999G999G990D00'
,p_column_alignment=>'RIGHT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(269630950384797431)
,p_query_column_id=>6
,p_column_alias=>'N2'
,p_column_display_sequence=>60
,p_use_as_row_header=>'N'
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(269631019432797432)
,p_query_column_id=>7
,p_column_alias=>'N3'
,p_column_display_sequence=>70
,p_use_as_row_header=>'N'
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(269631154982797433)
,p_query_column_id=>8
,p_column_alias=>'VC1'
,p_column_display_sequence=>45
,p_column_heading=>unistr('Descripci\00F3n')
,p_use_as_row_header=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(269631223675797434)
,p_query_column_id=>9
,p_column_alias=>'VC2'
,p_column_display_sequence=>90
,p_use_as_row_header=>'N'
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(269631367204797435)
,p_query_column_id=>10
,p_column_alias=>'VC3'
,p_column_display_sequence=>100
,p_use_as_row_header=>'N'
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(269631466718797436)
,p_query_column_id=>11
,p_column_alias=>'DT1'
,p_column_display_sequence=>110
,p_use_as_row_header=>'N'
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(269631512656797437)
,p_query_column_id=>12
,p_column_alias=>'DT2'
,p_column_display_sequence=>120
,p_use_as_row_header=>'N'
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(269631616508797438)
,p_query_column_id=>13
,p_column_alias=>'DT3'
,p_column_display_sequence=>130
,p_use_as_row_header=>'N'
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(269631786579797439)
,p_query_column_id=>14
,p_column_alias=>'ESTADO'
,p_column_display_sequence=>140
,p_use_as_row_header=>'N'
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(269631819832797440)
,p_query_column_id=>15
,p_column_alias=>'N4'
,p_column_display_sequence=>150
,p_use_as_row_header=>'N'
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(269631928990797441)
,p_query_column_id=>16
,p_column_alias=>'N5'
,p_column_display_sequence=>160
,p_use_as_row_header=>'N'
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(269632007983797442)
,p_query_column_id=>17
,p_column_alias=>'N6'
,p_column_display_sequence=>170
,p_use_as_row_header=>'N'
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(269632164745797443)
,p_query_column_id=>18
,p_column_alias=>'N7'
,p_column_display_sequence=>180
,p_use_as_row_header=>'N'
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(269632237432797444)
,p_query_column_id=>19
,p_column_alias=>'N8'
,p_column_display_sequence=>190
,p_use_as_row_header=>'N'
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(269632347627797445)
,p_query_column_id=>20
,p_column_alias=>'COMPANIA'
,p_column_display_sequence=>200
,p_use_as_row_header=>'N'
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(263189808606745803)
,p_plug_name=>unistr('Reducci\00F3n2')
,p_parent_plug_id=>wwv_flow_imp.id(261584148254843625)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(37806762584106520)
,p_plug_display_sequence=>20
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'TABLE'
,p_query_table=>'T_FINZ_CARGASMANUALES'
,p_query_where=>wwv_flow_string.join(wwv_flow_t_varchar2(
'TIPO=:P145_TIPOCARGA AND ANIO<=:P145_ANIO AND MES=:P145_MES ',
'AND ESTADO=1 AND VC2 IS NULL'))
,p_include_rowid_column=>false
,p_plug_source_type=>'NATIVE_IG'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>unistr('Reducci\00F3n2')
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(263192165814745826)
,p_name=>'ID'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'ID'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>30
,p_attribute_01=>'Y'
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_is_primary_key=>true
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(263192234630745827)
,p_name=>'TIPO'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'TIPO'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>40
,p_attribute_01=>'Y'
,p_filter_is_required=>false
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_is_primary_key=>false
,p_default_type=>'ITEM'
,p_default_expression=>'P145_TIPOCARGA'
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(263192384326745828)
,p_name=>'ANIO'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'ANIO'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>50
,p_attribute_01=>'Y'
,p_filter_is_required=>false
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_is_primary_key=>false
,p_default_type=>'ITEM'
,p_default_expression=>'P145_ANIO'
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(263192427282745829)
,p_name=>'MES'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'MES'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>60
,p_attribute_01=>'Y'
,p_filter_is_required=>false
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_is_primary_key=>false
,p_default_type=>'ITEM'
,p_default_expression=>'P145_MES'
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(263192574592745830)
,p_name=>'N1'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'N1'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_NUMBER_FIELD'
,p_heading=>unistr('C\00F3digo<br> Inversi\00F3n')
,p_heading_alignment=>'CENTER'
,p_display_sequence=>70
,p_value_alignment=>'CENTER'
,p_attribute_03=>'left'
,p_attribute_04=>'decimal'
,p_is_required=>false
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(263192629419745831)
,p_name=>'N2'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'N2'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_NUMBER_FIELD'
,p_heading=>'2018'
,p_heading_alignment=>'CENTER'
,p_display_sequence=>80
,p_value_alignment=>'RIGHT'
,p_attribute_03=>'left'
,p_attribute_04=>'decimal'
,p_format_mask=>'999G999G999G999G990D00'
,p_is_required=>false
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(263192790567745832)
,p_name=>'N3'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'N3'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_NUMBER_FIELD'
,p_heading=>'2019'
,p_heading_alignment=>'CENTER'
,p_display_sequence=>90
,p_value_alignment=>'RIGHT'
,p_attribute_03=>'left'
,p_attribute_04=>'decimal'
,p_format_mask=>'999G999G999G999G990D00'
,p_is_required=>false
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(263192800731745833)
,p_name=>'VC1'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'VC1'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXTAREA'
,p_heading=>unistr('Descripci\00F3n')
,p_heading_alignment=>'CENTER'
,p_display_sequence=>100
,p_value_alignment=>'LEFT'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
,p_is_required=>false
,p_max_length=>150
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(263192942798745834)
,p_name=>'VC2'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'VC2'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>110
,p_attribute_01=>'Y'
,p_filter_is_required=>false
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(263193082081745835)
,p_name=>'VC3'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'VC3'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_SELECT_LIST'
,p_heading=>'Estado'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>120
,p_value_alignment=>'LEFT'
,p_is_required=>false
,p_lov_type=>'SHARED'
,p_lov_id=>wwv_flow_imp.id(483951960873190821)
,p_lov_display_extra=>true
,p_lov_display_null=>true
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'LOV'
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(263193167065745836)
,p_name=>'DT1'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'DT1'
,p_data_type=>'DATE'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_DATE_PICKER_APEX'
,p_heading=>'Fecha'
,p_heading_alignment=>'CENTER'
,p_display_sequence=>130
,p_value_alignment=>'CENTER'
,p_attribute_01=>'N'
,p_attribute_02=>'POPUP'
,p_attribute_03=>'NONE'
,p_attribute_06=>'NONE'
,p_attribute_09=>'N'
,p_attribute_11=>'Y'
,p_is_required=>false
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_date_ranges=>'ALL'
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(263193296894745837)
,p_name=>'DT2'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'DT2'
,p_data_type=>'DATE'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>140
,p_attribute_01=>'Y'
,p_filter_is_required=>false
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(263193364821745838)
,p_name=>'DT3'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'DT3'
,p_data_type=>'DATE'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>150
,p_attribute_01=>'Y'
,p_filter_is_required=>false
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(263193410155745839)
,p_name=>'ESTADO'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'ESTADO'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>160
,p_attribute_01=>'Y'
,p_filter_is_required=>false
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_is_primary_key=>false
,p_default_type=>'STATIC'
,p_default_expression=>'1'
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(263193539027745840)
,p_name=>'N4'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'N4'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_NUMBER_FIELD'
,p_heading=>'2020'
,p_heading_alignment=>'CENTER'
,p_display_sequence=>170
,p_value_alignment=>'RIGHT'
,p_attribute_03=>'left'
,p_attribute_04=>'decimal'
,p_format_mask=>'999G999G999G999G990D00'
,p_is_required=>false
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(263193641901745841)
,p_name=>'N5'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'N5'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_NUMBER_FIELD'
,p_heading=>'2021'
,p_heading_alignment=>'CENTER'
,p_display_sequence=>180
,p_value_alignment=>'RIGHT'
,p_attribute_03=>'left'
,p_attribute_04=>'decimal'
,p_format_mask=>'999G999G999G999G990D00'
,p_is_required=>false
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(263193741482745842)
,p_name=>'N6'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'N6'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_NUMBER_FIELD'
,p_heading=>'2022'
,p_heading_alignment=>'CENTER'
,p_display_sequence=>190
,p_value_alignment=>'RIGHT'
,p_attribute_03=>'left'
,p_attribute_04=>'decimal'
,p_format_mask=>'999G999G999G999G990D00'
,p_is_required=>false
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(263193804342745843)
,p_name=>'N7'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'N7'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_NUMBER_FIELD'
,p_heading=>'2023'
,p_heading_alignment=>'CENTER'
,p_display_sequence=>200
,p_value_alignment=>'RIGHT'
,p_attribute_03=>'left'
,p_attribute_04=>'decimal'
,p_format_mask=>'999G999G999G999G990D00'
,p_is_required=>false
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(263193979311745844)
,p_name=>'N8'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'N8'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_NUMBER_FIELD'
,p_heading=>'2024'
,p_heading_alignment=>'CENTER'
,p_display_sequence=>210
,p_value_alignment=>'RIGHT'
,p_attribute_03=>'left'
,p_attribute_04=>'decimal'
,p_format_mask=>'999G999G999G999G990D00'
,p_is_required=>false
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(263194077256745845)
,p_name=>'COMPANIA'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'COMPANIA'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>220
,p_attribute_01=>'Y'
,p_filter_is_required=>false
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_is_primary_key=>false
,p_default_type=>'ITEM'
,p_default_expression=>'G_COMPANIA'
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(263194154684745846)
,p_name=>'APEX$ROW_ACTION'
,p_session_state_data_type=>'VARCHAR2'
,p_item_type=>'NATIVE_ROW_ACTION'
,p_display_sequence=>20
,p_use_as_row_header=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(263194249018745847)
,p_name=>'APEX$ROW_SELECTOR'
,p_session_state_data_type=>'VARCHAR2'
,p_item_type=>'NATIVE_ROW_SELECTOR'
,p_display_sequence=>10
,p_attribute_01=>'Y'
,p_attribute_02=>'Y'
,p_attribute_03=>'N'
,p_use_as_row_header=>false
);
wwv_flow_imp_page.create_interactive_grid(
 p_id=>wwv_flow_imp.id(263192035364745825)
,p_internal_uid=>263192035364745825
,p_is_editable=>true
,p_edit_operations=>'i:u:d'
,p_lost_update_check_type=>'VALUES'
,p_add_row_if_empty=>true
,p_submit_checked_rows=>false
,p_lazy_loading=>false
,p_requires_filter=>false
,p_select_first_row=>true
,p_fixed_row_height=>true
,p_pagination_type=>'SCROLL'
,p_show_total_row_count=>true
,p_show_toolbar=>true
,p_toolbar_buttons=>'SEARCH_COLUMN:SEARCH_FIELD:ACTIONS_MENU'
,p_enable_save_public_report=>false
,p_enable_subscriptions=>true
,p_enable_flashback=>true
,p_define_chart_view=>true
,p_enable_download=>true
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>true
,p_fixed_header=>'PAGE'
,p_show_icon_view=>false
,p_show_detail_view=>false
);
wwv_flow_imp_page.create_ig_report(
 p_id=>wwv_flow_imp.id(269010723967111947)
,p_interactive_grid_id=>wwv_flow_imp.id(263192035364745825)
,p_static_id=>'2690108'
,p_type=>'PRIMARY'
,p_default_view=>'GRID'
,p_show_row_number=>false
,p_settings_area_expanded=>false
);
wwv_flow_imp_page.create_ig_report_view(
 p_id=>wwv_flow_imp.id(269010901434111953)
,p_report_id=>wwv_flow_imp.id(269010723967111947)
,p_view_type=>'GRID'
,p_stretch_columns=>true
,p_srv_exclude_null_values=>false
,p_srv_only_display_columns=>true
,p_edit_mode=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(269011474537111979)
,p_view_id=>wwv_flow_imp.id(269010901434111953)
,p_display_seq=>2
,p_column_id=>wwv_flow_imp.id(263192165814745826)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(269012335746112002)
,p_view_id=>wwv_flow_imp.id(269010901434111953)
,p_display_seq=>3
,p_column_id=>wwv_flow_imp.id(263192234630745827)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(269013237520112007)
,p_view_id=>wwv_flow_imp.id(269010901434111953)
,p_display_seq=>4
,p_column_id=>wwv_flow_imp.id(263192384326745828)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(269014128201112025)
,p_view_id=>wwv_flow_imp.id(269010901434111953)
,p_display_seq=>5
,p_column_id=>wwv_flow_imp.id(263192427282745829)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(269014974966112038)
,p_view_id=>wwv_flow_imp.id(269010901434111953)
,p_display_seq=>6
,p_column_id=>wwv_flow_imp.id(263192574592745830)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>80
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(269015839331112042)
,p_view_id=>wwv_flow_imp.id(269010901434111953)
,p_display_seq=>10
,p_column_id=>wwv_flow_imp.id(263192629419745831)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>103
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(269016750799112045)
,p_view_id=>wwv_flow_imp.id(269010901434111953)
,p_display_seq=>12
,p_column_id=>wwv_flow_imp.id(263192790567745832)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>103
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(269017642213112048)
,p_view_id=>wwv_flow_imp.id(269010901434111953)
,p_display_seq=>7
,p_column_id=>wwv_flow_imp.id(263192800731745833)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>245
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(269018549548112063)
,p_view_id=>wwv_flow_imp.id(269010901434111953)
,p_display_seq=>11
,p_column_id=>wwv_flow_imp.id(263192942798745834)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(269019406844112073)
,p_view_id=>wwv_flow_imp.id(269010901434111953)
,p_display_seq=>8
,p_column_id=>wwv_flow_imp.id(263193082081745835)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>162
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(269020375116112092)
,p_view_id=>wwv_flow_imp.id(269010901434111953)
,p_display_seq=>9
,p_column_id=>wwv_flow_imp.id(263193167065745836)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>95
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(269021232575112095)
,p_view_id=>wwv_flow_imp.id(269010901434111953)
,p_display_seq=>13
,p_column_id=>wwv_flow_imp.id(263193296894745837)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(269022129185112099)
,p_view_id=>wwv_flow_imp.id(269010901434111953)
,p_display_seq=>14
,p_column_id=>wwv_flow_imp.id(263193364821745838)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(269023060011112112)
,p_view_id=>wwv_flow_imp.id(269010901434111953)
,p_display_seq=>15
,p_column_id=>wwv_flow_imp.id(263193410155745839)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(269023934508112118)
,p_view_id=>wwv_flow_imp.id(269010901434111953)
,p_display_seq=>16
,p_column_id=>wwv_flow_imp.id(263193539027745840)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>103
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(269024760160112134)
,p_view_id=>wwv_flow_imp.id(269010901434111953)
,p_display_seq=>17
,p_column_id=>wwv_flow_imp.id(263193641901745841)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>103
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(269025608644112138)
,p_view_id=>wwv_flow_imp.id(269010901434111953)
,p_display_seq=>18
,p_column_id=>wwv_flow_imp.id(263193741482745842)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>103
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(269026534418112142)
,p_view_id=>wwv_flow_imp.id(269010901434111953)
,p_display_seq=>19
,p_column_id=>wwv_flow_imp.id(263193804342745843)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>103
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(269027444587112145)
,p_view_id=>wwv_flow_imp.id(269010901434111953)
,p_display_seq=>20
,p_column_id=>wwv_flow_imp.id(263193979311745844)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>103
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(269028398408112148)
,p_view_id=>wwv_flow_imp.id(269010901434111953)
,p_display_seq=>21
,p_column_id=>wwv_flow_imp.id(263194077256745845)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(269036207316113643)
,p_view_id=>wwv_flow_imp.id(269010901434111953)
,p_display_seq=>1
,p_column_id=>wwv_flow_imp.id(263194154684745846)
,p_is_visible=>true
,p_is_frozen=>true
);
wwv_flow_imp_page.create_ig_report_aggregate(
 p_id=>wwv_flow_imp.id(90968000016)
,p_view_id=>wwv_flow_imp.id(269010901434111953)
,p_function=>'SUM'
,p_column_id=>wwv_flow_imp.id(263192629419745831)
,p_show_grand_total=>false
,p_is_enabled=>true
);
wwv_flow_imp_page.create_ig_report_aggregate(
 p_id=>wwv_flow_imp.id(423980008615)
,p_view_id=>wwv_flow_imp.id(269010901434111953)
,p_function=>'SUM'
,p_column_id=>wwv_flow_imp.id(263192790567745832)
,p_show_grand_total=>true
,p_is_enabled=>true
);
wwv_flow_imp_page.create_ig_report_aggregate(
 p_id=>wwv_flow_imp.id(447920010553)
,p_view_id=>wwv_flow_imp.id(269010901434111953)
,p_function=>'SUM'
,p_column_id=>wwv_flow_imp.id(263193539027745840)
,p_show_grand_total=>true
,p_is_enabled=>true
);
wwv_flow_imp_page.create_ig_report_aggregate(
 p_id=>wwv_flow_imp.id(612463012757)
,p_view_id=>wwv_flow_imp.id(269010901434111953)
,p_function=>'SUM'
,p_column_id=>wwv_flow_imp.id(263193641901745841)
,p_show_grand_total=>true
,p_is_enabled=>true
);
wwv_flow_imp_page.create_ig_report_aggregate(
 p_id=>wwv_flow_imp.id(655760014325)
,p_view_id=>wwv_flow_imp.id(269010901434111953)
,p_function=>'SUM'
,p_column_id=>wwv_flow_imp.id(263193741482745842)
,p_show_grand_total=>true
,p_is_enabled=>true
);
wwv_flow_imp_page.create_ig_report_aggregate(
 p_id=>wwv_flow_imp.id(788262016019)
,p_view_id=>wwv_flow_imp.id(269010901434111953)
,p_function=>'SUM'
,p_column_id=>wwv_flow_imp.id(263193804342745843)
,p_show_grand_total=>true
,p_is_enabled=>true
);
wwv_flow_imp_page.create_ig_report_aggregate(
 p_id=>wwv_flow_imp.id(859675017176)
,p_view_id=>wwv_flow_imp.id(269010901434111953)
,p_function=>'SUM'
,p_column_id=>wwv_flow_imp.id(263193979311745844)
,p_show_grand_total=>true
,p_is_enabled=>true
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(211879099519446235)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(211876613063446211)
,p_button_name=>'CARGA'
,p_button_action=>'REDIRECT_APP'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860056812106557)
,p_button_image_alt=>'Carga desde EXCEL'
,p_button_redirect_url=>'f?p=100:300:&SESSION.::&DEBUG.:300::'
,p_button_condition=>':P145_MES is not null AND :P145_TIPOCARGA IN (''LI'',''MAAA'',''RTIR'')'
,p_button_condition2=>'PLSQL'
,p_button_condition_type=>'EXPRESSION'
,p_icon_css_classes=>'fa-file-excel-o'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(269632415650797446)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(261584284843843626)
,p_button_name=>'VERACTIVOS'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860056812106557)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Ver Activos Fijos'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:164:&SESSION.::&DEBUG.::P164_ANIO,P164_MES:&P145_ANIO.,&P145_MES.'
,p_icon_css_classes=>'fa-truck'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(452277332507507336)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(211876948854446214)
,p_button_name=>'Aprobar'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860056812106557)
,p_button_image_alt=>'Enviar asientos'
,p_warn_on_unsaved_changes=>null
,p_button_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT 1',
'FROM t_finz_cargasmanuales',
'            where tipo = ''MA''',
'				and anio = :P145_ANIO',
'				and mes = :P145_MES',
'				and estado = 1;'))
,p_button_condition_type=>'EXISTS'
,p_icon_css_classes=>'fa-check-circle-o'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(211879472990446239)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(211876613063446211)
,p_button_name=>'DescargarLI'
,p_button_action=>'REDIRECT_URL'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860056812106557)
,p_button_image_alt=>'Descargar Formato Excel'
,p_button_redirect_url=>'#APP_FILES#FINZ/formato costos gastos regalias.xlsx'
,p_button_condition=>'P145_TIPOCARGA'
,p_button_condition2=>'LI'
,p_button_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_icon_css_classes=>'fa-file-arrow-down'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(211879645020446241)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(211876613063446211)
,p_button_name=>'DescargarMA'
,p_button_action=>'REDIRECT_URL'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860056812106557)
,p_button_image_alt=>'Descargar Formato Excel'
,p_button_redirect_url=>'#APP_FILES#FINZ/formato marcas.xlsx'
,p_button_condition=>'P145_TIPOCARGA'
,p_button_condition2=>'MAAA'
,p_button_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_icon_css_classes=>'fa-file-arrow-down'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(269629815485797420)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(211876613063446211)
,p_button_name=>'DescargarRTIR'
,p_button_action=>'REDIRECT_URL'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860056812106557)
,p_button_image_alt=>'Descargar Formato Excel'
,p_button_redirect_url=>'#APP_FILES#FINZ/formato reduccion tarifa.xlsx'
,p_button_condition=>'P145_TIPOCARGA'
,p_button_condition2=>'RTIR'
,p_button_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_icon_css_classes=>'fa-file-arrow-down'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(218460475000766607)
,p_button_sequence=>50
,p_button_plug_id=>wwv_flow_imp.id(211876613063446211)
,p_button_name=>'Buscar'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860056812106557)
,p_button_image_alt=>'Buscar'
,p_button_alignment=>'RIGHT'
,p_icon_css_classes=>'fa-search'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(225042197372262426)
,p_button_sequence=>60
,p_button_plug_id=>wwv_flow_imp.id(211876613063446211)
,p_button_name=>'Grabar_INE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860056812106557)
,p_button_image_alt=>'Grabar INE'
,p_button_alignment=>'RIGHT'
,p_button_condition=>'P145_TIPOCARGA'
,p_button_condition2=>'INE'
,p_button_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_icon_css_classes=>'fa-save'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(231046440586818811)
,p_button_sequence=>70
,p_button_plug_id=>wwv_flow_imp.id(211876613063446211)
,p_button_name=>'Grabar_ECD'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860056812106557)
,p_button_image_alt=>'Grabar ECD'
,p_button_alignment=>'RIGHT'
,p_button_condition=>'P145_TIPOCARGA'
,p_button_condition2=>'ECD'
,p_button_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_icon_css_classes=>'fa-save'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(231926847260750420)
,p_button_sequence=>80
,p_button_plug_id=>wwv_flow_imp.id(211876613063446211)
,p_button_name=>'Grabar_AMM'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860056812106557)
,p_button_image_alt=>'Grabar AMM'
,p_button_alignment=>'RIGHT'
,p_button_condition=>'P145_TIPOCARGA'
,p_button_condition2=>'AMM'
,p_button_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_icon_css_classes=>'fa-save'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(254257498793609432)
,p_button_sequence=>90
,p_button_plug_id=>wwv_flow_imp.id(211876613063446211)
,p_button_name=>'Grabar_DJP'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860056812106557)
,p_button_image_alt=>'Grabar DJP'
,p_button_alignment=>'RIGHT'
,p_button_condition=>'P145_TIPOCARGA'
,p_button_condition2=>'DJP'
,p_button_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_icon_css_classes=>'fa-save'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(254257522872609433)
,p_button_sequence=>100
,p_button_plug_id=>wwv_flow_imp.id(211876613063446211)
,p_button_name=>'Grabar_DFT'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860056812106557)
,p_button_image_alt=>'Grabar DFT'
,p_button_alignment=>'RIGHT'
,p_button_condition=>'P145_TIPOCARGA'
,p_button_condition2=>'DFT'
,p_button_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_icon_css_classes=>'fa-save'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(263189663253745801)
,p_button_sequence=>110
,p_button_plug_id=>wwv_flow_imp.id(211876613063446211)
,p_button_name=>'GrabaRTIR'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860056812106557)
,p_button_image_alt=>'Graba RTIR'
,p_button_alignment=>'RIGHT'
,p_button_condition=>'P145_TIPOCARGA'
,p_button_condition2=>'RTIR'
,p_button_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_icon_css_classes=>'fa-save'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(254257617715609434)
,p_button_sequence=>120
,p_button_plug_id=>wwv_flow_imp.id(211876613063446211)
,p_button_name=>'Retornar'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860056812106557)
,p_button_image_alt=>'Retornar'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:150:&SESSION.::&DEBUG.:::'
,p_icon_css_classes=>'fa-box-arrow-out-nw'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(469054611374883606)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(218464720655766650)
,p_button_name=>'Detalle'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860056812106557)
,p_button_image_alt=>'Detalle Gastos Patrocinio'
,p_button_position=>'PREVIOUS'
,p_button_redirect_url=>'f?p=&APP_ID.:147:&SESSION.::&DEBUG.::P147_ANIO,P147_MES:&P145_ANIO.,&P145_MES.'
,p_icon_css_classes=>'fa-clipboard-list'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(211876794301446212)
,p_name=>'P145_TIPOCARGA'
,p_item_sequence=>30
,p_prompt=>'Opciones:'
,p_display_as=>'NATIVE_RADIOGROUP'
,p_lov=>unistr('STATIC(,):Costos y Gastos de Regal\00EDasLIMarcasMABeneficio Econom\00EDa Popular y SolidariaBEPDeducci\00F3n Depreciaci\00F3nDDGastos Publicidad, Promocion y PatrocinioGPIncremento Neto EmpleosINEEmpleados con Discapacidad o SustitutosECDAdultos May')
||unistr('ores o Migrantes RetornadosAMMProvisi\00F3n Desahucio /Jub. PatronalDJPReducci\00F3n Tarifa Impuesto a la RentaRTIR')
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'5'
,p_attribute_02=>'SUBMIT'
,p_attribute_03=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(218460264900766605)
,p_name=>'P145_ANIO'
,p_item_sequence=>10
,p_prompt=>unistr('A\00F1o: ')
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'LOV_ANIOS2'
,p_lov=>'select to_char(sysdate,''yyyy'') + (level-2) d,to_char(sysdate,''yyyy'') + (level-2) r from dual connect by level <= 4'
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(218460392543766606)
,p_name=>'P145_MES'
,p_item_sequence=>20
,p_prompt=>'Mes: '
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'LOV_MESES'
,p_lov=>'select to_char(to_date(level,''MM''),''Month'') d, level r from dual connect by level <= 12'
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'SUBMIT'
,p_attribute_03=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(218461156289766614)
,p_name=>'P145_RUC'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(218461038149766613)
,p_prompt=>'RUC: '
,p_display_as=>'NATIVE_POPUP_LOV'
,p_named_lov=>'LOV_RUC_PROVEEDORES'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select TRIM(DESCRIPCION) || '' - '' || IDENTIFICACION AS D,',
'       IDENTIFICACION AS R',
'  from VT_JDE_MAESTROPROVEEDOR',
' order by 1'))
,p_lov_display_null=>'YES'
,p_cSize=>30
,p_colspan=>7
,p_display_when=>'1=2'
,p_display_when2=>'PLSQL'
,p_display_when_type=>'EXPRESSION'
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'POPUP'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_04=>'N'
,p_attribute_05=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(222832964874009921)
,p_name=>'P145_PORCENTAJE'
,p_is_required=>true
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(222830976201009901)
,p_prompt=>unistr('Deducci\00F3n: ')
,p_post_element_text=>'%'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT VALOR D, VALOR R',
'FROM T_CORP_UDC',
'WHERE ID_CABECERA=''FINZ_GGEST'' AND ID_TABLA=''POR'' AND DESCRIPCION2=''PUBLIPATRO'' AND ACTIVO=1;'))
,p_cHeight=>1
,p_colspan=>4
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(222833095835009922)
,p_name=>'P145_TOTAL'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(222830976201009901)
,p_prompt=>'Total: '
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(225041978923262424)
,p_name=>'P145_BANDERAINE'
,p_item_sequence=>100
,p_prompt=>'New'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_display_when=>'1=2'
,p_display_when2=>'PLSQL'
,p_display_when_type=>'EXPRESSION'
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_03=>'left'
,p_attribute_04=>'decimal'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(231049387185818840)
,p_name=>'P145_DEDUCCION'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(225043166199262436)
,p_prompt=>unistr('Valor de la deducci\00F3n por empleados contratados con discapacidad o sus sustitutos declarada en el formulario de impuesto a la renta: ')
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_colspan=>9
,p_grid_label_column_span=>8
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_03=>'left'
,p_attribute_04=>'decimal'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(231926986407750421)
,p_name=>'P145_DEDUCCIONAMM'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(231049754922818844)
,p_prompt=>unistr('Valor de la deducci\00F3n por empleados adultos mayores y migrantes retornados mayores a 40 a\00F1os declarada en el impuesto a la renta')
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_colspan=>9
,p_grid_label_column_span=>8
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_03=>'left'
,p_attribute_04=>'decimal'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(258005442877352048)
,p_name=>'P145_BANDERADJP'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(254257869559609436)
,p_prompt=>'Banderadjp'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_display_when=>'1=2'
,p_display_when2=>'PLSQL'
,p_display_when_type=>'EXPRESSION'
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_03=>'left'
,p_attribute_04=>'decimal'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(469054451479883604)
,p_name=>'P145_BANDERAGP'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(261584148254843625)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(211879150686446236)
,p_name=>'Cierre dialogo subir limites'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(211879099519446235)
,p_condition_element=>'P145_TIPOCARGA'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'LI'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(211879272134446237)
,p_event_id=>wwv_flow_imp.id(211879150686446236)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
unistr('-- verifico que a\00F1o y mes tenagan un valor , no pueden ser nulos'),
'IF :P145_ANIO IS NULL OR :P145_MES IS NULL THEN',
unistr('   raise_application_error (-20001,''A\00F1o y Mes deben tener un valor.'');'),
'END IF;',
'',
'-- borro datos anteriores',
'DELETE FROM T_FINZ_CARGASMANUALES',
'WHERE TIPO=:P145_TIPOCARGA AND ANIO=:P145_ANIO AND MES=:P145_MES AND COMPANIA=:G_COMPANIA AND ESTADO=1;',
'',
unistr('-- inserto los datos para los l\00EDmites'),
'INSERT INTO T_FINZ_CARGASMANUALES (TIPO,ANIO,MES,N1,VC1,VC2,N8,ESTADO,COMPANIA)',
'SELECT :P145_TIPOCARGA,C02,C03,C04,C05,C06,replace(C07,''.'','',''),1,:G_COMPANIA',
'FROM vt_apex_excel;'))
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(211879353661446238)
,p_event_id=>wwv_flow_imp.id(211879150686446236)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_02=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(211879716618446242)
,p_name=>'Cierre dialogo subir marcas'
,p_event_sequence=>20
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(211879099519446235)
,p_condition_element=>'P145_TIPOCARGA'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'MA'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(211879847135446243)
,p_event_id=>wwv_flow_imp.id(211879716618446242)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'   V_PORCREGALIAS NUMBER :=0;',
'   V_TOTALREGALIAS  NUMBER :=0;',
'BEGIN',
unistr('    -- verifico que a\00F1o y mes tengan un valor , no pueden ser nulos'),
'    IF :P145_ANIO IS NULL OR :P145_MES IS NULL THEN',
unistr('       raise_application_error (-20001,''A\00F1o y Mes deben tener un valor.'');'),
'    END IF;',
'',
'    -- borro los registros correspondientes al mes de proceso y que se encuentran en estado =1',
'',
'    DELETE T_FINZ_CARGASMANUALES',
'    WHERE TIPO=:P145_TIPOCARGA AND ANIO=:P145_ANIO AND MES=:P145_MES AND ESTADO=1;',
'',
'    -- inserto los datos para marcas',
'    INSERT INTO T_FINZ_CARGASMANUALES (TIPO,ANIO,MES,VC1,N1,N2,ESTADO,COMPANIA)',
'    SELECT :P145_TIPOCARGA,:P145_ANIO,:P145_MES,C02,replace(C03,''.'','',''),replace(C04,''.'','',''),1,:G_COMPANIA',
'    FROM vt_apex_excel;',
'',
'    -- actualizo los porcentajes para RETENCION en N3 e ISD en N4',
'    UPDATE T_FINZ_CARGASMANUALES',
'      SET (N3,N4)=(SELECT X.VALOR,Y.VALOR',
'                   FROM T_CORP_UDC X, T_CORP_UDC Y',
'                   WHERE X.ID_CABECERA=''FINZ_GGEST'' AND X.ID_TABLA=''POR'' AND X.DESCRIPCION2=''RETENCION'' AND X.ACTIVO=1',
'                   AND Y.ID_CABECERA=''FINZ_GGEST'' AND Y.ID_TABLA=''POR'' AND Y.DESCRIPCION2=''ISD'' AND Y.ACTIVO=1)',
'    WHERE TIPO=:P145_TIPOCARGA AND ANIO=:P145_ANIO AND MES=:P145_MES AND ESTADO=1',
'    AND EXISTS (SELECT X.VALOR,Y.VALOR',
'                   FROM T_CORP_UDC X, T_CORP_UDC Y ',
'                   WHERE X.ID_CABECERA=''FINZ_GGEST'' AND X.ID_TABLA=''POR'' AND X.DESCRIPCION2=''RETENCION'' AND X.ACTIVO=1',
'                   AND Y.ID_CABECERA=''FINZ_GGEST'' AND Y.ID_TABLA=''POR'' AND Y.DESCRIPCION2=''ISD'' AND Y.ACTIVO=1);',
'',
'    -- en N5 acumulo por marca',
'',
'    UPDATE T_FINZ_CARGASMANUALES X',
'      SET (N5)=(SELECT SUM(N1)',
'                FROM T_FINZ_CARGASMANUALES Y',
'                WHERE Y.TIPO=:P145_TIPOCARGA AND Y.ANIO=:P145_ANIO AND Y.MES<=:P145_MES AND Y.VC1=X.VC1',
'         --       AND Y.TIPO=X.TIPO AND Y.ANIO=X.ANIO AND Y.MES=X.MES',
'         )',
'    WHERE TIPO=:P145_TIPOCARGA AND ANIO=:P145_ANIO AND MES=:P145_MES AND ESTADO=1',
'    AND EXISTS (SELECT ''X''',
'                FROM T_FINZ_CARGASMANUALES Y',
'                WHERE Y.TIPO=:P145_TIPOCARGA AND Y.ANIO=:P145_ANIO AND Y.MES<=:P145_MES AND Y.VC1=X.VC1',
'         --       AND Y.TIPO=X.TIPO AND Y.ANIO=X.ANIO AND Y.MES=X.MES',
'         );',
'',
unistr('    -- en N6 calculo las regal\00EDas sin descuento'),
'    UPDATE T_FINZ_CARGASMANUALES X',
'      SET N6 = (SELECT N5*(N2/100)',
'                FROM T_FINZ_CARGASMANUALES Y',
'                WHERE Y.TIPO=:P145_TIPOCARGA AND Y.ANIO=:P145_ANIO AND Y.MES=:P145_MES AND Y.VC1=X.VC1)',
'    WHERE TIPO=:P145_TIPOCARGA AND ANIO=:P145_ANIO AND MES=:P145_MES AND ESTADO=1',
'    AND EXISTS (SELECT ''X''',
'                FROM T_FINZ_CARGASMANUALES Y',
'                WHERE Y.TIPO=:P145_TIPOCARGA AND Y.ANIO=:P145_ANIO AND Y.MES=:P145_MES AND Y.VC1=X.VC1);',
unistr('    -- en N7 calculo el descuento regal\00EDas'),
unistr('    -- obtengo porcentage de regal\00EDas'),
'    BEGIN',
'       SELECT VALOR/100 INTO V_PORCREGALIAS',
'       FROM T_CORP_UDC ',
'       WHERE ID_CABECERA=''FINZ_GGEST'' AND ID_TABLA=''POR'' AND DESCRIPCION2=''REGALIAS_MARCAS'' AND ACTIVO=1;',
'      EXCEPTION WHEN NO_DATA_FOUND THEN V_PORCREGALIAS:=0;',
'',
'    END;',
'',
'    -- Obtnego el total de las regalias sin descuento',
'    BEGIN',
'        SELECT SUM(N5) INTO V_TOTALREGALIAS',
'        FROM T_FINZ_CARGASMANUALES',
'        WHERE TIPO=:P145_TIPOCARGA AND ANIO=:P145_ANIO AND MES=:P145_MES;',
'      EXCEPTION WHEN NO_DATA_FOUND THEN V_TOTALREGALIAS:=0;',
'    END;',
'',
'    UPDATE T_FINZ_CARGASMANUALES',
'     SET N7= (N5/V_TOTALREGALIAS)*V_PORCREGALIAS',
'    WHERE TIPO=:P145_TIPOCARGA AND ANIO=:P145_ANIO AND MES=:P145_MES AND ESTADO=1;',
'    -- en N8 calculo regalias',
'    UPDATE T_FINZ_CARGASMANUALES',
'     SET N8= N7+N6',
'    WHERE TIPO=:P145_TIPOCARGA AND ANIO=:P145_ANIO AND MES=:P145_MES AND ESTADO=1;',
'END;'))
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(211879967430446244)
,p_event_id=>wwv_flow_imp.id(211879716618446242)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_02=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(269629409290797416)
,p_name=>'Cierre dialogo subir RTIR'
,p_event_sequence=>30
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(211879099519446235)
,p_condition_element=>'P145_TIPOCARGA'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'RTIR'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(269629503774797417)
,p_event_id=>wwv_flow_imp.id(269629409290797416)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
unistr('-- verifico que a\00F1o y mes tenagan un valor , no pueden ser nulos'),
'IF :P145_ANIO IS NULL OR :P145_MES IS NULL THEN',
unistr('   raise_application_error (-20001,''A\00F1o y Mes deben tener un valor.'');'),
'END IF;',
'',
'-- borro registros anteriores',
'DELETE FROM T_FINZ_CARGASMANUALES',
'WHERE TIPO=:P145_TIPOCARGA AND ANIO=:P145_ANIO AND MES=:P145_MES --AND ESTADO=9 ',
'AND COMPANIA=:G_COMPANIA;',
'',
unistr('-- inserto los datos para Reducci\00F3n Tarifa Impuesto a la Renta'),
'--INSERT INTO T_FINZ_CARGASMANUALES (TIPO,ANIO,MES,N1,ESTADO,COMPANIA)',
'INSERT INTO T_FINZ_CARGASMANUALES(TIPO, ANIO, MES,ESTADO, N1,N2,N3,N4,N5,N6,N7,N8,COMPANIA)',
'SELECT :P145_TIPOCARGA,:P145_ANIO,:P145_MES,1,C02,replace(C03,''.'','',''),replace(C04,''.'','',''),replace(C05,''.'','',''),',
'       replace(C06,''.'','',''),replace(C07,''.'','',''),replace(C08,''.'','',''),replace(C09,''.'','',''),:G_COMPANIA',
'FROM vt_apex_excel;',
'',
'-- Actualizo datos del activo fijo',
'UPDATE T_FINZ_CARGASMANUALES',
'   SET (VC1,DT1)=(SELECT FADL01,FADAJ',
'                  FROM VT_FINZ_ACTIVOSFIJOS',
'                  WHERE FANUMB=N1)',
'WHERE TIPO=:P145_TIPOCARGA AND ESTADO=1 AND COMPANIA=:G_COMPANIA',
'AND EXISTS (SELECT ''X''',
'            FROM VT_FINZ_ACTIVOSFIJOS',
'            WHERE FANUMB=N1);',
'',
''))
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(269629771349797419)
,p_event_id=>wwv_flow_imp.id(269629409290797416)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_name=>'PIVOT'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'--',
unistr('-- tomo de la tabla F1202:  MCU=''11000'' LT=AA FLSUB=''01      '' y desde el a\00F1o 2017'),
unistr('-- verifico que a\00F1o tenga un valor'),
'',
'DECLARE',
'   ',
'  V_FECDESDE NUMBER :=0;',
'  V_FECHASTA NUMBER :=0;',
'',
'BEGIN',
'',
'    IF :P145_ANIO IS NOT NULL AND :P145_MES IS NOT NULL THEN',
'',
'      -- borro registros en estado =1 y N2 is null',
'      DELETE T_FINZ_CARGASMANUALES',
'      WHERE ESTADO=1 AND TIPO=:P145_TIPOCARGA AND ANIO=:P145_ANIO AND MES=:P145_MES AND N2 IS NOT NULL;',
'',
'       --raise_application_error (-20001,''V_FECDESDE: ''||V_FECDESDE||'' V_FECHASTA: ''||V_FECHASTA);',
unistr('       -- creo los valores pOr a\00F1o de cadu uno de los activos ingresados'),
'       INSERT INTO T_FINZ_CARGASMANUALES (TIPO, ANIO, MES, N1,ESTADO,COMPANIA,N2)',
'       SELECT :P145_TIPOCARGA,FLFY+2000,:P145_MES,FLNUMB,8,:G_COMPANIA,SUM(FLAPYC/100)+SUM(FLAWTD/100)',
'       FROM F1202@JDEDTADL, T_FINZ_CARGASMANUALES',
'       WHERE FLMCU=''       11000'' AND FLLT=''AA'' and FLSUB=''01      ''',
'       AND FLFY BETWEEN 18 AND :P145_ANIO-2000 AND FLNUMB=N1 ',
'       AND ESTADO=9 AND TIPO=:P145_TIPOCARGA AND ANIO=:P145_ANIO AND MES=:P145_MES AND N2 IS NULL',
'       GROUP BY FLNUMB,FLFY;',
'       ',
'        -- Actualizo datos del activo fijo',
'        UPDATE T_FINZ_CARGASMANUALES',
'        SET (VC1,DT1)=(SELECT FADL01,FADAJ',
'                       FROM VT_FINZ_ACTIVOSFIJOS',
'                       WHERE FANUMB=N1)',
'        WHERE TIPO=:P145_TIPOCARGA AND ESTADO=8 AND COMPANIA=:G_COMPANIA',
'        AND EXISTS (SELECT ''X''',
'                    FROM VT_FINZ_ACTIVOSFIJOS',
'                    WHERE FANUMB=N1);',
'',
'        -- creo la tabla PIVOT ',
'        INSERT INTO T_FINZ_CARGASMANUALES(TIPO, ANIO, MES,DT1,VC1,ESTADO, N1,N2,N3,N4,N5,N6,N7,N8,COMPANIA)',
'        SELECT :P145_TIPOCARGA,:P145_ANIO,:P145_MES,DT1,VC1,1,N1,UNO,DOS,TRES,CUATRO,CINCO,SEIS,SIETE,:G_COMPANIA',
'        FROM (SELECT VC1,DT1,ANIO,N1,N2',
'              FROM T_FINZ_CARGASMANUALES',
'              WHERE TIPO=''RTIR'' AND ESTADO=8 AND COMPANIA=:G_COMPANIA',
'              ) ',
'        PIVOT (MAX(N2) for ANIO in (''2018'' AS "UNO",''2019'' AS "DOS",''2020'' AS "TRES",''2021'' AS "CUATRO",',
'                                    ''2022'' AS "CINCO",''2023'' AS "SEIS",''2024'' AS "SIETE",''2025'' AS "OCHO",',
'                                    ''2026'' AS "NUEV2",''2027'' AS "DIEZ"',
'                                    ));',
'          -- borro registros en estado =1 y N2 is null',
'     DELETE T_FINZ_CARGASMANUALES',
'     WHERE ESTADO<>1 AND TIPO=:P145_TIPOCARGA AND COMPANIA=:G_COMPANIA;--AND ANIO=:P145_ANIO AND MES=:P145_MES AND N2 IS NULL;',
'      ',
'      ELSE',
unistr('         raise_application_error (-20001,''A\00D1O y MES deben tener alg\00FAn valor'');'),
'    END IF;',
'    ',
'',
'END;'))
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
,p_server_condition_type=>'EXPRESSION'
,p_server_condition_expr1=>'1=2'
,p_server_condition_expr2=>'PLSQL'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(269629936939797421)
,p_event_id=>wwv_flow_imp.id(269629409290797416)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_name=>'Activos_fijos'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'   V_ANIO  NUMBER :=0;',
'   V_VALORINVERSION NUMBER :=0;',
'   V_PORCENTAJE  NUMBER :=0;',
'',
'BEGIN',
'    ',
unistr('    -- obtengo el total de loa activos fijos que se ingresan por la apicaci\00F3n'),
'    INSERT INTO T_FINZ_CARGASMANUALES(TIPO, ANIO, MES,VC1,VC2,ESTADO,N1,N8,COMPANIA)',
unistr('    SELECT :P145_TIPOCARGA,:P145_ANIO, :P145_MES, ''Detalle de Inversi\00F3n'',''SI'',1, '),
'            SUM(NVL(N2,0)+NVL(N3,0)+NVL(N4,0)+NVL(N5,0)+NVL(N6,0)+NVL(N7,0)+NVL(N8,0)),1,:G_COMPANIA',
'    FROM T_FINZ_CARGASMANUALES',
'    WHERE TIPO=:P145_TIPOCARGA AND ANIO=:P145_ANIO AND MES=:P145_MES AND ESTADO=1 AND COMPANIA=:G_COMPANIA;',
'',
'    V_ANIO:=:P145_ANIO-2000;',
'    -- obtengo el valor de lo activos fijos',
'    -- las cuentas tomo de la tabla general FINZ_GGEST - ID_TABLA=''ACTFIJ''',
'    INSERT INTO T_FINZ_CARGASMANUALES(TIPO, ANIO, MES,VC1,VC2,ESTADO,N1,N8,COMPANIA)',
'    SELECT :P145_TIPOCARGA,:P145_ANIO, :P145_MES, ''Total Activos Fijos Brutos'',''SI'',1, SUM(GLAA/100),2,:G_COMPANIA',
'    FROM F0911@JDEDTADL X',
'    WHERE GLLT = ''AA'' AND GLCTRY = 20 AND GLFY<= V_ANIO AND GLPN  <= :P145_MES  AND GLCO = ''00001''',
'    AND GLAID IN (SELECT GMAID',
'                  FROM F0901@JDEDTADL ',
'                  WHERE GMSUB != ''        ''              ',
'                  AND EXISTS (SELECT ''X''',
'                              FROM T_CORP_UDC',
'                              WHERE ID_CABECERA=''FINZ_GGEST'' AND ID_TABLA=''ACTFIJ'' AND ACTIVO=1',
'                              AND LPAD(VALOR,12,'' '')=GMMCU AND RPAD(VALOR2,6,'' '')=GMOBJ AND RPAD(VALOR3,8,'' '')=GMSUB));',
'',
'    -- recupero el porcentaje para el calculo, tomo de la tabla general FINZ_GGEST - ID_TABLA=''POR'' DESCRIPCION2=''IMPUESTO_RENTA''',
'    INSERT INTO T_FINZ_CARGASMANUALES(TIPO, ANIO, MES,VC1,VC2,ESTADO,N1,N8,COMPANIA)',
'    SELECT :P145_TIPOCARGA,:P145_ANIO, :P145_MES, ''Porcentaje'',''SI'',1, (VALOR/100),3,:G_COMPANIA',
'    FROM T_CORP_UDC',
'    WHERE ID_CABECERA=''FINZ_GGEST'' AND ID_TABLA=''POR'' AND DESCRIPCION2=''IMPUESTO_RENTA'' AND ACTIVO=1;',
'',
unistr('    -- recupero el valor de la inversi\00F3n'),
'    SELECT SUM(N1) INTO V_VALORINVERSION',
'    FROM T_FINZ_CARGASMANUALES',
'    WHERE TIPO=:P145_TIPOCARGA AND ANIO=:P145_ANIO AND MES=:P145_MES AND ESTADO=1 AND COMPANIA=:G_COMPANIA AND VC2=''SI'' AND N8=1;',
'',
unistr('    -- recupero porcentaje para el c\00E1lculo'),
'    SELECT N1 INTO V_PORCENTAJE',
'    FROM T_FINZ_CARGASMANUALES',
'    WHERE TIPO=:P145_TIPOCARGA AND ANIO=:P145_ANIO AND MES=:P145_MES AND ESTADO=1 AND COMPANIA=:G_COMPANIA AND VC2=''SI'' AND N8=1;',
'    ',
unistr('    -- calculo el porcentaje de reducci\00F3n'),
'    ',
'    INSERT INTO T_FINZ_CARGASMANUALES(TIPO, ANIO, MES,VC1,VC2,ESTADO,N1,N8,COMPANIA)',
unistr('    SELECT :P145_TIPOCARGA,:P145_ANIO, :P145_MES, ''Porcentaje Reducci\00F3n'',''SI'',1,(V_VALORINVERSION/N1)*V_PORCENTAJE'),
'    ,4,:G_COMPANIA',
'    FROM T_FINZ_CARGASMANUALES',
'    WHERE TIPO=:P145_TIPOCARGA AND ANIO=:P145_ANIO AND MES=:P145_MES AND ESTADO=1 AND COMPANIA=:G_COMPANIA AND VC2=''SI'' AND N8=2;',
'    ',
'',
'END;',
''))
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
,p_server_condition_type=>'EXPRESSION'
,p_server_condition_expr1=>'1=2'
,p_server_condition_expr2=>'PLSQL'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(269629639853797418)
,p_event_id=>wwv_flow_imp.id(269629409290797416)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_02=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(222833281330009924)
,p_name=>'Calcula_1'
,p_event_sequence=>40
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(222830976201009901)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'NATIVE_IG|REGION TYPE|interactivegridsave'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(222833305410009925)
,p_event_id=>wwv_flow_imp.id(222833281330009924)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'   V_VALOR   NUMBER :=0;',
'',
'BEGIN',
'/*',
'SELECT SUM(N1)*(:P145_PORCENTAJE/100)',
'INTO V_VALOR',
'FROM T_FINZ_CARGASMANUALES',
'WHERE TIPO=''GP'' AND ANIO=:P145_ANIO;*/',
'',
'UPDATE T_FINZ_CARGASMANUALES SET N4=:P145_PORCENTAJE',
'WHERE TIPO=''GP'' AND ANIO=:P145_ANIO AND MES=:P145_MES;',
'',
'--:P145_TOTAL:=V_VALOR;',
'END;'))
,p_attribute_02=>'P145_PORCENTAJE'
,p_attribute_03=>'P145_TOTAL'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(222833460690009926)
,p_event_id=>wwv_flow_imp.id(222833281330009924)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_02=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(225042937556262434)
,p_name=>'Valida INE'
,p_event_sequence=>50
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'ready'
,p_display_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_display_when_cond=>'P145_TIPOCARGA'
,p_display_when_cond2=>'INE'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(225043066192262435)
,p_event_id=>wwv_flow_imp.id(225042937556262434)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'-- verifico si existen datos ya cargados',
'DECLARE ',
'   V_CONTADOR NUMBER  :=0;',
'BEGIN',
'--raise_application_error (-20001,''P145_TIPOCARGA: ''||:P145_TIPOCARGA||'' P145_ANIO. ''||:P145_ANIO);',
'SELECT COUNT(*) INTO V_CONTADOR',
'FROM T_FINZ_CARGASMANUALES ',
'WHERE TIPO=:P145_TIPOCARGA AND ANIO=:P145_ANIO  AND MES=:P145_MES AND N1<>0 AND ESTADO=1;',
'',
':P145_BANDERAINE:=V_CONTADOR;',
'',
'END;'))
,p_attribute_02=>'P145_ANIO,P145_TIPOCARGA'
,p_attribute_03=>'P145_BANDERAINE'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(258005221902352046)
,p_name=>'Valida DJP'
,p_event_sequence=>60
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'ready'
,p_display_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_display_when_cond=>'P145_TIPOCARGA'
,p_display_when_cond2=>'DJP'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(258005368145352047)
,p_event_id=>wwv_flow_imp.id(258005221902352046)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'-- verifico si existen datos ya cargados',
'DECLARE ',
'   V_CONTADOR NUMBER  :=0;',
'BEGIN',
'--raise_application_error (-20001,''valida DJP, P145_TIPOCARGA: ''||:P145_TIPOCARGA||'' P145_ANIO. ''||:P145_ANIO);',
'SELECT COUNT(*) INTO V_CONTADOR',
'FROM T_FINZ_CARGASMANUALES ',
'WHERE COMPANIA=:G_COMPANIA AND TIPO=:P145_TIPOCARGA AND ANIO=:P145_ANIO  AND MES=:P145_MES AND N1<>0 AND ESTADO=1;',
'',
':P145_BANDERADJP:=V_CONTADOR;',
'',
'END;'))
,p_attribute_02=>'P145_ANIO,P145_TIPOCARGA'
,p_attribute_03=>'P145_BANDERADJP'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(469054207594883602)
,p_name=>'Valida GPPP'
,p_event_sequence=>70
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'ready'
,p_display_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_display_when_cond=>'P145_TIPOCARGA'
,p_display_when_cond2=>'GP'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(469054393655883603)
,p_event_id=>wwv_flow_imp.id(469054207594883602)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'-- verifico si existen datos ya cargados',
'DECLARE ',
'   V_CONTADOR NUMBER  :=0;',
'BEGIN',
'--raise_application_error (-20001,''valida DJP, P145_TIPOCARGA: ''||:P145_TIPOCARGA||'' P145_ANIO. ''||:P145_ANIO);',
'SELECT COUNT(*) INTO V_CONTADOR',
'FROM T_FINZ_CARGASMANUALES ',
'WHERE COMPANIA=:G_COMPANIA AND TIPO=:P145_TIPOCARGA AND ANIO=:P145_ANIO  AND MES=:P145_MES AND N1<>0 AND ESTADO=1;',
'',
':P145_BANDERAGP:=V_CONTADOR;',
'',
'END;'))
,p_attribute_02=>'P145_ANIO,P145_TIPOCARGA'
,p_attribute_03=>'P145_BANDERAGP'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(452277420666507337)
,p_name=>'New'
,p_event_sequence=>80
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(452277332507507336)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(452277552799507338)
,p_event_id=>wwv_flow_imp.id(452277420666507337)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'mostrarBarra();'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(452277779469507340)
,p_event_id=>wwv_flow_imp.id(452277420666507337)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'  V_RESP  VARCHAR(200);',
'',
'BEGIN',
' ',
'pk_finz_conciliacion.sp_asientosconciliacion(:G_COMPANIA,:APP_USER,:P145_ANIO,:P145_MES,V_RESP);',
'',
'END;'))
,p_attribute_02=>'P145_ANIO,P145_MES'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(452277803920507341)
,p_event_id=>wwv_flow_imp.id(452277420666507337)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(211876948854446214)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(452277621677507339)
,p_event_id=>wwv_flow_imp.id(452277420666507337)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'ocultarBarra();'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(222833709891009929)
,p_process_sequence=>10
,p_process_point=>'AFTER_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Recupero_porcentaje'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'   V_VALOR  NUMBER :=0;',
'   V_PORCENTAJE NUMBER :=0;',
'BEGIN',
'    SELECT SUM(N1)*MAX((N4/100)),MAX(N4)',
'    INTO V_VALOR,V_PORCENTAJE--:P145_TOTAL,:P145_PORCENTAJE',
'    FROM T_FINZ_CARGASMANUALES',
'    WHERE TIPO=''GP'' AND ANIO=:P145_ANIO AND MES=:P145_MES AND ESTADO=1;',
'',
'   :P145_TOTAL:=V_VALOR;:P145_PORCENTAJE:=V_PORCENTAJE;',
'END;',
'',
''))
,p_process_clob_language=>'PLSQL'
,p_process_when=>'P145_TIPOCARGA'
,p_process_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_process_when2=>'GP'
,p_internal_uid=>222833709891009929
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(225039678695262401)
,p_process_sequence=>20
,p_process_point=>'AFTER_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Incremento_empleados'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'-- borro el detalle  Incremento Neto de Empleados cuando estado=0',
'',
'DELETE FROM T_FINZ_CARGASMANUALES',
'WHERE COMPANIA=:G_COMPANIA AND ANIO=:P145_ANIO AND TIPO=:P145_TIPOCARGA AND MES=:P145_MES AND ESTADO=1;',
'',
'-- inserto el detalle Incremento Neto de Empleados',
'INSERT INTO T_FINZ_CARGASMANUALES(TIPO,ANIO,MES,VC1,N1,N4,ESTADO,COMPANIA)',
unistr('SELECT :P145_TIPOCARGA,:P145_ANIO,:P145_MES,''N\00FAmero de empleados nuevos seg\00FAn las condiciones establecidas en la normativa tributaria.'',0,1,1,:G_COMPANIA'),
'FROM DUAL;',
'',
'INSERT INTO T_FINZ_CARGASMANUALES(TIPO,ANIO,MES,VC1,N1,N4,ESTADO,COMPANIA)',
unistr('SELECT :P145_TIPOCARGA,:P145_ANIO,:P145_MES,''N\00FAmero de empleados que han salido seg\00FAn las condiciones establecidas en la normativa tributaria.'',0,2,1,:G_COMPANIA'),
'FROM DUAL;',
'',
'INSERT INTO T_FINZ_CARGASMANUALES(TIPO,ANIO,MES,VC1,N1,N4,VC2,ESTADO,COMPANIA)',
unistr('SELECT :P145_TIPOCARGA,:P145_ANIO,:P145_MES,''Incremento Neto de Empleos seg\00FAn las condiciones establecidas en la normativa tributaria. (a)'',0,3,''SI'',1,:G_COMPANIA'),
'FROM DUAL;',
'',
'INSERT INTO T_FINZ_CARGASMANUALES(TIPO,ANIO,MES,VC1,N1,N4,ESTADO,COMPANIA)',
unistr('SELECT :P145_TIPOCARGA,:P145_ANIO,:P145_MES,''Valor total de remuneraciones y beneficios de ley sobre los que se aport\00F3 al IESS pagados a los empleados nuevos en el ejercicio fiscal auditado.'',0,4,1,:G_COMPANIA'),
'FROM DUAL;',
'',
'INSERT INTO T_FINZ_CARGASMANUALES(TIPO,ANIO,MES,VC1,N1,N4,VC2,ESTADO,COMPANIA)',
'SELECT :P145_TIPOCARGA,:P145_ANIO,:P145_MES,''Valor promedio de remuneraciones y beneficios de ley a empleados nuevos'',0,5,''SI'',1,:G_COMPANIA',
'FROM DUAL;',
'',
'INSERT INTO T_FINZ_CARGASMANUALES(TIPO,ANIO,MES,VC1,N1,N4,ESTADO,COMPANIA)',
unistr('SELECT :P145_TIPOCARGA,:P145_ANIO,:P145_MES,''Gasto de n\00F3mina del ejercicio fiscal auditado. (b)'',0,6,1,:G_COMPANIA'),
'FROM DUAL;',
'',
'INSERT INTO T_FINZ_CARGASMANUALES(TIPO,ANIO,MES,VC1,N1,N4,ESTADO,COMPANIA)',
unistr('SELECT :P145_TIPOCARGA,:P145_ANIO,:P145_MES,''Gasto de n\00F3mina del ejercicio fiscal anterior al auditado.'',0,7,1,:G_COMPANIA'),
'FROM DUAL;',
'',
'INSERT INTO T_FINZ_CARGASMANUALES(TIPO,ANIO,MES,VC1,N1,N4,VC2,ESTADO,COMPANIA)',
unistr('SELECT :P145_TIPOCARGA,:P145_ANIO,:P145_MES,''Diferencia en el gasto de n\00F3mina entre los ejercicios fiscales'',0,8,''SI'',1,:G_COMPANIA'),
'FROM DUAL;',
'',
'INSERT INTO T_FINZ_CARGASMANUALES(TIPO,ANIO,MES,VC1,N1,N4,VC2,ESTADO,COMPANIA)',
unistr('SELECT :P145_TIPOCARGA,:P145_ANIO,:P145_MES,''Deducci\00F3n por incremento neto de empleados calculada'',0,9,''SI'',1,:G_COMPANIA'),
'FROM DUAL;',
'',
'INSERT INTO T_FINZ_CARGASMANUALES(TIPO,ANIO,MES,VC1,N1,N4,ESTADO,COMPANIA)',
unistr('SELECT :P145_TIPOCARGA,:P145_ANIO,:P145_MES,''Valor de la deducci\00F3n por incremento neto de empleos declarada en el formulario de impuesto a la renta'',0,10,1,:G_COMPANIA'),
'FROM DUAL;',
'',
'INSERT INTO T_FINZ_CARGASMANUALES(TIPO,ANIO,MES,VC1,N1,N4,VC2,ESTADO,COMPANIA)',
'SELECT :P145_TIPOCARGA,:P145_ANIO,:P145_MES,''Diferencia (c)'',0,11,''SI'',1,:G_COMPANIA FROM DUAL;',
'',
'--:P145_BANDERAINE:=1;',
''))
,p_process_clob_language=>'PLSQL'
,p_process_when=>':P145_TIPOCARGA=''INE'' AND :P145_BANDERAINE=0'
,p_process_when_type=>'EXPRESSION'
,p_process_when2=>'PLSQL'
,p_internal_uid=>225039678695262401
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(254937226347743711)
,p_process_sequence=>140
,p_process_point=>'AFTER_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Desahucio_Jubilacion'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'--',
'--raise_application_error (-20001,''CARGA REGISTROS INICIALES PARA DJP, P145_TIPOCARGA: ''||:P145_TIPOCARGA||'' P145_ANIO. ''||:P145_ANIO);',
'-- borro datos anteriores',
'',
' DELETE FROM T_FINZ_CARGASMANUALES',
' WHERE COMPANIA=:G_COMPANIA AND TIPO=:P145_TIPOCARGA AND ANIO=:P145_ANIO AND MES=:P145_MES AND ESTADO=1;',
'',
'-- INSERTO los registros para digitar el valor',
'',
'INSERT INTO T_FINZ_CARGASMANUALES (TIPO,ANIO,MES,VC1,VC2,VC3,N1,N7,N8,ESTADO,COMPANIA)',
unistr('SELECT :P145_TIPOCARGA,:P145_ANIO,:P145_MES,''DESAHUCIO'',''DIFERENCIA TEMPORARIA Empleados mayor a 10 a\00F1os'','''',0,1,1,1,:G_COMPANIA'),
'FROM DUAL;',
'',
'INSERT INTO T_FINZ_CARGASMANUALES (TIPO,ANIO,MES,VC1,VC2,VC3,N1,N7,N8,ESTADO,COMPANIA)',
'SELECT :P145_TIPOCARGA,:P145_ANIO,:P145_MES,''DESAHUCIO'',''(-) Ajuste por salidas anticipadas al 31-diciembre-2021 (7)'','''',0,1,2,1,:G_COMPANIA',
'FROM DUAL;',
'',
'INSERT INTO T_FINZ_CARGASMANUALES (TIPO,ANIO,MES,VC1,VC2,VC3,N1,N7,N8,ESTADO,COMPANIA)',
unistr('SELECT :P145_TIPOCARGA,:P145_ANIO,:P145_MES,''DESAHUCIO'',''Reversi\00F3n Diferencias temporarias Cesantes'','''',0,1,3,1,:G_COMPANIA'),
'FROM DUAL;',
'',
'-- inserto los registros para el cuadro 2 ',
'',
'INSERT INTO T_FINZ_CARGASMANUALES (TIPO,ANIO,MES,VC1,VC2,VC3,N1,N7,N8,ESTADO,COMPANIA)',
unistr('SELECT :P145_TIPOCARGA,:P145_ANIO,:P145_MES,''Jubilaci\00F3n Patronal'',''DIFERENCIA TEMPORARIA Empleados mayor a 10 a\00F1os'','''',0,1,4,1,:G_COMPANIA'),
'FROM DUAL;',
'',
'INSERT INTO T_FINZ_CARGASMANUALES (TIPO,ANIO,MES,VC1,VC2,VC3,N1,N7,N8,ESTADO,COMPANIA)',
unistr('SELECT :P145_TIPOCARGA,:P145_ANIO,:P145_MES,''Jubilaci\00F3n Patronal'',''(-) Ajuste por salidas anticipadas al 31-diciembre-2021 (7)'','''',0,1,5,1,:G_COMPANIA'),
'FROM DUAL;',
'',
'INSERT INTO T_FINZ_CARGASMANUALES (TIPO,ANIO,MES,VC1,VC2,VC3,N1,N7,N8,ESTADO,COMPANIA)',
unistr('SELECT :P145_TIPOCARGA,:P145_ANIO,:P145_MES,''Jubilaci\00F3n Patronal'',''Reversi\00F3n Diferencias temporarias Cesantes'','''',0,1,6,1,:G_COMPANIA'),
'FROM DUAL;',
'',
'-- Registro para 835=Deducciones Good Will por Leyes Especiales ',
'INSERT INTO T_FINZ_CARGASMANUALES (TIPO,ANIO,MES,VC1,VC2,VC3,N1,N7,N8,ESTADO,COMPANIA)',
unistr('SELECT :P145_TIPOCARGA,:P145_ANIO,:P145_MES,''Jubilaci\00F3n Patronal'',''Deducciones Good Will por Leyes Especiales'','''',0,1,835,1,:G_COMPANIA'),
'FROM DUAL;'))
,p_process_clob_language=>'PLSQL'
,p_process_when=>':P145_TIPOCARGA=''DJP'' AND :P145_BANDERADJP=0 AND 1=2'
,p_process_when_type=>'EXPRESSION'
,p_process_when2=>'PLSQL'
,p_internal_uid=>254937226347743711
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(462184324536489244)
,p_process_sequence=>150
,p_process_point=>'AFTER_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Desahucio_Jubilacion_1'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'-- borro datos anteriores',
'',
' DELETE FROM T_FINZ_CARGASMANUALES',
' WHERE COMPANIA=:G_COMPANIA AND TIPO=:P145_TIPOCARGA AND ANIO=:P145_ANIO AND MES=:P145_MES AND ESTADO=1;',
'',
'-- INSERTO los registros para digitar el valor',
'-- tomo los datos de la tabla general FINZ_GGEST ID_TABLA=DESJUB ACTIVO=1',
'INSERT INTO T_FINZ_CARGASMANUALES (TIPO,ANIO,MES,VC1,VC2,VC3,N1,N7,N8,ESTADO,COMPANIA)',
'SELECT :P145_TIPOCARGA,:P145_ANIO,:P145_MES,DESCRIPCION,DESCRIPCION2,'''',0,1,VALOR,1,:G_COMPANIA',
'FROM T_CORP_UDC',
'WHERE ID_CABECERA=''FINZ_GGEST'' AND ID_TABLA=''DESJUB''',
'AND ACTIVO=1;'))
,p_process_clob_language=>'PLSQL'
,p_process_when=>':P145_TIPOCARGA=''DJP'' AND :P145_BANDERADJP=0'
,p_process_when_type=>'EXPRESSION'
,p_process_when2=>'PLSQL'
,p_internal_uid=>462184324536489244
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(469054538876883605)
,p_process_sequence=>160
,p_process_point=>'AFTER_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Desahucio_GPPP'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'-- borro datos anteriores',
'',
' DELETE FROM T_FINZ_CARGASMANUALES',
' WHERE COMPANIA=:G_COMPANIA AND TIPO=:P145_TIPOCARGA AND ANIO=:P145_ANIO AND MES=:P145_MES AND ESTADO=1;',
'',
'-- INSERTO los registros para digitar el valor',
'-- tomo los datos de la tabla general FINZ_GGEST ID_TABLA=GPPP ACTIVO=1',
'INSERT INTO T_FINZ_CARGASMANUALES (TIPO,ANIO,MES,VC1,VC3,VC2,N1,N2,N7,N8,ESTADO,COMPANIA)',
'SELECT :P145_TIPOCARGA,:P145_ANIO,:P145_MES,DESCRIPCION,DESCRIPCION2,'''',0,0,1,VALOR,1,:G_COMPANIA',
'FROM T_CORP_UDC',
'WHERE ID_CABECERA=''FINZ_GGEST'' AND ID_TABLA=''GPPP''',
'AND ACTIVO=1;',
'',
'-- actualizo el valor acumulado por AN8 tomo de la tabla F0911 cuenta:16100.64101.15',
'',
'UPDATE T_FINZ_CARGASMANUALES',
'   SET N1=(SELECT SUM(GLAA/100)',
'           FROM F0911@JDEDTADL',
'           WHERE GLANI=''16100.64101.15               '' AND GLLT = ''AA'' AND GLCTRY = 20 ',
'           AND GLFY= :P145_ANIO-2000 AND GLPN  <= :P145_MES AND GLCO = :G_COMPANIA AND GLAN8=N8)',
'WHERE COMPANIA=:G_COMPANIA AND TIPO=:P145_TIPOCARGA AND ANIO=:P145_ANIO AND MES=:P145_MES AND ESTADO=1',
'AND EXISTS (SELECT ''X''',
'            FROM F0911@JDEDTADL',
'           WHERE GLANI=''16100.64101.15               '' AND GLLT = ''AA'' AND GLCTRY = 20 ',
'           AND GLFY= :P145_ANIO-2000 AND GLPN  <= :P145_MES AND GLCO = :G_COMPANIA AND GLAN8=N8);',
'',
'-- actualizo el valor acumulado por AN8 tomo de la tabla F0911 cuenta:16100.64101.15',
'',
'UPDATE T_FINZ_CARGASMANUALES',
'   SET N2=(SELECT SUM(GLAA/100)',
'           FROM F0911@JDEDTADL',
'           WHERE GLANI=''16100.64101.15               '' AND GLLT = ''AA'' AND GLCTRY = 20 ',
'           AND GLFY= :P145_ANIO-2000 AND GLPN = :P145_MES AND GLCO = :G_COMPANIA AND GLAN8=N8)',
'WHERE COMPANIA=:G_COMPANIA AND TIPO=:P145_TIPOCARGA AND ANIO=:P145_ANIO AND MES=:P145_MES AND ESTADO=1',
'AND EXISTS (SELECT ''X''',
'            FROM F0911@JDEDTADL',
'           WHERE GLANI=''16100.64101.15               '' AND GLLT = ''AA'' AND GLCTRY = 20 ',
'           AND GLFY= :P145_ANIO-2000 AND GLPN = :P145_MES AND GLCO = :G_COMPANIA AND GLAN8=N8);'))
,p_process_clob_language=>'PLSQL'
,p_process_when=>':P145_TIPOCARGA=''GP'' AND :P145_BANDERAGP=0'
,p_process_when_type=>'EXPRESSION'
,p_process_when2=>'PLSQL'
,p_internal_uid=>469054538876883605
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(211878956950446234)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_region_id=>wwv_flow_imp.id(211877046040446215)
,p_process_type=>'NATIVE_IG_DML'
,p_process_name=>unistr('Datos L\00EDmites - Save Interactive Grid Data')
,p_attribute_01=>'REGION_SOURCE'
,p_attribute_05=>'Y'
,p_attribute_06=>'Y'
,p_attribute_08=>'Y'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>211878956950446234
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(218461289709766615)
,p_process_sequence=>30
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Economia_Popular'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'--',
unistr('-- busco  todas la facturas del a\00F1o y mes ingresados'),
'-- tomo de la tabla F0018:  DCTO=''PV'' AND AN8=16659 (PROVEEDOR), ATXA= valor (importe imponible), DOCO= NUMERO DE ORDEN',
'-- los datos de la factura tomo de la vista VISTA V0411E NUMERO FACTURA=VINV ',
unistr('-- verifico que a\00F1o, mes Y ruc  tengan un valor'),
'DECLARE',
'   ',
'  V_FECDESDE NUMBER :=0;',
'  V_FECHASTA NUMBER :=0;',
'',
'  CURSOR C1 IS',
'     SELECT Y.VALOR VALOR',
'     FROM T_CORP_UDC Y',
'     WHERE Y.ID_CABECERA=''FINZ_GGEST'' AND Y.ID_TABLA=''BEP'' AND Y.DESCRIPCION2=''BENEFICIO ECONOMIA POPULAR'' AND Y.ACTIVO=1;',
'',
'BEGIN',
'    ',
'    -- borro datos anteriores',
'    DELETE FROM T_FINZ_CARGASMANUALES',
'    WHERE ANIO=:P145_ANIO AND TIPO=''BEP'';',
'',
'    IF :P145_ANIO IS NOT NULL AND :P145_MES IS NOT NULL THEN --AND :P145_RUC IS NOT NULL THEN',
'       -- obtengo las fechas a partir de los filtros ingresados',
'       SELECT TO_CHAR(TO_DATE(''01/01/''||:P145_ANIO,''DD/MM/YYYY''),''YYYYDDD'')-1900000,',
'              TO_CHAR(LAST_DAY(TO_DATE(''01/''||lpad(:P145_MES,2,''0'')||''/''||:P145_ANIO,''DD/MM/YYYY'')),''YYYYDDD'')-1900000 ',
'              INTO V_FECDESDE, V_FECHASTA',
'       FROM  DUAL;',
'',
'       --raise_application_error (-20001,''V_FECDESDE: ''||V_FECDESDE||'' V_FECHASTA: ''||V_FECHASTA);',
'       -- en N3 recupero el % de BENEFICIO',
'       FOR RUC IN C1 LOOP',
'           ',
'           INSERT INTO T_FINZ_CARGASMANUALES (TIPO,ANIO,MES,N1,N2,VC1,VC2,DT1,ESTADO,N3,N4,COMPANIA)',
'           SELECT :P145_TIPOCARGA,:P145_ANIO,:P145_MES,TDAEXP/100,TDDOCO,RPVINV,ABTAX,TO_DATE(TDTRDJ + 1900000,''yyyyddd''),1,Z.VALOR,',
'                  (TDAEXP/100)*(Z.VALOR/100),:G_COMPANIA',
'           FROM F0018@JDEDTADL X,F0411@JDEDTADL Y, F0101@JDEDTADL, T_CORP_UDC Z',
'           WHERE TDDCTO=''PV'' AND ABTAX=RPAD(RUC.VALOR,20,'' '') AND TDAN8=ABAN8',
'           AND TDDGL BETWEEN V_FECDESDE AND V_FECHASTA --123001 AND 123366',
'           AND TDDOCO=RPDOC AND TDDCTO=RPDCT',
'           AND Z.ID_CABECERA=''FINZ_GGEST'' AND Z.ID_TABLA=''POR'' AND Z.DESCRIPCION2=''BENEFICIO'' AND Z.ACTIVO=1',
'           ;',
'',
'       END LOOP;',
'      ELSE',
'',
unistr('         --raise_application_error (-20001,''A\00F1o, Mes, RUC deben tener alg\00FAn valor'');'),
unistr('         raise_application_error (-20001,''A\00F1o, Mes deben tener alg\00FAn valor'');'),
'    END IF;',
'    ',
'',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(218460475000766607)
,p_process_when=>'P145_TIPOCARGA'
,p_process_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_process_when2=>'BEP'
,p_internal_uid=>218461289709766615
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(218462616499766629)
,p_process_sequence=>40
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Deduccion_Depreciacion'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'--',
unistr('-- busco  todas la facturas del a\00F1o y mes ingresados'),
'-- tomo de la tabla F1202:  MCU<>''11000'' LT=AA',
unistr('-- verifico que a\00F1o tenga un valor'),
'',
'DECLARE',
'   ',
'  V_FECDESDE NUMBER :=0;',
'  V_FECHASTA NUMBER :=0;',
'',
'BEGIN',
'',
'    IF :P145_ANIO IS NOT NULL AND :P145_MES IS NOT NULL THEN',
' ',
'       --raise_application_error (-20001,''V_FECDESDE: ''||V_FECDESDE||'' V_FECHASTA: ''||V_FECHASTA);',
'       -- actualizo DEPRECIACION MENSUAL y ACUMULADA',
'       /*',
'       UPDATE T_FINZ_CARGASMANUALES ',
'       SET (N2,N3)=(SELECT FLAN01/100,(FLAN01/100)*:P145_MES--FLAPYN/100',
'                    FROM F1202@JDEDTADL ',
'                    WHERE FLMCU<>''       11000'' AND FLLT=''AA'' AND FLFY=:P145_ANIO-2000',
'                    AND FLNUMB=N1)',
'       WHERE TIPO=:P145_TIPOCARGA AND ANIO=:P145_ANIO',
'       AND EXISTS (SELECT ''X''',
'                   FROM F1202@JDEDTADL ',
'                   WHERE FLMCU<>''       11000'' AND FLLT=''AA'' AND FLFY=:P145_ANIO-2000',
'                   AND FLNUMB=N1);',
'        -- Actualizo datos del activo fijo',
'        UPDATE T_FINZ_CARGASMANUALES',
'        SET (VC1,DT1)=(SELECT FADL01,FADAJ',
'                       FROM VT_FINZ_ACTIVOSFIJOS',
'                       WHERE FANUMB=N1)',
'        WHERE TIPO=:P145_TIPOCARGA AND ANIO=:P145_ANIO',
'        AND EXISTS (SELECT ''X''',
'                    FROM VT_FINZ_ACTIVOSFIJOS',
'                    WHERE FANUMB=N1);',
'                    */',
'        ',
'        -- borro calculos anteriores en estado=1',
'        DELETE FROM T_FINZ_CARGASMANUALES',
'        WHERE TIPO=:P145_TIPOCARGA AND ANIO=:P145_ANIO AND MES=:P145_MES AND ESTADO=1;',
'        ',
unistr('        -- calculo la depreaci\00F3n tomando de la tabla de par\00E1metros FINZ_GGEST ID_TABLA=''DEDE''  ACTIVO=1'),
'        INSERT INTO T_FINZ_CARGASMANUALES (TIPO,ANIO,MES,N1,N2,N3,VC1,VC2,DT1,DT2,ESTADO,COMPANIA)',
'        SELECT :P145_TIPOCARGA,:P145_ANIO,:P145_MES,VALOR,(FLAN01/100) DEC,(FLAN01/100)*:P145_MES, DESCRIPCION2,DESCRIPCION,VALOR2,VALOR3,',
'               1,:G_COMPANIA',
'        FROM T_CORP_UDC y, F1202@JDEDTADL ',
'        WHERE Y.ID_CABECERA=''FINZ_GGEST'' AND Y.ID_TABLA=''DEDE'' AND Y.ACTIVO=1',
'        AND FLMCU<>''       11000'' AND FLLT=''AA'' AND FLFY=:P145_ANIO-2000 AND FLNUMB=VALOR;',
'        ',
unistr('        -- recalculo el valor de la depreciaci\00F3n para los activos que se compran (autorizaci\00F3n) en el a\00F1o en curso'),
'        UPDATE T_FINZ_CARGASMANUALES',
'           -- SET N3=N2*ROUND(MONTHS_BETWEEN(SYSDATE,DT2)) ',
'           -- SET N3=N2*CEIL(MONTHS_BETWEEN(SYSDATE,DT2)) ',
'           SET N3=N2*(MONTHS_BETWEEN(TRUNC(SYSDATE,''MONTH''),TRUNC(DT2,''MONTH'') ) )',
'        WHERE TIPO=:P145_TIPOCARGA AND ANIO=:P145_ANIO AND MES=:P145_MES AND ESTADO=1',
'        AND TO_CHAR(DT2,''YYYY'')=:P145_ANIO;',
'              ',
'      ELSE',
unistr('         raise_application_error (-20001,''A\00D1O, MES deben tener alg\00FAn valor'');'),
'    END IF;',
'    ',
'',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(218460475000766607)
,p_process_when=>'P145_TIPOCARGA'
,p_process_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_process_when2=>'DD'
,p_internal_uid=>218462616499766629
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(263189783288745802)
,p_process_sequence=>50
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Reduccion_Tarifa_IR'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'--',
unistr('-- tomo de la tabla F1202:  MCU=''11000'' LT=AA FLSUB=''01      '' y desde el a\00F1o 2017'),
unistr('-- verifico que a\00F1o tenga un valor'),
'',
'DECLARE',
'   ',
'  V_FECDESDE NUMBER :=0;',
'  V_FECHASTA NUMBER :=0;',
'',
'BEGIN',
'raise_application_error (-20001,''V_FECDESDE: ''||V_FECDESDE||'' V_FECHASTA: ''||V_FECHASTA);',
'',
'    IF :P145_ANIO IS NOT NULL AND :P145_MES IS NOT NULL THEN',
'',
'      -- borro registros en estado =1 y N2 is null',
'      DELETE T_FINZ_CARGASMANUALES',
'      WHERE ESTADO=1 AND TIPO=:P145_TIPOCARGA AND ANIO=:P145_ANIO AND MES=:P145_MES AND N2 IS NOT NULL;',
'',
'       --raise_application_error (-20001,''V_FECDESDE: ''||V_FECDESDE||'' V_FECHASTA: ''||V_FECHASTA);',
unistr('       -- creo los valores pOr a\00F1o de cadu uno de los activos ingresados'),
'       INSERT INTO T_FINZ_CARGASMANUALES (TIPO, ANIO, MES, N1,ESTADO,COMPANIA,N2)',
'       SELECT :P145_TIPOCARGA,FLFY+2000,:P145_MES,FLNUMB,8,:G_COMPANIA,SUM(FLAPYC/100)+SUM(FLAWTD/100)',
'       FROM F1202@JDEDTADL, T_FINZ_CARGASMANUALES',
'       WHERE FLMCU=''       11000'' AND FLLT=''AA'' and FLSUB=''01      ''',
'       AND FLFY BETWEEN 18 AND :P145_ANIO-2000 AND FLNUMB=N1 ',
'       AND ESTADO=9 AND TIPO=:P145_TIPOCARGA AND ANIO=:P145_ANIO AND MES=:P145_MES AND N2 IS NULL',
'       GROUP BY FLNUMB,FLFY;',
'       ',
'        -- Actualizo datos del activo fijo',
'        UPDATE T_FINZ_CARGASMANUALES',
'        SET (VC1,DT1)=(SELECT FADL01,FADAJ',
'                       FROM VT_FINZ_ACTIVOSFIJOS',
'                       WHERE FANUMB=N1)',
'        WHERE TIPO=:P145_TIPOCARGA AND ESTADO=8 AND COMPANIA=:G_COMPANIA',
'        AND EXISTS (SELECT ''X''',
'                    FROM VT_FINZ_ACTIVOSFIJOS',
'                    WHERE FANUMB=N1);',
'',
'        -- creo la tabla PIVOT ',
'        INSERT INTO T_FINZ_CARGASMANUALES(TIPO, ANIO, MES,DT1,VC1,ESTADO, N1,N2,N3,N4,N5,N6,N7,N8,COMPANIA)',
'        SELECT :P145_TIPOCARGA,:P145_ANIO,:P145_MES,DT1,VC1,1,N1,UNO,DOS,TRES,CUATRO,CINCO,SEIS,SIETE,:G_COMPANIA',
'        FROM (SELECT VC1,DT1,ANIO,N1,N2',
'              FROM T_FINZ_CARGASMANUALES',
'              WHERE TIPO=''RTIR'' AND ESTADO=8 AND COMPANIA=:G_COMPANIA',
'              ) ',
'        PIVOT (MAX(N2) for ANIO in (''2018'' AS "UNO",''2019'' AS "DOS",''2020'' AS "TRES",''2021'' AS "CUATRO",',
'                                    ''2022'' AS "CINCO",''2023'' AS "SEIS",''2024'' AS "SIETE",''2025'' AS "OCHO",',
'                                    ''2026'' AS "NUEV2",''2027'' AS "DIEZ"',
'                                    ));',
'          -- borro registros en estado =1 y N2 is null',
'         DELETE T_FINZ_CARGASMANUALES',
'         WHERE ESTADO<>1 AND TIPO=:P145_TIPOCARGA AND COMPANIA=:G_COMPANIA;--AND ANIO=:P145_ANIO AND MES=:P145_MES AND N2 IS NULL;',
'         -- actualizo el estado del activo',
'         UPDATE T_FINZ_CARGASMANUALES',
'           SET (VC3)=(SELECT FAEQST',
'                      FROM VT_FINZ_ACTIVOSFIJOS',
'                      WHERE FANUMB=N1)',
'         WHERE TIPO=:P145_TIPOCARGA AND ESTADO=1 AND COMPANIA=:G_COMPANIA',
'         AND EXISTS (SELECT ''X''',
'                     FROM VT_FINZ_ACTIVOSFIJOS',
'                     WHERE FANUMB=N1);',
'      ',
'      ELSE',
unistr('         raise_application_error (-20001,''A\00D1O y MES deben tener alg\00FAn valor'');'),
'    END IF;',
'    ',
'',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(211879099519446235)
,p_process_when=>'P145_TIPOCARGA'
,p_process_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_process_when2=>'RTIR'
,p_internal_uid=>263189783288745802
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(469055793599883617)
,p_process_sequence=>60
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Reduccion_Tarifa_IR_1'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'--',
'-- tomo los datos del mes anterior aprobado',
'-- caso 33199',
'--',
'',
'DECLARE',
'   ',
'  V_FECDESDE NUMBER :=0;',
'  V_FECHASTA NUMBER :=0;',
'  V_ANIO NUMBER :=0;',
'  V_MES NUMBER :=0;',
'',
'',
'BEGIN',
'',
'    IF :P145_ANIO IS NOT NULL AND :P145_MES IS NOT NULL THEN',
'',
'       -- borro registros en estado =1 -- ESTO LE COMENTO y DT3 is null (el campo DT3 se llena cuando grabo los datos)',
'       DELETE T_FINZ_CARGASMANUALES',
'       WHERE ESTADO=1 AND TIPO=:P145_TIPOCARGA AND ANIO=:P145_ANIO AND MES=:P145_MES AND ESTADO=1;-- AND DT3 IS NULL;',
'      ',
'       -- obtengo los datos del mes anterior aprobado',
unistr('       -- si mes = 1, resto uno al a\00F1o'),
'       IF :P145_MES=1 THEN',
'          V_ANIO:=:P145_ANIO-1; V_MES:=12;',
'         ELSE',
'          V_ANIO:=:P145_ANIO; V_MES:=:P145_MES-1;',
'       END IF;',
'      ',
'      --raise_application_error (-20001,''ENTRA A ESTA SECCION, valors PARA V_MES: ''||V_MES||'' V_ANIO: ''||V_ANIO);',
'       INSERT INTO T_FINZ_CARGASMANUALES(TIPO, ANIO, MES,DT1,VC1,ESTADO, N1,N2,N3,N4,N5,N6,N7,N8,COMPANIA)',
'       SELECT :P145_TIPOCARGA,:P145_ANIO,:P145_MES,DT1,VC1,1, N1,N2,N3,N4,N5,N6,N7,N8,COMPANIA',
'       FROM T_FINZ_CARGASMANUALES',
'       WHERE TIPO=:P145_TIPOCARGA AND ANIO=V_ANIO AND MES=V_MES AND ESTADO=2 AND COMPANIA=:G_COMPANIA AND VC2 IS NULL;',
'       ',
'       -- actualizo el estado del activo',
'       UPDATE T_FINZ_CARGASMANUALES',
'           SET (VC3)=(SELECT FAEQST',
'                      FROM VT_FINZ_ACTIVOSFIJOS',
'                      WHERE FANUMB=N1)',
'       WHERE TIPO=:P145_TIPOCARGA AND ANIO=:P145_ANIO  AND MES=:P145_MES AND ESTADO=1 AND COMPANIA=:G_COMPANIA',
'       AND EXISTS (SELECT ''X''',
'                   FROM VT_FINZ_ACTIVOSFIJOS',
'                   WHERE FANUMB=N1);',
'      ',
'      ELSE',
unistr('         raise_application_error (-20001,''A\00D1O y MES deben tener alg\00FAn valor'');'),
'    END IF;',
'    ',
'',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(218460475000766607)
,p_process_when=>'P145_TIPOCARGA'
,p_process_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_process_when2=>'RTIR'
,p_internal_uid=>469055793599883617
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(218464662143766649)
,p_process_sequence=>70
,p_process_point=>'AFTER_SUBMIT'
,p_region_id=>wwv_flow_imp.id(218462798421766630)
,p_process_type=>'NATIVE_IG_DML'
,p_process_name=>'DETALLE - Save Interactive Grid Data'
,p_attribute_01=>'REGION_SOURCE'
,p_attribute_05=>'Y'
,p_attribute_06=>'Y'
,p_attribute_08=>'Y'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>218464662143766649
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(222832860369009920)
,p_process_sequence=>80
,p_process_point=>'AFTER_SUBMIT'
,p_region_id=>wwv_flow_imp.id(222830976201009901)
,p_process_type=>'NATIVE_IG_DML'
,p_process_name=>'Publicidad - Save Interactive Grid Data'
,p_attribute_01=>'REGION_SOURCE'
,p_attribute_05=>'Y'
,p_attribute_06=>'Y'
,p_attribute_08=>'Y'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>222832860369009920
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(222835819466009950)
,p_process_sequence=>90
,p_process_point=>'AFTER_SUBMIT'
,p_region_id=>wwv_flow_imp.id(222833948258009931)
,p_process_type=>'NATIVE_IG_DML'
,p_process_name=>'Incremento - Save Interactive Grid Data'
,p_attribute_01=>'REGION_SOURCE'
,p_attribute_05=>'Y'
,p_attribute_06=>'Y'
,p_attribute_08=>'Y'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(225042197372262426)
,p_only_for_changed_rows=>'N'
,p_internal_uid=>222835819466009950
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(225042624042262431)
,p_process_sequence=>100
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Calcula_INE'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'   V_VALOR  NUMBER  :=0;',
'   V_VALOR1  NUMBER  :=0;',
'BEGIN',
unistr('  -- Obtengo el valor o valores necesarios para calcular cada l\00EDnea'),
'  BEGIN',
'     SELECT N1 INTO V_VALOR',
'     FROM T_FINZ_CARGASMANUALES ',
'     WHERE TIPO=:P145_TIPOCARGA AND ANIO=:P145_ANIO AND MES=:P145_MES AND ESTADO=1 AND N4=1;',
'    EXCEPTION WHEN NO_DATA_FOUND THEN V_VALOR:=0;',
'    ',
'  END;',
'--calculo las lineas que dependen de los datos ingresados',
unistr('-- l\00EDnea 3'),
'',
'UPDATE T_FINZ_CARGASMANUALES',
'    SET N1=(SELECT V_VALOR-N1',
'            FROM T_FINZ_CARGASMANUALES ',
'            WHERE TIPO=:P145_TIPOCARGA AND ANIO=:P145_ANIO  AND MES=:P145_MES AND ESTADO=1 AND N4=2)',
'WHERE TIPO=:P145_TIPOCARGA AND ANIO=:P145_ANIO  AND MES=:P145_MES AND ESTADO=1  AND N4=3',
'AND EXISTS (SELECT ''X''',
'            FROM T_FINZ_CARGASMANUALES ',
'            WHERE TIPO=:P145_TIPOCARGA AND ANIO=:P145_ANIO AND MES=:P145_MES AND ESTADO=1  AND N4=2);',
'',
'--calculo las lineas que dependen de los datos ingresados',
unistr('-- l\00EDnea 5'),
'',
'UPDATE T_FINZ_CARGASMANUALES',
'    SET N1=(SELECT N1/V_VALOR',
'            FROM T_FINZ_CARGASMANUALES ',
'            WHERE TIPO=:P145_TIPOCARGA AND ANIO=:P145_ANIO AND MES=:P145_MES AND ESTADO=1 AND N4=4)',
'WHERE TIPO=:P145_TIPOCARGA AND ANIO=:P145_ANIO AND MES=:P145_MES AND ESTADO=1  AND N4=5',
'AND EXISTS (SELECT ''X''',
'            FROM T_FINZ_CARGASMANUALES ',
'            WHERE TIPO=:P145_TIPOCARGA AND ANIO=:P145_ANIO AND MES=:P145_MES AND ESTADO=1  AND N4=4);',
'',
'--calculo las lineas que dependen de los datos ingresados',
unistr('-- l\00EDnea 8'),
'',
unistr('  -- Obtengo el valor o valor de la l\00EDnea 6'),
'  BEGIN',
'     SELECT N1 INTO V_VALOR',
'     FROM T_FINZ_CARGASMANUALES ',
'     WHERE TIPO=:P145_TIPOCARGA AND ANIO=:P145_ANIO AND MES=:P145_MES AND ESTADO=1  AND N4=6;',
'    EXCEPTION WHEN NO_DATA_FOUND THEN V_VALOR:=0;',
'    ',
'  END;',
'',
' ',
' UPDATE T_FINZ_CARGASMANUALES',
'    SET N1=(SELECT CASE WHEN V_VALOR<N1 THEN 0 ELSE V_VALOR-N1 END VAL',
'            FROM T_FINZ_CARGASMANUALES ',
'            WHERE TIPO=:P145_TIPOCARGA AND ANIO=:P145_ANIO AND MES=:P145_MES AND ESTADO=1  AND N4=7)',
'WHERE TIPO=:P145_TIPOCARGA AND ANIO=:P145_ANIO AND MES=:P145_MES AND ESTADO=1  AND N4=8',
'AND EXISTS (SELECT ''X''',
'            FROM T_FINZ_CARGASMANUALES ',
'            WHERE TIPO=:P145_TIPOCARGA AND ANIO=:P145_ANIO AND MES=:P145_MES AND ESTADO=1  AND N4=7);',
' ',
'--calculo las lineas que dependen de los datos ingresados',
unistr('-- l\00EDnea 9'),
'',
unistr('-- Obtengo el valor o valor de la l\00EDnea 7'),
'  BEGIN',
'     SELECT N1 INTO V_VALOR1',
'     FROM T_FINZ_CARGASMANUALES ',
'     WHERE TIPO=:P145_TIPOCARGA AND ANIO=:P145_ANIO AND MES=:P145_MES AND ESTADO=1  AND N4=7;',
'    EXCEPTION WHEN NO_DATA_FOUND THEN V_VALOR:=0;',
'    ',
'  END;',
'',
'  IF V_VALOR>V_VALOR1 THEN',
'     NULL;',
'  END IF;',
'',
'--UPDATE T_FINZ_CARGASMANUALES SET ESTADO=1',
'--WHERE TIPO=:P145_TIPOCARGA AND ANIO=:P145_ANIO AND MES=:P145_MES AND ESTADO=1 ;',
'',
':P145_BANDERAINE:=1;',
'',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(225042197372262426)
,p_internal_uid=>225042624042262431
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(231046318057818810)
,p_process_sequence=>110
,p_process_point=>'AFTER_SUBMIT'
,p_region_id=>wwv_flow_imp.id(225043217624262437)
,p_process_type=>'NATIVE_IG_DML'
,p_process_name=>'Discapacidad - Save Interactive Grid Data'
,p_attribute_01=>'REGION_SOURCE'
,p_attribute_05=>'Y'
,p_attribute_06=>'Y'
,p_attribute_08=>'Y'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>231046318057818810
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(231046558911818812)
,p_process_sequence=>120
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Calcula_ECD'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'   V_VALOR  NUMBER :=0;',
'',
'BEGIN',
'',
unistr('-- borro las l\00EDneas que se calculan para el resumen '),
'DELETE FROM T_FINZ_CARGASMANUALES',
'WHERE TIPO=:P145_TIPOCARGA AND ANIO=:P145_ANIO AND ESTADO=1 AND VC2 IS NOT NULL;',
'',
'--',
'UPDATE T_FINZ_CARGASMANUALES',
'SET N3=FLOOR(N1*(N2/100)),N5=N4-FLOOR(N1*(N2/100))',
'WHERE TIPO=:P145_TIPOCARGA AND ANIO=:P145_ANIO AND ESTADO=1;',
'',
'-- ',
'UPDATE T_FINZ_CARGASMANUALES',
'SET N8 = ( CASE WHEN N5>0 THEN ROUND(((N6/N4)*N5)*(150/100),2) ELSE 0 END )',
'WHERE TIPO=:P145_TIPOCARGA AND ANIO=:P145_ANIO AND ESTADO=1;',
'',
'-- ',
'INSERT INTO T_FINZ_CARGASMANUALES(TIPO, ANIO, MES,N8,VC1,VC2,ESTADO,COMPANIA)',
'SELECT :P145_TIPOCARGA,:P145_ANIO,:P145_MES,SUM(N8),',
unistr('       ''Deducci\00F3n por empleados contratados con discapacidad o sus sustitutos calculada'',''SI'',1,:G_COMPANIA'),
'FROM T_FINZ_CARGASMANUALES',
'WHERE TIPO=:P145_TIPOCARGA AND ANIO=:P145_ANIO AND ESTADO=1 AND VC2 IS NULL;',
'',
'SELECT SUM(N8) INTO V_VALOR',
'FROM T_FINZ_CARGASMANUALES',
'WHERE TIPO=:P145_TIPOCARGA AND ANIO=:P145_ANIO AND ESTADO=1 AND VC2 IS NULL;',
'',
'INSERT INTO T_FINZ_CARGASMANUALES(TIPO, ANIO, MES,N8,VC1,VC2,ESTADO,COMPANIA)',
'SELECT :P145_TIPOCARGA,:P145_ANIO,:P145_MES,NVL(:P145_DEDUCCION,0),',
unistr('       ''Valor de la deducci\00F3n por empleados contratados con discapacidad o sus sustitutos declarada en el formulario de impuesto a la renta'',''SI'',1,:G_COMPANIA'),
'FROM DUAL;',
'',
'INSERT INTO T_FINZ_CARGASMANUALES(TIPO, ANIO, MES,N8,VC1,VC2,ESTADO,COMPANIA)',
'SELECT :P145_TIPOCARGA,:P145_ANIO,:P145_MES,V_VALOR-NVL(:P145_DEDUCCION,0),''Diferencia'',''SI'',1,:G_COMPANIA',
'FROM DUAL;',
'',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(231046440586818811)
,p_internal_uid=>231046558911818812
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(231926725722750419)
,p_process_sequence=>130
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Calcula_AMM'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'   V_VALOR  NUMBER :=0;',
'',
'BEGIN',
'',
unistr('-- borro las l\00EDneas que se calculan para el resumen '),
'DELETE FROM T_FINZ_CARGASMANUALES',
'WHERE COMPANIA=:G_COMPANIA AND TIPO=:P145_TIPOCARGA AND ANIO=:P145_ANIO AND MES=:P145_MES AND ESTADO=1 AND VC2 IS NOT NULL;',
'--',
'UPDATE T_FINZ_CARGASMANUALES',
'SET N5=N3+N4',
'WHERE COMPANIA=:G_COMPANIA AND TIPO=:P145_TIPOCARGA AND ANIO=:P145_ANIO AND MES=:P145_MES AND ESTADO=1;',
'',
'-- ',
'UPDATE T_FINZ_CARGASMANUALES',
'SET N8 = ROUND(NVL(N5,0)*(150/100),2)',
'WHERE COMPANIA=:G_COMPANIA AND TIPO=:P145_TIPOCARGA AND ANIO=:P145_ANIO AND MES=:P145_MES AND ESTADO=1;',
'',
'-- ',
'INSERT INTO T_FINZ_CARGASMANUALES(TIPO, ANIO, MES,N8,VC1,VC2,ESTADO,COMPANIA)',
'SELECT :P145_TIPOCARGA,:P145_ANIO,:P145_MES,SUM(N8),',
unistr('       ''Deducci\00F3n por el pago a empleados adultos mayores y migrantes retornados mayores a 40 a\00F1os calculada'',''SI'',1,:G_COMPANIA'),
'FROM T_FINZ_CARGASMANUALES',
'WHERE COMPANIA=:G_COMPANIA AND TIPO=:P145_TIPOCARGA AND ANIO=:P145_ANIO AND MES=:P145_MES AND ESTADO=1 AND VC2 IS NULL;',
'',
'SELECT SUM(N6) INTO V_VALOR',
'FROM T_FINZ_CARGASMANUALES',
'WHERE COMPANIA=:G_COMPANIA AND TIPO=:P145_TIPOCARGA AND ANIO=:P145_ANIO AND ESTADO=1 AND MES=:P145_MES AND VC2 IS NULL;',
'',
'INSERT INTO T_FINZ_CARGASMANUALES(TIPO, ANIO, MES,N8,VC1,VC2,ESTADO,COMPANIA)',
'SELECT :P145_TIPOCARGA,:P145_ANIO,:P145_MES,NVL(:P145_DEDUCCION,0),',
unistr('       ''Valor de la deducci\00F3n por empleados adultos mayores y migrantes retornados mayores a 40 a\00F1os declarada en el impuesto a la renta'',''SI'',1,'),
'       :G_COMPANIA',
'FROM DUAL;',
'',
'INSERT INTO T_FINZ_CARGASMANUALES(TIPO, ANIO, MES,N8,VC1,VC2,ESTADO,COMPANIA)',
'SELECT :P145_TIPOCARGA,:P145_ANIO,:P145_MES,V_VALOR-NVL(:P145_DEDUCCIONAMM,0),',
'       ''Diferencia'',''SI'',1,:G_COMPANIA',
'FROM DUAL;',
'',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(231926847260750420)
,p_internal_uid=>231926725722750419
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(231926609353750418)
,p_process_sequence=>140
,p_process_point=>'AFTER_SUBMIT'
,p_region_id=>wwv_flow_imp.id(231049887634818845)
,p_process_type=>'NATIVE_IG_DML'
,p_process_name=>'Mayores_Migrantes - Save Interactive Grid Data'
,p_attribute_01=>'REGION_SOURCE'
,p_attribute_05=>'Y'
,p_attribute_06=>'Y'
,p_attribute_08=>'Y'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>231926609353750418
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(254937515721743714)
,p_process_sequence=>150
,p_process_point=>'AFTER_SUBMIT'
,p_region_id=>wwv_flow_imp.id(254257933762609437)
,p_process_type=>'NATIVE_IG_DML'
,p_process_name=>'Desahucio - Save Interactive Grid Data'
,p_attribute_01=>'REGION_SOURCE'
,p_attribute_05=>'Y'
,p_attribute_06=>'Y'
,p_attribute_08=>'Y'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(254257498793609432)
,p_only_for_changed_rows=>'N'
,p_internal_uid=>254937515721743714
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(254937641546743715)
,p_process_sequence=>160
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Calcula_DJP'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'-- borro registros que se calculan',
'DELETE FROM T_FINZ_CARGASMANUALES',
'WHERE COMPANIA=:G_COMPANIA AND TIPO=:P145_TIPOCARGA AND ANIO=:P145_ANIO AND MES=:P145_MES ',
'AND (N8>6 AND N8<>835) AND ESTADO=1;',
'',
'',
'INSERT INTO T_FINZ_CARGASMANUALES (TIPO,ANIO,MES,VC1,VC2,VC3,N1,N7,N8,ESTADO,COMPANIA)',
unistr('SELECT :P145_TIPOCARGA,:P145_ANIO,:P145_MES,'''',''Generaci\00F3n Prov. desahucio/jub.patronal'','''',SUM(N1),1,7,1,:G_COMPANIA'),
'FROM T_FINZ_CARGASMANUALES',
'WHERE COMPANIA=:G_COMPANIA AND TIPO=:P145_TIPOCARGA AND ANIO=:P145_ANIO AND MES=:P145_MES AND ESTADO=1;',
'-- 816',
'INSERT INTO T_FINZ_CARGASMANUALES (TIPO,ANIO,MES,VC1,VC2,VC3,N1,N7,N8,ESTADO,COMPANIA)',
unistr('SELECT :P145_TIPOCARGA,:P145_ANIO,:P145_MES,''Generaci\00F3n Prov. desahucio/jub.patronal'','''','''',(SUM(N1)/12)*:P145_MES,1,816,1,:G_COMPANIA'),
'FROM T_FINZ_CARGASMANUALES',
'WHERE COMPANIA=:G_COMPANIA AND TIPO=:P145_TIPOCARGA AND ANIO=:P145_ANIO AND MES=:P145_MES AND N8 IN (1,4) AND ESTADO=1;',
'-- 817',
'INSERT INTO T_FINZ_CARGASMANUALES (TIPO,ANIO,MES,VC1,VC2,VC3,N1,N7,N8,ESTADO,COMPANIA)',
unistr('SELECT :P145_TIPOCARGA,:P145_ANIO,:P145_MES,''Reversi\00F3n Prov. desahucio/jub.patronal'','''','''',(SUM(N1)/12)*:P145_MES,1,817,1,:G_COMPANIA'),
'FROM T_FINZ_CARGASMANUALES',
'WHERE COMPANIA=:G_COMPANIA AND TIPO=:P145_TIPOCARGA AND ANIO=:P145_ANIO AND MES=:P145_MES AND N8 IN (2,3,5,6) AND ESTADO=1;',
'-- 835',
'--INSERT INTO T_FINZ_CARGASMANUALES (TIPO,ANIO,VC1,VC2,VC3,N1,N7,N8,ESTADO)',
unistr('--SELECT :P145_TIPOCARGA,:P145_ANIO,''Reversi\00F3n Prov. desahucio/jub.patronal'','''','''',(SUM(N1)/12)*:P145_MES,1,816,1 '),
'--FROM T_FINZ_CARGASMANUALES',
'--WHERE TIPO=:P145_TIPOCARGA AND ANIO=:P145_ANIO AND N8 IN (2,3,5,6);',
'',
':P145_BANDERADJP:=1;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(254257498793609432)
,p_internal_uid=>254937641546743715
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(263194324966745848)
,p_process_sequence=>170
,p_process_point=>'AFTER_SUBMIT'
,p_region_id=>wwv_flow_imp.id(263189808606745803)
,p_process_type=>'NATIVE_IG_DML'
,p_process_name=>unistr('Reducci\00F3n2 - Save Interactive Grid Data')
,p_attribute_01=>'REGION_SOURCE'
,p_attribute_05=>'Y'
,p_attribute_06=>'Y'
,p_attribute_08=>'Y'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>263194324966745848
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(269630030121797422)
,p_process_sequence=>180
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Calcula_RTIR'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'   V_ANIO  NUMBER :=0;',
'   V_VALORINVERSION NUMBER :=0;',
'   V_PORCENTAJE  NUMBER :=0;',
'',
'BEGIN',
'    -- borro registros anteriores',
'    DELETE FROM T_FINZ_CARGASMANUALES',
'    WHERE TIPO=:P145_TIPOCARGA AND ANIO=:P145_ANIO AND MES=:P145_MES AND ESTADO=1 AND COMPANIA=:G_COMPANIA AND VC2=''SI'';',
'    ',
unistr('    -- obtengo el total de los activos fijos que se ingresan por la aplicaci\00F3n'),
'    INSERT INTO T_FINZ_CARGASMANUALES(TIPO, ANIO, MES,VC1,VC2,ESTADO,N1,N8,DT3,COMPANIA)',
unistr('    SELECT :P145_TIPOCARGA,:P145_ANIO, :P145_MES, ''Detalle de Inversi\00F3n'',''SI'',1, '),
'            SUM(NVL(N2,0)+NVL(N3,0)+NVL(N4,0)+NVL(N5,0)+NVL(N6,0)+NVL(N7,0)+NVL(N8,0))',
'            ,1,SYSDATE,:G_COMPANIA',
'    FROM T_FINZ_CARGASMANUALES',
'    WHERE TIPO=:P145_TIPOCARGA AND ANIO=:P145_ANIO AND MES=:P145_MES AND ESTADO=1 AND COMPANIA=:G_COMPANIA;',
'',
'    V_ANIO:=:P145_ANIO-2000;',
'    -- obtengo el valor de lo activos fijos',
'    -- las cuentas tomo de la tabla general FINZ_GGEST - ID_TABLA=''ACTFIJ''',
'    /*INSERT INTO T_FINZ_CARGASMANUALES(TIPO, ANIO, MES,VC1,VC2,ESTADO,N1,N8,COMPANIA)',
'    SELECT :P145_TIPOCARGA,:P145_ANIO, :P145_MES, ''Total Activos Fijos Brutos'',''SI'',1, SUM(GLAA/100),2,:G_COMPANIA',
'    FROM F0911@JDEDTADL X',
'    WHERE GLLT = ''AA'' AND GLCTRY = 20 --AND GLFY<= V_ANIO AND GLPN  <= :P145_MES  ',
'    AND GLCO = ''00001''',
'    AND GLAID IN (SELECT GMAID',
'                  FROM F0901@JDEDTADL ',
'                  WHERE GMSUB != ''        ''              ',
'                  AND EXISTS (SELECT ''X''',
'                              FROM T_CORP_UDC',
'                              WHERE ID_CABECERA=''FINZ_GGEST'' AND ID_TABLA=''ACTFIJ'' AND ACTIVO=1',
'                              AND LPAD(VALOR,12,'' '')=GMMCU AND RPAD(VALOR2,6,'' '')=GMOBJ AND RPAD(VALOR3,8,'' '')=GMSUB));',
'    */',
'    INSERT INTO T_FINZ_CARGASMANUALES(TIPO, ANIO, MES,VC1,VC2,ESTADO,N8,DT3,COMPANIA,N1)',
'    SELECT :P145_TIPOCARGA,:P145_ANIO, :P145_MES, ''Total Activos Fijos Brutos'',''SI'',1, 2,SYSDATE,:G_COMPANIA,',
'    sum(gbapyc)/100 + case',
'    when :P145_MES =  1 then',
'        sum(gban01)/100',
'    when :P145_MES =  2 then',
'        sum(gban01 + gban02)/100',
'    when :P145_MES =  3 then',
'        sum(gban01 + gban02 + gban03)/100',
'    when :P145_MES =  4 then',
'        sum(gban01 + gban02 + gban03 + gban04)/100',
'    when :P145_MES =  5 then',
'        sum(gban01 + gban02 + gban03 + gban04 + gban05)/100',
'    when :P145_MES =  6 then',
'        sum(gban01 + gban02 + gban03 + gban04 + gban05 + gban06)/100',
'    when :P145_MES =  7 then',
'        sum(gban01 + gban02 + gban03 + gban04 + gban05 + gban06 + gban07)/100',
'    when :P145_MES =  8 then',
'        sum(gban01 + gban02 + gban03 + gban04 + gban05 + gban06 + gban07 + gban08)/100',
'    when :P145_MES =  9 then',
'        sum(gban01 + gban02 + gban03 + gban04 + gban05 + gban06 + gban07 + gban08 + gban09)/100',
'    when :P145_MES = 10 then',
'        sum(gban01 + gban02 + gban03 + gban04 + gban05 + gban06 + gban07 + gban08 + gban09 + gban10)/100',
'    when :P145_MES = 11 then',
'        sum(gban01 + gban02 + gban03 + gban04 + gban05 + gban06 + gban07 + gban08 + gban09 + gban10 + gban11)/100',
'    when :P145_MES = 12 then',
'        sum(gban01 + gban02 + gban03 + gban04 + gban05 + gban06 + gban07 + gban08 + gban09 + gban10 + gban11 + gban12)/100',
'    else 0 end valor',
'from f0902@jdedtadl',
'where 1 = 1',
'    and gbco = :G_COMPANIA and gbmcu = gbmcu and gblt = ''AA'' and gbsbl = gbsbl and gbsblt = gbsblt and gbctry = 20 and gbfy = :P145_ANIO-2000',
'    and gbaid ',
'    IN (SELECT GMAID',
'              FROM F0901@JDEDTADL ',
'              WHERE GMSUB != ''        ''              ',
'              AND EXISTS (SELECT *--''X''',
'                          FROM T_CORP_UDC',
'                          WHERE ID_CABECERA=''FINZ_GGEST'' AND ID_TABLA=''ACTFIJ'' AND ACTIVO=1',
'                          AND LPAD(VALOR,12,'' '')=GMMCU AND RPAD(VALOR2,6,'' '')=GMOBJ AND RPAD(VALOR3,8,'' '')=GMSUB));',
'',
'',
'    -- recupero el porcentaje para el calculo, tomo de la tabla general FINZ_GGEST - ID_TABLA=''POR'' DESCRIPCION2=''IMPUESTO_RENTA''',
'    INSERT INTO T_FINZ_CARGASMANUALES(TIPO, ANIO, MES,VC1,VC2,ESTADO,N1,N8,DT3,COMPANIA)',
'    SELECT :P145_TIPOCARGA,:P145_ANIO, :P145_MES, ''Porcentaje'',''SI'',1, (VALOR/100),3,SYSDATE,:G_COMPANIA',
'    FROM T_CORP_UDC',
'    WHERE ID_CABECERA=''FINZ_GGEST'' AND ID_TABLA=''POR'' AND DESCRIPCION2=''IMPUESTO_RENTA'' AND ACTIVO=1;',
'',
unistr('    -- recupero el valor de la inversi\00F3n'),
'    SELECT SUM(N1) INTO V_VALORINVERSION',
'    FROM T_FINZ_CARGASMANUALES',
'    WHERE TIPO=:P145_TIPOCARGA AND ANIO=:P145_ANIO AND MES=:P145_MES AND ESTADO=1 AND COMPANIA=:G_COMPANIA AND VC2=''SI'' AND N8=1;',
'',
unistr('    -- recupero porcentaje para el c\00E1lculo'),
'    SELECT N1 INTO V_PORCENTAJE',
'    FROM T_FINZ_CARGASMANUALES',
'    WHERE TIPO=:P145_TIPOCARGA AND ANIO=:P145_ANIO AND MES=:P145_MES AND ESTADO=1 AND COMPANIA=:G_COMPANIA AND VC2=''SI'' AND N8=3;',
'    ',
unistr('    -- calculo el porcentaje de reducci\00F3n'),
'    ',
'    INSERT INTO T_FINZ_CARGASMANUALES(TIPO, ANIO, MES,VC1,VC2,ESTADO,N1,N8,DT3,COMPANIA)',
unistr('    SELECT :P145_TIPOCARGA,:P145_ANIO, :P145_MES, ''Porcentaje Reducci\00F3n'',''SI'',1,(V_VALORINVERSION/N1)*V_PORCENTAJE'),
'    ,4,SYSDATE,:G_COMPANIA',
'    FROM T_FINZ_CARGASMANUALES',
'    WHERE TIPO=:P145_TIPOCARGA AND ANIO=:P145_ANIO AND MES=:P145_MES AND ESTADO=1 AND COMPANIA=:G_COMPANIA AND VC2=''SI'' AND N8=2;',
'    ',
'',
'END;',
''))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(263189663253745801)
,p_process_when=>'P145_TIPOCARGA'
,p_process_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_process_when2=>'RTIR'
,p_internal_uid=>269630030121797422
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(413248796698452612)
,p_process_sequence=>190
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'MARCAS'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'--',
unistr('-- busco  todas la facturas del a\00F1o y mes ingresados'),
'-- tomo de la tabla F1202:  MCU<>''11000'' LT=AA',
unistr('-- verifico que a\00F1o tenga un valor'),
'',
'DECLARE',
'   ',
'  V_PORCREGALIAS NUMBER :=0;',
'  V_TOTALREGALIAS  NUMBER :=0;',
'',
'BEGIN',
'	commit;',
'	set transaction read write;',
'',
'    IF :P145_ANIO IS NOT NULL AND :P145_MES IS NOT NULL THEN',
'       ',
'        -- borro calculos anteriores en estado=1',
'        DELETE FROM T_FINZ_CARGASMANUALES',
'        WHERE TIPO=:P145_TIPOCARGA AND ANIO=:P145_ANIO AND MES=:P145_MES AND ESTADO=1;',
'',
'        -- inserto los datos para marcas',
'        INSERT INTO T_FINZ_CARGASMANUALES (TIPO,ANIO,MES,VC1,N1,N2,ESTADO,COMPANIA)',
'        SELECT :P145_TIPOCARGA,:P145_ANIO,:P145_MES,MAX(DESCRIPCION),SUM(ACAVLR),MAX(VALOR2),1,:G_COMPANIA',
'        FROM T_CORP_UDC y, V_ACA@ETLDL',
'        WHERE Y.ID_CABECERA=''FINZ_GGEST'' AND Y.ID_TABLA=''MARCAS'' AND Y.ACTIVO=1 ',
'        AND ACAYAR = :P145_ANIO AND ACAMES = :P145_MES AND ACALVL1 = 10 AND ACALVL2 <= 30 AND ACAMRK=VALOR',
'        GROUP BY ACAMRK;',
'        ',
'        -- si la MARCA no tiene ventas en el mes genero un registro con CERO en N1 para que no se pierda y sea  ',
'        -- posible acumular',
'',
'        -- inserto los datos para marcas',
'        INSERT INTO T_FINZ_CARGASMANUALES (TIPO,ANIO,MES,VC1,N1,N2,ESTADO,COMPANIA)',
'        SELECT :P145_TIPOCARGA,:P145_ANIO,:P145_MES,(DESCRIPCION),0,(VALOR2),1,:G_COMPANIA        ',
'        FROM T_CORP_UDC Y',
'        WHERE Y.ID_CABECERA=''FINZ_GGEST'' AND Y.ID_TABLA=''MARCAS'' AND Y.ACTIVO=1         ',
'        AND NOT EXISTS (SELECT ''X''',
'                        FROM  V_ACA@ETLDL',
'                        WHERE ACAYAR = :P145_ANIO AND ACAMES = :P145_MES AND ACALVL1 = 10 AND ACALVL2 <= 30 AND ACAMRK=VALOR);        ',
'        -- actualizo los porcentajes para RETENCION en N3 e ISD en N4',
'        UPDATE T_FINZ_CARGASMANUALES',
'          SET (N3,N4)=(SELECT X.VALOR,Y.VALOR',
'                       FROM T_CORP_UDC X, T_CORP_UDC Y',
'                       WHERE X.ID_CABECERA=''FINZ_GGEST'' AND X.ID_TABLA=''POR'' AND X.DESCRIPCION2=''RETENCION'' AND X.ACTIVO=1',
'                       AND Y.ID_CABECERA=''FINZ_GGEST'' AND Y.ID_TABLA=''POR'' AND Y.DESCRIPCION2=''ISD'' AND Y.ACTIVO=1)',
'        WHERE TIPO=:P145_TIPOCARGA AND ANIO=:P145_ANIO AND MES=:P145_MES AND ESTADO=1',
'        AND EXISTS (SELECT X.VALOR,Y.VALOR',
'                       FROM T_CORP_UDC X, T_CORP_UDC Y ',
'                       WHERE X.ID_CABECERA=''FINZ_GGEST'' AND X.ID_TABLA=''POR'' AND X.DESCRIPCION2=''RETENCION'' AND X.ACTIVO=1',
'                       AND Y.ID_CABECERA=''FINZ_GGEST'' AND Y.ID_TABLA=''POR'' AND Y.DESCRIPCION2=''ISD'' AND Y.ACTIVO=1);',
'',
'        -- en N5 acumulo por marca',
'',
'        UPDATE T_FINZ_CARGASMANUALES X',
'          SET (N5)=(SELECT SUM(N1)',
'                    FROM T_FINZ_CARGASMANUALES Y',
'                    WHERE Y.TIPO=:P145_TIPOCARGA AND Y.ANIO=:P145_ANIO AND Y.MES<=:P145_MES AND Y.VC1=X.VC1',
'             --       AND Y.TIPO=X.TIPO AND Y.ANIO=X.ANIO AND Y.MES=X.MES',
'             )',
'        WHERE TIPO=:P145_TIPOCARGA AND ANIO=:P145_ANIO AND MES=:P145_MES AND ESTADO=1',
'        AND EXISTS (SELECT ''X''',
'                    FROM T_FINZ_CARGASMANUALES Y',
'                    WHERE Y.TIPO=:P145_TIPOCARGA AND Y.ANIO=:P145_ANIO AND Y.MES<=:P145_MES AND Y.VC1=X.VC1',
'             --       AND Y.TIPO=X.TIPO AND Y.ANIO=X.ANIO AND Y.MES=X.MES',
'             );',
'',
unistr('        -- en N6 calculo las regal\00EDas sin descuento'),
'        UPDATE T_FINZ_CARGASMANUALES X',
'          SET N6 = (SELECT N5*(N2/100)',
'                    FROM T_FINZ_CARGASMANUALES Y',
'                    WHERE Y.TIPO=:P145_TIPOCARGA AND Y.ANIO=:P145_ANIO AND Y.MES=:P145_MES AND Y.VC1=X.VC1)',
'        WHERE TIPO=:P145_TIPOCARGA AND ANIO=:P145_ANIO AND MES=:P145_MES AND ESTADO=1',
'        AND EXISTS (SELECT ''X''',
'                    FROM T_FINZ_CARGASMANUALES Y',
'                    WHERE Y.TIPO=:P145_TIPOCARGA AND Y.ANIO=:P145_ANIO AND Y.MES=:P145_MES AND Y.VC1=X.VC1);',
unistr('        -- en N7 calculo el descuento regal\00EDas'),
unistr('        -- obtengo porcentage de regal\00EDas'),
'        BEGIN',
'           SELECT VALOR/100 INTO V_PORCREGALIAS',
'           FROM T_CORP_UDC ',
'           WHERE ID_CABECERA=''FINZ_GGEST'' AND ID_TABLA=''POR'' AND DESCRIPCION2=''REGALIAS_MARCAS'' AND ACTIVO=1;',
'          EXCEPTION WHEN NO_DATA_FOUND THEN V_PORCREGALIAS:=0;',
'',
'        END;',
'',
'        -- Obtnego el total de las regalias sin descuento',
'        BEGIN',
'            SELECT SUM(N5) INTO V_TOTALREGALIAS',
'            FROM T_FINZ_CARGASMANUALES',
'            WHERE TIPO=:P145_TIPOCARGA AND ANIO=:P145_ANIO AND MES=:P145_MES;',
'          EXCEPTION WHEN NO_DATA_FOUND THEN V_TOTALREGALIAS:=0;',
'        END;',
'',
'        UPDATE T_FINZ_CARGASMANUALES',
'         SET N7= (N5/V_TOTALREGALIAS)*N2--V_PORCREGALIAS',
'        WHERE TIPO=:P145_TIPOCARGA AND ANIO=:P145_ANIO AND MES=:P145_MES AND ESTADO=1;',
'        -- en N8 calculo regalias',
'        UPDATE T_FINZ_CARGASMANUALES',
'         SET N8= N7+N6',
'        WHERE TIPO=:P145_TIPOCARGA AND ANIO=:P145_ANIO AND MES=:P145_MES AND ESTADO=1;',
'',
'        -- calculo el valor del ISD',
'        UPDATE T_FINZ_CARGASMANUALES',
'         SET N4= N8*(N4/100)',
'        WHERE TIPO=:P145_TIPOCARGA AND ANIO=:P145_ANIO AND MES=:P145_MES AND ESTADO=1;',
'              ',
'      ELSE',
unistr('         raise_application_error (-20001,''A\00D1O, MES deben tener alg\00FAn valor'');'),
'    END IF;',
'    ',
'',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(218460475000766607)
,p_process_when=>'P145_TIPOCARGA'
,p_process_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_process_when2=>'MA'
,p_internal_uid=>413248796698452612
);
wwv_flow_imp.component_end;
end;
/
