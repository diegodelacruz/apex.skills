prompt --application/pages/page_02016
begin
--   Manifest
--     PAGE: 02016
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>109
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_page.create_page(
 p_id=>2016
,p_name=>'Descuentos Promocionales'
,p_alias=>'DESCUENTOS-PROMOCIONALES'
,p_step_title=>'Descuentos Promocionales'
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_page_component_map=>'18'
,p_created_on=>wwv_flow_imp.dz('20240618133148Z')
,p_last_updated_on=>wwv_flow_imp.dz('20240708204842Z')
,p_last_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(213221583472815803)
,p_plug_name=>'Barra de Acciones'
,p_region_template_options=>'#DEFAULT#:t-Form--stretchInputs'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(38289497777120142)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(37761271469106475)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(37860983999106559)
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(213221750805815805)
,p_plug_name=>'Filtros'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(38289867500120143)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(213223909929815827)
,p_plug_name=>'Consulta'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(37806762584106520)
,p_plug_display_sequence=>30
,p_include_in_reg_disp_sel_yn=>'Y'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'with wmar as (--MARCA',
'    select drsy,drrt,trim(drky)drky,drdl01,drdl02,drsphd from vt_jde_udcjde e where e.drsy = ''41'' and e.drrt = ''S1''',
'), wlng as (--LINEA NEGOCIO',
'	select drsy,drrt,trim(drky)drky,drdl01,drdl02,drsphd from vt_jde_udcjde c where c.drsy = ''41'' and c.drrt = ''S4''',
'), wcan as(--CANAL',
'    select drsy,drrt,trim(drky)drky,drdl01,drdl02,drsphd from  vt_jde_udcjde f where f.drsy = ''01'' and f.drrt = ''02''',
'), wprd as (--PRODUCTO',
'    select distinct codigoproducto,lineanegocio,marca,codmarca,codlinea from  data.vt_jde_productos',
'), wcli as (--CLIENTE',
'    select distinct codigo, canalalterno,codigopais,nombres from data.vt_jde_cliente',
') select gmr041 nivel_1',
'	, gmr042 nivel_2',
'	, glfy+2000 anio',
'	, glpn mes ',
'	, case when gldgj > 0 then to_date(gldgj + 1900000, ''yyyyddd'') else null end fecha_lm',
'	, glpo orden_compra',
'	, gldct tipo_doc',
'	, gldoc num_documento',
'	, glicu num_bacth',
'	, glan8 num_direccion',
'	, glmcu un',
'	, globj cta_objeto',
'	, glsub cta_auxiliar',
'	, glani num_cta',
'	, gllt tp_ln',
'	, glaa/100  importe',
'	, gmdl01 descripcion_cta1',
'	, glexa descripcion_cta2',
'	, glexr explicacion_observacion',
'	, glsbl lm_auxiliar',
'	, glabt1 ta1',
'	, nvl(trim(glabr1),codmarca) codmarca,nvl(trim(e.drdl01),marca) marca',
'	, glabt2 ta2',
'	, nvl(trim(glabr2),glan8) cliente,nombres descripcion_cliente',
'	, codigopais codpais',
'	, glabt3 ta3',
'	, nvl(trim(glabr3),codlinea) codlineanegocio,nvl(trim(c.drdl01),lineanegocio) lineanegocio',
'	, glabt4 ta4',
'	, decode (nvl(trim(glabr4),''999''),''999'',canalalterno,trim(glabr4))codcanal,f.drdl01 canal',
'	, glre ra',
'	, gltorg indicador_transaccion',
'	, glr1 referencia1',
'	, glr2 referencia2',
'	, gldcto tipo_ord',
'	, rprmr1 detalle_descuento',
'from f0911@jdedtadl a',
'inner join f0901@jdedtadl b on glaid = gmaid',
'left join wmar e on trim(glabr1) = (e.drky)',
'left join wlng c on trim(glabr3) = (c.drky)',
'left join wcli d on (nvl(trim(glabr2),glan8) = codigo)',
'left join wprd e on trim(glexr)= trim(codigoproducto)',
'left join wcan f on ((nvl(trim(glabr4),''999'') = ''999'' and trim(canalalterno) = (f.drky)) or (trim(glabr4) != ''999'' and trim(glabr4) = f.drky))',
'left join f03b11@jdedtadl on glkco = rpkco and gldct = rpdct and gldoc = rpdoc and glicu = rpicu and rprmr1 != ''                                                  ''',
'where 1 = 1',
'	and gmr041 = ''10''',
'	and gmr042 in (''20'',''52'',''53'',''54'',''55'',''56'',''57'',''58'',''59'')',
'	and glfy = (:p2016_anio - 2000)',
'	and glpn = :p2016_mes'))
,p_plug_source_type=>'NATIVE_IR'
,p_ajax_items_to_submit=>'P2016_ANIO,P2016_MES'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'Consulta'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
,p_updated_on=>wwv_flow_imp.dz('20240708204842Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(213224032108815828)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'EMASABANDA'
,p_internal_uid=>213224032108815828
,p_updated_on=>wwv_flow_imp.dz('20240708204842Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(213224108983815829)
,p_db_column_name=>'ANIO'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Anio'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(213224226101815830)
,p_db_column_name=>'MES'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Mes'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(213224363953815831)
,p_db_column_name=>'FECHA_LM'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Fecha Lm'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(213224495591815832)
,p_db_column_name=>'ORDEN_COMPRA'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Orden Compra'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(213224528758815833)
,p_db_column_name=>'TIPO_DOC'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Tipo Doc'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(213224658554815834)
,p_db_column_name=>'NUM_DOCUMENTO'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'Num Documento'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(213224712927815835)
,p_db_column_name=>'NUM_BACTH'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>'Num Bacth'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(213224868611815836)
,p_db_column_name=>'NUM_DIRECCION'
,p_display_order=>80
,p_column_identifier=>'H'
,p_column_label=>'Num Direccion'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(213224964845815837)
,p_db_column_name=>'UN'
,p_display_order=>90
,p_column_identifier=>'I'
,p_column_label=>'Un'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(213225064499815838)
,p_db_column_name=>'CTA_OBJETO'
,p_display_order=>100
,p_column_identifier=>'J'
,p_column_label=>'Cta Objeto'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(213225160381815839)
,p_db_column_name=>'CTA_AUXILIAR'
,p_display_order=>110
,p_column_identifier=>'K'
,p_column_label=>'Cta Auxiliar'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(213225277038815840)
,p_db_column_name=>'NUM_CTA'
,p_display_order=>120
,p_column_identifier=>'L'
,p_column_label=>'Num Cta'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(213225399499815841)
,p_db_column_name=>'TP_LN'
,p_display_order=>130
,p_column_identifier=>'M'
,p_column_label=>'Tp Ln'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(213225405679815842)
,p_db_column_name=>'IMPORTE'
,p_display_order=>140
,p_column_identifier=>'N'
,p_column_label=>'Importe'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(213225596110815843)
,p_db_column_name=>'DESCRIPCION_CTA1'
,p_display_order=>150
,p_column_identifier=>'O'
,p_column_label=>'Descripcion Cta1'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(213225610931815844)
,p_db_column_name=>'DESCRIPCION_CTA2'
,p_display_order=>160
,p_column_identifier=>'P'
,p_column_label=>unistr('Nombre Alpha Explicac\00F3n')
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(213225774069815845)
,p_db_column_name=>'EXPLICACION_OBSERVACION'
,p_display_order=>170
,p_column_identifier=>'Q'
,p_column_label=>'Explicacion Observacion'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(213225856133815846)
,p_db_column_name=>'LM_AUXILIAR'
,p_display_order=>180
,p_column_identifier=>'R'
,p_column_label=>'Lm Auxiliar'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(213225983684815847)
,p_db_column_name=>'TA1'
,p_display_order=>190
,p_column_identifier=>'S'
,p_column_label=>'Ta1'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(213226058138815848)
,p_db_column_name=>'CODMARCA'
,p_display_order=>200
,p_column_identifier=>'T'
,p_column_label=>'Codmarca'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(213226140625815849)
,p_db_column_name=>'MARCA'
,p_display_order=>210
,p_column_identifier=>'U'
,p_column_label=>'Marca'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(213226299509815850)
,p_db_column_name=>'TA2'
,p_display_order=>220
,p_column_identifier=>'V'
,p_column_label=>'Ta2'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(214619222234516101)
,p_db_column_name=>'CLIENTE'
,p_display_order=>230
,p_column_identifier=>'W'
,p_column_label=>'Cliente'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(214619329790516102)
,p_db_column_name=>'DESCRIPCION_CLIENTE'
,p_display_order=>240
,p_column_identifier=>'X'
,p_column_label=>'Descripcion Cliente'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(214619436136516103)
,p_db_column_name=>'CODPAIS'
,p_display_order=>250
,p_column_identifier=>'Y'
,p_column_label=>'Codpais'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(214619501095516104)
,p_db_column_name=>'TA3'
,p_display_order=>260
,p_column_identifier=>'Z'
,p_column_label=>'Ta3'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(214619625769516105)
,p_db_column_name=>'CODLINEANEGOCIO'
,p_display_order=>270
,p_column_identifier=>'AA'
,p_column_label=>'Codlineanegocio'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(214619740454516106)
,p_db_column_name=>'LINEANEGOCIO'
,p_display_order=>280
,p_column_identifier=>'AB'
,p_column_label=>'Lineanegocio'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(214619877536516107)
,p_db_column_name=>'TA4'
,p_display_order=>290
,p_column_identifier=>'AC'
,p_column_label=>'Ta4'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(214619975359516108)
,p_db_column_name=>'CODCANAL'
,p_display_order=>300
,p_column_identifier=>'AD'
,p_column_label=>'Codcanal'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(214620024702516109)
,p_db_column_name=>'CANAL'
,p_display_order=>310
,p_column_identifier=>'AE'
,p_column_label=>'Canal'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(214620151720516110)
,p_db_column_name=>'RA'
,p_display_order=>320
,p_column_identifier=>'AF'
,p_column_label=>'Ra'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(214620262300516111)
,p_db_column_name=>'INDICADOR_TRANSACCION'
,p_display_order=>330
,p_column_identifier=>'AG'
,p_column_label=>'Indicador Transaccion'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(214620313123516112)
,p_db_column_name=>'REFERENCIA1'
,p_display_order=>340
,p_column_identifier=>'AH'
,p_column_label=>'Referencia1'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(214620411043516113)
,p_db_column_name=>'REFERENCIA2'
,p_display_order=>350
,p_column_identifier=>'AI'
,p_column_label=>'Referencia2'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(214620519352516114)
,p_db_column_name=>'TIPO_ORD'
,p_display_order=>360
,p_column_identifier=>'AJ'
,p_column_label=>'Tipo Ord'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(214620637699516115)
,p_db_column_name=>'NIVEL_1'
,p_display_order=>370
,p_column_identifier=>'AK'
,p_column_label=>'Nivel 1'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(214620788662516116)
,p_db_column_name=>'NIVEL_2'
,p_display_order=>380
,p_column_identifier=>'AL'
,p_column_label=>'Nivel 2'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(371020405853652413)
,p_db_column_name=>'DETALLE_DESCUENTO'
,p_display_order=>390
,p_column_identifier=>'AM'
,p_column_label=>'Detalle Descuento'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20240705215534Z')
,p_updated_on=>wwv_flow_imp.dz('20240705215534Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(214635645063520440)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'2146357'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'NIVEL_1:NIVEL_2:ANIO:MES:FECHA_LM:ORDEN_COMPRA:TIPO_DOC:NUM_DOCUMENTO:NUM_BACTH:NUM_DIRECCION:UN:CTA_OBJETO:CTA_AUXILIAR:NUM_CTA:TP_LN:IMPORTE:DESCRIPCION_CTA1:DESCRIPCION_CTA2:EXPLICACION_OBSERVACION:LM_AUXILIAR:TA1:CODMARCA:MARCA:TA2:CLIENTE:DESCRI'
||'PCION_CLIENTE:CODPAIS:TA3:CODLINEANEGOCIO:LINEANEGOCIO:TA4:CODCANAL:CANAL:RA:INDICADOR_TRANSACCION:REFERENCIA1:REFERENCIA2:TIPO_ORD:DETALLE_DESCUENTO:'
,p_created_on=>wwv_flow_imp.dz('20240618133148Z')
,p_updated_on=>wwv_flow_imp.dz('20240705215719Z')
,p_created_by=>'EMASABANDA'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(213221695702815804)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(213221583472815803)
,p_button_name=>'Buscar'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860056812106557)
,p_button_image_alt=>'Buscar'
,p_button_alignment=>'RIGHT'
,p_icon_css_classes=>'fa-search'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(213221933266815807)
,p_name=>'P2016_ANIO'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(213221750805815805)
,p_prompt=>unistr('A\00D1o')
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT year D, year R FROM (select',
'to_char(sysdate, ''yyyy'') - (select trunc(months_between (sysdate,  trunc(ADD_MONTHS(SYSDATE, -4 * 12),''YEAR''))/12)+1 anios  from dual) + level year',
'from',
'dual',
'connect by',
'level <= (select trunc(months_between (sysdate, trunc(ADD_MONTHS(SYSDATE, -4 * 12),''YEAR'')  )/12)+1 anios  from dual)  ',
')   A',
'',
'ORDER BY 2 DESC;'))
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(213222066674815808)
,p_name=>'P2016_MES'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(213221750805815805)
,p_prompt=>'Mes'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT',
'    to_char(to_date(level, ''MM''), ''Month'') d,',
'    level                                  r',
'FROM',
'    dual',
'CONNECT BY',
'    level <= (CASE WHEN :P2016_ANIO = to_char(to_date(sysdate), ''YYYY'') THEN to_number(to_char(to_date(sysdate), ''MM'')) ELSE 12 END)',
'    ORDER BY 2 DESC',
'    ;'))
,p_lov_cascade_parent_items=>'P2016_ANIO'
,p_ajax_items_to_submit=>'P2016_ANIO'
,p_ajax_optimize_refresh=>'Y'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'NONE'
);
wwv_flow_imp.component_end;
end;
/
