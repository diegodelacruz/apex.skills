prompt --application/pages/page_00118
begin
--   Manifest
--     PAGE: 00118
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>109
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_page.create_page(
 p_id=>118
,p_name=>'Ajuste de Inventario'
,p_step_title=>'Ajuste de Inventario'
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_page_component_map=>'18'
,p_created_on=>wwv_flow_imp.dz('20230705164634Z')
,p_last_updated_on=>wwv_flow_imp.dz('20230216192513Z')
,p_last_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(158958373141034601)
,p_plug_name=>'Filtros'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(38289867500120143)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(326450468212260901)
,p_plug_name=>'Ajuste de Inventario'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(37806762584106520)
,p_plug_display_sequence=>30
,p_include_in_reg_disp_sel_yn=>'Y'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select control01,control02,control03,control04',
'	, txt01 ilglpt',
'	, txt02 ilclss',
'	, txt03 ildct',
'	, txt04 ilddct',
'	, txt05 ilmcu',
'	, txt06 illitm',
'	, txt07 nombreproducto',
'	, txt08 coddivisioncom',
'	, txt09 categoria',
'	, txt10 subcategoriaproducto',
'	, txt11 iltrum',
'	, txt12 illocn',
'	, txt13 divmanufactura',
'	, num01 ildgl',
'	, num02 ilicu',
'	, num03 ildoc',
'	, num04 iltrqt',
'	, num05 iluncs',
'	, num06 ilpaid',
'	, fecha01',
'from data.t_apex_temporal where control01 = :g_compania and control02 = :app_modulo and control03 = :app_user and control04 = ''data.pk_finz_reportes.sp_ajusteinventario'';'))
,p_plug_source_type=>'NATIVE_IR'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(326450610927260902)
,p_max_row_count=>'1000000'
,p_allow_report_saving=>'N'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_control_break=>'N'
,p_show_highlight=>'N'
,p_show_computation=>'N'
,p_show_aggregate=>'N'
,p_show_chart=>'N'
,p_show_group_by=>'N'
,p_show_pivot=>'N'
,p_show_flashback=>'N'
,p_download_formats=>'CSV:HTML'
,p_enable_mail_download=>'N'
,p_csv_output_separator=>';'
,p_owner=>'DDELACRUZ'
,p_internal_uid=>326450610927260902
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(212073973878340819)
,p_db_column_name=>'CONTROL01'
,p_display_order=>10
,p_column_identifier=>'AC'
,p_column_label=>'Control01'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(212074085123340820)
,p_db_column_name=>'CONTROL02'
,p_display_order=>20
,p_column_identifier=>'AD'
,p_column_label=>'Control02'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(212074115200340821)
,p_db_column_name=>'CONTROL03'
,p_display_order=>30
,p_column_identifier=>'AE'
,p_column_label=>'Control03'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(212074266795340822)
,p_db_column_name=>'CONTROL04'
,p_display_order=>40
,p_column_identifier=>'AF'
,p_column_label=>'Control04'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(111972447308981929)
,p_db_column_name=>'ILCLSS'
,p_display_order=>50
,p_column_identifier=>'K'
,p_column_label=>'Tipo Inv.'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(111972529478981930)
,p_db_column_name=>'ILDGL'
,p_display_order=>60
,p_column_identifier=>'L'
,p_column_label=>'Tipo Inv.'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(111972628682981931)
,p_db_column_name=>'ILDCT'
,p_display_order=>70
,p_column_identifier=>'M'
,p_column_label=>'Tipo Doc.'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(111972708430981932)
,p_db_column_name=>'ILDDCT'
,p_display_order=>80
,p_column_identifier=>'N'
,p_column_label=>'Desc. Documento'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(111972810215981933)
,p_db_column_name=>'ILMCU'
,p_display_order=>90
,p_column_identifier=>'O'
,p_column_label=>'UN'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(111972924357981934)
,p_db_column_name=>'ILICU'
,p_display_order=>100
,p_column_identifier=>'P'
,p_column_label=>'Batch'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(111973035989981935)
,p_db_column_name=>'ILDOC'
,p_display_order=>110
,p_column_identifier=>'Q'
,p_column_label=>'Documento'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(111973175829981936)
,p_db_column_name=>'ILLITM'
,p_display_order=>120
,p_column_identifier=>'R'
,p_column_label=>unistr('C\00F3d. Producto')
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(111973212474981937)
,p_db_column_name=>'NOMBREPRODUCTO'
,p_display_order=>130
,p_column_identifier=>'S'
,p_column_label=>'Producto'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(111973303471981938)
,p_db_column_name=>'CODDIVISIONCOM'
,p_display_order=>140
,p_column_identifier=>'T'
,p_column_label=>unistr('C\00F3d. Cat.')
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(111973451138981939)
,p_db_column_name=>'CATEGORIA'
,p_display_order=>150
,p_column_identifier=>'U'
,p_column_label=>unistr('Categor\00EDa')
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(111973578476981940)
,p_db_column_name=>'SUBCATEGORIAPRODUCTO'
,p_display_order=>160
,p_column_identifier=>'V'
,p_column_label=>unistr('Subcategor\00EDa')
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(212074552047340825)
,p_db_column_name=>'DIVMANUFACTURA'
,p_display_order=>170
,p_column_identifier=>'AI'
,p_column_label=>'Div. Manufactura'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(111973645797981941)
,p_db_column_name=>'ILTRUM'
,p_display_order=>180
,p_column_identifier=>'W'
,p_column_label=>'UM'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(111973761623981942)
,p_db_column_name=>'ILTRQT'
,p_display_order=>190
,p_column_identifier=>'X'
,p_column_label=>'Cantidad'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(111973854623981943)
,p_db_column_name=>'ILUNCS'
,p_display_order=>200
,p_column_identifier=>'Y'
,p_column_label=>'Costo Un.'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(111973925755981944)
,p_db_column_name=>'ILPAID'
,p_display_order=>210
,p_column_identifier=>'Z'
,p_column_label=>'Costo'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(111974089201981945)
,p_db_column_name=>'ILLOCN'
,p_display_order=>220
,p_column_identifier=>'AA'
,p_column_label=>unistr('Ubicaci\00F3n')
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(212074365891340823)
,p_db_column_name=>'ILGLPT'
,p_display_order=>230
,p_column_identifier=>'AG'
,p_column_label=>unistr('C\00F3d. Tipo')
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(212074457002340824)
,p_db_column_name=>'FECHA01'
,p_display_order=>240
,p_column_identifier=>'AH'
,p_column_label=>'Fecha LM'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_format_mask=>'dd/mm/yyyy'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(333608410468083523)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'1143853'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'FECHA01:ILGLPT:ILCLSS:ILDOC:ILDCT:ILDDCT:ILMCU:ILICU:ILLITM:NOMBREPRODUCTO:CODDIVISIONCOM:CATEGORIA:SUBCATEGORIAPRODUCTO:ILTRUM:ILTRQT:ILUNCS:ILPAID:ILLOCN::DIVMANUFACTURA'
,p_created_on=>wwv_flow_imp.dz('20230705164634Z')
,p_updated_on=>wwv_flow_imp.dz('20230705164634Z')
,p_created_by=>'CVACA'
,p_updated_by=>'CVACA'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1195341164914615303)
,p_plug_name=>'Barra de Acciones'
,p_region_template_options=>'#DEFAULT#:t-Form--stretchInputs'
,p_plug_template=>wwv_flow_imp.id(38289497777120142)
,p_plug_display_sequence=>30
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'REGION_POSITION_01'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(114386083994920143)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(1195341164914615303)
,p_button_name=>'BUSCAR'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860056812106557)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Buscar'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-search'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(114379490132920129)
,p_name=>'P118_FECHADESDE'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(158958373141034601)
,p_item_default=>'trunc(add_months(sysdate,-1),''month'')'
,p_item_default_type=>'EXPRESSION'
,p_item_default_language=>'PLSQL'
,p_prompt=>'Fecha Desde:'
,p_format_mask=>'dd/mm/yyyy'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(114379897527920129)
,p_name=>'P118_FECHAHASTA'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(158958373141034601)
,p_item_default=>'sysdate'
,p_item_default_type=>'EXPRESSION'
,p_item_default_language=>'PLSQL'
,p_prompt=>'Fecha Hasta:'
,p_format_mask=>'dd/mm/yyyy'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(114386885189920144)
,p_name=>'Buscar'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(114386083994920143)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(114387306392920144)
,p_event_id=>wwv_flow_imp.id(114386885189920144)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'mostrarBarra();'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(114387888477920151)
,p_event_id=>wwv_flow_imp.id(114386885189920144)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'	data.pk_finz_reportes.sp_ajusteinventario(:g_compania,:app_user,:p118_fechadesde,:p118_fechahasta);',
'end;'))
,p_attribute_02=>'P118_FECHADESDE,P118_FECHAHASTA'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(114388305963920151)
,p_event_id=>wwv_flow_imp.id(114386885189920144)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(326450468212260901)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(114388896522920152)
,p_event_id=>wwv_flow_imp.id(114386885189920144)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'ocultarBarra();'
);
wwv_flow_imp.component_end;
end;
/
