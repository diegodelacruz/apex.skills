prompt --application/pages/page_00197
begin
--   Manifest
--     PAGE: 00197
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>109
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_page.create_page(
 p_id=>197
,p_name=>'GESTION TRIBUTARIA - ANEXO INFORMANTE'
,p_alias=>'GESTION-TRIBUTARIA-ANEXO-INFORMANTE'
,p_page_mode=>'MODAL'
,p_step_title=>'GESTION TRIBUTARIA - ANEXO INFORMANTE'
,p_autocomplete_on_off=>'OFF'
,p_javascript_file_urls=>'https://cdnjs.cloudflare.com/ajax/libs/xlsx/0.18.5/xlsx.full.min.js'
,p_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'function f_render_form_informante(p_data) {',
'  // Parse seguro',
'  let raw;',
'  try { raw = typeof p_data === "string" ? JSON.parse(p_data) : JSON.parse(JSON.stringify(p_data || {})); }',
'  catch { raw = {}; }',
'',
'  const contenedor = document.getElementById("reporte-informante");',
'  if (!contenedor) return;',
'',
'  // Detecta esquema entrante',
'  const isNew = ("IdInformante" in raw) || ("razonSocial" in raw);',
'  const isOld = ("Ruc del Informante" in raw) || ("Razon Social" in raw);',
'  const schema = isNew ? "new" : (isOld ? "old" : "new");',
'',
'  // Mapas',
'  const newToOld = {',
'    IdInformante: "Ruc del Informante",',
'    razonSocial: "Razon Social",',
'    IdRepresentanteLegal: "ID Representante Legal",',
'    IDdelRucdelContador: "ID del Ruc del Contador",',
unistr('    Anio: "A\00F1o",'),
'    Mes: "Mes",',
'    TipoIDInformante: "Tipo ID del Informante",',
'    numEstabRuc: "Numeros de Establecimientos",',
'    totalVentas: "Total de Ventas",',
'    codigoOperativo: "Cod Tipo Operativo"',
'  };',
'  const oldToNew = Object.fromEntries(Object.entries(newToOld).map(([k,v]) => [v,k]));',
'',
'  // ViewModel con etiquetas antiguas',
'  const allOldLabels = Object.values(newToOld);',
'  let view = {};',
'  if (schema === "new") {',
'    Object.keys(newToOld).forEach(nk => view[newToOld[nk]] = raw[nk] ?? "");',
'  } else {',
'    allOldLabels.forEach(lbl => view[lbl] = raw[lbl] ?? "");',
'  }',
'',
'  // Helpers',
'  const fmtInt = new Intl.NumberFormat("es-EC", { maximumFractionDigits: 0 });',
'  const fmtNum = new Intl.NumberFormat("es-EC", { minimumFractionDigits: 0, maximumFractionDigits: 3 });',
'',
'  function parseNumero(valor) {',
'    if (valor == null) return 0;',
'    let s = String(valor).trim();',
'    if (!s) return 0;',
'    s = s.replace(/\s+/g, "")',
'         .replace(/^\((.*)\)$/, "-$1")',
'         .replace(/%/g, "")',
'         .replace(/\./g, "")',
'         .replace(",", ".");',
'    const num = parseFloat(s);',
'    return Number.isFinite(num) ? num : 0;',
'  }',
'  function toText(v){ return String(v == null ? "" : v); }',
'',
unistr('  // Normaliza num\00E9ricos en view'),
'  view["Numeros de Establecimientos"] = parseNumero(view["Numeros de Establecimientos"]);',
'  view["Total de Ventas"] = parseNumero(view["Total de Ventas"]);',
'',
'  // Sincroniza a almacenamiento respetando esquema de entrada',
'  function syncToStorage() {',
'    let out;',
'    if (schema === "new") {',
'      out = {};',
'      Object.keys(newToOld).forEach(nk => {',
'        const lbl = newToOld[nk];',
'        let val = view[lbl];',
'        if (nk === "numEstabRuc" || nk === "totalVentas") val = parseNumero(val);',
'        out[nk] = (nk === "numEstabRuc" || nk === "totalVentas") ? val : toText(val);',
'      });',
'    } else {',
'      out = {};',
'      allOldLabels.forEach(lbl => {',
'        let val = view[lbl];',
'        if (lbl === "Numeros de Establecimientos" || lbl === "Total de Ventas") val = parseNumero(val);',
'        out[lbl] = (lbl === "Numeros de Establecimientos" || lbl === "Total de Ventas") ? val : toText(val);',
'      });',
'    }',
'    $s("P197_JSON", JSON.stringify(out));',
'  }',
'',
'  // Render',
'  const html =',
'`<style>',
'#reporte-informante table{border-collapse:collapse;width:100%;font-size:13px}',
'#reporte-informante th,#reporte-informante td{border:.5px dotted #888;padding:4px 6px;text-align:left}',
'#reporte-informante th{background:#f2f2f2;width:38%}',
'#reporte-informante .editable{background:#eaffea}',
'#reporte-informante td[contenteditable="true"]{min-width:160px;outline:none}',
'#reporte-informante .seccion{margin-top:12px}',
'</style>',
'<div class="seccion">',
'  <i><u>Datos del informante:</u></i>',
'  <table><tbody>',
'    <tr><th>Ruc del Informante</th>',
'        <td contenteditable="true" class="editable" data-campo="Ruc del Informante">${toText(view["Ruc del Informante"])}</td></tr>',
'    <tr><th>Razon Social</th>',
'        <td contenteditable="true" class="editable" data-campo="Razon Social">${toText(view["Razon Social"])}</td></tr>',
'    <tr><th>ID Representante Legal</th>',
'        <td contenteditable="true" class="editable" data-campo="ID Representante Legal">${toText(view["ID Representante Legal"])}</td></tr>',
'    <tr><th>ID del Ruc del Contador</th>',
'        <td contenteditable="true" class="editable" data-campo="ID del Ruc del Contador">${toText(view["ID del Ruc del Contador"])}</td></tr>',
unistr('    <tr><th>A\00F1o</th>'),
unistr('		<td contenteditable="true" class="editable" data-campo="A\00F1o">${toText(view["A\00F1o"])}</td></tr>'),
'    <tr><th>Mes</th>',
'		<td contenteditable="true" class="editable" data-campo="Mes">${toText(view["Mes"])}</td></tr>',
'    <tr><th>Tipo ID del Informante</th>',
'        <td contenteditable="true" class="editable" data-campo="Tipo ID del Informante">${toText(view["Tipo ID del Informante"])}</td></tr>',
'    <tr><th>Numeros de Establecimientos</th>',
'        <td contenteditable="true" class="editable" data-campo="Numeros de Establecimientos">${fmtInt.format(view["Numeros de Establecimientos"])}</td></tr>',
'    <tr><th>Total de Ventas</th>',
'        <td contenteditable="true" class="editable" data-campo="Total de Ventas">${fmtNum.format(view["Total de Ventas"])}</td></tr>',
'    <tr><th>Cod Tipo Operativo</th>',
'        <td contenteditable="true" class="editable" data-campo="Cod Tipo Operativo">${toText(view["Cod Tipo Operativo"])}</td></tr>',
'  </tbody></table>',
'</div>`;',
'',
'  contenedor.innerHTML = html;',
'',
unistr('  // Eventos de edici\00F3n'),
'  contenedor.querySelectorAll(".editable").forEach(td => {',
'    td.addEventListener("blur", function(){',
'      const campo = this.dataset.campo;',
'      let txt = this.textContent.trim();',
'',
'      if (campo === "Numeros de Establecimientos") {',
'        view[campo] = parseNumero(txt);',
'        this.textContent = fmtInt.format(view[campo]);',
'      } else if (campo === "Total de Ventas") {',
'        view[campo] = parseNumero(txt);',
'        this.textContent = fmtNum.format(view[campo]);',
'      } else {',
'        view[campo] = txt;',
'      }',
'      syncToStorage();',
'    });',
'  });',
'',
'  // Guardado inicial con el mismo esquema de entrada',
'  syncToStorage();',
'}',
''))
,p_javascript_code_onload=>wwv_flow_string.join(wwv_flow_t_varchar2(
'$(secItems).hide();',
'let data = JSON.parse($v(''P197_JSON''));',
'f_render_form_informante(data);',
''))
,p_step_template=>wwv_flow_imp.id(37774372912106498)
,p_page_template_options=>'#DEFAULT#'
,p_dialog_chained=>'N'
,p_protection_level=>'C'
,p_page_component_map=>'16'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(261461836790535932)
,p_plug_name=>'BARRA DE BOTONES'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(38290276266120143)
,p_plug_display_sequence=>60
,p_location=>null
,p_ai_enabled=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(261462316170535937)
,p_plug_name=>'items'
,p_region_name=>'secItems'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(38289867500120143)
,p_plug_display_sequence=>80
,p_location=>null
,p_ai_enabled=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(279798652047380311)
,p_plug_name=>'ReporteInformante'
,p_region_name=>'reporte-informante'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(38289867500120143)
,p_plug_display_sequence=>20
,p_location=>null
,p_ai_enabled=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(152195312411748429)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(261461836790535932)
,p_button_name=>'CLOSE'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860181880106559)
,p_button_image_alt=>'Cerrar'
,p_warn_on_unsaved_changes=>null
,p_grid_new_row=>'N'
,p_grid_new_column=>'N'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(152195785648748435)
,p_button_sequence=>50
,p_button_plug_id=>wwv_flow_imp.id(261461836790535932)
,p_button_name=>'SAVE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860181880106559)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Guadar'
,p_grid_new_row=>'N'
,p_grid_new_column=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(261466166684536218)
,p_name=>'P197_IDDAT'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(261462316170535937)
,p_prompt=>'Iddat'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(279801301650380580)
,p_name=>'P197_JSON'
,p_data_type=>'CLOB'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(261462316170535937)
,p_prompt=>'Json'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>30
,p_cHeight=>5
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(279801943986380587)
,p_name=>'P197_PERIODO'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(261462316170535937)
,p_prompt=>'Periodo'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(152199935571748490)
,p_name=>'Cerrar'
,p_event_sequence=>50
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(152195312411748429)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(152200464879748494)
,p_event_id=>wwv_flow_imp.id(152199935571748490)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CLOSE'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(152199589909748486)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Process Create - PRUEBA DEPARTAMENTAL'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
'    update  data.t_finz_gestiontributariadatos dat set DATOSMOD= :P197_JSON, DATOSFIN= :P197_JSON where dat.id=:P197_IDDAT;',
'EXCEPTION WHEN OTHERS THEN ',
'    apex_error.add_error (',
'    p_message          => ''ERROR::''||SQLERRM  ,',
'    p_display_location =>apex_error.c_inline_in_notification );',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>152199589909748486
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(152199163890748481)
,p_process_sequence=>20
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Initialize'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
'    :P197_IDDAT:=:G_VALOR1;--nvl(:P197_IDDAT,:G_VALOR1);',
'     BEGIN',
'         select ',
'            dat.datosmod,GTB.PERIODO INTO :P197_JSON,:P197_PERIODO',
'        from data.t_finz_gestiontributaria gtb',
'        inner join data.t_finz_gestiontributariadet det ON gtb.id=det.idgtb',
'        inner join data.t_finz_gestiontributariadatos dat on det.id=dat.iddet',
'        WHERE dat.id =:P197_IDDAT;',
'     EXCEPTION WHEN OTHERS THEN ',
'        :P197_JSON:=NULL;:P197_PERIODO:=to_char(sysdate,''YYYYMM'');',
'     END;',
'',
'    ',
'    IF (:P197_JSON IS NULL)THEN ',
unistr('        --:P197_JSON:=''{"Ruc del Informante":"1791297385001","Razon Social":"ZAIMELLA DEL ECUADOR S.A.","ID Representante Legal":"1713934907001","ID del Ruc del Contador":"","A\00F1o":"''||substr(:P197_PERIODO,1,4)||''","Mes":"''||substr(:P197_PERIODO,5)||''')
||'","Tipo ID del Informante":"R","Numeros de Establecimientos":1,"Total de Ventas":12345.978,"Cod Tipo Operativo":"IVA"}'';',
'		:P197_JSON:=''{"IdInformante":"1791297385001","razonSocial":"ZAIMELLA DEL ECUADOR S.A.","IdRepresentanteLegal":"1713934907001","IDdelRucdelContador":"","Anio":"''||substr(:P197_PERIODO,1,4)||''","Mes":"''||substr(:P197_PERIODO,5)||''","TipoIDInformante"'
||':"R","numEstabRuc":1,"totalVentas":12345.978,"codigoOperativo":"IVA"}'';',
'    END IF;',
'    ',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>152199163890748481
);
wwv_flow_imp.component_end;
end;
/
