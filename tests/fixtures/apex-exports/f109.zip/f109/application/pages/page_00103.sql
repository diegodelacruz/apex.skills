prompt --application/pages/page_00103
begin
--   Manifest
--     PAGE: 00103
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>109
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_page.create_page(
 p_id=>103
,p_name=>unistr('PyG Envases Estructura - Parametrizaci\00F3n Nivel 2 - Valorizaci\00F3n para formulaciones')
,p_step_title=>unistr('PyG Envases Estructura - Parametrizaci\00F3n Nivel 2 - Valorizaci\00F3n para formulaciones')
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_page_component_map=>'21'
,p_created_on=>wwv_flow_imp.dz('20230705164634Z')
,p_last_updated_on=>wwv_flow_imp.dz('20240801181811Z')
,p_last_updated_by=>'MALBAN'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(105220451007171728)
,p_plug_name=>unistr('PyG Envases Estructura - Parametrizaci\00F3n Nivel 2 - Valorizaci\00F3n para formulaciones')
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(38290610465120145)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_menu_id=>wwv_flow_imp.id(37761271469106475)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(37860983999106559)
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(105220546341171729)
,p_plug_name=>'Barra de acciones'
,p_region_template_options=>'#DEFAULT#:t-Form--stretchInputs'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(38289497777120142)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_menu_id=>wwv_flow_imp.id(37761271469106475)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(37860983999106559)
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(105220824179171732)
,p_plug_name=>'Datos Estructura'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(38289867500120143)
,p_plug_display_sequence=>30
,p_include_in_reg_disp_sel_yn=>'Y'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(105368016250721215)
,p_plug_name=>'Valorizacion'
,p_region_name=>'Valorizacion'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(37806762584106520)
,p_plug_display_sequence=>40
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ',
'         ID ',
'        ,PARN2ID',
'        ,Valor',
'        ,Codificacion',
'        ,FechaIni',
'        ,FechaFin',
'        ,RUTA_APROBACION',
'        ,ESTADO',
'        ,APROBADOR',
'        ,TOKEN',
'from T_FINZ_PYGENV_FRM',
'where PARN2ID = :P103_PAR_ID'))
,p_plug_source_type=>'NATIVE_IG'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(105368283313721217)
,p_name=>'ID'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'ID'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_NUMBER_FIELD'
,p_heading=>'Id'
,p_heading_alignment=>'RIGHT'
,p_display_sequence=>40
,p_value_alignment=>'RIGHT'
,p_attribute_03=>'right'
,p_attribute_04=>'text'
,p_is_required=>true
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>true
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(105368392623721218)
,p_name=>'PARN2ID'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'PARN2ID'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_NUMBER_FIELD'
,p_heading=>'Parn2id'
,p_heading_alignment=>'RIGHT'
,p_display_sequence=>50
,p_value_alignment=>'RIGHT'
,p_attribute_03=>'right'
,p_attribute_04=>'text'
,p_is_required=>false
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(105369238830721227)
,p_name=>'FECHAINI'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'FECHAINI'
,p_data_type=>'DATE'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_DATE_PICKER'
,p_heading=>'Fecha Desde'
,p_heading_alignment=>'CENTER'
,p_display_sequence=>160
,p_value_alignment=>'CENTER'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
,p_is_required=>false
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(105369300078721228)
,p_name=>'FECHAFIN'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'FECHAFIN'
,p_data_type=>'DATE'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_DATE_PICKER'
,p_heading=>'Fecha Hasta'
,p_heading_alignment=>'CENTER'
,p_display_sequence=>170
,p_value_alignment=>'CENTER'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
,p_is_required=>false
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(105369409852721229)
,p_name=>'RUTA_APROBACION'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'RUTA_APROBACION'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_DISPLAY_ONLY'
,p_heading=>'Ruta'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>180
,p_value_alignment=>'LEFT'
,p_attribute_02=>'VALUE'
,p_attribute_05=>'PLAIN'
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_enable_control_break=>false
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(105369529294721230)
,p_name=>'ESTADO'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'ESTADO'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_DISPLAY_ONLY'
,p_heading=>'Estado'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>190
,p_value_alignment=>'LEFT'
,p_attribute_02=>'VALUE'
,p_attribute_05=>'PLAIN'
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_enable_control_break=>false
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(105369639275721231)
,p_name=>'APROBADOR'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'APROBADOR'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_DISPLAY_ONLY'
,p_heading=>'Aprobador'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>200
,p_value_alignment=>'LEFT'
,p_attribute_02=>'VALUE'
,p_attribute_05=>'PLAIN'
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_enable_control_break=>false
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(105370145477721236)
,p_name=>'APEX$ROW_ACTION'
,p_session_state_data_type=>'VARCHAR2'
,p_item_type=>'NATIVE_ROW_ACTION'
,p_display_sequence=>20
,p_enable_hide=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(105370958942721244)
,p_name=>'TOKEN'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'TOKEN'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>'Token'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>210
,p_value_alignment=>'LEFT'
,p_attribute_05=>'BOTH'
,p_format_mask=>'000000000'
,p_is_required=>false
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
,p_readonly_condition_type=>'ALWAYS'
,p_readonly_for_each_row=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(107415058285497221)
,p_name=>'VALOR'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'VALOR'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_NUMBER_FIELD'
,p_heading=>'Valor'
,p_heading_alignment=>'RIGHT'
,p_display_sequence=>230
,p_value_alignment=>'RIGHT'
,p_attribute_03=>'right'
,p_attribute_04=>'text'
,p_format_mask=>'999G999G999G999G990D0000'
,p_is_required=>false
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(107415114880497222)
,p_name=>'CODIFICACION'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'CODIFICACION'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>'Codificacion'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>240
,p_value_alignment=>'LEFT'
,p_is_required=>false
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_enable_control_break=>false
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_interactive_grid(
 p_id=>wwv_flow_imp.id(105368182386721216)
,p_internal_uid=>105368182386721216
,p_is_editable=>true
,p_edit_operations=>'u:d'
,p_lost_update_check_type=>'VALUES'
,p_submit_checked_rows=>false
,p_lazy_loading=>false
,p_requires_filter=>false
,p_max_row_count=>100000
,p_show_nulls_as=>'-'
,p_select_first_row=>true
,p_fixed_row_height=>true
,p_pagination_type=>'SCROLL'
,p_show_total_row_count=>true
,p_show_toolbar=>true
,p_toolbar_buttons=>'SEARCH_COLUMN:SEARCH_FIELD:ACTIONS_MENU:SAVE'
,p_enable_save_public_report=>true
,p_enable_subscriptions=>true
,p_enable_flashback=>true
,p_define_chart_view=>true
,p_enable_download=>true
,p_enable_mail_download=>true
,p_fixed_header=>'PAGE'
,p_show_icon_view=>false
,p_show_detail_view=>false
);
wwv_flow_imp_page.create_ig_report(
 p_id=>wwv_flow_imp.id(105483087763092031)
,p_interactive_grid_id=>wwv_flow_imp.id(105368182386721216)
,p_static_id=>'186561'
,p_type=>'PRIMARY'
,p_default_view=>'GRID'
,p_show_row_number=>false
,p_settings_area_expanded=>false
);
wwv_flow_imp_page.create_ig_report_view(
 p_id=>wwv_flow_imp.id(105483172899092031)
,p_report_id=>wwv_flow_imp.id(105483087763092031)
,p_view_type=>'GRID'
,p_stretch_columns=>true
,p_srv_exclude_null_values=>false
,p_srv_only_display_columns=>true
,p_edit_mode=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(105483686536092032)
,p_view_id=>wwv_flow_imp.id(105483172899092031)
,p_display_seq=>1
,p_column_id=>wwv_flow_imp.id(105368283313721217)
,p_is_visible=>true
,p_is_frozen=>true
,p_width=>90
,p_sort_order=>1
,p_sort_direction=>'DESC'
,p_sort_nulls=>'LAST'
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(105484009873092034)
,p_view_id=>wwv_flow_imp.id(105483172899092031)
,p_display_seq=>2
,p_column_id=>wwv_flow_imp.id(105368392623721218)
,p_is_visible=>false
,p_is_frozen=>false
,p_width=>90
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(105488584852092045)
,p_view_id=>wwv_flow_imp.id(105483172899092031)
,p_display_seq=>5
,p_column_id=>wwv_flow_imp.id(105369238830721227)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>104
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(105489021198092045)
,p_view_id=>wwv_flow_imp.id(105483172899092031)
,p_display_seq=>6
,p_column_id=>wwv_flow_imp.id(105369300078721228)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>102
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(105489540672092046)
,p_view_id=>wwv_flow_imp.id(105483172899092031)
,p_display_seq=>7
,p_column_id=>wwv_flow_imp.id(105369409852721229)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(105490020057092048)
,p_view_id=>wwv_flow_imp.id(105483172899092031)
,p_display_seq=>8
,p_column_id=>wwv_flow_imp.id(105369529294721230)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(105490543979092048)
,p_view_id=>wwv_flow_imp.id(105483172899092031)
,p_display_seq=>9
,p_column_id=>wwv_flow_imp.id(105369639275721231)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(105632466278239372)
,p_view_id=>wwv_flow_imp.id(105483172899092031)
,p_display_seq=>0
,p_column_id=>wwv_flow_imp.id(105370145477721236)
,p_is_visible=>true
,p_is_frozen=>true
,p_width=>52
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(105666687452204684)
,p_view_id=>wwv_flow_imp.id(105483172899092031)
,p_display_seq=>10
,p_column_id=>wwv_flow_imp.id(105370958942721244)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>81
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(107502086848889856)
,p_view_id=>wwv_flow_imp.id(105483172899092031)
,p_display_seq=>3
,p_column_id=>wwv_flow_imp.id(107415058285497221)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>140
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(107510371322950736)
,p_view_id=>wwv_flow_imp.id(105483172899092031)
,p_display_seq=>4
,p_column_id=>wwv_flow_imp.id(107415114880497222)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>140
);
wwv_flow_imp_page.create_ig_report_highlight(
 p_id=>wwv_flow_imp.id(51803000000)
,p_view_id=>wwv_flow_imp.id(105483172899092031)
,p_execution_seq=>5
,p_name=>'Permite Cambiar'
,p_background_color=>'#B5D6FF'
,p_condition_type=>'COLUMN'
,p_condition_column_id=>wwv_flow_imp.id(105369529294721230)
,p_condition_operator=>'N'
,p_condition_is_case_sensitive=>false
,p_is_enabled=>true
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(105221037683171734)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(105220546341171729)
,p_button_name=>'Regresar'
,p_button_static_id=>'btnRegresar'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860056812106557)
,p_button_image_alt=>'Regresar'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'LEFT'
,p_button_redirect_url=>'f?p=&APP_ID.:102:&SESSION.::&DEBUG.:RP:P102_N2_ID:&P103_N2_ID.'
,p_icon_css_classes=>'fa-arrow-left'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(105369768086721232)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(105220546341171729)
,p_button_name=>'Agregar'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860056812106557)
,p_button_image_alt=>'Agregar'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_icon_css_classes=>'fa-plus'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(105370850125721243)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(105220546341171729)
,p_button_name=>'Grabar'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860056812106557)
,p_button_image_alt=>'Grabar'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_button_condition_type=>'NEVER'
,p_icon_css_classes=>'fa-save'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(105369978354721234)
,p_button_sequence=>50
,p_button_plug_id=>wwv_flow_imp.id(105220546341171729)
,p_button_name=>'Aprobar'
,p_button_action=>'REDIRECT_APP'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860056812106557)
,p_button_image_alt=>'Enviar Aprobar'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=100:101:&SESSION.::&DEBUG.:RP:G_MODULO,G_OBJETO,G_OBJETO_ID,G_USUARIO,G_TIPO1:&APP_MODULO.,Pyg_ZP_Valores,&P103_TOKEN.,&APP_USER.,&P103_RUTAAPROBACION.'
,p_button_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select * ',
'from T_FINZ_PYGENV_FRM',
'where 1=1',
'and PARN2ID = :P103_PAR_ID ',
'and estado is null ',
'and token is  null ',
'and :P103_RUTAAPROBACION is not null ',
'and valor is not null',
';'))
,p_button_condition_type=>'NOT_EXISTS'
,p_icon_css_classes=>'fa-check-circle-o'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(105220973015171733)
,p_name=>'P103_N2_ID'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(105220824179171732)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(105367301935721208)
,p_name=>'P103_PAR_ID'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_imp.id(105220824179171732)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(105367451325721209)
,p_name=>'P103_NIVEL1'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(105220824179171732)
,p_prompt=>'Nivel1'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(105367539178721210)
,p_name=>'P103_NIVEL2'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(105220824179171732)
,p_prompt=>'Nivel2'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(105367631552721211)
,p_name=>'P103_ASOCIACION'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(105220824179171732)
,p_prompt=>'Asociacion/Parametro'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(105367778366721212)
,p_name=>'P103_COLUMNAS'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(105220824179171732)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(105367897159721213)
,p_name=>'P103_RUTAAPROBACION'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(105220824179171732)
,p_prompt=>'Rutaaprobacion'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_display_when=>'P103_RUTAAPROBACION'
,p_display_when_type=>'ITEM_IS_NOT_NULL'
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(105371157146721246)
,p_name=>'P103_TOKEN'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(105220824179171732)
,p_format_mask=>'000000000'
,p_display_as=>'NATIVE_HIDDEN'
,p_display_when=>'P103_TOKEN'
,p_display_when_type=>'ITEM_IS_NOT_NULL'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(105879220019607501)
,p_name=>'P103_TERMINA_FLUJO'
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_imp.id(105220824179171732)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(105879382429607502)
,p_name=>'P103_ENVIO_EXITO'
,p_item_sequence=>120
,p_item_plug_id=>wwv_flow_imp.id(105220824179171732)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(106831501194849106)
,p_name=>'P103_RESUTADO'
,p_item_sequence=>130
,p_item_plug_id=>wwv_flow_imp.id(105220824179171732)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(105371393077721248)
,p_name=>unistr('Cierre di\00E1logo: env\00EDo flujo')
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(105369978354721234)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(105371461087721249)
,p_event_id=>wwv_flow_imp.id(105371393077721248)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'var trama = JSON.parse(this.data.G_RESULTADO);',
'var isTerminoFlujo= trama.resultado.terminoFlujo;',
'',
'apex.item( "P103_TERMINA_FLUJO" ).setValue(0);',
'apex.item( "P103_ENVIO_EXITO" ).setValue(0);',
'',
'if(this.data.G_EXITO==''true''){',
'     mensaje(''exito'', this.data.G_MENSAJE);',
'     apex.item( "P103_ENVIO_EXITO" ).setValue(1);',
'    if(isTerminoFlujo){',
'        apex.item( "P103_TERMINA_FLUJO" ).setValue(1);',
'    }',
'}',
'else{ ',
'     mensaje(''error'', this.data.G_MENSAJE);',
'}',
''))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(105879565534607504)
,p_name=>unistr('Cierre di\00E1logo: envio flujo \00E9xito')
,p_event_sequence=>20
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(105220546341171729)
,p_condition_element=>'P103_ENVIO_EXITO'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'1'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(105879645217607505)
,p_event_id=>wwv_flow_imp.id(105879565534607504)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'v_valida number;',
'begin',
'',
'    IF :P103_TERMINA_FLUJO = 1 THEN',
'        UPDATE T_FINZ_PYGENV_FRM',
'        SET ESTADO = ''APROBADO'', APROBADOR = :APP_USER',
'        WHERE token = :P103_TOKEN;',
'        ',
'        COMMIT;',
'    ELSE',
'        UPDATE T_FINZ_PYGENV_FRM',
'        SET ESTADO = ''EN_PROCESO''',
'        WHERE token = :P103_TOKEN;',
'        commit;',
'       ',
'    END IF;',
'    commit;',
'end;',
'',
'declare v_aprobador varchar2(20);',
'begin',
'    begin',
'        select APROBADOR into v_aprobador from vt_finz_mesatrabajo_pygenvases where token=:P103_TOKEN;',
'    exception when others then',
'        v_aprobador:=null;',
'    end;',
'    if (v_aprobador is not null) then',
'        update T_FINZ_PYGENV_FRM',
'        set Aprobador = v_aprobador',
'        where  token=:P103_TOKEN;',
'        commit;',
'    end if;',
'end;'))
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(105879781350607506)
,p_event_id=>wwv_flow_imp.id(105879565534607504)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P103_TOKEN'
,p_attribute_01=>'STATIC_ASSIGNMENT'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(105879914908607508)
,p_event_id=>wwv_flow_imp.id(105879565534607504)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(105221037683171734)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(105880066716607509)
,p_event_id=>wwv_flow_imp.id(105879565534607504)
,p_event_result=>'TRUE'
,p_action_sequence=>50
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(105368016250721215)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(105880144287607510)
,p_event_id=>wwv_flow_imp.id(105879565534607504)
,p_event_result=>'TRUE'
,p_action_sequence=>60
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>' $(''#btnRegresar'').trigger("click");'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(105881428641607523)
,p_name=>'Enable/Disable'
,p_event_sequence=>30
,p_triggering_element_type=>'COLUMN'
,p_triggering_region_id=>wwv_flow_imp.id(105368016250721215)
,p_triggering_element=>'ESTADO'
,p_condition_element_type=>'COLUMN'
,p_condition_element=>'ESTADO'
,p_triggering_condition_type=>'NULL'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(105881581084607524)
,p_event_id=>wwv_flow_imp.id(105881428641607523)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_ENABLE'
,p_affected_elements_type=>'COLUMN'
,p_affected_elements=>'VALOR,CODIFICACION,FECHAINI,FECHAFIN'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(105881718065607526)
,p_event_id=>wwv_flow_imp.id(105881428641607523)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_DISABLE'
,p_affected_elements_type=>'COLUMN'
,p_affected_elements=>'VALOR,CODIFICACION,FECHAINI,FECHAFIN'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(105940114070866936)
,p_name=>'Grabar'
,p_event_sequence=>40
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(105368016250721215)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'NATIVE_IG|REGION TYPE|interactivegridsave'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(105940280901866937)
,p_event_id=>wwv_flow_imp.id(105940114070866936)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_01=>'Valorizacion'
,p_attribute_02=>'Y'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(105367938478721214)
,p_process_sequence=>10
,p_process_point=>'AFTER_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'setup interface'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare ',
'    v_id varchar2(999);',
'    v_n2id varchar2(999);',
'    v_nivel1 varchar2(999);',
'    v_nivel2 varchar2(999);',
'    v_Asociacion varchar2(999);',
'    v_Columnas varchar2(999);',
'    v_RutaAprobacion varchar2(999);',
'begin',
'    Select   ',
'         ID',
'        ,N2_ID',
'        ,pk_finanzas.fn_traeNiveles(N2_ID, 1,''ENV'')Nivel1',
'        ,pk_finanzas.fn_traeNiveles(N2_ID, 2,''ENV'')Nivel2',
'        ,TXT01',
'        ,TXT11',
'        ,RUTA_APROBACION',
'    into ',
'         v_id',
'        ,v_n2id',
'        ,v_nivel1',
'        ,v_nivel2',
'        ,v_Asociacion',
'        ,v_Columnas ',
'        ,v_RutaAprobacion     ',
'    from T_FINZ_PARAM_FORMULAS',
'    where  ID= :P103_PAR_ID AND TIPO=''ENV''',
'    ;',
'    DBMS_OUTPUT.PUT_LINE(''v_id:             '' || v_id);',
'    DBMS_OUTPUT.PUT_LINE(''v_n2id:           '' || v_n2id);',
'    DBMS_OUTPUT.PUT_LINE(''v_nivel1:         '' || v_nivel1);',
'    DBMS_OUTPUT.PUT_LINE(''v_nivel2:         '' || v_nivel2);',
'    DBMS_OUTPUT.PUT_LINE(''v_Asociacion:     '' || v_Asociacion);',
'    DBMS_OUTPUT.PUT_LINE(''v_Columnas:       '' || v_Columnas);',
'    DBMS_OUTPUT.PUT_LINE(''v_RutaAprobacion: '' || v_RutaAprobacion);',
'    SELECT ',
'         v_n2id',
'        ,v_nivel1',
'        ,v_nivel2',
'        ,v_Asociacion',
'        ,v_Columnas ',
'        ,v_RutaAprobacion    ',
'    INTO ',
'         :P103_N2_ID',
'        ,:P103_NIVEL1',
'        ,:P103_NIVEL2',
'        ,:P103_ASOCIACION',
'        ,:P103_COLUMNAS ',
'        ,:P103_RUTAAPROBACION    ',
'    FROM DUAL;',
'    DBMS_OUTPUT.PUT_LINE('':p_id:             '' || :p_id);',
'    DBMS_OUTPUT.PUT_LINE('':P103_N2_ID:           '' || :P103_N2_ID);',
'    DBMS_OUTPUT.PUT_LINE('':P103_NIVEL1:         '' || :P103_NIVEL1);',
'    DBMS_OUTPUT.PUT_LINE('':P103_NIVEL2:         '' || :P103_NIVEL2);',
'    DBMS_OUTPUT.PUT_LINE('':P103_ASOCIACION:     '' || :P103_ASOCIACION);',
'    DBMS_OUTPUT.PUT_LINE('':P103_COLUMNAS:       '' || :P103_COLUMNAS);',
'    DBMS_OUTPUT.PUT_LINE('':P103_RUTAAPROBACION: '' || :P103_RUTAAPROBACION);',
'exception when others then',
'        :P103_N2_ID:='''';',
'        :P103_NIVEL1:='''';',
'        :P103_NIVEL2:='''';',
'        :P103_ASOCIACION:='''';',
'        :P103_COLUMNAS:='''';',
'        :P103_RUTAAPROBACION:='''';',
'end;',
'',
'declare ',
'    v_Token number;',
'begin',
'    select max(token) into v_Token from T_FINZ_PYGENV_FRM where  PARN2ID= :P103_PAR_ID;',
'    :p103_token:=v_Token;',
'    ',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>105367938478721214
,p_updated_on=>wwv_flow_imp.dz('20240801181811Z')
,p_updated_by=>'MALBAN'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(105369831086721233)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Valorizacion- Save Interactive Grid Data_Agregar_Linea'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE ',
'    v_fechaFin date;',
'    v_fechaIni date;',
'',
'begin',
'    select max(FechaFin) into v_fechaIni',
'    from T_FINZ_PYGENV_FRM where PARN2ID=:P103_PAR_ID;',
'    ',
'    if (v_fechaIni is null) then ',
'        v_fechaIni:= trunc(sysdate,''MM'');',
'        v_fechaFin:= last_day(sysdate);',
'    else',
'        v_fechaIni:= trunc(v_fechaIni+1,''MM'');',
'        v_fechaFin:= last_day(v_fechaIni);',
'    end if;',
'    DBMS_OUTPUT.PUT_LINE(''v_fechaIni:''||v_fechaIni);',
'    DBMS_OUTPUT.PUT_LINE(''v_fechaFin:''||v_fechaFin);',
'    ',
'    insert into T_FINZ_PYGENV_FRM',
'        (     PARN2ID,   COMPANIA,Valor,Codificacion,  FechaIni,  FechaFin,     RUTA_APROBACION,ESTADO,APROBADOR)',
'    values',
'        (:P103_PAR_ID,:G_COMPANIA, null,        null,v_fechaIni,v_fechaFin,:P103_RUTAAPROBACION,  null,     null);',
'    commit;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(105369768086721232)
,p_internal_uid=>105369831086721233
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(105370325583721238)
,p_process_sequence=>40
,p_process_point=>'AFTER_SUBMIT'
,p_region_id=>wwv_flow_imp.id(105368016250721215)
,p_process_type=>'NATIVE_IG_DML'
,p_process_name=>'Valorizacion- Save Interactive Grid Data_Validar'
,p_attribute_01=>'PLSQL_CODE'
,p_attribute_04=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare v_mensaje varchar2(999);',
'        v_duplicado number;',
'        v_solapado1 number;',
'        v_solapado2 number;',
'        v_error     varchar2(3999);',
'        v_coderror  varchar2(3999);',
'        v_mensaje2  varchar2(999);',
'        v_fechaini date; ',
'        v_fechafin date;',
'        v_token number;',
'        v_esnuevo number;',
'        v_resultado number;',
'begin',
'    begin',
'        select fechaini, fechafin into v_fechaini,v_fechafin  from T_FINZ_PYGENV_FRM where id = :id;',
'    END;',
'    v_duplicado:=pk_finanzas.fn_pygenv_validaperiododup(:FechaIni,:FechaFin);',
'    v_solapado1:=pk_finanzas.fn_pygenv_validaperiodosol(:FechaIni);',
'    v_solapado2:=pk_finanzas.fn_pygenv_validaperiodosol(:FechaFin);',
'',
'    v_resultado:=1;',
'    case :APEX$ROW_STATUS ',
'    WHEN ''U'' THEN ',
'        IF (v_duplicado>0 and (:FechaIni NOT IN(v_fechaini)  and :FechaFin NOT IN(v_fechafin)) ) then     ',
'        :TOKEN:=NULL;Raise_Application_Error (-20010, ''Fechas Duplicadas.      [''''''||:FechaIni||'''''',''''''||:FechaFin||'''''']'');',
'        end if;',
'        IF (v_solapado1>0 and (:FechaIni not between v_fechaini and v_fechafin ) )then',
'        :TOKEN:=NULL;Raise_Application_Error (-20020, ''Fecha de Inicio Solapda.[''''''||:FechaIni||'''''']'');',
'        end if;',
'        IF (v_solapado2>0 and (:FechaFin not between v_fechaini and v_fechafin ) ) then',
'        :TOKEN:=NULL;Raise_Application_Error (-20030, ''Fechas de Fin Solapda.  [''''''||:FechaFin||'''''']'');',
'        end if;',
'        IF (:valor is null ) then',
'        :TOKEN:=NULL;Raise_Application_Error (-20040, ''No puede tener valores vacios.'');',
'        end if;',
'        sp_pygenv_generatoken(:PARN2ID, v_token,V_MENSAJE,v_esnuevo ) ;',
'        if(V_MENSAJE = ''OK'')THEN',
'            v_resultado:=0;',
'            :P103_RESUTADO:=v_resultado;',
'            if (v_esnuevo=1)then',
'                apex_application.g_print_success_message :=''Se genero el token para autorizacion: 	''||v_token;',
'            end if;',
'        else',
'            v_resultado:=1;',
'            :P103_RESUTADO:=v_resultado;',
'            :TOKEN:=NULL;Raise_Application_Error (-20050, ''Error al generar el token.'');',
'        END IF;',
'      ',
'    END CASE;',
'EXCEPTION WHEN OTHERS THEN',
'    V_ERROR:=SQLERRM;',
'    V_CODERROR:=SQLCODE;',
'',
'    begin',
'        SELECT ',
'            CASE ',
'                WHEN V_CODERROR=''-20010'' THEN replace(V_ERROR,''ORA-20010:'','' '')',
'                WHEN V_CODERROR=''-20020'' THEN replace(V_ERROR,''ORA-20020:'','' '')',
'                WHEN V_CODERROR=''-20030'' THEN replace(V_ERROR,''ORA-20030:'','' '')',
'                WHEN V_CODERROR=''-20040'' THEN replace(V_ERROR,''ORA-20040:'','' '')',
'                WHEN V_CODERROR=''-20050'' THEN replace(V_ERROR,''ORA-20050:'','' '')',
'            END ',
'            INTO  V_MENSAJE',
'        FROM DUAL;',
'',
'        :P103_RESUTADO:=v_resultado;',
'        apex_error.add_error (',
'            p_message          => ''Error en actualizar datos de formulaciones:''|| V_MENSAJE,',
'            p_display_location =>apex_error.c_inline_in_notification ',
'       );',
'    exception when others then ',
'            DBMS_OUTPUT.PUT_LINE(''  :SQLERRM:''||  SQLERRM);    ',
'    end;    ',
'END;',
'',
''))
,p_attribute_05=>'N'
,p_attribute_06=>'Y'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>'Valorizacion'
,p_process_when_type=>'REQUEST_EQUALS_CONDITION'
,p_exec_cond_for_each_row=>'Y'
,p_internal_uid=>105370325583721238
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(106832125157849112)
,p_process_sequence=>80
,p_process_point=>'AFTER_SUBMIT'
,p_region_id=>wwv_flow_imp.id(105368016250721215)
,p_process_type=>'NATIVE_IG_DML'
,p_process_name=>'Valorizacion- Save Interactive Grid Data_Grabar'
,p_attribute_01=>'REGION_SOURCE'
,p_attribute_05=>'Y'
,p_attribute_06=>'Y'
,p_attribute_08=>'Y'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>'Valorizacion'
,p_process_when_type=>'REQUEST_EQUALS_CONDITION'
,p_exec_cond_for_each_row=>'Y'
,p_process_success_message=>'datos almacenados'
,p_internal_uid=>106832125157849112
);
wwv_flow_imp.component_end;
end;
/
