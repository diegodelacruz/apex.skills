prompt --application/pages/page_00188
begin
--   Manifest
--     PAGE: 00188
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>109
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_page.create_page(
 p_id=>188
,p_name=>'GESTION TRIBUTARIA - PRUEBA DEPARTAMENTAL'
,p_alias=>'GESTION-TRIBUTARIA-PRUEBA-DEPARTAMENTAL'
,p_page_mode=>'MODAL'
,p_step_title=>'GESTION TRIBUTARIA - PRUEBA DEPARTAMENTAL'
,p_autocomplete_on_off=>'OFF'
,p_javascript_file_urls=>'https://cdnjs.cloudflare.com/ajax/libs/xlsx/0.18.5/xlsx.full.min.js'
,p_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'function f_render_pruebadepartamental_editable(p_data) { ',
'  // ===== Helpers base =====',
'  let json;',
'  try {',
'    json = typeof p_data === "string" ? JSON.parse(p_data) : JSON.parse(JSON.stringify(p_data || {}));',
'  } catch (e) { json = {}; }',
'',
'  // Limpieza de claves antiguas ID_COMPROBANTE*',
'  Object.keys(json).forEach(k => { if(/^ID_COMPROBANTE\d+$/.test(k)) delete json[k]; });',
'',
'  const contenedor = document.getElementById(''reporte-renta'');',
'  if (!contenedor) return;',
'',
'  function redondear2(val) {',
'    const n = Number.parseFloat(val);',
'    return Number.isFinite(n) ? Math.round(n * 100) / 100 : 0;',
'  }',
'  function toNumber(v) {',
'    if (v == null) return 0;',
'    const s = String(v).trim();',
'    if (!s) return 0;',
'    let t = s.replace(/[^0-9,.\-+]/g, '''');',
'    const lastComma = t.lastIndexOf('','');',
'    const lastDot   = t.lastIndexOf(''.'');',
'    if (lastComma > lastDot) { t = t.replace(/\./g, '''').replace('','', ''.''); } else { t = t.replace(/,/g, ''''); }',
'    const n = Number.parseFloat(t);',
'    return Number.isFinite(n) ? n : 0;',
'  }',
'  function isNumberish(v){ return !(v==='''' || v==null) && Number.isFinite(toNumber(v)); }',
'',
'  // ==== Fecha helpers ====',
'  function toInputDateValue(v){',
'    if(!v) return '''';',
'    const s = String(v).trim();',
'    if (/^\d{4}-\d{2}-\d{2}$/.test(s)) return s;               // yyyy-mm-dd',
'    const m = s.match(/^(\d{2})\/(\d{2})\/(\d{4})$/);           // dd/mm/yyyy',
'    if (m) return `${m[3]}-${m[2].padStart(2,''0'')}-${m[1].padStart(2,''0'')}`;',
'    const d = new Date(s);',
'    if (isNaN(d)) return '''';',
'    const mm = String(d.getMonth()+1).padStart(2,''0'');',
'    const dd = String(d.getDate()).padStart(2,''0'');',
'    return `${d.getFullYear()}-${mm}-${dd}`;',
'  }',
'  function fromInputDateValue(v){                                // yyyy-mm-dd -> dd/mm/yyyy',
'    if(!v) return '''';',
'    const [y,m,d] = v.split(''-'');',
'    if(!y || !m || !d) return '''';',
'    return `${d.padStart(2,''0'')}/${m.padStart(2,''0'')}/${y}`;',
'  }',
'  function getPeriodoMinISO(){',
'    const per = $v("P188_PERIODO");',
'    if(!per || !/^\d{6}$/.test(per)) return '''';',
'    const y = per.slice(0,4), m = per.slice(4,6);',
'    return `${y}-${m}-01`;',
'  }',
'',
'  function getBC() {',
'    let bc = $v("P188_BCDEPARTAMENAL");',
'    if (bc == null || bc === '''') bc = $v("P188_BCDEPARTAMENTAL");',
'    return toNumber(bc);',
'  }',
'',
'  function isTextKey(clave){',
'    return (',
'      /^FECHA\d+$/.test(clave) ||',
'      /^COMPROBANTE\d+$/.test(clave) ||',
'      /^DETALLE\d+$/.test(clave) ||',
'      clave === ''CUENTA''',
'    );',
'  }',
'',
'  // ===== Detalles =====',
'  const CAMPOS_DET = [''FECHA'',''COMPROBANTE'',''DETALLE'',''BI'',''IMP''];',
'  const MAX_FILAS = 6;',
'',
'  function getMaxIndiceDetalles() {',
'    let max = 0;',
'    Object.keys(json).forEach(k => {',
'      const m = k.match(/^(FECHA|COMPROBANTE|DETALLE|BI|IMP)(\d+)$/);',
'      if (m) max = Math.max(max, parseInt(m[2],10));',
'    });',
'    return max;',
'  }',
'',
'  function leerDetalles() {',
'    const n = getMaxIndiceDetalles();',
'    const arr = [];',
'    if (n === 0) {',
'      arr.push({ FECHA:'''', COMPROBANTE:'''', DETALLE:'''', BI:''0'', IMP:''0'' });',
'    } else {',
'      for (let i=1;i<=n;i++){',
'        const fila = {};',
'        CAMPOS_DET.forEach(c=> fila[c] = json[c + i] ?? '''');',
'        arr.push(fila);',
'      }',
'    }',
'    return arr;',
'  }',
'',
'  function limpiarDetallesEnJson() {',
'    Object.keys(json).forEach(k=>{',
'      if (/^(FECHA|COMPROBANTE|DETALLE|BI|IMP)\d+$/.test(k)) delete json[k];',
'    });',
'  }',
'',
'  function escribirDetalles(arr) {',
'    limpiarDetallesEnJson();',
'    arr.forEach((fila, idx)=>{',
'      const i = idx + 1;',
'      CAMPOS_DET.forEach(c=>{',
'        json[c + i] = fila[c] ?? '''';',
'      });',
'    });',
'  }',
'',
'  function agregarFila() {',
'    const arr = leerDetalles();',
'    if (arr.length >= MAX_FILAS) return;',
'    arr.push({ FECHA:'''', COMPROBANTE:'''', DETALLE:'''', BI:''0'', IMP:''0'' });',
'    escribirDetalles(arr);',
'    recalcularTotales();',
'  }',
'',
'  function eliminarFila(index0) {',
'    const arr = leerDetalles();',
'    if (index0<0 || index0>=arr.length) return;',
'    arr.splice(index0,1);',
'    escribirDetalles(arr);',
'    recalcularTotales();',
'  }',
'',
'  // ===== Render principal =====',
'  function render() {',
'    contenedor.innerHTML = '''';',
'',
'    const detalles = leerDetalles();',
'    const nFilas = detalles.length;',
'    const minISO = getPeriodoMinISO();',
'    const minAttr = minISO ? ` min="${minISO}"` : '''';',
'',
'    let html = `',
'      <style>',
'        table { border-collapse: collapse; width: 100%; font-size: 13px; }',
'        th, td { border: 1px solid #000; padding: 4px 6px; text-align: left; }',
'        th { background-color: #f2f2f2; }',
'        .seccion { margin-top: 12px; }',
'        .editable { background-color: #eaffea; }',
'        td[contenteditable="true"] { min-width: 80px; }',
'        .text-right { text-align: right; }',
'        .text-left { text-align: left; }',
'        .readonly { background-color:#f4f4f4; }',
'        .toolbar { display:flex; gap:8px; align-items:center; margin:8px 0; }',
'        .btn-icon { border:1px solid #ddd; background:#fff; padding:4px 8px; cursor:pointer; border-radius:4px; }',
'        .btn-icon:disabled { opacity:.4; cursor:not-allowed; }',
'        .btn-delete { border:none; background:transparent; cursor:pointer; }',
'        .btn-delete i { color:#b30000; }',
'        .acciones-col { width:40px; text-align:center; }',
'        input.date-input { width: 140px; height: 24px; }',
'      </style>',
'',
'      <div><strong>CUENTA: ${$v("P188_CUENTADESCRIPCION")} - </strong> ',
'        <span class="text-left" data-clave="CUENTA">${(json.CUENTA ?? '''')}</span>',
'      </div>',
'',
'      <div class="toolbar">',
'        <button id="btnAddDetalle" class="btn-icon"${nFilas>=MAX_FILAS ? '' disabled'' : ''''}>',
'          <i class="fa fa-plus"></i> Agregar detalle',
'        </button>',
'        <span style="font-size:12px;color:#666">(${nFilas}/${MAX_FILAS})</span>',
'      </div>',
'',
'      <div class="seccion">',
'        <table>',
'          <thead>',
'            <tr>',
'              <th>FECHA</th>',
'              <th>COMPROBANTE</th>',
'              <th>DETALLE</th>',
'              <th>BI</th>',
'              <th>IMP</th>',
'              <th class="acciones-col">Acc.</th>',
'            </tr>',
'          </thead>',
'          <tbody>`;',
'',
'    for (let i = 0; i < nFilas; i++) {',
'      const fila = detalles[i];',
'      html += `<tr>`;',
'',
'      CAMPOS_DET.forEach(campo => {',
'        const clave = campo + (i+1);',
'        const valor = (fila[campo] ?? '''');',
'',
'        if (campo === ''FECHA'') {',
'          const valISO = toInputDateValue(valor);',
'          html += `<td class="text-left"><input type="date" class="date-input" data-fecha="${clave}" value="${valISO}"${minAttr}></td>`;',
'          return;',
'        }',
'',
'        let mostrar, align;',
'        if (campo === ''COMPROBANTE'' || campo === ''DETALLE'') {',
'          mostrar = valor ?? '''';',
'          align   = ''text-left'';',
'        } else {',
'          const esNum = isNumberish(valor);',
'          mostrar = esNum ? redondear2(toNumber(valor)) : (valor ?? '''');',
'          align   = esNum ? ''text-right'' : ''text-left'';',
'        }',
'',
'        html += `<td contenteditable="true" class="editable ${align}" data-clave="${clave}" data-row="${i}">${mostrar}</td>`;',
'      });',
'',
'      html += `',
'        <td class="acciones-col">',
'          <button class="btn-delete" data-del="${i}" title="Eliminar">',
'            <i class="fa fa-trash-o"></i>',
'          </button>',
'        </td>',
'      `;',
'      html += `</tr>`;',
'    }',
'',
'    html += `</tbody></table></div>`;',
'',
unistr('    // ===== Secci\00F3n de deducciones ====='),
'    const filas = [',
'      { label: ''CON DEDUCCION'', prefijo: ''DDGASTOSEMP_CON_DEDUCCION'' },',
'      { label: ''SIN DEDUCCION'', prefijo: ''DDGASTOSEMP_SIN_DEDUCCION'' },',
'      { label: ''PERSONAL LIQUIDADO CON DEDUCCION'', prefijo: ''DDGASTOSPLQ_CON_DEDUCCION'' },',
'      { label: ''PERSONAL LIQUIDADO SIN DEDUCCION'', prefijo: ''DDGASTOSPLQ_SIN_DEDUCCION'' }',
'    ];',
'    const campos = [''EMPL'', ''BASE_IMP_MENSUAL'', ''DSCT_MES'', ''IMPORTE''];',
'',
'    html += `<div class="seccion">',
unistr('      <i><u>Deducci\00F3n de gastos:</u></i>'),
'      <table>',
'        <thead><tr><th></th>${campos.map(c => `<th>${c}</th>`).join('''')}</tr></thead>',
'        <tbody>`;',
'',
'    filas.forEach(fila => {',
'      html += `<tr><td>${fila.label}</td>`;',
'      campos.forEach(campo => {',
'        const clave = `${fila.prefijo}_${campo}`;',
'        const valor = (json[clave] ?? '''');',
'        const esNum = isNumberish(valor);',
'        const mostrar = esNum ? redondear2(toNumber(valor)) : valor;',
'        const align = esNum ? ''text-right'' : ''text-left'';',
'        const soloLectura = (fila.label === ''CON DEDUCCION'' && campo === ''DSCT_MES'');',
'',
'        if (soloLectura) {',
'          html += `<td class="${align} readonly">${mostrar}</td>`;',
'        } else {',
'          html += `<td contenteditable="true" class="editable ${align}" data-clave="${clave}">${mostrar}</td>`;',
'        }',
'      });',
'      html += `</tr>`;',
'    });',
'',
'    // Totales',
'    html += `<tr><td><strong>TOTAL EMPLEADOS</strong></td>`;',
'    campos.forEach(campo => {',
'      const clave = `TOTALES_${campo}`;',
'      const valor = (json[clave] ?? '''');',
'      const esNum = isNumberish(valor);',
'      const mostrar = esNum ? redondear2(toNumber(valor)) : valor;',
'      const align = esNum ? ''text-right'' : ''text-left'';',
'      html += `<td><strong class="${align}">${mostrar}</strong></td>`;',
'    });',
'    html += `</tr>`;',
'',
'    html += `</tbody></table></div>`;',
'',
'    // Totales finales',
'    const totalIR = redondear2(toNumber(json.TOTAL_IMPUESTO_RENTA));',
'    const bc = redondear2(getBC());',
'    const diferencia = redondear2(totalIR - bc);',
'',
'    html += `<div class="seccion" style="text-align:right; font-size:14px;">',
'      <strong>TOTAL IMPUESTO RENTA:</strong> ',
'      <span class="readonly">${totalIR}</span>',
'    </div>',
'    <div class="seccion" style="text-align:right; font-size:14px;">',
'      <strong>Bc:</strong> ',
'      <span class="readonly">${bc}</span>',
'    </div>',
'    <div class="seccion" style="text-align:right; font-size:14px;">',
'      <strong>DIFERENCIA:</strong> ',
'      <span class="readonly">${diferencia}</span>',
'    </div>`;',
'',
'    contenedor.innerHTML = html;',
'',
'    // ===== Eventos =====',
'    const btnAdd = contenedor.querySelector(''#btnAddDetalle'');',
'    if (btnAdd) btnAdd.addEventListener(''click'', agregarFila);',
'',
'    contenedor.querySelectorAll(''button[data-del]'').forEach(btn=>{',
'      btn.addEventListener(''click'', function(){',
'        const idx = parseInt(this.getAttribute(''data-del''),10);',
'        eliminarFila(idx);',
'      });',
'    });',
'',
unistr('    // Fecha: input type="date" con m\00EDnimo por P188_PERIODO'),
'    contenedor.querySelectorAll(''input[type="date"][data-fecha]'').forEach(inp=>{',
'      inp.addEventListener(''change'', function(){',
'        const clave = this.getAttribute(''data-fecha'');',
'        let iso = this.value || '''';',
'        const minISO2 = getPeriodoMinISO();',
'        if (minISO2 && iso && iso < minISO2) { iso = minISO2; this.value = minISO2; }',
'        json[clave] = fromInputDateValue(iso);',
'        $s(''P188_JSON'', JSON.stringify(json));',
'      });',
'    });',
'',
'    // Otras celdas editables',
'    contenedor.querySelectorAll(''.editable'').forEach(cell => {',
'      cell.addEventListener(''blur'', function () {',
'        const clave = this.dataset.clave;',
'        const txt = this.textContent.trim();',
'        if (isTextKey(clave)) {',
'          json[clave] = txt;',
'        } else {',
'          json[clave] = redondear2(toNumber(txt));',
'        }',
'        recalcularTotales();',
'      });',
'    });',
'',
'    $s(''P188_JSON'', JSON.stringify(json));',
'  }',
'',
unistr('  // ===== C\00E1lculos ====='),
'  function recalcularTotales() {',
'    let totalBI = 0;',
'    const n = getMaxIndiceDetalles();',
'    for (let i = 1; i <= n; i++) {',
'      totalBI += toNumber(json[''BI'' + i]);',
'    }',
'    json[''DDGASTOSEMP_CON_DEDUCCION_DSCT_MES''] = redondear2(totalBI);',
'',
'    const campos = [''EMPL'', ''BASE_IMP_MENSUAL'', ''DSCT_MES'', ''IMPORTE''];',
'    const claves = [',
'      ''DDGASTOSEMP_CON_DEDUCCION'',',
'      ''DDGASTOSEMP_SIN_DEDUCCION'',',
'      ''DDGASTOSPLQ_CON_DEDUCCION'',',
'      ''DDGASTOSPLQ_SIN_DEDUCCION''',
'    ];',
'    const total = {};',
'    campos.forEach(campo => {',
'      total[campo] = 0;',
'      claves.forEach(k => { total[campo] += toNumber(json[`${k}_${campo}`]); });',
'      json[`TOTALES_${campo}`] = redondear2(total[campo]);',
'    });',
'',
'    json[''TOTAL_IMPUESTO_RENTA''] = redondear2(total[''DSCT_MES'']);',
'    $s(''P188_JSON'', JSON.stringify(json));',
'    render();',
'  }',
'',
'  render();',
'}',
'',
'function f_render_pruebadepartamental_editable_v2(p_data) { ',
'  // ===== Helpers base =====',
'  let json;',
'  try {',
'    json = typeof p_data === "string" ? JSON.parse(p_data) : JSON.parse(JSON.stringify(p_data || {}));',
'  } catch (e) { json = {}; }',
'',
'  // Limpieza de claves antiguas ID_COMPROBANTE*',
'  Object.keys(json).forEach(k => { if(/^ID_COMPROBANTE\d+$/.test(k)) delete json[k]; });',
'',
'  const contenedor = document.getElementById(''reporte-renta'');',
'  if (!contenedor) return;',
'',
'  function redondear2(val) {',
'    const n = Number.parseFloat(val);',
'    return Number.isFinite(n) ? Math.round(n * 100) / 100 : 0;',
'  }',
'  function toNumber(v) {',
'    if (v == null) return 0;',
'    const s = String(v).trim();',
'    if (!s) return 0;',
'    let t = s.replace(/[^0-9,.\-+]/g, '''');',
'    const lastComma = t.lastIndexOf('','');',
'    const lastDot   = t.lastIndexOf(''.'');',
'    if (lastComma > lastDot) { t = t.replace(/\./g, '''').replace('','', ''.''); } else { t = t.replace(/,/g, ''''); }',
'    const n = Number.parseFloat(t);',
'    return Number.isFinite(n) ? n : 0;',
'  }',
'  function isNumberish(v){ return !(v==='''' || v==null) && Number.isFinite(toNumber(v)); }',
'',
'  // ==== Fecha helpers ====',
'  function toInputDateValue(v){',
'    if(!v) return '''';',
'    const s = String(v).trim();',
'    if (/^\d{4}-\d{2}-\d{2}$/.test(s)) return s;               // yyyy-mm-dd',
'    const m = s.match(/^(\d{2})\/(\d{2})\/(\d{4})$/);           // dd/mm/yyyy',
'    if (m) return `${m[3]}-${m[2].padStart(2,''0'')}-${m[1].padStart(2,''0'')}`;',
'    const d = new Date(s);',
'    if (isNaN(d)) return '''';',
'    const mm = String(d.getMonth()+1).padStart(2,''0'');',
'    const dd = String(d.getDate()).padStart(2,''0'');',
'    return `${d.getFullYear()}-${mm}-${dd}`;',
'  }',
'  function fromInputDateValue(v){                                // yyyy-mm-dd -> dd/mm/yyyy',
'    if(!v) return '''';',
'    const [y,m,d] = v.split(''-'');',
'    if(!y || !m || !d) return '''';',
'    return `${d.padStart(2,''0'')}/${m.padStart(2,''0'')}/${y}`;',
'  }',
'',
'  function getBC() {',
'    let bc = $v("P188_BCDEPARTAMENAL");',
'    if (bc == null || bc === '''') bc = $v("P188_BCDEPARTAMENTAL");',
'    return toNumber(bc);',
'  }',
'',
'  function isTextKey(clave){',
'    return (',
'      /^FECHA\d+$/.test(clave) ||',
'      /^COMPROBANTE\d+$/.test(clave) ||',
'      /^DETALLE\d+$/.test(clave) ||',
'      clave === ''CUENTA''',
'    );',
'  }',
'',
'  // ===== Detalles =====',
'  const CAMPOS_DET = [''FECHA'',''COMPROBANTE'',''DETALLE'',''BI'',''IMP''];',
'  const MAX_FILAS = 6;',
'',
'  function getMaxIndiceDetalles() {',
'    let max = 0;',
'    Object.keys(json).forEach(k => {',
'      const m = k.match(/^(FECHA|COMPROBANTE|DETALLE|BI|IMP)(\d+)$/);',
'      if (m) max = Math.max(max, parseInt(m[2],10));',
'    });',
'    return max;',
'  }',
'',
'  function leerDetalles() {',
'    const n = getMaxIndiceDetalles();',
'    const arr = [];',
'    if (n === 0) {',
'      arr.push({ FECHA:'''', COMPROBANTE:'''', DETALLE:'''', BI:''0'', IMP:''0'' });',
'    } else {',
'      for (let i=1;i<=n;i++){',
'        const fila = {};',
'        CAMPOS_DET.forEach(c=> fila[c] = json[c + i] ?? '''');',
'        arr.push(fila);',
'      }',
'    }',
'    return arr;',
'  }',
'',
'  function limpiarDetallesEnJson() {',
'    Object.keys(json).forEach(k=>{',
'      if (/^(FECHA|COMPROBANTE|DETALLE|BI|IMP)\d+$/.test(k)) delete json[k];',
'    });',
'  }',
'',
'  function escribirDetalles(arr) {',
'    limpiarDetallesEnJson();',
'    arr.forEach((fila, idx)=>{',
'      const i = idx + 1;',
'      CAMPOS_DET.forEach(c=>{',
'        json[c + i] = fila[c] ?? '''';',
'      });',
'    });',
'  }',
'',
'  function agregarFila() {',
'    const arr = leerDetalles();',
'    if (arr.length >= MAX_FILAS) return;',
'    arr.push({ FECHA:'''', COMPROBANTE:'''', DETALLE:'''', BI:''0'', IMP:''0'' });',
'    escribirDetalles(arr);',
'    recalcularTotales();',
'  }',
'',
'  function eliminarFila(index0) {',
'    const arr = leerDetalles();',
'    if (index0<0 || index0>=arr.length) return;',
'    arr.splice(index0,1);',
'    escribirDetalles(arr);',
'    recalcularTotales();',
'  }',
'',
'  // ===== Render principal =====',
'  function render() {',
'    contenedor.innerHTML = '''';',
'',
'    const detalles = leerDetalles();',
'    const nFilas = detalles.length;',
'',
'    let html = `',
'      <style>',
'        table { border-collapse: collapse; width: 100%; font-size: 13px; }',
'        th, td { border: 1px solid #000; padding: 4px 6px; text-align: left; }',
'        th { background-color: #f2f2f2; }',
'        .seccion { margin-top: 12px; }',
'        .editable { background-color: #eaffea; }',
'        td[contenteditable="true"] { min-width: 80px; }',
'        .text-right { text-align: right; }',
'        .text-left { text-align: left; }',
'        .readonly { background-color:#f4f4f4; }',
'        .toolbar { display:flex; gap:8px; align-items:center; margin:8px 0; }',
'        .btn-icon { border:1px solid #ddd; background:#fff; padding:4px 8px; cursor:pointer; border-radius:4px; }',
'        .btn-icon:disabled { opacity:.4; cursor:not-allowed; }',
'        .btn-delete { border:none; background:transparent; cursor:pointer; }',
'        .btn-delete i { color:#b30000; }',
'        .acciones-col { width:40px; text-align:center; }',
'        input.date-input { width: 140px; height: 24px; }',
'      </style>',
'',
'      <div><strong>CUENTA: ${$v("P188_CUENTADESCRIPCION")} - </strong> ',
'        <span class="text-left" data-clave="CUENTA">${(json.CUENTA ?? '''')}</span>',
'      </div>',
'',
'      <div class="toolbar">',
'        <button id="btnAddDetalle" class="btn-icon"${nFilas>=MAX_FILAS ? '' disabled'' : ''''}>',
'          <i class="fa fa-plus"></i> Agregar detalle',
'        </button>',
'        <span style="font-size:12px;color:#666">(${nFilas}/${MAX_FILAS})</span>',
'      </div>',
'',
'      <div class="seccion">',
'        <table>',
'          <thead>',
'            <tr>',
'              <th>FECHA</th>',
'              <th>COMPROBANTE</th>',
'              <th>DETALLE</th>',
'              <th>BI</th>',
'              <th>IMP</th>',
'              <th class="acciones-col">Acc.</th>',
'            </tr>',
'          </thead>',
'          <tbody>`;',
'',
'    for (let i = 0; i < nFilas; i++) {',
'      const fila = detalles[i];',
'      html += `<tr>`;',
'',
'      CAMPOS_DET.forEach(campo => {',
'        const clave = campo + (i+1);',
'        const valor = (fila[campo] ?? '''');',
'',
'        if (campo === ''FECHA'') {',
'          const valISO = toInputDateValue(valor);',
'          html += `<td class="text-left"><input type="date" class="date-input" data-fecha="${clave}" value="${valISO}"></td>`;',
'          return;',
'        }',
'',
'        let mostrar, align;',
'        if (campo === ''COMPROBANTE'' || campo === ''DETALLE'') {',
'          mostrar = valor ?? '''';',
'          align   = ''text-left'';',
'        } else {',
'          const esNum = isNumberish(valor);',
'          mostrar = esNum ? redondear2(toNumber(valor)) : (valor ?? '''');',
'          align   = esNum ? ''text-right'' : ''text-left'';',
'        }',
'',
'        html += `<td contenteditable="true" class="editable ${align}" data-clave="${clave}" data-row="${i}">${mostrar}</td>`;',
'      });',
'',
'      html += `',
'        <td class="acciones-col">',
'          <button class="btn-delete" data-del="${i}" title="Eliminar">',
'            <i class="fa fa-trash-o"></i>',
'          </button>',
'        </td>',
'      `;',
'      html += `</tr>`;',
'    }',
'',
'    html += `</tbody></table></div>`;',
'',
unistr('    // ===== Secci\00F3n de deducciones ====='),
'    const filas = [',
'      { label: ''CON DEDUCCION'', prefijo: ''DDGASTOSEMP_CON_DEDUCCION'' },',
'      { label: ''SIN DEDUCCION'', prefijo: ''DDGASTOSEMP_SIN_DEDUCCION'' },',
'      { label: ''PERSONAL LIQUIDADO CON DEDUCCION'', prefijo: ''DDGASTOSPLQ_CON_DEDUCCION'' },',
'      { label: ''PERSONAL LIQUIDADO SIN DEDUCCION'', prefijo: ''DDGASTOSPLQ_SIN_DEDUCCION'' }',
'    ];',
'    const campos = [''EMPL'', ''BASE_IMP_MENSUAL'', ''DSCT_MES'', ''IMPORTE''];',
'',
'    html += `<div class="seccion">',
unistr('      <i><u>Deducci\00F3n de gastos:</u></i>'),
'      <table>',
'        <thead><tr><th></th>${campos.map(c => `<th>${c}</th>`).join('''')}</tr></thead>',
'        <tbody>`;',
'',
'    filas.forEach(fila => {',
'      html += `<tr><td>${fila.label}</td>`;',
'      campos.forEach(campo => {',
'        const clave = `${fila.prefijo}_${campo}`;',
'        const valor = (json[clave] ?? '''');',
'        const esNum = isNumberish(valor);',
'        const mostrar = esNum ? redondear2(toNumber(valor)) : valor;',
'        const align = esNum ? ''text-right'' : ''text-left'';',
'        const soloLectura = (fila.label === ''CON DEDUCCION'' && campo === ''DSCT_MES'');',
'',
'        if (soloLectura) {',
'          html += `<td class="${align} readonly">${mostrar}</td>`;',
'        } else {',
'          html += `<td contenteditable="true" class="editable ${align}" data-clave="${clave}">${mostrar}</td>`;',
'        }',
'      });',
'      html += `</tr>`;',
'    });',
'',
'    // Totales',
'    html += `<tr><td><strong>TOTAL EMPLEADOS</strong></td>`;',
'    campos.forEach(campo => {',
'      const clave = `TOTALES_${campo}`;',
'      const valor = (json[clave] ?? '''');',
'      const esNum = isNumberish(valor);',
'      const mostrar = esNum ? redondear2(toNumber(valor)) : valor;',
'      const align = esNum ? ''text-right'' : ''text-left'';',
'      html += `<td><strong class="${align}">${mostrar}</strong></td>`;',
'    });',
'    html += `</tr>`;',
'',
'    html += `</tbody></table></div>`;',
'',
'    // Totales finales',
'    const totalIR = redondear2(toNumber(json.TOTAL_IMPUESTO_RENTA));',
'    const bc = redondear2(getBC());',
'    const diferencia = redondear2(totalIR - bc);',
'',
'    html += `<div class="seccion" style="text-align:right; font-size:14px;">',
'      <strong>TOTAL IMPUESTO RENTA:</strong> ',
'      <span class="readonly">${totalIR}</span>',
'    </div>',
'    <div class="seccion" style="text-align:right; font-size:14px;">',
'      <strong>Bc:</strong> ',
'      <span class="readonly">${bc}</span>',
'    </div>',
'    <div class="seccion" style="text-align:right; font-size:14px;">',
'      <strong>DIFERENCIA:</strong> ',
'      <span class="readonly">${diferencia}</span>',
'    </div>`;',
'',
'    contenedor.innerHTML = html;',
'',
'    // ===== Eventos =====',
'    const btnAdd = contenedor.querySelector(''#btnAddDetalle'');',
'    if (btnAdd) btnAdd.addEventListener(''click'', agregarFila);',
'',
'    contenedor.querySelectorAll(''button[data-del]'').forEach(btn=>{',
'      btn.addEventListener(''click'', function(){',
'        const idx = parseInt(this.getAttribute(''data-del''),10);',
'        eliminarFila(idx);',
'      });',
'    });',
'',
'    // Fecha: input type="date"',
'    contenedor.querySelectorAll(''input[type="date"][data-fecha]'').forEach(inp=>{',
'      inp.addEventListener(''change'', function(){',
'        const clave = this.getAttribute(''data-fecha'');',
'        json[clave] = fromInputDateValue(this.value);',
'        $s(''P188_JSON'', JSON.stringify(json));',
'        // No recalcula totales. Si se requiere refresco visual, llamar render();',
'      });',
'    });',
'',
'    // Otras celdas editables',
'    contenedor.querySelectorAll(''.editable'').forEach(cell => {',
'      cell.addEventListener(''blur'', function () {',
'        const clave = this.dataset.clave;',
'        const txt = this.textContent.trim();',
'        if (isTextKey(clave)) {',
'          json[clave] = txt;',
'        } else {',
'          json[clave] = redondear2(toNumber(txt));',
'        }',
'        recalcularTotales();',
'      });',
'    });',
'',
'    $s(''P188_JSON'', JSON.stringify(json));',
'  }',
'',
unistr('  // ===== C\00E1lculos ====='),
'  function recalcularTotales() {',
'    let totalBI = 0;',
'    const n = getMaxIndiceDetalles();',
'    for (let i = 1; i <= n; i++) {',
'      totalBI += toNumber(json[''BI'' + i]);',
'    }',
'    json[''DDGASTOSEMP_CON_DEDUCCION_DSCT_MES''] = redondear2(totalBI);',
'',
'    const campos = [''EMPL'', ''BASE_IMP_MENSUAL'', ''DSCT_MES'', ''IMPORTE''];',
'    const claves = [',
'      ''DDGASTOSEMP_CON_DEDUCCION'',',
'      ''DDGASTOSEMP_SIN_DEDUCCION'',',
'      ''DDGASTOSPLQ_CON_DEDUCCION'',',
'      ''DDGASTOSPLQ_SIN_DEDUCCION''',
'    ];',
'    const total = {};',
'    campos.forEach(campo => {',
'      total[campo] = 0;',
'      claves.forEach(k => { total[campo] += toNumber(json[`${k}_${campo}`]); });',
'      json[`TOTALES_${campo}`] = redondear2(total[campo]);',
'    });',
'',
'    json[''TOTAL_IMPUESTO_RENTA''] = redondear2(total[''DSCT_MES'']);',
'    $s(''P188_JSON'', JSON.stringify(json));',
'    render();',
'  }',
'',
'  render();',
'}',
'',
'',
'',
unistr('// ======= Exportar a Excel (sin cambios de l\00F3gica) ======='),
'function f_exportar_reporte_completo_excel() {',
'  const contenedor = document.getElementById(''reporte-renta'');',
'  if (!contenedor) {',
unistr('    alert(''No se encontr\00F3 la regi\00F3n'');'),
'    return;',
'  }',
'  if (typeof XLSX === ''undefined'' || !XLSX.utils) {',
unistr('    alert(''No est\00E1 cargada la librer\00EDa XLSX'');'),
'    return;',
'  }',
'',
'  const tmp = document.createElement(''table'');',
'  tmp.style.borderCollapse = ''collapse'';',
'  tmp.style.fontSize = ''13px'';',
'',
'  let json;',
'  try { json = JSON.parse($v(''P188_JSON'')); } catch(e){ json = {}; }',
'  const filaCuenta = tmp.insertRow();',
'  const celdaCuenta = filaCuenta.insertCell();',
'  celdaCuenta.colSpan = 10;',
'  celdaCuenta.innerHTML = `<strong>CUENTA:</strong> ${json.CUENTA ?? ''''}`;',
'',
'  const tablas = contenedor.querySelectorAll(''table'');',
'  tablas.forEach(tabla => {',
'    tabla.querySelectorAll(''tr'').forEach(tr => {',
'      const nuevaFila = tmp.insertRow();',
'      tr.querySelectorAll(''th, td'').forEach(td => {',
'        const nuevaCelda = nuevaFila.insertCell();',
unistr('        // Evita copiar los botones (toman texto vac\00EDo)'),
'        nuevaCelda.innerHTML = td.innerText;',
'        nuevaCelda.style.textAlign = td.style.textAlign || ''left'';',
'      });',
'    });',
'    tmp.insertRow(); // separador',
'  });',
'',
'  const filaFinal = tmp.insertRow();',
'  const celdaFinal = filaFinal.insertCell();',
'  celdaFinal.colSpan = 10;',
'  celdaFinal.innerHTML = `<strong>TOTAL IMPUESTO RENTA:</strong> ${json.TOTAL_IMPUESTO_RENTA ?? 0}`;',
'',
'  const wb = XLSX.utils.book_new();',
'  const ws = XLSX.utils.table_to_sheet(tmp);',
'  XLSX.utils.book_append_sheet(wb, ws, "Reporte Renta");',
'  XLSX.writeFile(wb, ''Reporte_Renta.xlsx'');',
'}',
''))
,p_javascript_code_onload=>wwv_flow_string.join(wwv_flow_t_varchar2(
'$(secItems).hide();',
'let data = JSON.parse($v(''P188_JSON''));',
'f_render_pruebadepartamental_editable(data);',
''))
,p_step_template=>wwv_flow_imp.id(37774372912106498)
,p_page_template_options=>'#DEFAULT#'
,p_dialog_chained=>'N'
,p_protection_level=>'C'
,p_page_component_map=>'16'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(42166626447330527)
,p_plug_name=>'BARRA DE BOTONES'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(38290276266120143)
,p_plug_display_sequence=>60
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(42167105827330532)
,p_plug_name=>'items'
,p_region_name=>'secItems'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(38289867500120143)
,p_plug_display_sequence=>80
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(60503441704174906)
,p_plug_name=>'ReporteRenta'
,p_region_name=>'reporte-renta'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(38289867500120143)
,p_plug_display_sequence=>20
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(58701837235752236)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(42166626447330527)
,p_button_name=>'Notify'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860181880106559)
,p_button_image_alt=>'Notificar'
,p_warn_on_unsaved_changes=>null
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(42502853682630857)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(42166626447330527)
,p_button_name=>'CLOSE'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860181880106559)
,p_button_image_alt=>'Cerrar'
,p_warn_on_unsaved_changes=>null
,p_grid_new_row=>'N'
,p_grid_new_column=>'N'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(42503819612630858)
,p_button_sequence=>50
,p_button_plug_id=>wwv_flow_imp.id(42166626447330527)
,p_button_name=>'SAVE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860181880106559)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Guadar'
,p_grid_new_row=>'N'
,p_grid_new_column=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(42168260874330543)
,p_name=>'P188_IDDAT'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(42167105827330532)
,p_prompt=>'Iddat'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(60503395840174905)
,p_name=>'P188_JSON'
,p_data_type=>'CLOB'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(42167105827330532)
,p_prompt=>'Json'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>30
,p_cHeight=>5
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(60503781076174909)
,p_name=>'P188_BCCTACONTABLE'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(42167105827330532)
,p_prompt=>'Bcctacontable'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_grid_label_column_span=>3
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(60503940407174911)
,p_name=>'P188_BCDEPARTAMENTAL'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(42167105827330532)
,p_prompt=>'Bcdepartamental'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(60504038176174912)
,p_name=>'P188_PERIODO'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(42167105827330532)
,p_prompt=>'Periodo'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(60504163043174913)
,p_name=>'P188_CUENTANUMERO'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(42167105827330532)
,p_prompt=>'Cuentanumero'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(60504293186174914)
,p_name=>'P188_CUENTADESCRIPCION'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(42167105827330532)
,p_prompt=>'Cuentadescripcion'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(58701934394752237)
,p_name=>'Notificar'
,p_event_sequence=>40
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(58701837235752236)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(58702193650752239)
,p_event_id=>wwv_flow_imp.id(58701934394752237)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'mostrarBarra();'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(58702075553752238)
,p_event_id=>wwv_flow_imp.id(58701934394752237)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE ',
'    p_mesaje          clob:=''<p><strong>Estimado Usuario</strong></p>',
unistr('<p>La presente tiene como objeto, indicar que no se ha procesado la informaci\00F3n de prueba departamental misma que debe ser ingresada hasta maximo el dia 8 de cada mes</p>'';'),
'    p_valor         varchar2(100):=''PDEP'';',
' begin',
'    pk_finz_gestiontributaria.sp_notifiacion(p_mesaje,p_valor);',
' end;'))
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(58702228381752240)
,p_event_id=>wwv_flow_imp.id(58701934394752237)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'mensajeExito("Se ha notificado correctamente");',
'ocultarBarra();'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(60503597557174907)
,p_name=>'Cerrar'
,p_event_sequence=>50
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(42502853682630857)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(60503671559174908)
,p_event_id=>wwv_flow_imp.id(60503597557174907)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CLOSE'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(42505458963630868)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Process Create - PRUEBA DEPARTAMENTAL'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
'    update  data.t_finz_gestiontributariadatos dat set DATOSINI= :P188_JSON, DATOSMOD= :P188_JSON, DATOSFIN= :P188_JSON where dat.id=:P188_IDDAT;',
'EXCEPTION WHEN OTHERS THEN ',
'    apex_error.add_error (',
'    p_message          => ''ERROR::''||SQLERRM  ,',
'    p_display_location =>apex_error.c_inline_in_notification );',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>42505458963630868
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(42168018743330541)
,p_process_sequence=>20
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Initialize'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
'    IF NOT APEX_COLLECTION.COLLECTION_EXISTS(''PRUEBA_DEPARTAMENTAL'') THEN',
'        APEX_COLLECTION.CREATE_COLLECTION(''PRUEBA_DEPARTAMENTAL'');',
'    END IF;',
'    IF APEX_COLLECTION.COLLECTION_EXISTS(''PRUEBA_DEPARTAMENTAL'') THEN',
'        APEX_COLLECTION.TRUNCATE_COLLECTION(''PRUEBA_DEPARTAMENTAL'');',
'    END IF;',
'',
'    :P188_IDDAT:=nvl(:P188_IDDAT,:G_VALOR1);',
'    select ',
'        dat.datosmod,GTB.PERIODO INTO :P188_JSON,:P188_PERIODO',
'    from data.t_finz_gestiontributaria gtb',
'    inner join data.t_finz_gestiontributariadet det ON gtb.id=det.idgtb',
'    inner join data.t_finz_gestiontributariadatos dat on det.id=dat.iddet',
'    WHERE dat.id =:P188_IDDAT;',
'',
'    select ',
'    --ID, PERIODO,  BUSQ,',
'    DESCRIP_BALANCE, CTA_BALANCE,',
'    PK_FINZ_GESTIONTRIBUTARIA.f_trer_valorbalance (PERIODO,BUSQ,TIPO_BUSQ_BC) BC',
'    into :P188_CUENTADESCRIPCION,:P188_CUENTANUMERO,:P188_BCDEPARTAMENTAL',
'    from ( ',
'    SELECT ROWNUM ID , --ID, TIPO_RESUMEN, TIPO_BUSQ_BC, PERIODO, VENTA_BRUTA, VENTA_NETA, IVA_VENTAS',
'    PK_FINZ_GESTIONTRIBUTARIA.f_trae_descripcioncuenta(''BC_RET_EMP'',''P'',''D'') DESCRIP_BALANCE,',
'    PK_FINZ_GESTIONTRIBUTARIA.f_trae_descripcioncuenta(''BC_RET_EMP'',''P'',''C'') CTA_BALANCE,',
'    PK_FINZ_GESTIONTRIBUTARIA.f_trae_descripcioncuenta(''BC_RET_EMP'',''P'',''C'') BUSQ',
'    , ''C'' TIPO_BUSQ_BC',
'    , :P188_PERIODO PERIODO',
'',
'    FROM DUAL D',
'',
'    );',
'    :P188_BCDEPARTAMENTAL:=replace(:P188_BCDEPARTAMENTAL,'','',''.'');',
'    IF (:P188_JSON IS NULL)THEN ',
'		--:P188_JSON:=''{"CUENTA":"''||:P188_CUENTANUMERO||''","FECHA1":"DD/MM/YYYY","COMPROBANTE1":"","DETALLE1":"","BI1":0.00,"IMP1":0.00,"FECHA2":"DD/MM/YYYY","COMPROBANTE2":"","DETALLE2":"","BI2":0.00,"IMP2":0.00,"FECHA3":"DD/MM/YYYY","COMPROBANTE3":"","D'
||'ETALLE3":"","BI3":0.00,"IMP3":0.00,"FECHA4":"DD/MM/YYYY","COMPROBANTE4":"","DETALLE4":"","BI4":0.00,"IMP4":0.00,"FECHA5":"DD/MM/YYYY","COMPROBANTE5":"","DETALLE5":"","BI5":0.00,"IMP5":0.00,"DDGASTOSEMP_CON_DEDUCCION_EMPL":0,"DDGASTOSEMP_CON_DEDUCCION'
||'_BASE_IMP_MENSUAL":0.00,"DDGASTOSEMP_CON_DEDUCCION_DSCT_MES":0.00,"DDGASTOSEMP_CON_DEDUCCION_IMPORTE":0.00,"DDGASTOSEMP_SIN_DEDUCCION_EMPL":0,"DDGASTOSEMP_SIN_DEDUCCION_BASE_IMP_MENSUAL":0.00,"DDGASTOSEMP_SIN_DEDUCCION_DSCT_MES":0.00,"DDGASTOSEMP_SIN'
||'_DEDUCCION_IMPORTE":0.00,"DDGASTOSPLQ_CON_DEDUCCION_EMPL":0,"DDGASTOSPLQ_CON_DEDUCCION_BASE_IMP_MENSUAL":0.00,"DDGASTOSPLQ_CON_DEDUCCION_DSCT_MES":0.00,"DDGASTOSPLQ_CON_DEDUCCION_IMPORTE":0.00,"DDGASTOSPLQ_SIN_DEDUCCION_EMPL":0,"DDGASTOSPLQ_SIN_DEDUC'
||'CION_BASE_IMP_MENSUAL":0.00,"DDGASTOSPLQ_SIN_DEDUCCION_DSCT_MES":0.00,"DDGASTOSPLQ_SIN_DEDUCCION_IMPORTE":0.00,"TOTALES_EMPL":0,"TOTALES_BASE_IMP_MENSUAL":0.00,"TOTALES_DSCT_MES":0.00,"TOTALES_IMPORTE":0.00,"TOTAL_IMPUESTO_RENTA":0.00}'';',
'		:P188_JSON:=''{"CUENTA":"''||:P188_CUENTANUMERO||''","DDGASTOSEMP_CON_DEDUCCION_EMPL":0.00,"DDGASTOSEMP_CON_DEDUCCION_BASE_IMP_MENSUAL":0.00,"DDGASTOSEMP_CON_DEDUCCION_DSCT_MES":0.00,"DDGASTOSEMP_CON_DEDUCCION_IMPORTE":0.00,"DDGASTOSEMP_SIN_DEDUCCION_'
||'EMPL":0.00,"DDGASTOSEMP_SIN_DEDUCCION_BASE_IMP_MENSUAL":0.00,"DDGASTOSEMP_SIN_DEDUCCION_DSCT_MES":0.00,"DDGASTOSEMP_SIN_DEDUCCION_IMPORTE":0.00,"DDGASTOSPLQ_CON_DEDUCCION_EMPL":0.00,"DDGASTOSPLQ_CON_DEDUCCION_BASE_IMP_MENSUAL":0.00,"DDGASTOSPLQ_CON_D'
||'EDUCCION_DSCT_MES":0.00,"DDGASTOSPLQ_CON_DEDUCCION_IMPORTE":0.00,"DDGASTOSPLQ_SIN_DEDUCCION_EMPL":0.00,"DDGASTOSPLQ_SIN_DEDUCCION_BASE_IMP_MENSUAL":0.00,"DDGASTOSPLQ_SIN_DEDUCCION_DSCT_MES":0.00,"DDGASTOSPLQ_SIN_DEDUCCION_IMPORTE":0.00,"TOTALES_EMPL"'
||':0.00,"TOTALES_BASE_IMP_MENSUAL":0.00,"TOTALES_DSCT_MES":0.00,"TOTALES_IMPORTE":0.00,"TOTAL_IMPUESTO_RENTA":0.00}'';',
'    END IF;',
'    ',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>42168018743330541
);
wwv_flow_imp.component_end;
end;
/
