prompt --application/pages/page_groups
begin
--   Manifest
--     PAGE GROUPS: 109
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>109
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(37885355684106626)
,p_group_name=>'Administration'
);
wwv_flow_imp.component_end;
end;
/
