prompt --application/pages/page_00177
begin
--   Manifest
--     PAGE: 00177
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>109
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_page.create_page(
 p_id=>177
,p_name=>'Valida Tipo Despedicio'
,p_alias=>'VALIDA-TIPO-DESPEDICIO'
,p_step_title=>'Valida Tipo Despedicio'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_page_component_map=>'21'
,p_created_on=>wwv_flow_imp.dz('20250527195327Z')
,p_last_updated_on=>wwv_flow_imp.dz('20250801161729Z')
,p_created_by=>'DBURBANO'
,p_last_updated_by=>'DBURBANO'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(24903152661498633)
,p_plug_name=>'Filtros'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(38289867500120143)
,p_plug_display_sequence=>10
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
,p_created_on=>wwv_flow_imp.dz('20250527195707Z')
,p_updated_on=>wwv_flow_imp.dz('20250527195707Z')
,p_created_by=>'DBURBANO'
,p_updated_by=>'DBURBANO'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(24903342250498635)
,p_plug_name=>'BarraAcciones'
,p_parent_plug_id=>wwv_flow_imp.id(24903152661498633)
,p_region_template_options=>'#DEFAULT#:t-Form--stretchInputs'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(38289497777120142)
,p_plug_display_sequence=>30
,p_location=>null
,p_menu_id=>wwv_flow_imp.id(37761271469106475)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(37860983999106559)
,p_created_on=>wwv_flow_imp.dz('20250527195811Z')
,p_updated_on=>wwv_flow_imp.dz('20250527212010Z')
,p_created_by=>'DBURBANO'
,p_updated_by=>'DBURBANO'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(40820637077078930)
,p_plug_name=>'Breadcrumb'
,p_title=>'Valida Tipo Desperdicio'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(37817215439106526)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_location=>null
,p_menu_id=>wwv_flow_imp.id(37761271469106475)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(37860983999106559)
,p_created_on=>wwv_flow_imp.dz('20250527195327Z')
,p_updated_on=>wwv_flow_imp.dz('20250527195511Z')
,p_created_by=>'DBURBANO'
,p_updated_by=>'DBURBANO'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(40821387203078936)
,p_plug_name=>'Valida Tipo Despedicio'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(37806762584106520)
,p_plug_display_sequence=>30
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'-- Busca las transacciones marcadas como costo de desperdicio que no lo son en realidad',
unistr('-- Busca las transacciones tipo PM1 que est\00E1n ligadas a ordenes de producci\00F3n en estato 82, para cada transacci\00F3n PM1 valido'),
unistr('-- que no se haya generado un transacci\00F3n IC (IC indica que son consumos normales y no de desperdicio)'),
'SELECT f.ilukid AS id, TRIM(f.ilmcu) AS bodega, f.ildoco AS orden, f.illitm item, f.iltrqt/10000 cantidad, f.ilpaid/100 preciototal, f.ilrcd motivo',
'     , TO_DATE(f.ilcrdj + 1900000,''yyyyddd'') Fecha, LPAD(f.iltday, 6, ''0'') Hora',
'  FROM F4111@jdedtadl f, (SELECT d1.ILMCU, d1.ILDOCO, d1.ILCRDJ, d1.ILTDAY',
'                            FROM (SELECT k.ilmcu, k.ildoco, k.ilrcd, k.ilcrdj, iltday, count(*), (SELECT count(*)',
'                                                                                                    FROM F4111@jdedtadl k1',
'                                                                                                   WHERE k1.ilmcu = k.ilmcu',
'                                                                                                     AND k1.ildoco = k.ildoco',
'                                                                                                     AND k1.ilcrdj = k.ilcrdj',
'                                                                                                     AND (k1.iltday BETWEEN k.iltday AND k.iltday + 1 )',
'                                                                                                     AND k1.ildct = ''IC'') as valida',
'                                    FROM F4111@jdedtadl k',
'                                   WHERE k.ilmcu = lpad(:P177_BODEGA, 12) ',
'                                     AND k.ilrcd = ''PM1''',
'--                                     AND k.iltday BETWEEN 65650 AND 65655',
'                                     AND k.ildoco IN (SELECT o.wadoco',
'                                                        FROM f4801@jdedtadl o',
'                                                       WHERE o.wasrst = ''82''',
'--                                                         AND o.wadoco = 1432331',
'                                                         AND o.wadcto IN (''WO'', ''WE'')',
'                                                         AND o.wammcu = lpad(:P177_BODEGA, 12))',
'                                   GROUP BY k.ilmcu, k.ildoco, k.ilrcd, k.ilcrdj, iltday) d1 WHERE valida > 0) d2',
' WHERE f.ilmcu = d2.ilmcu',
'   AND f.ildoco = d2.ildoco',
'   AND f.ilcrdj = d2.ilcrdj',
'   AND f.iltday = d2.iltday',
'',
'/*',
'SELECT d3.*',
'       , (TO_DATE(hora2, ''HH24MISS'') - TO_DATE(hora1, ''HH24MISS'')) * 24 * 60 * 60 AS diferencia_en_segundos',
'FROM',
'(',
'SELECT ILMCU Bodega, ILDOCO Orden_Prod, ILLITM Item, CANTIDAD, PRECIOTOTAL, ILUKID ID, MOTIVO, ',
'       TO_DATE(ilcrdj + 1900000,''yyyyddd'') Fecha ',
'       , LPAD(ILTDAY, 6, ''0'') Hora1',
'       , LPAD(Hora2, 6, ''0'') Hora2 ',
'FROM',
'(',
'SELECT d1.*,',
'       (SELECT MIN(k1.iltday)',
'          FROM F4111@jdedtadl k1',
'         WHERE k1.ilmcu = d1.ilmcu',
'           AND k1.ildoco = d1.ildoco',
'           AND k1.ilcrdj = d1.ilcrdj',
'           AND k1.iltday > d1.iltday',
unistr('           AND k1.ildct = ''IS'') as Hora2 --Hora de la diguiente transacci\00F3n IS'),
'FROM ',
'(',
'SELECT k.ilmcu, k.ildoco, k.illitm, k.iltrqt/10000 cantidad, k.ilpaid/100 preciototal, k.ilukid, k.ilrcd Motivo, k.ilcrdj, iltday, ',
'       (SELECT MAX(k1.ilukid)',
'          FROM F4111@jdedtadl k1',
'         WHERE k1.ilmcu = k.ilmcu',
'           AND k1.ildoco = k.ildoco',
'           AND k1.ilcrdj = k.ilcrdj',
'--           AND k1.iltday = k.iltday',
'           AND (k1.iltday BETWEEN k.iltday AND k.iltday + 1 )',
'           AND k1.ildct = ''IS'') as valida',
'  FROM F4111@jdedtadl k',
' WHERE k.ilmcu = lpad(:P177_BODEGA, 12) ',
'   AND k.ilrcd = ''PM1''',
'   AND k.ildoco IN (SELECT o.wadoco',
'                      FROM f4801@jdedtadl o',
'                     WHERE o.wasrst = ''82''',
'                       AND o.wadcto IN (''WO'', ''WE'')',
'                       AND o.wammcu = lpad(:P177_BODEGA, 12)',
'                      -- AND o.wadoco = 1422141',
'                    )',
'   ',
'ORDER BY k.ilukid',
') d1',
'WHERE d1.VALIDA IS NULL',
') d2',
') d3 WHERE ABS((TO_DATE(hora2, ''HH24MISS'') - TO_DATE(hora1, ''HH24MISS'')) * 24 * 60 * 60) > 1',
';',
'*/'))
,p_plug_source_type=>'NATIVE_IG'
,p_prn_page_header=>'Valida Tipo Despedicio'
,p_created_on=>wwv_flow_imp.dz('20250527195327Z')
,p_updated_on=>wwv_flow_imp.dz('20250801161728Z')
,p_created_by=>'DBURBANO'
,p_updated_by=>'DBURBANO'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(24903691992498638)
,p_name=>'APEX$ROW_ACTION'
,p_item_type=>'NATIVE_ROW_ACTION'
,p_display_sequence=>20
,p_updated_on=>wwv_flow_imp.dz('20250527200934Z')
,p_updated_by=>'DBURBANO'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(24903780057498639)
,p_name=>'APEX$ROW_SELECTOR'
,p_item_type=>'NATIVE_ROW_SELECTOR'
,p_display_sequence=>10
,p_attribute_01=>'Y'
,p_attribute_02=>'Y'
,p_attribute_03=>'N'
,p_updated_on=>wwv_flow_imp.dz('20250527200935Z')
,p_updated_by=>'DBURBANO'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(24904113008498643)
,p_name=>'ID'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'ID'
,p_data_type=>'NUMBER'
,p_is_query_only=>false
,p_item_type=>'NATIVE_NUMBER_FIELD'
,p_heading=>'Id'
,p_heading_alignment=>'RIGHT'
,p_display_sequence=>140
,p_value_alignment=>'RIGHT'
,p_attribute_03=>'left'
,p_attribute_04=>'decimal'
,p_is_required=>true
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
,p_updated_on=>wwv_flow_imp.dz('20250527211551Z')
,p_updated_by=>'DBURBANO'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(40822656468078960)
,p_name=>'BODEGA'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'BODEGA'
,p_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>'Bodega'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>30
,p_value_alignment=>'LEFT'
,p_attribute_05=>'BOTH'
,p_is_required=>false
,p_max_length=>12
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_enable_pivot=>false
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
,p_updated_on=>wwv_flow_imp.dz('20250527200935Z')
,p_updated_by=>'DBURBANO'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(40824516471078965)
,p_name=>'ITEM'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'ITEM'
,p_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>'Item'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>50
,p_value_alignment=>'LEFT'
,p_attribute_05=>'BOTH'
,p_is_required=>false
,p_max_length=>25
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_enable_pivot=>false
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
,p_updated_on=>wwv_flow_imp.dz('20250527200936Z')
,p_updated_by=>'DBURBANO'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(40825545027078966)
,p_name=>'CANTIDAD'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'CANTIDAD'
,p_data_type=>'NUMBER'
,p_is_query_only=>false
,p_item_type=>'NATIVE_NUMBER_FIELD'
,p_heading=>'Cantidad'
,p_heading_alignment=>'RIGHT'
,p_display_sequence=>60
,p_value_alignment=>'RIGHT'
,p_attribute_03=>'left'
,p_attribute_04=>'decimal'
,p_is_required=>false
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_enable_pivot=>false
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
,p_updated_on=>wwv_flow_imp.dz('20250527200936Z')
,p_updated_by=>'DBURBANO'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(40826541023078967)
,p_name=>'PRECIOTOTAL'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'PRECIOTOTAL'
,p_data_type=>'NUMBER'
,p_is_query_only=>false
,p_item_type=>'NATIVE_NUMBER_FIELD'
,p_heading=>'Preciototal'
,p_heading_alignment=>'RIGHT'
,p_display_sequence=>70
,p_value_alignment=>'RIGHT'
,p_attribute_03=>'left'
,p_attribute_04=>'decimal'
,p_is_required=>false
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_enable_pivot=>false
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
,p_updated_on=>wwv_flow_imp.dz('20250527200936Z')
,p_updated_by=>'DBURBANO'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(40828557709078968)
,p_name=>'MOTIVO'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'MOTIVO'
,p_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>'Motivo'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>90
,p_value_alignment=>'LEFT'
,p_attribute_05=>'BOTH'
,p_is_required=>false
,p_max_length=>3
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_enable_pivot=>false
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
,p_updated_on=>wwv_flow_imp.dz('20250527200936Z')
,p_updated_by=>'DBURBANO'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(40829512385078969)
,p_name=>'FECHA'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'FECHA'
,p_data_type=>'DATE'
,p_is_query_only=>false
,p_item_type=>'NATIVE_DATE_PICKER_APEX'
,p_heading=>'Fecha'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>100
,p_value_alignment=>'LEFT'
,p_attribute_01=>'N'
,p_attribute_02=>'POPUP'
,p_attribute_03=>'NONE'
,p_attribute_06=>'NONE'
,p_attribute_09=>'N'
,p_attribute_11=>'Y'
,p_is_required=>false
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_date_ranges=>'ALL'
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_enable_pivot=>false
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
,p_updated_on=>wwv_flow_imp.dz('20250527200936Z')
,p_updated_by=>'DBURBANO'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(124051955479591018)
,p_name=>'ORDEN'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'ORDEN'
,p_data_type=>'NUMBER'
,p_is_query_only=>false
,p_item_type=>'NATIVE_NUMBER_FIELD'
,p_heading=>'Orden'
,p_heading_alignment=>'RIGHT'
,p_display_sequence=>150
,p_value_alignment=>'RIGHT'
,p_attribute_03=>'left'
,p_attribute_04=>'decimal'
,p_is_required=>false
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
,p_updated_on=>wwv_flow_imp.dz('20250801161615Z')
,p_updated_by=>'DBURBANO'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(124052013762591019)
,p_name=>'HORA'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'HORA'
,p_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>'Hora'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>160
,p_value_alignment=>'LEFT'
,p_attribute_05=>'BOTH'
,p_is_required=>false
,p_max_length=>6
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
,p_updated_on=>wwv_flow_imp.dz('20250801161615Z')
,p_updated_by=>'DBURBANO'
);
wwv_flow_imp_page.create_interactive_grid(
 p_id=>wwv_flow_imp.id(40821807416078937)
,p_internal_uid=>40821807416078937
,p_is_editable=>true
,p_lost_update_check_type=>'VALUES'
,p_submit_checked_rows=>false
,p_lazy_loading=>false
,p_requires_filter=>false
,p_select_first_row=>true
,p_fixed_row_height=>true
,p_pagination_type=>'SCROLL'
,p_show_total_row_count=>true
,p_show_toolbar=>true
,p_enable_save_public_report=>false
,p_enable_subscriptions=>true
,p_enable_flashback=>true
,p_define_chart_view=>true
,p_enable_download=>true
,p_enable_mail_download=>true
,p_fixed_header=>'PAGE'
,p_show_icon_view=>false
,p_show_detail_view=>false
,p_updated_on=>wwv_flow_imp.dz('20250801161728Z')
,p_updated_by=>'DBURBANO'
);
wwv_flow_imp_page.create_ig_report(
 p_id=>wwv_flow_imp.id(40822204166078938)
,p_interactive_grid_id=>wwv_flow_imp.id(40821807416078937)
,p_static_id=>'408223'
,p_type=>'PRIMARY'
,p_default_view=>'GRID'
,p_show_row_number=>false
,p_settings_area_expanded=>true
,p_updated_on=>wwv_flow_imp.dz('20250801161728Z')
,p_updated_by=>'DBURBANO'
);
wwv_flow_imp_page.create_ig_report_view(
 p_id=>wwv_flow_imp.id(40822496893078941)
,p_report_id=>wwv_flow_imp.id(40822204166078938)
,p_view_type=>'GRID'
,p_stretch_columns=>true
,p_srv_exclude_null_values=>false
,p_srv_only_display_columns=>true
,p_edit_mode=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(40822919734078963)
,p_view_id=>wwv_flow_imp.id(40822496893078941)
,p_display_seq=>3
,p_column_id=>wwv_flow_imp.id(40822656468078960)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(40824982899078966)
,p_view_id=>wwv_flow_imp.id(40822496893078941)
,p_display_seq=>5
,p_column_id=>wwv_flow_imp.id(40824516471078965)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(40825972511078966)
,p_view_id=>wwv_flow_imp.id(40822496893078941)
,p_display_seq=>6
,p_column_id=>wwv_flow_imp.id(40825545027078966)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(40826995352078967)
,p_view_id=>wwv_flow_imp.id(40822496893078941)
,p_display_seq=>7
,p_column_id=>wwv_flow_imp.id(40826541023078967)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(40828908673078968)
,p_view_id=>wwv_flow_imp.id(40822496893078941)
,p_display_seq=>8
,p_column_id=>wwv_flow_imp.id(40828557709078968)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(40829922493078969)
,p_view_id=>wwv_flow_imp.id(40822496893078941)
,p_display_seq=>9
,p_column_id=>wwv_flow_imp.id(40829512385078969)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(40872120491175663)
,p_view_id=>wwv_flow_imp.id(40822496893078941)
,p_display_seq=>1
,p_column_id=>wwv_flow_imp.id(24903691992498638)
,p_is_visible=>true
,p_is_frozen=>true
,p_width=>53
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(41022184381573353)
,p_view_id=>wwv_flow_imp.id(40822496893078941)
,p_display_seq=>2
,p_column_id=>wwv_flow_imp.id(24904113008498643)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(126150970170695406)
,p_view_id=>wwv_flow_imp.id(40822496893078941)
,p_display_seq=>4
,p_column_id=>wwv_flow_imp.id(124051955479591018)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(126151841434695418)
,p_view_id=>wwv_flow_imp.id(40822496893078941)
,p_display_seq=>10
,p_column_id=>wwv_flow_imp.id(124052013762591019)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(24903548972498637)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(24903342250498635)
,p_button_name=>'Buscar'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860056812106557)
,p_button_image_alt=>'Buscar'
,p_icon_css_classes=>'fa-search'
,p_grid_new_row=>'Y'
,p_grid_column=>11
,p_created_on=>wwv_flow_imp.dz('20250527195932Z')
,p_updated_on=>wwv_flow_imp.dz('20250527212443Z')
,p_created_by=>'DBURBANO'
,p_updated_by=>'DBURBANO'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(24904369755498645)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(24903342250498635)
,p_button_name=>'Corregir'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860056812106557)
,p_button_image_alt=>'Corregir'
,p_confirm_message=>unistr('Se modificar\00E1 el Motivo de Los Items seleccionados, este pasar\00E1 a ser  "   " ')
,p_icon_css_classes=>'fa-database-check'
,p_grid_new_row=>'N'
,p_grid_column=>12
,p_created_on=>wwv_flow_imp.dz('20250527212348Z')
,p_updated_on=>wwv_flow_imp.dz('20250527212615Z')
,p_created_by=>'DBURBANO'
,p_updated_by=>'DBURBANO'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(24903217765498634)
,p_name=>'P177_BODEGA'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(24903152661498633)
,p_prompt=>'Bodega'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'STATIC:ABSORBENTE;17005,COSMETICA;17009,ENVASES;17016'
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_created_on=>wwv_flow_imp.dz('20250527195707Z')
,p_updated_on=>wwv_flow_imp.dz('20250527195707Z')
,p_created_by=>'DBURBANO'
,p_updated_by=>'DBURBANO'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(24904200625498644)
,p_name=>'P177_IDS'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(24903152661498633)
,p_prompt=>unistr('Selecci\00F3n:')
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_created_on=>wwv_flow_imp.dz('20250527212011Z')
,p_updated_on=>wwv_flow_imp.dz('20250527212208Z')
,p_created_by=>'DBURBANO'
,p_updated_by=>'DBURBANO'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(24903951090498641)
,p_name=>'da_select'
,p_event_sequence=>10
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(40821387203078936)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'NATIVE_IG|REGION TYPE|interactivegridselectionchange'
,p_created_on=>wwv_flow_imp.dz('20250527202735Z')
,p_updated_on=>wwv_flow_imp.dz('20250527212134Z')
,p_created_by=>'DBURBANO'
,p_updated_by=>'DBURBANO'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(24904065505498642)
,p_event_id=>wwv_flow_imp.id(24903951090498641)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'var i, i_ids = ":", i_id,',
'model = this.data.model;',
'for ( i = 0; i < this.data.selectedRecords.length; i++ ) {',
'    i_id = model.getValue( this.data.selectedRecords[i], "ID");',
'    i_ids += model.getValue( this.data.selectedRecords[i], "ID") + ":";',
'}',
'apex.item( "P177_IDS" ).setValue (i_ids);'))
,p_created_on=>wwv_flow_imp.dz('20250527202735Z')
,p_updated_on=>wwv_flow_imp.dz('20250527212134Z')
,p_created_by=>'DBURBANO'
,p_updated_by=>'DBURBANO'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(24903887753498640)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_region_id=>wwv_flow_imp.id(40821387203078936)
,p_process_type=>'NATIVE_IG_DML'
,p_process_name=>'Valida Tipo Despedicio - Save Interactive Grid Data'
,p_attribute_01=>'REGION_SOURCE'
,p_attribute_05=>'Y'
,p_attribute_06=>'Y'
,p_attribute_08=>'Y'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>24903887753498640
,p_created_on=>wwv_flow_imp.dz('20250527200934Z')
,p_updated_on=>wwv_flow_imp.dz('20250527200934Z')
,p_created_by=>'DBURBANO'
,p_updated_by=>'DBURBANO'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(24904439992498646)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Procesar'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
'if :P177_IDS = '':'' then',
'    APEX_ERROR.ADD_ERROR(p_message => ''Debe seleccionar al menos un item!'' , p_display_location => APEX_ERROR.C_INLINE_IN_NOTIFICATION);',
'else',
'    FOR rec IN (SELECT Column_Value AS ilukid_val FROM TABLE(APEX_STRING.SPLIT(RTRIM(LTRIM(:P177_IDS, '':''), '':''), '':''))) LOOP',
'        UPDATE F4111@jdedtadl SET ilrcd = ''   '' ',
'        WHERE ilukid = TO_NUMBER(rec.ilukid_val); ',
'    END LOOP;',
'    COMMIT;',
'END IF;',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(24904369755498645)
,p_internal_uid=>24904439992498646
,p_created_on=>wwv_flow_imp.dz('20250527213729Z')
,p_updated_on=>wwv_flow_imp.dz('20250527230635Z')
,p_created_by=>'DBURBANO'
,p_updated_by=>'DBURBANO'
);
wwv_flow_imp.component_end;
end;
/
