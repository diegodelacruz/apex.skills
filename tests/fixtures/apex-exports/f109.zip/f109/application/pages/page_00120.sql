prompt --application/pages/page_00120
begin
--   Manifest
--     PAGE: 00120
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>109
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_page.create_page(
 p_id=>120
,p_name=>'Listado de Liquidaciones por Orden de Compra'
,p_alias=>'LISTADO-DE-LIQUIDACIONES-POR-ORDEN-DE-COMPRA'
,p_page_mode=>'MODAL'
,p_step_title=>'Listado de Liquidaciones por Orden de Compra'
,p_autocomplete_on_off=>'OFF'
,p_javascript_code_onload=>'$(secItems).hide();'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.a-IRR-toolbar {',
'    border: #e6e6e6;',
'    background: linear-gradient(#00a65a,#00a65a);',
'    height: 30px;',
'    padding-bottom: 0px;',
'}'))
,p_step_template=>wwv_flow_imp.id(37781137309106503)
,p_page_template_options=>'#DEFAULT#'
,p_dialog_height=>'500'
,p_dialog_width=>'1300'
,p_dialog_max_width=>'1300'
,p_protection_level=>'C'
,p_page_component_map=>'18'
,p_created_on=>wwv_flow_imp.dz('20230711153637Z')
,p_last_updated_on=>wwv_flow_imp.dz('20260313172959Z')
,p_created_by=>'EMASABANDA'
,p_last_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(24937011565073001)
,p_plug_name=>'REPORTE'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(37806762584106520)
,p_plug_display_sequence=>30
,p_include_in_reg_disp_sel_yn=>'Y'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ID',
', SELECCION',
', ORDENCOMPRAID',
', ORDENCOMPRATIPO',
', CREALIQFECHA',
', LIQUIDACIONPERIODO',
', LIQUIDACIONVALOR12',
', LIQUIDACIONVALOR0',
', LIQUIDACIONPERIODO_V',
', LIQUIDACIONVALOR12_V',
', LIQUIDACIONVALOR0_V',
', LIQUIDACIONVALORTOTAL',
', POCENTAJE/:P120_MONTO_MAXIMO POCENTAJE',
', REGISTROUSUARIO',
', REGISTROFECHA',
', ESLIQUIDACIONGENERADA',
', ESTADO',
', CREALIQ',
', EDITDET ',
', CASE WHEN PK_CORP_FLUJOAPROBACION.F_APROBADORFLUJO(:APP_USER, APROBADOR, :APP_MODULO ,:G_COMPANIA) =1',
unistr('  THEN ''<a href="'' ||PK_FINZ_GLIQ_DINAMICAS.f_gliq_url_docuemento(''GLIQ'',''APROBAR'')||''?detalleId=''||detalleId||''&token=''||token ||''" target="_blank"><span title="Aprobar Liquidaci\00F3n: '' || NUMLIQUIDACIONGENERADA||''" id="''||ID||''"  class="ApobLiq fa fa')
||'-thumbs-up "> </span></a>''',
'  ELSE '''' end url',
', Detalle',
', Objetivo',
'from vt_gliq_dinamicas_detalle',
'where ORDENCOMPRAID=:P120_NUMERO_ORDEN_COMPRA',
'order by id;'))
,p_plug_source_type=>'NATIVE_IR'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'REPORTE'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
,p_created_on=>wwv_flow_imp.dz('20230711153755Z')
,p_updated_on=>wwv_flow_imp.dz('20230711212503Z')
,p_created_by=>'EMASABANDA'
,p_updated_by=>'EMASABANDA'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(24937163325073002)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_show_search_textbox=>'N'
,p_show_actions_menu=>'N'
,p_report_list_mode=>'NONE'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_enable_mail_download=>'Y'
,p_owner=>'EMASABANDA'
,p_internal_uid=>24937163325073002
,p_created_on=>wwv_flow_imp.dz('20230711153755Z')
,p_updated_on=>wwv_flow_imp.dz('20230711212503Z')
,p_created_by=>'EMASABANDA'
,p_updated_by=>'EMASABANDA'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(24937291319073003)
,p_db_column_name=>'ID'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'<span style="color:#0572ce" >Id.</span>'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20230711153755Z')
,p_updated_on=>wwv_flow_imp.dz('20230711155014Z')
,p_created_by=>'EMASABANDA'
,p_updated_by=>'EMASABANDA'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(24937383024073004)
,p_db_column_name=>'SELECCION'
,p_display_order=>40
,p_column_identifier=>'B'
,p_column_label=>'<span title="Seleccion Detalle" style="color:#0572ce" >Sel.</span>'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_column_alignment=>'CENTER'
,p_display_condition_type=>'EXISTS'
,p_display_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT COUNT(1) existe',
'FROM t_finz_gliq_detalleoc',
'WHERE ordencompraid = :p120_numero_orden_compra',
'AND ordencompratipo = :p120_tipo_orden_compra',
'AND esliquidaciongenerada = 0',
'HAVING COUNT(1) > 0'))
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20230711153755Z')
,p_updated_on=>wwv_flow_imp.dz('20230711202017Z')
,p_created_by=>'EMASABANDA'
,p_updated_by=>'EMASABANDA'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(24937638637073007)
,p_db_column_name=>'CREALIQFECHA'
,p_display_order=>70
,p_column_identifier=>'E'
,p_column_label=>'Fec. Liquid.'
,p_column_type=>'STRING'
,p_display_condition_type=>'EXISTS'
,p_display_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT 1 existe',
'FROM VT_GLIQ_DINAMICAS_DETALLE a WHERE  LIQUIDACIONPERIODO IS NOT NULL AND ORDENCOMPRAID=:P120_NUMERO_ORDEN_COMPRA',
' '))
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20230711153756Z')
,p_updated_on=>wwv_flow_imp.dz('20230711160054Z')
,p_created_by=>'EMASABANDA'
,p_updated_by=>'EMASABANDA'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(24937751109073008)
,p_db_column_name=>'LIQUIDACIONPERIODO'
,p_display_order=>80
,p_column_identifier=>'F'
,p_column_label=>'Liquidacionperiodo'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20230711153756Z')
,p_updated_on=>wwv_flow_imp.dz('20230711155014Z')
,p_created_by=>'EMASABANDA'
,p_updated_by=>'EMASABANDA'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(24938064953073011)
,p_db_column_name=>'LIQUIDACIONPERIODO_V'
,p_display_order=>100
,p_column_identifier=>'I'
,p_column_label=>'Liquidacionperiodo V'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20230711153756Z')
,p_updated_on=>wwv_flow_imp.dz('20230711155014Z')
,p_created_by=>'EMASABANDA'
,p_updated_by=>'EMASABANDA'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(24938162772073012)
,p_db_column_name=>'LIQUIDACIONVALOR12_V'
,p_display_order=>110
,p_column_identifier=>'J'
,p_column_label=>'Liquidacionvalor12 V'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20230711153756Z')
,p_updated_on=>wwv_flow_imp.dz('20230711155014Z')
,p_created_by=>'EMASABANDA'
,p_updated_by=>'EMASABANDA'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(24938257824073013)
,p_db_column_name=>'LIQUIDACIONVALOR0_V'
,p_display_order=>120
,p_column_identifier=>'K'
,p_column_label=>'Liquidacionvalor0 V'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20230711153756Z')
,p_updated_on=>wwv_flow_imp.dz('20230711155014Z')
,p_created_by=>'EMASABANDA'
,p_updated_by=>'EMASABANDA'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(24937977879073010)
,p_db_column_name=>'LIQUIDACIONVALOR0'
,p_display_order=>130
,p_column_identifier=>'H'
,p_column_label=>'<span style="color:#0572ce" >Subtotal 0%</span>'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G990D00'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20230711153756Z')
,p_updated_on=>wwv_flow_imp.dz('20230711171727Z')
,p_created_by=>'EMASABANDA'
,p_updated_by=>'EMASABANDA'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(24937873261073009)
,p_db_column_name=>'LIQUIDACIONVALOR12'
,p_display_order=>140
,p_column_identifier=>'G'
,p_column_label=>'<span style="color:#0572ce" >Subtotal 12%</span>'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G990D00'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20230711153756Z')
,p_updated_on=>wwv_flow_imp.dz('20230711171727Z')
,p_created_by=>'EMASABANDA'
,p_updated_by=>'EMASABANDA'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(24938359256073014)
,p_db_column_name=>'LIQUIDACIONVALORTOTAL'
,p_display_order=>150
,p_column_identifier=>'L'
,p_column_label=>'<span style="color:#0572ce" >Total</span>'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G990D00'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20230711153756Z')
,p_updated_on=>wwv_flow_imp.dz('20230711171727Z')
,p_created_by=>'EMASABANDA'
,p_updated_by=>'EMASABANDA'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(24938459488073015)
,p_db_column_name=>'POCENTAJE'
,p_display_order=>160
,p_column_identifier=>'M'
,p_column_label=>'%'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20230711153756Z')
,p_updated_on=>wwv_flow_imp.dz('20230711185257Z')
,p_created_by=>'EMASABANDA'
,p_updated_by=>'EMASABANDA'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(24938710618073018)
,p_db_column_name=>'ESLIQUIDACIONGENERADA'
,p_display_order=>190
,p_column_identifier=>'P'
,p_column_label=>'<span title="Liquidacion Generada" style="color:#0572ce" >Liq.</span>'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20230711153756Z')
,p_updated_on=>wwv_flow_imp.dz('20230711185402Z')
,p_created_by=>'EMASABANDA'
,p_updated_by=>'EMASABANDA'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(24938867886073019)
,p_db_column_name=>'ESTADO'
,p_display_order=>200
,p_column_identifier=>'Q'
,p_column_label=>'<span title="Estado Detalle" style="color:#0572ce" >Est.</span>'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20230711153756Z')
,p_updated_on=>wwv_flow_imp.dz('20230711185402Z')
,p_created_by=>'EMASABANDA'
,p_updated_by=>'EMASABANDA'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(24938934387073020)
,p_db_column_name=>'CREALIQ'
,p_display_order=>210
,p_column_identifier=>'R'
,p_column_label=>'<span title="Crear/Ver Liquidacion" style="color:#0572ce" class="fa fa-file-archive-o"></span>'
,p_column_link=>'JavaScript:$s("P120_IDPROCESA",'''');$s("P120_IDPROCESA",#ID#);'
,p_column_linktext=>'#CREALIQ#'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_column_alignment=>'CENTER'
,p_display_condition_type=>'EXISTS'
,p_display_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT  * ',
'FROM VT_GLIQ_DINAMICAS_DETALLE a WHERE CreaLiq IS NOT NULL AND ORDENCOMPRAID=:P120_NUMERO_ORDEN_COMPRA'))
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20230711153756Z')
,p_updated_on=>wwv_flow_imp.dz('20230711185402Z')
,p_created_by=>'EMASABANDA'
,p_updated_by=>'EMASABANDA'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(24939008533073021)
,p_db_column_name=>'EDITDET'
,p_display_order=>220
,p_column_identifier=>'S'
,p_column_label=>'<span class="fa fa-pencil"></span>'
,p_column_link=>'JavaScript:$s("P120_IDEDITAR",'''');$s("P120_IDEDITAR",#ID#);$s("P120_PERIODO",'''');$s("P120_PERIODO",''#CREALIQFECHA#'');$s("P120_SUBTOTAL12",'''');$s("P120_SUBTOTAL12",#LIQUIDACIONVALOR12_V#);$s("P120_SUBTOTAL0",'''');$s("P120_SUBTOTAL0",#LIQUIDACIONVALOR0_'
||'V#);'
,p_column_linktext=>'#EDITDET#'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_column_alignment=>'CENTER'
,p_display_condition_type=>'NEVER'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20230711153756Z')
,p_updated_on=>wwv_flow_imp.dz('20230711212503Z')
,p_created_by=>'EMASABANDA'
,p_updated_by=>'EMASABANDA'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(24939276686073023)
,p_db_column_name=>'DETALLE'
,p_display_order=>240
,p_column_identifier=>'U'
,p_column_label=>'Detalle'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20230711153756Z')
,p_updated_on=>wwv_flow_imp.dz('20230711184820Z')
,p_created_by=>'EMASABANDA'
,p_updated_by=>'EMASABANDA'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(24939321536073024)
,p_db_column_name=>'OBJETIVO'
,p_display_order=>250
,p_column_identifier=>'V'
,p_column_label=>'Objetivo'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20230711153756Z')
,p_updated_on=>wwv_flow_imp.dz('20230711184820Z')
,p_created_by=>'EMASABANDA'
,p_updated_by=>'EMASABANDA'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(24939112649073022)
,p_db_column_name=>'URL'
,p_display_order=>260
,p_column_identifier=>'T'
,p_column_label=>'Url'
,p_column_type=>'STRING'
,p_display_condition_type=>'EXISTS'
,p_display_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT DISTINCT CONS.URL FROM (select ',
'CASE WHEN PK_CORP_FLUJOAPROBACION.F_APROBADORFLUJO(:APP_USER, APROBADOR, :APP_MODULO ,:G_COMPANIA) =1',
unistr('  THEN ''<a href="'' ||PK_FINZ_GLIQ_DINAMICAS.f_gliq_url_docuemento(''GLIQ'',''APROBAR'')||''?detalleId=''||detalleId||''&token=''||token ||''" target="_blank"><span title="Aprobar Liquidaci\00F3n: '' || NUMLIQUIDACIONGENERADA||''" id="''||ID||''"  class="ApobLiq fa fa')
||'-thumbs-up "> </span></a>''',
'  ELSE '''' end url',
'from vt_gliq_dinamicas_detalle',
'where ORDENCOMPRAID= :p120_numero_orden_compra )CONS',
'WHERE  CONS.URL IS NOT NULL',
';'))
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20230711153756Z')
,p_updated_on=>wwv_flow_imp.dz('20230711205445Z')
,p_created_by=>'EMASABANDA'
,p_updated_by=>'EMASABANDA'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(24937429123073005)
,p_db_column_name=>'ORDENCOMPRAID'
,p_display_order=>270
,p_column_identifier=>'C'
,p_column_label=>'Numero'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_created_on=>wwv_flow_imp.dz('20230711153755Z')
,p_updated_on=>wwv_flow_imp.dz('20230711155014Z')
,p_created_by=>'EMASABANDA'
,p_updated_by=>'EMASABANDA'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(24937512411073006)
,p_db_column_name=>'ORDENCOMPRATIPO'
,p_display_order=>280
,p_column_identifier=>'D'
,p_column_label=>'Tipo'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_created_on=>wwv_flow_imp.dz('20230711153755Z')
,p_updated_on=>wwv_flow_imp.dz('20230711155014Z')
,p_created_by=>'EMASABANDA'
,p_updated_by=>'EMASABANDA'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(24938531597073016)
,p_db_column_name=>'REGISTROUSUARIO'
,p_display_order=>290
,p_column_identifier=>'N'
,p_column_label=>'Registrousuario'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_created_on=>wwv_flow_imp.dz('20230711153756Z')
,p_updated_on=>wwv_flow_imp.dz('20230711155014Z')
,p_created_by=>'EMASABANDA'
,p_updated_by=>'EMASABANDA'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(24938675202073017)
,p_db_column_name=>'REGISTROFECHA'
,p_display_order=>300
,p_column_identifier=>'O'
,p_column_label=>'Registrofecha'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_created_on=>wwv_flow_imp.dz('20230711153756Z')
,p_updated_on=>wwv_flow_imp.dz('20230711155014Z')
,p_created_by=>'EMASABANDA'
,p_updated_by=>'EMASABANDA'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(24950962092078085)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'249510'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'SELECCION:LIQUIDACIONVALOR12:LIQUIDACIONVALOR0:LIQUIDACIONVALORTOTAL:POCENTAJE:DETALLE:OBJETIVO:ESLIQUIDACIONGENERADA:ESTADO:CREALIQ:EDITDET:'
,p_created_on=>wwv_flow_imp.dz('20230711153757Z')
,p_updated_on=>wwv_flow_imp.dz('20230711211408Z')
,p_created_by=>'EMASABANDA'
,p_updated_by=>'EMASABANDA'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(24939683173073027)
,p_plug_name=>'items'
,p_region_name=>'secItems'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(38289867500120143)
,p_plug_display_sequence=>40
,p_include_in_reg_disp_sel_yn=>'Y'
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
,p_created_on=>wwv_flow_imp.dz('20230711153919Z')
,p_updated_on=>wwv_flow_imp.dz('20230711211837Z')
,p_created_by=>'EMASABANDA'
,p_updated_by=>'EMASABANDA'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(24940783290073038)
,p_plug_name=>unistr('Datos \00F3rden compra ')
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(38289867500120143)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
,p_created_on=>wwv_flow_imp.dz('20230711160315Z')
,p_updated_on=>wwv_flow_imp.dz('20230711160316Z')
,p_created_by=>'EMASABANDA'
,p_updated_by=>'EMASABANDA'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(24940876370073039)
,p_plug_name=>'Datos'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(38289867500120143)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_new_grid_row=>false
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
,p_created_on=>wwv_flow_imp.dz('20230711160315Z')
,p_updated_on=>wwv_flow_imp.dz('20230711164425Z')
,p_created_by=>'EMASABANDA'
,p_updated_by=>'EMASABANDA'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(25726307169605530)
,p_plug_name=>'Footer'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(38290276266120143)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'REGION_POSITION_03'
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
,p_created_on=>wwv_flow_imp.dz('20230711204213Z')
,p_updated_on=>wwv_flow_imp.dz('20230711212555Z')
,p_created_by=>'EMASABANDA'
,p_updated_by=>'EMASABANDA'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(25726428395605531)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(25726307169605530)
,p_button_name=>'Cerrar'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860181880106559)
,p_button_image_alt=>'Cerrar'
,p_created_on=>wwv_flow_imp.dz('20230711204213Z')
,p_updated_on=>wwv_flow_imp.dz('20230711212556Z')
,p_created_by=>'EMASABANDA'
,p_updated_by=>'EMASABANDA'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(25343654324556618)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(24937011565073001)
,p_button_name=>'Agregar2'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860056812106557)
,p_button_image_alt=>'Agregar2'
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
,p_warn_on_unsaved_changes=>null
,p_button_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select 1 from T_FINZ_GLIQ_DETALLEOC',
'where 1=1',
'and ORDENCOMPRAID=:P120_NUMERO_ORDEN_COMPRA',
'and ORDENCOMPRATIPO=:P120_TIPO_ORDEN_COMPRA',
'HAVING nvl(SUM(LIQUIDACIONVALOR12+ LIQUIDACIONVALOR0),0) <:P120_MONTO_MAXIMO'))
,p_button_condition_type=>'EXISTS'
,p_icon_css_classes=>'fa-plus-circle'
,p_created_on=>wwv_flow_imp.dz('20230711185746Z')
,p_updated_on=>wwv_flow_imp.dz('20230711212556Z')
,p_created_by=>'EMASABANDA'
,p_updated_by=>'EMASABANDA'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(25343797835556619)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(24937011565073001)
,p_button_name=>'Grabar'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860056812106557)
,p_button_image_alt=>'Grabar'
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
,p_warn_on_unsaved_changes=>null
,p_button_condition_type=>'NEVER'
,p_icon_css_classes=>'fa-floppy-o'
,p_created_on=>wwv_flow_imp.dz('20230711185746Z')
,p_updated_on=>wwv_flow_imp.dz('20230711212556Z')
,p_created_by=>'EMASABANDA'
,p_updated_by=>'EMASABANDA'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(25343915235556621)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(24937011565073001)
,p_button_name=>'BorrarSeleccion'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860056812106557)
,p_button_image_alt=>unistr('Borrar Selecci\00F3n')
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
,p_warn_on_unsaved_changes=>null
,p_button_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select distinct 1 from T_FINZ_GLIQ_DETALLEOC',
'where (nvl(esliquidaciongenerada, 0)=0)',
'and ORDENCOMPRAID=:P120_NUMERO_ORDEN_COMPRA',
'and ORDENCOMPRATIPO=:P120_TIPO_ORDEN_COMPRA'))
,p_button_condition_type=>'EXISTS'
,p_icon_css_classes=>'fa-minus-circle'
,p_created_on=>wwv_flow_imp.dz('20230711185746Z')
,p_updated_on=>wwv_flow_imp.dz('20260313172430Z')
,p_created_by=>'EMASABANDA'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(25344057990556622)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(24937011565073001)
,p_button_name=>'BorrarTodo'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860056812106557)
,p_button_image_alt=>'Borrar Todo'
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
,p_warn_on_unsaved_changes=>null
,p_button_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ''x'' from T_FINZ_GLIQ_DETALLEOC',
'where ORDENCOMPRAID = :P120_NUMERO_ORDEN_COMPRA',
'	and (:p120_banderagliq > 0',
'		or (ESLIQUIDACIONGENERADA = 1 and  ORDENCOMPRATIPO=:P120_TIPO_ORDEN_COMPRA))'))
,p_button_condition_type=>'EXISTS'
,p_icon_css_classes=>'fa-trash'
,p_created_on=>wwv_flow_imp.dz('20230711190012Z')
,p_updated_on=>wwv_flow_imp.dz('20260313172959Z')
,p_created_by=>'EMASABANDA'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(25344104863556623)
,p_button_sequence=>50
,p_button_plug_id=>wwv_flow_imp.id(24937011565073001)
,p_button_name=>'Refrescar'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860056812106557)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Refrescar'
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
,p_button_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT 1 ',
'FROM VT_GLIQ_DINAMICAS_DETALLE a WHERE CreaLiq IS NOT NULL AND ORDENCOMPRAID=:P120_NUMERO_ORDEN_COMPRA',
'UNION ALL',
'SELECT 1 FROM (select ',
'CASE WHEN PK_CORP_FLUJOAPROBACION.F_APROBADORFLUJO(:APP_USER, APROBADOR, :APP_MODULO ,:G_COMPANIA) =1',
unistr('  THEN ''<a href="'' ||PK_FINZ_GLIQ_DINAMICAS.f_gliq_url_docuemento(''GLIQ'',''APROBAR'')||''?detalleId=''||detalleId||''&token=''||token ||''" target="_blank"><span title="Aprobar Liquidaci\00F3n: '' || NUMLIQUIDACIONGENERADA||''" id="''||ID||''"  class="ApobLiq fa fa')
||'-thumbs-up "> </span></a>''',
'  ELSE '''' end url',
'from vt_gliq_dinamicas_detalle',
'where ORDENCOMPRAID= :P120_numero_orden_compra )CONS',
'WHERE  CONS.URL IS NOT NULL',
';'))
,p_button_condition_type=>'EXISTS'
,p_icon_css_classes=>'fa fa-refresh'
,p_created_on=>wwv_flow_imp.dz('20230711190012Z')
,p_updated_on=>wwv_flow_imp.dz('20230711212556Z')
,p_created_by=>'EMASABANDA'
,p_updated_by=>'EMASABANDA'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(25344279506556624)
,p_button_sequence=>60
,p_button_plug_id=>wwv_flow_imp.id(24937011565073001)
,p_button_name=>'CotejarRecepcion'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860056812106557)
,p_button_image_alt=>unistr('Cotejar Recepci\00F3n')
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
,p_button_condition=>'SELECT PRUOPN, PRAOPN FROM F43121@JDEDTADL WHERE PRDOCO=:P120_NUMERO_ORDEN_COMPRA AND  PRDCTO=:p120_tipo_orden_compra AND  PRAOPN>0'
,p_button_condition_type=>'EXISTS'
,p_icon_css_classes=>'fa-cogs'
,p_created_on=>wwv_flow_imp.dz('20230711190012Z')
,p_updated_on=>wwv_flow_imp.dz('20260313172331Z')
,p_created_by=>'EMASABANDA'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(24939791493073028)
,p_name=>'P120_NUMERO_ORDEN_COMPRA'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(24940783290073038)
,p_prompt=>unistr('N\00FAm. Orden Compra')
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(37859556976106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
,p_created_on=>wwv_flow_imp.dz('20230711153919Z')
,p_updated_on=>wwv_flow_imp.dz('20230711212555Z')
,p_created_by=>'EMASABANDA'
,p_updated_by=>'EMASABANDA'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(24939893067073029)
,p_name=>'P120_PERIODO'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(24939683173073027)
,p_prompt=>'Periodo'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_created_on=>wwv_flow_imp.dz('20230711154524Z')
,p_updated_on=>wwv_flow_imp.dz('20230711212555Z')
,p_created_by=>'EMASABANDA'
,p_updated_by=>'EMASABANDA'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(24939938535073030)
,p_name=>'P120_MONTO_FALTANTE'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(24939683173073027)
,p_prompt=>'Monto Faltante'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_created_on=>wwv_flow_imp.dz('20230711154524Z')
,p_updated_on=>wwv_flow_imp.dz('20230711212556Z')
,p_created_by=>'EMASABANDA'
,p_updated_by=>'EMASABANDA'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(24940022127073031)
,p_name=>'P120_MENSAJE'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(24939683173073027)
,p_prompt=>'Mensaje'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_created_on=>wwv_flow_imp.dz('20230711154524Z')
,p_updated_on=>wwv_flow_imp.dz('20230711212556Z')
,p_created_by=>'EMASABANDA'
,p_updated_by=>'EMASABANDA'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(24940161374073032)
,p_name=>'P120_MONTO_MAXIMO'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(24939683173073027)
,p_prompt=>'Monto Maximo'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_created_on=>wwv_flow_imp.dz('20230711154524Z')
,p_updated_on=>wwv_flow_imp.dz('20230711212556Z')
,p_created_by=>'EMASABANDA'
,p_updated_by=>'EMASABANDA'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(24940281657073033)
,p_name=>'P120_IDACTIVA'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(24939683173073027)
,p_prompt=>'Idactiva'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_created_on=>wwv_flow_imp.dz('20230711154524Z')
,p_updated_on=>wwv_flow_imp.dz('20230711212556Z')
,p_created_by=>'EMASABANDA'
,p_updated_by=>'EMASABANDA'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(24940365285073034)
,p_name=>'P120_IDEDITAR'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(24939683173073027)
,p_prompt=>'Ideditar'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_created_on=>wwv_flow_imp.dz('20230711154524Z')
,p_updated_on=>wwv_flow_imp.dz('20230711212556Z')
,p_created_by=>'EMASABANDA'
,p_updated_by=>'EMASABANDA'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(24940434093073035)
,p_name=>'P120_SENDTOSAVE'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(24939683173073027)
,p_prompt=>'Sendtosave'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_created_on=>wwv_flow_imp.dz('20230711154524Z')
,p_updated_on=>wwv_flow_imp.dz('20230711212556Z')
,p_created_by=>'EMASABANDA'
,p_updated_by=>'EMASABANDA'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(24940576397073036)
,p_name=>'P120_TXTDETALLE'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_imp.id(24939683173073027)
,p_prompt=>'Txtdetalle'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_created_on=>wwv_flow_imp.dz('20230711154524Z')
,p_updated_on=>wwv_flow_imp.dz('20230711212556Z')
,p_created_by=>'EMASABANDA'
,p_updated_by=>'EMASABANDA'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(24940619556073037)
,p_name=>'P120_TXTOBJETIVO'
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_imp.id(24939683173073027)
,p_prompt=>'Txtobjetivo'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_created_on=>wwv_flow_imp.dz('20230711154524Z')
,p_updated_on=>wwv_flow_imp.dz('20230711212556Z')
,p_created_by=>'EMASABANDA'
,p_updated_by=>'EMASABANDA'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(24941312705073044)
,p_name=>'P120_TIPO_ORDEN_COMPRA'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(24940783290073038)
,p_prompt=>'Tipo Orden Compra'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(37859556976106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
,p_created_on=>wwv_flow_imp.dz('20230711164402Z')
,p_updated_on=>wwv_flow_imp.dz('20230711212556Z')
,p_created_by=>'EMASABANDA'
,p_updated_by=>'EMASABANDA'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(24941498263073045)
,p_name=>'P120_MONTO_ORDEN_COMPRA'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(24940783290073038)
,p_prompt=>'Monto Orden Compra'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(37859556976106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
,p_created_on=>wwv_flow_imp.dz('20230711164402Z')
,p_updated_on=>wwv_flow_imp.dz('20230711212556Z')
,p_created_by=>'EMASABANDA'
,p_updated_by=>'EMASABANDA'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(24941588532073046)
,p_name=>'P120_TIPO_PROVEEDOR'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(24940783290073038)
,p_prompt=>'Tipo Proveedor'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_named_lov=>'LOV_TIPOPROVEEDOR'
,p_lov=>'.'||wwv_flow_imp.id(107474199533629316)||'.'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(37859556976106557)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'Y'
,p_attribute_02=>'LOV'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
,p_created_on=>wwv_flow_imp.dz('20230711164402Z')
,p_updated_on=>wwv_flow_imp.dz('20230711212556Z')
,p_created_by=>'EMASABANDA'
,p_updated_by=>'EMASABANDA'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(24941614616073047)
,p_name=>'P120_SUBTOTAL12'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(24940876370073039)
,p_prompt=>'Subtotal 12%'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859556976106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_03=>'left'
,p_attribute_04=>'decimal'
,p_created_on=>wwv_flow_imp.dz('20230711164402Z')
,p_updated_on=>wwv_flow_imp.dz('20230711212555Z')
,p_created_by=>'EMASABANDA'
,p_updated_by=>'EMASABANDA'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(24941740103073048)
,p_name=>'P120_SUBTOTAL0'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(24940876370073039)
,p_prompt=>'Subtotal 0%'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(37859556976106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_03=>'left'
,p_attribute_04=>'decimal'
,p_created_on=>wwv_flow_imp.dz('20230711164402Z')
,p_updated_on=>wwv_flow_imp.dz('20230711212556Z')
,p_created_by=>'EMASABANDA'
,p_updated_by=>'EMASABANDA'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(24941864859073049)
,p_name=>'P120_MONTO_FALTANTE_TXT'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(24940876370073039)
,p_prompt=>'Falta por Cubrir OC'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_cattributes_element=>'style="color:red; border:none;text-align: right;" readonly=""'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(37859556976106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
,p_created_on=>wwv_flow_imp.dz('20230711164402Z')
,p_updated_on=>wwv_flow_imp.dz('20230711212556Z')
,p_created_by=>'EMASABANDA'
,p_updated_by=>'EMASABANDA'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(25344533720556627)
,p_name=>'P120_IDPROCESA'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(24939683173073027)
,p_prompt=>'Idprocesa'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_created_on=>wwv_flow_imp.dz('20230711190656Z')
,p_updated_on=>wwv_flow_imp.dz('20230711212556Z')
,p_created_by=>'EMASABANDA'
,p_updated_by=>'EMASABANDA'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(390408481049622901)
,p_name=>'P120_BANDERAGLIQ'
,p_item_sequence=>120
,p_item_plug_id=>wwv_flow_imp.id(24939683173073027)
,p_prompt=>'Banderagliq'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_created_on=>wwv_flow_imp.dz('20260313172057Z')
,p_updated_on=>wwv_flow_imp.dz('20260313172057Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(25344354037556625)
,p_name=>'InsertarDetalle'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(25343654324556618)
,p_condition_element=>'P120_IDPROCESA'
,p_triggering_condition_type=>'NULL'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
,p_created_on=>wwv_flow_imp.dz('20230711190656Z')
,p_updated_on=>wwv_flow_imp.dz('20230711190656Z')
,p_created_by=>'EMASABANDA'
,p_updated_by=>'EMASABANDA'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(25344487141556626)
,p_event_id=>wwv_flow_imp.id(25344354037556625)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_01=>'Agregar2'
,p_attribute_02=>'Y'
,p_created_on=>wwv_flow_imp.dz('20230711190656Z')
,p_updated_on=>wwv_flow_imp.dz('20230711190656Z')
,p_created_by=>'EMASABANDA'
,p_updated_by=>'EMASABANDA'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(25344682053556628)
,p_name=>'VerOcultarCamposLiquidacion'
,p_event_sequence=>20
,p_condition_element=>'P120_MONTO_FALTANTE'
,p_triggering_condition_type=>'NOT_NULL'
,p_bind_type=>'bind'
,p_bind_event_type=>'ready'
,p_created_on=>wwv_flow_imp.dz('20230711192155Z')
,p_updated_on=>wwv_flow_imp.dz('20230711192412Z')
,p_created_by=>'EMASABANDA'
,p_updated_by=>'EMASABANDA'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(25344741712556629)
,p_event_id=>wwv_flow_imp.id(25344682053556628)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P120_SUBTOTAL12,P120_SUBTOTAL0,P120_MONTO_FALTANTE_TXT'
,p_created_on=>wwv_flow_imp.dz('20230711192155Z')
,p_updated_on=>wwv_flow_imp.dz('20230711192155Z')
,p_created_by=>'EMASABANDA'
,p_updated_by=>'EMASABANDA'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(25345535401556637)
,p_event_id=>wwv_flow_imp.id(25344682053556628)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(24940876370073039)
,p_created_on=>wwv_flow_imp.dz('20230711192412Z')
,p_updated_on=>wwv_flow_imp.dz('20230711192412Z')
,p_created_by=>'EMASABANDA'
,p_updated_by=>'EMASABANDA'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(25345028507556632)
,p_event_id=>wwv_flow_imp.id(25344682053556628)
,p_event_result=>'FALSE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P120_SUBTOTAL12,P120_SUBTOTAL0,P120_MONTO_FALTANTE_TXT'
,p_created_on=>wwv_flow_imp.dz('20230711192155Z')
,p_updated_on=>wwv_flow_imp.dz('20230711192412Z')
,p_created_by=>'EMASABANDA'
,p_updated_by=>'EMASABANDA'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(25345425904556636)
,p_event_id=>wwv_flow_imp.id(25344682053556628)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(24940876370073039)
,p_created_on=>wwv_flow_imp.dz('20230711192412Z')
,p_updated_on=>wwv_flow_imp.dz('20230711192412Z')
,p_created_by=>'EMASABANDA'
,p_updated_by=>'EMASABANDA'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(25345188290556633)
,p_name=>'ActualizarTextoDetalle'
,p_event_sequence=>30
,p_triggering_element_type=>'JQUERY_SELECTOR'
,p_triggering_element=>'.DETALLEDINAM'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
,p_created_on=>wwv_flow_imp.dz('20230711192328Z')
,p_updated_on=>wwv_flow_imp.dz('20230711192328Z')
,p_created_by=>'EMASABANDA'
,p_updated_by=>'EMASABANDA'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(25345223967556634)
,p_event_id=>wwv_flow_imp.id(25345188290556633)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'var i=$(this.triggeringElement).attr(''Id'');',
'var v=$(this.triggeringElement).val();',
'apex.item("P120_TXTDETALLE").setValue(v);',
'apex.item("P120_IDEDITAR").setValue(i);'))
,p_created_on=>wwv_flow_imp.dz('20230711192328Z')
,p_updated_on=>wwv_flow_imp.dz('20230711192328Z')
,p_created_by=>'EMASABANDA'
,p_updated_by=>'EMASABANDA'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(25345389939556635)
,p_event_id=>wwv_flow_imp.id(25345188290556633)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_01=>'.DETALLEDINAM'
,p_attribute_02=>'Y'
,p_created_on=>wwv_flow_imp.dz('20230711192328Z')
,p_updated_on=>wwv_flow_imp.dz('20230711192328Z')
,p_created_by=>'EMASABANDA'
,p_updated_by=>'EMASABANDA'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(25345672069556638)
,p_name=>'ActualizarTextoObjetivo'
,p_event_sequence=>40
,p_triggering_element_type=>'JQUERY_SELECTOR'
,p_triggering_element=>'.OBJETIVODINAM'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
,p_created_on=>wwv_flow_imp.dz('20230711192623Z')
,p_updated_on=>wwv_flow_imp.dz('20230711192623Z')
,p_created_by=>'EMASABANDA'
,p_updated_by=>'EMASABANDA'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(25345794003556639)
,p_event_id=>wwv_flow_imp.id(25345672069556638)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'var i=$(this.triggeringElement).attr(''Id'');',
'var v=$(this.triggeringElement).val();',
'apex.item("P120_TXTOBJETIVO").setValue(v);',
'apex.item("P120_IDEDITAR").setValue(i);'))
,p_created_on=>wwv_flow_imp.dz('20230711192623Z')
,p_updated_on=>wwv_flow_imp.dz('20230711192623Z')
,p_created_by=>'EMASABANDA'
,p_updated_by=>'EMASABANDA'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(25345864740556640)
,p_event_id=>wwv_flow_imp.id(25345672069556638)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_01=>'.OBJETIVODINAM'
,p_attribute_02=>'Y'
,p_created_on=>wwv_flow_imp.dz('20230711192623Z')
,p_updated_on=>wwv_flow_imp.dz('20230711192623Z')
,p_created_by=>'EMASABANDA'
,p_updated_by=>'EMASABANDA'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(25345911581556641)
,p_name=>'LiquidacionEjecutaCrear'
,p_event_sequence=>50
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P120_IDPROCESA'
,p_condition_element=>'P120_IDPROCESA'
,p_triggering_condition_type=>'NOT_NULL'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
,p_created_on=>wwv_flow_imp.dz('20230711194925Z')
,p_updated_on=>wwv_flow_imp.dz('20230711195014Z')
,p_created_by=>'EMASABANDA'
,p_updated_by=>'EMASABANDA'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(25346007107556642)
,p_event_id=>wwv_flow_imp.id(25345911581556641)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_CONFIRM'
,p_attribute_01=>unistr('\00BFEst\00E1 seguro de generar la informaci\00F3n de la liquidacion?')
,p_created_on=>wwv_flow_imp.dz('20230711194925Z')
,p_updated_on=>wwv_flow_imp.dz('20230711194925Z')
,p_created_by=>'EMASABANDA'
,p_updated_by=>'EMASABANDA'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(25346345543556645)
,p_event_id=>wwv_flow_imp.id(25345911581556641)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P120_SENDTOSAVE'
,p_attribute_01=>'STATIC_ASSIGNMENT'
,p_attribute_02=>'0'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
,p_created_on=>wwv_flow_imp.dz('20230711195014Z')
,p_updated_on=>wwv_flow_imp.dz('20230711195014Z')
,p_created_by=>'EMASABANDA'
,p_updated_by=>'EMASABANDA'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(25346174245556643)
,p_event_id=>wwv_flow_imp.id(25345911581556641)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P120_SENDTOSAVE'
,p_attribute_01=>'STATIC_ASSIGNMENT'
,p_attribute_02=>'1'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
,p_created_on=>wwv_flow_imp.dz('20230711194925Z')
,p_updated_on=>wwv_flow_imp.dz('20230711194925Z')
,p_created_by=>'EMASABANDA'
,p_updated_by=>'EMASABANDA'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(25346465105556646)
,p_event_id=>wwv_flow_imp.id(25345911581556641)
,p_event_result=>'FALSE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_CANCEL_EVENT'
,p_created_on=>wwv_flow_imp.dz('20230711195014Z')
,p_updated_on=>wwv_flow_imp.dz('20230711195014Z')
,p_created_by=>'EMASABANDA'
,p_updated_by=>'EMASABANDA'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(25346200119556644)
,p_event_id=>wwv_flow_imp.id(25345911581556641)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_02=>'Y'
,p_created_on=>wwv_flow_imp.dz('20230711194925Z')
,p_updated_on=>wwv_flow_imp.dz('20230711194925Z')
,p_created_by=>'EMASABANDA'
,p_updated_by=>'EMASABANDA'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(25346596978556647)
,p_name=>'PreLiquidacionEditar'
,p_event_sequence=>60
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P120_IDEDITAR'
,p_condition_element=>'P120_IDEDITAR'
,p_triggering_condition_type=>'NOT_NULL'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
,p_created_on=>wwv_flow_imp.dz('20230711195140Z')
,p_updated_on=>wwv_flow_imp.dz('20230711195257Z')
,p_created_by=>'EMASABANDA'
,p_updated_by=>'EMASABANDA'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(25346619769556648)
,p_event_id=>wwv_flow_imp.id(25346596978556647)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(25343797835556619)
,p_created_on=>wwv_flow_imp.dz('20230711195140Z')
,p_updated_on=>wwv_flow_imp.dz('20230711195140Z')
,p_created_by=>'EMASABANDA'
,p_updated_by=>'EMASABANDA'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(25346701275556649)
,p_event_id=>wwv_flow_imp.id(25346596978556647)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P120_IDEDITAR,P120_PERIODO'
,p_created_on=>wwv_flow_imp.dz('20230711195140Z')
,p_updated_on=>wwv_flow_imp.dz('20230711195140Z')
,p_created_by=>'EMASABANDA'
,p_updated_by=>'EMASABANDA'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(25346898181556650)
,p_event_id=>wwv_flow_imp.id(25346596978556647)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P120_SUBTOTAL12,P120_SUBTOTAL0,P120_MONTO_FALTANTE_TXT'
,p_created_on=>wwv_flow_imp.dz('20230711195211Z')
,p_updated_on=>wwv_flow_imp.dz('20230711195211Z')
,p_created_by=>'EMASABANDA'
,p_updated_by=>'EMASABANDA'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(25723447715605501)
,p_event_id=>wwv_flow_imp.id(25346596978556647)
,p_event_result=>'FALSE'
,p_action_sequence=>30
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(25343797835556619)
,p_created_on=>wwv_flow_imp.dz('20230711195257Z')
,p_updated_on=>wwv_flow_imp.dz('20230711195257Z')
,p_created_by=>'EMASABANDA'
,p_updated_by=>'EMASABANDA'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(25723593549605502)
,p_event_id=>wwv_flow_imp.id(25346596978556647)
,p_event_result=>'FALSE'
,p_action_sequence=>40
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P120_IDEDITAR,P120_PERIODO'
,p_created_on=>wwv_flow_imp.dz('20230711195257Z')
,p_updated_on=>wwv_flow_imp.dz('20230711195257Z')
,p_created_by=>'EMASABANDA'
,p_updated_by=>'EMASABANDA'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(25723680557605503)
,p_event_id=>wwv_flow_imp.id(25346596978556647)
,p_event_result=>'FALSE'
,p_action_sequence=>50
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P120_SUBTOTAL12,P120_SUBTOTAL0,P120_MONTO_FALTANTE_TXT'
,p_created_on=>wwv_flow_imp.dz('20230711195257Z')
,p_updated_on=>wwv_flow_imp.dz('20230711195257Z')
,p_created_by=>'EMASABANDA'
,p_updated_by=>'EMASABANDA'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(25723725252605504)
,p_name=>'ActualizarDetalle'
,p_event_sequence=>70
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(25343797835556619)
,p_condition_element=>'P120_IDEDITAR'
,p_triggering_condition_type=>'NOT_NULL'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
,p_created_on=>wwv_flow_imp.dz('20230711195433Z')
,p_updated_on=>wwv_flow_imp.dz('20230711195433Z')
,p_created_by=>'EMASABANDA'
,p_updated_by=>'EMASABANDA'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(25723874693605505)
,p_event_id=>wwv_flow_imp.id(25723725252605504)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_CONFIRM'
,p_attribute_01=>unistr('\00BFEsta seguro(a) actualizar los datos del periodo?')
,p_created_on=>wwv_flow_imp.dz('20230711195433Z')
,p_updated_on=>wwv_flow_imp.dz('20230711195433Z')
,p_created_by=>'EMASABANDA'
,p_updated_by=>'EMASABANDA'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(25723923931605506)
,p_event_id=>wwv_flow_imp.id(25723725252605504)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_01=>'Editar'
,p_attribute_02=>'Y'
,p_created_on=>wwv_flow_imp.dz('20230711195433Z')
,p_updated_on=>wwv_flow_imp.dz('20230711195433Z')
,p_created_by=>'EMASABANDA'
,p_updated_by=>'EMASABANDA'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(25724009721605507)
,p_name=>'ConfirmarBorrarSeleccionDetalle'
,p_event_sequence=>80
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(25343915235556621)
,p_triggering_condition_type=>'JAVASCRIPT_EXPRESSION'
,p_triggering_expression=>wwv_flow_string.join(wwv_flow_t_varchar2(
'document.querySelectorAll(''.chkF01'').length == [].filter.call( document.querySelectorAll(''.chkF01''), function( el ) {return !el.checked}).length ',
''))
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
,p_created_on=>wwv_flow_imp.dz('20230711195614Z')
,p_updated_on=>wwv_flow_imp.dz('20230711195649Z')
,p_created_by=>'EMASABANDA'
,p_updated_by=>'EMASABANDA'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(25724174957605508)
,p_event_id=>wwv_flow_imp.id(25724009721605507)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'mensaje(''error'', ''Debe seleccionar al menos un detalle para proceder a eliminar, valide e intente nuevamente''); '
,p_created_on=>wwv_flow_imp.dz('20230711195614Z')
,p_updated_on=>wwv_flow_imp.dz('20230711195614Z')
,p_created_by=>'EMASABANDA'
,p_updated_by=>'EMASABANDA'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(25724459220605511)
,p_event_id=>wwv_flow_imp.id(25724009721605507)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_CONFIRM'
,p_attribute_01=>unistr('\00BFEsta seguro(a) de eliminar los detalles seleccionados?')
,p_created_on=>wwv_flow_imp.dz('20230711195649Z')
,p_updated_on=>wwv_flow_imp.dz('20230711195649Z')
,p_created_by=>'EMASABANDA'
,p_updated_by=>'EMASABANDA'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(25724278569605509)
,p_event_id=>wwv_flow_imp.id(25724009721605507)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_CANCEL_EVENT'
,p_created_on=>wwv_flow_imp.dz('20230711195614Z')
,p_updated_on=>wwv_flow_imp.dz('20230711195614Z')
,p_created_by=>'EMASABANDA'
,p_updated_by=>'EMASABANDA'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(25724326991605510)
,p_event_id=>wwv_flow_imp.id(25724009721605507)
,p_event_result=>'FALSE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_01=>'BorrarSeleccion'
,p_attribute_02=>'Y'
,p_created_on=>wwv_flow_imp.dz('20230711195649Z')
,p_updated_on=>wwv_flow_imp.dz('20230711195649Z')
,p_created_by=>'EMASABANDA'
,p_updated_by=>'EMASABANDA'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(25724522446605512)
,p_name=>'ActivaInactivaDetalle'
,p_event_sequence=>90
,p_triggering_element_type=>'JQUERY_SELECTOR'
,p_triggering_element=>'.chkF03'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
,p_created_on=>wwv_flow_imp.dz('20230711200723Z')
,p_updated_on=>wwv_flow_imp.dz('20230711201012Z')
,p_created_by=>'EMASABANDA'
,p_updated_by=>'EMASABANDA'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(25724676842605513)
,p_event_id=>wwv_flow_imp.id(25724522446605512)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'var v=$(this.triggeringElement)[0].value;',
'$s("P120_IDACTIVA",v);',
'',
' '))
,p_created_on=>wwv_flow_imp.dz('20230711200723Z')
,p_updated_on=>wwv_flow_imp.dz('20230711200723Z')
,p_created_by=>'EMASABANDA'
,p_updated_by=>'EMASABANDA'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(25724728775605514)
,p_event_id=>wwv_flow_imp.id(25724522446605512)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'    update T_FINZ_GLIQ_DETALLEOC',
'    set estado = decode (estado,1,0,1)',
'    where id=:P120_IDACTIVA;',
'    commit;',
'    :P120_IDPROCESA:=null;',
'    :P120_IDEDITAR:=null;',
'end;'))
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
,p_created_on=>wwv_flow_imp.dz('20230711200827Z')
,p_updated_on=>wwv_flow_imp.dz('20230711200827Z')
,p_created_by=>'EMASABANDA'
,p_updated_by=>'EMASABANDA'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(25724838760605515)
,p_event_id=>wwv_flow_imp.id(25724522446605512)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_02=>'Y'
,p_created_on=>wwv_flow_imp.dz('20230711201012Z')
,p_updated_on=>wwv_flow_imp.dz('20230711201012Z')
,p_created_by=>'EMASABANDA'
,p_updated_by=>'EMASABANDA'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(25725161883605518)
,p_name=>'ConfirmarBorrarTodoDetalle'
,p_event_sequence=>100
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(25344057990556622)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
,p_created_on=>wwv_flow_imp.dz('20230711201251Z')
,p_updated_on=>wwv_flow_imp.dz('20230711201349Z')
,p_created_by=>'EMASABANDA'
,p_updated_by=>'EMASABANDA'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(25725257905605519)
,p_event_id=>wwv_flow_imp.id(25725161883605518)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_CONFIRM'
,p_attribute_01=>unistr('\00BFEsta seguro(a) de eliminar todos los detalles, posterior a esta acci\00F3n deber\00E1 volver a cargar uno por uno los detalles?')
,p_created_on=>wwv_flow_imp.dz('20230711201251Z')
,p_updated_on=>wwv_flow_imp.dz('20230711201251Z')
,p_created_by=>'EMASABANDA'
,p_updated_by=>'EMASABANDA'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(25725346470605520)
,p_event_id=>wwv_flow_imp.id(25725161883605518)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_01=>'BorrarTodo'
,p_attribute_02=>'Y'
,p_created_on=>wwv_flow_imp.dz('20230711201251Z')
,p_updated_on=>wwv_flow_imp.dz('20230711201251Z')
,p_created_by=>'EMASABANDA'
,p_updated_by=>'EMASABANDA'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(25341953627556601)
,p_process_sequence=>10
,p_process_point=>'AFTER_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Setup Interface'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare v_valor number;',
'begin',
'	select valor,to_char(valor,''FML999G999G999G999G990D00'') ',
'	INTO :P120_MONTO_MAXIMO,:P120_MONTO_ORDEN_COMPRA',
'	from    VT_COMP_MESATRABAJO m',
'	where   M.NUMERO =:P120_NUMERO_ORDEN_COMPRA',
'	and     M.TIPO =:P120_TIPO_ORDEN_COMPRA;',
'',
'    :P120_SUBTOTAL12:=0;',
'    :P120_SUBTOTAL0 :=0;',
'',
'	:p120_banderagliq := 0;',
'	begin',
'		select count(1) into :p120_banderagliq',
'		from data.t_finz_gliq_detalleoc a inner join data.t_gliq_liquidacion b on a.numliquidaciongenerada = b.id ',
'		where 1 = 1',
'			and a.ordencompraid = :P120_NUMERO_ORDEN_COMPRA',
'			and b.estado = 1',
'			and b.estadoaprobacion = ''G'';',
'',
'		exception when others then :p120_banderagliq := -1;',
'	end;',
'',
'    select :P120_MONTO_MAXIMO- nvl(sum(nvl(LIQUIDACIONVALOR12,0)+nvl(LIQUIDACIONVALOR0,0)), 0) INTO :P120_MONTO_FALTANTE',
'    from T_FINZ_GLIQ_DETALLEOC t1 where ORDENCOMPRAID=:P120_NUMERO_ORDEN_COMPRA and ORDENCOMPRATIPO = :P120_TIPO_ORDEN_COMPRA;',
'',
'    BEGIN',
'        SELECT trim(ABAT1) into :P120_TIPO_PROVEEDOR ',
'        FROM vt_jde_ordencompra_cab cab',
'        INNER JOIN f0101@jdedtadl lid on cab.CODIGOPROVEEDOR = lid.aban8',
'        WHERE DOCUMENTO=:P120_NUMERO_ORDEN_COMPRA and DOCUMENTOTIPO = :P120_TIPO_ORDEN_COMPRA;',
'    EXCEPTION WHEN OTHERS THEN ',
'        :P120_TIPO_PROVEEDOR :='''';',
'    END;',
'',
' ',
'    :P120_MONTO_FALTANTE_TXT:= to_char(:P120_MONTO_FALTANTE,''FML999G999G999G999G990D00'');',
'    :P120_SUBTOTAL12:=:P120_MONTO_FALTANTE;',
'    if (:P120_MONTO_FALTANTE=0) then',
'       :P120_MONTO_FALTANTE:= '''';',
'    end if;',
'    :P120_SENDTOSAVE:=0;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>25341953627556601
,p_created_on=>wwv_flow_imp.dz('20230711165750Z')
,p_updated_on=>wwv_flow_imp.dz('20260313172057Z')
,p_created_by=>'EMASABANDA'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(25725433787605521)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Preliquidacion - Inserta Datos'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare v_valorsum number;',
'v_valoring number;',
'v_periodo date;',
'v_subtotal0 number;',
'v_subtotal12 number;',
'v_montomaximo number;',
'v_numeroorden number;',
'v_tipoorden varchar2(99);',
'v_user varchar2(99);',
'v_desc varchar2(3999);',
'v_identidad	varchar2(100);',
'v_tipoproveedor varchar2(99);',
'begin    ',
'	v_subtotal12 := to_number(replace(:P120_subtotal12,''.'','',''));',
'	v_subtotal0 := to_number(replace(:P120_subtotal0,''.'','',''));',
'	v_periodo:=to_date(replace(:P120_periodo, ''-'',''''));',
'	v_montomaximo:=to_number(replace(:P120_MONTO_MAXIMO, ''-'',''''));',
'	v_numeroorden:=to_number(replace(:P120_numero_orden_compra, ''-'',''''));',
'	v_tipoorden:=:P120_tipo_orden_compra;',
'	v_user:=:app_user;',
'	v_tipoproveedor:=:P120_TIPO_PROVEEDOR;',
'',
'	select  sum(LIQUIDACIONVALOR12+LIQUIDACIONVALOR0) into v_valorsum',
'	from    T_FINZ_GLIQ_DETALLEOC t1 ',
'	where   ORDENCOMPRAID=:P120_numero_orden_compra ',
'	and     ORDENCOMPRATIPO = :P120_tipo_orden_compra;',
'',
'	v_valorsum:=nvl(v_valorsum,0);',
'',
'	v_valoring:=v_subtotal12+v_subtotal0+v_valorsum;',
'',
'	if nvl(v_valoring,0)<=nvl(v_montomaximo,0) then',
'		begin',
'			-- DLC: Para las OCs de Pagos Recurrentes de Proveedores del Exterior.',
'			select identidad, descripcionpago',
'			into v_identidad, v_desc',
'			from data.vt_comp_pagosrecurrentes',
'			where 1 = 1',
'				and numorden = v_numeroorden',
'				and tipoorden = v_tipoorden;',
'',
'			exception when others then v_identidad := null;',
'		end;',
'',
'		data.pk_finz_gliq_dinamicas.sp_gliq_dinamincas_insert(1	',
'			, 0',
'			, v_periodo',
'			, v_numeroorden',
'			, v_tipoorden',
'			, v_subtotal12',
'			, v_subtotal0',
'			, v_user',
'			, v_montomaximo',
'			, v_tipoproveedor',
'			, ''detalle''',
'			, :P120_mensaje	',
'		);',
'',
'		if v_identidad is not null then',
'			update data.t_finz_gliq_detalleoc x set x.detalle = v_desc where ordencompraid = v_numeroorden and ordencompratipo = v_tipoorden;',
'		end if;',
'		apex_application.g_print_success_message := ''Registro correcto'';',
'',
'	else',
'		apex_error.add_error (',
'		p_message          => ''El valor ingresado excede al valor de la orden de compra, valide e intente nuevamente.'',',
'		p_display_location =>apex_error.C_INLINE_IN_NOTIFICATION',
'		);',
'	end if;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(25343654324556618)
,p_internal_uid=>25725433787605521
,p_created_on=>wwv_flow_imp.dz('20230711202215Z')
,p_updated_on=>wwv_flow_imp.dz('20250627165647Z')
,p_created_by=>'EMASABANDA'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(25725535971605522)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Preliquidacion - Actualiza Datos'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare ',
'v_idprocesar number;',
'p_periodo  date;',
'p_mensaje	varchar2(3999);',
'begin',
'    v_idprocesar:=:P120_IDEDITAR;',
'    p_periodo:=:P120_PERIODO;',
'    apex_application.g_print_success_message :=''p_periodo:'' || p_periodo || '', v_idprocesar: '' || v_idprocesar ;',
'    ',
'    PK_FINZ_GLIQ_DINAMICAS.sp_gliq_actualizaliquidacion(:app_user,v_idprocesar,p_periodo,p_mensaje);',
'    if (p_mensaje like ''error:%'') then',
'        apex_error.add_error (',
'        p_message          => p_mensaje,',
'        p_display_location =>apex_error.c_inline_in_notification );',
'    else',
'        apex_application.g_print_success_message :=''Registro actualizado correctamente!!!'';',
'        :P120_IDEDITAR:='''';',
'    end if;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(25343797835556619)
,p_internal_uid=>25725535971605522
,p_created_on=>wwv_flow_imp.dz('20230711204213Z')
,p_updated_on=>wwv_flow_imp.dz('20230711205530Z')
,p_created_by=>'EMASABANDA'
,p_updated_by=>'EMASABANDA'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(25725621388605523)
,p_process_sequence=>30
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Preliquidacion - Actualiza Texto Detalle'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare ',
'v_idprocesar number;',
'p_detalle  varchar2(3999);',
'begin',
'    v_idprocesar:=:P120_IDEDITAR;',
'    p_detalle:=:P120_TXTDETALLE;',
'    ',
'    update T_FINZ_GLIQ_DETALLEOC',
'    set DETALLE=p_detalle',
'    where id= v_idprocesar;',
'    commit;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>'.DETALLEDINAM'
,p_process_when_type=>'REQUEST_EQUALS_CONDITION'
,p_process_success_message=>'Detalle actualizado correctamente'
,p_internal_uid=>25725621388605523
,p_created_on=>wwv_flow_imp.dz('20230711204213Z')
,p_updated_on=>wwv_flow_imp.dz('20230711205530Z')
,p_created_by=>'EMASABANDA'
,p_updated_by=>'EMASABANDA'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(25725782337605524)
,p_process_sequence=>40
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Preliquidacion - Actualiza Texto Objetivo'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare ',
'v_idprocesar number;',
'p_objetivo  varchar2(3999);',
'begin',
'    v_idprocesar:=:P120_IDEDITAR;',
'    p_objetivo:=:P120_TXTOBJETIVO;',
'',
'    update T_FINZ_GLIQ_DETALLEOC',
'    set objetivo=p_objetivo',
'    where id= v_idprocesar;',
'    commit;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>'.OBJETIVODINAM'
,p_process_when_type=>'REQUEST_EQUALS_CONDITION'
,p_process_success_message=>'Objetivo actualizado correctamente'
,p_internal_uid=>25725782337605524
,p_created_on=>wwv_flow_imp.dz('20230711204213Z')
,p_updated_on=>wwv_flow_imp.dz('20230711205559Z')
,p_created_by=>'EMASABANDA'
,p_updated_by=>'EMASABANDA'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(25725813378605525)
,p_process_sequence=>50
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>unistr('Preliquidacion - Eliminar Selecci\00F3n')
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'v_iddet varchar2(50);',
'v_producto varchar2(50);',
'v_codigoproducto varchar2(50);',
'v_ids varchar2(9999);',
'v_valida number:=0;',
'v_mensaje varchar2(9999);',
'x number:=0;',
'begin',
'    for i in 1..apex_application.g_f01.count loop',
'        v_iddet := apex_application.g_f01(i);',
'        delete from T_FINZ_GLIQ_DETALLEOC where id = v_iddet;',
'        commit;',
'        x:=x+1;',
'    end loop;',
'    if (x=1) then',
'        v_mensaje :=''Registro eliminado correctamente!!!'';',
'    else ',
'        v_mensaje :=''''||x||'' Registro seleccionados eliminados correctamente!!!'';',
'    end if;',
'    apex_application.g_print_success_message :=v_mensaje;',
'    commit;',
'exception when others then',
'    apex_error.add_error (',
'        p_message          => SQLERRM || ''x:''||x|| '' - v_iddet:''||v_iddet,',
'        p_display_location =>apex_error.C_INLINE_IN_NOTIFICATION',
'    );',
'    rollback;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_process_error_message=>'RROROROROOR'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(25343915235556621)
,p_internal_uid=>25725813378605525
,p_created_on=>wwv_flow_imp.dz('20230711204213Z')
,p_updated_on=>wwv_flow_imp.dz('20230711205806Z')
,p_created_by=>'EMASABANDA'
,p_updated_by=>'EMASABANDA'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(25725910364605526)
,p_process_sequence=>60
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Preliquidacion - Eliminar Todo'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'v_iddet number;',
'v_producto varchar(50);',
'v_codigoproducto varchar(50);',
'x number:=0;',
'v_ids varchar2(9999);',
'v_valida number:=0;',
'v_mensaje varchar(9999);',
'begin',
'    delete from T_FINZ_GLIQ_DETALLEOC ',
'    where  ORDENCOMPRAID=:P120_NUMERO_ORDEN_COMPRA',
'    and ORDENCOMPRATIPO=:P120_TIPO_ORDEN_COMPRA;',
'    ',
'    v_mensaje :=''Todos los registros eliminados correctamente!!!'';',
'    apex_application.g_print_success_message :=v_mensaje;',
'    commit;',
'exception when others then',
'    apex_error.add_error (',
'        p_message          => SQLERRM ,',
'        p_display_location =>apex_error.C_INLINE_IN_NOTIFICATION',
'    );',
'    rollback;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(25344057990556622)
,p_internal_uid=>25725910364605526
,p_created_on=>wwv_flow_imp.dz('20230711204213Z')
,p_updated_on=>wwv_flow_imp.dz('20230711205616Z')
,p_created_by=>'EMASABANDA'
,p_updated_by=>'EMASABANDA'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(25726026450605527)
,p_process_sequence=>70
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Liquidacion - Inserta'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare v_idprocesar number;',
'p_numeroliquidacion  number;',
'p_fechaliquidacion date;',
'p_mensaje	         varchar2(3999);',
'begin',
'v_idprocesar:=:P120_IDPROCESA;',
' IF (:P120_SENDTOSAVE=1) THEN ',
'     PK_FINZ_GLIQ_DINAMICAS.sp_gliq_crealiquidacion(:app_user,v_idprocesar,p_numeroliquidacion,p_fechaliquidacion,p_mensaje);',
'     if (p_mensaje like ''error:%'') then',
'        apex_error.add_error (',
'        p_message          => p_mensaje,',
'        p_display_location =>apex_error.c_inline_in_notification );',
'     else',
'         IF (p_numeroliquidacion is not null) then',
unistr('             apex_application.g_print_success_message :=''Liquidaci\00F3n No. '' || p_numeroliquidacion || '' con fecha: ''||p_fechaliquidacion||'', generada correctamente!!!'';'),
'             :P120_IDPROCESA:='''';',
'         end if;',
'     end if;',
' END IF;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>'P120_SENDTOSAVE'
,p_process_when_type=>'ITEM_NOT_NULL_OR_ZERO'
,p_internal_uid=>25726026450605527
,p_created_on=>wwv_flow_imp.dz('20230711204213Z')
,p_updated_on=>wwv_flow_imp.dz('20230711205445Z')
,p_created_by=>'EMASABANDA'
,p_updated_by=>'EMASABANDA'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(25726113149605528)
,p_process_sequence=>80
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Cotejo - Recepcion'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare p_mensaje varchar2(3999);',
'begin    ',
'    PK_FINZ_GLIQ_DINAMICAS.reprocesarcotejomanual(:P120_numero_orden_compra, :P120_tipo_orden_compra,p_mensaje);',
'    IF(trim(p_mensaje)=''OK'')THEN',
'      apex_application.g_print_success_message :=''Se ha registrado correctamente el cotejo'';  ',
'     else ',
'      apex_error.add_error (',
'            p_message          => ''Ha ocurrido un error al momento de cotejar favor valide y vuelva a intentarlo'',',
'            p_display_location =>apex_error.c_inline_in_notification ,',
'            p_page_item_name   => ''P120_NUMERO_ORDEN_COMPRA:''',
'      );',
'    END IF;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(25344279506556624)
,p_internal_uid=>25726113149605528
,p_created_on=>wwv_flow_imp.dz('20230711204213Z')
,p_updated_on=>wwv_flow_imp.dz('20230711205445Z')
,p_created_by=>'EMASABANDA'
,p_updated_by=>'EMASABANDA'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(25726291706605529)
,p_process_sequence=>90
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_CLOSE_WINDOW'
,p_process_name=>unistr('Cierra Di\00E1logo - PreLiquidaciones')
,p_attribute_02=>'N'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(25726428395605531)
,p_internal_uid=>25726291706605529
,p_created_on=>wwv_flow_imp.dz('20230711204213Z')
,p_updated_on=>wwv_flow_imp.dz('20230711205200Z')
,p_created_by=>'EMASABANDA'
,p_updated_by=>'EMASABANDA'
);
wwv_flow_imp.component_end;
end;
/
