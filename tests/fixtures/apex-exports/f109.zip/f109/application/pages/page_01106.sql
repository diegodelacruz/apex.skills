prompt --application/pages/page_01106
begin
--   Manifest
--     PAGE: 01106
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>109
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_page.create_page(
 p_id=>1106
,p_name=>unistr('Aprobaci\00F3n Variaci\00F3n Gastos Manufactura')
,p_step_title=>unistr('Aprobaci\00F3n Variaci\00F3n Gastos Manufactura')
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_page_component_map=>'03'
,p_created_on=>wwv_flow_imp.dz('20230705164635Z')
,p_last_updated_on=>wwv_flow_imp.dz('20210406050000Z')
,p_last_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(765946846291284230)
,p_plug_name=>unistr('Aprobaci\00F3n de Variaci\00F3n Gastos Manufactura')
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(37786313898106507)
,p_plug_display_sequence=>10
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'TEXT',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(400608032791760131)
,p_name=>unistr('Variaciones M\00E1quina')
,p_parent_plug_id=>wwv_flow_imp.id(765946846291284230)
,p_template=>wwv_flow_imp.id(38289867500120143)
,p_display_sequence=>10
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_display_point=>'SUB_REGIONS'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select id',
'	, idcab',
'	, idcabma',
'	, codigoestado',
'	, codigodivision',
'	, codigomaquina',
'	, gastototal',
'	, gastototalma',
'	, observacion',
'	, (nvl(gastototal,0) - nvl(gastototalma,0)) variacion',
'from t_finz_costeodif where idcab = :p1106_id order by codigodivision,codigomaquina'))
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(37830327650106535)
,p_query_num_rows=>50
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_show_nulls_as=>'-'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'Y'
,p_csv_output_link_text=>'Descargar'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(400608125970760132)
,p_query_column_id=>1
,p_column_alias=>'ID'
,p_column_display_sequence=>1
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(400608203344760133)
,p_query_column_id=>2
,p_column_alias=>'IDCAB'
,p_column_display_sequence=>2
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(400608353148760134)
,p_query_column_id=>3
,p_column_alias=>'IDCABMA'
,p_column_display_sequence=>3
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(400608446544760135)
,p_query_column_id=>4
,p_column_alias=>'CODIGOESTADO'
,p_column_display_sequence=>4
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(400608516256760136)
,p_query_column_id=>5
,p_column_alias=>'CODIGODIVISION'
,p_column_display_sequence=>5
,p_column_heading=>unistr('Divisi\00F3n')
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_display_as=>'TEXT_FROM_LOV_ESC'
,p_named_lov=>wwv_flow_imp.id(350603703974816017)
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(400608697423760137)
,p_query_column_id=>6
,p_column_alias=>'CODIGOMAQUINA'
,p_column_display_sequence=>6
,p_column_heading=>unistr('M\00E1quina')
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_display_as=>'TEXT_FROM_LOV_ESC'
,p_named_lov=>wwv_flow_imp.id(400686960521471326)
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(400608725859760138)
,p_query_column_id=>7
,p_column_alias=>'GASTOTOTAL'
,p_column_display_sequence=>7
,p_column_heading=>'Gasto'
,p_use_as_row_header=>'N'
,p_column_format=>'FML999G999G999G999G990D00'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(400608874039760139)
,p_query_column_id=>8
,p_column_alias=>'GASTOTOTALMA'
,p_column_display_sequence=>8
,p_column_heading=>'Gasto Mes Anterior'
,p_use_as_row_header=>'N'
,p_column_format=>'FML999G999G999G999G990D00'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(400608985935760140)
,p_query_column_id=>9
,p_column_alias=>'OBSERVACION'
,p_column_display_sequence=>10
,p_column_heading=>unistr('Justificaci\00F3n')
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(400609099186760141)
,p_query_column_id=>10
,p_column_alias=>'VARIACION'
,p_column_display_sequence=>9
,p_column_heading=>unistr('Variaci\00F3n')
,p_use_as_row_header=>'N'
,p_column_format=>'FML999G999G999G999G990D00'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(464859079872326228)
,p_name=>'Variaciones Producto'
,p_parent_plug_id=>wwv_flow_imp.id(765946846291284230)
,p_template=>wwv_flow_imp.id(38289867500120143)
,p_display_sequence=>20
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_new_grid_row=>false
,p_new_grid_column=>false
,p_display_point=>'SUB_REGIONS'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'with datos as',
'(',
'    select a.*',
'    , trim(d.imdsc1) imdsc1',
'    , round(c.irsetc/10,2) jdenpersonas',
'    , round(c.irrunm/100,2) jderesultado',
'    , case when (round(c.irrunm/100,2) != round(a.resultado,2) or round(c.irsetc/10,2) != a.personasturno) then 1 else 0 end flagdif',
'    from t_finz_costeoprd a inner join t_finz_costeocab b on a.idcab = b.id',
'    left join f3003@jdedtadl c on a.rowidruta = c.rowid',
'    inner join f4101@jdedtadl d on rpad(a.irkitl,25,'' '') = d.imlitm',
'    where c.irtrt = rpad(''M'',3,'' '') and pk_commons.f_g2jde(to_date(b.anno||b.mes,''yyyymm'')) between c.irefff and decode(nvl(c.irefft,0),0,140366,c.irefft)',
'    and idcab = :p1106_id',
') select * from datos where flagdif = 1'))
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(37830327650106535)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_show_nulls_as=>'-'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'Y'
,p_csv_output_link_text=>'Descargar'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(464859137658326229)
,p_query_column_id=>1
,p_column_alias=>'ID'
,p_column_display_sequence=>13
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(464859283048326230)
,p_query_column_id=>2
,p_column_alias=>'IDCAB'
,p_column_display_sequence=>14
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(464859374306326231)
,p_query_column_id=>3
,p_column_alias=>'CODIGODIVISION'
,p_column_display_sequence=>3
,p_column_heading=>unistr('Divisi\00F3n')
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(464859405008326232)
,p_query_column_id=>4
,p_column_alias=>'CODIGOMAQUINA'
,p_column_display_sequence=>4
,p_column_heading=>unistr('M\00E1quina')
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(464859563594326233)
,p_query_column_id=>5
,p_column_alias=>'PERSONASTURNO'
,p_column_display_sequence=>8
,p_column_heading=>'Per/turno'
,p_use_as_row_header=>'N'
,p_column_alignment=>'RIGHT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(464859647987326234)
,p_query_column_id=>6
,p_column_alias=>'BASETIEMPO'
,p_column_display_sequence=>15
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(464859796007326235)
,p_query_column_id=>7
,p_column_alias=>'UNDKGHORA'
,p_column_display_sequence=>16
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(464859803768326236)
,p_query_column_id=>8
,p_column_alias=>'ROWIDRUTA'
,p_column_display_sequence=>17
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(464859943001326237)
,p_query_column_id=>9
,p_column_alias=>'IXKIT'
,p_column_display_sequence=>18
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(464860021767326238)
,p_query_column_id=>10
,p_column_alias=>'IRKIT'
,p_column_display_sequence=>19
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(464860180738326239)
,p_query_column_id=>11
,p_column_alias=>'IRKITL'
,p_column_display_sequence=>5
,p_column_heading=>unistr('C\00F3d. Producto')
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(464860210535326240)
,p_query_column_id=>12
,p_column_alias=>'IRKITA'
,p_column_display_sequence=>20
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(464860309126326241)
,p_query_column_id=>13
,p_column_alias=>'IROPSQ'
,p_column_display_sequence=>7
,p_column_heading=>'Op.'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(464860421380326242)
,p_query_column_id=>14
,p_column_alias=>'IREFFF'
,p_column_display_sequence=>21
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(464860540749326243)
,p_query_column_id=>15
,p_column_alias=>'IREFFT'
,p_column_display_sequence=>22
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(464860630794326244)
,p_query_column_id=>16
,p_column_alias=>'UMCONV'
,p_column_display_sequence=>23
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(464860772881326245)
,p_query_column_id=>17
,p_column_alias=>'IXBQTY'
,p_column_display_sequence=>24
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(464860802065326246)
,p_query_column_id=>18
,p_column_alias=>'RESULTADO'
,p_column_display_sequence=>10
,p_column_heading=>'Resultado'
,p_use_as_row_header=>'N'
,p_column_format=>'999G999G999G999G990D00'
,p_column_alignment=>'RIGHT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(464860920713326247)
,p_query_column_id=>19
,p_column_alias=>'ESTADO'
,p_column_display_sequence=>25
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(464861097345326248)
,p_query_column_id=>20
,p_column_alias=>'OBSERVACION'
,p_column_display_sequence=>12
,p_column_heading=>unistr('Observaci\00F3n')
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(464861188386326249)
,p_query_column_id=>21
,p_column_alias=>'COMENTARIO'
,p_column_display_sequence=>26
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(464861247850326250)
,p_query_column_id=>22
,p_column_alias=>'SEQJDE'
,p_column_display_sequence=>27
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(464885001492466901)
,p_query_column_id=>23
,p_column_alias=>'IMDSC1'
,p_column_display_sequence=>6
,p_column_heading=>'Producto'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(464885192531466902)
,p_query_column_id=>24
,p_column_alias=>'JDENPERSONAS'
,p_column_display_sequence=>9
,p_column_heading=>'Per/turno JDE'
,p_use_as_row_header=>'N'
,p_column_alignment=>'RIGHT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(464885209946466903)
,p_query_column_id=>25
,p_column_alias=>'JDERESULTADO'
,p_column_display_sequence=>11
,p_column_heading=>'Resultado JDE'
,p_use_as_row_header=>'N'
,p_column_format=>'999G999G999G999G990D00'
,p_column_alignment=>'RIGHT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(464885302713466904)
,p_query_column_id=>26
,p_column_alias=>'FLAGDIF'
,p_column_display_sequence=>28
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1116318337400550664)
,p_plug_name=>'Barra de Acciones'
,p_region_template_options=>'#DEFAULT#:t-Form--stretchInputs'
,p_plug_template=>wwv_flow_imp.id(38289497777120142)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'REGION_POSITION_01'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(400864442797723289)
,p_button_sequence=>1
,p_button_plug_id=>wwv_flow_imp.id(1116318337400550664)
,p_button_name=>'CANCEL'
,p_button_static_id=>'btnAtras'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860056812106557)
,p_button_image_alt=>'Salir'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'LEFT'
,p_button_redirect_url=>'f?p=&APP_ID.:100:&SESSION.::&DEBUG.:::'
,p_icon_css_classes=>'fa-arrow-left'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(400863676134723287)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(1116318337400550664)
,p_button_name=>'APROBAR'
,p_button_action=>'REDIRECT_APP'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860056812106557)
,p_button_image_alt=>'Aprobar'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=100:102:&SESSION.::&DEBUG.:RP:G_COMPANIA,G_MODULO,G_USUARIO,G_OBJETO,G_OBJETO_ID:&G_COMPANIA.,&APP_MODULO.,&APP_USER.,&APP_OBJETO_VARGTOMNF.,&P1106_ID.'
,p_button_condition=>'P1106_FLAG'
,p_button_condition2=>'1'
,p_button_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_icon_css_classes=>'fa-thumbs-up'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(400864054412723289)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(1116318337400550664)
,p_button_name=>'RECHAZAR'
,p_button_action=>'REDIRECT_APP'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860056812106557)
,p_button_image_alt=>'Rechazar'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=100:103:&SESSION.::&DEBUG.:RP:G_COMPANIA,G_MODULO,G_USUARIO,G_OBJETO,G_OBJETO_ID:&G_COMPANIA.,&APP_MODULO.,&APP_USER.,&APP_OBJETO_VARGTOMNF.,&P1106_ID.'
,p_button_condition=>'P1106_FLAG'
,p_button_condition2=>'1'
,p_button_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_icon_css_classes=>'fa-thumbs-down'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(400872373076723309)
,p_branch_action=>'f?p=&APP_ID.:100:&SESSION.&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_sequence=>1
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(400865108093723290)
,p_name=>'P1106_ID'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(765946846291284230)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(400865598077723292)
,p_name=>'P1106_APROBADOR'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(765946846291284230)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(400865996316723292)
,p_name=>'P1106_FLAG'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(765946846291284230)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(400866303923723292)
,p_name=>'P1106_APROBAR_EXITO'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(765946846291284230)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(400870384681723307)
,p_name=>'Cierre Dialogo: aprobar'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(400863676134723287)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(400870846652723307)
,p_event_id=>wwv_flow_imp.id(400870384681723307)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'mostrarBarra();',
'var trama = JSON.parse(this.data.G_RESULTADO);',
'var isTerminoFlujo = trama.resultado.terminoFlujo;',
'',
'apex.item( "P1106_APROBAR_EXITO" ).setValue(0);',
'',
'if(this.data.G_EXITO == ''true''){',
'    mensaje(''exito'', this.data.G_MENSAJE);',
'    apex.item( "P1106_APROBAR_EXITO" ).setValue(1);',
'    if(isTerminoFlujo){',
'        apex.item( "P1106_APROBAR_EXITO" ).setValue(2);',
'    }',
'}',
'else{',
'    mensaje(''error'', this.data.G_MENSAJE);',
'}'))
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(400871399826723309)
,p_event_id=>wwv_flow_imp.id(400870384681723307)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'IF :P1106_APROBAR_EXITO = 2 THEN',
'    update t_finz_costeocab x set x.codigoestadovar = ''APROBADO'' where id = :p1106_id;',
'END IF;'))
,p_attribute_02=>'P1106_APROBAR_EXITO'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(400871818522723309)
,p_event_id=>wwv_flow_imp.id(400870384681723307)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'ocultarBarra();',
'$(''#btnAtras'').trigger("click");'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(400868488402723304)
,p_name=>'Cierre Dialogo: rechazar'
,p_event_sequence=>20
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(400864054412723289)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(400869493710723306)
,p_event_id=>wwv_flow_imp.id(400868488402723304)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'mostrarBarra();',
'var trama = JSON.parse(this.data.G_RESULTADO);',
'var isTerminoFlujo = trama.resultado.terminoFlujo;',
'',
'apex.item( "P1106_APROBAR_EXITO" ).setValue(0);',
'',
'if(this.data.G_EXITO == ''true''){',
'    mensaje(''exito'', this.data.G_MENSAJE);',
'    apex.item( "P1106_APROBAR_EXITO" ).setValue(1);',
'}',
'else{',
'    mensaje(''error'', this.data.G_MENSAJE);',
'}'))
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(400869962577723307)
,p_event_id=>wwv_flow_imp.id(400868488402723304)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'IF :P1106_APROBAR_EXITO = 1 THEN',
'    update t_finz_costeocab x set x.codigoestadovar = ''RECHAZADO'' where id = :p1106_id;',
'END IF;'))
,p_attribute_02=>'P1106_APROBAR_EXITO'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(400868911355723304)
,p_event_id=>wwv_flow_imp.id(400868488402723304)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'ocultarBarra();',
'$(''#btnAtras'').trigger("click");'))
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(400868044353723303)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'New'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'if :p1106_aprobador = :app_user then',
'    :p1106_flag := 1;',
'end if;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>400868044353723303
);
wwv_flow_imp.component_end;
end;
/
