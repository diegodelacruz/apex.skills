prompt --application/pages/page_00155
begin
--   Manifest
--     PAGE: 00155
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>109
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_page.create_page(
 p_id=>155
,p_name=>unistr('aprobar Conciliaci\00F3n')
,p_alias=>unistr('APROBAR-CONCILIACI\00D3N')
,p_step_title=>unistr('aprobar Conciliaci\00F3n')
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'03'
,p_created_on=>wwv_flow_imp.dz('20240801205631Z')
,p_last_updated_on=>wwv_flow_imp.dz('20241002180720Z')
,p_last_updated_by=>'MALBAN'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(258001691254352010)
,p_plug_name=>'Barra de acciones'
,p_region_template_options=>'#DEFAULT#:t-Form--stretchInputs'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(38289497777120142)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(37761271469106475)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(37860983999106559)
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(258002368141352017)
,p_name=>'CONCILIACION'
,p_template=>wwv_flow_imp.id(38289867500120143)
,p_display_sequence=>50
,p_include_in_reg_disp_sel_yn=>'Y'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT VC3,NVL(N3,0) N3',
'FROM TEMPORAL',
'WHERE COMPANIA=:G_COMPANIA AND PROGRAMA=''CONCILIA_TRIBUTARIA'' AND USUARIO=''FINANZAS_CT''',
'ORDER BY N19,N20;'))
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(37830327650106535)
,p_query_num_rows=>200
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
,p_updated_on=>wwv_flow_imp.dz('20240816193505Z')
,p_updated_by=>'MALBAN'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(258002485335352018)
,p_query_column_id=>1
,p_column_alias=>'VC3'
,p_column_display_sequence=>10
,p_column_heading=>unistr('Descripci\00F3n')
,p_use_as_row_header=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(258002594118352019)
,p_query_column_id=>2
,p_column_alias=>'N3'
,p_column_display_sequence=>20
,p_column_heading=>'Valor'
,p_use_as_row_header=>'N'
,p_column_format=>'999G999G999G999G990D00'
,p_column_alignment=>'RIGHT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(258002653312352020)
,p_plug_name=>'Botones'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(38290276266120143)
,p_plug_display_sequence=>60
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_condition_type=>'EXPRESSION'
,p_plug_display_when_condition=>'PK_CORP_FLUJOAPROBACION.F_APROBADORFLUJO(:P155_USUARIO, :P155_APROBADOR, :APP_MODULO ,:G_COMPANIA)=1'
,p_plug_display_when_cond2=>'PLSQL'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(258057054855137885)
,p_plug_name=>unistr('Aprobar Concilicaci\00F3n Tributaria &P155_IDPROCESO.')
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(38290610465120145)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_location=>null
,p_menu_id=>wwv_flow_imp.id(37761271469106475)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(37860983999106559)
,p_updated_on=>wwv_flow_imp.dz('20241002180720Z')
,p_updated_by=>'MALBAN'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(258002870872352022)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(258002653312352020)
,p_button_name=>'APROBAR'
,p_button_static_id=>'btnAprobar'
,p_button_action=>'REDIRECT_APP'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860181880106559)
,p_button_image_alt=>'Aprobar'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=100:102:&SESSION.::&DEBUG.::G_COMPANIA,G_MODULO,G_USUARIO,G_OBJETO,G_OBJETO_ID,G_USUARIO_FLUJO:&G_COMPANIA.,&APP_MODULO.,&APP_USER.,CONCILIACION_TRIBUTARIA,&P155_IDPROCESO.,&P155_APROBADOR.'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(258004003025352034)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(258001691254352010)
,p_button_name=>'VER_RUTA'
,p_button_action=>'REDIRECT_APP'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860056812106557)
,p_button_image_alt=>'Ver Ruta'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=100:104:&SESSION.::&DEBUG.::G_OBJETO,G_OBJETO_ID,G_TODO:CONCILIACION_TRIBUTARIA,&P155_IDPROCESO.,true'
,p_icon_css_classes=>'fa-road'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(258001792026352011)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(258001691254352010)
,p_button_name=>'Retrornar'
,p_button_static_id=>'btnRegresar'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860056812106557)
,p_button_image_alt=>'Retrornar'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:100:&SESSION.::&DEBUG.:::'
,p_icon_css_classes=>'fa-box-arrow-out-nw'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(258002972769352023)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(258002653312352020)
,p_button_name=>'RECHAZAR'
,p_button_static_id=>'btnRechazar'
,p_button_action=>'REDIRECT_APP'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860181880106559)
,p_button_image_alt=>'Rechazar'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=100:103:&SESSION.::&DEBUG.::G_COMPANIA,G_MODULO,G_USUARIO,G_OBJETO,G_OBJETO_ID,G_USUARIO_FLUJO:&G_COMPANIA.,&APP_MODULO.,&APP_USER.,CONCILIACION_TRIBUTARIA,&P155_IDPROCESO.,'
,p_grid_new_row=>'N'
,p_grid_new_column=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(258001814458352012)
,p_name=>'P155_APROBADOR'
,p_item_sequence=>10
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(258002033272352014)
,p_name=>'P155_IDPROCESO'
,p_item_sequence=>20
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(258002190044352015)
,p_name=>'P155_APROBACION_EXITO'
,p_item_sequence=>30
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(258002249739352016)
,p_name=>'P155_TERMINA_FLUJO'
,p_item_sequence=>40
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(258002708063352021)
,p_name=>'P155_USUARIO'
,p_item_sequence=>45
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(413252269415452647)
,p_name=>'P155_RESPUESTA'
,p_item_sequence=>70
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
,p_created_on=>wwv_flow_imp.dz('20240904161037Z')
,p_updated_on=>wwv_flow_imp.dz('20240904163413Z')
,p_created_by=>'MALBAN'
,p_updated_by=>'MALBAN'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(258003019785352024)
,p_name=>unistr('Cierre di\00E1logo: aprobar')
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(258002870872352022)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(258003143483352025)
,p_event_id=>wwv_flow_imp.id(258003019785352024)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P155_TERMINA_FLUJO'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'var trama = JSON.parse(this.data.G_RESULTADO);',
'var isTerminoFlujo= trama.resultado.terminoFlujo;',
'apex.item( "P155_TERMINA_FLUJO" ).setValue(0);',
'',
'if(this.data.G_EXITO==''true''){',
'    mensaje(''exito'', this.data.G_MENSAJE);',
'    if(isTerminoFlujo){',
'        apex.item( "P155_TERMINA_FLUJO" ).setValue(1);',
'    }',
'    $(''#btnAprobar'').hide();',
'    $(''#btnRechazar'').hide();',
'}',
'else{',
'    mensaje(''error'', this.data.G_MENSAJE);',
'}'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(258003273026352026)
,p_name=>unistr('Cierre di\00E1logo: aprobar exito')
,p_event_sequence=>20
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(258002870872352022)
,p_condition_element=>'P155_TERMINA_FLUJO'
,p_triggering_condition_type=>'GREATER_THAN_OR_EQUAL'
,p_triggering_expression=>'1'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
,p_updated_on=>wwv_flow_imp.dz('20240904163803Z')
,p_updated_by=>'MALBAN'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(258004203618352036)
,p_event_id=>wwv_flow_imp.id(258003273026352026)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'	',
'mostrarBarra();'))
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(258003383674352027)
,p_event_id=>wwv_flow_imp.id(258003273026352026)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'   V_RESPUESTA   VARCHAR2(100)  :='''';',
'',
'BEGIN',
'    -- Ejecuto el proceso para copiar los datos de la tabla TEMPORAL  a la tabla T_FINZ_CONCILIACIONMENSUAL',
'    -- adicional el proceso actualiza el campo ESTADO=2 de la tabla T_FINZ_CARGASMANUALES',
'    -- borra los registros de la tabla TEMPORAL',
'    PK_FINZ_CONCILIACION.SP_GRABACONCILIACION(:G_COMPANIA,''FINANZAS_CT'',SUBSTR(:P155_IDPROCESO,3,2),SUBSTR(:P155_IDPROCESO,5));',
'',
'    -- genero asiento contable',
'    PK_FINZ_CONCILIACION.SP_ASIENTOSCONCILIACION(:G_COMPANIA,''FINANZAS_CT'',SUBSTR(:P155_IDPROCESO,1,4),SUBSTR(:P155_IDPROCESO,5),V_RESPUESTA);',
'    :P155_RESPUESTA:=''BATHC: ''||V_RESPUESTA;',
'END;'))
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20240904163803Z')
,p_updated_by=>'MALBAN'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(258003488086352028)
,p_event_id=>wwv_flow_imp.id(258003273026352026)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
' $(''#btnRegresar'').trigger("click");',
'    $(''#btnAprobar'').hide();',
'    $(''#btnRechazar'').hide();'))
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(258004144810352035)
,p_event_id=>wwv_flow_imp.id(258003273026352026)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'ocultarBarra();'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(258003598839352029)
,p_name=>unistr('Cierre di\00E1logo: rechazar')
,p_event_sequence=>30
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(258002972769352023)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(258003691246352030)
,p_event_id=>wwv_flow_imp.id(258003598839352029)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'apex.item( "P155_TERMINA_FLUJO" ).setValue(0);',
'if(this.data.G_EXITO==''true''){',
'    mensaje(''exito'', this.data.G_MENSAJE);',
'    apex.item( "P155_TERMINA_FLUJO" ).setValue(1);',
'    $(''#btnAprobar'').hide();',
'    $(''#btnRechazar'').hide();',
'}    ',
'else{',
'    mensaje(''error'', this.data.G_MENSAJE);',
'}'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(258003744206352031)
,p_name=>unistr('Cierre di\00E1logo: rechazar exito')
,p_event_sequence=>40
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(258002972769352023)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(258003871771352032)
,p_event_id=>wwv_flow_imp.id(258003744206352031)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>'NULL;'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(258003916402352033)
,p_event_id=>wwv_flow_imp.id(258003744206352031)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
' $(''#btnRegresar'').trigger("click");',
'    $(''#btnAprobar'').hide();',
'    $(''#btnRechazar'').hide();'))
);
wwv_flow_imp.component_end;
end;
/
