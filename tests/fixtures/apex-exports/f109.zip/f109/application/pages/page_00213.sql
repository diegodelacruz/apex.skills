prompt --application/pages/page_00213
begin
--   Manifest
--     PAGE: 00213
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>109
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_page.create_page(
 p_id=>213
,p_name=>'Reporte Cobros Clientes'
,p_step_title=>'Reporte Cobros Clientes'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_page_component_map=>'18'
,p_created_on=>wwv_flow_imp.dz('20230705164635Z')
,p_last_updated_on=>wwv_flow_imp.dz('20210324050000Z')
,p_last_updated_by=>'CVACA'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(493558691835141802)
,p_plug_name=>'Filtros'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(38289867500120143)
,p_plug_display_sequence=>10
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(493562223141141838)
,p_plug_name=>'Selector de Reporte'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(38289867500120143)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_source_type=>'NATIVE_DISPLAY_SELECTOR'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'display_region_icons', 'N',
  'include_show_all', 'N',
  'rds_mode', 'STANDARD',
  'remember_selection', 'SESSION')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(480068915354017533)
,p_plug_name=>'Pendientes en Banco'
,p_parent_plug_id=>wwv_flow_imp.id(493562223141141838)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(37806762584106520)
,p_plug_display_sequence=>40
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select to_date(MPDGJ + 1900000,''yyyyddd'') FECDOC, trim(GMDL01) nombrebanco, MPCKNU referenciabancaria, MPAA/100 monto, trim(MPEXR) explicacion ',
'from F5509505@JDEDTADL a, f0901@JDEDTADL b',
'WHERE a.MPAID = b.GMAID',
'and MPAA>0 and MPEV02 != ''1'' AND MPEV01 <>''P''',
'and (MPDGJ BETWEEN TO_CHAR(TO_DATE(:P213_F_DESDE,''DD/MM/YYYY'') ,''YYYYDDD'') - 1900000 AND TO_CHAR(TO_DATE(:P213_F_HASTA,''DD/MM/YYYY'') ,''YYYYDDD'') - 1900000)',
'AND ((TRIM(a.MPCKNU) = :P213_REFERENCIA) OR (:P213_REFERENCIA IS NULL))',
'order by MPDGJ, GMDL01, MPCKNU'))
,p_plug_source_type=>'NATIVE_IR'
,p_ajax_items_to_submit=>'P213_F_DESDE,P213_F_HASTA,P213_REFERENCIA'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>210
,p_prn_height=>297
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(189237559436468326)
,p_max_row_count=>'1000000'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'CVACA'
,p_internal_uid=>189237559436468326
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(189237638008468327)
,p_db_column_name=>'FECDOC'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Fecha'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(189237786709468328)
,p_db_column_name=>'NOMBREBANCO'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Banco'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(189237807249468329)
,p_db_column_name=>'REFERENCIABANCARIA'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Referencia Bancaria'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(189237972415468330)
,p_db_column_name=>'MONTO'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Monto'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G990D00'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(189238013117468331)
,p_db_column_name=>'EXPLICACION'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>unistr('Explicaci\00F3n')
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(189267203432505439)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'1892673'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'FECDOC:NOMBREBANCO:REFERENCIABANCARIA:MONTO:EXPLICACION'
,p_created_on=>wwv_flow_imp.dz('20230705164635Z')
,p_updated_on=>wwv_flow_imp.dz('20230705164635Z')
,p_created_by=>'CVACA'
,p_updated_by=>'CVACA'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(480069529791017539)
,p_plug_name=>'Reversados'
,p_parent_plug_id=>wwv_flow_imp.id(493562223141141838)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(37806762584106520)
,p_plug_display_sequence=>50
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select trim(GMDL01) nombrebanco, MPCKNU referenciabancaria, trim(MPEXR) explicacion, to_date(MPDGJ + 1900000,''yyyyddd'') fechatransaccion, case when MPAA < 0 then ''D'' else ''C'' end Tipo,',
'MPAA/100 monto',
'from F5509505@JDEDTADL a, f0901@JDEDTADL b',
'WHERE a.MPAID = b.GMAID',
'and MPEV02 != ''1'' AND MPEV01 != ''P''',
'AND ((MPEXR LIKE ''%REV%'') OR (MPCKNU LIKE ''%REV%'') OR (MPEXR LIKE ''%DEVUEL%'') OR (MPCKNU LIKE ''%DEVUEL%''))',
'and (MPDGJ BETWEEN TO_CHAR(TO_DATE(:P213_F_DESDE,''DD/MM/YYYY'') ,''YYYYDDD'') - 1900000 AND TO_CHAR(TO_DATE(:P213_F_HASTA,''DD/MM/YYYY'') ,''YYYYDDD'') - 1900000)',
'AND ((TRIM(a.MPCKNU) = :P213_REFERENCIA) OR (:P213_REFERENCIA IS NULL))'))
,p_plug_source_type=>'NATIVE_IR'
,p_ajax_items_to_submit=>'P213_F_DESDE,P213_F_HASTA,P213_REFERENCIA'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>210
,p_prn_height=>297
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(189238123742468332)
,p_max_row_count=>'1000000'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'CVACA'
,p_internal_uid=>189238123742468332
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(189238292752468333)
,p_db_column_name=>'NOMBREBANCO'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Nombrebanco'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(189238372148468334)
,p_db_column_name=>'REFERENCIABANCARIA'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Referenciabancaria'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(189238407928468335)
,p_db_column_name=>'EXPLICACION'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Explicacion'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(189238550763468336)
,p_db_column_name=>'FECHATRANSACCION'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Fechatransaccion'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(189238653120468337)
,p_db_column_name=>'TIPO'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Tipo'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(189238756161468338)
,p_db_column_name=>'MONTO'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'Monto'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(189267976581505443)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'1892680'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'NOMBREBANCO:REFERENCIABANCARIA:EXPLICACION:FECHATRANSACCION:TIPO:MONTO'
,p_created_on=>wwv_flow_imp.dz('20230705164635Z')
,p_updated_on=>wwv_flow_imp.dz('20230705164635Z')
,p_created_by=>'CVACA'
,p_updated_by=>'CVACA'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(493558788069141803)
,p_plug_name=>'Resumen Cobros Procesados'
,p_parent_plug_id=>wwv_flow_imp.id(493562223141141838)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(37806762584106520)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select RYAN8 cliente, trim(d.NOMBRES) nombre, RYGLBA idbanco, to_date(RYDGJ + 1900000,''yyyyddd'') fecha, to_date(RYDMTJ + 1900000,''yyyyddd'') fechacobro, RYCKNU referenciabanco, sum(((RZPAAP*-1)/100)) monto, ',
'(trim(GMMCU)||''.''||trim(GMOBJ)||''.''||trim(GMSUB)) cuentabanco, trim(GMDL01) nombrebanco, RZDCTM tipodocumento, RYICU batch, CODIGOCANAL codigocanal, CANAL nombrecanal,',
'(SELECT distinct x.PRSTATUS FROM F5503B01@JDEDTADL x WHERE x.PRBANKREF = a.RYCKNU and x.PRURAB = a.RYICU and rownum = 1) procesado,',
'--(SELECT distinct x.PRDESC2000 FROM F5503B01@JDEDTADL x WHERE x.PRBANKREF = a.RYCKNU and x.PRURAB = a.RYICU and rownum = 1) observacion',
'a.RYEXR observacion',
'FROM F03B13@jdedtadl a, f03B14@jdedtadl b, f0901@JDEDTADL c, VT_JDE_CLIENTE d',
'where a.RYPYID = b.RZPYID',
'AND a.RYGLBA = c.GMAID ',
'and a.RYAN8 = d.CODIGO',
'and RYDGJ BETWEEN TO_CHAR(TO_DATE(:P213_F_DESDE,''DD/MM/YYYY'') ,''YYYYDDD'') - 1900000 AND TO_CHAR(TO_DATE(:P213_F_HASTA,''DD/MM/YYYY'') ,''YYYYDDD'') - 1900000',
'AND ((TRIM(a.RYCKNU) = :P213_REFERENCIA) OR (:P213_REFERENCIA IS NULL))',
'AND ((codigocanal = (:P213_CANAL)) OR (:P213_CANAL IS NULL))',
'AND ((RYAN8 = :P213_CLIENTE) OR (:P213_CLIENTE IS NULL))',
'--and (a.RYCKNU, a.RYICU) in (select distinct PRBANKREF, PRURAB from F5503B01@jdedtadl)',
'--and trim(a.RYCKNU) = ''58602629''',
'group by ',
'RYAN8, d.NOMBRES , RYGLBA , RYDGJ, RYCKNU, GMMCU,GMOBJ,GMSUB, trim(GMDL01), RZDCTM, RYICU,CODIGOCANAL,CANAL,a.RYEXR,RYDMTJ',
'having sum(((RZPAAP*-1)/100)) <> 0',
'order by RYAN8,RYCKNU;'))
,p_plug_source_type=>'NATIVE_IR'
,p_ajax_items_to_submit=>'P213_F_DESDE,P213_F_HASTA,P213_REFERENCIA,P213_CANAL,P213_CLIENTE'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>210
,p_prn_height=>297
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(189235064308468301)
,p_max_row_count=>'1000000'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'CVACA'
,p_internal_uid=>189235064308468301
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(189235101795468302)
,p_db_column_name=>'CLIENTE'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>unistr('C\00F3digo Cliente')
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(189235266163468303)
,p_db_column_name=>'IDBANCO'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Idbanco'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(189235350281468304)
,p_db_column_name=>'FECHA'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Fecha LM'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(189235403621468305)
,p_db_column_name=>'REFERENCIABANCO'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Referencia Bancaria'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(189235535039468306)
,p_db_column_name=>'MONTO'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Valor'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G990D00'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(189235639152468307)
,p_db_column_name=>'CUENTABANCO'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'Cuenta Bancaria'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(189235736210468308)
,p_db_column_name=>'NOMBREBANCO'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>'Banco'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(189235826358468309)
,p_db_column_name=>'TIPODOCUMENTO'
,p_display_order=>80
,p_column_identifier=>'H'
,p_column_label=>'Tipo Doc - Cobro'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(189235971327468310)
,p_db_column_name=>'BATCH'
,p_display_order=>90
,p_column_identifier=>'I'
,p_column_label=>'Batch'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(189236042980468311)
,p_db_column_name=>'PROCESADO'
,p_display_order=>100
,p_column_identifier=>'J'
,p_column_label=>'Procesado'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(189236128093468312)
,p_db_column_name=>'OBSERVACION'
,p_display_order=>110
,p_column_identifier=>'K'
,p_column_label=>'Observaciones'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(189238833788468339)
,p_db_column_name=>'NOMBRE'
,p_display_order=>120
,p_column_identifier=>'L'
,p_column_label=>'Cliente'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(189238911058468340)
,p_db_column_name=>'CODIGOCANAL'
,p_display_order=>130
,p_column_identifier=>'M'
,p_column_label=>'Codigocanal'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(189239026531468341)
,p_db_column_name=>'NOMBRECANAL'
,p_display_order=>140
,p_column_identifier=>'N'
,p_column_label=>'Nombrecanal'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(478829336545331335)
,p_db_column_name=>'FECHACOBRO'
,p_display_order=>150
,p_column_identifier=>'O'
,p_column_label=>'Fecha Cobro'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(189266000335505412)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'1892661'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'CLIENTE:NOMBRE:NOMBREBANCO:FECHA:FECHACOBRO:REFERENCIABANCO:MONTO:CUENTABANCO:TIPODOCUMENTO:BATCH:PROCESADO:OBSERVACION:'
,p_sum_columns_on_break=>'MONTO'
,p_created_on=>wwv_flow_imp.dz('20230705164635Z')
,p_updated_on=>wwv_flow_imp.dz('20230705164635Z')
,p_created_by=>'CVACA'
,p_updated_by=>'CVACA'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(493562381729141839)
,p_plug_name=>'Detalle Cobros'
,p_parent_plug_id=>wwv_flow_imp.id(493562223141141838)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(37806762584106520)
,p_plug_display_sequence=>30
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select RZAN8 cliente, trim(d.NOMBRES) nombre, RYGLBA idbanco, to_date(RYDGJ + 1900000,''yyyyddd'') fecha, to_date(RYDMTJ + 1900000,''yyyyddd'') fechacobro, RYCKNU referenciabanco, RYCKAM/100 MONTODEPOSITO, (((RZPAAP*-1)/100)) montoaplicado, ',
'(trim(GMMCU)||''.''||trim(GMOBJ)||''.''||trim(GMSUB)) cuentabanco, trim(GMDL01) nombrebanco, RZDCTM tipodocumento, RYICU batch, RZDOC ||''-''||RZDCT factura,',
'(SELECT distinct x.PRSTATUS FROM F5503B01@JDEDTADL x WHERE x.PRBANKREF = a.RYCKNU and x.PRURAB = a.RYICU and rownum = 1) procesado,',
'(SELECT distinct x.PRDESC2000 FROM F5503B01@JDEDTADL x WHERE x.PRBANKREF = a.RYCKNU and x.PRURAB = a.RYICU and rownum = 1) observacion',
'FROM F03B13@jdedtadl a, f03B14@jdedtadl b, f0901@JDEDTADL c, VT_JDE_CLIENTE d',
'where a.RYPYID = b.RZPYID',
'AND a.RYGLBA = c.GMAID',
'and b.RZAN8 = d.CODIGO',
'and (RYDGJ BETWEEN TO_CHAR(TO_DATE(:P213_F_DESDE,''DD/MM/YYYY'') ,''YYYYDDD'') - 1900000 AND TO_CHAR(TO_DATE(:P213_F_HASTA,''DD/MM/YYYY'') ,''YYYYDDD'') - 1900000)',
'AND ((TRIM(a.RYCKNU) = :P213_REFERENCIA) OR (:P213_REFERENCIA IS NULL))',
'AND ((codigocanal = (:P213_CANAL)) OR (:P213_CANAL IS NULL))',
'AND (((RYAN8 = :P213_CLIENTE) OR (:P213_CLIENTE IS NULL)) or (RZAN8 = :P213_CLIENTE))',
'--and (a.RYCKNU, a.RYICU) in (select distinct PRBANKREF, PRURAB from F5503B01@jdedtadl)',
'order by RZAN8,RYAN8 , RYCKNU;'))
,p_plug_source_type=>'NATIVE_IR'
,p_ajax_items_to_submit=>'P213_F_DESDE,P213_F_HASTA,P213_REFERENCIA,P213_CANAL,P213_CLIENTE'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>210
,p_prn_height=>297
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(189236318367468314)
,p_max_row_count=>'1000000'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'CVACA'
,p_internal_uid=>189236318367468314
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(189236425051468315)
,p_db_column_name=>'CLIENTE'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>unistr('C\00F3digo Cliente')
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(189236579928468316)
,p_db_column_name=>'IDBANCO'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Idbanco'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(189236669675468317)
,p_db_column_name=>'FECHA'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Fecha LM'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(189236719984468318)
,p_db_column_name=>'REFERENCIABANCO'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Referencia Bancaria'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(189236979517468320)
,p_db_column_name=>'CUENTABANCO'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'Cuenta Bancaria'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(189237084970468321)
,p_db_column_name=>'NOMBREBANCO'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>'Banco'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(189237177516468322)
,p_db_column_name=>'TIPODOCUMENTO'
,p_display_order=>80
,p_column_identifier=>'H'
,p_column_label=>'Tipo Doc - Cobro'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(189237217426468323)
,p_db_column_name=>'BATCH'
,p_display_order=>90
,p_column_identifier=>'I'
,p_column_label=>'Batch'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(189237355805468324)
,p_db_column_name=>'PROCESADO'
,p_display_order=>100
,p_column_identifier=>'J'
,p_column_label=>'Procesado'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(189237458373468325)
,p_db_column_name=>'OBSERVACION'
,p_display_order=>110
,p_column_identifier=>'K'
,p_column_label=>'Observacion'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(189239142145468342)
,p_db_column_name=>'NOMBRE'
,p_display_order=>120
,p_column_identifier=>'L'
,p_column_label=>'Cliente'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(189239245109468343)
,p_db_column_name=>'MONTODEPOSITO'
,p_display_order=>130
,p_column_identifier=>'M'
,p_column_label=>'Total Cobro'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G990D00'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(189239362491468344)
,p_db_column_name=>'MONTOAPLICADO'
,p_display_order=>140
,p_column_identifier=>'N'
,p_column_label=>'Valor Aplicado'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G990D00'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(189239663417468347)
,p_db_column_name=>'FACTURA'
,p_display_order=>150
,p_column_identifier=>'Q'
,p_column_label=>'Factura'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(478829416395331336)
,p_db_column_name=>'FECHACOBRO'
,p_display_order=>160
,p_column_identifier=>'R'
,p_column_label=>'Fecha Cobro'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(189266617761505429)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_type=>'REPORT'
,p_report_alias=>'1892667'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'CLIENTE:NOMBRE:NOMBREBANCO:FECHA:FECHACOBRO:REFERENCIABANCO:MONTODEPOSITO:CUENTABANCO:TIPODOCUMENTO:BATCH:PROCESADO:FACTURA:MONTOAPLICADO:'
,p_sum_columns_on_break=>'MONTOAPLICADO'
,p_created_on=>wwv_flow_imp.dz('20230705164635Z')
,p_updated_on=>wwv_flow_imp.dz('20230705164635Z')
,p_created_by=>'CVACA'
,p_updated_by=>'CVACA'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(973946023127365033)
,p_plug_name=>'Reportes Cobros Clientes'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(37817215439106526)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(37761271469106475)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(37860983999106559)
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(3743936145535273085)
,p_plug_name=>'Barra de acciones'
,p_region_template_options=>'#DEFAULT#:t-Form--stretchInputs'
,p_plug_template=>wwv_flow_imp.id(38289497777120142)
,p_plug_display_sequence=>30
,p_plug_display_point=>'REGION_POSITION_01'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(493558556212141801)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(3743936145535273085)
,p_button_name=>'BTN_BUSCAR'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860056812106557)
,p_button_image_alt=>'Buscar'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_icon_css_classes=>'fa-search'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(493560012582141816)
,p_name=>'P213_F_DESDE'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(493558691835141802)
,p_prompt=>unistr('Fecha Dep\00F3sito Desde: ')
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_colspan=>5
,p_grid_column=>1
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(493560111677141817)
,p_name=>'P213_F_HASTA'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(493558691835141802)
,p_prompt=>unistr('Fecha Dep\00F3sito Hasta: ')
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_colspan=>6
,p_grid_column=>7
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(493560227832141818)
,p_name=>'P213_REFERENCIA'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(493558691835141802)
,p_prompt=>unistr('Referencia Dep\00F3sito:')
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_colspan=>7
,p_grid_column=>1
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(493560359727141819)
,p_name=>'P213_CANAL'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(493558691835141802)
,p_prompt=>'Canal:'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select distinct a, b from (',
'    select (codigocanal||''-''||canal) a, codigocanal b from VT_JDE_CLIENTE a where estado = 1 ',
'                          )',
'order by a'))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_colspan=>7
,p_grid_column=>1
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(493560429294141820)
,p_name=>'P213_CLIENTE'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(493558691835141802)
,p_prompt=>'Cliente:'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select distinct a,b from (',
'    select codigo||''-''||nombres a, codigo b from VT_JDE_CLIENTE a where estado = 1',
'                          )',
'order by a                          '))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_colspan=>7
,p_grid_column=>1
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'NONE'
);
wwv_flow_imp.component_end;
end;
/
