prompt --application/pages/page_00200
begin
--   Manifest
--     PAGE: 00200
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>109
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_page.create_page(
 p_id=>200
,p_name=>'Reporte Cuentas Por Cobrar'
,p_step_title=>'Reporte Cuentas Por Cobrar'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_page_component_map=>'18'
,p_created_on=>wwv_flow_imp.dz('20230705164634Z')
,p_last_updated_on=>wwv_flow_imp.dz('20210917160546Z')
,p_last_updated_by=>'MCOELLO'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(351554549596748801)
,p_plug_name=>'Filtros'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(38289867500120143)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(351554969850748805)
,p_plug_name=>'Cuentas Por Cobrar'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(37806762584106520)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT NULL CODIGOPADRE, NULL NOMBREPADRE,NULL TIPO, NULL CONDICIONCREDITO, null DIASGRACIA, NULL VALOR_DEUDA, NULL VALOR_NO_VENCIDO,NULL RANGO18, NULL RANGO930, NULL RANGO3160, NULL RANGO61,  NULL TOTAL_VENCIDO,',
'TO_CHAR(TO_DATE(:P200_FECHA_INICIO,''DD/MM/YYYY'')) DIA1 ,TO_CHAR( TO_DATE(:P200_FECHA_INICIO ,''DD/MM/YYYY'')  +1) DIA2, TO_CHAR(TO_DATE(:P200_FECHA_INICIO ,''DD/MM/YYYY'')  +2) DIA3, TO_CHAR(TO_DATE(:P200_FECHA_INICIO ,''DD/MM/YYYY'')  +3) DIA4, TO_CHAR(TO'
||'_DATE(:P200_FECHA_INICIO ,''DD/MM/YYYY'')  +4) DIA5, ',
'NULL DIFERENCIAPORCOBRAR, NULL TOTALPAGADO, NULL PORCENTAJE, NULL PORCENTAJECOBRAR',
'FROM DUAL',
'',
'UNION',
'',
'SELECT NULL CODIGOPADRE,NULL NOMBREPADRE, TIPO, NULL CONDICIONCREDITO, NULL DIASGRACIA, VALOR_DEUDA, VALOR_NO_VENCIDO, RANGO18, RANGO930, RANGO3160, RANGO61, TOTAL_VENCIDO, TO_CHAR(DIA1) DIA1, TO_CHAR(DIA2) DIA2, TO_CHAR(DIA3) DIA3, TO_CHAR(DIA4) DIA'
||'4, TO_CHAR(DIA5) DIA5,',
'(TOTAL_VENCIDO - DIA1 -DIA2- DIA3-DIA4-DIA5) DIFERENCIAPORCOBRAR,(DIA1 +DIA2 +DIA3+DIA4+DIA5) TOTALPAGADO, CASE WHEN TOTAL_VENCIDO = 0 THEN 0 ELSE  ROUND(((DIA1 +DIA2 +DIA3+DIA4+DIA5)/TOTAL_VENCIDO)*100,2) END PORCENTAJE, ',
'CASE WHEN TOTAL_VENCIDO =0 THEN 0 ELSE ROUND(((TOTAL_VENCIDO - DIA1 -DIA2- DIA3-DIA4-DIA5)/TOTAL_VENCIDO) * 100,2) END PORCENTAJECOBRAR  FROM (',
'',
'select CODIGOPADRE2 CODIGOPADRE,  NOMBREPADRE, TIPO, '''' CONDICIONCREDITO, null DIASGRACIA, SUM(VALOR_DEUDA) VALOR_DEUDA, SUM(VALOR_NO_VENCIDO) VALOR_NO_VENCIDO, SUM(RANGO18) RANGO18, SUM(RANGO930) RANGO930, SUM(RANGO3160) RANGO3160, SUM(RANGO61) RANG'
||'O61 ,  SUM(TOTAL_VENCIDO) TOTAL_VENCIDO,',
'SUM(DIA1) DIA1, SUM(DIA2) DIA2, SUM(DIA3) DIA3, SUM(DIA4) DIA4, SUM(DIA5) DIA5 FROM (',
'SELECT   CODIGOPADRE,  NULL CODIGOPADRE2 ,NULL NOMBREPADRE, TIPO, '''' CONDICIONCREDITO, null DIASGRACIA, SUM(VALOR_DEUDA) VALOR_DEUDA, SUM(VALOR_NO_VENCIDO) VALOR_NO_VENCIDO, SUM(VALOR_RANGO1) RANGO18, SUM(VALOR_RANGO2) RANGO930, SUM(VALOR_RANGO3) RAN'
||'GO3160, SUM(VALOR_RANGO4) RANGO61 ,  SUM(TOTAL_VENCIDO) TOTAL_VENCIDO,',
'(SELECT CASE WHEN SUM(RZPAAP)/100 IS NULL THEN 0 ELSE ABS(SUM(RZPAAP)/100) END  FROM F03B14@JDEDTADL',
'WHERE RZDGJ = TO_CHAR(TO_DATE(:P200_FECHA_INICIO),''YYYYDDD'')-1900000',
'AND RZPA8 = CODIGOPADRE',
'AND RZDCTM= ''RC'') DIA1, ',
'(SELECT CASE WHEN SUM(RZPAAP)/100 IS NULL THEN 0 ELSE ABS(SUM(RZPAAP)/100) END FROM F03B14@JDEDTADL',
'WHERE RZDGJ = TO_CHAR(TO_DATE(:P200_FECHA_INICIO)+1,''YYYYDDD'')-1900000',
'AND RZPA8 = CODIGOPADRE',
'AND RZDCTM= ''RC'') DIA2,',
'(SELECT CASE WHEN SUM(RZPAAP)/100 IS NULL THEN 0 ELSE ABS(SUM(RZPAAP)/100)  END  FROM F03B14@JDEDTADL',
'WHERE RZDGJ = TO_CHAR(TO_DATE(:P200_FECHA_INICIO)+2,''YYYYDDD'')-1900000',
'AND RZPA8 = CODIGOPADRE',
'AND RZDCTM= ''RC'') DIA3,',
'(SELECT CASE WHEN SUM(RZPAAP)/100 IS NULL THEN 0 ELSE ABS(SUM(RZPAAP)/100)  END FROM F03B14@JDEDTADL',
'WHERE RZDGJ = TO_CHAR(TO_DATE(:P200_FECHA_INICIO)+3,''YYYYDDD'')-1900000',
'AND RZPA8 = CODIGOPADRE',
'AND RZDCTM= ''RC'') DIA4,',
'(SELECT CASE WHEN SUM(RZPAAP)/100 IS NULL THEN 0 ELSE ABS(SUM(RZPAAP)/100)  END FROM F03B14@JDEDTADL',
'WHERE RZDGJ = TO_CHAR(TO_DATE(:P200_FECHA_INICIO) +4,''YYYYDDD'')-1900000',
'AND RZPA8 = CODIGOPADRE',
'AND RZDCTM= ''RC'') DIA5',
'FROM VT_JDE_CUENTASXCOBRAR',
'WHERE TIPO IS NOT NULL',
'GROUP BY TIPO,CODIGOPADRE) A',
'GROUP BY CODIGOPADRE2, NOMBREPADRE, TIPO, CONDICIONCREDITO)',
'',
'UNION ',
'',
'SELECT CODIGOPADRE, NOMBREPADRE, TIPO, CONDICIONCREDITO, DIASGRACIA, SUM(VALOR_DEUDA) VALOR_DEUDA, SUM(VALOR_NO_VENCIDO) VALOR_NO_VENCIDO, SUM(RANGO18) RANGO18, SUM(RANGO930) RANGO930, SUM(RANGO3160) RANGO3160, SUM(RANGO61) RANGO61, SUM(TOTAL_VENCIDO'
||') TOTAL_VENCIDO, TO_CHAR(SUM(DIA1)) DIA1, TO_CHAR(SUM(DIA2)) DIA2, TO_CHAR(SUM(DIA3)) DIA3, TO_CHAR(SUM(DIA4)) DIA4, TO_CHAR(SUM(DIA5)) DIA5,',
'SUM(TOTAL_VENCIDO - DIA1 -DIA2- DIA3-DIA4-DIA5) DIFERENCIAPORCOBRAR,SUM(DIA1 +DIA2 +DIA3+DIA4+DIA5) TOTALPAGADO, CASE WHEN SUM(TOTAL_VENCIDO) = 0 THEN MAX(0) ELSE  ROUND((SUM(DIA1 +DIA2 +DIA3+DIA4+DIA5)/SUM(TOTAL_VENCIDO))*100,2) END PORCENTAJE, ',
'CASE WHEN SUM(TOTAL_VENCIDO) =0 THEN MAX(0) ELSE ROUND((SUM(TOTAL_VENCIDO - DIA1 -DIA2- DIA3-DIA4-DIA5)/SUM(TOTAL_VENCIDO)) * 100,2) END PORCENTAJECOBRAR  FROM (',
'SELECT CODIGOPADRE, NOMBREPADRE, TIPO, CONDICIONCREDITO,DIASGRACIA, SUM(VALOR_DEUDA) VALOR_DEUDA, SUM(VALOR_NO_VENCIDO) VALOR_NO_VENCIDO, SUM(VALOR_RANGO1) RANGO18, SUM(VALOR_RANGO2) RANGO930, SUM(VALOR_RANGO3) RANGO3160, SUM(VALOR_RANGO4) RANGO61, S'
||'UM(TOTAL_VENCIDO) TOTAL_VENCIDO,',
'(SELECT TO_CHAR(CASE WHEN SUM(RZPAAP)/100 IS NULL THEN 0 ELSE ABS(SUM(RZPAAP)/100) END)  FROM F03B14@JDEDTADL',
'WHERE RZDGJ = TO_CHAR(TO_DATE(:P200_FECHA_INICIO),''YYYYDDD'')-1900000',
'AND RZPA8 = CODIGOPADRE',
'AND RZDCTM= ''RC'') DIA1, ',
'(SELECT TO_CHAR(CASE WHEN SUM(RZPAAP)/100 IS NULL THEN 0 ELSE ABS(SUM(RZPAAP)/100) END) FROM F03B14@JDEDTADL',
'WHERE RZDGJ = TO_CHAR(TO_DATE(:P200_FECHA_INICIO)+1,''YYYYDDD'')-1900000',
'AND RZPA8 = CODIGOPADRE',
'AND RZDCTM= ''RC'') DIA2,',
'(SELECT TO_CHAR(CASE WHEN SUM(RZPAAP)/100 IS NULL THEN 0 ELSE ABS(SUM(RZPAAP)/100)  END)  FROM F03B14@JDEDTADL',
'WHERE RZDGJ = TO_CHAR(TO_DATE(:P200_FECHA_INICIO)+2,''YYYYDDD'')-1900000',
'AND RZPA8 = CODIGOPADRE',
'AND RZDCTM= ''RC'') DIA3,',
'(SELECT TO_CHAR(CASE WHEN SUM(RZPAAP)/100 IS NULL THEN 0 ELSE ABS(SUM(RZPAAP)/100)  END) FROM F03B14@JDEDTADL',
'WHERE RZDGJ = TO_CHAR(TO_DATE(:P200_FECHA_INICIO)+3,''YYYYDDD'')-1900000',
'AND RZPA8 = CODIGOPADRE',
'AND RZDCTM= ''RC'') DIA4,',
'(SELECT TO_CHAR(CASE WHEN SUM(RZPAAP)/100 IS NULL THEN 0 ELSE ABS(SUM(RZPAAP)/100)  END) FROM F03B14@JDEDTADL',
'WHERE RZDGJ = TO_CHAR(TO_DATE(:P200_FECHA_INICIO) +4,''YYYYDDD'')-1900000',
'AND RZPA8 = CODIGOPADRE',
'AND RZDCTM= ''RC'') DIA5',
'FROM VT_JDE_CUENTASXCOBRAR  ',
'WHERE  VALOR_DEUDA<>0',
'AND CODIGOPADRE <> 1',
'GROUP BY CODIGOPADRE, NOMBREPADRE, TIPO, CONDICIONCREDITO,DIASGRACIA) ',
'GROUP BY CODIGOPADRE, NOMBREPADRE, TIPO, CONDICIONCREDITO,DIASGRACIA',
'',
'UNION',
'',
'SELECT CODIGOPADRE, translate (''TOTAL'' using nchar_cs) NOMBREPADRE, translate ('' '' using nchar_cs) TIPO, CONDICIONCREDITO, DIASGRACIA, VALOR_DEUDA, VALOR_NO_VENCIDO, RANGO18, RANGO930, RANGO3160, RANGO61, TOTAL_VENCIDO, TO_CHAR(DIA1) DIA1, TO_CHAR(DI'
||'A2) DIA2, TO_CHAR(DIA3) DIA3, TO_CHAR(DIA4) DIA4, TO_CHAR(DIA5) DIA5,',
'(TOTAL_VENCIDO - DIA1 -DIA2- DIA3-DIA4-DIA5) DIFERENCIAPORCOBRAR,(DIA1 +DIA2 +DIA3+DIA4+DIA5) TOTALPAGADO, CASE WHEN TOTAL_VENCIDO = 0 THEN 0 ELSE  ROUND(((DIA1 +DIA2 +DIA3+DIA4+DIA5)/TOTAL_VENCIDO)*100,2) END PORCENTAJE, ',
'CASE WHEN TOTAL_VENCIDO =0 THEN 0 ELSE ROUND(((TOTAL_VENCIDO - DIA1 -DIA2- DIA3-DIA4-DIA5)/TOTAL_VENCIDO) * 100,2) END PORCENTAJECOBRAR  FROM (',
'SELECT CODIGOPADRE2 CODIGOPADRE, NOMBREPADRE, TIPO, CONDICIONCREDITO, DIASGRACIA,SUM(VALOR_DEUDA) VALOR_DEUDA, SUM(VALOR_NO_VENCIDO) VALOR_NO_VENCIDO, SUM(RANGO18) RANGO18, SUM(RANGO930) RANGO930, SUM(RANGO3160) RANGO3160, SUM(RANGO61) RANGO61 ,  SUM'
||'(TOTAL_VENCIDO) TOTAL_VENCIDO,',
'SUM(DIA1) DIA1, SUM(DIA2) DIA2, SUM(DIA3) DIA3,SUM(DIA4) DIA4,SUM(DIA5) DIA5 FROM (',
'',
'SELECT   CODIGOPADRE, NULL CODIGOPADRE2, NULL NOMBREPADRE, '' '' TIPO, '''' CONDICIONCREDITO, null DIASGRACIA, SUM(VALOR_DEUDA) VALOR_DEUDA, SUM(VALOR_NO_VENCIDO) VALOR_NO_VENCIDO, SUM(VALOR_RANGO1) RANGO18, SUM(VALOR_RANGO2) RANGO930, SUM(VALOR_RANGO3) '
||'RANGO3160, SUM(VALOR_RANGO4) RANGO61 ,  SUM(TOTAL_VENCIDO) TOTAL_VENCIDO,',
'(SELECT CASE WHEN SUM(RZPAAP)/100 IS NULL THEN 0 ELSE ABS(SUM(RZPAAP)/100) END  FROM F03B14@JDEDTADL',
'WHERE RZDGJ = TO_CHAR(TO_DATE(:P200_FECHA_INICIO),''YYYYDDD'')-1900000',
'AND RZPA8 = CODIGOPADRE',
'AND RZDCTM= ''RC'') DIA1, ',
'(SELECT CASE WHEN SUM(RZPAAP)/100 IS NULL THEN 0 ELSE ABS(SUM(RZPAAP)/100) END FROM F03B14@JDEDTADL',
'WHERE RZDGJ = TO_CHAR(TO_DATE(:P200_FECHA_INICIO)+1,''YYYYDDD'')-1900000',
'AND RZPA8 = CODIGOPADRE',
'AND RZDCTM= ''RC'') DIA2,',
'(SELECT CASE WHEN SUM(RZPAAP)/100 IS NULL THEN 0 ELSE ABS(SUM(RZPAAP)/100)  END  FROM F03B14@JDEDTADL',
'WHERE RZDGJ = TO_CHAR(TO_DATE(:P200_FECHA_INICIO)+2,''YYYYDDD'')-1900000',
'AND RZPA8 = CODIGOPADRE',
'AND RZDCTM= ''RC'') DIA3,',
'(SELECT CASE WHEN SUM(RZPAAP)/100 IS NULL THEN 0 ELSE ABS(SUM(RZPAAP)/100)  END FROM F03B14@JDEDTADL',
'WHERE RZDGJ = TO_CHAR(TO_DATE(:P200_FECHA_INICIO)+3,''YYYYDDD'')-1900000',
'AND RZPA8 = CODIGOPADRE',
'AND RZDCTM= ''RC'') DIA4,',
'(SELECT CASE WHEN SUM(RZPAAP)/100 IS NULL THEN 0 ELSE ABS(SUM(RZPAAP)/100)  END FROM F03B14@JDEDTADL',
'WHERE RZDGJ = TO_CHAR(TO_DATE(:P200_FECHA_INICIO) +4,''YYYYDDD'')-1900000',
'AND RZPA8 = CODIGOPADRE',
'AND RZDCTM= ''RC'') DIA5',
'FROM VT_JDE_CUENTASXCOBRAR',
'WHERE TIPO IS NOT NULL',
'GROUP BY CODIGOPADRE)',
'GROUP BY CODIGOPADRE2 , NOMBREPADRE, TIPO, CONDICIONCREDITO,DIASGRACIA)',
'',
'ORDER BY TIPO DESC, CODIGOPADRE   DESC, VALOR_DEUDA DESC'))
,p_plug_source_type=>'NATIVE_IR'
,p_ajax_items_to_submit=>'P200_FECHA_INICIO,P200_FECHA_FIN'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>210
,p_prn_height=>297
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(351555024998748806)
,p_max_row_count=>'1000000'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'MCOELLO'
,p_internal_uid=>351555024998748806
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(351555194260748807)
,p_db_column_name=>'CODIGOPADRE'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>unistr('C\00F3digo Padre')
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(351555276067748808)
,p_db_column_name=>'NOMBREPADRE'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Cliente'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(351555343071748809)
,p_db_column_name=>'TIPO'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Tipo'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(351555477191748810)
,p_db_column_name=>'CONDICIONCREDITO'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>unistr('Condici\00F3n Cr\00E9dito')
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(351555543477748811)
,p_db_column_name=>'VALOR_DEUDA'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Valor Deuda'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(351555606026748812)
,p_db_column_name=>'VALOR_NO_VENCIDO'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'Valor No Vencido'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(351556191316748817)
,p_db_column_name=>'TOTAL_VENCIDO'
,p_display_order=>110
,p_column_identifier=>'K'
,p_column_label=>'Total Vencido'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(539283454463279018)
,p_db_column_name=>'DIASGRACIA'
,p_display_order=>200
,p_column_identifier=>'AC'
,p_column_label=>unistr('D\00EDas de Gracia')
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(539283554687279019)
,p_db_column_name=>'RANGO18'
,p_display_order=>210
,p_column_identifier=>'AD'
,p_column_label=>'Rango 0-8'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(539283649524279020)
,p_db_column_name=>'RANGO930'
,p_display_order=>220
,p_column_identifier=>'AE'
,p_column_label=>'Rango 9-15'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(539283724558279021)
,p_db_column_name=>'RANGO3160'
,p_display_order=>230
,p_column_identifier=>'AF'
,p_column_label=>'Rango 16-30'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(539283858082279022)
,p_db_column_name=>'RANGO61'
,p_display_order=>240
,p_column_identifier=>'AG'
,p_column_label=>'Rango >30'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(539283910744279023)
,p_db_column_name=>'DIA1'
,p_display_order=>250
,p_column_identifier=>'AH'
,p_column_label=>'Dia1'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(539284027261279024)
,p_db_column_name=>'DIA2'
,p_display_order=>260
,p_column_identifier=>'AI'
,p_column_label=>'Dia2'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(539284163473279025)
,p_db_column_name=>'DIA3'
,p_display_order=>270
,p_column_identifier=>'AJ'
,p_column_label=>'Dia3'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(539284271045279026)
,p_db_column_name=>'DIA4'
,p_display_order=>280
,p_column_identifier=>'AK'
,p_column_label=>'Dia4'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(539284324674279027)
,p_db_column_name=>'DIA5'
,p_display_order=>290
,p_column_identifier=>'AL'
,p_column_label=>'Dia5'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(539284474888279028)
,p_db_column_name=>'DIFERENCIAPORCOBRAR'
,p_display_order=>300
,p_column_identifier=>'AM'
,p_column_label=>'Diferencia Por Cobrar'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(539284551306279029)
,p_db_column_name=>'TOTALPAGADO'
,p_display_order=>310
,p_column_identifier=>'AN'
,p_column_label=>'Total Pagado $'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(539284657036279030)
,p_db_column_name=>'PORCENTAJE'
,p_display_order=>320
,p_column_identifier=>'AO'
,p_column_label=>'Total Pagado %'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(539284797147279031)
,p_db_column_name=>'PORCENTAJECOBRAR'
,p_display_order=>330
,p_column_identifier=>'AP'
,p_column_label=>'% Por cobrar'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(351571591675812279)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'3515716'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'CODIGOPADRE:NOMBREPADRE:TIPO:CONDICIONCREDITO:DIASGRACIA:VALOR_DEUDA:VALOR_NO_VENCIDO:TOTAL_VENCIDO:RANGO18:RANGO930:RANGO3160:RANGO61:DIA1:DIA2:DIA3:DIA4:DIA5:DIFERENCIAPORCOBRAR:TOTALPAGADO:PORCENTAJE:PORCENTAJECOBRAR:'
,p_created_on=>wwv_flow_imp.dz('20230705164634Z')
,p_updated_on=>wwv_flow_imp.dz('20230705164634Z')
,p_created_by=>'CVACA'
,p_updated_by=>'CVACA'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(691409265556770482)
,p_plug_name=>'Reporte Cuentas Por Cobrar'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(37817215439106526)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(37761271469106475)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(37860983999106559)
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(2290761101602475749)
,p_plug_name=>'Barra de acciones'
,p_region_template_options=>'#DEFAULT#:t-Form--stretchInputs'
,p_plug_template=>wwv_flow_imp.id(38289497777120142)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'REGION_POSITION_01'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(351554135720747435)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(2290761101602475749)
,p_button_name=>'BUSCAR'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860056812106557)
,p_button_image_alt=>'Buscar'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_icon_css_classes=>'fa-search'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(351554772938748803)
,p_name=>'P200_FECHA_INICIO'
,p_is_required=>true
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(351554549596748801)
,p_prompt=>'Fecha Inicio'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(351554866120748804)
,p_name=>'P200_FECHA_FIN'
,p_is_required=>true
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(351554549596748801)
,p_prompt=>'Fecha Fin'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_imp.component_end;
end;
/
