prompt --application/pages/page_02003
begin
--   Manifest
--     PAGE: 02003
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>109
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_page.create_page(
 p_id=>2003
,p_name=>unistr('D\00EDas promedio de pago')
,p_step_title=>unistr('D\00EDas promedio de pago')
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_page_component_map=>'03'
,p_created_on=>wwv_flow_imp.dz('20230705164635Z')
,p_last_updated_on=>wwv_flow_imp.dz('20230112170502Z')
,p_last_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(379202407108612004)
,p_name=>unistr('D\00EDas promedio de Pago')
,p_template=>wwv_flow_imp.id(38289867500120143)
,p_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select rpan8',
'	, max(abalph) nombre',
'	, max(abac02) canal',
'	--, round(avg((to_date(rpjcl+ 1900000,''yyyyddd'')-to_date(rpdivj+ 1900000,''yyyyddd''))),2) promedio',
'	--, round(avg(rpjcl - rpdivj),2) promedio',
'	, avg(data.pk_commons.f_jde2g(rpjcl) - data.pk_commons.f_jde2g(rpdivj)) promedio',
'	, rpfy+2000 anio',
'	, rppn mes',
'from f0101@jdedtadl, f03b11@jdedtadl',
'where aban8 = rpan8',
'	and rpdct in (''FN'',''FE'')',
'	and rppst = ''P''',
'	and (abac02=:p2003_canal or :p2003_canal is null)',
'	and (rpan8=:p2003_cliente or :p2003_cliente is null)',
'	and (rppa8 =:p2003_grupocliente or :p2003_grupocliente is null)',
'	--and rpdivj between to_char(to_date(:p2003_desde,''DD-MM-YYYY''),''YYYYDDD'')-1900000 and to_char(to_date(:p2003_hasta,''DD-MM-YYYY''),''YYYYDDD'' )-1900000',
'	and rpdivj between data.pk_commons.f_g2jde(:p2003_desde) and data.pk_commons.f_g2jde(:p2003_hasta)',
'group by rpan8,rpfy,rppn'))
,p_ajax_enabled=>'Y'
,p_ajax_items_to_submit=>'P2003_DESDE,P2003_HASTA'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(37830327650106535)
,p_query_num_rows=>30
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_show_nulls_as=>'-'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'Y'
,p_csv_output_link_text=>'Descargar'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(379202548955612005)
,p_query_column_id=>1
,p_column_alias=>'RPAN8'
,p_column_display_sequence=>1
,p_column_heading=>unistr('C\00F3d. Cliente')
,p_use_as_row_header=>'N'
,p_column_alignment=>'CENTER'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(379203004516612010)
,p_query_column_id=>2
,p_column_alias=>'NOMBRE'
,p_column_display_sequence=>2
,p_column_heading=>'Cliente'
,p_use_as_row_header=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(379203105573612011)
,p_query_column_id=>3
,p_column_alias=>'CANAL'
,p_column_display_sequence=>3
,p_column_heading=>'Canal'
,p_use_as_row_header=>'N'
,p_column_alignment=>'CENTER'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(379202674199612006)
,p_query_column_id=>4
,p_column_alias=>'PROMEDIO'
,p_column_display_sequence=>6
,p_column_heading=>'Promedio'
,p_use_as_row_header=>'N'
,p_column_format=>'999G999G999G999G990D00'
,p_column_alignment=>'RIGHT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(243817747724109949)
,p_query_column_id=>5
,p_column_alias=>'ANIO'
,p_column_display_sequence=>4
,p_column_heading=>unistr('A\00F1o')
,p_use_as_row_header=>'N'
,p_column_alignment=>'CENTER'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(243817846112109950)
,p_query_column_id=>6
,p_column_alias=>'MES'
,p_column_display_sequence=>5
,p_column_heading=>'Mes'
,p_use_as_row_header=>'N'
,p_column_alignment=>'CENTER'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(722885536737894061)
,p_plug_name=>unistr('Par\00E1metros')
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(38289867500120143)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(722886039840894066)
,p_plug_name=>'Barra de Acciones'
,p_region_template_options=>'#DEFAULT#:t-Form--stretchInputs'
,p_plug_template=>wwv_flow_imp.id(38289497777120142)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'REGION_POSITION_01'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(379194152104568489)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(722886039840894066)
,p_button_name=>'BUSCAR'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860056812106557)
,p_button_image_alt=>'Buscar'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_icon_css_classes=>'fa-search'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(379195105692568490)
,p_name=>'P2003_DESDE'
,p_is_required=>true
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(722885536737894061)
,p_prompt=>'Desde'
,p_format_mask=>'dd/mm/yyyy'
,p_source=>'SELECT ADD_MONTHS( SYSDATE,-6) FROM DUAL'
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(379195581003568492)
,p_name=>'P2003_HASTA'
,p_is_required=>true
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(722885536737894061)
,p_prompt=>'Hasta'
,p_format_mask=>'dd/mm/yyyy'
,p_source=>'SYSDATE'
,p_source_type=>'EXPRESSION'
,p_source_language=>'PLSQL'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(379202761315612007)
,p_name=>'P2003_CANAL'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(722885536737894061)
,p_prompt=>'Canal'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'LOV_CANAL'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select DRDL01  as d,',
'     DRKY    as r',
'  from VT_JDE_UDCJDE WHERE DRSY= ''01'' AND DRRT= ''02''',
' order by 1'))
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(379202891969612008)
,p_name=>'P2003_CLIENTE'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(722885536737894061)
,p_prompt=>'Cliente'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'LOV_CLIENTES'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select CODIGO||''-''||NOMBRES as d,',
'     CODIGO   as r',
'  from VT_JDE_CLIENTE',
' order by 1'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'Seleccione'
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(379202944165612009)
,p_name=>'P2003_GRUPOCLIENTE'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(722885536737894061)
,p_prompt=>'Grupo'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'LOV_GRUPO_CLIENTES'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'  select DISTINCT CODIGOGRUPO||''-''||GRUPO  as d,',
'       CODIGOGRUPO as r',
'  from VT_JDE_CLIENTE',
' order by 1'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'Seleccione'
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'NONE'
);
wwv_flow_imp.component_end;
end;
/
