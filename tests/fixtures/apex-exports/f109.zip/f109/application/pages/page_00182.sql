prompt --application/pages/page_00182
begin
--   Manifest
--     PAGE: 00182
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>109
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_page.create_page(
 p_id=>182
,p_name=>'GESTION TRIBUTARIA - GESTIONAR PERIODOS'
,p_alias=>'GESTION-TRIBUTARIA-GESTIONAR-PERIODOS'
,p_step_title=>'Gestionar Datos de Periodo'
,p_autocomplete_on_off=>'OFF'
,p_html_page_header=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<meta charset="UTF-8">',
'<script src="https://cdnjs.cloudflare.com/ajax/libs/xlsx/0.18.5/xlsx.full.min.js"></script>'))
,p_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'let v_tiene_cambios=0;',
'let v_JSONGESTION="";',
'let v_JSONCOLUMNAS="";',
'let v_JSONCOLUMNASMAYORES="";',
'let v_actividades_ultimo_click="";',
'let v_secDetalle = "#secDetalle";',
'let v_regBarraAccion2 = "#regBarraAccion2";',
'let v_secAlerta = "#secAlerta";',
'let v_secItems = "#secItems";',
'let v_regSecVenta = "#regSecVenta";',
'let v_regSecRetencion = "#regSecRetencion";',
'function f_habilita_recarga_click_actividades(){',
'	if (window.P182_ACTIVIDADES_CLICK_BIND) return;',
'	window.P182_ACTIVIDADES_CLICK_BIND = true;',
'	v_actividades_ultimo_click = $v("P182_ACTIVIDADES");',
'	$(document).on("change", "input[name=''P182_ACTIVIDADES'']", function(){',
'		v_actividades_ultimo_click = this.value;',
'	});',
'	$(document).on("click", "input[name=''P182_ACTIVIDADES'']", function(){',
'		const valorActual = this.value;',
'		const repiteSeleccion = valorActual === v_actividades_ultimo_click;',
'		v_actividades_ultimo_click = valorActual;',
'		if (repiteSeleccion) {',
'			setTimeout(function(){ apex.event.trigger("#P182_ACTIVIDADES", "change"); }, 0);',
'		}',
'	});',
'}',
'function f_setearPopUp(p_coddoc,p_coddct,p_tipo){',
'	$s("P182_CODDOC_REEMB",p_coddoc);',
'	$s("P182_TIPO_REEMB",p_tipo);',
'	$s("P182_CODDCT_REEMB",p_coddct);',
'}',
'',
'function f_setearRegistro(p_id, p_idpadre, p_accion) {',
'    let jsonData = "";',
'	try{',
'		jsonData = JSON.parse(v_JSONGESTION);',
'	}catch(ex){',
'		jsonData = v_JSONGESTION;',
'	}',
'	let v_filtro=1;',
'	if (p_accion === ''borrar'') {',
'		const jsonFiltrado = jsonData.filter(item => parseInt(item.ID, 10) !== parseInt(p_id, 10));',
'		v_JSONGESTION= JSON.stringify(jsonFiltrado);',
unistr('		ejecutarConBarraCarga(v_filtro); // Recargar la tabla despu\00E9s de borrar'),
'		mensajeExito("Resgistro eliminado correctanmente");',
'	}',
'	if (p_accion === ''duplicar'') {',
'		const registroOriginal = jsonData.find(item => parseInt(item.ID, 10) === parseInt(p_id, 10));',
'		if (!registroOriginal) return;',
'',
'		const filtradosPorPadre = jsonData.filter(item => item.IDPADRE === p_idpadre);',
'		const maxID = filtradosPorPadre.length > 0',
'			? Math.max(...filtradosPorPadre.map(item => parseInt(item.ID, 10))) + 10',
'			: parseInt(p_id, 10) + 10;',
'',
'		const nuevoRegistro = JSON.parse(JSON.stringify(registroOriginal));',
'		nuevoRegistro.ID = maxID;',
'		const camposLimpiar = (v_JSONCOLUMNASMAYORES || "").split(",");',
'		camposLimpiar.forEach(campo => {',
'			if (campo) nuevoRegistro[campo.trim()] = "";',
'		});',
'',
'		const idx = jsonData.findIndex(item => parseInt(item.ID, 10) === parseInt(p_id, 10));',
'		if (idx !== -1) {',
'			jsonData.splice(idx + 1, 0, nuevoRegistro);',
'		} else {',
'			jsonData.push(nuevoRegistro);',
'		}',
'		v_JSONGESTION= JSON.stringify(jsonData);',
'		ejecutarConBarraCarga(v_filtro);',
'		mensajeExito("Resgistro duplicado correctanmente");',
'	}',
'} ',
'',
'function f_getsecuencias(){',
'	let secuencias = {};',
'	["FN", "D1", "FE", "FD","RT"].forEach(codigo => {',
'		let itemName = "P182_SECUENCIA" + codigo;',
'		let valor = $v(itemName).trim();',
'		if (valor===""){valor ="0";}',
'		if (valor !== "0") {',
'			secuencias[codigo] = valor;',
'		}',
'	});',
'	return secuencias;',
'}',
'',
'function f_preprocesar_json_segun_secuencias(p_jsonData, p_secuencias) {',
'	const actividad = $v("P182_ACTIVIDADES");',
'	if (!["002","003"].includes(actividad)) return p_jsonData;',
'',
'	let jsonData;',
'	try {',
'		const parsed = JSON.parse(p_jsonData);',
'		jsonData = Array.isArray(parsed) ? parsed : [];',
'	} catch (e) {',
'		jsonData = Array.isArray(p_jsonData) ? p_jsonData : [];',
'	}',
'',
'	const toInt = (v) => {',
'		if (v == null) return NaN;',
'		const s = String(v);',
'		const onlyDigits = s.replace(/\D+/g, "");',
'		return parseInt(onlyDigits, 10);',
'	};',
'	const getNumero = (r) => {',
'		let n = toInt(r.NUMERO_DOCUMETO);',
'		if (isNaN(n)) n = toInt(r.NUMERO_DOCUMENTO);',
'		if (isNaN(n)) n = toInt(r.N_DOC);',
'		return n;',
'	};',
'	const getTP = (r) => String(r.TPDOC || "").trim().toUpperCase();',
'',
'	const buildRow = (tpl, tipoDoc, numero, validacion, newId) => {',
'		const base = {};',
'		const keys = Object.keys(tpl || jsonData[0] || {});',
'		for (const k of keys) base[k] = "";',
'		base.TPDOC = tipoDoc;',
'		base.N_DOC = `${tipoDoc} ${numero}`;',
'		base.NUMERO_DOCUMETO = numero;',
'		if (keys.includes("NUMERO_DOCUMENTO")) base.NUMERO_DOCUMENTO = numero;',
'		base.ID = newId;',
'		base.IDPADRE = newId;',
'		base.VALIDACIONES = validacion;',
'		return base;',
'	};',
'',
'	const pad9 = (n) => String(n).replace(/\D+/g, "").padStart(9, "0");',
'',
'	const buildRow003 = (tpl, numero, validacion, newId) => {',
'		const base = {};',
'		const keys = Object.keys(tpl || jsonData[0] || {});',
'		for (const k of keys) base[k] = "";',
'		base.RANGO_NO_SIG_1 = numero;                ',
'		base.DESCRIPCION = `001-001-${pad9(numero)}`;       ',
'		base.ID = newId;',
'		base.IDPADRE = newId;',
'		base.VALIDACIONES = validacion;',
'		return base;',
'	};',
'',
'	const maxID  = Math.max(...jsonData.map(r => toInt(r.ID)).filter(n => !isNaN(n)), 0);',
'	const maxIDP = Math.max(...jsonData.map(r => toInt(r.IDPADRE)).filter(n => !isNaN(n)), 0);',
'	let nextID = Math.max(maxID, maxIDP) + 1000;',
'',
'	const secuencias = p_secuencias || {};',
'	const permitidos = actividad === "002" ? new Set(["FN","FE","FD","D1"])',
'						: new Set(["RT"]);',
'',
'	Object.entries(secuencias).forEach(([tipoDocRaw, secuenciaInicial]) => {',
'		const tipoDoc = String(tipoDocRaw || "").trim().toUpperCase();',
'		if (!permitidos.has(tipoDoc)) return;',
'		if (secuenciaInicial == null || String(secuenciaInicial).trim() === "") return;',
'',
'		const secuenciaNum = parseInt(String(secuenciaInicial).replace(/\D+/g, ""), 10);',
'		if (isNaN(secuenciaNum)) return;',
'',
'		if (actividad === "002") {',
'			const grupo = jsonData.filter((r) => getTP(r) === tipoDoc);',
'			const numerosExistentes = grupo.map(getNumero).filter((n) => !isNaN(n));',
'			const tpl = grupo[0] || jsonData[0] || {};',
'',
'			if (numerosExistentes.includes(secuenciaNum)) {',
'				for (const r of grupo) {',
'					const n = getNumero(r);',
'					if (n === secuenciaNum) {',
'						r.VALIDACIONES = "N Doc Anterior";',
'						if (!r.N_DOC) r.N_DOC = `${tipoDoc} ${secuenciaNum}`;',
'						if (isNaN(toInt(r.NUMERO_DOCUMETO))) r.NUMERO_DOCUMETO = secuenciaNum;',
'						if ("NUMERO_DOCUMENTO" in r && isNaN(toInt(r.NUMERO_DOCUMENTO))) r.NUMERO_DOCUMENTO = secuenciaNum;',
'					}',
'				}',
'			} else {',
'				jsonData.push(buildRow(tpl, tipoDoc, secuenciaNum, "N Doc Anterior", nextID));',
'				nextID += 1000;',
'				numerosExistentes.push(secuenciaNum);',
'			}',
'',
'			const maxSecuencia = Math.max(...numerosExistentes, secuenciaNum);',
'			for (let i = secuenciaNum + 1; i <= maxSecuencia; i++) {',
'				if (!numerosExistentes.includes(i)) {',
'					jsonData.push(buildRow(tpl, tipoDoc, i, "REVISION SECUENCIAL", nextID));',
'					nextID += 1000;',
'				}',
'			}',
'		} else { // actividad === "003"',
'		const grupo = jsonData; ',
'		const numerosExistentes003 = grupo',
'		.map(r => toInt(r.RANGO_NO_SIG_1))',
'		.filter(n => !isNaN(n));',
'',
'		const tpl = jsonData[0] || {};',
'',
'		if (numerosExistentes003.includes(secuenciaNum)) {',
'			for (const r of grupo) {',
'				const n = toInt(r.RANGO_NO_SIG_1);',
'				if (n === secuenciaNum) {',
'					r.VALIDACIONES = "N Doc Anterior";',
'					if (!r.DESCRIPCION) r.DESCRIPCION = `001-001-${pad9(secuenciaNum)}`;',
'					if (isNaN(toInt(r.RANGO_NO_SIG_1))) r.RANGO_NO_SIG_1 = secuenciaNum;',
'				}',
'			}',
'		} else {',
'			jsonData.push(buildRow003(tpl, secuenciaNum, "N Doc Anterior", nextID));',
'			nextID += 1000;',
'			numerosExistentes003.push(secuenciaNum);',
'		}',
'',
'		const maxSecuencia = Math.max(...numerosExistentes003, secuenciaNum);',
'			for (let i = secuenciaNum + 1; i <= maxSecuencia; i++) {',
'				if (!numerosExistentes003.includes(i)) {',
'					jsonData.push(buildRow003(tpl, i, "REVISION SECUENCIAL", nextID));',
'					nextID += 1000;',
'				}',
'			}',
'		}',
'	});',
'',
'	return JSON.stringify(jsonData);',
'}',
'',
'// ===== helpers de texto =====',
'function trim2(v){ return v==null ? "" : String(v).trim(); }',
'function isBlank(v){ return v==null || trim2(v)===""; }',
'',
'function f_aplicar_calculos_json(p_data, p_columnas) {',
'',
'	// ===== parseo seguro =====',
'	let datos, columnas;',
'	try { datos = JSON.parse(p_data || "[]"); } catch { datos = []; }',
'	try { columnas = JSON.parse(p_columnas || "[]"); } catch { columnas = []; }',
'	function toNumberGeneral(v) {',
'		if (v == null) return 0;',
'		if (typeof v === "number" && Number.isFinite(v)) return v;',
'		let s = String(v).trim();',
'		if (!s) return 0;',
'		s = s.replace(/^\((.*)\)$/, "-$1");',
'		const hasPct = /%/.test(s);',
'		s = s.replace(/[^0-9,.\005C-]/g, "");',
'		const lastDot = s.lastIndexOf(".");',
'		const lastCom = s.lastIndexOf(",");',
'		if (lastDot > lastCom) s = s.replace(/,/g, "");',
'		else if (lastCom > lastDot) { s = s.replace(/\./g, ""); s = s.replace(/,/g, "."); }',
'		else s = s.replace(/[.,]/g, "");',
'		let n = parseFloat(s);',
'		if (!Number.isFinite(n)) n = 0;',
'		return hasPct ? n / 100 : n;',
'	}',
'	const pow10 = n => Math.pow(10, n|0);',
'	function roundN(x, n) { const f = pow10(n|0); return Math.round((+x || 0) * f) / f; }',
'	function truncN(x, n) { const f = pow10(n|0), v = (+x || 0) * f; return (v < 0 ? Math.ceil(v) : Math.floor(v)) / f; }',
'	function nvl(a, b) { return (a === null || a === undefined || a === "") ? b : a; }',
'	function greatest() { return Array.from(arguments).reduce((m, v) => Math.max(m, +v || 0), -Infinity); }',
'	function least() { return Array.from(arguments).reduce((m, v) => Math.min(m, +v || 0), Infinity); }',
'',
'	function isBlank(x){ const s = x==null ? '''' : String(x); return s.trim()===''''; }',
'	function trim2(x){ return x==null ? '''' : String(x).trim(); }',
'',
'	function convertirPlsqlAJs(formulaPlsql) {',
'		let f = String(formulaPlsql || "");',
'',
'		f = f.replace(/TRIM\s*\(\s*([^)]+?)\s*\)\s+IS\s+NULL/gi, ''isBlank($1)'');',
'		f = f.replace(/TRIM\s*\(\s*([^)]+?)\s*\)\s+IS\s+NOT\s+NULL/gi, ''!isBlank($1)'');',
'		f = f.replace(/(\b[\w$]+\b)\s+IS\s+NULL/gi, ''isBlank($1)'');',
'		f = f.replace(/(\b[\w$]+\b)\s+IS\s+NOT\s+NULL/gi, ''!isBlank($1)'');',
'		f = f.replace(/\bTRIM\s*\(\s*([^)]+?)\s*\)/gi, ''trim2($1)'');',
'		f = f.replace(/CASE\s+WHEN\s+([^]*?)\s+THEN\s+([^]*?)\s+ELSE\s+([^]*?)\s+END/gi,''( ($1) ? ($2) : ($3) )'');',
'		f = f.replace(/CASE\s+WHEN\s+([^]*?)\s+THEN\s+([^]*?)\s+END/gi,''( ($1) ? ($2) : "" )'');',
'		f = f.replace(/\|\|/g, ''+'');',
'		f = f.replace(/:\s*\)/g, '':"")'');',
'		f = f.replace(/ROUND\s*\(\s*([^\s][^,]*?)\s*,\s*([0-9]+)\s*\)/gi, ''roundN(($1), $2)'');',
'		f = f.replace(/TRUNC\s*\(\s*([^\s][^,]*?)\s*,\s*([0-9]+)\s*\)/gi, ''truncN(($1), $2)'');',
'		f = f.replace(/MOD\s*\(\s*([^,]+?)\s*,\s*([^)]+?)\s*\)/gi, ''((($1)) % (($2)))'');',
'		f = f.replace(/POWER\s*\(\s*([^,]+?)\s*,\s*([^)]+?)\s*\)/gi, ''Math.pow(($1), ($2))'');',
'		f = f.replace(/NVL\s*\(\s*([^,]+?)\s*,\s*([^)]+?)\s*\)/gi, ''nvl(($1), ($2))'');',
'		f = f.replace(/ABS\s*\(\s*([^)]+?)\s*\)/gi, ''Math.abs(($1))'');',
'		f = f.replace(/CEIL\s*\(\s*([^)]+?)\s*\)/gi, ''Math.ceil(($1))'');',
'		f = f.replace(/FLOOR\s*\(\s*([^)]+?)\s*\)/gi, ''Math.floor(($1))'');',
'		f = f.replace(/SQRT\s*\(\s*([^)]+?)\s*\)/gi, ''Math.sqrt(($1))'');',
'		f = f.replace(/EXP\s*\(\s*([^)]+?)\s*\)/gi, ''Math.exp(($1))'');',
'		f = f.replace(/\bLN\s*\(\s*([^)]+?)\s*\)/gi, ''Math.log(($1))'');',
'		f = f.replace(/GREATEST\s*\(\s*([^)]+?)\s*\)/gi, (_, args)=> ''greatest('' + args + '')'');',
'		f = f.replace(/LEAST\s*\(\s*([^)]+?)\s*\)/gi, (_, args)=> ''least('' + args + '')'');',
'		// f = f.replace(/"/g, "");',
'		f = f.replace(/\bTRUE\b/gi, ''1'').replace(/\bFALSE\b/gi, ''0'').replace(/\bNULL\b/gi, ''0'');',
'		return f.trim();',
'	}',
'',
'	function mapIdentTexto(expr) {',
'		const KW = new Set(["ROUND","TRUNC","MOD","POWER","NVL","ABS","CEIL","FLOOR","SQRT","EXP","LN","GREATEST","LEAST","CASE","WHEN","THEN","ELSE","END","AND","OR","NOT","IS","NULL","MATH","SIGN","ISBLANK","TRIM2","N","S"]);',
'		return expr.replace(',
'			/''(?:[^''\\]|\\.)*''|"(?:[^"\\]|\\.)*"|\b([A-Za-z_][A-Za-z0-9_]*)\b/g,',
'			(m, id) => !id ? m : (KW.has(id.toUpperCase()) ? id : `N("${id}")`)',
'		);',
'	}',
'',
'	function inyectarValores(formulaJs, row, alias) {',
'		const RESERVED = new Set(["roundN","truncN","nvl","greatest","least","Math","NaN","Infinity","isNaN","Number","abs"]);',
'		let f = String(formulaJs || "");',
'		f = f.replace(/"([^"\\]+)"/g, (_, name) => {',
'			const v = Object.prototype.hasOwnProperty.call(row, name) ? row[name] : 0;',
'			const n = (typeof v === "number") ? v : toNumberGeneral(v);',
'			return String(Number.isFinite(n) ? n : 0);',
'		});',
'',
'		f = f.replace(/\b[A-Za-z_$][A-Za-z0-9_$]*\b/g, (id) => {',
'			if (RESERVED.has(id)) return id;',
'			if (!Object.prototype.hasOwnProperty.call(row, id)) return "0";',
'			const v = row[id];',
'			if (typeof v === "number") return String(v);',
'			if (v == null || v === "") return "0";',
'			return String(toNumberGeneral(v));',
'		});',
'		return f;',
'	}',
'',
'  function evaluar(expr) {',
'		try {',
'			expr = expr.replace(/"/g, '''');',
'			const body = ''return ('' + expr + '');'';',
'			const fn = new Function("roundN","truncN","nvl","greatest","least","Math", body);',
'			const r = fn(roundN, truncN, nvl, greatest, least, Math);',
'			return Number.isFinite(r) ? r : 0;',
'		} catch { return 0; }',
'	}',
'	function evaluarTexto(expr, row,alias) {',
'		const N = (k) => toNumberGeneral(row?.[k]);',
'		const S = (k) => { const v = row?.[k]; return v==null ? "" : String(v); };',
'		const body = ''return ('' + expr + '');'';',
'		const fn = new Function("roundN","truncN","nvl","greatest","least","Math","N","S", body);',
'		return fn(roundN, truncN, nvl, greatest, least, Math, N, S);',
'	}',
'',
'	columnas.forEach(col => {',
'		if (col && col.CALCULO === "Y" && typeof col.COLUMNA === "string") {',
'			const alias = String(col.ALIAS || "").replace(/"/g, "");',
'			const formulaPL = col.COLUMNA;',
'			if(alias!=="VALIDACIONES"){',
'				const esTexto = /''(?:[^'']*)''|\|\||\bCASE\b/i.test(formulaPL);',
'				datos.forEach(row => {',
'					',
'					let fjs = convertirPlsqlAJs(formulaPL);',
'					fjs = fjs',
'					.replace(/\bisBlank\s*\(\s*([A-Za-z_][A-Za-z0-9_]*)\s*\)/g, ''isBlank(S("$1"))'')',
'					.replace(/\btrim2\s*\(\s*([A-Za-z_][A-Za-z0-9_]*)\s*\)/g, ''trim2(S("$1"))'');',
'',
'',
'					let result;',
'					if (esTexto) {',
'						let exprTexto = mapIdentTexto(fjs);',
'						const orn= String(row["NUMEROORDEN"]|| "");',
'					',
'						exprTexto = exprTexto',
'						.replace(/S\("([^"]+)"\)/g, (_, k) =>{JSON.stringify(String(row?.[k] ?? ""));} )',
'						.replace(/N\("([^"]+)"\)/g, (_, k) =>{String(toNumberGeneral(row?.[k]));	   } );',
'						 ',
'						result = evaluarTexto(exprTexto, row, alias);',
'					} else {',
'						const exprNum = inyectarValores(fjs, row, alias);',
'						result = evaluar(exprNum);',
'						result = roundN(result, 2);',
'						if (Object.is(result, -0)) result = 0;',
'					}',
'					row[alias] = result;',
'					try { if (typeof v_tiene_cambios !== "undefined") v_tiene_cambios = 1; } catch (_) {}',
'				});',
'			}',
'		}//ejmc',
'	});',
'	columnas.forEach(col => {',
'		//console.log("id:"+col.ID+",ALIAS:"+col.ALIAS);',
'		if (col && col.CALCULO === "Y" && typeof col.COLUMNA === "string") {',
'			const alias = String(col.ALIAS || "").replace(/"/g, "");',
'			const formulaPL = col.COLUMNA;',
'			if(alias==="VALIDACIONES"){',
'				// console.log("formulaPL:"+formulaPL);',
'				const esTexto = /''(?:[^'']*)''|\|\||\bCASE\b/i.test(formulaPL);',
'				datos.forEach(row => {',
'					',
'					let fjs = convertirPlsqlAJs(formulaPL);',
'					fjs = fjs',
'					.replace(/\bisBlank\s*\(\s*([A-Za-z_][A-Za-z0-9_]*)\s*\)/g, ''isBlank(S("$1"))'')',
'					.replace(/\btrim2\s*\(\s*([A-Za-z_][A-Za-z0-9_]*)\s*\)/g, ''trim2(S("$1"))'');',
'',
'',
'					let result;',
'					if (esTexto) {',
'						let exprTexto = mapIdentTexto(fjs);',
'						const orn= String(row["NUMEROORDEN"]|| "");',
'						exprTexto = exprTexto	',
'							.replace(/S\("([^"]+)"\)/g, (_, k) => JSON.stringify(String(row?.[k] ?? "" ) ) )',
'							.replace(/N\("([^"]+)"\)/g, (_, k) => String(toNumberGeneral(row?.[k] ) ) );',
'						if(alias==="VALIDACIONES" && orn===''25700335'') {console.log("4.exprTexto:"+exprTexto);}//ejmc',
'						result = evaluarTexto(exprTexto, row, alias);',
'					} else {',
'						const exprNum = inyectarValores(fjs, row, alias);',
'						result = evaluar(exprNum);',
'						result = roundN(result, 2);',
'						if (Object.is(result, -0)) result = 0;',
'					}',
'					row[alias] = result;',
'					try { if (typeof v_tiene_cambios !== "undefined") v_tiene_cambios = 1; } catch (_) {}',
'				});',
'			}',
'		}//ejmc',
'	});',
'',
'  ',
'',
'  return JSON.stringify(datos);',
'}',
'document.addEventListener("DOMContentLoaded", function () {',
'    const radios = document.querySelectorAll("input[name=''P182_IDDATO'']");',
'    radios.forEach(radio => {',
'        radio.addEventListener("onchange", () => {',
'            // Primero, quitar la clase a todos',
'            radios.forEach(r => {',
'                const label = document.querySelector(`label[for="${r.id}"]`);',
'                if (label) label.style.backgroundColor = ""; // Quitar color anterior',
'            });',
'',
'            // Ahora, aplicar estilo al seleccionado',
'            const selectedLabel = document.querySelector(`label[for="${radio.id}"]`);',
'            if (selectedLabel) selectedLabel.style.backgroundColor = "red";',
'        });',
'    });',
'});',
'',
'function f_asegura_columna_estado(p_json, p_columnas){',
'  let columnas = [];',
'  try { columnas = JSON.parse(p_columnas || "[]"); } catch (_) { columnas = []; }',
'  if (!Array.isArray(columnas)) return p_columnas;',
'  columnas.forEach(col => {',
'    if (col && String(col.ALIAS || col.COLUMNA || "").toUpperCase() === "ESTADO") {',
'      col.VISIBLE = "N";',
'    }',
'  });',
'  return JSON.stringify(columnas);',
'}',
'function P182_preserva_validaciones_html(p_json_editado, p_json_base){',
'  let editados = [];',
'  let base = [];',
'  try { editados = JSON.parse(p_json_editado || "[]"); } catch (_) { editados = []; }',
'  try { base = JSON.parse(p_json_base || "[]"); } catch (_) { base = []; }',
'  if (!Array.isArray(editados) || !Array.isArray(base) || base.length === 0) return p_json_editado;',
'  const basePorId = new Map();',
'  base.forEach(r => { if (r && r.ID != null) basePorId.set(String(r.ID), r); });',
'  editados.forEach(r => {',
'    if (!r || r.ID == null) return;',
'    const b = basePorId.get(String(r.ID));',
'    if (!b) return;',
'    const valNueva = String(r.VALIDACIONES || "");',
'    const valBase = String(b.VALIDACIONES || "");',
'    if (valBase.indexOf("<li") >= 0 || valBase.indexOf("<LI") >= 0) {',
'      if (valNueva.indexOf("<li") < 0 && valNueva.indexOf("<LI") < 0) {',
'        r.VALIDACIONES = valBase;',
'      }',
'    }',
'  });',
'  return JSON.stringify(editados);',
'}',
'',
'function f_generatabla(p_json,p_columnas,p_filtro){',
'  let v_json = p_json || "";',
'  let v_columnas = p_columnas || "";',
'	let v_filtro=p_filtro;',
'',
'     const secuencias = f_getsecuencias();',
'     if (v_json){',
'         v_json=f_preprocesar_json_segun_secuencias(v_json,secuencias);',
'     }',
'',
'    if (v_json){',
'         v_json=f_aplicar_calculos_json(v_json,v_columnas);',
'    }',
'         v_columnas=f_asegura_columna_estado(v_json,v_columnas);',
'         v_JSONGESTION=v_json;',
'         v_JSONCOLUMNAS=v_columnas;',
'',
'    const p_visibles=1;',
'	const p_acc_edita=($v("P182_ESTADO_DATO")==="3")? 0 : 1;',
'    const p_acc_borra=getBorra();',
'    const p_acc_copia= getCopia();',
'    const p_columnas_orden=getSort();',
'    const p_proceso=$v("P182_ACTIVIDADES");',
'    f_genera_tablahtml_json(v_json,v_columnas,p_visibles,p_acc_edita,p_acc_borra,p_acc_copia,p_columnas_orden,p_proceso,v_filtro);',
'}',
unistr('// Uso: despu\00E9s de renderizar la tabla'),
'',
'',
'',
'function getSort(){',
'    if ($v("P182_ACTIVIDADES")==="001"){//DOCUMENTO ELECTRONICO',
'        return "COMPROBANTE,RUC_EMISOR,DOCUMENTO";',
'    }',
'    if ($v("P182_ACTIVIDADES")==="002"){//VENTAS',
'        return "NDOC,N_DOC";',
'    }',
'    if ($v("P182_ACTIVIDADES")==="003"){//RETENCIONES',
'        return "RANGO_NO_SIG_1,NUM_DOCUMENTO";',
'    }',
'    if ($v("P182_ACTIVIDADES")==="004"){//COMPRAS',
'        return "N_DOC,COD_SRI_DECLARACIONES,COD_SRI_ANEXO";',
'    }',
'    if ($v("P182_ACTIVIDADES")==="006"){//ICE',
'        return "N_DOC";',
'    }',
'    if ($v("P182_ACTIVIDADES")==="005"){//SENAE',
'        return "N_DOC";',
'    }',
'    if ($v("P182_ACTIVIDADES")==="007"){//RETENCIONES CLIENTES',
'        return "CLAVE_ACCESO,NO_DOCUMENTO,SERIE_COMPROBANTE";',
'    }',
'    return " ";',
'}',
'',
'function getBorra(){',
'     if ($v("P182_ACTIVIDADES")==="001"){//DOCUMENTOS RECIBIDOS',
'         return 0;',
'     }',
'    return ($v("P182_ESTADO_DATO")==="3")? 0 : 1;',
'}',
'',
'function getCopia(){',
'     if ($v("P182_ACTIVIDADES")==="001"){//DOCUMENTOS RECIBIDOS',
'         return 0;',
'     }',
'    return ($v("P182_ESTADO_DATO")==="3")? 0 : 1;',
'}',
'function f_llamarProcesoByID (v_parametro1){',
'    var result = null;',
'    return new Promise((resolve, reject) => {',
'    apex.server.process(',
'        ''LLAMAR_PROCESO_BYID'', // Nombre del proceso',
'        {',
'            x01:v_parametro1,',
'        }, // variables del proceso',
'        {',
'            dataType: "json",',
'            success: function(pData)',
'            {',
'                //result = pData.result;',
'                resolve(pData);  // Resuelve la promesa con los datos del servidor',
'',
'            }',
'            ,error: function(err) {',
'                console.error("Error LLAMAR_PROCESO_BYID:", err);',
'                 reject(err);  // Rechaza la promesa en caso de error',
'            }',
'        }',
'    );',
'    });',
'}',
'',
'function f_llamarProcesoGrabar(v_parametro1,v_parametro2,v_parametro3,v_parametro4,v_parametro5,v_parametro6){',
'    var result = null;',
'    return new Promise((resolve, reject) => {',
'		apex.server.process(',
'			''LLAMAR_GRABAR_PROCESO'', // Nombre del proceso',
'			{',
'				x01:v_parametro1,',
'				x02:v_parametro2,',
'				x03:v_parametro3,',
'				x04:v_parametro4,',
'				p_clob_01:v_parametro5,',
'				x05:v_parametro6,',
'			}, // variables del proceso',
'			{',
'				dataType: "json",',
'				success: function(pData)',
'				{',
'					//result = pData.result;',
'					resolve(pData);  // Resuelve la promesa con los datos del servidor',
'',
'				}',
'				,error: function(err) {',
'					console.error("Error LLAMAR_GRABAR_PROCESO:", err);',
'					reject(err);  // Rechaza la promesa en caso de error',
'				}',
'			}',
'		);',
'    });',
'}',
'',
'function f_llamarProcesoCerrar(v_parametro1,v_parametro2,v_parametro3,v_parametro4,v_parametro5,v_parametro6,v_parametro7){',
'    var result = null;',
'    return new Promise((resolve, reject) => {',
'		apex.server.process(',
'			''LLAMAR_CERRAR_PROCESO'',',
'			{',
'				x01:v_parametro1,',
'				x02:v_parametro2,',
'				x03:v_parametro3,',
'				x04:v_parametro4,',
'				p_clob_01:v_parametro5,',
'				x05:v_parametro6,',
'				x06:v_parametro7',
'			},',
'			{',
'				dataType: "json",',
'				success: function(pData)',
'				{',
'					resolve(pData);',
'				}',
'				,error: function(err) {',
'					console.error("Error LLAMAR_CERRAR_PROCESO:", err);',
'					reject(err);',
'				}',
'			}',
'		);',
'    });',
'}',
'',
'',
'function _getFiltrosActivos() {',
'  const filtros = {};',
'  document.querySelectorAll("#report_detail .filtro-input").forEach(inp => {',
'    const col = inp.getAttribute("data-col") || "";',
'    filtros[col] = inp.value;',
'  });',
unistr('  // si usas checks/rangos agrega aqu\00ED lecturas similares'),
'  return filtros;',
'}',
'function _setFiltrosActivos(filtros) {',
'  if (!filtros) return;',
'  document.querySelectorAll("#report_detail .filtro-input").forEach(inp => {',
'    const col = inp.getAttribute("data-col") || "";',
'    if (col in filtros) {',
'      inp.value = filtros[col] ?? "";',
'      inp.dispatchEvent(new Event("input", { bubbles: true }));',
'      inp.dispatchEvent(new Event("change", { bubbles: true }));',
'    }',
'  });',
'}',
'function mostrarBarraSegura(){',
'  try {',
'    mostrarBarra();',
'  } catch (error) {',
'    console.warn("mostrarBarraSegura", error);',
'  }',
'}',
'function ocultarBarraSegura(){',
'  try {',
'    if (typeof spinner !== "undefined" && spinner && typeof spinner.remove === "function") {',
'      spinner.remove();',
'    }',
'  } catch (error) {',
'    console.warn("ocultarBarraSegura", error);',
'  } finally {',
'    try { spinner = null; } catch (_) {}',
'  }',
'}',
'async function ejecutarConBarraCarga(p_filtro, p_barra_activa) {',
'  try {',
'    const filtros = _getFiltrosActivos();       ',
'    // if (!p_barra_activa) {',
'    //   mostrarBarra();',
'    // }',
'    await new Promise((resolve, reject) => {',
'      setTimeout(() => {',
'        try {',
'          f_generatabla(v_JSONGESTION, v_JSONCOLUMNAS, p_filtro);',
'          resolve();',
'        } catch (error) {',
'          reject(error);',
'        }',
'      }, 0);',
'    });',
'    _setFiltrosActivos(filtros);                 ',
'  } catch (error) {',
'    console.error("Error al ejecutar f_generatabla:", error);',
'  } finally {',
'    null;',
'    //try{ocultarBarra();}catch(_){}',
'  }',
'}',
'',
'function f_cargaOpciones (p_item){',
'	(function () {',
'		function setCol($els, n){',
'			$els.each(function(){',
'				const el = this;',
'				const toRemove = [];',
'				el.classList.forEach(cls => {',
'					if (cls === "col" || cls.indexOf("col-") === 0) toRemove.push(cls);',
'				});',
'				toRemove.forEach(c => el.classList.remove(c));',
'				el.classList.add("col-" + n);',
'			});',
'		}',
'',
'		function apply(){',
'			const $c = $("#"+p_item);',
'			if (!$c.length) return;',
'			setCol($c.find(".t-Form-labelContainer"), 0);',
'			setCol($c.find(".t-Form-inputContainer"), 12);',
'		}',
'',
'		// inicial y tras eventos APEX comunes',
'			$(apply);',
'		$(document).on("apexafterrefresh apexafterclosedialog apexafterpagesubmit", apply);',
'	})();',
'',
'}'))
,p_javascript_code_onload=>wwv_flow_string.join(wwv_flow_t_varchar2(
'$(".t-Button.t-Button--icon.t-Button--header.t-Button--headerTree.is-active").click();',
'f_habilita_recarga_click_actividades();',
'f_cargaOpciones("P182_ACTIVIDADES_CONTAINER");',
'f_cargaOpciones("P182_IDDATO_CONTAINER");',
'f_cargaOpciones("P182_ALERTAERROR_CONTAINER");',
'$(v_regBarraAccion2).hide(); ',
'$(v_secAlerta).hide();',
'$(v_secItems).hide();',
'console.log("P192_TIENE_AF:"+$v("P192_TIENE_AF"));',
' if($v("P192_TIENE_AF")==="0" ){',
'    $(v_secAlerta).show();//apex.message.alert($v("P182_ALERTAERROR"));',
'}',
'$("#P182_ALERTAERROR_DISPLAY").removeClass("display_only apex-item-display-only");',
''))
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.tr-total{    color: white;    background-color: #689599;}',
'.tr-total-general{    color: white;        background-color: #04891699;',
'    border-bottom: 0.5px solid #04891699;}',
'.nth_child_odd {background-color: #e5e5e5}',
'.nth_child_even {background-color: #ffffff;}',
'.tr-hover:hover {',
'    background-color: #0572ce3b !important;',
'    color: rgba(55, 55, 55, 0.537) !important;',
'    cursor: default;',
'}',
'.color-light-title{color: #000 !important;background-color: #8bc34a !important;}',
'.HAlignRight{text-align: right !important;padding-right: 6px;font-size: 1em;line-height: 0.5em;}',
'.HAlignCenter{text-align: center !important;font-size: 1em;line-height: 0.5em;}',
'td{padding-right:5px;padding-left: 5px;}',
'.t-Report-colHead {',
'    background-color: #e9edee !important;',
'    border: 1px solid black !important; ',
'    ',
'    text-align: center;',
'    color: #0572ce;',
'}',
'#scroll-bottom-inner thead th {',
'    position: sticky;',
'    top: 0;',
'    background-color: #f8f8f8;',
'    z-index: 3;',
'}',
'.tr_secini {',
'   background-color: #0046ff2e;color:red;',
'}',
'.tr_secper {',
'   background-color: #0046ff2e;',
'    color: #9b9b9b;',
'    text-decoration: line-through;',
'}',
'.scroll-container { position: relative; width: 100%; }',
'.scroll-top, .scroll-bottom { overflow-x: auto; overflow-y: hidden; width: 100%; }',
'.scroll-top { height: 20px; /* altura solo para mostrar barra arriba */ }',
'.scroll-bottom { overflow: auto; max-height: 200px; } ',
'.scroll-inner { width: max-content; }',
'/* Solo aplica al item P182_IDDATO con estilo "pill button" */',
unistr('/* Estilo para el radio group P182_IDDATO cuando est\00E1 seleccionado */'),
'input[name="P182_IDDATO"]:checked + label.t-Button {',
'    background-color: #4CAF50;',
'    color: white;',
'    border-color: #4CAF50;',
'}',
'',
'/* Suaviza transiciones */',
'label.t-Button {',
'    transition: background-color 0.3s ease;',
'}',
'',
'.t-Form-labelContainer col col-2{',
'	display:none;',
'}',
'',
'',
'#P182_IDDATO .apex-item-option label {',
'    background-color: purple !important;',
'    color: #04891699 !important;',
'}',
'',
'',
unistr(' /* Cambiar el fondo del bot\00F3n seleccionado SOLO para P182_IDDATO */'),
'#P182_IDDATO .apex-item-option input[type="radio"]:checked + label {',
'    background-color: #04891699 !important;',
'    color: #e6eaec !important;',
'}',
'',
'/* (Opcional) Estilo hover */',
'#P182_IDDATO .apex-item-option label:hover {',
'    background-color: #04891699;',
'    color: #04891699;',
'}',
'',
'.filtro-multiple {',
'    position: relative;',
'    display: inline-block;',
'    width: 100%;',
'}',
'.dropdown-checkboxes {',
'    display: none;',
'    padding: 5px;',
'}',
'.dropdown-checkboxes label {',
'    display: block;',
'    white-space: nowrap;',
'}',
'',
'div.formulario {',
'    border-radius: 3px;',
'    box-shadow: 0 1px 3px 0 rgba(0, 0, 0, 0.2), 0 1px 1px 0 rgba(0, 0, 0, 0.14), 0 2px 1px -1px rgba(0, 0, 0, 0.12);',
'    background: #FFF;',
'    padding: 0px;',
'}'))
,p_page_template_options=>'#DEFAULT#'
,p_page_component_map=>'03'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(45213862780289112)
,p_plug_name=>'Secuenciales'
,p_region_name=>'dlgSecuencias'
,p_region_template_options=>'#DEFAULT#:js-dialog-autoheight:js-dialog-size720x480'
,p_plug_template=>wwv_flow_imp.id(37804699672106518)
,p_plug_display_sequence=>30
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(45215049974289124)
,p_plug_name=>'Formulario Venta'
,p_region_name=>'regSecVenta'
,p_parent_plug_id=>wwv_flow_imp.id(45213862780289112)
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(38289867500120143)
,p_plug_display_sequence=>50
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(45215116090289125)
,p_plug_name=>'Botones'
,p_parent_plug_id=>wwv_flow_imp.id(45213862780289112)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(38290276266120143)
,p_plug_display_sequence=>80
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(180871558737614224)
,p_plug_name=>'Formulario Retenciones'
,p_region_name=>'regSecRetencion'
,p_parent_plug_id=>wwv_flow_imp.id(45213862780289112)
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(38289867500120143)
,p_plug_display_sequence=>60
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(172202351722168434)
,p_plug_name=>'Titulo'
,p_title=>'PERIODO: &P182_PERIODO_NOMBRE.'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(95503811913299190)
,p_plug_display_sequence=>20
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_item_display_point=>'BELOW'
,p_location=>null
,p_menu_id=>wwv_flow_imp.id(37761271469106475)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(37860983999106559)
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(172202649544168437)
,p_plug_name=>'REGION 3'
,p_region_template_options=>'#DEFAULT#:t-Form--noPadding:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels:t-Form--labelsAbove:margin-top-none:margin-bottom-none:margin-left-none:margin-right-none'
,p_plug_template=>wwv_flow_imp.id(38289867500120143)
,p_plug_display_sequence=>40
,p_plug_display_point=>'REGION_POSITION_01'
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(540148598405116702)
,p_plug_name=>'REGION 1'
,p_title=>'&P182_PERIODO_NOMBRE.'
,p_region_name=>'secRegion1'
,p_region_template_options=>'#DEFAULT#:t-Form--noPadding:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels:t-Form--labelsAbove:margin-top-none:margin-bottom-none:margin-left-none:margin-right-none'
,p_region_attributes=>'style="display: flex;justify-content: center;align-items: center;text-align: center;"'
,p_plug_template=>wwv_flow_imp.id(38289867500120143)
,p_plug_display_sequence=>30
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'REGION_POSITION_01'
,p_location=>null
,p_plug_display_condition_type=>'EXISTS'
,p_plug_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT DESCRIPCION,ID_TABLA FROM "DATA"."T_CORP_UDC" ',
'WHERE ID_CABECERA=''FINZ_GT01'' AND ID_TABLA not in ( ''000'' ,''999'')',
'and ID_TABLA in (SELECT ITEM FROM TABLE(PK_COMMONS.F_DIVIDIRTEXTO(:P182_ACTIVIDADESPERIODO,'':'') ) )',
'and id_tabla in (select idproceso from t_finz_gestiontributariadet det inner join DATA.t_finz_gestiontributariadatos dat on det.id=dat.iddet where det.IDGTB= :P182_IDPERIODO)'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(540149575263116712)
,p_plug_name=>'Items'
,p_region_name=>'secItems'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(95503811913299190)
,p_plug_display_sequence=>50
,p_include_in_reg_disp_sel_yn=>'Y'
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(581863514509074749)
,p_plug_name=>'Campos json'
,p_parent_plug_id=>wwv_flow_imp.id(540149575263116712)
,p_region_template_options=>'#DEFAULT#:js-useLocalStorage:is-collapsed:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(37796755046106514)
,p_plug_display_sequence=>270
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(550356270682460428)
,p_plug_name=>'REGION 2'
,p_region_name=>'secDetalle'
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:t-Region--removeHeader:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(37807886111106520)
,p_plug_display_sequence=>40
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(550355323378460419)
,p_name=>'DETALLE'
,p_region_name=>'report_detail'
,p_parent_plug_id=>wwv_flow_imp.id(550356270682460428)
,p_template=>wwv_flow_imp.id(37806762584106520)
,p_display_sequence=>20
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_display_point=>'SUB_REGIONS'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>'SELECT rownum id, D.* FROM DUAL D'
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(37830327650106535)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(550355773314460423)
,p_query_column_id=>1
,p_column_alias=>'ID'
,p_column_display_sequence=>10
,p_column_heading=>'Id'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(550355839410460424)
,p_query_column_id=>2
,p_column_alias=>'DUMMY'
,p_column_display_sequence=>20
,p_column_heading=>'Dummy'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(550356363927460429)
,p_plug_name=>'Barra de Acciones'
,p_region_template_options=>'#DEFAULT#:t-Form--stretchInputs'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(38289497777120142)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_location=>null
,p_menu_id=>wwv_flow_imp.id(37761271469106475)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(37860983999106559)
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(550356853585460434)
,p_plug_name=>'Barra de Acciones Actividad'
,p_region_name=>'regBarraAccion2'
,p_region_template_options=>'#DEFAULT#:t-Form--stretchInputs'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(38289497777120142)
,p_plug_display_sequence=>50
,p_plug_display_point=>'REGION_POSITION_01'
,p_location=>null
,p_menu_id=>wwv_flow_imp.id(37761271469106475)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(37860983999106559)
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(550996438458588436)
,p_plug_name=>'Alerta'
,p_region_name=>'secAlerta'
,p_region_template_options=>'#DEFAULT#:t-Alert--colorBG:t-Alert--horizontal:t-Alert--defaultIcons:t-Alert--warning:t-Alert--removeHeading:t-Form--noPadding:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels:t-Form--labelsAbove:margin-top-none:margin-bottom-none:margin-left-n'
||'one:margin-right-none'
,p_plug_template=>wwv_flow_imp.id(37782629797106503)
,p_plug_display_sequence=>20
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(550994637214588418)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(550356853585460434)
,p_button_name=>'Insertar_Registro_json'
,p_button_static_id=>'btnInsertaRegistroJson'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860056812106557)
,p_button_image_alt=>'Insertar Registro'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'LEFT'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-plus'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(42164160448330502)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(550356853585460434)
,p_button_name=>'Guardar_CAMBIOS'
,p_button_static_id=>'btnGrabarCambios'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860056812106557)
,p_button_image_alt=>'Guardar'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'LEFT'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-save-as'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(125466778677948902)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(550356853585460434)
,p_button_name=>'Filtros'
,p_button_static_id=>'btnLimpiarFiltros'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860056812106557)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Borar Filtros'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'LEFT'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-filter'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(13870558570746214)
,p_button_sequence=>50
,p_button_plug_id=>wwv_flow_imp.id(550356853585460434)
,p_button_name=>'RECARGAR'
,p_button_static_id=>'btnRecargar'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860056812106557)
,p_button_image_alt=>'Recargar'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'LEFT'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-undo-alt'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(44521738031941341)
,p_button_sequence=>60
,p_button_plug_id=>wwv_flow_imp.id(550356853585460434)
,p_button_name=>'Resumen'
,p_button_static_id=>'btnResumen'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860056812106557)
,p_button_image_alt=>'Resumen'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:194:&SESSION.::&DEBUG.:RR,194:P194_IDDATO,P194_IDPROCESO:&P182_IDDATO.,&P182_ACTIVIDADES.'
,p_icon_css_classes=>'fa-window-restore'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(45215383762289127)
,p_button_sequence=>70
,p_button_plug_id=>wwv_flow_imp.id(550356853585460434)
,p_button_name=>'btnIngresarSecuencias'
,p_button_static_id=>'btnIngresarSecuencias'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860056812106557)
,p_button_image_alt=>'Secuenciales'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-database-plus'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(125470578067948940)
,p_button_sequence=>80
,p_button_plug_id=>wwv_flow_imp.id(550356853585460434)
,p_button_name=>'ATS'
,p_button_static_id=>'btnAts'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860056812106557)
,p_button_image_alt=>'XML'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-file-code-o'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(8909048448245731)
,p_button_sequence=>90
,p_button_plug_id=>wwv_flow_imp.id(550356853585460434)
,p_button_name=>'Exportar'
,p_button_static_id=>'btnExportar'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860056812106557)
,p_button_image_alt=>'Excel'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-file-excel-o'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(550356553497460431)
,p_button_sequence=>100
,p_button_plug_id=>wwv_flow_imp.id(550356853585460434)
,p_button_name=>'Cerrar_Actividad'
,p_button_static_id=>'btnCerrarActividad'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860056812106557)
,p_button_image_alt=>'Cerrar Actividad'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
,p_confirm_message=>unistr('Est\00E1 seguro de realizar la accion de cerrar la actividad.')
,p_icon_css_classes=>'fa-times-square-o'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(215621309897421304)
,p_button_sequence=>110
,p_button_plug_id=>wwv_flow_imp.id(550356853585460434)
,p_button_name=>'Abrir_Actividad'
,p_button_static_id=>'btnAbrirActividad'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860056812106557)
,p_button_image_alt=>'Abrir Actividad'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
,p_confirm_message=>unistr('Est\00E1 seguro de realizar la accion de re-abrir la actividad.')
,p_icon_css_classes=>'fa-book fam-star fam-is-success'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(45214842710289122)
,p_button_sequence=>50
,p_button_plug_id=>wwv_flow_imp.id(45215116090289125)
,p_button_name=>'Aceptar'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--small:t-Button--primary:t-Button--simple:t-Button--pillStart'
,p_button_template_id=>wwv_flow_imp.id(37860181880106559)
,p_button_image_alt=>'Aceptar'
,p_button_position=>'BOTTOM'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(45215877634289132)
,p_button_sequence=>60
,p_button_plug_id=>wwv_flow_imp.id(45215116090289125)
,p_button_name=>'Cancelar'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--small:t-Button--primary:t-Button--simple:t-Button--pillStart'
,p_button_template_id=>wwv_flow_imp.id(37860181880106559)
,p_button_image_alt=>'Cancelar'
,p_button_position=>'BOTTOM'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(550996041354588432)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(540149575263116712)
,p_button_name=>'Enviar_Pagina'
,p_button_static_id=>'btnenviarPagina'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860056812106557)
,p_button_image_alt=>'Enviar Pagina'
,p_button_position=>'RIGHT_OF_TITLE'
,p_icon_css_classes=>'fa-repeat'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(125470225251948937)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(540149575263116712)
,p_button_name=>'Abrir198'
,p_button_static_id=>'btnPage198'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860181880106559)
,p_button_image_alt=>'Abrir198'
,p_button_position=>'RIGHT_OF_TITLE'
,p_button_redirect_url=>'f?p=&APP_ID.:198:&SESSION.::&DEBUG.:RR,198:P198_CODDCT,P198_CODDOC,P198_TIPO:&P182_CODDCT_REEMB.,&P182_CODDOC_REEMB.,&P182_TIPO_REEMB.'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(540149343214116710)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(550356363927460429)
,p_button_name=>'Atras'
,p_button_static_id=>'btnAtras'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860056812106557)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Atras'
,p_button_position=>'TOP'
,p_button_alignment=>'LEFT'
,p_button_redirect_url=>'f?p=&APP_ID.:180:&SESSION.::&DEBUG.:RR,180::'
,p_icon_css_classes=>'fa-arrow-left'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(252567712051886012)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(550356363927460429)
,p_button_name=>'Areas_Fiscales'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860056812106557)
,p_button_image_alt=>'Areas Fiscales'
,p_button_position=>'TOP'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:199:&SESSION.::&DEBUG.:RR,199:P199_PERIODO:&P182_PERIODO.'
,p_icon_css_classes=>'&P182_ICONAF.'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(60505674719174928)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(550356363927460429)
,p_button_name=>'Formularios_SRI'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860056812106557)
,p_button_image_alt=>'Formularios SRI'
,p_button_position=>'TOP'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:195:&SESSION.::&DEBUG.:RR,195:P195_IDPERIODO:&P182_IDPERIODO.'
,p_button_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT distinct 1',
'FROM t_finz_gestiontributariacfg cfg ',
'INNER JOIN data.t_finz_gestiontributariadatos dat ON cfg.id = dat.idcfg',
'INNER JOIN data.t_finz_gestiontributariadet   det ON dat.iddet = det.id',
'WHERE cfg.compania = :g_compania',
'AND det.idgtb = :P182_IDPERIODO',
'AND cfg.estado = 1'))
,p_button_condition_type=>'EXISTS'
,p_icon_css_classes=>'fa fa-file-signature'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(9725547981582219)
,p_button_sequence=>50
,p_button_plug_id=>wwv_flow_imp.id(550356363927460429)
,p_button_name=>'Check_list_procesos'
,p_button_static_id=>'btnCargarArchivos'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860056812106557)
,p_button_image_alt=>'Procesos'
,p_button_position=>'TOP'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:190:&SESSION.::&DEBUG.:190:P190_IDPERIODO:&P182_IDPERIODO.'
,p_button_condition=>'P182_FAICON_PROCESOS'
,p_button_condition2=>'0'
,p_button_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_icon_css_classes=>'fa-badge-check'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(180869910009614208)
,p_button_sequence=>60
,p_button_plug_id=>wwv_flow_imp.id(550356363927460429)
,p_button_name=>'Check_list_procesos_1'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860056812106557)
,p_button_image_alt=>'Procesos'
,p_button_position=>'TOP'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:190:&SESSION.::&DEBUG.:190:P190_IDPERIODO:&P182_IDPERIODO.'
,p_button_condition=>'P182_FAICON_PROCESOS'
,p_button_condition2=>'1'
,p_button_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_icon_css_classes=>'fa-badge-check fam-x fam-is-danger'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(540055834851066049)
,p_button_sequence=>70
,p_button_plug_id=>wwv_flow_imp.id(550356363927460429)
,p_button_name=>'Procesar_Datos'
,p_button_static_id=>'btnCargarDatos'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860056812106557)
,p_button_image_alt=>'Cargar Datos'
,p_button_position=>'TOP'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
,p_button_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE ',
'V_CONTADOR NUMBER;',
'BEGIN',
'	select COUNT(distinct 1) CERRAR INTO V_CONTADOR from t_finz_gestiontributaria where estado!=3 and id =:P182_IDPERIODO AND :P182_ACTIVIDADESROL=''ADMINISTRADOR'';',
'	IF (V_CONTADOR=1) THEN ',
'		RETURN TRUE;',
'	ELSE',
'		RETURN FALSE;',
'	END IF;',
'END;',
'	'))
,p_button_condition2=>'PLSQL'
,p_button_condition_type=>'FUNCTION_BODY'
,p_icon_css_classes=>'fa-recycle'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(540055934666066050)
,p_button_sequence=>80
,p_button_plug_id=>wwv_flow_imp.id(550356363927460429)
,p_button_name=>'Cerrar_Periodo'
,p_button_static_id=>'btnCerrarPeriodo'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860056812106557)
,p_button_image_alt=>'Cerrar Periodo'
,p_button_position=>'TOP'
,p_button_alignment=>'RIGHT'
,p_show_processing=>'Y'
,p_confirm_message=>unistr('\00BFEst\00E1 seguro de realizar la acci\00F3n de cerrar el periodo?')
,p_button_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE ',
'V_CONTADOR NUMBER;',
'BEGIN',
'	select COUNT(distinct 1) CERRAR INTO V_CONTADOR from t_finz_gestiontributaria where estado!=3 and id =:P182_IDPERIODO',
'    AND NOT EXISTS ( select    COUNT(1),estado    from t_finz_gestiontributariadet where idgtb=:P182_IDPERIODO AND estado!=3 GROUP BY estado',
'    );',
'	IF (V_CONTADOR=1) THEN ',
'		RETURN TRUE;',
'	ELSE',
'		RETURN FALSE;',
'	END IF;',
'END;',
'	'))
,p_button_condition2=>'PLSQL'
,p_button_condition_type=>'FUNCTION_BODY'
,p_icon_css_classes=>'fa-calendar-times-o'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(540148458281116701)
,p_button_sequence=>90
,p_button_plug_id=>wwv_flow_imp.id(550356363927460429)
,p_button_name=>'Activar_Periodo'
,p_button_static_id=>'btnActivarPeriodo'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860056812106557)
,p_button_image_alt=>'Activar Periodo'
,p_button_position=>'TOP'
,p_button_alignment=>'RIGHT'
,p_show_processing=>'Y'
,p_confirm_message=>unistr('\00BFEst\00E1 seguro de realizar la acci\00F3n de re apertura del periodo?')
,p_button_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE ',
'V_CONTADOR NUMBER;',
'BEGIN',
'	select COUNT(distinct 1)   ABRIR into V_CONTADOR from t_finz_gestiontributaria where estado=3 and id =:P182_IDPERIODO',
'	AND NOT EXISTS ( select    COUNT(1),estado    from t_finz_gestiontributariadet where idgtb=:P182_IDPERIODO AND estado!=3 GROUP BY estado) ;',
'',
'	IF (V_CONTADOR=1) THEN ',
'        RETURN TRUE;',
'	ELSE',
'		RETURN FALSE;',
'	END IF;',
'END;'))
,p_button_condition2=>'PLSQL'
,p_button_condition_type=>'FUNCTION_BODY'
,p_icon_css_classes=>'fa-calendar-check-o'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(11713823103621015)
,p_name=>'P182_TIENEARCHIVOS'
,p_item_sequence=>120
,p_item_plug_id=>wwv_flow_imp.id(540149575263116712)
,p_prompt=>'Tienearchivos'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(34446026087782343)
,p_name=>'P182_IDDATO'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(172202649544168437)
,p_prompt=>'.'
,p_display_as=>'NATIVE_RADIOGROUP'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'with ',
'      tob as ( SELECT id_tabla tob_id, descripcion tob_descripcion FROM DATA.T_CORP_UDC WHERE activo=''1'' and id_cabecera = ''FINZ_GT02'' AND id_tabla >=''900'' )',
'    , tpr as ( SELECT id_tabla tpr_id, descripcion tpr_descripcion FROM DATA.T_CORP_UDC WHERE activo=''1'' and id_cabecera = ''FINZ_GT01'' AND id_tabla != ''000'' and id_tabla=:P182_ACTIVIDADES  )',
'SELECT cfg.descripcion d,dat.id r',
'FROM t_finz_gestiontributariacfg cfg',
'inner join DATA.t_finz_gestiontributariadatos dat on cfg.id= dat.IDCFG',
'inner join DATA.t_finz_gestiontributariadet det on dat.iddet= det.id',
'INNER JOIN tob ON tob_id = cfg.tipoobjeto',
'INNER JOIN tpr ON tpr_id = cfg.idproceso',
'WHERE 1=1 ',
'and det.idgtb=:P182_IDPERIODO',
'and cfg.estado=1',
'and trim(tob_descripcion) !=''RESULTADOS ATS XML''',
'and datosmod is not null',
'ORDER BY  d;'))
,p_lov_cascade_parent_items=>'P182_ACTIVIDADES'
,p_ajax_items_to_submit=>'P182_ACTIVIDADES'
,p_ajax_optimize_refresh=>'Y'
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--stretchInputs:t-Form-fieldContainer--large:margin-top-none:margin-bottom-none:margin-left-none:margin-right-none:t-Form-fieldContainer--radioButtonGroup'
,p_warn_on_unsaved_changes=>'I'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'12'
,p_attribute_02=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(45213952931289113)
,p_name=>'P182_SECUENCIAFN'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(45215049974289124)
,p_prompt=>'Secuencia FN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'0'
,p_attribute_02=>'9999999999'
,p_attribute_03=>'left'
,p_attribute_04=>'numeric'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(45214098760289114)
,p_name=>'P182_SECUENCIAD1'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(45215049974289124)
,p_prompt=>'Secuencia D1'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(45214176889289115)
,p_name=>'P182_SECUENCIAFE'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(45215049974289124)
,p_prompt=>'Secuencia FE'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(45215923954289133)
,p_name=>'P182_SECUENCIAFD'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(45215049974289124)
,p_prompt=>'Secuencia FD'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(50249240326209239)
,p_name=>'P182_TIENERESUMEN'
,p_item_sequence=>130
,p_item_plug_id=>wwv_flow_imp.id(540149575263116712)
,p_prompt=>'Tieneresumen'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(65697171498146329)
,p_name=>'P182_PERIODO'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(540149575263116712)
,p_prompt=>'Periodo'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(123115807265713201)
,p_name=>'P182_MENSAJE'
,p_item_sequence=>140
,p_item_plug_id=>wwv_flow_imp.id(540149575263116712)
,p_prompt=>'Mensaje'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(123116948077713212)
,p_name=>'P182_USUARIO'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(540149575263116712)
,p_prompt=>'Usuario'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(125469691370948931)
,p_name=>'P182_CODDOC_REEMB'
,p_item_sequence=>150
,p_item_plug_id=>wwv_flow_imp.id(540149575263116712)
,p_prompt=>'Coddoc Reemb'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(125469722949948932)
,p_name=>'P182_CODDCT_REEMB'
,p_item_sequence=>170
,p_item_plug_id=>wwv_flow_imp.id(540149575263116712)
,p_prompt=>'Coddct Reemb'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(125470661732948941)
,p_name=>'P182_SERVERDESCARGA'
,p_item_sequence=>180
,p_item_plug_id=>wwv_flow_imp.id(540149575263116712)
,p_prompt=>'Serverdescarga'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(125471007892948945)
,p_name=>'P182_NUMERORCHIVO'
,p_item_sequence=>190
,p_item_plug_id=>wwv_flow_imp.id(540149575263116712)
,p_prompt=>'Numerorchivo'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(171732842997653204)
,p_name=>'P182_TIPO_REEMB'
,p_item_sequence=>160
,p_item_plug_id=>wwv_flow_imp.id(540149575263116712)
,p_prompt=>'Tipo Reemb'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(172202236068168433)
,p_name=>'P182_PERIODO_NOMBRE'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(540149575263116712)
,p_prompt=>'Periodo:'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(180869803747614207)
,p_name=>'P182_FAICON_PROCESOS'
,p_item_sequence=>200
,p_item_plug_id=>wwv_flow_imp.id(540149575263116712)
,p_prompt=>'Faicon Procesos'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(180871407441614223)
,p_name=>'P182_SECUENCIART'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(180871558737614224)
,p_prompt=>'Secuencia'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(180873619327614245)
,p_name=>'P182_POSICION'
,p_item_sequence=>210
,p_item_plug_id=>wwv_flow_imp.id(540149575263116712)
,p_prompt=>'Posicion'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(215621043363421301)
,p_name=>'P182_EXITO'
,p_item_sequence=>220
,p_item_plug_id=>wwv_flow_imp.id(540149575263116712)
,p_prompt=>'Exito'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(258344277483605222)
,p_name=>'P182_ICONAF'
,p_item_sequence=>230
,p_item_plug_id=>wwv_flow_imp.id(540149575263116712)
,p_prompt=>'Iconaf'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(258344301395605223)
,p_name=>'P192_TIENE_AF'
,p_item_sequence=>240
,p_item_plug_id=>wwv_flow_imp.id(540149575263116712)
,p_prompt=>'Tiene Af'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(284751524828074940)
,p_name=>'P182_ACTIVIDADESPERMISO'
,p_item_sequence=>250
,p_item_plug_id=>wwv_flow_imp.id(540149575263116712)
,p_prompt=>'Actividadespermiso'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(284751695095074941)
,p_name=>'P182_ACTIVIDADESROL'
,p_item_sequence=>260
,p_item_plug_id=>wwv_flow_imp.id(540149575263116712)
,p_prompt=>'Actividadesrol'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(540148718700116704)
,p_name=>'P182_ACTIVIDADES'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(540148598405116702)
,p_use_cache_before_default=>'NO'
,p_prompt=>'.'
,p_display_as=>'NATIVE_RADIOGROUP'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT DESCRIPCION,ID_TABLA FROM "DATA"."T_CORP_UDC" ',
'WHERE ID_CABECERA=''FINZ_GT01'' and ( TO_NUMBER(ID_TABLA) BETWEEN 1 AND 899)',
'and ID_TABLA in (SELECT ITEM FROM TABLE(PK_COMMONS.F_DIVIDIRTEXTO(:P182_ACTIVIDADESPERIODO,'':'') ) )',
'and id_tabla in (select idproceso from t_finz_gestiontributariadet det where det.IDGTB= :P182_IDPERIODO)',
'AND ID_TABLA in (SELECT ITEM FROM TABLE(PK_COMMONS.F_DIVIDIRTEXTO(:P182_ACTIVIDADESPERMISO,'':'') ) )'))
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'t-Form-fieldContainer--stretchInputs:margin-top-none:margin-bottom-none:margin-left-none:margin-right-none:t-Form-fieldContainer--radioButtonGroup'
,p_warn_on_unsaved_changes=>'I'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'12'
,p_attribute_02=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(540149657753116713)
,p_name=>'P182_IDPERIODO'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(540149575263116712)
,p_prompt=>'Idperiodo'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(540149976354116716)
,p_name=>'P182_ACTIVIDADESPERIODO'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(540149575263116712)
,p_prompt=>'Actividadesperiodo'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(549655994222944714)
,p_name=>'P182_IDREGISTRO'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(540149575263116712)
,p_prompt=>'Idregistro'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(549656771502944722)
,p_name=>'P182_COMPANIA'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(540149575263116712)
,p_prompt=>'Compania'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(550496953221860806)
,p_name=>'P182_DEREGISTRO'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(581863514509074749)
,p_prompt=>'Deregistro'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859556976106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(550994062399588412)
,p_name=>'P182_ULREGISTRO'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_imp.id(540149575263116712)
,p_prompt=>'Ulregistro'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(550994975188588421)
,p_name=>'P182_NMREGISTRO'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(581863514509074749)
,p_prompt=>'Nmregistro'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859556976106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(550996384241588435)
,p_name=>'P182_ALERTAERROR'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(550996438458588436)
,p_prompt=>'Alertaerror'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--stretchInputs:t-Form-fieldContainer--large:t-Form-fieldContainer--preTextBlock:t-Form-fieldContainer--postTextBlock:margin-top-none:margin-bottom-none:margin-left-none:margin-right-none:t-Form-fieldContainer--radioBut'
||'tonGroup'
,p_attribute_01=>'Y'
,p_attribute_04=>'N'
,p_attribute_05=>'HTML'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(580582897073466348)
,p_name=>'P182_ESTADO_DATO'
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_imp.id(540149575263116712)
,p_prompt=>'Estado Dato'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(550355987423460425)
,p_name=>'LoadPage'
,p_event_sequence=>20
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'ready'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(11713738068621014)
,p_event_id=>wwv_flow_imp.id(550355987423460425)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'var tienearch =$v("P182_TIENEARCHIVOS");',
'tienearch=parseInt(tienearch, 10);',
'if (tienearch===1){',
'    $s("P182_TIENEARCHIVOS"," 999");',
'    $("#btnCargarArchivos").trigger("click");',
'}',
'$(v_secDetalle).hide();',
'$("#btnResumen").hide();',
'/*llamada a la funcion para renderizar la tabla */',
'let p_filtro=1;',
'ejecutarConBarraCarga(p_filtro);',
'console.log("P192_TIENE_AF:"+$v("P192_TIENE_AF"));',
' if($v("P192_TIENE_AF")==="0"){',
'    $(v_secAlerta).show();//apex.message.alert($v("P182_ALERTAERROR"));',
'}'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(550497227735860809)
,p_name=>'CambioRegistro'
,p_event_sequence=>30
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P182_DEREGISTRO'
,p_condition_element=>'P182_DEREGISTRO'
,p_triggering_condition_type=>'NOT_NULL'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(550497302586860810)
,p_event_id=>wwv_flow_imp.id(550497227735860809)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
':G_GT_VALJSON:=:P182_DEREGISTRO;',
':G_GT_IDJSON:=:P182_IDREGISTRO;'))
,p_attribute_02=>'P182_DEREGISTRO,P182_IDREGISTRO'
,p_attribute_03=>'G_GT_VALJSON,G_GT_IDJSON'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(550994149621588413)
,p_event_id=>wwv_flow_imp.id(550497227735860809)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>' $(''#btnEditarCrearRegistro'').trigger("click");'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(550995455445588426)
,p_name=>'Cambia Data 0'
,p_event_sequence=>50
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P182_IDDATO'
,p_condition_element=>'P182_IDDATO'
,p_triggering_condition_type=>'NOT_NULL'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(123116290491713205)
,p_event_id=>wwv_flow_imp.id(550995455445588426)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'console.clear();',
'console.log("IDDATO_INICIO", {iddato: $v("P182_IDDATO"), actividad: $v("P182_ACTIVIDADES")});',
unistr('$(v_secDetalle).hide();  // Aseg\00FArate que `secDetalle` exista en el \00E1mbito'),
'$(v_regBarraAccion2).hide();',
'$(v_secAlerta).hide();',
'apex.item("P182_ACTIVIDADES").disable();',
'apex.item("P182_IDDATO").disable();',
'$("#btnIngresarSecuencias").hide();',
'$("#btnCerrarActividad").hide();',
'$("#btnAbrirActividad").hide();',
'$("#btnGrabarCambios").hide();',
'$("#btnInsertaRegistroJson").hide();',
'$("#btnResumen").hide();',
'$("#btnAts").hide();',
'$("#btnRecargar").hide();',
'f_llamarProcesoByID($v("P182_IDDATO")).then((resultado) => {',
'	console.log("RESULTADO", {tieneDatajson: resultado.tieneDatajson, estado: resultado.estado, gtjsonLength: (resultado.gtjson || "").length, columnasLength: (resultado.columnas || "").length});',
'	console.log("ln.16.resultado.tieneDatajson:"+resultado.tieneDatajson);',
'	if(resultado.tieneDatajson==1){',
'		const v_alerta=(resultado.estado===3)? "Proceso: "+apex.item(''P182_ACTIVIDADES'').displayValueFor($v(''P182_ACTIVIDADES''))+"/"+apex.item(''P182_IDDATO'').displayValueFor($v(''P182_IDDATO''))+" Cerrado" :"";',
'		if (resultado.estado===3){$(v_secAlerta).show();$("#btnAbrirActividad").show();}',
'		if (resultado.estado!==3){',
'			$("#btnCerrarActividad").show();',
'			$("#btnGrabarCambios").show();',
'			$("#btnInsertaRegistroJson").show();',
'			$("#btnRecargar").show();',
'			if ($v("P182_ACTIVIDADES")==="002"){$("#btnIngresarSecuencias").show();$(v_regSecVenta).show();}',
'			if ($v("P182_ACTIVIDADES")==="003"){$("#btnIngresarSecuencias").show();$(v_regSecRetencion).show();}',
'		}',
'		$s("P182_ALERTAERROR",v_alerta);',
'		$s("P182_ESTADO_DATO",resultado.estado);',
'		$s("P182_TIENERESUMEN",resultado.tieneresumen);',
'		v_JSONCOLUMNAS=resultado.columnas;',
'		v_JSONCOLUMNASMAYORES=resultado.columnasmayor;',
'		v_JSONGESTION= resultado.gtjson;',
'		if(resultado.tieneresumen===''Y''){',
'			$("#btnResumen").show();',
'		}',
'		if($v("P182_ACTIVIDADES")===''009''){',
'			$("#btnAts").show();',
'		}',
'		',
'		/*llamada a la funcion para renderizar la tabla */',
'		let p_filtro=1;',
'		//f_generatabla(v_JSONGESTION,resultado.columnas,p_filtro);',
'		return ejecutarConBarraCarga(p_filtro, true).then(() => {',
'			$(v_regBarraAccion2).show();',
'			apex.item("P182_IDDATO").enable();',
'			apex.item("P182_ACTIVIDADES").enable();',
'		});',
'	}',
'	else{',
unistr('		console.warn("IDDATO_SIN_DATOS", "No se encontr\00F3 data para renderizar");'),
unistr('		mensajeError("No se ha seleccionado el origen de informaci\00F3n del proceso");'),
'		apex.item("P182_IDDATO").enable(); ',
'		apex.item("P182_ACTIVIDADES").enable(); 	',
'		return false;',
'	}',
'',
'	',
'}).catch((error) => {',
'	console.error("Hubo un error: " + error);',
'	apex.item("P182_IDDATO").enable();',
'	apex.item("P182_ACTIVIDADES").enable();',
'	return false;',
'}).finally(() => {',
'    ocultarBarraSegura();',
'    $(v_regBarraAccion2).show();',
'});',
''))
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(123117862952713221)
,p_event_id=>wwv_flow_imp.id(550995455445588426)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>':G_GT_IDJSON:=:P182_IDDATO;'
,p_attribute_02=>'P182_IDDATO'
,p_attribute_03=>'G_GT_IDJSON'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(8906768498245708)
,p_name=>'Carga_Datos'
,p_event_sequence=>70
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(540055834851066049)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(29613144717218708)
,p_event_id=>wwv_flow_imp.id(8906768498245708)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_CONFIRM'
,p_attribute_01=>unistr('La ejecuci\00F3n del proceso puede tomar tiempo debido a la cantidad de datos.<br /> <br /> \00BFConfirma que desea proceder?')
,p_attribute_03=>'danger'
,p_attribute_04=>'fa-recycle'
,p_attribute_06=>unistr('S\00CD')
,p_attribute_07=>'NO'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(8906940506245710)
,p_event_id=>wwv_flow_imp.id(8906768498245708)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_01=>'CargatDatos'
,p_attribute_02=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(8909104580245732)
,p_name=>'Exportar'
,p_event_sequence=>80
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(8909048448245731)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(8909254386245733)
,p_event_id=>wwv_flow_imp.id(8909104580245732)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'let precesoSeleccionado = $(`input[name="P182_ACTIVIDADES"]:checked`).next("label").text().trim();',
'let datoSeleccionado    = $(`input[name="P182_IDDATO"]:checked`).next("label").text().trim();',
'',
'',
'const cadena = precesoSeleccionado+"_"+datoSeleccionado;',
'const cadenaSinEspacios = cadena.replace(/ /g, "_");',
'',
'exportTabla2Xlsx(cadenaSinEspacios ,''report_detail'',"DATOS_TABLA",v_JSONCOLUMNAS);'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(13870615573746215)
,p_name=>'RecargarDetalle'
,p_event_sequence=>90
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(13870558570746214)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(13870739548746216)
,p_event_id=>wwv_flow_imp.id(13870615573746215)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'$s("P182_IDDATO",$v("P182_IDDATO"));'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(42164298830330503)
,p_name=>'GUARDAR CAMBIOS'
,p_event_sequence=>100
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(42164160448330502)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(42164371995330504)
,p_event_id=>wwv_flow_imp.id(42164298830330503)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'let v_JSONGESTION_GRABAR = f_obtener_datos_editados();',
'v_JSONGESTION = v_JSONGESTION_GRABAR;',
'console.log(v_JSONGESTION_GRABAR );',
'let parametro1=$v("P182_IDPERIODO");',
'let parametro2=$v("P182_COMPANIA");',
'let parametro3=$v("P182_ACTIVIDADES");',
'let parametro4=$v("P182_USUARIO");',
'let parametro5=v_JSONGESTION_GRABAR;',
'let parametro6=$v("P182_IDDATO");  ',
'apex.item("P182_ACTIVIDADES").disable();',
'apex.item("P182_IDDATO").disable();',
'const filtros = _getFiltrosActivos();        ',
'f_llamarProcesoGrabar(parametro1,parametro2,parametro3,parametro4,parametro5,parametro6).then((resultado) => {',
'    if (resultado.exito===1) {',
'        $("#btnRecargar").trigger("click");// ejecutarConBarraCarga(1);                   // re-render con filtros	',
'        _setFiltrosActivos(filtros);                // restaurar filtros',
'        mensajeExito("Datos almacenados correctamente");',
'    } else {',
unistr('        mensajeError(resultado.mensaje || "No se ha seleccionado el origen de informaci\00F3n del proceso");'),
'    }',
'})',
'.catch((error) => {',
'    mensajeError("Hubo un error: " + error);',
'    console.error("Hubo un error: " + error); ',
'})',
'.finally(() => {',
'    apex.item("P182_ACTIVIDADES").enable();',
'    apex.item("P182_IDDATO").enable();',
'  });',
'  $s("P182_IDDATO",$v("P182_IDDATO"));'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(42164565379330506)
,p_name=>'insertar registro'
,p_event_sequence=>110
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(550994637214588418)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(42164605018330507)
,p_event_id=>wwv_flow_imp.id(42164565379330506)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'$(v_secDetalle).hide();',
' ',
'if ((v_JSONGESTION)!=""){',
'    v_JSONGESTION=f_aplicar_calculos_json(v_JSONGESTION,v_JSONCOLUMNAS);',
'}',
' let p_visibles=1;',
'let p_acc_edita=($v("P182_ESTADO_DATO")==="3")? 0 :2;',
'let p_acc_borra=getBorra();',
'let p_acc_copia= getCopia();',
'let p_columnas_orden=getSort();',
'let p_proceso=$v("P182_ACTIVIDADES");',
'let p_filtro=0;',
'f_genera_tablahtml_json(v_JSONGESTION,v_JSONCOLUMNAS,p_visibles,p_acc_edita,p_acc_borra,p_acc_copia,p_columnas_orden,p_proceso,p_filtro);',
'',
' '))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(45215671115289130)
,p_name=>'abrirRgionDialog'
,p_event_sequence=>120
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(45215383762289127)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(45215724213289131)
,p_event_id=>wwv_flow_imp.id(45215671115289130)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(45213862780289112)
,p_attribute_01=>'$(this.affectedElements).dialog(''open'')'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(45216265482289136)
,p_name=>'cerrarRgionDialog'
,p_event_sequence=>130
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(45215877634289132)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(45216333033289137)
,p_event_id=>wwv_flow_imp.id(45216265482289136)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(45213862780289112)
,p_attribute_01=>'$(this.affectedElements).dialog(''close'')'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(45216422418289138)
,p_name=>'Aceptar'
,p_event_sequence=>140
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(45214842710289122)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(65696818776146326)
,p_event_id=>wwv_flow_imp.id(45216422418289138)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'//mostrarBarra();'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(45216547627289139)
,p_event_id=>wwv_flow_imp.id(45216422418289138)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'$(v_secDetalle).hide();',
' ',
'let secuencias = f_getsecuencias();',
' ',
'if ((v_JSONGESTION)!=""){',
'    v_JSONGESTION=f_preprocesar_json_segun_secuencias(v_JSONGESTION,secuencias);',
'}',
'if (v_JSONGESTION!=""){',
'    v_JSONGESTION=f_aplicar_calculos_json(v_JSONGESTION,v_JSONCOLUMNAS);',
'}',
'let p_visibles=1;',
'let p_acc_edita=($v("P182_ESTADO_DATO")==="3")? 0 : 1;;',
'let p_acc_borra=getBorra();',
'let p_acc_copia= getCopia();',
'let p_columnas_orden=getSort();',
'let p_proceso=$v("P182_ACTIVIDADES");',
'let p_filtro=0;',
'f_genera_tablahtml_json(v_JSONGESTION,v_JSONCOLUMNAS,p_visibles,p_acc_edita,p_acc_borra,p_acc_copia,p_columnas_orden,p_proceso,p_filtro);',
''))
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(45216659195289140)
,p_event_id=>wwv_flow_imp.id(45216422418289138)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(45213862780289112)
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'$(this.affectedElements).dialog(''close'')',
'//ocultarBarra();'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(123117051880713213)
,p_name=>'Actividades'
,p_event_sequence=>150
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P182_ACTIVIDADES'
,p_condition_element=>'P182_ACTIVIDADES'
,p_triggering_condition_type=>'NOT_NULL'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(125466688768948901)
,p_event_id=>wwv_flow_imp.id(123117051880713213)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare v_contar number;',
'begin',
'	:G_GT_ACTIVIDADES:=:P182_ACTIVIDADES;',
'',
'	with ',
'	      tob as ( SELECT id_tabla tob_id, descripcion tob_descripcion FROM DATA.T_CORP_UDC WHERE activo=''1'' and id_cabecera = ''FINZ_GT02'' AND id_tabla >=''900'' )',
'	    , tpr as ( SELECT id_tabla tpr_id, descripcion tpr_descripcion FROM DATA.T_CORP_UDC WHERE activo=''1'' and id_cabecera = ''FINZ_GT01'' AND id_tabla != ''000'' and id_tabla=:P182_ACTIVIDADES  )',
'	SELECT count(distinct 1) into v_contar',
'	FROM t_finz_gestiontributariacfg cfg',
'	inner join DATA.t_finz_gestiontributariadatos dat on cfg.id= dat.IDCFG',
'	inner join DATA.t_finz_gestiontributariadet det on dat.iddet= det.id',
'	INNER JOIN tob ON tob_id = cfg.tipoobjeto',
'	INNER JOIN tpr ON tpr_id = cfg.idproceso',
'	WHERE 1=1 ',
'	and det.idgtb=:P182_IDPERIODO',
'	and cfg.estado=1',
'	and trim(tob_descripcion) !=''RESULTADOS ATS XML''',
'	and datosmod is not null',
'	;',
'	:P182_MENSAJE:='''';',
'	if (v_contar=0)then',
unistr('		:P182_MENSAJE:=''Datos no cargados para esta opci\00F3n.'';'),
'	end if;',
'end;'))
,p_attribute_02=>'P182_ACTIVIDADES,P182_IDPERIODO'
,p_attribute_03=>'G_GT_ACTIVIDADES,P182_MENSAJE'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(180869335836614202)
,p_event_id=>wwv_flow_imp.id(123117051880713213)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'alert(''es vacio'')',
'document.querySelector(".t-Button--closeAlert")?.click();'))
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(123117194161713214)
,p_event_id=>wwv_flow_imp.id(123117051880713213)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'$(v_secDetalle).hide();',
'$(v_regSecVenta).hide();',
'$(v_regSecRetencion).hide();',
'$(v_regBarraAccion2).hide();',
'$(v_secAlerta).hide();',
'$s("P182_IDDATO","");',
'console.clear();',
'document.querySelector(".t-Button--closeAlert")?.click();',
'console.log("''"+$v("P182_MENSAJE")+"''");',
'if($v("P182_MENSAJE")!==""){',
'	console.log("abre el mensaje");',
'	mensajeError($v("P182_MENSAJE"));',
'}'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(125466815295948903)
,p_name=>'QuitarFiltros'
,p_event_sequence=>160
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(125466778677948902)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(125466920857948904)
,p_event_id=>wwv_flow_imp.id(125466815295948903)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
' ',
'f_limpiarFiltrosTabla();',
' '))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(125469833408948933)
,p_name=>'CAMBIA CODDOC REEMB'
,p_event_sequence=>170
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P182_CODDOC_REEMB'
,p_condition_element=>'P182_CODDOC_REEMB'
,p_triggering_condition_type=>'NOT_NULL'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(125469981137948934)
,p_event_id=>wwv_flow_imp.id(125469833408948933)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>':G_VALOR1:=:P182_CODDOC_REEMB;'
,p_attribute_02=>'P182_CODDOC_REEMB'
,p_attribute_03=>'G_VALOR1'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(125470065417948935)
,p_name=>'CAMBIA CODDCT REEMB'
,p_event_sequence=>180
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P182_CODDCT_REEMB'
,p_condition_element=>'P182_CODDCT_REEMB'
,p_triggering_condition_type=>'NOT_NULL'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(125470122780948936)
,p_event_id=>wwv_flow_imp.id(125470065417948935)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>':G_VALOR2:=:P182_CODDCT_REEMB;'
,p_attribute_02=>'P182_CODDCT_REEMB'
,p_attribute_03=>'G_VALOR2'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(125470441354948939)
,p_event_id=>wwv_flow_imp.id(125470065417948935)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'$(''#btnPage198'').trigger("click");'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(125470762201948942)
,p_name=>'ATS'
,p_event_sequence=>190
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(125470578067948940)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(125471250192948947)
,p_event_id=>wwv_flow_imp.id(125470762201948942)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'//mostrarBarra();'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(125470820159948943)
,p_event_id=>wwv_flow_imp.id(125470762201948942)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE V_TEXTO VARCHAR2(3999);',
'valor1 number;',
'valor2 varchar2(3999);',
'begin',
'	SELECT cfg.descripcion  INTO V_TEXTO FROM t_finz_gestiontributariacfg cfg inner join t_finz_gestiontributariadatos dat on cfg.id=dat.idcfg where dat.id=:P182_IDDATO;',
'	PK_FINZ_GESTIONTRIBUTARIA.sp_generarxmlats (:P182_IDPERIODO ,:g_compania,V_TEXTO ,:P182_NUMERORCHIVO,:P182_EXITO,:P182_MENSAJE);',
'exception when others then',
'	:P182_MENSAJE:=sqlerrm;',
'end;'))
,p_attribute_02=>'P182_IDPERIODO ,G_COMPANIA ,P182_NUMERORCHIVO'
,p_attribute_03=>'P182_NUMERORCHIVO,P182_MENSAJE,P182_EXITO'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(125470941230948944)
,p_event_id=>wwv_flow_imp.id(125470762201948942)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'//ocultarBarra();',
'if ($v("P182_MENSAJE")===""){',
'	var NUMEROARCHIVOXML=$v("P182_NUMERORCHIVO");',
'    var url="http://"+$v("P182_SERVERDESCARGA")+".zaimella.com/QCPs/fileApexDownloadWS/"+NUMEROARCHIVOXML;',
'    window.open(url, "_blank");',
'	mensajeExito("Archivo Descargado");',
'}',
'else {',
'		if($v("P182_EXITO")==="2"){',
'			var NUMEROARCHIVOXML=$v("P182_NUMERORCHIVO");',
'			var url="http://"+$v("P182_SERVERDESCARGA")+".zaimella.com/QCPs/fileApexDownloadWS/"+NUMEROARCHIVOXML;',
'			window.open(url, "_blank");',
'			//mensajeExito("Archivo Descargado");',
'			alertaWarn($v("P182_MENSAJE"),  true, 10000);',
'			',
'		}else{',
'			mensajeError($v("P182_MENSAJE"));',
'		}',
'',
'}',
''))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(171732952141653205)
,p_name=>'CAMBIA TIPO REEMB'
,p_event_sequence=>200
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P182_TIPO_REEMB'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(171733091063653206)
,p_event_id=>wwv_flow_imp.id(171732952141653205)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>':G_VALOR3:=:P182_TIPO_REEMB;'
,p_attribute_02=>'P182_TIPO_REEMB'
,p_attribute_03=>'G_VALOR3'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(180872871687614237)
,p_name=>'CERRAR_ACTIVIDAD'
,p_event_sequence=>210
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(550356553497460431)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(180872994676614238)
,p_event_id=>wwv_flow_imp.id(180872871687614237)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_name=>'CERRAR_ACTIVIDAD'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'let v_JSONGESTION = f_obtener_datos_editados();',
'let parametro1=$v("P182_IDPERIODO");',
'let parametro2=$v("P182_COMPANIA");',
'let parametro3=$v("P182_ACTIVIDADES");',
'let parametro4=$v("P182_USUARIO");',
'let parametro5='''';',
'let parametro6=$v("P182_IDDATO");  ',
'let parametro7=2;  ',
'apex.item("P182_ACTIVIDADES").disable();',
'apex.item("P182_IDDATO").disable();',
'//mostrarBarra();',
'const filtros = _getFiltrosActivos();        ',
'f_llamarProcesoCerrar(parametro1,parametro2,parametro3,parametro4,parametro5,parametro6,parametro7)',
'  .then((resultado) => {',
'    if (resultado.exito===1) {',
'		if(resultado.loadpage===0){',
'			$("#btnRecargar").trigger("click");',
'			ejecutarConBarraCarga(1);',
'			_setFiltrosActivos(filtros);',
'		}else{',
'			$("#btnenviarPagina").trigger("click");',
'		}',
'		mensajeExito("Datos almacenados correctamente");',
'    } else {',
unistr('      mensajeError("No se ha seleccionado el origen de informaci\00F3n del proceso");'),
'    }',
'  })',
'  .catch((error) => { mensajeError("Hubo un error: " + error);',
'  console.error("Hubo un error: " + error); })',
'  .finally(() => {',
'    //try{ocultarBarra();}catch(_){}',
'    apex.item("P182_ACTIVIDADES").enable();',
'    apex.item("P182_IDDATO").enable();',
'  });'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(215621408987421305)
,p_name=>'ABRIR_ACTIVIDAD'
,p_event_sequence=>220
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(215621309897421304)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(215621509174421306)
,p_event_id=>wwv_flow_imp.id(215621408987421305)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_name=>'ABRIR_ACTIVIDAD'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'let v_JSONGESTION = f_obtener_datos_editados();',
'let parametro1=$v("P182_IDPERIODO");',
'let parametro2=$v("P182_COMPANIA");',
'let parametro3=$v("P182_ACTIVIDADES");',
'let parametro4=$v("P182_USUARIO");',
'let parametro5='''';',
'let parametro6=$v("P182_IDDATO");  ',
'let parametro7=0;  ',
'apex.item("P182_ACTIVIDADES").disable();',
'apex.item("P182_IDDATO").disable();',
'// mostrarBarra();',
'const filtros = _getFiltrosActivos();        ',
'f_llamarProcesoCerrar(parametro1,parametro2,parametro3,parametro4,parametro5,parametro6,parametro7).then((resultado) => {',
'    if (resultado.exito===1) {',
'        if(resultado.loadpage===0){',
'            $("#btnRecargar").trigger("click");',
'            ejecutarConBarraCarga(1);',
'            _setFiltrosActivos(filtros);',
'        }else{',
'            $("#btnenviarPagina").trigger("click");',
'        }',
'        mensajeExito("Datos almacenados correctamente");',
'    } else {',
unistr('    mensajeError("No se ha seleccionado el origen de informaci\00F3n del proceso");'),
'    }',
'})',
'.catch((error) => {',
'    mensajeError("Hubo un error: " + error);',
'    console.error("Hubo un error: " + error); ',
'})',
'.finally(() => {',
'    // try{ocultarBarra();}catch(_){}',
'    apex.item("P182_ACTIVIDADES").enable();',
'    apex.item("P182_IDDATO").enable();',
'});'))
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(540149865288116715)
,p_process_sequence=>10
,p_process_point=>'AFTER_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'SetupPage'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare V_Actividad varchar2(3999);',
'begin',
'    :P182_COMPANIA:=:g_COMPANIA;',
'	:P182_USUARIO:=:APP_USER;',
'    begin',
'        SELECT ACTIVIDADES,PERIODO INTO :P182_ACTIVIDADESPERIODO,:P182_PERIODO FROM T_FINZ_GESTIONTRIBUTARIA where id =:P182_IDPERIODO;',
'    exception when others then ',
'        null;',
'    end;',
'    :G_GT_VALJSON:='''';',
'	-- :P182_IDDATO:=NULL;',
'	-- :P182_ACTIVIDADES:=NULL;',
'	:P182_PERIODO_NOMBRE:=REPLACE(to_char(to_date(:P182_PERIODO,''YYYYMM''),''Month/YYYY''),'' '','''') ;',
'end;',
'',
'',
'declare v_server VARCHAR2(100);',
'begin',
'    v_server:=''pruebas'';',
'    IF(PK_CORP_COMMONS.F_ISPRODUCCION())THEN',
'        v_server:=''apps'';',
'    END IF;',
'    :P182_SERVERDESCARGA:=v_server;',
'    DBMS_OUTPUT.PUT_LINE(''v_server: ''||:P182_SERVERDESCARGA );',
'end;',
'declare v_contador number;',
'begin',
'	SELECT',
'	 count(distinct 1) into v_contador',
'	FROM',
'	    t_finz_gestiontributaria      gtb',
'	    LEFT JOIN t_finz_gestiontributariadet   det ON gtb.id = det.idgtb',
'	    LEFT JOIN t_finz_gestiontributariadatos dat ON dat.iddet = det.id',
'	where dat.datosmod is null',
'	and det.idgtb= :P182_IDPERIODO',
'	order by dat.id,det.idproceso,det.idgtb,det.id,dat.idcfg;',
'	:P182_FAICON_PROCESOS:=v_contador;',
'end;',
'',
' ',
'BEGIN',
'',
' pk_finz_gestiontributaria.sp_validaLocalAreasFiscales(',
'        p_periodo =>:P182_PERIODO,',
'        p_alertaerror  =>:P182_ALERTAERROR,',
'        p_tiene_af  =>:P192_TIENE_AF,',
'        p_icon  =>:P182_ICONAF',
'    );',
'END;',
'',
'BEGIN',
'    SELECT VALOR2,DESCRIPCION INTO :P182_ACTIVIDADESPERMISO,:P182_ACTIVIDADESROL',
'    FROM DATA.T_CORP_UDC',
'    WHERE ID_TABLA <> ''000''',
'      AND ACTIVO = ''1''',
'      AND ID_CABECERA = ''FINZ_GT00''',
'      AND NVL(UPPER(VALOR), UPPER(:APP_USER)) = UPPER(:APP_USER)',
'    ORDER BY DECODE(UPPER(VALOR), UPPER(:APP_USER), 1, 2)',
'    FETCH FIRST 1 ROW ONLY;',
'END;',
''))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>540149865288116715
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(550995969877588431)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'PROCES0_SP_GENERARPERIODO'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare v_gtjson nclob;',
'begin  ',
'',
'	PK_FINZ_GESTIONTRIBUTARIA.sp_generardataperiodo',
'	(',
'		  p_idgtb	    =>:P182_IDPERIODO',
'		, p_compania	=>:G_COMPANIA',
'		, p_responsable =>:APP_USER',
'		, p_tienearchivos => :P182_TIENEARCHIVOS',
'	);',
'	:P182_ALERTAERROR:='''';',
'exception when others then ',
'	null;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>'CargatDatos'
,p_process_when_type=>'REQUEST_EQUALS_CONDITION'
,p_internal_uid=>550995969877588431
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(580582697445466346)
,p_process_sequence=>30
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'PROCESO_SP_GUARDARPROCESOMODPERIODO'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'if(1=2)then',
'    PK_FINZ_GESTIONTRIBUTARIA.sp_guardardataprocesoperiodo',
'    (',
'          p_idgtb		=>:P182_IDPERIODO',
'        , p_compania    =>:G_COMPANIA',
'        , p_idproceso   =>:P182_ACTIVIDADES',
'        , p_responsable =>:APP_USER',
'        , p_json        =>null--:P182_JSON',
'        , p_tipo        =>1',
'        , p_iddat       =>:P182_IDDATO',
'    ) ;',
'end if;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>'GUARDAR_JSON123'
,p_process_when_type=>'REQUEST_EQUALS_CONDITION'
,p_internal_uid=>580582697445466346
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(215621108356421302)
,p_process_sequence=>50
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'PROCESO_SP_CERRARPERIODO'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'    PK_FINZ_GESTIONTRIBUTARIA.sp_cierre_periodo',
'    (',
'          p_idgtb		=>:P182_IDPERIODO',
'    ) ;',
'    :P182_ESTADO_DATO:=3;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(540055934666066050)
,p_internal_uid=>215621108356421302
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(215621277382421303)
,p_process_sequence=>60
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'PROCESO_SP_ABRIRPERIODO'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'    PK_FINZ_GESTIONTRIBUTARIA.sp_reabrir_periodo',
'    (',
'          p_idgtb		=>:P182_IDPERIODO',
'    ) ;',
'    :P182_ESTADO_DATO:=3;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(540148458281116701)
,p_internal_uid=>215621277382421303
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(123115994571713202)
,p_process_sequence=>10
,p_process_point=>'ON_DEMAND'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'LLAMAR_PROCESO_BYID'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    l_result VARCHAR2(4000);',
'    v_datid number;',
'    v_gtjson nclob;',
'    v_estado number;',
'    v_columnas nclob ;         ',
'    v_columnasmayor clob;       ',
'    v_tieneresumen varchar2(5);',
'    v_secuenciad1 number;',
'    v_secuenciafn number;',
'    v_secuenciafe number;',
'    v_secuenciafd number;',
'    v_secuenciart number;',
'	v_tieneDatajson number;',
'BEGIN',
'    apex_json.open_object;',
'	v_datid:=apex_application.g_x01;',
unistr('    -- Llama a la funci\00F3n con los par\00E1metros que recibir\00E1 del lado del cliente'),
'	 PK_FINZ_GESTIONTRIBUTARIA.sp_extrae_informacion_json_byid(',
'		p_datid  => v_datid,',
'        p_gtjson => v_gtjson,',
'        p_estado => v_estado,',
'        p_columnas => v_columnas,',
'        p_columnasCtsMay => v_columnasmayor,',
'        p_tieneresumen => v_tieneresumen,',
'        p_secuenciad1 => v_secuenciad1,',
'        p_secuenciafn => v_secuenciafn,',
'        p_secuenciafe => v_secuenciafe,',
'        p_secuenciafd => v_secuenciafd,',
'        p_secuenciart => v_secuenciart',
'    );',
' ',
'	v_tieneDatajson:=case when DBMS_LOB.GETLENGTH(v_gtjson)>0 then 1 else 0 end;',
'    -- Devuelve el resultado para el lado del cliente',
'	apex_json.write( p_name => ''gtjson'', p_value =>v_gtjson);',
'	apex_json.write( p_name => ''estado'', p_value =>v_estado);',
'	apex_json.write( p_name => ''columnas'', p_value =>v_columnas);',
'	apex_json.write( p_name => ''tieneresumen'', p_value =>v_tieneresumen);',
'	apex_json.write( p_name => ''columnasmayor'', p_value =>v_columnasmayor);',
'	apex_json.write( p_name => ''secuenciad1'', p_value =>v_secuenciad1);',
'	apex_json.write( p_name => ''secuenciafn'', p_value =>v_secuenciafn);',
'	apex_json.write( p_name => ''secuenciafe'', p_value =>v_secuenciafe);',
'	apex_json.write( p_name => ''secuenciafd'', p_value =>v_secuenciafd);',
'	apex_json.write( p_name => ''secuenciart'', p_value =>v_secuenciart);',
'	apex_json.write( p_name => ''tieneDatajson'', p_value =>v_tieneDatajson);',
' ',
'',
'    apex_json.close_object;',
'END;',
'',
'',
''))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>123115994571713202
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(123116864697713211)
,p_process_sequence=>20
,p_process_point=>'ON_DEMAND'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'LLAMAR_GRABAR_PROCESO'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    l_result VARCHAR2(4000);',
'	v_idgtb number;',
'	v_compania varchar2(5);',
'	v_idproceso varchar2(30);',
'	v_responsable varchar2(399);',
'	v_json clob;',
'	v_tipo number;',
'	v_iddat number;',
'	v_exito number;',
'	v_mensaje varchar2(4000);',
'BEGIN',
'	PK_FINZ_GESTIONTRIBUTARIA.sp_log(p_tipo      => 1,p_linea         => 12 ,p_mensaje		=> ',
'        ''  p_idgtb =>''||v_idgtb||',
'        '', p_compania =>''||v_compania||',
'        '', p_idproceso =>''||v_idproceso||',
'        '', p_responsable =>''||v_responsable||',
'        '', p_tipo =>''||v_tipo||',
'        '', p_iddat =>''||v_iddat',
'        ,p_query=>v_json',
'    );',
'    apex_json.open_object;',
'	v_idgtb:=apex_application.g_x01;',
'	v_compania:=apex_application.g_x02;',
'	v_idproceso:=apex_application.g_x03;',
'	v_responsable:=apex_application.g_x04;',
'	v_json:=apex_application.g_clob_01;',
'	v_iddat:=apex_application.g_x05;',
'	v_tipo:=1;',
'',
'	begin',
'		    PK_FINZ_GESTIONTRIBUTARIA.sp_guardardataprocesoperiodo',
'	    (',
'	          p_idgtb		=>v_idgtb',
'	        , p_compania    =>v_compania',
'	        , p_idproceso   =>v_idproceso',
'	        , p_responsable =>v_responsable',
'	        , p_json        =>v_json',
'	        , p_tipo        =>v_tipo',
'	        , p_iddat       =>v_iddat',
'	    ) ;',
'	 	v_exito:=1;',
'        v_mensaje:=null;',
'	exception when others then ',
'		 	v_exito:=0;',
'            v_mensaje:=sqlerrm;',
'	end;	 ',
'    -- Devuelve el resultado para el lado del cliente',
'	apex_json.write( p_name => ''exito'', p_value =>v_exito);',
'	apex_json.write( p_name => ''mensaje'', p_value =>v_mensaje);',
'    apex_json.close_object;',
'END;',
'',
'',
''))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>123116864697713211
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(180873032548614239)
,p_process_sequence=>30
,p_process_point=>'ON_DEMAND'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'LLAMAR_CERRAR_PROCESO'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    l_result VARCHAR2(4000);',
'	v_idgtb number;',
'	v_compania varchar2(5);',
'	v_idproceso varchar2(30);',
'	v_responsable varchar2(399);',
'	v_json clob;',
'	v_tipo number;',
'	v_iddat number;',
'	v_exito number;',
'	v_contador number;',
'BEGIN',
'	PK_FINZ_GESTIONTRIBUTARIA.sp_log(p_tipo      => 1,p_linea         => 12 ,p_mensaje		=> ',
'        ''  p_idgtb =>''||v_idgtb||',
'        '', p_compania =>''||v_compania||',
'        '', p_idproceso =>''||v_idproceso||',
'        '', p_responsable =>''||v_responsable||',
'        '', p_tipo =>''||v_tipo||',
'        '', p_iddat =>''||v_iddat',
'        ,p_query=>v_json',
'    );',
'    apex_json.open_object;',
'	v_idgtb:=apex_application.g_x01;',
'	v_compania:=apex_application.g_x02;',
'	v_idproceso:=apex_application.g_x03;',
'	v_responsable:=apex_application.g_x04;',
'	v_json:=apex_application.g_clob_01;',
'	v_iddat:=apex_application.g_x05;',
'	v_tipo:=apex_application.g_x06;',
'',
'	begin',
'		    PK_FINZ_GESTIONTRIBUTARIA.sp_guardardataprocesoperiodo',
'	    (',
'	          p_idgtb		=>v_idgtb',
'	        , p_compania    =>v_compania',
'	        , p_idproceso   =>v_idproceso',
'	        , p_responsable =>v_responsable',
'	        , p_json        =>v_json',
'	        , p_tipo        =>v_tipo',
'	        , p_iddat       =>v_iddat',
'	    ) ;',
'	 	v_exito:=1;',
'	exception when others then ',
'		 	v_exito:=0;',
'	end;	 ',
'	select count(distinct 1) into v_contador from t_finz_gestiontributariadet where estado!=3 and idgtb=:P182_IDPERIODO;',
'	v_contador:=case v_contador when 0 then 1 else 0 end;',
'    -- Devuelve el resultado para el lado del cliente',
'	apex_json.write( p_name => ''exito'', p_value =>v_exito);',
'	apex_json.write( p_name => ''loadpage'', p_value =>v_contador);',
'    apex_json.close_object;',
'END;',
'',
'',
''))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>180873032548614239
);
wwv_flow_imp.component_end;
end;
/
