prompt --application/pages/page_00466
begin
--   Manifest
--     PAGE: 00466
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>109
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_page.create_page(
 p_id=>466
,p_name=>'Activos Fijos - Asig. Manual'
,p_alias=>unistr('ASIGNACI\00D3N-MANUAL')
,p_step_title=>unistr('Asignaci\00F3n Manual')
,p_autocomplete_on_off=>'OFF'
,p_javascript_code_onload=>'$(regOcultos).hide();'
,p_page_template_options=>'#DEFAULT#'
,p_page_component_map=>'18'
,p_last_updated_on=>wwv_flow_imp.dz('20260422210825Z')
,p_last_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(208193341950278461)
,p_plug_name=>'Filtros'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(38289867500120143)
,p_plug_display_sequence=>31
,p_location=>null
,p_ai_enabled=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
,p_updated_on=>wwv_flow_imp.dz('20260326152336Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(208895719200553217)
,p_plug_name=>'Activos Seleccionables'
,p_region_name=>'rg_activos_seleccionables'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(95503811913299190)
,p_plug_display_sequence=>41
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select apex_item.checkbox(1, id, '' class="chkF01"'') seleccion',
'	, lpad(coderp, 8, ''0'') coderp',
'	, codactivo',
'	, descripcion1',
'	, descripcion2',
'	, descripcion3',
'	, codtipo',
'	, codcategoria',
'	, codsubcategoria',
'	, estado',
'	, codubicacion',
'	, codcustodio',
'from t_finz_activosfijos',
'where 1 = 1',
'	and compania = :G_COMPANIA',
'	and (codtipo = :P466_TIPO or :P466_TIPO is null)',
'	and (codcategoria = :P466_CATEGORIA or :P466_CATEGORIA is null)',
'	and (codsubcategoria = :P466_SUBCATEGORIA or :P466_SUBCATEGORIA is null)',
'	and not exists (select ''X''',
'		from t_finz_activosfijoslev',
'		where 1 = 1',
'			and idact = t_finz_activosfijos.id',
'			and origen = ''ASIGNACION''',
'			and estado in (''CREACION'', ''PENDIENTE''))'))
,p_plug_source_type=>'NATIVE_IR'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
,p_ai_enabled=>false
,p_updated_on=>wwv_flow_imp.dz('20260326201450Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(208895880731553219)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'MALBAN'
,p_internal_uid=>208895880731553219
,p_updated_on=>wwv_flow_imp.dz('20260326201450Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(208897026850553230)
,p_db_column_name=>'SELECCION'
,p_display_order=>10
,p_column_identifier=>'J'
,p_column_label=>'-'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
,p_updated_on=>wwv_flow_imp.dz('20260326143233Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(208896116030553221)
,p_db_column_name=>'CODACTIVO'
,p_display_order=>40
,p_column_identifier=>'B'
,p_column_label=>unistr('C\00F3d. Activo')
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
,p_updated_on=>wwv_flow_imp.dz('20260209171127Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(208896211469553222)
,p_db_column_name=>'DESCRIPCION1'
,p_display_order=>50
,p_column_identifier=>'C'
,p_column_label=>unistr('Descripci\00F3n 1')
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(208896281347553223)
,p_db_column_name=>'CODTIPO'
,p_display_order=>60
,p_column_identifier=>'D'
,p_column_label=>'Tipo'
,p_column_type=>'STRING'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_rpt_named_lov=>wwv_flow_imp.id(98576969558658537)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(208896434531553224)
,p_db_column_name=>'CODCATEGORIA'
,p_display_order=>70
,p_column_identifier=>'E'
,p_column_label=>unistr('Categor\00EDa')
,p_column_type=>'STRING'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_rpt_named_lov=>wwv_flow_imp.id(98577560814666584)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(208896475272553225)
,p_db_column_name=>'CODSUBCATEGORIA'
,p_display_order=>80
,p_column_identifier=>'F'
,p_column_label=>unistr('Subcategor\00EDa:')
,p_column_type=>'STRING'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_rpt_named_lov=>wwv_flow_imp.id(98577774561669941)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(208896582849553226)
,p_db_column_name=>'ESTADO'
,p_display_order=>90
,p_column_identifier=>'G'
,p_column_label=>'Estado'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_updated_on=>wwv_flow_imp.dz('20260326143311Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(208896699856553227)
,p_db_column_name=>'CODUBICACION'
,p_display_order=>100
,p_column_identifier=>'H'
,p_column_label=>unistr('Ubicaci\00F3n')
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
,p_updated_on=>wwv_flow_imp.dz('20260209171200Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(208896832415553228)
,p_db_column_name=>'CODCUSTODIO'
,p_display_order=>110
,p_column_identifier=>'I'
,p_column_label=>'Custodio'
,p_column_type=>'STRING'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_heading_alignment=>'LEFT'
,p_rpt_named_lov=>wwv_flow_imp.id(336564499940306120)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
,p_updated_on=>wwv_flow_imp.dz('20260209171315Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(341504154809855530)
,p_db_column_name=>'DESCRIPCION2'
,p_display_order=>130
,p_column_identifier=>'M'
,p_column_label=>'Descripcion 2'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20260203063930Z')
,p_updated_on=>wwv_flow_imp.dz('20260203063930Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(341504230839855531)
,p_db_column_name=>'DESCRIPCION3'
,p_display_order=>140
,p_column_identifier=>'N'
,p_column_label=>'Descripcion 3'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20260203063930Z')
,p_updated_on=>wwv_flow_imp.dz('20260203063930Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(349044088212138614)
,p_db_column_name=>'CODERP'
,p_display_order=>150
,p_column_identifier=>'P'
,p_column_label=>unistr('C\00F3d. ERP')
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20260209170934Z')
,p_updated_on=>wwv_flow_imp.dz('20260209170959Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(209083770968666211)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'1030625'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'SELECCION:CODACTIVO:CODCATEGORIA:CODSUBCATEGORIA:DESCRIPCION3:CODUBICACION:CODCUSTODIO:'
,p_updated_on=>wwv_flow_imp.dz('20260326201449Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(210359059677899944)
,p_plug_name=>'Barra de acciones'
,p_region_template_options=>'#DEFAULT#:t-Form--stretchInputs'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(38289497777120142)
,p_plug_display_sequence=>1
,p_location=>null
,p_menu_id=>wwv_flow_imp.id(37761271469106475)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(37860983999106559)
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(210359981609899953)
,p_plug_name=>unistr('Detalle de asignaci\00F3n')
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(95503811913299190)
,p_plug_display_sequence=>51
,p_location=>null
,p_ai_enabled=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
,p_updated_on=>wwv_flow_imp.dz('20260326152336Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(210360089817899954)
,p_plug_name=>unistr('Asignaci\00F3n')
,p_parent_plug_id=>wwv_flow_imp.id(210359981609899953)
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(38289867500120143)
,p_plug_display_sequence=>40
,p_plug_display_point=>'SUB_REGIONS'
,p_location=>null
,p_ai_enabled=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
,p_updated_on=>wwv_flow_imp.dz('20260320175209Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(398586648066320606)
,p_plug_name=>'Ocultos'
,p_region_name=>'regOcultos'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(38289867500120143)
,p_plug_display_sequence=>11
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
,p_created_on=>wwv_flow_imp.dz('20260326152129Z')
,p_updated_on=>wwv_flow_imp.dz('20260326152130Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(398586793930320607)
,p_plug_name=>'Eliminar'
,p_parent_plug_id=>wwv_flow_imp.id(398586648066320606)
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(38289867500120143)
,p_plug_display_sequence=>60
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
,p_created_on=>wwv_flow_imp.dz('20260326152336Z')
,p_updated_on=>wwv_flow_imp.dz('20260326154318Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(398588132378320621)
,p_plug_name=>'Asignaciones en borrador y proceso'
,p_region_name=>'rg_asignaciones_borrador'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(37806762584106520)
,p_plug_display_sequence=>71
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select',
'    case',
'	    when estado = ''CREACION'' then',
'	        ''<a href="javascript:void(0);" '' ||',
unistr('	        ''onclick="if(confirm(''''\00BFDeseas eliminar este registro?'''')){'' ||'),
'	        ''$s(''''P466_ID_ELIMINAR'''','''''' || id || '''''');'' ||',
'	        ''apex.submit({request: ''''ELIMINAR_CREACION''''});'' ||',
'	        ''} return false;" title="Eliminar">'' ||',
'	        ''<span class="fa fa-trash-o" aria-hidden="true"></span></a>''',
'	    else',
'	        null',
'	end as eliminar,',
'    idaud,',
'    idact,',
'    lpad(coderp, 8, ''0'') as coderp,',
'    origen,',
'    estado,',
'    fechaasigna,',
'    codusuario,',
'    observacion',
'from t_finz_activosfijoslev',
'where 1 = 1',
'	and compania = :G_COMPANIA',
'	and usercrea = :app_user',
'	and origen   = ''ASIGNACION''',
'	-- and estado in (''CREACION'', ''PENDIENTE'')',
'	and estado in (''CREACION'')',
'order by id desc'))
,p_plug_source_type=>'NATIVE_IR'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
,p_created_on=>wwv_flow_imp.dz('20260326154718Z')
,p_updated_on=>wwv_flow_imp.dz('20260326181410Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(398588396766320623)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'DDELACRUZ'
,p_internal_uid=>398588396766320623
,p_created_on=>wwv_flow_imp.dz('20260326154718Z')
,p_updated_on=>wwv_flow_imp.dz('20260326181410Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(398588417078320624)
,p_db_column_name=>'ELIMINAR'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'-'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20260326154718Z')
,p_updated_on=>wwv_flow_imp.dz('20260326154718Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(398588528845320625)
,p_db_column_name=>'IDAUD'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Idaud'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_created_on=>wwv_flow_imp.dz('20260326154718Z')
,p_updated_on=>wwv_flow_imp.dz('20260326154718Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(398588685404320626)
,p_db_column_name=>'IDACT'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'ID Act.'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_created_on=>wwv_flow_imp.dz('20260326154718Z')
,p_updated_on=>wwv_flow_imp.dz('20260326155453Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(398588712036320627)
,p_db_column_name=>'CODERP'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>unistr('C\00F3d. ERP')
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20260326154718Z')
,p_updated_on=>wwv_flow_imp.dz('20260326155504Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(398588819319320628)
,p_db_column_name=>'ORIGEN'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Origen'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_created_on=>wwv_flow_imp.dz('20260326154718Z')
,p_updated_on=>wwv_flow_imp.dz('20260326154718Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(398588914501320629)
,p_db_column_name=>'ESTADO'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'Estado'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20260326154718Z')
,p_updated_on=>wwv_flow_imp.dz('20260326154718Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(398589063794320630)
,p_db_column_name=>'FECHAASIGNA'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>'Fecha Asigna'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20260326154718Z')
,p_updated_on=>wwv_flow_imp.dz('20260326154718Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(398589149432320631)
,p_db_column_name=>'CODUSUARIO'
,p_display_order=>80
,p_column_identifier=>'H'
,p_column_label=>'Responsable'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20260326154718Z')
,p_updated_on=>wwv_flow_imp.dz('20260326154718Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(398589292661320632)
,p_db_column_name=>'OBSERVACION'
,p_display_order=>90
,p_column_identifier=>'I'
,p_column_label=>unistr('Observaci\00F3n')
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20260326154718Z')
,p_updated_on=>wwv_flow_imp.dz('20260326154718Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(405821422394443561)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'4058215'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'ELIMINAR:IDAUD:IDACT:CODERP:ORIGEN:ESTADO:FECHAASIGNA:CODUSUARIO:OBSERVACION'
,p_created_on=>wwv_flow_imp.dz('20260326155415Z')
,p_updated_on=>wwv_flow_imp.dz('20260326155415Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(106043649199912652)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(210359059677899944)
,p_button_name=>'CANCEL'
,p_button_static_id=>'btnRetornar'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860056812106557)
,p_button_image_alt=>'Cancel'
,p_button_position=>'ABOVE_BOX'
,p_button_alignment=>'LEFT'
,p_button_redirect_url=>'f?p=&APP_ID.:460:&SESSION.::&DEBUG.:::'
,p_icon_css_classes=>'fa-arrow-left'
,p_updated_on=>wwv_flow_imp.dz('20260326161735Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(106044442139912652)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(210359059677899944)
,p_button_name=>'SAVE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860056812106557)
,p_button_image_alt=>'Grabar'
,p_button_position=>'ABOVE_BOX'
,p_button_alignment=>'RIGHT'
,p_button_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select 1',
'from data.t_finz_activosfijoslev',
'where 1 = 1',
'	and compania = :g_compania',
'	and origen   = ''ASIGNACION''',
'	and estado   = ''CREACION''',
'	and usercrea = :app_user'))
,p_button_condition_type=>'EXISTS'
,p_icon_css_classes=>'fa-save'
,p_updated_on=>wwv_flow_imp.dz('20260422210825Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(106050472418912660)
,p_button_sequence=>50
,p_button_plug_id=>wwv_flow_imp.id(210360089817899954)
,p_button_name=>'AGREGAR'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860056812106557)
,p_button_image_alt=>'Agregar'
,p_button_position=>'ABOVE_BOX'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-plus'
,p_updated_on=>wwv_flow_imp.dz('20260326174930Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(208895793782553213)
,p_name=>'P466_COMPANIA'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(398586648066320606)
,p_item_default=>':G_COMPANIA'
,p_item_default_type=>'EXPRESSION'
,p_item_default_language=>'PLSQL'
,p_prompt=>'New'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_updated_on=>wwv_flow_imp.dz('20260326152348Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(208895952294553214)
,p_name=>'P466_TIPO'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(208193341950278461)
,p_prompt=>'Tipo: '
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'LOV_AFI_TIPO'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select DRDL01 D, DRKY R',
'from vt_jde_udcjde where drsy = ''12'' and drrt = ''21''',
'and DRKY is not null',
'order by 2;'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'Seleccione'
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'SUBMIT'
,p_attribute_03=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20260203063632Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(208896030042553215)
,p_name=>'P466_CATEGORIA'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(208193341950278461)
,p_prompt=>unistr('Categor\00EDa: ')
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select DRKY||''-''||DRDL01 D, DRKY R',
'from vt_jde_udcjde where drsy = ''12'' and drrt = ''22''',
'and substr(DRKY,1,1)=:P466_TIPO',
'order by 2;'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'Seleccione'
,p_lov_cascade_parent_items=>'P466_TIPO'
,p_ajax_optimize_refresh=>'Y'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'SUBMIT'
,p_attribute_03=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20260203063632Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(208896131752553216)
,p_name=>'P466_SUBCATEGORIA'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(208193341950278461)
,p_prompt=>unistr('Subcategor\00EDa: ')
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select DRKY||''-''||DRDL01 D, DRKY R',
'from vt_jde_udcjde where drsy = ''12'' and drrt = ''23''',
'and substr(DRKY,1,4)=:P466_CATEGORIA',
'order by 2;'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'Seleccione'
,p_lov_cascade_parent_items=>'P466_CATEGORIA'
,p_ajax_optimize_refresh=>'Y'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'SUBMIT'
,p_attribute_03=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20260326174146Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(208897842814553233)
,p_name=>'P466_SINSELECCION'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(398586648066320606)
,p_prompt=>'New'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_updated_on=>wwv_flow_imp.dz('20260326161327Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(210389238846900000)
,p_name=>'P466_RESPONSABLE'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(210360089817899954)
,p_prompt=>'Usuario Responsable: '
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'LOV_APEX_USUARIO'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select case',
'	when trim(apellidos) is null then trim(nombres)',
'	when trim(nombres) is null then trim(apellidos)',
'	else trim(apellidos)||'' ''||trim(nombres) end d',
'	, nombreusuario r',
'from data.vt_corp_usuario',
'where 1 = 1',
'order by 1'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'Seleccione'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'NONE'
,p_updated_on=>wwv_flow_imp.dz('20260326180734Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(210389253999900001)
,p_name=>'P466_FECHALIMITE'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(210360089817899954)
,p_item_default=>'trunc(sysdate)+1'
,p_item_default_type=>'EXPRESSION'
,p_item_default_language=>'PLSQL'
,p_prompt=>unistr('Fecha L\00EDmite: ')
,p_display_as=>'NATIVE_DATE_PICKER_APEX'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'POPUP'
,p_attribute_03=>'NONE'
,p_attribute_06=>'NONE'
,p_attribute_09=>'N'
,p_attribute_11=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20260326160709Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(210389373791900002)
,p_name=>'P466_OBSERVACIONASIGANCION'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(210360089817899954)
,p_prompt=>unistr('Observaci\00F3n: ')
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_updated_on=>wwv_flow_imp.dz('20260325212058Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(398588041652320620)
,p_name=>'P466_ID_ELIMINAR'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(398586648066320606)
,p_prompt=>'Id Eliminar'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_created_on=>wwv_flow_imp.dz('20260326154318Z')
,p_updated_on=>wwv_flow_imp.dz('20260326174254Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(398587431151320614)
,p_name=>'Agregar Asignacion'
,p_event_sequence=>90
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(106050472418912660)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
,p_created_on=>wwv_flow_imp.dz('20260326153056Z')
,p_updated_on=>wwv_flow_imp.dz('20260326175743Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(398589712061320637)
,p_event_id=>wwv_flow_imp.id(398587431151320614)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'var lineas = '''';',
'',
'document.querySelectorAll(''.chkF01'').forEach(function (seleccion) {',
'    if (seleccion.checked) {',
'        if (lineas === '''') {',
'            lineas = seleccion.value;',
'        } else {',
'            lineas = lineas + '','' + seleccion.value;',
'        }',
'    }',
'});',
'',
'apex.item(''P466_SINSELECCION'').setValue(lineas);',
'console.log(''P466_SINSELECCION recalculado antes de agregar: '' + lineas);'))
,p_created_on=>wwv_flow_imp.dz('20260326170210Z')
,p_updated_on=>wwv_flow_imp.dz('20260326170210Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(398587519902320615)
,p_event_id=>wwv_flow_imp.id(398587431151320614)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    v_registros number;',
'begin',
'    if trim(:P466_SINSELECCION) is null then',
'        raise_application_error(-20001, ''Debes seleccionar al menos un activo.'');',
'    end if;',
'',
'    if :P466_RESPONSABLE is null then',
'        raise_application_error(-20002, ''Debes seleccionar un responsable.'');',
'    end if;',
'',
'    if :P466_FECHALIMITE is null then',
unistr('        raise_application_error(-20003, ''Debes ingresar la fecha l\00EDmite.'');'),
'    end if;',
'',
'    insert into t_finz_activosfijoslev',
'    (',
'        usercrea,',
'        fechcrea,',
'        compania,',
'        idact,',
'        coderp,',
'        origen,',
'        estado,',
'        fechaasigna,',
'        codusuario,',
'        observacion',
'    )',
'    select',
'        :APP_USER,',
'        sysdate,',
'        :G_COMPANIA,',
'        a.id,',
'        a.coderp,',
'        ''ASIGNACION'',',
'        ''CREACION'',',
'        :P466_FECHALIMITE,',
'        :P466_RESPONSABLE,',
'        :P466_OBSERVACIONASIGANCION',
'    from t_finz_activosfijos a',
'         join table(apex_string.split(:P466_SINSELECCION, '','')) s',
'           on trim(s.column_value) = to_char(a.id)',
'    where 1 = 1',
'      and a.compania = :G_COMPANIA',
'      and not exists',
'      (',
'          select 1',
'          from t_finz_activosfijoslev l',
'          where 1 = 1',
'            and l.compania = :G_COMPANIA',
'            and l.idact    = a.id',
'            and l.origen   = ''ASIGNACION''',
'            and l.estado in (''CREACION'', ''PENDIENTE'')',
'      );',
'',
'    v_registros := sql%rowcount;',
'',
'    if v_registros = 0 then',
unistr('        raise_application_error(-20004, ''No se agregaron registros. Es posible que ya est\00E9n en CREACION o PENDIENTE.'');'),
'    end if;',
'end;'))
,p_attribute_02=>'P466_SINSELECCION,P466_RESPONSABLE,P466_FECHALIMITE,P466_OBSERVACIONASIGANCION'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
,p_created_on=>wwv_flow_imp.dz('20260326153057Z')
,p_updated_on=>wwv_flow_imp.dz('20260326170210Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(398587670446320616)
,p_event_id=>wwv_flow_imp.id(398587431151320614)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P466_SINSELECCION'
,p_attribute_01=>'STATIC_ASSIGNMENT'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
,p_created_on=>wwv_flow_imp.dz('20260326153057Z')
,p_updated_on=>wwv_flow_imp.dz('20260326170210Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(398589619511320636)
,p_event_id=>wwv_flow_imp.id(398587431151320614)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
':P466_RESPONSABLE := null;',
':P466_OBSERVACIONASIGANCION := null;',
':P466_FECHALIMITE := trunc(sysdate) + 1;'))
,p_attribute_03=>'P466_RESPONSABLE,P466_OBSERVACIONASIGANCION,P466_FECHALIMITE'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
,p_created_on=>wwv_flow_imp.dz('20260326160627Z')
,p_updated_on=>wwv_flow_imp.dz('20260326170210Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(398587968533320619)
,p_event_id=>wwv_flow_imp.id(398587431151320614)
,p_event_result=>'TRUE'
,p_action_sequence=>60
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'apex.region("rg_activos_seleccionables").refresh();',
'apex.region("rg_asignaciones_borrador").refresh();',
'',
'$("#SAVE, #SAVE span.t-Button-label").closest("button, a").show();',
'',
'apex.message.showPageSuccess(''Registros agregados en estado CREACION.'');'))
,p_created_on=>wwv_flow_imp.dz('20260326153130Z')
,p_updated_on=>wwv_flow_imp.dz('20260326175743Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(398589565485320635)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Eliminar asignacion en creacion'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'    if :P466_ID_ELIMINAR is null then',
unistr('        raise_application_error(-20021, ''No se recibi\00F3 el identificador del registro a eliminar.'');'),
'    end if;',
'',
'    delete from t_finz_activosfijoslev',
'    where 1 = 1',
'		and compania = :G_COMPANIA',
'		and id       = :P466_ID_ELIMINAR',
'		and origen   = ''ASIGNACION''',
'		and estado   = ''CREACION'';',
'',
'    if sql%rowcount = 0 then',
'        raise_application_error(-20022, ''Solo se pueden eliminar registros en estado CREACION.'');',
'    end if;',
'',
'    :P466_ID_ELIMINAR := null;',
'',
'    apex_application.g_print_success_message := ''Registro eliminado correctamente.'';',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>'ELIMINAR_CREACION'
,p_process_when_type=>'REQUEST_EQUALS_CONDITION'
,p_internal_uid=>398589565485320635
,p_created_on=>wwv_flow_imp.dz('20260326155141Z')
,p_updated_on=>wwv_flow_imp.dz('20260326174254Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(106059424714912667)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>unistr('Grabar Asignaci\00F3n')
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'	v_registros number := 0;',
'begin',
'	update data.t_finz_activosfijoslev',
'		set estado = ''PENDIENTE''',
'	where 1 = 1',
'		and compania = :G_COMPANIA',
'		and origen   = ''ASIGNACION''',
'		and estado   = ''CREACION''',
'		and usercrea = :APP_USER;',
'',
'	v_registros := sql%rowcount;',
'',
'	if v_registros = 0 then',
'		raise_application_error(-20031, ''No existen registros en estado CREACION para grabar.'');',
'	end if;',
'',
'	data.pk_finz_activosfijos.sp_notificar(',
'		p_compania => :G_COMPANIA,',
'		p_usuario  => :APP_USER,',
'		p_opcion   => ''ASIGNACION'',',
'		p_idactivo => null',
'	);',
'',
unistr('	apex_application.g_print_success_message := ''Registros grabados correctamente. Se actualizaron a estado PENDIENTE y se envi\00F3 la notificaci\00F3n.'';'),
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(106044442139912652)
,p_internal_uid=>106059424714912667
,p_updated_on=>wwv_flow_imp.dz('20260326204609Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp.component_end;
end;
/
