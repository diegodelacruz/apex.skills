prompt --application/pages/page_00471
begin
--   Manifest
--     PAGE: 00471
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>109
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_page.create_page(
 p_id=>471
,p_name=>'Activos Fijos - Editar Levantamiento'
,p_alias=>'ACTIVOS-FIJOS-EDITAR-LEVANTAMIENTO'
,p_step_title=>'Activos Fijos - Editar Levantamiento'
,p_autocomplete_on_off=>'OFF'
,p_javascript_code_onload=>'$(regOcultos).hide();'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'16'
,p_created_on=>wwv_flow_imp.dz('20260518033503Z')
,p_last_updated_on=>wwv_flow_imp.dz('20260522164807Z')
,p_created_by=>'DDELACRUZ'
,p_last_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(465820591375129001)
,p_plug_name=>'Ocultos'
,p_region_name=>'regOcultos'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(38289867500120143)
,p_plug_display_sequence=>10
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
,p_created_on=>wwv_flow_imp.dz('20260518033712Z')
,p_updated_on=>wwv_flow_imp.dz('20260518045122Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(465820653215129002)
,p_plug_name=>'Datos'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(38289867500120143)
,p_plug_display_sequence=>20
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
,p_created_on=>wwv_flow_imp.dz('20260518033712Z')
,p_updated_on=>wwv_flow_imp.dz('20260518033712Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(472291639626936002)
,p_plug_name=>unistr('Revisi\00F3n')
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(38289867500120143)
,p_plug_display_sequence=>30
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
,p_created_on=>wwv_flow_imp.dz('20260522070655Z')
,p_updated_on=>wwv_flow_imp.dz('20260522071959Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(600051480391691283)
,p_plug_name=>'Barra de acciones'
,p_region_template_options=>'#DEFAULT#:t-Form--stretchInputs'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(38289497777120142)
,p_plug_display_sequence=>40
,p_plug_display_point=>'REGION_POSITION_01'
,p_location=>null
,p_menu_id=>wwv_flow_imp.id(37761271469106475)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(37860983999106559)
,p_ai_enabled=>false
,p_created_on=>wwv_flow_imp.dz('20260518045218Z')
,p_updated_on=>wwv_flow_imp.dz('20260518045218Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(465941715044590409)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(600051480391691283)
,p_button_name=>'CANCEL'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860056812106557)
,p_button_image_alt=>'Cancel'
,p_button_position=>'TOP'
,p_button_alignment=>'LEFT'
,p_button_redirect_url=>'f?p=&APP_ID.:462:&SESSION.::&DEBUG.:462::'
,p_icon_css_classes=>'fa-arrow-left'
,p_created_on=>wwv_flow_imp.dz('20260518045218Z')
,p_updated_on=>wwv_flow_imp.dz('20260518045311Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(465820873898129004)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(600051480391691283)
,p_button_name=>'SAVE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860056812106557)
,p_button_image_alt=>'Guardar'
,p_button_position=>'TOP'
,p_button_alignment=>'RIGHT'
,p_icon_css_classes=>'fa-save'
,p_created_on=>wwv_flow_imp.dz('20260518033736Z')
,p_updated_on=>wwv_flow_imp.dz('20260518051720Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(465821811631129014)
,p_name=>'P471_IDACT'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(465820591375129001)
,p_prompt=>'Idact'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_created_on=>wwv_flow_imp.dz('20260518035013Z')
,p_updated_on=>wwv_flow_imp.dz('20260518035013Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(472291792286936003)
,p_name=>'P471_REVISADO'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(472291639626936002)
,p_prompt=>'Encontrado'
,p_display_as=>'NATIVE_RADIOGROUP'
,p_named_lov=>'LOV_SI_NO_SN'
,p_lov=>'.'||wwv_flow_imp.id(341484489208595861)||'.'
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'2'
,p_attribute_02=>'NONE'
,p_created_on=>wwv_flow_imp.dz('20260522070655Z')
,p_updated_on=>wwv_flow_imp.dz('20260522163819Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(472291871525936004)
,p_name=>'P471_DESCRIPCIONREVISION'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(472291639626936002)
,p_prompt=>unistr('Descripci\00F3n')
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_created_on=>wwv_flow_imp.dz('20260522070733Z')
,p_updated_on=>wwv_flow_imp.dz('20260522071959Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(472292351964936009)
,p_name=>'P471_IDLEV'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(465820591375129001)
,p_prompt=>'Idlev'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_created_on=>wwv_flow_imp.dz('20260522071403Z')
,p_updated_on=>wwv_flow_imp.dz('20260522071403Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(599945994664307935)
,p_name=>'P471_CODERP'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(465820653215129002)
,p_prompt=>unistr('C\00F3d. ERP')
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
,p_created_on=>wwv_flow_imp.dz('20260518034824Z')
,p_updated_on=>wwv_flow_imp.dz('20260518042745Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(599946476509307938)
,p_name=>'P471_CODACTIVO'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(465820653215129002)
,p_prompt=>unistr('C\00F3d. Activo')
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
,p_created_on=>wwv_flow_imp.dz('20260518034824Z')
,p_updated_on=>wwv_flow_imp.dz('20260518042745Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(599946874539307940)
,p_name=>'P471_DESCRIPCION1'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(465820653215129002)
,p_prompt=>unistr('Descripci\00F3n 1: ')
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
,p_created_on=>wwv_flow_imp.dz('20260518034824Z')
,p_updated_on=>wwv_flow_imp.dz('20260518042746Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(599947255556307942)
,p_name=>'P471_DESCRIPCION2'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_imp.id(465820653215129002)
,p_prompt=>unistr('Descripci\00F3n 2: ')
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
,p_created_on=>wwv_flow_imp.dz('20260518034824Z')
,p_updated_on=>wwv_flow_imp.dz('20260518042746Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(599947645205307945)
,p_name=>'P471_DESCRIPCION3'
,p_is_required=>true
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_imp.id(465820653215129002)
,p_prompt=>unistr('Descripci\00F3n 3: ')
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_attribute_06=>'UPPER'
,p_created_on=>wwv_flow_imp.dz('20260518034824Z')
,p_updated_on=>wwv_flow_imp.dz('20260518042746Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(599948019525307947)
,p_name=>'P471_CODTIPO'
,p_item_sequence=>120
,p_item_plug_id=>wwv_flow_imp.id(465820653215129002)
,p_prompt=>'Tipo: '
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'LOV_AFI_TIPO'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select DRDL01 D, DRKY R',
'from vt_jde_udcjde where drsy = ''12'' and drrt = ''21''',
'and DRKY is not null',
'order by 2;'))
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_read_only_when_type=>'ALWAYS'
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'NONE'
,p_created_on=>wwv_flow_imp.dz('20260518034824Z')
,p_updated_on=>wwv_flow_imp.dz('20260518054710Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(599948413577307950)
,p_name=>'P471_CODCATEGORIA'
,p_item_sequence=>130
,p_item_plug_id=>wwv_flow_imp.id(465820653215129002)
,p_prompt=>unistr('Categor\00EDa: ')
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'LOV_AFI_CATEGORIA'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select DRDL01 D, DRKY R',
'from vt_jde_udcjde@datadl where drsy = ''12'' and drrt = ''22''',
'order by 2;'))
,p_cHeight=>1
,p_read_only_when_type=>'ALWAYS'
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'NONE'
,p_created_on=>wwv_flow_imp.dz('20260518034824Z')
,p_updated_on=>wwv_flow_imp.dz('20260518054710Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(599948733384307952)
,p_name=>'P471_CODSUBCATEGORIA'
,p_item_sequence=>140
,p_item_plug_id=>wwv_flow_imp.id(465820653215129002)
,p_prompt=>unistr('Subcategor\00EDa: ')
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'LOV_AFI_SUBCATEGORIA'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select DRDL01 D, DRKY R',
'from vt_jde_udcjde@datadl where drsy = ''12'' and drrt = ''23''',
'order by 2;'))
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_read_only_when_type=>'ALWAYS'
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'NONE'
,p_created_on=>wwv_flow_imp.dz('20260518034824Z')
,p_updated_on=>wwv_flow_imp.dz('20260518054710Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(599949183370307954)
,p_name=>'P471_FECHACOMPRA'
,p_item_sequence=>180
,p_item_plug_id=>wwv_flow_imp.id(465820653215129002)
,p_prompt=>'Fecha Compra: '
,p_format_mask=>'dd/mm/yyyy'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
,p_created_on=>wwv_flow_imp.dz('20260518034824Z')
,p_updated_on=>wwv_flow_imp.dz('20260518042746Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(599949524225307957)
,p_name=>'P471_FECHAINIDEP'
,p_item_sequence=>200
,p_item_plug_id=>wwv_flow_imp.id(465820653215129002)
,p_prompt=>unistr('Fecha Ini. Depreciaci\00F3n: ')
,p_format_mask=>'dd/mm/yyyy'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
,p_created_on=>wwv_flow_imp.dz('20260518034824Z')
,p_updated_on=>wwv_flow_imp.dz('20260518042746Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(599949981999307960)
,p_name=>'P471_FECHAFINDEP'
,p_item_sequence=>210
,p_item_plug_id=>wwv_flow_imp.id(465820653215129002)
,p_prompt=>unistr('Fecha Fin Depreciaci\00F3n: ')
,p_format_mask=>'dd/mm/yyyy'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
,p_created_on=>wwv_flow_imp.dz('20260518034824Z')
,p_updated_on=>wwv_flow_imp.dz('20260518042746Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(599950290356307962)
,p_name=>'P471_COSTO'
,p_item_sequence=>160
,p_item_plug_id=>wwv_flow_imp.id(465820653215129002)
,p_prompt=>'Costo: '
,p_format_mask=>'FML999G999G999G999G990D00'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
,p_created_on=>wwv_flow_imp.dz('20260518034824Z')
,p_updated_on=>wwv_flow_imp.dz('20260518042746Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(599951911420307973)
,p_name=>'P471_CODUBICACION'
,p_item_sequence=>250
,p_item_plug_id=>wwv_flow_imp.id(465820653215129002)
,p_prompt=>unistr('C\00F3d Ubicaci\00F3n: ')
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>32
,p_cMaxlength=>50
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'NONE'
,p_created_on=>wwv_flow_imp.dz('20260518034824Z')
,p_updated_on=>wwv_flow_imp.dz('20260518042746Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(599952288729307975)
,p_name=>'P471_FECHAUBICACION'
,p_item_sequence=>240
,p_item_plug_id=>wwv_flow_imp.id(465820653215129002)
,p_item_default=>'to_char(sysdate,''dd/mm/yyyy'')'
,p_item_default_type=>'EXPRESSION'
,p_item_default_language=>'PLSQL'
,p_prompt=>unistr('Fecha Ubicaci\00F3n: ')
,p_display_as=>'NATIVE_DATE_PICKER_APEX'
,p_cSize=>32
,p_cMaxlength=>255
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'POPUP'
,p_attribute_03=>'NONE'
,p_attribute_06=>'NONE'
,p_attribute_09=>'N'
,p_attribute_11=>'N'
,p_attribute_12=>'TODAY-BUTTON'
,p_attribute_13=>'VISIBLE'
,p_attribute_15=>'IMAGE'
,p_created_on=>wwv_flow_imp.dz('20260518034824Z')
,p_updated_on=>wwv_flow_imp.dz('20260518042746Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(599953138320307980)
,p_name=>'P471_CODCUSTODIO'
,p_item_sequence=>260
,p_item_plug_id=>wwv_flow_imp.id(465820653215129002)
,p_prompt=>'Custodio: '
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'LOV_CODDIRECCIONUSUARIO'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select coderp, trim(apellidos)||'' ''||trim(nombres) colaborador',
'from data.vt_corp_usuario',
'where compania = :g_compania and nvl(coderp,0) > 0'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'Seleccione'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'NONE'
,p_created_on=>wwv_flow_imp.dz('20260518034824Z')
,p_updated_on=>wwv_flow_imp.dz('20260518042746Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(599953581918307983)
,p_name=>'P471_FECHAASIGNACION'
,p_item_sequence=>190
,p_item_plug_id=>wwv_flow_imp.id(465820653215129002)
,p_prompt=>unistr('Fecha Asignaci\00F3n: ')
,p_format_mask=>'dd/mm/yyyy'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
,p_created_on=>wwv_flow_imp.dz('20260518034824Z')
,p_updated_on=>wwv_flow_imp.dz('20260518042746Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(599953913607307985)
,p_name=>'P471_CENTROCOSTO'
,p_item_sequence=>230
,p_item_plug_id=>wwv_flow_imp.id(465820653215129002)
,p_prompt=>'Centro de Costo:'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>32
,p_cMaxlength=>12
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'NONE'
,p_created_on=>wwv_flow_imp.dz('20260518034824Z')
,p_updated_on=>wwv_flow_imp.dz('20260518042746Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(599955107753307993)
,p_name=>'P471_VALORRESIDUAL'
,p_item_sequence=>170
,p_item_plug_id=>wwv_flow_imp.id(465820653215129002)
,p_prompt=>'Valor Residual'
,p_format_mask=>'FML999G999G999G999G990D00'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
,p_created_on=>wwv_flow_imp.dz('20260518034824Z')
,p_updated_on=>wwv_flow_imp.dz('20260518042746Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(599957898484308010)
,p_name=>'P471_NOTAS'
,p_item_sequence=>300
,p_item_plug_id=>wwv_flow_imp.id(465820653215129002)
,p_prompt=>'Notas: '
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>60
,p_cMaxlength=>1000
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_created_on=>wwv_flow_imp.dz('20260518034824Z')
,p_updated_on=>wwv_flow_imp.dz('20260518042747Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(864417889903527583)
,p_name=>'P471_OBSADICIONA1'
,p_item_sequence=>270
,p_item_plug_id=>wwv_flow_imp.id(465820653215129002)
,p_prompt=>'Obs. Adicional 1'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_cMaxlength=>100
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_created_on=>wwv_flow_imp.dz('20260518034824Z')
,p_updated_on=>wwv_flow_imp.dz('20260518042746Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(864418179597527585)
,p_name=>'P471_OBSADICIONA2'
,p_item_sequence=>280
,p_item_plug_id=>wwv_flow_imp.id(465820653215129002)
,p_prompt=>'Obs. Adicional 2'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_cMaxlength=>100
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_created_on=>wwv_flow_imp.dz('20260518034824Z')
,p_updated_on=>wwv_flow_imp.dz('20260518042746Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(864418197173527586)
,p_name=>'P471_OBSADICIONA3'
,p_item_sequence=>290
,p_item_plug_id=>wwv_flow_imp.id(465820653215129002)
,p_prompt=>'Obs. Adicional 3'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_cMaxlength=>100
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_created_on=>wwv_flow_imp.dz('20260518034824Z')
,p_updated_on=>wwv_flow_imp.dz('20260518042747Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(472291905846936005)
,p_name=>'Revisado'
,p_event_sequence=>10
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P471_REVISADO'
,p_condition_element=>'P471_REVISADO'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'S'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
,p_created_on=>wwv_flow_imp.dz('20260522070900Z')
,p_updated_on=>wwv_flow_imp.dz('20260522070901Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(472292035976936006)
,p_event_id=>wwv_flow_imp.id(472291905846936005)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P471_DESCRIPCIONREVISION'
,p_created_on=>wwv_flow_imp.dz('20260522070900Z')
,p_updated_on=>wwv_flow_imp.dz('20260522070900Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(472292135280936007)
,p_event_id=>wwv_flow_imp.id(472291905846936005)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P471_DESCRIPCIONREVISION'
,p_created_on=>wwv_flow_imp.dz('20260522070901Z')
,p_updated_on=>wwv_flow_imp.dz('20260522070901Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(465913902753431804)
,p_process_sequence=>10
,p_process_point=>'AFTER_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'SetUp'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'v_activofijo	data.t_finz_activosfijos%rowtype;',
'v_activoleva	data.t_finz_activosfijoslev%rowtype;',
'v_bandera1		number;',
'begin',
'	begin',
'		select *',
'		into v_activofijo',
'		from data.t_finz_activosfijos',
'		where id = :p471_idact;',
'',
'		exception when others then v_bandera1 := 0;',
'	end;',
'',
'	begin',
'		:p471_coderp			:= v_activofijo.coderp;',
'		:p471_codactivo			:= v_activofijo.codactivo;',
'		:p471_descripcion1		:= v_activofijo.descripcion1;',
'		:p471_descripcion2		:= v_activofijo.descripcion2;',
'		:p471_descripcion3		:= v_activofijo.descripcion3;',
'		:p471_codtipo			:= v_activofijo.codtipo;',
'		:p471_codcategoria		:= v_activofijo.codcategoria;',
'		:p471_codsubcategoria	:= v_activofijo.codsubcategoria;',
'		:p471_costo				:= v_activofijo.costo;',
'		:p471_valorresidual		:= v_activofijo.valorresidual;',
'		:p471_fechacompra		:= v_activofijo.fechacompra;',
'		:p471_fechaasignacion	:= v_activofijo.fechaasignacion;',
'		:p471_fechainidep		:= v_activofijo.fechainidep;',
'		:p471_fechafindep		:= v_activofijo.fechafindep;',
'		:p471_centrocosto		:= v_activofijo.centrocosto;',
'		:p471_fechaubicacion	:= v_activofijo.fechaubicacion;',
'		:p471_codubicacion		:= v_activofijo.codubicacion;',
'		:p471_codcustodio		:= v_activofijo.codcustodio;',
'		:p471_obsadiciona1		:= v_activofijo.obsadiciona1;',
'		:p471_obsadiciona2		:= v_activofijo.obsadiciona2;',
'		:p471_obsadiciona3		:= v_activofijo.obsadiciona3;',
'		:p471_notas				:= v_activofijo.notas;',
'	end;',
'',
'	begin',
'		select *',
'		into v_activoleva',
'		from data.t_finz_activosfijoslev',
'		where id = :p471_idlev;',
'',
'		:p471_revisado := v_activoleva.revisado;',
'		:p471_descripcionrevision := v_activoleva.descripcionrevision;',
'',
'		exception when others then :p471_revisado := null; :p471_descripcionrevision := null;',
'	end;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>465913902753431804
,p_created_on=>wwv_flow_imp.dz('20260518044523Z')
,p_updated_on=>wwv_flow_imp.dz('20260522072416Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(465914139197431806)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Actualizar'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'	update data.t_finz_activosfijos set',
'		descripcion3		= :p471_descripcion3',
'		, centrocosto		= :p471_centrocosto',
'		, fechaubicacion	= :p471_fechaubicacion',
'		, codubicacion		= :p471_codubicacion',
'		, codcustodio		= :p471_codcustodio',
'		, obsadiciona1		= :p471_obsadiciona1',
'		, obsadiciona2		= :p471_obsadiciona2',
'		, obsadiciona3		= :p471_obsadiciona3',
'		, notas				= :p471_notas',
'	where id = :p471_idact;',
'',
'	update data.t_finz_activosfijoslev x set',
'		x.revisado				= trim(:p471_revisado),',
'		x.descripcionrevision	= substr(trim(:p471_descripcionrevision),1,999)',
'	where id = :p471_idlev;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_process_error_message=>unistr('No se pudo actualizar el registro. Cont\00E1ctese con el administrador.')
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_success_message=>'Datos Actualizados'
,p_internal_uid=>465914139197431806
,p_created_on=>wwv_flow_imp.dz('20260518051420Z')
,p_updated_on=>wwv_flow_imp.dz('20260522164807Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp.component_end;
end;
/
