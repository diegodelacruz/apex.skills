prompt --application/pages/page_00224
begin
--   Manifest
--     PAGE: 00224
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>109
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_page.create_page(
 p_id=>224
,p_name=>'Maintenance of Standards'
,p_step_title=>'Maintenance of Standards'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_page_component_map=>'18'
,p_created_on=>wwv_flow_imp.dz('20230705164635Z')
,p_last_updated_on=>wwv_flow_imp.dz('20220425162458Z')
,p_last_updated_by=>'EZAMBRANO'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(96297201250404211)
,p_plug_name=>'Barra de acciones'
,p_region_template_options=>'#DEFAULT#:t-Form--stretchInputs'
,p_plug_template=>wwv_flow_imp.id(38289497777120142)
,p_plug_display_sequence=>1
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'REGION_POSITION_01'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(124581308576374193)
,p_plug_name=>'Buscar'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(38289867500120143)
,p_plug_display_sequence=>20
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(186399237860670244)
,p_plug_name=>unistr('Reporte de Est\00E1ndares')
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(37806762584106520)
,p_plug_display_sequence=>30
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT SUBSTR(CODIGOESTANDAR, 2, 2) ORDEN, ',
'CODEMPRESA,',
'CODIGOESTANDAR ,',
'MAQUINA ,',
'VALOR , ',
'MES , ',
'ANIO, ',
'AUDITORIAUSUARIO ,',
'AUDITORIAFECHA  FROM T_ZUSA_ESTANDARESMAQ',
'ORDER BY 1'))
,p_plug_source_type=>'NATIVE_IR'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(186399338489670244)
,p_name=>unistr('Reporte de Costos Producci\00F3n ')
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'EZAMBRANO'
,p_internal_uid=>186399338489670244
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(63114358039701262)
,p_db_column_name=>'CODEMPRESA'
,p_display_order=>10
,p_column_identifier=>'AM'
,p_column_label=>'Codempresa'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(63114726213701263)
,p_db_column_name=>'CODIGOESTANDAR'
,p_display_order=>20
,p_column_identifier=>'AN'
,p_column_label=>'Variable'
,p_column_type=>'STRING'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_rpt_named_lov=>wwv_flow_imp.id(108781669872424098)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(63115149675701265)
,p_db_column_name=>'MAQUINA'
,p_display_order=>30
,p_column_identifier=>'AO'
,p_column_label=>'Maquina'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(63115512449701265)
,p_db_column_name=>'VALOR'
,p_display_order=>40
,p_column_identifier=>'AP'
,p_column_label=>'Valor'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D0000'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(63115951448701266)
,p_db_column_name=>'MES'
,p_display_order=>50
,p_column_identifier=>'AQ'
,p_column_label=>'Mes'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(63116365710701266)
,p_db_column_name=>'ANIO'
,p_display_order=>60
,p_column_identifier=>'AR'
,p_column_label=>'Anio'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(63116737167701268)
,p_db_column_name=>'AUDITORIAUSUARIO'
,p_display_order=>70
,p_column_identifier=>'AS'
,p_column_label=>'Auditoriausuario'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(63117179704701268)
,p_db_column_name=>'AUDITORIAFECHA'
,p_display_order=>80
,p_column_identifier=>'AT'
,p_column_label=>'Auditoriafecha'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(63117536575701268)
,p_db_column_name=>'ORDEN'
,p_display_order=>90
,p_column_identifier=>'AU'
,p_column_label=>'Orden'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(186400044360670956)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_type=>'PIVOT'
,p_report_alias=>'631179'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'CODIGOESTANDAR:MAQUINA:VALOR:MES:ANIO:'
,p_sort_column_1=>'ORDEN'
,p_sort_direction_1=>'ASC'
,p_sort_column_2=>'CODIGOESTANDAR'
,p_sort_direction_2=>'ASC'
,p_sort_column_3=>'0'
,p_sort_direction_3=>'ASC'
,p_sort_column_4=>'0'
,p_sort_direction_4=>'ASC'
,p_sort_column_5=>'0'
,p_sort_direction_5=>'ASC'
,p_sort_column_6=>'0'
,p_sort_direction_6=>'ASC'
,p_created_on=>wwv_flow_imp.dz('20230705164635Z')
,p_updated_on=>wwv_flow_imp.dz('20230705164635Z')
,p_created_by=>'CVACA'
,p_updated_by=>'CVACA'
);
wwv_flow_imp_page.create_worksheet_pivot(
 p_id=>wwv_flow_imp.id(125376786963880546)
,p_report_id=>wwv_flow_imp.id(186400044360670956)
,p_pivot_columns=>'ANIO:MES'
,p_row_columns=>'ORDEN:MAQUINA:CODIGOESTANDAR'
,p_created_on=>wwv_flow_imp.dz('20230705164635Z')
,p_updated_on=>wwv_flow_imp.dz('20230705164635Z')
,p_created_by=>'CVACA'
,p_updated_by=>'CVACA'
);
wwv_flow_imp_page.create_worksheet_pivot_agg(
 p_id=>wwv_flow_imp.id(63118686173701268)
,p_pivot_id=>wwv_flow_imp.id(125376786963880546)
,p_display_seq=>1
,p_function_name=>'SUM'
,p_column_name=>'VALOR'
,p_db_column_name=>'PFC1'
,p_column_label=>'-'
,p_format_mask=>'999G999G999G999G990D00000'
,p_display_sum=>'N'
,p_created_on=>wwv_flow_imp.dz('20230705164635Z')
,p_updated_on=>wwv_flow_imp.dz('20230705164635Z')
,p_created_by=>'CVACA'
,p_updated_by=>'CVACA'
);
wwv_flow_imp_page.create_worksheet_pivot_sort(
 p_id=>wwv_flow_imp.id(63119033924701268)
,p_pivot_id=>wwv_flow_imp.id(125376786963880546)
,p_sort_seq=>1
,p_sort_column_name=>'ORDEN'
,p_sort_direction=>'ASC'
,p_created_on=>wwv_flow_imp.dz('20230705164635Z')
,p_updated_on=>wwv_flow_imp.dz('20230705164635Z')
,p_created_by=>'CVACA'
,p_updated_by=>'CVACA'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(63119779194701269)
,p_button_sequence=>60
,p_button_plug_id=>wwv_flow_imp.id(96297201250404211)
,p_button_name=>'GUARDAR'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860056812106557)
,p_button_image_alt=>'Guardar'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_icon_css_classes=>'fa-save'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(63120562924701273)
,p_button_sequence=>70
,p_button_plug_id=>wwv_flow_imp.id(96297201250404211)
,p_button_name=>'MODIFICAR'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860056812106557)
,p_button_image_alt=>'Modificar'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_icon_css_classes=>'fa-clipboard-edit'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(63120135984701273)
,p_button_sequence=>80
,p_button_plug_id=>wwv_flow_imp.id(96297201250404211)
,p_button_name=>'BUSCAR'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860056812106557)
,p_button_image_alt=>'Guardar'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_icon_css_classes=>'fa-search'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(63112073737701260)
,p_name=>'P224_MOTIVO'
,p_is_required=>true
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(124581308576374193)
,p_prompt=>unistr('Est\00E1ndar:')
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'LOV_MOTIVOSING'
,p_lov=>'.'||wwv_flow_imp.id(108787365326430302)||'.'
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(63112444243701260)
,p_name=>'P224_DESDE'
,p_is_required=>true
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(124581308576374193)
,p_prompt=>unistr('Per\00EDodo Act:')
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'STATIC:2020;2020,2021;2021,2022;2022,2023;2023,2024;2024,2025;2025,2026;2026,2027;2027,2028;2028,2029;2029,2030;2030'
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(63112868718701260)
,p_name=>'P224_MES_AC'
,p_is_required=>true
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(124581308576374193)
,p_prompt=>'Mes Actual:'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'STATIC:1;1,2;2,3;3,4;4,5;5,6;6,7;7,8;8,9;9,10;10,11;11,12;12'
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(63113227782701260)
,p_name=>'P224_MACHINE'
,p_is_required=>true
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(124581308576374193)
,p_prompt=>unistr('M\00E1quina:')
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'LOV_MACHINE'
,p_lov=>'.'||wwv_flow_imp.id(108799505812474951)||'.'
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(63113695082701262)
,p_name=>'P224_VALOR'
,p_is_required=>true
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(124581308576374193)
,p_item_default=>'0'
,p_prompt=>'Valor:'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(63122226864701274)
,p_validation_name=>'VALCALULO'
,p_validation_sequence=>10
,p_validation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE ',
'V_CONT NUMBER;',
'',
'BEGIN',
'SELECT COUNT(*) INTO V_CONT FROM T_ZUSA_ESTANDARESMAQ WHERE MES =:P224_MES_AC AND ANIO =:P224_DESDE',
'AND CODIGOESTANDAR IN (''001'',''002'',''003'') AND MAQUINA =:P224_MACHINE AND :P224_MOTIVO =''004'';',
'',
'IF V_CONT < 3  AND :P224_MOTIVO =''004'' THEN ',
'  RETURN FALSE;',
'END IF;',
'RETURN TRUE ;',
'END;'))
,p_validation2=>'PLSQL'
,p_validation_type=>'FUNC_BODY_RETURNING_BOOLEAN'
,p_error_message=>unistr('Para ingresar la variable UNIDADES POR MINUTO deben estar las anteriores variables ingresadas para el c\00E1lculo autom\00E1tico.')
,p_when_button_pressed=>wwv_flow_imp.id(63119779194701269)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(63122678886701274)
,p_validation_name=>'CONTROL MES'
,p_validation_sequence=>20
,p_validation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'V_CONT NUMBER;',
'',
'BEGIN',
'',
'SELECT COUNT(*) INTO V_CONT FROM T_ZUSA_ESTANDARESMAQ WHERE MES =:P224_MES_AC AND ANIO=:P224_DESDE AND MAQUINA =:P224_MACHINE AND CODIGOESTANDAR =:P224_MOTIVO;',
'',
'',
'IF V_CONT >0 THEN ',
'RETURN FALSE;',
'END IF;',
'RETURN TRUE;',
'',
'',
'END;'))
,p_validation2=>'PLSQL'
,p_validation_type=>'FUNC_BODY_RETURNING_BOOLEAN'
,p_error_message=>unistr('Ya existe esa variable para este mes y m\00E1quina.')
,p_when_button_pressed=>wwv_flow_imp.id(63119779194701269)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(63123049098701274)
,p_validation_name=>'MODIFICAR'
,p_validation_sequence=>30
,p_validation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'V_MES NUMBER;',
'V_ANIO NUMBER;',
'',
'BEGIN ',
'SELECT TO_NUMBER( TO_CHAR (SYSDATE,''MM'')) ,TO_NUMBER(TO_CHAR(SYSDATE,''YYYY'') ) INTO V_MES, V_ANIO  FROM DUAL;',
'',
'',
'IF :P224_MES_AC =V_MES AND :P224_DESDE = V_ANIO THEN ',
'   RETURN true;',
'END IF;',
'RETURN false;',
'',
'END;'))
,p_validation2=>'PLSQL'
,p_validation_type=>'FUNC_BODY_RETURNING_BOOLEAN'
,p_error_message=>unistr('No se puede modificar est\00E1ndares para meses anteriores!')
,p_when_button_pressed=>wwv_flow_imp.id(63120562924701273)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(63123359178701274)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'GUARDAR_ESTANDAR'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'INSERT INTO T_ZUSA_ESTANDARESMAQ  (CODEMPRESA,',
'CODIGOESTANDAR ,',
'MAQUINA ,',
'VALOR , ',
'MES , ',
'ANIO, ',
'AUDITORIAUSUARIO ,',
'AUDITORIAFECHA )',
'VALUES (''00002'',:P224_MOTIVO, :P224_MACHINE, :P224_VALOR, :P224_MES_AC,:P224_DESDE,:APP_USER,SYSDATE);'))
,p_process_clob_language=>'PLSQL'
,p_process_error_message=>unistr('NO se ha guardado la informaci\00F3n.!')
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(63119779194701269)
,p_process_when=>'P224_MOTIVO'
,p_process_when_type=>'ITEM_IS_NOT_NULL'
,p_process_success_message=>'Se ha guardado correctamente!.'
,p_internal_uid=>63123359178701274
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(63124553087701276)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'ACTUALIZA'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'   UPDATE T_ZUSA_ESTANDARESMAQ SET VALOR = :P224_VALOR WHERE  MES =:P224_MES_AC AND ANIO =:P224_DESDE',
'   AND MAQUINA =:P224_MACHINE AND  CODIGOESTANDAR = :P224_MOTIVO ;',
'   ',
'--RECALCULA',
'',
'',
'UPDATE T_ZUSA_ESTANDARESMAQ SET VALOR = ( SELECT (valor * (select (valor/100) FROM T_ZUSA_ESTANDARESMAQ  WHERE mes = :P224_MES_AC and anio = :P224_DESDE  AND MAQUINA = :P224_MACHINE and codigoestandar=''002'' )',
'*(select valor FROM T_ZUSA_ESTANDARESMAQ  WHERE mes = :P224_MES_AC and anio = :P224_DESDE AND MAQUINA = :P224_MACHINE and codigoestandar=''003'' )',
'*(select (valor*60) FROM T_ZUSA_ESTANDARESMAQ  WHERE mes = :P224_MES_AC and anio = :P224_DESDE  AND MAQUINA = :P224_MACHINE and codigoestandar=''004'' )) unidades',
'FROM T_ZUSA_ESTANDARESMAQ  WHERE mes = :P224_MES_AC and anio = :P224_DESDE AND MAQUINA = :P224_MACHINE  and codigoestandar=''001'' )',
'WHERE  MES =:P224_MES_AC AND ANIO =:P224_DESDE',
'   AND MAQUINA =:P224_MACHINE AND  CODIGOESTANDAR = ''008'' ;',
'   ',
'',
'',
'',
'---- labor',
'UPDATE T_ZUSA_ESTANDARESMAQ SET VALOR =(select  ROUND (VALOR / (select valor FROM T_ZUSA_ESTANDARESMAQ  WHERE mes = :P224_MES_AC and anio = :P224_DESDE and codigoestandar=''008'' ),5)',
'FROM T_ZUSA_ESTANDARESMAQ  WHERE mes = :P224_MES_AC and anio = :P224_DESDE AND MAQUINA = :P224_MACHINE and codigoestandar=''005'')',
'WHERE  MES =:P224_MES_AC AND ANIO =:P224_DESDE',
'   AND MAQUINA =:P224_MACHINE AND  CODIGOESTANDAR = ''009'';',
'--MAINTENENCE',
'',
'UPDATE T_ZUSA_ESTANDARESMAQ SET VALOR = (select ROUND (VALOR / (select valor FROM T_ZUSA_ESTANDARESMAQ  WHERE mes = :P224_MES_AC and anio = :P224_DESDE AND MAQUINA = :P224_MACHINE and codigoestandar=''008'' ),5)',
'FROM T_ZUSA_ESTANDARESMAQ  WHERE mes = :P224_MES_AC and anio = :P224_DESDE AND MAQUINA = :P224_MACHINE and codigoestandar=''006'')',
'WHERE  MES =:P224_MES_AC AND ANIO =:P224_DESDE',
'   AND MAQUINA =:P224_MACHINE AND  CODIGOESTANDAR = ''010'';',
'',
'--OVERHEAD',
'UPDATE T_ZUSA_ESTANDARESMAQ SET VALOR = ( select  ROUND (VALOR / (select valor FROM T_ZUSA_ESTANDARESMAQ  WHERE mes = :P224_MES_AC and anio = :P224_DESDE AND MAQUINA = :P224_MACHINE and codigoestandar=''008'' ),5)',
'FROM T_ZUSA_ESTANDARESMAQ  WHERE mes = :P224_MES_AC and anio = :P224_DESDE AND MAQUINA = :P224_MACHINE and codigoestandar=''007'')',
'WHERE   MES =:P224_MES_AC AND ANIO =:P224_DESDE',
'   AND MAQUINA =:P224_MACHINE AND  CODIGOESTANDAR = ''011'' ;',
'',
'',
'   ',
''))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(63120562924701273)
,p_process_success_message=>unistr('SE MODIFICO CON \00C9XITO!')
,p_internal_uid=>63124553087701276
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(63124180716701276)
,p_process_sequence=>30
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'GUARDAR_CALCULOS'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'--CACULO DE NUMERO DE UNIDADES',
'',
'DECLARE',
' V_CONT NUMBER;',
' V_CONSTD NUMBER;',
' ',
'BEGIN',
'',
'SELECT COUNT(*) INTO V_CONT FROM  T_ZUSA_ESTANDARESMAQ WHERE  mes = :P224_MES_AC and anio = :P224_DESDE AND MAQUINA = :P224_MACHINE and codigoestandar=''004'' AND :P224_MOTIVO = ''004'';',
'',
'IF V_CONT >0 THEN ',
'INSERT INTO T_ZUSA_ESTANDARESMAQ  (CODEMPRESA,',
'CODIGOESTANDAR ,',
'MAQUINA ,',
'VALOR , ',
'MES , ',
'ANIO, ',
'AUDITORIAUSUARIO ,',
'AUDITORIAFECHA )',
'select ''00002'',''008'', :P224_MACHINE, (valor * (select (valor/100) FROM T_ZUSA_ESTANDARESMAQ  WHERE mes = :P224_MES_AC and anio = :P224_DESDE  AND MAQUINA = :P224_MACHINE and codigoestandar=''002'' )',
'*(select valor FROM T_ZUSA_ESTANDARESMAQ  WHERE mes = :P224_MES_AC and anio = :P224_DESDE AND MAQUINA = :P224_MACHINE and codigoestandar=''003'' )',
'*(select (valor*60) FROM T_ZUSA_ESTANDARESMAQ  WHERE mes = :P224_MES_AC and anio = :P224_DESDE  AND MAQUINA = :P224_MACHINE and codigoestandar=''004'' )) unidades, :P224_MES_AC,:P224_DESDE, :APP_USER,SYSDATE',
'FROM T_ZUSA_ESTANDARESMAQ  WHERE mes = :P224_MES_AC and anio = :P224_DESDE AND MAQUINA = :P224_MACHINE  and codigoestandar=''001'';',
'',
'END IF;',
'',
unistr('--CALCULO DE EST\00C1NDARES'),
'SELECT COUNT(*) INTO V_CONSTD FROM  T_ZUSA_ESTANDARESMAQ WHERE  mes = :P224_MES_AC and anio = :P224_DESDE AND MAQUINA = :P224_MACHINE and codigoestandar=''007'' AND :P224_MOTIVO = ''007'';',
'',
'IF V_CONSTD >0 THEN',
'-- LABOR',
'',
'INSERT INTO T_ZUSA_ESTANDARESMAQ  (CODEMPRESA,',
'CODIGOESTANDAR ,',
'MAQUINA ,',
'VALOR , ',
'MES , ',
'ANIO, ',
'AUDITORIAUSUARIO ,',
'AUDITORIAFECHA )',
'select ''00002'',''009'',:P224_MACHINE, ROUND (VALOR / (select valor FROM T_ZUSA_ESTANDARESMAQ  WHERE mes = :P224_MES_AC and anio = :P224_DESDE and codigoestandar=''008'' ),5),:P224_MES_AC,:P224_DESDE, :APP_USER,SYSDATE',
'FROM T_ZUSA_ESTANDARESMAQ  WHERE mes = :P224_MES_AC and anio = :P224_DESDE AND MAQUINA = :P224_MACHINE and codigoestandar=''005'';',
'',
'--MAINTENENCE',
'',
'INSERT INTO T_ZUSA_ESTANDARESMAQ  (CODEMPRESA,',
'CODIGOESTANDAR ,',
'MAQUINA ,',
'VALOR , ',
'MES , ',
'ANIO, ',
'AUDITORIAUSUARIO ,',
'AUDITORIAFECHA )',
'select ''00002'',''010'',:P224_MACHINE, ROUND (VALOR / (select valor FROM T_ZUSA_ESTANDARESMAQ  WHERE mes = :P224_MES_AC and anio = :P224_DESDE AND MAQUINA = :P224_MACHINE and codigoestandar=''008'' ),5),:P224_MES_AC,:P224_DESDE, :APP_USER,SYSDATE',
'FROM T_ZUSA_ESTANDARESMAQ  WHERE mes = :P224_MES_AC and anio = :P224_DESDE AND MAQUINA = :P224_MACHINE and codigoestandar=''006'';',
'',
'--OVERHEAD',
'INSERT INTO T_ZUSA_ESTANDARESMAQ  (CODEMPRESA,',
'CODIGOESTANDAR ,',
'MAQUINA ,',
'VALOR , ',
'MES , ',
'ANIO, ',
'AUDITORIAUSUARIO ,',
'AUDITORIAFECHA )',
'select ''00002'',''011'',:P224_MACHINE, ROUND (VALOR / (select valor FROM T_ZUSA_ESTANDARESMAQ  WHERE mes = :P224_MES_AC and anio = :P224_DESDE AND MAQUINA = :P224_MACHINE and codigoestandar=''008'' ),5),:P224_MES_AC,:P224_DESDE, :APP_USER,SYSDATE',
'FROM T_ZUSA_ESTANDARESMAQ  WHERE mes = :P224_MES_AC and anio = :P224_DESDE AND MAQUINA = :P224_MACHINE and codigoestandar=''007'';',
'',
'',
'',
'END IF;',
'',
'',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_process_error_message=>unistr('NO se ha guardado la informaci\00F3n.!')
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(63119779194701269)
,p_process_when=>'P224_MOTIVO'
,p_process_when_type=>'ITEM_IS_NOT_NULL'
,p_process_success_message=>'Se ha guardado correctamente!.'
,p_internal_uid=>63124180716701276
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(63123732120701276)
,p_process_sequence=>40
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'LIMPIA'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
':P224_MOTIVO:= NULL;',
':P224_MACHINE :=NULL;',
':P224_VALOR:=0;',
'--:P224_DESDE:=NULL;',
'--P224_MES_AC:=NULL;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(63119779194701269)
,p_internal_uid=>63123732120701276
);
wwv_flow_imp.component_end;
end;
/
