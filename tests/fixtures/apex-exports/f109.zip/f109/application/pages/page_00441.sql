prompt --application/pages/page_00441
begin
--   Manifest
--     PAGE: 00441
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>109
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_page.create_page(
 p_id=>441
,p_name=>'PYG INDUSTRIALES - PAG - FUENTES DE DATOS'
,p_alias=>'PYG-INDUSTRIALES-FUENTES-DE-DATOS'
,p_step_title=>'PYG INDUSTRIALES - FUENTES DE DATOS'
,p_autocomplete_on_off=>'OFF'
,p_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'',
'function f_cargaOpciones (p_item){',
'	(function () {',
'		function setCol($els, n){',
'			$els.each(function(){',
'				const el = this;',
'				const toRemove = [];',
'				el.classList.forEach(cls => {',
'					if (cls === "col" || cls.indexOf("col-") === 0) toRemove.push(cls);',
'				});',
'				toRemove.forEach(c => el.classList.remove(c));',
'				el.classList.add("col-" + n);',
'			});',
'		}',
'',
'		function apply(){',
'			const $c = $("#"+p_item);',
'			if (!$c.length) return;',
'			setCol($c.find(".t-Form-labelContainer"), 0);',
'			setCol($c.find(".t-Form-inputContainer"), 12);',
'		}',
'',
'		// inicial y tras eventos APEX comunes',
'		$(apply);',
'		$(document).on("apexafterrefresh apexafterclosedialog apexafterpagesubmit", apply);',
'	})();',
'',
'}'))
,p_javascript_code_onload=>wwv_flow_string.join(wwv_flow_t_varchar2(
'$(".t-Button.t-Button--icon.t-Button--header.t-Button--headerTree.is-active").click();',
'f_cargaOpciones("P441_COMPANIA_FILTRO_CONTAINER");',
'$(secItems).hide();',
''))
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.a-IRR-button.a-IRR-sortWidget-button[data-option="hide"], .a-IRR-button.a-IRR-sortWidget-button[data-option="freeze"]{',
'	display:none;',
'}',
'.a-IRR-controlsContainer {',
'    border-top: 1px solid;',
'    border-bottom-width: 0;',
'    display: none;',
'}',
'',
'.a-IG-controlsContainer, .a-IRR-controlsContainer {',
'    border-bottom: var(--a-report-controls-border-width, 1px) solid var(--a-report-controls-border-color);',
'    padding-block-end: var(--a-report-controls-padding-y, 8px);',
'    padding-block-start: var(--a-report-controls-padding-y, 8px);',
'    padding-inline-end: var(--a-report-controls-padding-x, 8px);',
'    padding-inline-start: var(--a-report-controls-padding-x, 8px);',
'    display: none;',
'}'))
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'18'
,p_last_updated_on=>wwv_flow_imp.dz('20260221140213Z')
,p_last_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(99268707624732402)
,p_plug_name=>'MasterLeft'
,p_title=>'Listado de Fuentes Datos'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(38289867500120143)
,p_plug_display_sequence=>20
,p_plug_display_point=>'REGION_POSITION_01'
,p_location=>null
,p_menu_id=>wwv_flow_imp.id(37761271469106475)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(37860983999106559)
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(99272584271732440)
,p_plug_name=>'Barra de Acciones'
,p_region_template_options=>'#DEFAULT#:t-Form--stretchInputs'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(38289497777120142)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_location=>null
,p_menu_id=>wwv_flow_imp.id(37761271469106475)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(37860983999106559)
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(114517765252768731)
,p_plug_name=>'Reportes'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(38289867500120143)
,p_plug_display_sequence=>10
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(114517564571768729)
,p_plug_name=>'RegionSelector'
,p_region_name=>'rptSelector'
,p_parent_plug_id=>wwv_flow_imp.id(114517765252768731)
,p_region_template_options=>'#DEFAULT#:js-useLocalStorage:t-TabsRegion-mod--fillLabels:t-TabsRegion-mod--pill:t-TabsRegion-mod--large'
,p_plug_template=>wwv_flow_imp.id(37814656137106525)
,p_plug_display_sequence=>30
,p_plug_display_point=>'SUB_REGIONS'
,p_location=>null
,p_plug_source_type=>'NATIVE_DISPLAY_SELECTOR'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'display_region_icons', 'N',
  'include_show_all', 'Y',
  'rds_mode', 'STANDARD',
  'remember_selection', 'USER')).to_clob
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(98558614374460718)
,p_name=>unistr('Configuraci\00F3n')
,p_region_name=>'rptListadoCfg'
,p_parent_plug_id=>wwv_flow_imp.id(114517564571768729)
,p_template=>wwv_flow_imp.id(37806762584106520)
,p_display_sequence=>20
,p_region_template_options=>'#DEFAULT#:t-IRR-region--noBorders'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_display_point=>'SUB_REGIONS'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'WITH ',
'CPN AS (SELECT DESCRIPCION CPNDESCRIPCION,ID_TABLA CPNID FROM t_corp_udc where id_cabecera=''COMP_CGZCM'' and ID_TABLA!=''00000'' /*and ACTIVO=''1''*/),',
'TOB AS (SELECT DESCRIPCION TOBDESCRIPCION,ID_TABLA TOBID FROM T_CORP_UDC WHERE ID_CABECERA=''FINZ_GT02'' AND ID_TABLA  in(''001'')  AND ACTIVO=''1''  ),',
'SQM AS (SELECT DESCRIPCION SQMDESCRIPCION,ID_TABLA SQMID FROM T_CORP_UDC WHERE ID_CABECERA=''FINZ_GT04'' AND ID_TABLA!=''000''  AND ACTIVO=''1''),',
'erp as (SELECT DESCRIPCION ERPDESCRIPCION,ID_TABLA ERPID FROM T_CORP_UDC WHERE ID_CABECERA=''FINZ_GT03'' AND ID_TABLA!=''000'' AND ACTIVO=''1''  order by to_number(ID_TABLA)',
')',
'select ID,',
'    CPNDESCRIPCION COMPANIA,',
'    DECODE(UPPER(TABLAPROCESO),''T_FINZ_DISTRIBUCIONASC'',''ASIENTOS CONTABLES'',''T_FINZ_DISTRIBUCIONVTA'',''VENTAS'') TABLAPROCESO,  ',
'    DESCRIPCION,',
'    ESTADO,',
'    ERPDESCRIPCION ERP,',
'    SQMDESCRIPCION ESQUEMA,',
'    TOBDESCRIPCION TIPOOBJETO,',
'    OBJETO,',
'    CPNID codcompania',
'from T_FINZ_DISTRIBUCIONCFG',
'LEFT JOIN TOB ON TIPOOBJETO=TOBID',
'LEFT JOIN SQM ON ESQUEMA=SQMID',
'LEFT JOIN CPN ON COMPANIA=CPNID',
'LEFT JOIN ERP ON ERP=ERPID',
'WHERE (COMPANIA= :P441_COMPANIA_FILTRO or :P441_COMPANIA_FILTRO is null)',
'order by CPNDESCRIPCION,DESCRIPCION'))
,p_ajax_enabled=>'Y'
,p_ajax_items_to_submit=>'P441_COMPANIA_FILTRO'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(37830327650106535)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(99962142626702803)
,p_query_column_id=>1
,p_column_alias=>'ID'
,p_column_display_sequence=>10
,p_use_as_row_header=>'N'
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(99962276405702804)
,p_query_column_id=>2
,p_column_alias=>'COMPANIA'
,p_column_display_sequence=>20
,p_column_heading=>'Compania'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_display_when_cond_type=>'ITEM_IS_NULL'
,p_display_when_condition=>'P441_COMPANIA_FILTRO'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(99962810251702810)
,p_query_column_id=>3
,p_column_alias=>'TABLAPROCESO'
,p_column_display_sequence=>40
,p_column_heading=>'Proceso'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(99962332067702805)
,p_query_column_id=>4
,p_column_alias=>'DESCRIPCION'
,p_column_display_sequence=>30
,p_column_heading=>'Descripcion'
,p_use_as_row_header=>'N'
,p_column_link=>'f?p=&APP_ID.:442:&SESSION.::&DEBUG.:RR,442:P442_ID,G_COMPANIADIST:#ID#,#CODCOMPANIA#'
,p_column_linktext=>'#DESCRIPCION#'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(99962464951702806)
,p_query_column_id=>5
,p_column_alias=>'ESTADO'
,p_column_display_sequence=>50
,p_column_heading=>'Estado'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(99962547677702807)
,p_query_column_id=>6
,p_column_alias=>'ERP'
,p_column_display_sequence=>60
,p_column_heading=>'Erp'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(99962633801702808)
,p_query_column_id=>7
,p_column_alias=>'ESQUEMA'
,p_column_display_sequence=>70
,p_column_heading=>'Esquema'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(99962721605702809)
,p_query_column_id=>8
,p_column_alias=>'TIPOOBJETO'
,p_column_display_sequence=>80
,p_column_heading=>'Tipoobjeto'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(99964968831702831)
,p_query_column_id=>9
,p_column_alias=>'OBJETO'
,p_column_display_sequence=>100
,p_column_heading=>'Objeto'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(123074718728026645)
,p_query_column_id=>10
,p_column_alias=>'CODCOMPANIA'
,p_column_display_sequence=>110
,p_use_as_row_header=>'N'
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(121221681761878504)
,p_plug_name=>unistr('Obtenci\00F3n de datos')
,p_region_name=>'rptListadoRgl'
,p_parent_plug_id=>wwv_flow_imp.id(114517564571768729)
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(37806762584106520)
,p_plug_display_sequence=>30
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'WITH ',
'CPN AS (SELECT DESCRIPCION CPNDESCRIPCION,ID_TABLA CPNID FROM t_corp_udc where id_cabecera=''COMP_CGZCM'' and ID_TABLA!=''00000'' /*and ACTIVO=''1''*/)',
'select ID,',
'       USERCREA,',
'       FECHCREA,',
'       USERMODI,',
'       FECHMODI,',
'       CPNDESCRIPCION COMPANIA,',
'       CPNID codcompania,',
'       TIPO,',
'       DESCRIPCION,',
'       VERSION,',
'       PARAMETROS,',
'       VALIDACIONES,',
'       REGLA1,',
'       REGLA2,',
'       REGLA3,',
'       REGLA4,',
'       REGLA5',
'  from T_FINZ_DISTRIBUCIONRGL',
'  LEFT JOIN CPN ON COMPANIA=CPNID',
' where 1=1',
' and (COMPANIA= :P441_COMPANIA_FILTRO or :P441_COMPANIA_FILTRO is null)'))
,p_plug_source_type=>'NATIVE_IR'
,p_ajax_items_to_submit=>'P441_COMPANIA_FILTRO'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
,p_updated_on=>wwv_flow_imp.dz('20260220151900Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(121221707599878505)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_show_search_bar=>'N'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_enable_mail_download=>'Y'
,p_owner=>'EMASABANDA'
,p_internal_uid=>121221707599878505
,p_updated_on=>wwv_flow_imp.dz('20260220151900Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(121221829170878506)
,p_db_column_name=>'ID'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Id'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(121221905975878507)
,p_db_column_name=>'USERCREA'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Usercrea'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(121222024972878508)
,p_db_column_name=>'FECHCREA'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Fechcrea'
,p_column_type=>'DATE'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(121222140217878509)
,p_db_column_name=>'USERMODI'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Usermodi'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(121222242271878510)
,p_db_column_name=>'FECHMODI'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Fechmodi'
,p_column_type=>'DATE'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(121222362456878511)
,p_db_column_name=>'COMPANIA'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'Compania'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(121222484371878512)
,p_db_column_name=>'TIPO'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>'Tipo'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(121222563186878513)
,p_db_column_name=>'DESCRIPCION'
,p_display_order=>80
,p_column_identifier=>'H'
,p_column_label=>'Descripcion'
,p_column_link=>'f?p=&APP_ID.:446:&SESSION.::&DEBUG.:RR,446:P446_ID,G_COMPANIADIST:#ID#,#CODCOMPANIA#'
,p_column_linktext=>'#DESCRIPCION#'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
,p_updated_on=>wwv_flow_imp.dz('20260220151900Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(121222623154878514)
,p_db_column_name=>'VERSION'
,p_display_order=>90
,p_column_identifier=>'I'
,p_column_label=>'Version'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(121222769478878515)
,p_db_column_name=>'PARAMETROS'
,p_display_order=>100
,p_column_identifier=>'J'
,p_column_label=>'Parametros'
,p_column_type=>'CLOB'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(121222817429878516)
,p_db_column_name=>'VALIDACIONES'
,p_display_order=>110
,p_column_identifier=>'K'
,p_column_label=>'Validaciones'
,p_column_type=>'CLOB'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(121222983480878517)
,p_db_column_name=>'REGLA1'
,p_display_order=>120
,p_column_identifier=>'L'
,p_column_label=>'Regla1'
,p_column_type=>'CLOB'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(121223027500878518)
,p_db_column_name=>'REGLA2'
,p_display_order=>130
,p_column_identifier=>'M'
,p_column_label=>'Regla2'
,p_column_type=>'CLOB'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(121223193074878519)
,p_db_column_name=>'REGLA3'
,p_display_order=>140
,p_column_identifier=>'N'
,p_column_label=>'Regla3'
,p_column_type=>'CLOB'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(121223298123878520)
,p_db_column_name=>'REGLA4'
,p_display_order=>150
,p_column_identifier=>'O'
,p_column_label=>'Regla4'
,p_column_type=>'CLOB'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(121223387221878521)
,p_db_column_name=>'REGLA5'
,p_display_order=>160
,p_column_identifier=>'P'
,p_column_label=>'Regla5'
,p_column_type=>'CLOB'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(123074679268026644)
,p_db_column_name=>'CODCOMPANIA'
,p_display_order=>170
,p_column_identifier=>'Q'
,p_column_label=>'Codcompania'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(121638221404920432)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'1216383'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'ID:USERCREA:FECHCREA:USERMODI:FECHMODI:COMPANIA:TIPO:DESCRIPCION:VERSION:PARAMETROS:VALIDACIONES:REGLA1:REGLA2:REGLA3:REGLA4:REGLA5'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(114518429769768738)
,p_plug_name=>'Items'
,p_region_name=>'secItems'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(38289867500120143)
,p_plug_display_sequence=>20
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(114517414082768728)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(99272584271732440)
,p_button_name=>'Atras'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860056812106557)
,p_button_image_alt=>'Atras'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'LEFT'
,p_button_redirect_url=>'f?p=&APP_ID.:440:&SESSION.::&DEBUG.:440::'
,p_icon_css_classes=>'fa-arrow-left'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(99272661972732441)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(99272584271732440)
,p_button_name=>'AgregarCfg'
,p_button_static_id=>'btnAgregarCfg'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860056812106557)
,p_button_image_alt=>'Agregarcfg'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:442:&SESSION.::&DEBUG.:RR,442:G_COMPANIADIST,P442_ID:&P441_COMPANIA_FILTRO.,'
,p_button_condition=>'P441_COMPANIA_FILTRO'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_icon_css_classes=>'fa-plus'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(114518986497768743)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(99272584271732440)
,p_button_name=>'AgregarRgl'
,p_button_static_id=>'btnAgregarRgl'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860056812106557)
,p_button_image_alt=>'Agregarrgl'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:446:&SESSION.::&DEBUG.:RR,446:G_COMPANIADIST:&P441_COMPANIA_FILTRO.'
,p_button_condition=>'P441_COMPANIA_FILTRO'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_icon_css_classes=>'fa-plus'
,p_updated_on=>wwv_flow_imp.dz('20260220151836Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(99271280646732427)
,p_name=>'P441_COMPANIA_FILTRO'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(99268707624732402)
,p_prompt=>'Compania'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'LOV_FINZ_PGI_COMPANIA'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'      SELECT DESCRIPCION, ID_TABLA IDCOMPANIA',
'FROM t_corp_udc ',
'where id_cabecera=''COMP_CGZCM'' ',
'and ID_TABLA!=''00000'' ',
'/*and ACTIVO=''1''*/',
'order by ID_TABLA;'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'Seleccione'
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--stretchInputs:t-Form-fieldContainer--large:t-Form-fieldContainer--preTextBlock:t-Form-fieldContainer--postTextBlock:t-Form-fieldContainer--radioButtonGroup'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'SUBMIT'
,p_attribute_03=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(114518501698768739)
,p_name=>'P441_NAVEGADORTABS'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(114518429769768738)
,p_prompt=>'Navegadortabs'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_warn_on_unsaved_changes=>'I'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(114518620671768740)
,p_name=>'Activar Tab'
,p_event_sequence=>20
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(114517564571768729)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'custom'
,p_bind_event_type_custom=>'atabsactivate'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(114518774443768741)
,p_event_id=>wwv_flow_imp.id(114518620671768740)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'var atab = apex.region("rptSelector").widget().aTabs("getActive").href;',
'var ttab = atab.replace("SR_","") ;',
'let vtipo="";',
'$s("P441_NAVEGADORTABS",atab);',
'$(''#btnAgregarCfg'').hide();',
'$(''#btnAgregarRgl'').hide();',
'switch(ttab) { ',
'    case ''#rptListadoCfg'': 		apex.region("rptListadoCfg").refresh();$(''#btnAgregarCfg'').show();break;',
'    case ''#rptListadoRgl'': 		apex.region("rptListadoRgl").refresh();$(''#btnAgregarRgl'').show();break;',
'}'))
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(114518814261768742)
,p_event_id=>wwv_flow_imp.id(114518620671768740)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'    :g_navegadortabs:= :P441_NAVEGADORTABS;',
'end;'))
,p_attribute_02=>'P441_NAVEGADORTABS'
,p_attribute_03=>'G_NAVEGADORTABS'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(123074314356026641)
,p_name=>'SeleccionaCompania'
,p_event_sequence=>30
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P441_COMPANIA_FILTRO'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(123074444494026642)
,p_event_id=>wwv_flow_imp.id(123074314356026641)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>':G_COMPANIADIST:=:P441_COMPANIA_FILTRO;'
,p_attribute_02=>'P441_COMPANIA_FILTRO'
,p_attribute_03=>'G_COMPANIADIST'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(123074515002026643)
,p_process_sequence=>10
,p_process_point=>'AFTER_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Setup Interface'
,p_process_sql_clob=>':P441_COMPANIA_FILTRO:=:G_COMPANIADIST;'
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>123074515002026643
,p_updated_on=>wwv_flow_imp.dz('20260221140213Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp.component_end;
end;
/
