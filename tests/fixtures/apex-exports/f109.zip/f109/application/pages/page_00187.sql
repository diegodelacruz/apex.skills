prompt --application/pages/page_00187
begin
--   Manifest
--     PAGE: 00187
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>109
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_page.create_page(
 p_id=>187
,p_name=>'GESTION TRIBUTARIA - VER CARGA DATOS'
,p_alias=>'GESTION-TRIBUTARIA-VER-CARGA-DATOS'
,p_page_mode=>'MODAL'
,p_step_title=>'GESTION TRIBUTARIA - VER CARGA DATOS'
,p_autocomplete_on_off=>'OFF'
,p_html_page_header=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<meta charset="UTF-8">',
'<script src="https://cdnjs.cloudflare.com/ajax/libs/xlsx/0.18.5/xlsx.full.min.js"></script>'))
,p_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'let v_tiene_cambios=0;',
'let v_JSONGESTION="";',
'let v_JSONCOLUMNAS="";',
'let v_JSONCOLUMNASMAYORES="";',
' ',
' ',
'// ===== helpers de texto =====',
'function trim2(v){ return v==null ? "" : String(v).trim(); }',
'function isBlank(v){ return v==null || trim2(v)===""; }',
'',
'',
'function f_aplicar_calculos_json(p_data, p_columnas) {',
'',
'	// ===== parseo seguro =====',
'	let datos, columnas;',
'	try { datos = JSON.parse(p_data || "[]"); } catch { datos = []; }',
'	try { columnas = JSON.parse(p_columnas || "[]"); } catch { columnas = []; }',
'	function toNumberGeneral(v) {',
'		if (v == null) return 0;',
'		if (typeof v === "number" && Number.isFinite(v)) return v;',
'		let s = String(v).trim();',
'		if (!s) return 0;',
'		s = s.replace(/^\((.*)\)$/, "-$1");',
'		const hasPct = /%/.test(s);',
'		s = s.replace(/[^0-9,.\005C-]/g, "");',
'		const lastDot = s.lastIndexOf(".");',
'		const lastCom = s.lastIndexOf(",");',
'		if (lastDot > lastCom) s = s.replace(/,/g, "");',
'		else if (lastCom > lastDot) { s = s.replace(/\./g, ""); s = s.replace(/,/g, "."); }',
'		else s = s.replace(/[.,]/g, "");',
'		let n = parseFloat(s);',
'		if (!Number.isFinite(n)) n = 0;',
'		return hasPct ? n / 100 : n;',
'	}',
'	const pow10 = n => Math.pow(10, n|0);',
'	function roundN(x, n) { const f = pow10(n|0); return Math.round((+x || 0) * f) / f; }',
'	function truncN(x, n) { const f = pow10(n|0), v = (+x || 0) * f; return (v < 0 ? Math.ceil(v) : Math.floor(v)) / f; }',
'	function nvl(a, b) { return (a === null || a === undefined || a === "") ? b : a; }',
'	function greatest() { return Array.from(arguments).reduce((m, v) => Math.max(m, +v || 0), -Infinity); }',
'	function least() { return Array.from(arguments).reduce((m, v) => Math.min(m, +v || 0), Infinity); }',
'',
'	function isBlank(x){ const s = x==null ? '''' : String(x); return s.trim()===''''; }',
'	function trim2(x){ return x==null ? '''' : String(x).trim(); }',
'',
'	function convertirPlsqlAJs(formulaPlsql) {',
'		let f = String(formulaPlsql || "");',
'',
'		f = f.replace(/TRIM\s*\(\s*([^)]+?)\s*\)\s+IS\s+NULL/gi, ''isBlank($1)'');',
'		f = f.replace(/TRIM\s*\(\s*([^)]+?)\s*\)\s+IS\s+NOT\s+NULL/gi, ''!isBlank($1)'');',
'		f = f.replace(/(\b[\w$]+\b)\s+IS\s+NULL/gi, ''isBlank($1)'');',
'		f = f.replace(/(\b[\w$]+\b)\s+IS\s+NOT\s+NULL/gi, ''!isBlank($1)'');',
'		f = f.replace(/\bTRIM\s*\(\s*([^)]+?)\s*\)/gi, ''trim2($1)'');',
'		f = f.replace(/CASE\s+WHEN\s+([^]*?)\s+THEN\s+([^]*?)\s+ELSE\s+([^]*?)\s+END/gi,''( ($1) ? ($2) : ($3) )'');',
'		f = f.replace(/CASE\s+WHEN\s+([^]*?)\s+THEN\s+([^]*?)\s+END/gi,''( ($1) ? ($2) : "" )'');',
'		f = f.replace(/\|\|/g, ''+'');',
'		f = f.replace(/:\s*\)/g, '':"")'');',
'		f = f.replace(/ROUND\s*\(\s*([^\s][^,]*?)\s*,\s*([0-9]+)\s*\)/gi, ''roundN(($1), $2)'');',
'		f = f.replace(/TRUNC\s*\(\s*([^\s][^,]*?)\s*,\s*([0-9]+)\s*\)/gi, ''truncN(($1), $2)'');',
'		f = f.replace(/MOD\s*\(\s*([^,]+?)\s*,\s*([^)]+?)\s*\)/gi, ''((($1)) % (($2)))'');',
'		f = f.replace(/POWER\s*\(\s*([^,]+?)\s*,\s*([^)]+?)\s*\)/gi, ''Math.pow(($1), ($2))'');',
'		f = f.replace(/NVL\s*\(\s*([^,]+?)\s*,\s*([^)]+?)\s*\)/gi, ''nvl(($1), ($2))'');',
'		f = f.replace(/ABS\s*\(\s*([^)]+?)\s*\)/gi, ''Math.abs(($1))'');',
'		f = f.replace(/CEIL\s*\(\s*([^)]+?)\s*\)/gi, ''Math.ceil(($1))'');',
'		f = f.replace(/FLOOR\s*\(\s*([^)]+?)\s*\)/gi, ''Math.floor(($1))'');',
'		f = f.replace(/SQRT\s*\(\s*([^)]+?)\s*\)/gi, ''Math.sqrt(($1))'');',
'		f = f.replace(/EXP\s*\(\s*([^)]+?)\s*\)/gi, ''Math.exp(($1))'');',
'		f = f.replace(/\bLN\s*\(\s*([^)]+?)\s*\)/gi, ''Math.log(($1))'');',
'		f = f.replace(/GREATEST\s*\(\s*([^)]+?)\s*\)/gi, (_, args)=> ''greatest('' + args + '')'');',
'		f = f.replace(/LEAST\s*\(\s*([^)]+?)\s*\)/gi, (_, args)=> ''least('' + args + '')'');',
'		// f = f.replace(/"/g, "");',
'		f = f.replace(/\bTRUE\b/gi, ''1'').replace(/\bFALSE\b/gi, ''0'').replace(/\bNULL\b/gi, ''0'');',
'		return f.trim();',
'	}',
'',
'	function mapIdentTexto(expr) {',
'		const KW = new Set(["ROUND","TRUNC","MOD","POWER","NVL","ABS","CEIL","FLOOR","SQRT","EXP","LN","GREATEST","LEAST","CASE","WHEN","THEN","ELSE","END","AND","OR","NOT","IS","NULL","MATH","SIGN","ISBLANK","TRIM2","N","S"]);',
'		return expr.replace(',
'			/''(?:[^''\\]|\\.)*''|"(?:[^"\\]|\\.)*"|\b([A-Za-z_][A-Za-z0-9_]*)\b/g,',
'			(m, id) => !id ? m : (KW.has(id.toUpperCase()) ? id : `N("${id}")`)',
'		);',
'	}',
'',
'	function inyectarValores(formulaJs, row, alias) {',
'		const RESERVED = new Set(["roundN","truncN","nvl","greatest","least","Math","NaN","Infinity","isNaN","Number","abs"]);',
'		let f = String(formulaJs || "");',
'		f = f.replace(/"([^"\\]+)"/g, (_, name) => {',
'			const v = Object.prototype.hasOwnProperty.call(row, name) ? row[name] : 0;',
'			const n = (typeof v === "number") ? v : toNumberGeneral(v);',
'			return String(Number.isFinite(n) ? n : 0);',
'		});',
'',
'		f = f.replace(/\b[A-Za-z_$][A-Za-z0-9_$]*\b/g, (id) => {',
'			if (RESERVED.has(id)) return id;',
'			if (!Object.prototype.hasOwnProperty.call(row, id)) return "0";',
'			const v = row[id];',
'			if (typeof v === "number") return String(v);',
'			if (v == null || v === "") return "0";',
'			return String(toNumberGeneral(v));',
'		});',
'		return f;',
'	}',
'',
'  function evaluar(expr) {',
'		try {',
'			expr = expr.replace(/"/g, '''');',
'			const body = ''return ('' + expr + '');'';',
'			const fn = new Function("roundN","truncN","nvl","greatest","least","Math", body);',
'			const r = fn(roundN, truncN, nvl, greatest, least, Math);',
'			return Number.isFinite(r) ? r : 0;',
'		} catch { return 0; }',
'	}',
'	function evaluarTexto(expr, row,alias) {',
'		const N = (k) => toNumberGeneral(row?.[k]);',
'		const S = (k) => { const v = row?.[k]; return v==null ? "" : String(v); };',
'		const body = ''return ('' + expr + '');'';',
'		const fn = new Function("roundN","truncN","nvl","greatest","least","Math","N","S", body);',
'		return fn(roundN, truncN, nvl, greatest, least, Math, N, S);',
'	}',
'',
'	columnas.forEach(col => {',
'		//console.log("id:"+col.ID+",ALIAS:"+col.ALIAS);',
'		if (col && col.CALCULO === "Y" && typeof col.COLUMNA === "string") {',
'			const alias = String(col.ALIAS || "").replace(/"/g, "");',
'			const formulaPL = col.COLUMNA;',
'			if(alias!=="VALIDACIONES"){',
'				// console.log("formulaPL:"+formulaPL);',
'				const esTexto = /''(?:[^'']*)''|\|\||\bCASE\b/i.test(formulaPL);',
'				datos.forEach(row => {',
'			',
'					let fjs = convertirPlsqlAJs(formulaPL);',
'					fjs = fjs',
'					.replace(/\bisBlank\s*\(\s*([A-Za-z_][A-Za-z0-9_]*)\s*\)/g, ''isBlank(S("$1"))'')',
'					.replace(/\btrim2\s*\(\s*([A-Za-z_][A-Za-z0-9_]*)\s*\)/g, ''trim2(S("$1"))'');',
'',
'',
'					let result;',
'					if (esTexto) {',
'						let exprTexto = mapIdentTexto(fjs);',
'						const orn= String(row["NUMEROORDEN"]|| "");',
'			',
'						exprTexto = exprTexto',
'						.replace(/S\("([^"]+)"\)/g, (_, k) =>{JSON.stringify(String(row?.[k] ?? ""));} )',
'						.replace(/N\("([^"]+)"\)/g, (_, k) =>{String(toNumberGeneral(row?.[k]));	   } );',
'				 ',
'						result = evaluarTexto(exprTexto, row, alias);',
'					} else {',
'						const exprNum = inyectarValores(fjs, row, alias);',
'						result = evaluar(exprNum);',
'						result = roundN(result, 2);',
'						if (Object.is(result, -0)) result = 0;',
'					}',
'					row[alias] = result;',
'					try { if (typeof v_tiene_cambios !== "undefined") v_tiene_cambios = 1; } catch (_) {}',
'				});',
'			}',
'		}//ejmc',
'	});',
'	columnas.forEach(col => {',
'		//console.log("id:"+col.ID+",ALIAS:"+col.ALIAS);',
'		if (col && col.CALCULO === "Y" && typeof col.COLUMNA === "string") {',
'			const alias = String(col.ALIAS || "").replace(/"/g, "");',
'			const formulaPL = col.COLUMNA;',
'			if(alias==="VALIDACIONES"){',
'				// console.log("formulaPL:"+formulaPL);',
'				const esTexto = /''(?:[^'']*)''|\|\||\bCASE\b/i.test(formulaPL);',
'				datos.forEach(row => {',
'			',
'					let fjs = convertirPlsqlAJs(formulaPL);',
'					fjs = fjs',
'					.replace(/\bisBlank\s*\(\s*([A-Za-z_][A-Za-z0-9_]*)\s*\)/g, ''isBlank(S("$1"))'')',
'					.replace(/\btrim2\s*\(\s*([A-Za-z_][A-Za-z0-9_]*)\s*\)/g, ''trim2(S("$1"))'');',
'',
'',
'					let result;',
'					if (esTexto) {',
'						let exprTexto = mapIdentTexto(fjs);',
'						const orn= String(row["NUMEROORDEN"]|| "");',
'						exprTexto = exprTexto	',
'							.replace(/S\("([^"]+)"\)/g, (_, k) => JSON.stringify(String(row?.[k] ?? "" ) ) )',
'							.replace(/N\("([^"]+)"\)/g, (_, k) => String(toNumberGeneral(row?.[k] ) ) );',
'						if(alias==="VALIDACIONES" && orn===''25700335'') {console.log("4.exprTexto:"+exprTexto);}//ejmc',
'						result = evaluarTexto(exprTexto, row, alias);',
'					} else {',
'						const exprNum = inyectarValores(fjs, row, alias);',
'						result = evaluar(exprNum);',
'						result = roundN(result, 2);',
'						if (Object.is(result, -0)) result = 0;',
'					}',
'					row[alias] = result;',
'					try { if (typeof v_tiene_cambios !== "undefined") v_tiene_cambios = 1; } catch (_) {}',
'				});',
'			}',
'		}//ejmc',
'	});',
'',
'',
'',
'  return JSON.stringify(datos);',
'}',
'document.addEventListener("DOMContentLoaded", function () {',
'    const radios = document.querySelectorAll("input[name=''P187_IDDATO'']");',
'    radios.forEach(radio => {',
'        radio.addEventListener("onchange", () => {',
'            // Primero, quitar la clase a todos',
'            radios.forEach(r => {',
'                const label = document.querySelector(`label[for="${r.id}"]`);',
'                if (label) label.style.backgroundColor = ""; // Quitar color anterior',
'            });',
'',
'            // Ahora, aplicar estilo al seleccionado',
'            const selectedLabel = document.querySelector(`label[for="${radio.id}"]`);',
'            if (selectedLabel) selectedLabel.style.backgroundColor = "red";',
'        });',
'    });',
'});',
'',
'function f_asegura_columna_estado(p_json, p_columnas){',
'  let datos = [];',
'  let columnas = [];',
'  try { datos = JSON.parse(p_json || "[]"); } catch (_) { datos = []; }',
'  try { columnas = JSON.parse(p_columnas || "[]"); } catch (_) { columnas = []; }',
'  if (!Array.isArray(datos) || !datos.some(row => row && Object.prototype.hasOwnProperty.call(row, "ESTADO"))) return p_columnas;',
'  if (!Array.isArray(columnas)) columnas = [];',
'  const existeEstado = columnas.some(col => col && String(col.ALIAS || col.COLUMNA || "").toUpperCase() === "ESTADO");',
'  if (!existeEstado) {',
'    const maxId = columnas.reduce((max, col) => Math.max(max, Number(col && col.ID) || 0), 0);',
'    columnas.push({ID: maxId + 1, COLUMNA: "ESTADO", ALIAS: "ESTADO", VISIBLE: "Y", TIPODATO: "T", EDITABLE: "N", QRYRESUL: "Y", CALCULO: "N"});',
'  }',
'  return JSON.stringify(columnas);',
'}',
'',
'function f_generatabla(p_json,p_columnas,p_filtro){',
'  let v_json = p_json || "";',
'  let v_columnas = p_columnas || "";',
'	let v_filtro=p_filtro;',
'',
'    if (v_json){',
'         v_json=f_aplicar_calculos_json(v_json,v_columnas);',
'    }',
'	v_columnas=f_asegura_columna_estado(v_json,v_columnas);',
'	v_JSONGESTION=v_json;',
'	v_JSONCOLUMNAS=v_columnas;',
'',
'    const p_visibles=2;',
'	const p_acc_edita=0;',
'    const p_acc_borra=0;',
'    const p_acc_copia= 0;',
'    const p_columnas_orden=getSort();',
'    const p_proceso=$v("P187_ACTIVIDADES");',
'    f_genera_tablahtml_json(v_json,v_columnas,p_visibles,p_acc_edita,p_acc_borra,p_acc_copia,p_columnas_orden,p_proceso,v_filtro);',
'}',
unistr('// Uso: despu\00E9s de renderizar la tabla'),
'',
'function getSort(){',
'    if ($v("P187_ACTIVIDADES")==="001"){//DOCUMENTO ELECTRONICO',
'        return "COMPROBANTE,RUC_EMISOR,DOCUMENTO";',
'    }',
'    if ($v("P187_ACTIVIDADES")==="002"){//VENTAS',
'        return "NDOC,N_DOC";',
'    }',
'    if ($v("P187_ACTIVIDADES")==="003"){//RETENCIONES',
'        return "RANGO_NO_SIG_1,NUM_DOCUMENTO";',
'    }',
'    if ($v("P187_ACTIVIDADES")==="004"){//COMPRAS',
'        return "N_DOC";',
'    }',
'    if ($v("P187_ACTIVIDADES")==="006"){//ICE',
'        return "N_DOC";',
'    }',
'    if ($v("P187_ACTIVIDADES")==="005"){//SENAE',
'        return "N_DOC";',
'    }',
'    if ($v("P187_ACTIVIDADES")==="007"){//RETENCIONES CLIENTES',
'        return "CLAVE_ACCESO,NO_DOCUMENTO,SERIE_COMPROBANTE";',
'    }',
'    return " ";',
'}',
'',
'  ',
'function f_llamarProcesoByID (v_parametro1){',
'    var result = null;',
'    return new Promise((resolve, reject) => {',
'    apex.server.process(',
'        ''LLAMAR_PROCESO_BYID'', // Nombre del proceso',
'        {',
'            x01:v_parametro1,',
'        }, // variables del proceso',
'        {',
'            dataType: "json",',
'            success: function(pData)',
'            {',
'                //result = pData.result;',
'                resolve(pData);  // Resuelve la promesa con los datos del servidor',
'',
'            }',
'            ,error: function(err) {',
'                console.error("Error LLAMAR_PROCESO_BYID:", err);',
'                 reject(err);  // Rechaza la promesa en caso de error',
'            }',
'        }',
'    );',
'    });',
'}',
' ',
'',
'function _getFiltrosActivos() {',
'  const filtros = {};',
'  document.querySelectorAll("#report_detail .filtro-input").forEach(inp => {',
'    const col = inp.getAttribute("data-col") || "";',
'    filtros[col] = inp.value;',
'  });',
unistr('  // si usas checks/rangos agrega aqu\00ED lecturas similares'),
'  return filtros;',
'}',
'function _setFiltrosActivos(filtros) {',
'  if (!filtros) return;',
'  document.querySelectorAll("#report_detail .filtro-input").forEach(inp => {',
'    const col = inp.getAttribute("data-col") || "";',
'    if (col in filtros) {',
'      inp.value = filtros[col] ?? "";',
'      inp.dispatchEvent(new Event("input", { bubbles: true }));',
'      inp.dispatchEvent(new Event("change", { bubbles: true }));',
'    }',
'  });',
'}',
'async function ejecutarConBarraCarga(p_filtro) {',
'  try {',
'    const filtros = _getFiltrosActivos();       ',
'    mostrarBarra();',
'    await new Promise((resolve) => {',
'      setTimeout(() => {',
'        f_generatabla(v_JSONGESTION, v_JSONCOLUMNAS, p_filtro);',
'        resolve();',
'      }, 0);',
'    });',
'    _setFiltrosActivos(filtros);                 ',
'  } catch (error) {',
'    console.error("Error al ejecutar f_generatabla:", error);',
'  } finally {',
'    ocultarBarra();',
'  }',
'}',
'',
'function f_cargaOpciones (p_item){',
'	(function () {',
'		function setCol($els, n){',
'			$els.each(function(){',
'				const el = this;',
'				const toRemove = [];',
'				el.classList.forEach(cls => {',
'					if (cls === "col" || cls.indexOf("col-") === 0) toRemove.push(cls);',
'				});',
'				toRemove.forEach(c => el.classList.remove(c));',
'				el.classList.add("col-" + n);',
'			});',
'		}',
'',
'		function apply(){',
'			const $c = $("#"+p_item);',
'			if (!$c.length) return;',
'			setCol($c.find(".t-Form-labelContainer"), 0);',
'			setCol($c.find(".t-Form-inputContainer"), 12);',
'		}',
'',
'		// inicial y tras eventos APEX comunes',
'		$(apply);',
'		$(document).on("apexafterrefresh apexafterclosedialog apexafterpagesubmit", apply);',
'	})();',
'',
'}'))
,p_javascript_code_onload=>wwv_flow_string.join(wwv_flow_t_varchar2(
' $(".t-Button.t-Button--icon.t-Button--header.t-Button--headerTree.is-active").click();',
' f_cargaOpciones("P187_ACTIVIDADES_CONTAINER");',
' f_cargaOpciones("P187_IDDATO_CONTAINER");',
' f_cargaOpciones("P187_ALERTAERROR_CONTAINER");',
' $(secItems).hide();',
' $(secAlerta).hide();'))
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.tr-total{    color: white;    background-color: #689599;}',
'.tr-total-general{    color: white;        background-color: #04891699;',
'    border-bottom: 0.5px solid #04891699;}',
'.nth_child_odd {background-color: #e5e5e5}',
'.nth_child_even {background-color: #ffffff;}',
'.tr-hover:hover {',
'    background-color: #0572ce3b !important;',
'    color: rgba(55, 55, 55, 0.537) !important;',
'    cursor: default;',
'}',
'.color-light-title{color: #000 !important;background-color: #8bc34a !important;}',
'.HAlignRight{text-align: right !important;padding-right: 6px;font-size: 1em;line-height: 0.5em;}',
'.HAlignCenter{text-align: center !important;font-size: 1em;line-height: 0.5em;}',
'td{padding-right:5px;padding-left: 5px;}',
'.t-Report-colHead {',
'    background-color: #e9edee !important;',
'    border: 1px solid black !important; ',
'    ',
'    text-align: center;',
'    color: #0572ce;',
'}',
'#scroll-bottom-inner thead th {',
'    position: sticky;',
'    top: 0;',
'    background-color: #f8f8f8;',
'    z-index: 3;',
'}',
'.tr_secini {',
'   background-color: #0046ff2e;color:red;',
'}',
'.tr_secper {',
'   background-color: #0046ff2e;',
'    color: #9b9b9b;',
'    text-decoration: line-through;',
'}',
'.scroll-container { position: relative; width: 100%; }',
'.scroll-top, .scroll-bottom { overflow-x: auto; overflow-y: hidden; width: 100%; }',
'.scroll-top { height: 20px; /* altura solo para mostrar barra arriba */ }',
'.scroll-bottom { overflow: auto; max-height: 200px; } ',
'.scroll-inner { width: max-content; }',
'/* Solo aplica al item P187_IDDATO con estilo "pill button" */',
unistr('/* Estilo para el radio group P187_IDDATO cuando est\00E1 seleccionado */'),
'input[name="P187_IDDATO"]:checked + label.t-Button {',
'    background-color: #4CAF50;',
'    color: white;',
'    border-color: #4CAF50;',
'}',
'',
'/* Suaviza transiciones */',
'label.t-Button {',
'    transition: background-color 0.3s ease;',
'}',
'',
'.t-Form-labelContainer col col-2{',
'	display:none;',
'}',
'',
'',
'#P187_IDDATO .apex-item-option label {',
'    background-color: purple !important;',
'    color: #04891699 !important;',
'}',
'',
'',
unistr(' /* Cambiar el fondo del bot\00F3n seleccionado SOLO para P187_IDDATO */'),
'#P187_IDDATO .apex-item-option input[type="radio"]:checked + label {',
'    background-color: #04891699 !important;',
'    color: #e6eaec !important;',
'}',
'',
'/* (Opcional) Estilo hover */',
'#P187_IDDATO .apex-item-option label:hover {',
'    background-color: #04891699;',
'    color: #04891699;',
'}',
'',
'.filtro-multiple {',
'    position: relative;',
'    display: inline-block;',
'    width: 100%;',
'}',
'.dropdown-checkboxes {',
'    display: none;',
'    padding: 5px;',
'}',
'.dropdown-checkboxes label {',
'    display: block;',
'    white-space: nowrap;',
'}',
'',
'div.formulario {',
'    border-radius: 3px;',
'    box-shadow: 0 1px 3px 0 rgba(0, 0, 0, 0.2), 0 1px 1px 0 rgba(0, 0, 0, 0.14), 0 2px 1px -1px rgba(0, 0, 0, 0.12);',
'    background: #FFF;',
'    padding: 0px;',
'}'))
,p_page_template_options=>'#DEFAULT#:ui-dialog--stretch:t-Dialog--noPadding'
,p_dialog_chained=>'N'
,p_protection_level=>'C'
,p_page_component_map=>'03'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(215622709827421318)
,p_plug_name=>'New'
,p_region_template_options=>'#DEFAULT#:t-Form--stretchInputs'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(38289497777120142)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_location=>null
,p_menu_id=>wwv_flow_imp.id(37761271469106475)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(37860983999106559)
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(215623080042421321)
,p_plug_name=>'botones'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(38290276266120143)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_03'
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(767716931921178883)
,p_plug_name=>'REGION 1'
,p_title=>'&P187_PERIODO_NOMBRE.'
,p_region_name=>'secRegion1'
,p_region_template_options=>'#DEFAULT#:t-Form--noPadding:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels:margin-top-none:margin-bottom-none:margin-left-none:margin-right-none'
,p_region_attributes=>'STYLE'
,p_plug_template=>wwv_flow_imp.id(38289867500120143)
,p_plug_display_sequence=>20
,p_plug_display_point=>'REGION_POSITION_01'
,p_location=>null
,p_ai_enabled=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(767717908779178893)
,p_plug_name=>'Items'
,p_region_name=>'secItems'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(95503811913299190)
,p_plug_display_sequence=>70
,p_include_in_reg_disp_sel_yn=>'Y'
,p_location=>null
,p_ai_enabled=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(777924604198522609)
,p_plug_name=>'REGION 2'
,p_region_name=>'secDetalle'
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:t-Region--removeHeader:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(37807886111106520)
,p_plug_display_sequence=>60
,p_location=>null
,p_ai_enabled=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(777923656894522600)
,p_name=>'DETALLE'
,p_region_name=>'report_detail'
,p_parent_plug_id=>wwv_flow_imp.id(777924604198522609)
,p_template=>wwv_flow_imp.id(37806762584106520)
,p_display_sequence=>20
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_display_point=>'SUB_REGIONS'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>'SELECT rownum id, D.* FROM DUAL D'
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(37830327650106535)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(227582784762062271)
,p_query_column_id=>1
,p_column_alias=>'ID'
,p_column_display_sequence=>10
,p_column_heading=>'Id'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(227583156791062272)
,p_query_column_id=>2
,p_column_alias=>'DUMMY'
,p_column_display_sequence=>20
,p_column_heading=>'Dummy'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(778564771974650617)
,p_plug_name=>'Alerta'
,p_region_name=>'secAlerta'
,p_region_template_options=>'#DEFAULT#:t-Alert--colorBG:t-Alert--horizontal:t-Alert--defaultIcons:t-Alert--info:t-Alert--removeHeading:t-Form--noPadding:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels:t-Form--labelsAbove:margin-top-none:margin-bottom-none:margin-left-none'
||':margin-right-none'
,p_plug_template=>wwv_flow_imp.id(37782629797106503)
,p_plug_display_sequence=>50
,p_location=>null
,p_ai_enabled=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(215623151585421322)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(215623080042421321)
,p_button_name=>'Cerrar'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860181880106559)
,p_button_image_alt=>'Cerrar'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(227585515874062274)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(215622709827421318)
,p_button_name=>'Exportar'
,p_button_static_id=>'btnExportar'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860056812106557)
,p_button_image_alt=>'Excel'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-file-excel-o'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(214748290278636305)
,p_name=>'P187_NOMBRE'
,p_item_sequence=>230
,p_item_plug_id=>wwv_flow_imp.id(767717908779178893)
,p_prompt=>'Nombre'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(214748375381636306)
,p_name=>'P187_ALIAS'
,p_item_sequence=>240
,p_item_plug_id=>wwv_flow_imp.id(767717908779178893)
,p_prompt=>'Alias'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(215622867859421319)
,p_name=>'P187_EMPTY'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(767716931921178883)
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(37859379436106556)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(239288727386683276)
,p_name=>'P187_TIENEARCHIVOS'
,p_item_sequence=>120
,p_item_plug_id=>wwv_flow_imp.id(767717908779178893)
,p_prompt=>'Tienearchivos'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(262038019019844623)
,p_name=>'P187_IDDATO'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(767716931921178883)
,p_prompt=>'ACTIVIDAD'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'with ',
'      tob as ( SELECT id_tabla tob_id, descripcion tob_descripcion FROM DATA.T_CORP_UDC WHERE activo=''1'' and id_cabecera = ''FINZ_GT02'' AND id_tabla != ''000'' )',
'    , tpr as ( SELECT id_tabla tpr_id, descripcion tpr_descripcion FROM DATA.T_CORP_UDC WHERE activo=''1'' and id_cabecera = ''FINZ_GT01'' AND id_tabla != ''000'' )',
'SELECT cfg.descripcion d,dat.id r',
'FROM t_finz_gestiontributariacfg cfg',
'inner join DATA.t_finz_gestiontributariadatos dat on cfg.id= dat.IDCFG',
'inner join DATA.t_finz_gestiontributariadet det on dat.iddet= det.id',
'INNER JOIN tob ON tob_id = cfg.tipoobjeto',
'INNER JOIN tpr ON tpr_id = cfg.idproceso',
'WHERE 1=1 ',
'and cfg.estado=1',
'and trim(tob_descripcion) !=''RESULTADOS ATS XML''',
'and datosmod is not null',
'ORDER BY  d;'))
,p_cHeight=>1
,p_read_only_when_type=>'ALWAYS'
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--stretchInputs:t-Form-fieldContainer--large:margin-top-none:margin-bottom-none:margin-left-none:margin-right-none'
,p_warn_on_unsaved_changes=>'I'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(277824144609271500)
,p_name=>'P187_TIENERESUMEN'
,p_item_sequence=>130
,p_item_plug_id=>wwv_flow_imp.id(767717908779178893)
,p_prompt=>'Tieneresumen'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(293272075781208590)
,p_name=>'P187_PERIODO'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(767717908779178893)
,p_prompt=>'Periodo'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(350690711548775462)
,p_name=>'P187_MENSAJE'
,p_item_sequence=>140
,p_item_plug_id=>wwv_flow_imp.id(767717908779178893)
,p_prompt=>'Mensaje'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(350691852360775473)
,p_name=>'P187_USUARIO'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(767717908779178893)
,p_prompt=>'Usuario'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(353044595654011192)
,p_name=>'P187_CODDOC_REEMB'
,p_item_sequence=>150
,p_item_plug_id=>wwv_flow_imp.id(767717908779178893)
,p_prompt=>'Coddoc Reemb'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(353044627233011193)
,p_name=>'P187_CODDCT_REEMB'
,p_item_sequence=>170
,p_item_plug_id=>wwv_flow_imp.id(767717908779178893)
,p_prompt=>'Coddct Reemb'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(353045566016011202)
,p_name=>'P187_SERVERDESCARGA'
,p_item_sequence=>180
,p_item_plug_id=>wwv_flow_imp.id(767717908779178893)
,p_prompt=>'Serverdescarga'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(353045912176011206)
,p_name=>'P187_NUMERORCHIVO'
,p_item_sequence=>190
,p_item_plug_id=>wwv_flow_imp.id(767717908779178893)
,p_prompt=>'Numerorchivo'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(399307747280715465)
,p_name=>'P187_TIPO_REEMB'
,p_item_sequence=>160
,p_item_plug_id=>wwv_flow_imp.id(767717908779178893)
,p_prompt=>'Tipo Reemb'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(399777140351230694)
,p_name=>'P187_PERIODO_NOMBRE'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(767716931921178883)
,p_prompt=>'Periodo:'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(408444708030676468)
,p_name=>'P187_FAICON_PROCESOS'
,p_item_sequence=>200
,p_item_plug_id=>wwv_flow_imp.id(767717908779178893)
,p_prompt=>'Faicon Procesos'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(408448523610676506)
,p_name=>'P187_POSICION'
,p_item_sequence=>210
,p_item_plug_id=>wwv_flow_imp.id(767717908779178893)
,p_prompt=>'Posicion'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(443195947646483562)
,p_name=>'P187_EXITO'
,p_item_sequence=>220
,p_item_plug_id=>wwv_flow_imp.id(767717908779178893)
,p_prompt=>'Exito'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(767722204148178961)
,p_name=>'P187_ACTIVIDADES'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(767716931921178883)
,p_use_cache_before_default=>'NO'
,p_prompt=>'PROCESO'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT DESCRIPCION,ID_TABLA FROM "DATA"."T_CORP_UDC" ',
'WHERE ID_CABECERA=''FINZ_GT01'' and ( TO_NUMBER(ID_TABLA) BETWEEN 1 AND 899)',
'and ID_TABLA in (SELECT ITEM FROM TABLE(PK_COMMONS.F_DIVIDIRTEXTO(:P187_ACTIVIDADESPERIODO,'':'') ) )',
'and id_tabla in (select idproceso from t_finz_gestiontributariadet det where det.IDGTB= :P187_IDPERIODO)',
'ORDER BY TO_NUMBER(VALOR3) '))
,p_cHeight=>1
,p_read_only_when_type=>'ALWAYS'
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--stretchInputs:margin-top-none:margin-bottom-none:margin-left-none:margin-right-none'
,p_warn_on_unsaved_changes=>'I'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(767724562036178974)
,p_name=>'P187_IDPERIODO'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(767717908779178893)
,p_prompt=>'Idperiodo'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(767724880637178977)
,p_name=>'P187_ACTIVIDADESPERIODO'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(767717908779178893)
,p_prompt=>'Actividadesperiodo'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(777230898506006975)
,p_name=>'P187_IDREGISTRO'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(767717908779178893)
,p_prompt=>'Idregistro'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(777231675786006983)
,p_name=>'P187_COMPANIA'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(767717908779178893)
,p_prompt=>'Compania'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(778565310315650661)
,p_name=>'P187_ALERTAERROR'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(778564771974650617)
,p_prompt=>'Alertaerror'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(778568966682650673)
,p_name=>'P187_ULREGISTRO'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_imp.id(767717908779178893)
,p_prompt=>'Ulregistro'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(808157801356528609)
,p_name=>'P187_ESTADO_DATO'
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_imp.id(767717908779178893)
,p_prompt=>'Estado Dato'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(227604404592062301)
,p_name=>'LoadPage'
,p_event_sequence=>20
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'ready'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(215622959359421320)
,p_event_id=>wwv_flow_imp.id(227604404592062301)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'console.clear();',
unistr('$(secDetalle).hide();  // Aseg\00FArate que `secDetalle` exista en el \00E1mbito'),
'$(secAlerta).hide();',
'$("#btnRecargar").hide();',
'f_llamarProcesoByID($v("P187_IDDATO")).then((resultado) => {',
'	console.log("ln.10.resultado.tieneDatajson:"+resultado.tieneDatajson);',
'	if(resultado.tieneDatajson==1){',
'		const v_alerta=(resultado.estado===3)? "Proceso: "+apex.item(''P187_ACTIVIDADES'').displayValueFor($v(''P187_ACTIVIDADES''))+"/"+apex.item(''P187_IDDATO'').displayValueFor($v(''P187_IDDATO''))+" Cerrado" :"";',
'		if (resultado.estado===3){$(secAlerta).show();$("#btnAbrirActividad").show();}',
'		if (resultado.estado!==3){',
'			$("#btnCerrarActividad").show();',
'			$("#btnGrabarCambios").show();',
'			$("#btnInsertaRegistroJson").show();',
'			$("#btnRecargar").show();',
'			if ($v("P187_ACTIVIDADES")==="002"){$("#btnIngresarSecuencias").show();$(regSecVenta).show();}',
'			if ($v("P187_ACTIVIDADES")==="003"){$("#btnIngresarSecuencias").show();$(regSecRetencion).show();}',
'		}',
'		$s("P187_ALERTAERROR",v_alerta);',
'		$s("P187_ESTADO_DATO",resultado.estado);',
'		$s("P187_TIENERESUMEN",resultado.tieneresumen);',
'		v_JSONCOLUMNAS=resultado.columnas;',
'		v_JSONCOLUMNASMAYORES=resultado.columnasmayor;',
'		v_JSONGESTION= resultado.gtjson;',
'		/*llamada a la funcion para renderizar la tabla */',
'		let p_filtro=0;',
'		ejecutarConBarraCarga(p_filtro);',
'	}',
'	else{',
unistr('		mensajeError("No se ha seleccionado el origen de informaci\00F3n del proceso");'),
'',
'		return false;',
'	}',
'',
'console.log("sale");	',
'}).catch((error) => { console.error("Hubo un error: " + error);	 console.log("sale con error");return false; });',
''))
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(227604911291062302)
,p_event_id=>wwv_flow_imp.id(227604404592062301)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'$(secDetalle).hide();',
'$("#btnResumen").hide();',
'/*llamada a la funcion para renderizar la tabla */',
'let p_filtro=1;',
'ejecutarConBarraCarga(p_filtro);'))
,p_server_condition_type=>'NEVER'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(227612325689062308)
,p_name=>'Exportar'
,p_event_sequence=>80
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(227585515874062274)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(227612869612062308)
,p_event_id=>wwv_flow_imp.id(227612325689062308)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'let precesoSeleccionado = $("#P187_ACTIVIDADES_DISPLAY").text().trim();',
'let datoSeleccionado    = $("#P187_IDDATO_DISPLAY").text().trim();',
'',
'',
'const cadena = precesoSeleccionado+"_"+datoSeleccionado;',
'const cadenaSinEspacios = cadena.replace(/ /g, "_");',
'',
'exportTabla2Xlsx(cadenaSinEspacios ,''report_detail'',"DATOS_TABLA",v_JSONCOLUMNAS);'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(215623275674421323)
,p_name=>'New'
,p_event_sequence=>90
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(215623151585421322)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(215623393211421324)
,p_event_id=>wwv_flow_imp.id(215623275674421323)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CLOSE'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(227600431013062295)
,p_process_sequence=>10
,p_process_point=>'AFTER_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'SetupPage'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare V_Actividad varchar2(3999);',
'begin',
'    :P187_COMPANIA:=:g_COMPANIA;',
'	:P187_USUARIO:=:APP_USER;',
'    begin',
'        SELECT ACTIVIDADES,PERIODO INTO :P187_ACTIVIDADESPERIODO,:P187_PERIODO FROM T_FINZ_GESTIONTRIBUTARIA where id =:P187_IDPERIODO;',
'    exception when others then ',
'        null;',
'    end;',
'    :G_GT_VALJSON:='''';',
'	:P187_PERIODO_NOMBRE:=REPLACE(to_char(to_date(:P187_PERIODO,''YYYYMM''),''Month/YYYY''),'' '','''') ;',
'	:P187_IDDATO:=:P187_IDDATO;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>227600431013062295
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(227598432883062291)
,p_process_sequence=>10
,p_process_point=>'ON_DEMAND'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'LLAMAR_PROCESO_BYID'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    l_result VARCHAR2(4000);',
'    v_datid number;',
'    v_gtjson nclob;',
'    v_estado number;',
'    v_columnas nclob ;         ',
'    v_columnasmayor clob;       ',
'    v_tieneresumen varchar2(5);',
'    v_secuenciad1 number;',
'    v_secuenciafn number;',
'    v_secuenciafe number;',
'    v_secuenciafd number;',
'    v_secuenciart number;',
'	v_tieneDatajson number;',
'BEGIN',
'    apex_json.open_object;',
'	v_datid:=apex_application.g_x01;',
unistr('    -- Llama a la funci\00F3n con los par\00E1metros que recibir\00E1 del lado del cliente'),
'	 PK_FINZ_GESTIONTRIBUTARIA.sp_extrae_informacion_json_byid(',
'		p_datid  => v_datid,',
'        p_gtjson => v_gtjson,',
'        p_estado => v_estado,',
'        p_columnas => v_columnas,',
'        p_columnasCtsMay => v_columnasmayor,',
'        p_tieneresumen => v_tieneresumen,',
'        p_secuenciad1 => v_secuenciad1,',
'        p_secuenciafn => v_secuenciafn,',
'        p_secuenciafe => v_secuenciafe,',
'        p_secuenciafd => v_secuenciafd,',
'        p_secuenciart => v_secuenciart',
'    );',
' ',
'	v_tieneDatajson:=case when DBMS_LOB.GETLENGTH(v_gtjson)>0 then 1 else 0 end;',
'    -- Devuelve el resultado para el lado del cliente',
'	apex_json.write( p_name => ''gtjson'', p_value =>v_gtjson);',
'	apex_json.write( p_name => ''estado'', p_value =>v_estado);',
'	apex_json.write( p_name => ''columnas'', p_value =>v_columnas);',
'	apex_json.write( p_name => ''tieneresumen'', p_value =>v_tieneresumen);',
'	apex_json.write( p_name => ''columnasmayor'', p_value =>v_columnasmayor);',
'	apex_json.write( p_name => ''secuenciad1'', p_value =>v_secuenciad1);',
'	apex_json.write( p_name => ''secuenciafn'', p_value =>v_secuenciafn);',
'	apex_json.write( p_name => ''secuenciafe'', p_value =>v_secuenciafe);',
'	apex_json.write( p_name => ''secuenciafd'', p_value =>v_secuenciafd);',
'	apex_json.write( p_name => ''secuenciart'', p_value =>v_secuenciart);',
'	apex_json.write( p_name => ''tieneDatajson'', p_value =>v_tieneDatajson);',
' ',
'',
'    apex_json.close_object;',
'END;',
'',
'',
''))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>227598432883062291
);
wwv_flow_imp.component_end;
end;
/
