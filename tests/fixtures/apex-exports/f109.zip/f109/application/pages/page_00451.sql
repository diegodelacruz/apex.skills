prompt --application/pages/page_00451
begin
--   Manifest
--     PAGE: 00451
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>109
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_page.create_page(
 p_id=>451
,p_name=>'PYG INDUSTRIALES - DLG - BASE DISTRIBUCION'
,p_alias=>'PYG-INDUSTRIALES-DLG-BASE-DISTRIBUCION'
,p_page_mode=>'MODAL'
,p_step_title=>unistr('Base de Distribuci\00F3n')
,p_autocomplete_on_off=>'OFF'
,p_javascript_code_onload=>wwv_flow_string.join(wwv_flow_t_varchar2(
'var regiones = [',
'    "tbBaseDistribucion"',
'];',
'for (var i = 0; i < regiones.length; i++) {',
'    var region = apex.region(regiones[i]);',
'',
'    if (region) {',
'        let grid = region.widget();',
'        let actions = grid.interactiveGrid("getActions");',
'        actions.hide("save");',
'    }',
'}',
'',
'$(secItems).hide();'))
,p_step_template=>wwv_flow_imp.id(37774372912106498)
,p_page_template_options=>'#DEFAULT#:t-Dialog--noPadding'
,p_dialog_width=>'60%'
,p_dialog_css_classes=>'dlg-sin-cerrar'
,p_dialog_chained=>'N'
,p_protection_level=>'C'
,p_page_component_map=>'21'
,p_created_on=>wwv_flow_imp.dz('20260303160349Z')
,p_last_updated_on=>wwv_flow_imp.dz('20260327023209Z')
,p_created_by=>'DDELACRUZ'
,p_last_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(367597012876845850)
,p_plug_name=>'Barra de Accion'
,p_region_template_options=>'#DEFAULT#:t-Form--stretchInputs'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(38289497777120142)
,p_plug_display_sequence=>20
,p_plug_display_point=>'REGION_POSITION_01'
,p_location=>null
,p_menu_id=>wwv_flow_imp.id(37761271469106475)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(37860983999106559)
,p_created_on=>wwv_flow_imp.dz('20260303160816Z')
,p_updated_on=>wwv_flow_imp.dz('20260303160816Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(376249233525576903)
,p_plug_name=>'Items'
,p_region_name=>'secItems'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(38289867500120143)
,p_plug_display_sequence=>40
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
,p_created_on=>wwv_flow_imp.dz('20260303164648Z')
,p_updated_on=>wwv_flow_imp.dz('20260325193011Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(404655436577870715)
,p_plug_name=>'Encabezado'
,p_title=>'Asientos de:'
,p_region_name=>'rgEncabezado'
,p_region_template_options=>'#DEFAULT#:t-Form--noPadding:t-Form--xlarge:t-Form--stretchInputs:t-Form--leftLabels:margin-top-none:margin-bottom-none:margin-left-none:margin-right-none'
,p_region_attributes=>'style ="padding: 0;"'
,p_plug_template=>wwv_flow_imp.id(38289867500120143)
,p_plug_display_sequence=>10
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
,p_created_on=>wwv_flow_imp.dz('20260325193011Z')
,p_updated_on=>wwv_flow_imp.dz('20260325194417Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(741575303976203337)
,p_plug_name=>'BASE_DE_DISTRIBUCION'
,p_title=>'BASE DE DISTRIBUCION'
,p_region_name=>'tbBaseDistribucion'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(37806762584106520)
,p_plug_display_sequence=>20
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select     SEQ_ID,  ',
'    C001, ',
'    C002, ',
'    C003, ',
'    C004, ',
'    C005, ',
'    C006,',
'    C007,',
'    C008,',
'    C009,',
'    C020',
'FROM APEX_COLLECTIONS ',
'WHERE COLLECTION_NAME = ''COLECCION_REGLASBASD''',
' '))
,p_plug_source_type=>'NATIVE_IG'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'BASE DE DISTRIBUCION'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
,p_ai_enabled=>false
,p_created_on=>wwv_flow_imp.dz('20260303160504Z')
,p_updated_on=>wwv_flow_imp.dz('20260327023209Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_region_column_group(
 p_id=>wwv_flow_imp.id(741577182706203356)
,p_heading=>'Condicionantes'
,p_label=>'Condicionantes'
,p_updated_on=>wwv_flow_imp.dz('20260303160504Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(741575506732203339)
,p_name=>'APEX$ROW_SELECTOR'
,p_session_state_data_type=>'VARCHAR2'
,p_item_type=>'NATIVE_ROW_SELECTOR'
,p_display_sequence=>10
,p_attribute_01=>'Y'
,p_attribute_02=>'Y'
,p_attribute_03=>'N'
,p_updated_on=>wwv_flow_imp.dz('20260303160504Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(741575633122203340)
,p_name=>'APEX$ROW_ACTION'
,p_session_state_data_type=>'VARCHAR2'
,p_item_type=>'NATIVE_ROW_ACTION'
,p_display_sequence=>20
,p_updated_on=>wwv_flow_imp.dz('20260303160504Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(741575757623203341)
,p_name=>'SEQ_ID'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'SEQ_ID'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_DISPLAY_ONLY'
,p_heading=>'Seq Id'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>30
,p_value_alignment=>'LEFT'
,p_attribute_02=>'VALUE'
,p_attribute_05=>'PLAIN'
,p_enable_filter=>false
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_enable_hide=>false
,p_is_primary_key=>true
,p_duplicate_value=>true
,p_include_in_export=>false
,p_updated_on=>wwv_flow_imp.dz('20260303160504Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(741575801047203342)
,p_name=>'C001'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'C001'
,p_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_SELECT_LIST'
,p_heading=>'Tipo Base'
,p_heading_alignment=>'CENTER'
,p_display_sequence=>40
,p_value_alignment=>'LEFT'
,p_is_required=>true
,p_lov_type=>'SHARED'
,p_lov_id=>wwv_flow_imp.id(121710145807591205)
,p_lov_display_extra=>true
,p_lov_display_null=>true
,p_lov_null_text=>'Seleccione'
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'LOV'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_default_type=>'SQL_QUERY'
,p_default_expression=>'SELECT ''BD'' FROM DUAL'
,p_duplicate_value=>true
,p_include_in_export=>true
,p_updated_on=>wwv_flow_imp.dz('20260327022144Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(741575886149203343)
,p_name=>'C002'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'C002'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_SELECT_LIST'
,p_heading=>'Nivel 01'
,p_heading_alignment=>'CENTER'
,p_display_sequence=>60
,p_value_alignment=>'LEFT'
,p_group_id=>wwv_flow_imp.id(741577182706203356)
,p_use_group_for=>'BOTH'
,p_is_required=>true
,p_lov_type=>'SHARED'
,p_lov_id=>wwv_flow_imp.id(119193859528059131)
,p_lov_display_extra=>true
,p_lov_display_null=>true
,p_lov_null_text=>'Seleccione'
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'LOV'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
,p_updated_on=>wwv_flow_imp.dz('20260303160504Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(741576034879203344)
,p_name=>'C003'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'C003'
,p_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_CHECKBOX'
,p_heading=>'Nivel 02'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>70
,p_value_alignment=>'LEFT'
,p_group_id=>wwv_flow_imp.id(741577182706203356)
,p_use_group_for=>'BOTH'
,p_attribute_01=>'1'
,p_is_required=>false
,p_lov_type=>'SHARED'
,p_lov_id=>wwv_flow_imp.id(119194387269080626)
,p_lov_display_extra=>true
,p_lov_cascade_parent_items=>'C002'
,p_ajax_items_to_submit=>'C002'
,p_ajax_optimize_refresh=>true
,p_multi_value_type=>'SEPARATED'
,p_multi_value_separator=>','
,p_filter_is_required=>false
,p_use_as_row_header=>false
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
,p_escape_on_http_output=>true
,p_updated_on=>wwv_flow_imp.dz('20260304152018Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(741576137476203345)
,p_name=>'C004'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'C004'
,p_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_SELECT_LIST'
,p_heading=>'Obj. Origen'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>50
,p_value_alignment=>'LEFT'
,p_is_required=>false
,p_lov_type=>'SHARED'
,p_lov_id=>wwv_flow_imp.id(142729312902456972)
,p_lov_display_extra=>false
,p_lov_display_null=>false
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'SHARED'
,p_filter_lov_id=>wwv_flow_imp.id(142729312902456972)
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_default_type=>'SQL_QUERY'
,p_default_expression=>'SELECT ''DATA.VT_FINZ_DISTRIBUCIONTMP_MES'' FROM DUAL'
,p_duplicate_value=>true
,p_include_in_export=>true
,p_updated_on=>wwv_flow_imp.dz('20260327022436Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(741576206728203346)
,p_name=>'C005'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'C005'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>'Cols. Origen'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>110
,p_value_alignment=>'LEFT'
,p_attribute_05=>'BOTH'
,p_attribute_06=>'UPPER'
,p_is_required=>false
,p_max_length=>4000
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
,p_updated_on=>wwv_flow_imp.dz('20260303160504Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(741576354842203347)
,p_name=>'C006'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'C006'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_SELECT_LIST'
,p_heading=>'Obj. Destino'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>120
,p_value_alignment=>'LEFT'
,p_is_required=>false
,p_lov_type=>'SHARED'
,p_lov_id=>wwv_flow_imp.id(142729312902456972)
,p_lov_display_extra=>true
,p_lov_display_null=>true
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'LOV'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
,p_updated_on=>wwv_flow_imp.dz('20260303160504Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(741576432023203348)
,p_name=>'C007'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'C007'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>'Cols. Destino'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>130
,p_value_alignment=>'LEFT'
,p_attribute_05=>'BOTH'
,p_attribute_06=>'UPPER'
,p_is_required=>false
,p_max_length=>4000
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
,p_updated_on=>wwv_flow_imp.dz('20260303160504Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(741576735923203351)
,p_name=>'C020'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'C020'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>'Comentario (Opcional)'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>140
,p_value_alignment=>'LEFT'
,p_attribute_05=>'BOTH'
,p_attribute_06=>'UPPER'
,p_is_required=>false
,p_max_length=>4000
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
,p_updated_on=>wwv_flow_imp.dz('20260303160504Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(741576866089203353)
,p_name=>'C008'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'C008'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>'Condicion 1'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>80
,p_value_alignment=>'LEFT'
,p_group_id=>wwv_flow_imp.id(741577182706203356)
,p_use_group_for=>'BOTH'
,p_attribute_05=>'BOTH'
,p_is_required=>false
,p_max_length=>4000
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
,p_updated_on=>wwv_flow_imp.dz('20260303160504Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(741576991648203354)
,p_name=>'C009'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'C009'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>'Condicion 2'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>90
,p_value_alignment=>'LEFT'
,p_group_id=>wwv_flow_imp.id(741577182706203356)
,p_use_group_for=>'BOTH'
,p_attribute_05=>'BOTH'
,p_is_required=>false
,p_max_length=>4000
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
,p_updated_on=>wwv_flow_imp.dz('20260303160504Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_interactive_grid(
 p_id=>wwv_flow_imp.id(741575412840203338)
,p_internal_uid=>741575412840203338
,p_is_editable=>true
,p_edit_operations=>'i:u:d'
,p_lost_update_check_type=>'VALUES'
,p_add_row_if_empty=>false
,p_submit_checked_rows=>false
,p_lazy_loading=>false
,p_requires_filter=>false
,p_select_first_row=>false
,p_fixed_row_height=>true
,p_pagination_type=>'SCROLL'
,p_show_total_row_count=>false
,p_show_toolbar=>true
,p_enable_save_public_report=>false
,p_enable_subscriptions=>true
,p_enable_flashback=>false
,p_define_chart_view=>false
,p_enable_download=>false
,p_download_formats=>null
,p_fixed_header=>'PAGE'
,p_show_icon_view=>false
,p_show_detail_view=>false
,p_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'function (config) {',
'	return cargarToolbar(config);',
'}',
''))
,p_updated_on=>wwv_flow_imp.dz('20260327023209Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_ig_report(
 p_id=>wwv_flow_imp.id(741593408599213233)
,p_interactive_grid_id=>wwv_flow_imp.id(741575412840203338)
,p_static_id=>'3653572'
,p_type=>'PRIMARY'
,p_default_view=>'GRID'
,p_rows_per_page=>1000
,p_show_row_number=>false
,p_settings_area_expanded=>true
,p_updated_on=>wwv_flow_imp.dz('20260327022919Z')
,p_updated_by=>'EMASABANDA'
);
wwv_flow_imp_page.create_ig_report_view(
 p_id=>wwv_flow_imp.id(741593656943213240)
,p_report_id=>wwv_flow_imp.id(741593408599213233)
,p_view_type=>'GRID'
,p_stretch_columns=>true
,p_srv_exclude_null_values=>false
,p_srv_only_display_columns=>true
,p_edit_mode=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(741594790101213266)
,p_view_id=>wwv_flow_imp.id(741593656943213240)
,p_display_seq=>1
,p_column_id=>wwv_flow_imp.id(741575633122203340)
,p_is_visible=>true
,p_is_frozen=>true
,p_width=>40
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(741595771724213282)
,p_view_id=>wwv_flow_imp.id(741593656943213240)
,p_display_seq=>2
,p_column_id=>wwv_flow_imp.id(741575757623203341)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>58
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(741596674303213288)
,p_view_id=>wwv_flow_imp.id(741593656943213240)
,p_display_seq=>6
,p_column_id=>wwv_flow_imp.id(741575801047203342)
,p_is_visible=>false
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(741597525490213293)
,p_view_id=>wwv_flow_imp.id(741593656943213240)
,p_display_seq=>3
,p_column_id=>wwv_flow_imp.id(741575886149203343)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>250
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(741598492773213299)
,p_view_id=>wwv_flow_imp.id(741593656943213240)
,p_display_seq=>4
,p_column_id=>wwv_flow_imp.id(741576034879203344)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>250
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(741599445051213305)
,p_view_id=>wwv_flow_imp.id(741593656943213240)
,p_display_seq=>7
,p_column_id=>wwv_flow_imp.id(741576137476203345)
,p_is_visible=>false
,p_is_frozen=>false
,p_width=>156
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(741600297356213310)
,p_view_id=>wwv_flow_imp.id(741593656943213240)
,p_display_seq=>10
,p_column_id=>wwv_flow_imp.id(741576206728203346)
,p_is_visible=>false
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(741601221778213316)
,p_view_id=>wwv_flow_imp.id(741593656943213240)
,p_display_seq=>11
,p_column_id=>wwv_flow_imp.id(741576354842203347)
,p_is_visible=>false
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(741602156944213322)
,p_view_id=>wwv_flow_imp.id(741593656943213240)
,p_display_seq=>12
,p_column_id=>wwv_flow_imp.id(741576432023203348)
,p_is_visible=>false
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(741604843029213336)
,p_view_id=>wwv_flow_imp.id(741593656943213240)
,p_display_seq=>5
,p_column_id=>wwv_flow_imp.id(741576735923203351)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(741769689388641271)
,p_view_id=>wwv_flow_imp.id(741593656943213240)
,p_display_seq=>8
,p_column_id=>wwv_flow_imp.id(741576866089203353)
,p_is_visible=>false
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(741770642922641287)
,p_view_id=>wwv_flow_imp.id(741593656943213240)
,p_display_seq=>9
,p_column_id=>wwv_flow_imp.id(741576991648203354)
,p_is_visible=>false
,p_is_frozen=>false
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1161195442179479621)
,p_plug_name=>'Botones'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(38290276266120143)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_03'
,p_location=>null
,p_ai_enabled=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
,p_created_on=>wwv_flow_imp.dz('20260311162941Z')
,p_updated_on=>wwv_flow_imp.dz('20260311163025Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(387567442574056215)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(1161195442179479621)
,p_button_name=>'Cerrar'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860181880106559)
,p_button_image_alt=>'Cerrar'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-arrow-left'
,p_created_on=>wwv_flow_imp.dz('20260311162941Z')
,p_updated_on=>wwv_flow_imp.dz('20260311163025Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(376253294027576943)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(367597012876845850)
,p_button_name=>'Guardar'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860056812106557)
,p_button_image_alt=>'Guardar'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_icon_css_classes=>'fa-save'
,p_created_on=>wwv_flow_imp.dz('20260310141411Z')
,p_updated_on=>wwv_flow_imp.dz('20260310141411Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(376249398960576904)
,p_name=>'P451_SEQ_ID'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(376249233525576903)
,p_prompt=>'Seq Id'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_created_on=>wwv_flow_imp.dz('20260303164649Z')
,p_updated_on=>wwv_flow_imp.dz('20260303164702Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(376252551183576936)
,p_name=>'P451_CLOB'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(376249233525576903)
,p_prompt=>'Clob'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_created_on=>wwv_flow_imp.dz('20260309190916Z')
,p_updated_on=>wwv_flow_imp.dz('20260309190916Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(404654052634870701)
,p_name=>'P451_NUMREGLA'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(376249233525576903)
,p_prompt=>'Numregla'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_created_on=>wwv_flow_imp.dz('20260325185331Z')
,p_updated_on=>wwv_flow_imp.dz('20260325185331Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(404655552765870716)
,p_name=>'P451_NIVEL_1'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(404655436577870715)
,p_prompt=>'Nivel 1'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'LOV_PYG_NIVEL01'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT  TRIM(DRKY) || '' - '' || DRDL01 D, TRIM(DRKY) R ',
'FROM VT_JDE_UDC ',
'WHERE DRSY=''09'' AND DRRT IN (''41'') AND TRIM(DRKY) IS NOT NULL ',
'ORDER BY DRRT, TO_NUMBER(TRIM(DRKY))'))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_read_only_when_type=>'ALWAYS'
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'NONE'
,p_created_on=>wwv_flow_imp.dz('20260325193011Z')
,p_updated_on=>wwv_flow_imp.dz('20260325194057Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(404655624223870717)
,p_name=>'P451_NIVEL_2'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(404655436577870715)
,p_prompt=>'Nivel 2'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'LOV_PYG_NIVEL02'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT  TRIM(DRKY) || '' - '' || DRDL01 D, TRIM(DRKY) R ',
'FROM VT_JDE_UDC ',
'WHERE DRSY=''09'' AND DRRT IN (''42'') AND TRIM(DRKY) IS NOT NULL ',
'ORDER BY DRRT, TO_NUMBER(TRIM(DRKY))'))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_read_only_when_type=>'ALWAYS'
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'NONE'
,p_created_on=>wwv_flow_imp.dz('20260325193011Z')
,p_updated_on=>wwv_flow_imp.dz('20260325194057Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(376253913678576950)
,p_name=>'Cerrar'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(387567442574056215)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
,p_created_on=>wwv_flow_imp.dz('20260310162411Z')
,p_updated_on=>wwv_flow_imp.dz('20260311163025Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(386064148458380801)
,p_event_id=>wwv_flow_imp.id(376253913678576950)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CLOSE'
,p_created_on=>wwv_flow_imp.dz('20260310162411Z')
,p_updated_on=>wwv_flow_imp.dz('20260310163031Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(376242971992553376)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_region_id=>wwv_flow_imp.id(741575303976203337)
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'basse de distribucion'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare ',
'    v_APEXROW_STATUS varchar2(399);',
'    v_nombrecoleccion varchar2(399):=''COLECCION_REGLASBASD'';',
'BEGIN',
'    v_APEXROW_STATUS:=:APEX$ROW_STATUS;',
'    case v_APEXROW_STATUS  ',
'        WHEN ''C'' THEN APEX_COLLECTION.ADD_MEMBER   (p_collection_name => v_nombrecoleccion                 ,p_C001=>trim(upper(:C001)),p_C002=>trim(upper(:C002)),p_C003=>trim(upper(:C003)),p_C004=>trim(upper(:C004)),p_C005=>trim(upper(:C005)),p_C006='
||'>trim(upper(:C006)),p_C007=>trim(upper(:C007)),p_C008=>trim(upper(:C008)),p_C009=>trim(upper(:C009)),p_C020=>trim(upper(:C020)));',
'        WHEN ''U'' THEN APEX_COLLECTION.UPDATE_MEMBER(p_collection_name => v_nombrecoleccion,p_seq => :seq_id,p_C001=>trim(upper(:C001)),p_C002=>trim(upper(:C002)),p_C003=>trim(upper(:C003)),p_C004=>trim(upper(:C004)),p_C005=>trim(upper(:C005)),p_C006='
||'>trim(upper(:C006)),p_C007=>trim(upper(:C007)),p_C008=>trim(upper(:C008)),p_C009=>trim(upper(:C009)),p_C020=>trim(upper(:C020)));',
'        WHEN ''D'' THEN APEX_COLLECTION.DELETE_MEMBER(p_collection_name => v_nombrecoleccion,p_seq => :seq_id);',
'    END CASE;',
'END;',
''))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_only_for_changed_rows=>'N'
,p_internal_uid=>376242971992553376
,p_created_on=>wwv_flow_imp.dz('20260303160619Z')
,p_updated_on=>wwv_flow_imp.dz('20260325185525Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(376250236478576913)
,p_process_sequence=>50
,p_process_point=>'AFTER_SUBMIT'
,p_region_id=>wwv_flow_imp.id(741575303976203337)
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'DATOS'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare ',
'    v_APEXROW_STATUS varchar2(399);',
'	l_rec  apex_collections%ROWTYPE;',
'	l_json_final CLOB;',
'	l_json  CLOB;',
'BEGIN',
' ',
'     SELECT JSON_ARRAYAGG(',
'           JSON_OBJECT(',
'             ''FLAG''      VALUE collection_name,',
'             ''ID''        VALUE seq_id,',
'             ''TIPOVENTA'' VALUE c001,''NIVEL01''   VALUE c002,',
'             ''NIVEL02''   VALUE c003,''OBJORIG''   VALUE c004,',
'             ''COLSORIG''  VALUE c005,''OBJDEST''   VALUE c006,',
'             ''COLSDEST''  VALUE c007,''CONDIC1''   VALUE c008,',
'             ''CONDIC2''   VALUE c009,''COMENTARI'' VALUE c020',
'           RETURNING CLOB)',
'         RETURNING CLOB',
'         )',
'    INTO l_json_final',
'    FROM apex_collections',
'   WHERE collection_name = ''COLECCION_REGLASBASD'';',
'',
'   SELECT *',
'   INTO   l_rec',
'   FROM   apex_collections',
'   WHERE  collection_name = ''COLECCION_REGLAS''||:P451_NUMREGLA||''DIST''',
'   AND    seq_id = :P451_SEQ_ID;',
'',
'',
'   APEX_COLLECTION.UPDATE_MEMBER(',
'       p_collection_name => ''COLECCION_REGLAS''||:P451_NUMREGLA||''DIST'',',
'       p_seq             => :P451_SEQ_ID,',
'       p_c001            => l_rec.c001,p_c002            => l_rec.c002,',
'       p_c003            => l_rec.c003,p_c004            => l_rec.c004,',
'       p_c005            => l_rec.c005,p_c006            => l_rec.c006,',
'       p_c007            => l_rec.c007,p_c008            => l_rec.c008,',
'       p_c009            => l_rec.c009,p_c010            => l_rec.c010,',
'       p_c011            => l_rec.c011,p_c012            => l_rec.c012,',
'       p_c013            => l_rec.c013,p_c014            => l_rec.c014,',
'       p_c015            => l_rec.c015,',
'	   p_clob001         => l_json_final,',
'	   p_c021            => l_rec.c021',
'   );',
'	BEGIN',
'	    l_json:= pk_finz_distribucion.f_traer_jsonReglasDist(:P447_REGLANUMERO);',
'	    IF(:P451_NUMREGLA=1)THEN :G_VALOR1  := l_json;END IF;',
'	    IF(:P451_NUMREGLA=2)THEN :G_VALOR2  := l_json;END IF;',
'	    IF(:P451_NUMREGLA=3)THEN :G_VALOR3  := l_json;END IF;',
'	    IF(:P451_NUMREGLA=4)THEN :G_VALOR4  := l_json;END IF;',
'	    IF(:P451_NUMREGLA=5)THEN :G_VALOR5  := l_json;END IF;',
' ',
'	END;   ',
'END;',
'',
''))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_success_message=>'Datos almacenados correctamente'
,p_internal_uid=>376250236478576913
,p_created_on=>wwv_flow_imp.dz('20260303174908Z')
,p_updated_on=>wwv_flow_imp.dz('20260325185453Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(376250140645576912)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Setup Interface'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE ',
'',
'	l_rec  apex_collections%ROWTYPE;',
'BEGIN',
'	:P451_NUMREGLA:=:G_VALORRGN;',
'	begin',
'		SELECT *',
'		INTO   l_rec',
'		FROM   apex_collections',
'		WHERE  collection_name = ''COLECCION_REGLAS''||:P451_NUMREGLA||''DIST''',
'		AND    seq_id = :P451_SEQ_ID;',
'	exception when others then',
'		NULL;',
'	end;',
'	:P451_NIVEL_1:=l_rec.C002;',
'	:P451_NIVEL_2:=l_rec.C003;',
'	IF APEX_COLLECTION.COLLECTION_EXISTS(''COLECCION_REGLASBASD'') THEN APEX_COLLECTION.DELETE_COLLECTION(''COLECCION_REGLASBASD''); END IF;',
'	IF NOT  APEX_COLLECTION.COLLECTION_EXISTS(''COLECCION_REGLASBASD'') THEN APEX_COLLECTION.CREATE_COLLECTION  (''COLECCION_REGLASBASD''); END IF;',
'	IF      APEX_COLLECTION.COLLECTION_EXISTS(''COLECCION_REGLASBASD'') THEN APEX_COLLECTION.TRUNCATE_COLLECTION(''COLECCION_REGLASBASD''); END IF;',
'',
'		FOR COLS IN ( ',
'	        SELECT ',
'	             ID',
'	            ,TIPOVENTA 	C001',
'	            ,NIVEL01 	C002',
'	            ,NIVEL02 	C003',
'	            ,OBJORIG 	c004',
'	            ,COLSORIG   C005',
'	            ,OBJDEST   	C006',
'	            ,COLSDEST  	C007',
'	            ,CONDIC1 	C008',
'	            ,CONDIC2 	C009 ',
'	            ,COMENTARI c020',
'	        FROM JSON_TABLE( l_rec.clob001,''$[*]''',
'	            COLUMNS (',
'	                ID          NUMBER         PATH ''$.ID''',
'	                ,TIPOVENTA  VARCHAR2(3999) PATH ''$.TIPOVENTA''',
'	                ,NIVEL01   	VARCHAR2(3999) PATH ''$.NIVEL01''',
'	                ,NIVEL02   	VARCHAR2(3999) PATH ''$.NIVEL02''',
'	                ,OBJORIG    VARCHAR2(3999) PATH ''$.OBJORIG''',
'	                ,COLSORIG   VARCHAR2(3999) PATH ''$.COLSORIG''',
'	                ,OBJDEST   	VARCHAR2(3999) PATH ''$.OBJDEST''',
'	                ,COLSDEST   VARCHAR2(3999) PATH ''$.COLSDEST''',
'	                ,CONDIC1  	VARCHAR2(3999) PATH ''$.CONDIC1''',
'	                ,CONDIC2   	VARCHAR2(3999) PATH ''$.CONDIC2''',
'					,COMENTARI 	VARCHAR2(3999) PATH ''$.COMENTARI''',
'	                 ',
'	            )',
'	        ) ORDER BY ID',
'		)',
'		LOOP',
'	        APEX_COLLECTION.ADD_MEMBER(',
'	            p_collection_name =>''COLECCION_REGLASBASD'',',
'	            p_c001 => COLS.c001,',
'	            p_c002 => COLS.c002,',
'	            p_c003 => COLS.c003,',
'	            p_c004 => COLS.c004,',
'	            p_c005 => COLS.c005,',
'	            p_c006 => COLS.c006,',
'	            p_c007 => COLS.c007,',
'	            p_c008 => COLS.c008,',
'	            p_c009 => COLS.c009,',
'	            p_c020 => COLS.c020',
'	        );',
'	    END LOOP;',
'',
'END;',
''))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>376250140645576912
,p_created_on=>wwv_flow_imp.dz('20260303172926Z')
,p_updated_on=>wwv_flow_imp.dz('20260325193542Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp.component_end;
end;
/
