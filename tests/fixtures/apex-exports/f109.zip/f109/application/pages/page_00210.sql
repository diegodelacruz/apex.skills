prompt --application/pages/page_00210
begin
--   Manifest
--     PAGE: 00210
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>109
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_page.create_page(
 p_id=>210
,p_name=>'Carga Estado de Cuenta'
,p_step_title=>'Carga Estado de Cuenta'
,p_autocomplete_on_off=>'OFF'
,p_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'function ejecutarPantalla() ',
'{',
'',
unistr('//   if(confirm(''Su dep\00F3sito es por $ ''||:P70_TOTDEPOSITO||''Est\00E1 seguro de procesar el registro?''))'),
' // {',
'',
'javascript:apex.submit(''ACEPTAR_DEPOSITO'');',
'jsRemoveWindowLoad();',
'jsShowWindowLoad("Procesando registros espere por favor...");',
'',
'',
'//};',
'',
'};',
'',
'',
'function jsRemoveWindowLoad() {',
'    // eliminamos el div que bloquea pantalla',
'    $("#WindowLoad").remove();',
' ',
'};',
' ',
'function jsShowWindowLoad(mensaje) {',
'    //eliminamos si existe un div ya bloqueando',
'    jsRemoveWindowLoad();',
' ',
'    //si no enviamos mensaje se pondra este por defecto',
unistr('    if (mensaje === undefined) mensaje = "Procesando la informaci\00F3n<br>Espere por favor";'),
' ',
'    //centrar imagen gif',
'    height = 20;//El div del titulo, para que se vea mas arriba (H)',
'    var ancho = 0;',
'    var alto = 0;',
' ',
'    //obtenemos el ancho y alto de la ventana de nuestro navegador, compatible con todos los navegadores',
'    if (window.innerWidth == undefined) ancho = window.screen.width;',
'    else ancho = window.innerWidth;',
'    if (window.innerHeight == undefined) alto = window.screen.height;',
'    else alto = window.innerHeight;',
' ',
unistr('    //operaci\00F3n necesaria para centrar el div que muestra el mensaje'),
'    var heightdivsito = alto/2 - parseInt(height)/2;//Se utiliza en el margen superior, para centrar',
' ',
'   //imagen que aparece mientras nuestro div es mostrado y da apariencia de cargando',
'    imgCentro = "<div style=''text-align:center;height:" + alto + "px;''><div  style=''color:#0000ff;margin-top:" + heightdivsito + "px; font-size:20px;font-weight:bold''>" + mensaje + "</div><img  src=''#APP_IMAGES#BAR.gif''></div>";',
' ',
'        //creamos el div que bloquea grande------------------------------------------',
'        div = document.createElement("div");',
'        div.id = "WindowLoad"',
'        div.style.width = ancho + "px";',
'        div.style.height = alto + "px";',
'        $("body").append(div);',
' ',
'        //creamos un input text para que el foco se plasme en este y el usuario no pueda escribir en nada de atras',
'        input = document.createElement("input");',
'        input.id = "focusInput";',
'        input.type = "text"',
' ',
'        //asignamos el div que bloquea',
'        $("#WindowLoad").append(input);',
' ',
'        //asignamos el foco y ocultamos el input text',
'        $("#focusInput").focus();',
'        $("#focusInput").hide();',
' ',
'        //centramos el div del texto',
'        $("#WindowLoad").html(imgCentro);',
' ',
'};'))
,p_page_template_options=>'#DEFAULT#'
,p_page_component_map=>'03'
,p_created_on=>wwv_flow_imp.dz('20240826203228Z')
,p_last_updated_on=>wwv_flow_imp.dz('20260526143036Z')
,p_last_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(479069159641602428)
,p_plug_name=>unistr('Informaci\00F3n')
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(38289867500120143)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(480010723123982732)
,p_name=>'Datos Procesados'
,p_template=>wwv_flow_imp.id(38289867500120143)
,p_display_sequence=>10
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select mpaid',
'	, mpcknu',
'	, mpexr',
'	, mpcn',
'	, mpaa/100 as mpaa',
'	, data.pk_commons.f_jde2g(mpdgj) mpdgj',
'	, mpev01',
'	, mpev02',
'	, mpuser',
'	, mpupmj',
'	, mpupmt',
'	, mpjobn',
'	, mpdivj',
'	, mpkco',
'	, mpdoc',
'	, mpdct',
'	, mpedbt',
'	, mpedtn',
'	, mpedln/1000 mpedln',
'	, mpedus',
'	, mpdl01',
'	, mpdl02',
'from f5509505@jdedtadl',
'where 1 = 1',
'	and trim(mpedbt) = :p210_flag1',
'	and mpaid = :p210_banco'))
,p_ajax_enabled=>'Y'
,p_ajax_items_to_submit=>'P210_FLAG1,P210_BANCO'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(37830327650106535)
,p_query_num_rows=>50
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_show_nulls_as=>'-'
,p_query_no_data_found=>'No Data'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
,p_updated_on=>wwv_flow_imp.dz('20250321205557Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(480010848277982733)
,p_query_column_id=>1
,p_column_alias=>'MPAID'
,p_column_display_sequence=>1
,p_column_heading=>'Banco'
,p_use_as_row_header=>'N'
,p_column_alignment=>'CENTER'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(480010942277982734)
,p_query_column_id=>2
,p_column_alias=>'MPCKNU'
,p_column_display_sequence=>2
,p_column_heading=>'Referencia'
,p_use_as_row_header=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(480011064178982735)
,p_query_column_id=>3
,p_column_alias=>'MPEXR'
,p_column_display_sequence=>3
,p_column_heading=>unistr('Explicaci\00F3n')
,p_use_as_row_header=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(480011134745982736)
,p_query_column_id=>4
,p_column_alias=>'MPCN'
,p_column_display_sequence=>5
,p_use_as_row_header=>'N'
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(480068874768017532)
,p_query_column_id=>5
,p_column_alias=>'MPAA'
,p_column_display_sequence=>4
,p_column_heading=>'Monto'
,p_use_as_row_header=>'N'
,p_column_format=>'FML999G999G999G999G990D00'
,p_column_alignment=>'RIGHT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(480011376457982738)
,p_query_column_id=>6
,p_column_alias=>'MPDGJ'
,p_column_display_sequence=>6
,p_column_heading=>unistr('Fecha Transacci\00F3n')
,p_use_as_row_header=>'N'
,p_column_format=>'dd/mm/yyyy'
,p_column_alignment=>'CENTER'
,p_default_sort_column_sequence=>1
,p_default_sort_dir=>'desc'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(480011409472982739)
,p_query_column_id=>7
,p_column_alias=>'MPEV01'
,p_column_display_sequence=>7
,p_use_as_row_header=>'N'
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(480011596737982740)
,p_query_column_id=>8
,p_column_alias=>'MPEV02'
,p_column_display_sequence=>8
,p_use_as_row_header=>'N'
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(480011648441982741)
,p_query_column_id=>9
,p_column_alias=>'MPUSER'
,p_column_display_sequence=>9
,p_use_as_row_header=>'N'
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(480011703982982742)
,p_query_column_id=>10
,p_column_alias=>'MPUPMJ'
,p_column_display_sequence=>10
,p_use_as_row_header=>'N'
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(480011870136982743)
,p_query_column_id=>11
,p_column_alias=>'MPUPMT'
,p_column_display_sequence=>11
,p_use_as_row_header=>'N'
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(480011934995982744)
,p_query_column_id=>12
,p_column_alias=>'MPJOBN'
,p_column_display_sequence=>12
,p_use_as_row_header=>'N'
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(480012091848982745)
,p_query_column_id=>13
,p_column_alias=>'MPDIVJ'
,p_column_display_sequence=>13
,p_use_as_row_header=>'N'
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(480012147638982746)
,p_query_column_id=>14
,p_column_alias=>'MPKCO'
,p_column_display_sequence=>14
,p_use_as_row_header=>'N'
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(480012222514982747)
,p_query_column_id=>15
,p_column_alias=>'MPDOC'
,p_column_display_sequence=>15
,p_use_as_row_header=>'N'
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(480012373299982748)
,p_query_column_id=>16
,p_column_alias=>'MPDCT'
,p_column_display_sequence=>16
,p_use_as_row_header=>'N'
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(480012472001982749)
,p_query_column_id=>17
,p_column_alias=>'MPEDBT'
,p_column_display_sequence=>17
,p_column_heading=>'Batch'
,p_use_as_row_header=>'N'
,p_column_alignment=>'CENTER'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(480012507513982750)
,p_query_column_id=>18
,p_column_alias=>'MPEDTN'
,p_column_display_sequence=>18
,p_use_as_row_header=>'N'
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(480065734478017501)
,p_query_column_id=>19
,p_column_alias=>'MPEDLN'
,p_column_display_sequence=>19
,p_column_heading=>'Linea'
,p_use_as_row_header=>'N'
,p_column_alignment=>'CENTER'
,p_default_sort_column_sequence=>2
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(480065809928017502)
,p_query_column_id=>20
,p_column_alias=>'MPEDUS'
,p_column_display_sequence=>20
,p_column_heading=>'Usuario'
,p_use_as_row_header=>'N'
,p_column_alignment=>'CENTER'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(480065918348017503)
,p_query_column_id=>21
,p_column_alias=>'MPDL01'
,p_column_display_sequence=>21
,p_column_heading=>unistr('Descripci\00F3n 1')
,p_use_as_row_header=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(40375070669094938)
,p_query_column_id=>22
,p_column_alias=>'MPDL02'
,p_column_display_sequence=>22
,p_column_heading=>unistr('Descripci\00F3n 2')
,p_use_as_row_header=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(2769985162110906258)
,p_plug_name=>'Barra de acciones'
,p_region_template_options=>'#DEFAULT#:t-Form--stretchInputs'
,p_plug_template=>wwv_flow_imp.id(38289497777120142)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'REGION_POSITION_01'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(479069287507602429)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(2769985162110906258)
,p_button_name=>'BTN_SUBIR_EDC'
,p_button_action=>'REDIRECT_APP'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860056812106557)
,p_button_image_alt=>'Btn Subir Edc'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=100:300:&SESSION.::&DEBUG.:RP,300::'
,p_icon_css_classes=>'fa-upload'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(480066485571017508)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(2769985162110906258)
,p_button_name=>'Buscar'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860056812106557)
,p_button_image_alt=>'Buscar'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_button_condition_type=>'NEVER'
,p_icon_css_classes=>'fa-search'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(479068915030602426)
,p_name=>'P210_BANCO'
,p_is_required=>true
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(479069159641602428)
,p_prompt=>'Banco:'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select trim(ayaid)||'' - ''||trim(upper(aydl01)) d',
'    , trim(ayaid) r',
'from f0030@jdedtadl',
'where trim(aycbnk) is not null and trim(aydl01) is not null',
'order by trim(upper(aydl01))'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'Seleccione'
,p_cHeight=>1
,p_tag_attributes=>'style="max-width:250px;"'
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(479070266985602439)
,p_name=>'P210_MENSAJESALIDA'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(479069159641602428)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(480066063000017504)
,p_name=>'P210_FLAG1'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(479069159641602428)
,p_use_cache_before_default=>'NO'
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(479069338824602430)
,p_name=>'Cerrar dialogo tabla'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(479069287507602429)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
,p_updated_on=>wwv_flow_imp.dz('20260526143036Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(479069437396602431)
,p_event_id=>wwv_flow_imp.id(479069338824602430)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'p_banco 	varchar2(200);',
'p_usuario 	varchar2(200);',
'p_mensaje 	varchar2(200);',
'v_log_app	varchar2(100);',
'v_log_dsc	varchar2(999);',
'begin',
'	v_log_app := ''apex.109.210.subir'';',
'	:p210_mensajesalida := '''';',
'	p_banco 			:= :p210_banco;',
'	p_usuario 			:= :app_user;',
'	:P210_FLAG1 		:= 0;',
'',
unistr('	v_log_dsc := ''Par\00E1metros: p_banco: ''||p_banco||'', p_usuario: ''||p_usuario;'),
'',
'	data.pk_commons.sp_apex_log(p_aplicacion=>v_log_app,p_paso=>0,p_descripcion=>v_log_dsc,p_mensaje=>null,p_observacion=>null,p_query=>null);',
'',
'	data.pk_finz_cobroclientes.sp_insertestadocuenta(p_compania => :g_compania, p_usuario => p_usuario, p_banco => p_banco,p_mensaje => p_mensaje);',
'',
'	:p210_mensajesalida := p_mensaje;',
'end;'))
,p_attribute_02=>'P210_BANCO'
,p_attribute_03=>'P210_MENSAJESALIDA'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20260526143036Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(479071060867602447)
,p_event_id=>wwv_flow_imp.id(479069338824602430)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P210_MENSAJESALIDA'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(480066335785017507)
,p_event_id=>wwv_flow_imp.id(479069338824602430)
,p_event_result=>'TRUE'
,p_action_sequence=>50
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P210_FLAG1'
,p_attribute_01=>'SQL_STATEMENT'
,p_attribute_03=>'select max(TO_NUMBER(trim(MPEDBT))) from F5509505@JDEDTADL;'
,p_attribute_08=>'Y'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(480008612299982711)
,p_event_id=>wwv_flow_imp.id(479069338824602430)
,p_event_result=>'TRUE'
,p_action_sequence=>60
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'//mensaje(''exito'', apex.item( "P210_MENSAJESALIDA" ).getValue());',
'',
'apex.message.clearErrors();',
'',
'apex.message.showPageSuccess( apex.item( "P210_MENSAJESALIDA" ).getValue() );',
''))
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(480066622336017510)
,p_event_id=>wwv_flow_imp.id(479069338824602430)
,p_event_result=>'TRUE'
,p_action_sequence=>70
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(480010723123982732)
);
wwv_flow_imp.component_end;
end;
/
