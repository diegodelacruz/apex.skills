prompt --application/pages/page_00164
begin
--   Manifest
--     PAGE: 00164
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>109
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_page.create_page(
 p_id=>164
,p_name=>'Detalle Activos Fijos'
,p_alias=>'DETALLE-ACTIVOS-FIJOS1'
,p_page_mode=>'MODAL'
,p_step_title=>'Detalle Activos Fijos'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'03'
,p_created_on=>wwv_flow_imp.dz('20240801205716Z')
,p_last_updated_on=>wwv_flow_imp.dz('20240827210808Z')
,p_last_updated_by=>'MALBAN'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(271836961556219506)
,p_name=>'Detalle'
,p_template=>wwv_flow_imp.id(38289867500120143)
,p_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT GLAID,TRIM(GLANI),SUM(GLAA/100)',
'FROM F0911@JDEDTADL X',
'WHERE GLLT = ''AA'' AND GLCTRY = 20 --AND GLFY<= :P164_ANIO-2000 AND GLPN  <= :P164_MES  ',
'AND GLCO = ''00001''',
'AND GLAID IN (SELECT GMAID',
'              FROM F0901@JDEDTADL ',
'              WHERE GMSUB != ''        ''              ',
'              AND EXISTS (SELECT *--''X''',
'                          FROM T_CORP_UDC',
'                          WHERE ID_CABECERA=''FINZ_GGEST'' AND ID_TABLA=''ACTFIJ'' AND ACTIVO=1',
'                          AND LPAD(VALOR,12,'' '')=GMMCU AND RPAD(VALOR2,6,'' '')=GMOBJ AND RPAD(VALOR3,8,'' '')=GMSUB))',
'GROUP BY TRIM(GLANI),GLAID;'))
,p_display_when_condition=>'1=2'
,p_display_when_cond2=>'PLSQL'
,p_display_condition_type=>'EXPRESSION'
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(37830327650106535)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
,p_updated_on=>wwv_flow_imp.dz('20240827205916Z')
,p_updated_by=>'MALBAN'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(271837059435219507)
,p_query_column_id=>1
,p_column_alias=>'GLAID'
,p_column_display_sequence=>10
,p_column_heading=>'Cuenta'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_display_as=>'TEXT_FROM_LOV_ESC'
,p_named_lov=>wwv_flow_imp.id(532084568011346114)
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(271837192747219508)
,p_query_column_id=>2
,p_column_alias=>'TRIM(GLANI)'
,p_column_display_sequence=>20
,p_use_as_row_header=>'N'
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(271837254584219509)
,p_query_column_id=>3
,p_column_alias=>'SUM(GLAA/100)'
,p_column_display_sequence=>30
,p_column_heading=>'Valor'
,p_use_as_row_header=>'N'
,p_column_format=>'999G999G999G999G990D00'
,p_column_alignment=>'RIGHT'
,p_disable_sort_column=>'N'
,p_sum_column=>'Y'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(413248851285452613)
,p_name=>'Detalle2'
,p_template=>wwv_flow_imp.id(38289867500120143)
,p_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select gbaid, sum(gbapyc)/100 + case',
'    when :P164_MES =  1 then',
'        sum(gban01)/100',
'    when :P164_MES =  2 then',
'        sum(gban01 + gban02)/100',
'    when :P164_MES =  3 then',
'        sum(gban01 + gban02 + gban03)/100',
'    when :P164_MES =  4 then',
'        sum(gban01 + gban02 + gban03 + gban04)/100',
'    when :P164_MES =  5 then',
'        sum(gban01 + gban02 + gban03 + gban04 + gban05)/100',
'    when :P164_MES =  6 then',
'        sum(gban01 + gban02 + gban03 + gban04 + gban05 + gban06)/100',
'    when :P164_MES =  7 then',
'        sum(gban01 + gban02 + gban03 + gban04 + gban05 + gban06 + gban07)/100',
'    when :P164_MES =  8 then',
'        sum(gban01 + gban02 + gban03 + gban04 + gban05 + gban06 + gban07 + gban08)/100',
'    when :P164_MES =  9 then',
'        sum(gban01 + gban02 + gban03 + gban04 + gban05 + gban06 + gban07 + gban08 + gban09)/100',
'    when :P164_MES = 10 then',
'        sum(gban01 + gban02 + gban03 + gban04 + gban05 + gban06 + gban07 + gban08 + gban09 + gban10)/100',
'    when :P164_MES = 11 then',
'        sum(gban01 + gban02 + gban03 + gban04 + gban05 + gban06 + gban07 + gban08 + gban09 + gban10 + gban11)/100',
'    when :P164_MES = 12 then',
'        sum(gban01 + gban02 + gban03 + gban04 + gban05 + gban06 + gban07 + gban08 + gban09 + gban10 + gban11 + gban12)/100',
'    else 0 end valor',
'from f0902@jdedtadl',
'where 1 = 1',
'    and gbco = :G_COMPANIA and gbmcu = gbmcu and gblt = ''AA'' and gbsbl = gbsbl and gbsblt = gbsblt ',
'    and gbctry = 20 and gbfy = :P164_ANIO-2000',
'    and gbaid --= ''00406570'' ',
'    IN (SELECT GMAID',
'              FROM F0901@JDEDTADL ',
'              WHERE GMSUB != ''        ''              ',
'              AND EXISTS (SELECT *--''X''',
'                          FROM T_CORP_UDC',
'                          WHERE ID_CABECERA=''FINZ_GGEST'' AND ID_TABLA=''ACTFIJ'' AND ACTIVO=1',
'                          AND LPAD(VALOR,12,'' '')=GMMCU AND RPAD(VALOR2,6,'' '')=GMOBJ AND RPAD(VALOR3,8,'' '')=GMSUB))',
'                          ',
'group by gbaid',
'ORDER BY 1;',
''))
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(37830327650106535)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
,p_created_on=>wwv_flow_imp.dz('20240827205916Z')
,p_updated_on=>wwv_flow_imp.dz('20240827210808Z')
,p_created_by=>'MALBAN'
,p_updated_by=>'MALBAN'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(413249207555452617)
,p_query_column_id=>1
,p_column_alias=>'GBAID'
,p_column_display_sequence=>10
,p_column_heading=>'Cuenta'
,p_use_as_row_header=>'N'
,p_display_as=>'TEXT_FROM_LOV_ESC'
,p_named_lov=>wwv_flow_imp.id(532084568011346114)
,p_derived_column=>'N'
,p_include_in_export=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20240827210808Z')
,p_updated_by=>'MALBAN'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(413249380585452618)
,p_query_column_id=>2
,p_column_alias=>'VALOR'
,p_column_display_sequence=>20
,p_column_heading=>'Valor'
,p_use_as_row_header=>'N'
,p_column_format=>'999G999G999G999G990D00'
,p_column_alignment=>'RIGHT'
,p_sum_column=>'Y'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20240827210808Z')
,p_updated_by=>'MALBAN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(271837488555219511)
,p_name=>'P164_ANIO'
,p_item_sequence=>30
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
,p_updated_on=>wwv_flow_imp.dz('20240827205916Z')
,p_updated_by=>'MALBAN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(271837522011219512)
,p_name=>'P164_MES'
,p_item_sequence=>40
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
,p_updated_on=>wwv_flow_imp.dz('20240827205916Z')
,p_updated_by=>'MALBAN'
);
wwv_flow_imp.component_end;
end;
/
