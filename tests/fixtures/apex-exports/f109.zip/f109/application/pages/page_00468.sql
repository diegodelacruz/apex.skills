prompt --application/pages/page_00468
begin
--   Manifest
--     PAGE: 00468
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>109
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_page.create_page(
 p_id=>468
,p_name=>unistr('Activos Fijos - Depreciaci\00F3n Simulada')
,p_alias=>unistr('DEPRECIACI\00D3N-SIMULADA')
,p_page_mode=>'MODAL'
,p_step_title=>unistr('Depreciaci\00F3n Simulada')
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'03'
,p_last_updated_on=>wwv_flow_imp.dz('20260327152631Z')
,p_last_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(134218988170902026)
,p_name=>'DATOS'
,p_template=>wwv_flow_imp.id(38289867500120143)
,p_display_sequence=>40
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ROWNUM,t.id,                          -- o la PK que tengas en T_FINZ_ACTIVOSFIJOS',
'       jt.num01,',
'       jt.dte01 AS dte01,  -- ajusta formato si tus fechas vienen distinto',
'       jt.num02,',
'       jt.num03,',
'       jt.num04,',
'       jt.num05,',
'       jt.txt01',
'FROM T_FINZ_ACTIVOSFIJOS t',
'CROSS JOIN',
'JSON_TABLE(',
'  t.DEPRECIACION,                         -- campo CLOB con el JSON array',
'  ''$[*]''                                -- cada elemento del array',
'  COLUMNS (',
'    num01  NUMBER       PATH ''$.NUM01'',',
'    dte01  VARCHAR2(50) PATH ''$.DTE01'',',
'    num02  NUMBER       PATH ''$.NUM02'',',
'    num03  NUMBER       PATH ''$.NUM03'',',
'    num04  NUMBER       PATH ''$.NUM04'',',
'    num05  NUMBER       PATH ''$.NUM05'',',
'    txt01  VARCHAR2(4000) PATH ''$.TXT01''',
'  )',
') jt',
'WHERE t.id = :P468_IDACTIVO       -- opcional: filtrar por el registro que quieres mostrar',
''))
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(37830327650106535)
,p_query_num_rows=>300
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
,p_updated_on=>wwv_flow_imp.dz('20260130044134Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(134220155390902038)
,p_query_column_id=>1
,p_column_alias=>'ROWNUM'
,p_column_display_sequence=>10
,p_column_heading=>'.'
,p_use_as_row_header=>'N'
,p_column_alignment=>'CENTER'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(134219832481902035)
,p_query_column_id=>2
,p_column_alias=>'ID'
,p_column_display_sequence=>70
,p_use_as_row_header=>'N'
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(134219937647902036)
,p_query_column_id=>3
,p_column_alias=>'NUM01'
,p_column_display_sequence=>80
,p_use_as_row_header=>'N'
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(134219155166902028)
,p_query_column_id=>4
,p_column_alias=>'DTE01'
,p_column_display_sequence=>20
,p_column_heading=>'Fecha'
,p_use_as_row_header=>'N'
,p_column_format=>'DD-MM-YYYY'
,p_column_alignment=>'CENTER'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(134219207958902029)
,p_query_column_id=>5
,p_column_alias=>'NUM02'
,p_column_display_sequence=>30
,p_column_heading=>'Costo'
,p_use_as_row_header=>'N'
,p_column_format=>'999G999G999G999G990D00'
,p_column_alignment=>'RIGHT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(134219327150902030)
,p_query_column_id=>6
,p_column_alias=>'NUM03'
,p_column_display_sequence=>40
,p_column_heading=>unistr('Depreciaci\00F3n ACM')
,p_use_as_row_header=>'N'
,p_column_format=>'999G999G999G999G990D00'
,p_column_alignment=>'RIGHT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(134219487267902031)
,p_query_column_id=>7
,p_column_alias=>'NUM04'
,p_column_display_sequence=>50
,p_column_heading=>'Dep. Gasto'
,p_use_as_row_header=>'N'
,p_column_format=>'999G999G999G999G990D00'
,p_column_alignment=>'RIGHT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(134219533830902032)
,p_query_column_id=>8
,p_column_alias=>'NUM05'
,p_column_display_sequence=>60
,p_column_heading=>'Valor Neto'
,p_use_as_row_header=>'N'
,p_column_format=>'999G999G999G999G990D00'
,p_column_alignment=>'RIGHT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(134220008274902037)
,p_query_column_id=>9
,p_column_alias=>'TXT01'
,p_column_display_sequence=>90
,p_use_as_row_header=>'N'
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(134218741780902024)
,p_name=>'P468_IDACTIVO'
,p_item_sequence=>10
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(134218865352902025)
,p_name=>'P468_TIPOACTIVO'
,p_item_sequence=>30
,p_prompt=>'Tipo Activo:'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'LOV_AFI_TIPO'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select DRDL01 D, DRKY R',
'from vt_jde_udcjde where drsy = ''12'' and drrt = ''21''',
'and DRKY is not null',
'order by 2;'))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_read_only_when_type=>'ALWAYS'
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(134219656994902033)
,p_name=>'P468_CODERP'
,p_item_sequence=>20
,p_prompt=>'ID Activo: '
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(134218695141902023)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>unistr('calculasimulaci\00F3n')
,p_process_sql_clob=>'data.PK_FINZ_ACTIVOSFIJOS.SP_SIMULADEPRECIACION(:G_COMPANIA,:APP_USER,:P468_IDACTIVO,:P468_TIPOACTIVO);'
,p_process_clob_language=>'PLSQL'
,p_process_when=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT 1',
'FROM DATA.T_FINZ_ACTIVOSFIJOS',
'WHERE ID = :P468_IDACTIVO AND DEPRECIACION is not null'))
,p_process_when_type=>'NOT_EXISTS'
,p_internal_uid=>134218695141902023
,p_updated_on=>wwv_flow_imp.dz('20260130044320Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp.component_end;
end;
/
