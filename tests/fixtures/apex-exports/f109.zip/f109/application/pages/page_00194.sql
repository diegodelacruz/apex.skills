prompt --application/pages/page_00194
begin
--   Manifest
--     PAGE: 00194
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>109
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_page.create_page(
 p_id=>194
,p_name=>'GESTION TRIBUTARIA  -  RESUMEN DE DATOS'
,p_alias=>'GESTION-TRIBUTARIA-RESUMEN-DE-DATOS'
,p_page_mode=>'MODAL'
,p_autocomplete_on_off=>'OFF'
,p_javascript_code=>'$(secItems).hide();'
,p_step_template=>wwv_flow_imp.id(37774372912106498)
,p_page_template_options=>'#DEFAULT#:ui-dialog--stretch'
,p_protection_level=>'C'
,p_page_component_map=>'18'
,p_last_updated_on=>wwv_flow_imp.dz('20260205164436Z')
,p_last_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(43069874278983346)
,p_plug_name=>'items'
,p_region_name=>'secItems'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(38289867500120143)
,p_plug_display_sequence=>100
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
,p_updated_on=>wwv_flow_imp.dz('20251001185051Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(44519904248941323)
,p_plug_name=>'Resumen de Ventas'
,p_title=>'Resumen de Ventas'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(38289867500120143)
,p_plug_display_sequence=>10
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'WITH ',
'     T_DATOSVTAS AS (',
'        SELECT TP_DOC,TIPO_Y_N',
'        , SUM(pk_commons.safe_to_number(BASE_0))BASE_0, SUM(pk_commons.safe_to_number(IVA_0))IVA_0',
'        , SUM(pk_commons.safe_to_number(BASE_12))BASE_12, (SUM(pk_commons.safe_to_number(BASE_12)) *0.12)IVA_12',
'        , SUM(pk_commons.safe_to_number(BASE_15))BASE_15, (SUM(pk_commons.safe_to_number(BASE_15)) *0.15)IVA_15',
'        , SUM(pk_commons.safe_to_number(BASE_NO_OBJ))BASE_NO_OBJ, SUM(pk_commons.safe_to_number(SIN_CT))SIN_CT',
'        , SUM(pk_commons.safe_to_number(FLETE))FLETE, SUM(pk_commons.safe_to_number(SEGURO))SEGURO',
'        , (SELECT VALOR FROM DATA.T_CORP_UDC WHERE REGEXP_LIKE (ID_CABECERA, ''FINZ_GT05'') AND ID_TABLA!=''000''  and descripcion2 =''BUSQUEDA DE BALANCE D/C VTAS'' ) TIPO_BUSQ_BC',
'        , :P194_PERIODO PERIODO,VALIDADORSRI',
'        FROM t_finz_gestiontributariadatos t,',
'        JSON_TABLE(',
'            case when t.estado=3 then t.DATOSFIN ELSE t.DATOSMOD END ',
'            ,''$[*]'' COLUMNS(',
'                 TP_DOC VARCHAR(3999) PATH''$.TPDOC_VAL'',TIPO_Y_N VARCHAR(3999) PATH''$.TIPOYN_VAL'',BASE_12 NUMBER PATH''$.BASE12'',BASE_15 NUMBER PATH''$.BASE15'',BASE_0 NUMBER PATH''$.BASE0''',
'                ,SIN_CT NUMBER PATH''$.SINCT'',BASE_NO_OBJ NUMBER PATH''$.BASENOOBJ'',IVA_12 NUMBER PATH''$.IVA12'',IVA_15 NUMBER PATH''$.IVA15'',IVA_0 NUMBER PATH''$.IVA0''',
'                ,FLETE NUMBER PATH''$.FLETE'',SEGURO NUMBER PATH''$.SEGURO'', VALIDADORSRI varchar2(3999) PATH''$.VALIDADORSRI'')',
'        )jt WHERE 1=1',
'        and t.id=:P194_IDDATO',
'        and :P194_IDPROCESO=''002''',
'        AND (VALIDADORSRI!=''T'' AND VALIDADORSRI!=''S'')',
'        GROUP BY TP_DOC,TIPO_Y_N,VALIDADORSRI',
'     ) --SELECT * FROM T_DATOSVTAS;',
'    ,T_DETALLE AS (',
'        SELECT 1 id, ''VENTAS LOC15%'' TIPO_RESUMEN,MAX(TIPO_BUSQ_BC)TIPO_BUSQ_BC,MAX(PERIODO)PERIODO,',
'            SUM(case when TP_DOC in (''FN'',''FD'',''ND'',''FG'') then (BASE_15) else null end )as VENTA_BRUTA,',
'            SUM(case when TP_DOC in (''FN'',''FD'',''ND'',''FG'',''D1'') then (BASE_15) else null end )as VENTA_NETA,',
'            SUM(case when TP_DOC in (''FN'',''FD'',''ND'',''FG'',''D1'') then (IVA_15) else null end )  as IVA_VENTAS',
'        FROM T_DATOSVTAS ',
'		UNION ALL',
'		select 2 id, ''VENTAS AF 15%'' TIPO_RESUMEN,MAX(TIPO_BUSQ_BC)TIPO_BUSQ_BC,MAX(PERIODO)PERIODO,',
'            SUM(case when TP_DOC in (''FN-ACTF'') then (BASE_15) else null end )as VENTA_BRUTA_AF15,',
'            SUM(case when TP_DOC in (''FN-ACTF'',''D1-ACTF'') then (BASE_15) else null end )as VENTA_NETA_AF15,',
'            SUM(case when TP_DOC in (''FN-ACTF'',''D1-ACTF'') then (IVA_15) else null end )  as IVA_VENTAS_AF15',
'		FROM T_DATOSVTAS ',
'		UNION ALL',
'		select 3 id, ''VENTAS LOC12%'' TIPO_RESUMEN,MAX(TIPO_BUSQ_BC)TIPO_BUSQ_BC,MAX(PERIODO)PERIODO,',
'            SUM(case when TP_DOC in (''FN'',''FD'',''ND'',''FG'') then (BASE_12) else null end )as VENTA_BRUTA_LOC12,',
'            SUM(case when TP_DOC in (''FN'',''FD'',''ND'',''FG'',''D1'') then (BASE_12) else null end )as VENTA_NETA_LOC12,',
'            SUM(case when TP_DOC in (''FN'',''FD'',''ND'',''FG'',''D1'') then IVA_12 else null end )  as IVA_VENTAS_LOC12',
'		FROM T_DATOSVTAS ',
'		UNION ALL',
'		select 4 id, ''VENTAS AF 12%'' TIPO_RESUMEN,MAX(TIPO_BUSQ_BC)TIPO_BUSQ_BC,MAX(PERIODO)PERIODO,',
'            SUM(case when TP_DOC in (''FN-ACTF'') then (BASE_12) else null end )as VENTA_BRUTA_AF12,',
'            SUM(case when TP_DOC in (''FN-ACTF'',''D1-ACTF'') then (BASE_12) else null end )as VENTA_NETA_AF12,',
'            SUM(case when TP_DOC in (''FN-ACTF'',''D1-ACTF'') then IVA_12 else null end )  as IVA_VENTAS_AF12',
'		FROM T_DATOSVTAS ',
'		UNION ALL',
'		select 5 id, ''VENTAS LOC0%'' TIPO_RESUMEN,MAX(TIPO_BUSQ_BC)TIPO_BUSQ_BC,MAX(PERIODO)PERIODO,',
'            SUM(case when TP_DOC in (''FN'',''FD'',''FG'') then (BASE_0) else null end )as VENTA_BRUTA_LOC0,',
'            SUM(case when TP_DOC in (''FN'',''FD'',''FG'',''D1'') then (BASE_0) else null end )as VENTA_NETA_LOC0,',
'            SUM(case when TP_DOC in (''FN'',''FD'',''FG'',''D1'') then IVA_0 else null end )  as IVA_VENTAS_LOC0',
'		FROM T_DATOSVTAS ',
'		UNION ALL',
'		select 6 id, ''VENTAS LOC0% SIN CT'' TIPO_RESUMEN,MAX(TIPO_BUSQ_BC)TIPO_BUSQ_BC,MAX(PERIODO)PERIODO,',
'            SUM(case when TP_DOC in (''FN'',''FD'',''FG'') then SIN_CT else null end )as VENTA_BRUTA_LOCNCT,',
'            SUM(case when TP_DOC in (''FN'',''FD'',''FG'',''D1'') then SIN_CT else null end )as VENTA_NETA_LOCNCT,',
'            SUM(case when TP_DOC in (''FN'',''FD'',''FG'',''D1'') then IVA_0 else null end )  as IVA_VENTAS_LOCNCT',
'		FROM T_DATOSVTAS ',
'		UNION ALL',
'		select 7 id, ''VENTAS LOC ACTIVO FIJO 0%'' TIPO_RESUMEN,MAX(TIPO_BUSQ_BC)TIPO_BUSQ_BC,MAX(PERIODO)PERIODO,',
'            SUM(case when TP_DOC in (''FN-ACTSND'') then (BASE_0) else null end )as VENTA_BRUTA_AF0,',
'            SUM(case when TP_DOC in (''FN-ACTSND'') then (BASE_0) else null end )as VENTA_NETA_AF0,',
'            SUM(case when TP_DOC in (''FN-ACTSND'') then IVA_0 else null end )  as IVA_VENTAS_AF0',
'		FROM T_DATOSVTAS ',
'		UNION ALL',
'		select 8 id, ''EXPORTACIONES BIENES'' TIPO_RESUMEN,MAX(TIPO_BUSQ_BC)TIPO_BUSQ_BC,MAX(PERIODO)PERIODO,',
'            SUM(case when TIPO_Y_N in (''EXPORTBIEN'') then NVL((BASE_0),0)+NVL(FLETE ,0)+NVL(SEGURO,0) else 0 end )-SUM(case when TP_DOC in (''D1-EXT'') then (BASE_0) else 0 end ) as VENTA_BRUTA_EXP,',
'            SUM(case when TIPO_Y_N in (''EXPORTBIEN'') then NVL((BASE_0),0)+NVL(FLETE ,0)+NVL(SEGURO,0) else 0 end ) as VENTA_NETA_EXP,',
'            null as IVA_VENTAS_EXP',
'		FROM T_DATOSVTAS ',
'		UNION ALL',
'		select 9 id, ''EXPORTACIONES SERVICIOS'' TIPO_RESUMEN,MAX(TIPO_BUSQ_BC)TIPO_BUSQ_BC,MAX(PERIODO)PERIODO,',
'            SUM(case when TIPO_Y_N in (''EXPORTSERV'') then NVL((BASE_0),0)+NVL(FLETE ,0)+NVL(SEGURO,0) else null end ) as VENTA_BRUTA_SRV,',
'            SUM(case when TIPO_Y_N in (''EXPORTSERV'') then NVL((BASE_0),0)+NVL(FLETE ,0)+NVL(SEGURO,0) else null end ) as VENTA_NETA_SRV,',
'            null as IVA_VENTAS_SRV',
'		FROM T_DATOSVTAS ',
'		UNION ALL',
'		select 10 id, ''REEMBOLSO DE GASTOS 15%'' TIPO_RESUMEN,MAX(TIPO_BUSQ_BC)TIPO_BUSQ_BC,MAX(PERIODO)PERIODO,',
'            SUM(case when TP_DOC in (''FN-REEMB'') then (BASE_15) else null end )as VENTA_BRUTA_GST15,',
'            SUM(case when TP_DOC in (''FN-REEMB'') then (BASE_15) else null end )as VENTA_NETA_GST15,',
'            SUM(case when TP_DOC in (''FN-REEMB'') then (IVA_15) else null end )  as IVA_VENTAS_GST15',
'		FROM T_DATOSVTAS ',
'		UNION ALL',
'		select 11 id, ''REEMBOLSO DE GASTOS 12%'' TIPO_RESUMEN,MAX(TIPO_BUSQ_BC)TIPO_BUSQ_BC,MAX(PERIODO)PERIODO,',
'            SUM(case when TP_DOC in (''FN-REEMB'') then (BASE_12) else null end )as VENTA_BRUTA_GST12,',
'            SUM(case when TP_DOC in (''FN-REEMB'') then (BASE_12) else null end )as VENTA_NETA_GST12,',
'            SUM(case when TP_DOC in (''FN-REEMB'') then IVA_12 else null end )  as IVA_VENTAS_GST12',
'		FROM T_DATOSVTAS ',
'		UNION ALL',
'		select 12 id, ''REEMBOLSO DE GASTOS 0%'' TIPO_RESUMEN,MAX(TIPO_BUSQ_BC)TIPO_BUSQ_BC,MAX(PERIODO)PERIODO,',
'            SUM(case when TP_DOC in (''FN-REEMB'') then (BASE_0) else null end )as VENTA_BRUTA_GST0,',
'            SUM(case when TP_DOC in (''FN-REEMB'') then (BASE_0) else null end )as VENTA_NETA_GST0,',
'            SUM(case when TP_DOC in (''FN-REEMB'') then IVA_0 else null end )  as IVA_VENTAS_GST0',
'		FROM T_DATOSVTAS ',
'		UNION ALL ',
'		select 13 id, ''TRANSFERENCIA NO OBJETO O EXENTAS'' TIPO_RESUMEN,MAX(TIPO_BUSQ_BC)TIPO_BUSQ_BC,MAX(PERIODO)PERIODO,',
'            SUM(BASE_NO_OBJ )as VENTA_BRUTA_NOJB,',
'            SUM(BASE_NO_OBJ )as VENTA_NETA_NOJB,',
'            SUM(IVA_0 )  as IVA_VENTAS_NOJB ',
'		FROM T_DATOSVTAS ',
'    )',
'    ,T_RESUMEN as(',
'        select ',
'            ID, TIPO_RESUMEN RESUMEN, PERIODO, VENTA_BRUTA, VENTA_NETA, IVA_VENTAS, DESCRIP_BALANCE, CTA_BALANCE, BUSQ ',
'            ,PK_FINZ_GESTIONTRIBUTARIA.f_trer_valorbalance (PERIODO,BUSQ,TIPO_BUSQ_BC) BC',
'			,abs(nvl(pk_finz_gestiontributaria.f_trer_valorbalance (periodo,busq,tipo_busq_bc),0))-abs(nvl(IVA_VENTAS,0))dif',
'        from ( SELECT ID, TIPO_RESUMEN, TIPO_BUSQ_BC, PERIODO, VENTA_BRUTA, VENTA_NETA, IVA_VENTAS,PK_FINZ_GESTIONTRIBUTARIA.f_trae_descripcioncuenta(TIPO_RESUMEN,''P'',''D'') DESCRIP_BALANCE,PK_FINZ_GESTIONTRIBUTARIA.f_trae_descripcioncuenta(TIPO_RESUME'
||'N,''P'',''C'') CTA_BALANCE',
'                ,PK_FINZ_GESTIONTRIBUTARIA.f_trae_descripcioncuenta(TIPO_RESUMEN,''P'',TIPO_BUSQ_BC) BUSQ',
'                FROM T_DETALLE D',
'                WHERE 1=1 and :P194_IDPROCESO=''002''',
'        )',
'    )',
'',
'	 ',
'    SELECT ',
'         ID,RESUMEN,DESCRIP_BALANCE,CTA_BALANCE',
'		 ,pk_commons.safe_to_number(VENTA_BRUTA) VENTA_BRUTA',
'		 ,pk_commons.safe_to_number(VENTA_NETA) VENTA_NETA',
'		 ,pk_commons.safe_to_number(IVA_VENTAS) IVA_VENTAS',
'		 ,pk_commons.safe_to_number(BC) BC',
'		 ,pk_commons.safe_to_number(DIF) DIF',
'    FROM T_RESUMEN',
' ',
' ',
'	where ',
'	   nvl(abs(pk_commons.safe_to_number(VENTA_BRUTA)),0)>0 ',
'	or nvl(abs(pk_commons.safe_to_number(VENTA_NETA)),0)>0 ',
'	or nvl(abs(pk_commons.safe_to_number(IVA_VENTAS) ),0)>0',
'	',
'',
'    ;'))
,p_plug_source_type=>'NATIVE_IR'
,p_ajax_items_to_submit=>'P194_IDPROCESO,P194_IDDATO,P194_PERIODO'
,p_plug_display_condition_type=>'EXPRESSION'
,p_plug_display_when_condition=>':P194_IDPROCESO in (''002'')'
,p_plug_display_when_cond2=>'PLSQL'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'Resumen de Ventas'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
,p_updated_on=>wwv_flow_imp.dz('20251021193630Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(44520067740941324)
,p_max_row_count=>'1000000'
,p_allow_report_saving=>'N'
,p_show_search_textbox=>'N'
,p_report_list_mode=>'NONE'
,p_lazy_loading=>true
,p_show_detail_link=>'N'
,p_show_rows_per_page=>'N'
,p_show_filter=>'N'
,p_show_sort=>'N'
,p_show_control_break=>'N'
,p_show_highlight=>'N'
,p_show_computation=>'N'
,p_show_aggregate=>'N'
,p_show_chart=>'N'
,p_show_group_by=>'N'
,p_show_pivot=>'N'
,p_show_flashback=>'N'
,p_show_reset=>'N'
,p_show_help=>'N'
,p_download_formats=>'XLSX'
,p_enable_mail_download=>'N'
,p_owner=>'EMASABANDA'
,p_internal_uid=>44520067740941324
,p_updated_on=>wwv_flow_imp.dz('20251021193630Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(44520190407941325)
,p_db_column_name=>'ID'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Id'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'NUMBER'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(44520214154941326)
,p_db_column_name=>'RESUMEN'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'-'
,p_sync_form_label=>'N'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(44520479531941328)
,p_db_column_name=>'VENTA_BRUTA'
,p_display_order=>30
,p_column_identifier=>'D'
,p_column_label=>'V. Bruta'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'NUMBER'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G990D00'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(44520555748941329)
,p_db_column_name=>'VENTA_NETA'
,p_display_order=>40
,p_column_identifier=>'E'
,p_column_label=>'V. Neta'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'NUMBER'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G990D00'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(44520648037941330)
,p_db_column_name=>'IVA_VENTAS'
,p_display_order=>50
,p_column_identifier=>'F'
,p_column_label=>'Iva Ventas'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'NUMBER'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G990D00'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(44522479142941348)
,p_db_column_name=>'DESCRIP_BALANCE'
,p_display_order=>60
,p_column_identifier=>'G'
,p_column_label=>'Descrip Balance'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_display_condition=>'APP_USER'
,p_display_condition2=>'EMASABANDA'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(45213545306289109)
,p_db_column_name=>'BC'
,p_display_order=>70
,p_column_identifier=>'L'
,p_column_label=>'Bc'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'NUMBER'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G990D00'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(45213648957289110)
,p_db_column_name=>'DIF'
,p_display_order=>80
,p_column_identifier=>'M'
,p_column_label=>'Dif'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'NUMBER'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G990D00'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(50248960989209236)
,p_db_column_name=>'CTA_BALANCE'
,p_display_order=>90
,p_column_identifier=>'N'
,p_column_label=>'Cta Balance'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(44598548846298641)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'445986'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'ID:RESUMEN:DESCRIP_BALANCE:CTA_BALANCE:VENTA_BRUTA:VENTA_NETA:IVA_VENTAS:BC:DIF:'
,p_sum_columns_on_break=>'VENTA_BRUTA:VENTA_NETA:IVA_VENTAS'
);
wwv_flow_imp_page.create_worksheet_condition(
 p_id=>wwv_flow_imp.id(57414233929811920)
,p_report_id=>wwv_flow_imp.id(44598548846298641)
,p_name=>'DIFERENCA CON EL BC'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'DIF'
,p_operator=>'is not null'
,p_expr=>'0'
,p_condition_sql=>' (case when ("DIF" is not null) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# #APXWS_OP_NAME#'
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_column_bg_color=>'#050505'
,p_column_font_color=>'#ffffff'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(44520778640941331)
,p_plug_name=>'Resumen de ICE Ventas'
,p_title=>'Resumen de ICE'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(38289867500120143)
,p_plug_display_sequence=>60
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'WITH ',
' T_ICE AS(',
'    SELECT  TP_DOC,SUM (pk_commons.safe_to_number(ICE))ICE , (SELECT VALOR FROM DATA.T_CORP_UDC WHERE REGEXP_LIKE (ID_CABECERA, ''FINZ_GT05'') AND ID_TABLA!=''000''  and descripcion2 =''BUSQUEDA DE BALANCE D/C ICES'' ) TIPO_BUSQ_BC',
'        , :P194_PERIODO PERIODO ',
'    FROM t_finz_gestiontributariadatos t,',
'    JSON_TABLE(',
'        case when t.estado=3 then t.DATOSFIN ELSE t.DATOSMOD END ,''$[*]'' COLUMNS(TP_DOC VARCHAR(3999) PATH''$.TPDOC_VAL'',ICE NUMBER PATH''$.ICE'')',
'    )jt WHERE id=:P194_IDDATO',
'    group by TP_DOC',
')',
',T_DETALLE AS (',
'    SELECT 1 id, ''IMPUESTO CONSUMOS ESPECIALES BRUTO'' TIPO_RESUMEN,''BRUTO'' RESUMEN,MAX(TIPO_BUSQ_BC)TIPO_BUSQ_BC,MAX(PERIODO)PERIODO, SUM(ICE) SUM_ICE, SUM(DECODE(TP_DOC,''D1'',ICE,0)) SUM_ICE_D1, SUM(ICE) - SUM(DECODE(TP_DOC,''D1'',ICE,0)) BRUTO_IMP_1,S'
||'UM(ICE) - SUM(DECODE(TP_DOC,''D1'',ICE,0)) BRUTO_IMP_2 FROM T_ICE UNION ALL',
'    SELECT 2 id, ''IMPUESTO CONSUMOS ESPECIALES NETTO'' TIPO_RESUMEN,''NETO''  RESUMEN,MAX(TIPO_BUSQ_BC)TIPO_BUSQ_BC,MAX(PERIODO)PERIODO, SUM(ICE) SUM_ICE, SUM(DECODE(TP_DOC,''D1'',ICE,0)) SUM_ICE_D1, SUM(ICE) - SUM(DECODE(TP_DOC,''D0'',ICE,0)) NETTO_IMP_1,S'
||'UM(ICE) - SUM(DECODE(TP_DOC,''D0'',ICE,0)) NETTO_IMP_2 FROM T_ICE',
')',
'SELECT ',
' ID, RESUMEN, BRUTO_IMP_1, BRUTO_IMP_2, DESCRIP_BALANCE, CTA_BALANCE  ',
',PK_FINZ_GESTIONTRIBUTARIA.f_trer_valorbalance (PERIODO,BUSQ,TIPO_BUSQ_BC) BC',
',(PK_FINZ_GESTIONTRIBUTARIA.f_trer_valorbalance (PERIODO,BUSQ,TIPO_BUSQ_BC)+(BRUTO_IMP_2))dif',
'FROM (',
'SELECT ID, TIPO_RESUMEN, RESUMEN, TIPO_BUSQ_BC, PERIODO, SUM_ICE, SUM_ICE_D1, BRUTO_IMP_1, BRUTO_IMP_2,',
'PK_FINZ_GESTIONTRIBUTARIA.f_trae_descripcioncuenta(TIPO_RESUMEN,''P'',''D'') DESCRIP_BALANCE,PK_FINZ_GESTIONTRIBUTARIA.f_trae_descripcioncuenta(TIPO_RESUMEN,''P'',''C'') CTA_BALANCE',
',PK_FINZ_GESTIONTRIBUTARIA.f_trae_descripcioncuenta(TIPO_RESUMEN,''P'',TIPO_BUSQ_BC) BUSQ',
'FROM T_DETALLE)',
'where :P194_IDPROCESO=''002'';',
''))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_plug_display_when_condition=>'P194_IDPROCESO'
,p_plug_display_when_cond2=>'002'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'Resumen de ICE'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
,p_updated_on=>wwv_flow_imp.dz('20250801152812Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(44520813364941332)
,p_max_row_count=>'1000000'
,p_allow_report_saving=>'N'
,p_show_search_textbox=>'N'
,p_report_list_mode=>'NONE'
,p_lazy_loading=>true
,p_show_detail_link=>'N'
,p_show_rows_per_page=>'N'
,p_show_filter=>'N'
,p_show_sort=>'N'
,p_show_control_break=>'N'
,p_show_highlight=>'N'
,p_show_computation=>'N'
,p_show_aggregate=>'N'
,p_show_chart=>'N'
,p_show_group_by=>'N'
,p_show_pivot=>'N'
,p_show_flashback=>'N'
,p_show_reset=>'N'
,p_show_help=>'N'
,p_download_formats=>'XLSX'
,p_enable_mail_download=>'N'
,p_owner=>'EMASABANDA'
,p_internal_uid=>44520813364941332
,p_updated_on=>wwv_flow_imp.dz('20250801152812Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(44520971780941333)
,p_db_column_name=>'ID'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Id'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'NUMBER'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(44521039791941334)
,p_db_column_name=>'RESUMEN'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'-'
,p_alternative_label=>'Resumen de ICE'
,p_sync_form_label=>'N'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(45212747966289101)
,p_db_column_name=>'DESCRIP_BALANCE'
,p_display_order=>50
,p_column_identifier=>'H'
,p_column_label=>'Descrip Balance'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(45212888097289102)
,p_db_column_name=>'BC'
,p_display_order=>60
,p_column_identifier=>'I'
,p_column_label=>'Bc'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'NUMBER'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G990D00'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(45212920600289103)
,p_db_column_name=>'DIF'
,p_display_order=>70
,p_column_identifier=>'J'
,p_column_label=>'Dif'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'NUMBER'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G990D00'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(50249393708209240)
,p_db_column_name=>'BRUTO_IMP_1'
,p_display_order=>80
,p_column_identifier=>'K'
,p_column_label=>'Impuesto'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'NUMBER'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G990D00'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(50249479541209241)
,p_db_column_name=>'BRUTO_IMP_2'
,p_display_order=>90
,p_column_identifier=>'L'
,p_column_label=>'Impuesto'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'NUMBER'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G990D00'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(50249589668209242)
,p_db_column_name=>'CTA_BALANCE'
,p_display_order=>100
,p_column_identifier=>'M'
,p_column_label=>'Cta Balance'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(44610908866346441)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'446110'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'ID:RESUMEN:DESCRIP_BALANCE:CTA_BALANCE:BRUTO_IMP_1:BRUTO_IMP_2:BC:DIF'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(50210972271203123)
,p_plug_name=>'Resumen de Retenciones'
,p_region_name=>'ir_reten'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_region_attributes=>'style="text-wrap-mode: nowrap;"'
,p_plug_template=>wwv_flow_imp.id(37806762584106520)
,p_plug_display_sequence=>40
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'with t_totales as (',
'    SELECT',
'         sum(NVL("DIV",0)) as "DIV",sum(NVL("RET_FTE_37",0)) as "RET_FTE_37",sum(NVL("RET_FTE_35",0)) as "RET_FTE_35",sum(NVL("RET_FTE_25",0)) as "RET_FTE_25",sum(NVL("RET_FTE_22",0)) as "RET_FTE_22"',
'        ,sum(NVL("RET_FTE_12_50",0)) as "RET_FTE_12_50",sum(NVL("RET_FTE_10",0)) as "RET_FTE_10",sum(NVL("RET_FTE_8",0)) as "RET_FTE_8",sum(NVL("RET_FTE_3",0)) as "RET_FTE_3"',
'        ,sum(NVL("RET_FTE_2_75",0)) as "RET_FTE_2_75",sum(NVL("RET_FTE_2",0)) as "RET_FTE_2",sum(NVL("RET_FTE_1_75",0)) as "RET_FTE_1_75",sum(NVL("RET_FTE_1",0)) as "RET_FTE_1"',
'        ,sum(NVL("RET_FTE_0_10",0)) as "RET_FTE_0_10",sum(NVL("RET_FTE_0_01",0)) as "RET_FTE_0_01",sum(NVL("RET_FTE_0",0)) as "RET_FTE_0",sum(NVL("AUT_RET_-3",0)) as "AUT_RET_-3"',
'        ,sum(NVL("RET_IVA_0",0)) as "RET_IVA_0",sum(NVL("RET_IVA_10",0)) as "RET_IVA_10",sum(NVL("RET_IVA_14_29",0)) as "RET_IVA_14_29",sum(NVL("RET_IVA_20",0)) as "RET_IVA_20"',
'        ,sum(NVL("RET_IVA_30",0)) as "RET_IVA_30",sum(NVL("RET_IVA_67",0)) as "RET_IVA_67",sum(NVL("RET_IVA_70",0)) as "RET_IVA_70",sum(NVL("RET_IVA_100",0)) as "RET_IVA_100"',
'    FROM t_finz_gestiontributariadatos t,JSON_TABLE(t.DATOSMOD,''$[*]'' COLUMNS(',
'                "VALIDADOR_SRI" VARCHAR2(399) PATH''$."VALIDADOR_SRI"'',"DIV" NUMBER PATH''$."DIV"'',"RET_FTE_37" NUMBER PATH''$."RET_FTE_37"'',"RET_FTE_35" NUMBER PATH''$."RET_FTE_35"'',"RET_FTE_25" NUMBER PATH''$."RET_FTE_25"'',"RET_FTE_22" NUMBER PATH''$."RE'
||'T_FTE_22"'',"RET_FTE_12_50" NUMBER PATH''$."RET_FTE_12_50"'',"RET_FTE_10" NUMBER PATH''$."RET_FTE_10"'',"RET_FTE_8" NUMBER PATH''$."RET_FTE_8"'',"RET_FTE_3" NUMBER PATH''$."RET_FTE_3"'',"RET_FTE_2_75" NUMBER PATH''$."RET_FTE_2_75"'',"RET_FTE_2" NUMBER PATH''$."R'
||'ET_FTE_2"'',"RET_FTE_1_75" NUMBER PATH''$."RET_FTE_1_75"'',"RET_FTE_1" NUMBER PATH''$."RET_FTE_1"'',"RET_FTE_0_10" NUMBER PATH''$."RET_FTE_0_10"'',"RET_FTE_0_01" NUMBER PATH''$."RET_FTE_0_01"'',"RET_FTE_0" NUMBER PATH''$."RET_FTE_0"'',"AUT_RET_-3" NUMBER PATH''$'
||'."AUT_RET_-3"'',"RET_IVA_0" NUMBER PATH''$."RET_IVA_0"'',"RET_IVA_10" NUMBER PATH''$."RET_IVA_10"'',"RET_IVA_14_29" NUMBER PATH''$."RET_IVA_14_29"'',"RET_IVA_20" NUMBER PATH''$."RET_IVA_20"'',"RET_IVA_30" NUMBER PATH''$."RET_IVA_30"'',"RET_IVA_67" NUMBER PATH''$'
||'."RET_IVA_67"'',"RET_IVA_70" NUMBER PATH''$."RET_IVA_70"'',"RET_IVA_100" NUMBER PATH''$."RET_IVA_100"''',
'            )',
'        )jt WHERE id=:P194_IDDATO AND UPPER(NVL(VALIDADOR_SRI,''X'')) NOT IN (''T'',''S'') --UPPER(VALIDADOR_SRI) NOT IN (''T'',''S'')',
')',
',t_etiquetas as (',
'    SELECT ',
'        ''DIV'' as etq001,''RET_FTE_37'' as etq002,''RET_FTE_35'' as etq003,''RET_FTE_25'' as etq004,''RET_FTE_22'' as etq005,''RET_FTE_12_50'' as etq006,''RET_FTE_10'' as etq007,',
'        ''RET_FTE_8'' as etq008,''RET_FTE_3'' as etq009,''RET_FTE_2_75'' as etq010,''RET_FTE_2'' as etq011,''RET_FTE_1_75'' as etq012,''RET_FTE_1'' as etq013,''RET_FTE_0_10'' as etq014,',
'        ''RET_FTE_0_01'' as etq015,''RET_FTE_0'' as etq016,''AUT_RET_-3'' as etq017,''RET_IVA_0'' as etq018,''RET_IVA_10'' as etq019,''RET_IVA_14_29'' as etq020,''RET_IVA_20'' as etq021,',
'        ''RET_IVA_30'' as etq022,''RET_IVA_67'' as etq023,''RET_IVA_70'' as etq024,''RET_IVA_100'' as etq025 ,',
'        (SELECT VALOR FROM DATA.T_CORP_UDC WHERE REGEXP_LIKE (ID_CABECERA, ''FINZ_GT05'') AND ID_TABLA!=''000''  and descripcion2 =''BUSQUEDA DE BALANCE D/C RETE'' ) TIPO_BUSQ_BC,',
'        :P194_PERIODO PERIODO',
'    FROM  dual',
')',
',T_filavacia as (',
'    SELECT ',
'         null etq001,null etq002,null etq003,null etq004,null etq005,null etq006,null etq007,null etq008,null etq009,null etq010,null etq011,null etq012,null etq013',
'        ,null etq014,null etq015,null etq016,null etq017,null etq018,null etq019,null etq020,null etq021,null etq022,null etq023,null etq024,null etq025',
'    FROM  dual',
')',
',T_BALANCE AS (',
'    SELECT ',
'        abs(NVL(PK_FINZ_GESTIONTRIBUTARIA.f_trer_valorbalance (PERIODO,PK_FINZ_GESTIONTRIBUTARIA.f_trae_descripcioncuenta(''BC_''||ETQ001,''P'',TIPO_BUSQ_BC),TIPO_BUSQ_BC),0)	+NVL(PK_FINZ_GESTIONTRIBUTARIA.f_trer_valorbalance (PERIODO,PK_FINZ_GESTIONTRIB'
||'UTARIA.f_trae_descripcioncuenta(''BC_''||ETQ001,''S'',TIPO_BUSQ_BC),TIPO_BUSQ_BC),0)) AS ETQ001,',
'        abs(NVL(PK_FINZ_GESTIONTRIBUTARIA.f_trer_valorbalance (PERIODO,PK_FINZ_GESTIONTRIBUTARIA.f_trae_descripcioncuenta(''BC_''||ETQ002,''P'',TIPO_BUSQ_BC),TIPO_BUSQ_BC),0)	+NVL(PK_FINZ_GESTIONTRIBUTARIA.f_trer_valorbalance (PERIODO,PK_FINZ_GESTIONTRIB'
||'UTARIA.f_trae_descripcioncuenta(''BC_''||ETQ002,''S'',TIPO_BUSQ_BC),TIPO_BUSQ_BC),0)) AS ETQ002,',
'        abs(NVL(PK_FINZ_GESTIONTRIBUTARIA.f_trer_valorbalance (PERIODO,PK_FINZ_GESTIONTRIBUTARIA.f_trae_descripcioncuenta(''BC_''||ETQ003,''P'',TIPO_BUSQ_BC),TIPO_BUSQ_BC),0)	+NVL(PK_FINZ_GESTIONTRIBUTARIA.f_trer_valorbalance (PERIODO,PK_FINZ_GESTIONTRIB'
||'UTARIA.f_trae_descripcioncuenta(''BC_''||ETQ003,''S'',TIPO_BUSQ_BC),TIPO_BUSQ_BC),0)) AS ETQ003,',
'        abs(NVL(PK_FINZ_GESTIONTRIBUTARIA.f_trer_valorbalance (PERIODO,PK_FINZ_GESTIONTRIBUTARIA.f_trae_descripcioncuenta(''BC_''||ETQ004,''P'',TIPO_BUSQ_BC),TIPO_BUSQ_BC),0)	+NVL(PK_FINZ_GESTIONTRIBUTARIA.f_trer_valorbalance (PERIODO,PK_FINZ_GESTIONTRIB'
||'UTARIA.f_trae_descripcioncuenta(''BC_''||ETQ004,''S'',TIPO_BUSQ_BC),TIPO_BUSQ_BC),0)) AS ETQ004,',
'        abs(NVL(PK_FINZ_GESTIONTRIBUTARIA.f_trer_valorbalance (PERIODO,PK_FINZ_GESTIONTRIBUTARIA.f_trae_descripcioncuenta(''BC_''||ETQ005,''P'',TIPO_BUSQ_BC),TIPO_BUSQ_BC),0)	+NVL(PK_FINZ_GESTIONTRIBUTARIA.f_trer_valorbalance (PERIODO,PK_FINZ_GESTIONTRIB'
||'UTARIA.f_trae_descripcioncuenta(''BC_''||ETQ005,''S'',TIPO_BUSQ_BC),TIPO_BUSQ_BC),0)) AS ETQ005,',
'        abs(NVL(PK_FINZ_GESTIONTRIBUTARIA.f_trer_valorbalance (PERIODO,PK_FINZ_GESTIONTRIBUTARIA.f_trae_descripcioncuenta(''BC_''||ETQ006,''P'',TIPO_BUSQ_BC),TIPO_BUSQ_BC),0)	+NVL(PK_FINZ_GESTIONTRIBUTARIA.f_trer_valorbalance (PERIODO,PK_FINZ_GESTIONTRIB'
||'UTARIA.f_trae_descripcioncuenta(''BC_''||ETQ006,''S'',TIPO_BUSQ_BC),TIPO_BUSQ_BC),0)) AS ETQ006,',
'        abs(NVL(PK_FINZ_GESTIONTRIBUTARIA.f_trer_valorbalance (PERIODO,PK_FINZ_GESTIONTRIBUTARIA.f_trae_descripcioncuenta(''BC_''||ETQ007,''P'',TIPO_BUSQ_BC),TIPO_BUSQ_BC),0)	+NVL(PK_FINZ_GESTIONTRIBUTARIA.f_trer_valorbalance (PERIODO,PK_FINZ_GESTIONTRIB'
||'UTARIA.f_trae_descripcioncuenta(''BC_''||ETQ007,''S'',TIPO_BUSQ_BC),TIPO_BUSQ_BC),0)) AS ETQ007,',
'        abs(NVL(PK_FINZ_GESTIONTRIBUTARIA.f_trer_valorbalance (PERIODO,PK_FINZ_GESTIONTRIBUTARIA.f_trae_descripcioncuenta(''BC_''||ETQ008,''P'',TIPO_BUSQ_BC),TIPO_BUSQ_BC),0)	+NVL(PK_FINZ_GESTIONTRIBUTARIA.f_trer_valorbalance (PERIODO,PK_FINZ_GESTIONTRIB'
||'UTARIA.f_trae_descripcioncuenta(''BC_''||ETQ008,''S'',TIPO_BUSQ_BC),TIPO_BUSQ_BC),0)) AS ETQ008,',
'        abs(NVL(PK_FINZ_GESTIONTRIBUTARIA.f_trer_valorbalance (PERIODO,PK_FINZ_GESTIONTRIBUTARIA.f_trae_descripcioncuenta(''BC_''||ETQ009,''P'',TIPO_BUSQ_BC),TIPO_BUSQ_BC),0)	+NVL(PK_FINZ_GESTIONTRIBUTARIA.f_trer_valorbalance (PERIODO,PK_FINZ_GESTIONTRIB'
||'UTARIA.f_trae_descripcioncuenta(''BC_''||ETQ009,''S'',TIPO_BUSQ_BC),TIPO_BUSQ_BC),0)) AS ETQ009,',
'        abs(NVL(PK_FINZ_GESTIONTRIBUTARIA.f_trer_valorbalance (PERIODO,PK_FINZ_GESTIONTRIBUTARIA.f_trae_descripcioncuenta(''BC_''||ETQ010,''P'',TIPO_BUSQ_BC),TIPO_BUSQ_BC),0)	+NVL(PK_FINZ_GESTIONTRIBUTARIA.f_trer_valorbalance (PERIODO,PK_FINZ_GESTIONTRIB'
||'UTARIA.f_trae_descripcioncuenta(''BC_''||ETQ010,''S'',TIPO_BUSQ_BC),TIPO_BUSQ_BC),0)) AS ETQ010,',
'        abs(NVL(PK_FINZ_GESTIONTRIBUTARIA.f_trer_valorbalance (PERIODO,PK_FINZ_GESTIONTRIBUTARIA.f_trae_descripcioncuenta(''BC_''||ETQ011,''P'',TIPO_BUSQ_BC),TIPO_BUSQ_BC),0)	+NVL(PK_FINZ_GESTIONTRIBUTARIA.f_trer_valorbalance (PERIODO,PK_FINZ_GESTIONTRIB'
||'UTARIA.f_trae_descripcioncuenta(''BC_''||ETQ011,''S'',TIPO_BUSQ_BC),TIPO_BUSQ_BC),0)) AS ETQ011,',
'        abs(NVL(PK_FINZ_GESTIONTRIBUTARIA.f_trer_valorbalance (PERIODO,PK_FINZ_GESTIONTRIBUTARIA.f_trae_descripcioncuenta(''BC_''||ETQ012,''P'',TIPO_BUSQ_BC),TIPO_BUSQ_BC),0)	+NVL(PK_FINZ_GESTIONTRIBUTARIA.f_trer_valorbalance (PERIODO,PK_FINZ_GESTIONTRIB'
||'UTARIA.f_trae_descripcioncuenta(''BC_''||ETQ012,''S'',TIPO_BUSQ_BC),TIPO_BUSQ_BC),0)) AS ETQ012,',
'        abs(NVL(PK_FINZ_GESTIONTRIBUTARIA.f_trer_valorbalance (PERIODO,PK_FINZ_GESTIONTRIBUTARIA.f_trae_descripcioncuenta(''BC_''||ETQ013,''P'',TIPO_BUSQ_BC),TIPO_BUSQ_BC),0)	+NVL(PK_FINZ_GESTIONTRIBUTARIA.f_trer_valorbalance (PERIODO,PK_FINZ_GESTIONTRIB'
||'UTARIA.f_trae_descripcioncuenta(''BC_''||ETQ013,''S'',TIPO_BUSQ_BC),TIPO_BUSQ_BC),0)) AS ETQ013,',
'        abs(NVL(PK_FINZ_GESTIONTRIBUTARIA.f_trer_valorbalance (PERIODO,PK_FINZ_GESTIONTRIBUTARIA.f_trae_descripcioncuenta(''BC_''||ETQ014,''P'',TIPO_BUSQ_BC),TIPO_BUSQ_BC),0)	+NVL(PK_FINZ_GESTIONTRIBUTARIA.f_trer_valorbalance (PERIODO,PK_FINZ_GESTIONTRIB'
||'UTARIA.f_trae_descripcioncuenta(''BC_''||ETQ014,''S'',TIPO_BUSQ_BC),TIPO_BUSQ_BC),0)) AS ETQ014,',
'        abs(NVL(PK_FINZ_GESTIONTRIBUTARIA.f_trer_valorbalance (PERIODO,PK_FINZ_GESTIONTRIBUTARIA.f_trae_descripcioncuenta(''BC_''||ETQ015,''P'',TIPO_BUSQ_BC),TIPO_BUSQ_BC),0)	+NVL(PK_FINZ_GESTIONTRIBUTARIA.f_trer_valorbalance (PERIODO,PK_FINZ_GESTIONTRIB'
||'UTARIA.f_trae_descripcioncuenta(''BC_''||ETQ015,''S'',TIPO_BUSQ_BC),TIPO_BUSQ_BC),0)) AS ETQ015,',
'        abs(NVL(PK_FINZ_GESTIONTRIBUTARIA.f_trer_valorbalance (PERIODO,PK_FINZ_GESTIONTRIBUTARIA.f_trae_descripcioncuenta(''BC_''||ETQ016,''P'',TIPO_BUSQ_BC),TIPO_BUSQ_BC),0)	+NVL(PK_FINZ_GESTIONTRIBUTARIA.f_trer_valorbalance (PERIODO,PK_FINZ_GESTIONTRIB'
||'UTARIA.f_trae_descripcioncuenta(''BC_''||ETQ016,''S'',TIPO_BUSQ_BC),TIPO_BUSQ_BC),0)) AS ETQ016,',
'        abs(NVL(PK_FINZ_GESTIONTRIBUTARIA.f_trer_valorbalance (PERIODO,PK_FINZ_GESTIONTRIBUTARIA.f_trae_descripcioncuenta(''BC_''||ETQ017,''P'',TIPO_BUSQ_BC),TIPO_BUSQ_BC),0)	+NVL(PK_FINZ_GESTIONTRIBUTARIA.f_trer_valorbalance (PERIODO,PK_FINZ_GESTIONTRIB'
||'UTARIA.f_trae_descripcioncuenta(''BC_''||ETQ017,''S'',TIPO_BUSQ_BC),TIPO_BUSQ_BC),0)) AS ETQ017,',
'        abs(NVL(PK_FINZ_GESTIONTRIBUTARIA.f_trer_valorbalance (PERIODO,PK_FINZ_GESTIONTRIBUTARIA.f_trae_descripcioncuenta(''BC_''||ETQ018,''P'',TIPO_BUSQ_BC),TIPO_BUSQ_BC),0)	+NVL(PK_FINZ_GESTIONTRIBUTARIA.f_trer_valorbalance (PERIODO,PK_FINZ_GESTIONTRIB'
||'UTARIA.f_trae_descripcioncuenta(''BC_''||ETQ018,''S'',TIPO_BUSQ_BC),TIPO_BUSQ_BC),0)) AS ETQ018,',
'        abs(NVL(PK_FINZ_GESTIONTRIBUTARIA.f_trer_valorbalance (PERIODO,PK_FINZ_GESTIONTRIBUTARIA.f_trae_descripcioncuenta(''BC_''||ETQ019,''P'',TIPO_BUSQ_BC),TIPO_BUSQ_BC),0)	+NVL(PK_FINZ_GESTIONTRIBUTARIA.f_trer_valorbalance (PERIODO,PK_FINZ_GESTIONTRIB'
||'UTARIA.f_trae_descripcioncuenta(''BC_''||ETQ019,''S'',TIPO_BUSQ_BC),TIPO_BUSQ_BC),0)) AS ETQ019,',
'        abs(NVL(PK_FINZ_GESTIONTRIBUTARIA.f_trer_valorbalance (PERIODO,PK_FINZ_GESTIONTRIBUTARIA.f_trae_descripcioncuenta(''BC_''||ETQ020,''P'',TIPO_BUSQ_BC),TIPO_BUSQ_BC),0)	+NVL(PK_FINZ_GESTIONTRIBUTARIA.f_trer_valorbalance (PERIODO,PK_FINZ_GESTIONTRIB'
||'UTARIA.f_trae_descripcioncuenta(''BC_''||ETQ020,''S'',TIPO_BUSQ_BC),TIPO_BUSQ_BC),0)) AS ETQ020,',
'        abs(NVL(PK_FINZ_GESTIONTRIBUTARIA.f_trer_valorbalance (PERIODO,PK_FINZ_GESTIONTRIBUTARIA.f_trae_descripcioncuenta(''BC_''||ETQ021,''P'',TIPO_BUSQ_BC),TIPO_BUSQ_BC),0)	+NVL(PK_FINZ_GESTIONTRIBUTARIA.f_trer_valorbalance (PERIODO,PK_FINZ_GESTIONTRIB'
||'UTARIA.f_trae_descripcioncuenta(''BC_''||ETQ021,''S'',TIPO_BUSQ_BC),TIPO_BUSQ_BC),0)) AS ETQ021,',
'        abs(NVL(PK_FINZ_GESTIONTRIBUTARIA.f_trer_valorbalance (PERIODO,PK_FINZ_GESTIONTRIBUTARIA.f_trae_descripcioncuenta(''BC_''||ETQ022,''P'',TIPO_BUSQ_BC),TIPO_BUSQ_BC),0)	+NVL(PK_FINZ_GESTIONTRIBUTARIA.f_trer_valorbalance (PERIODO,PK_FINZ_GESTIONTRIB'
||'UTARIA.f_trae_descripcioncuenta(''BC_''||ETQ022,''S'',TIPO_BUSQ_BC),TIPO_BUSQ_BC),0)) AS ETQ022,',
'        abs(NVL(PK_FINZ_GESTIONTRIBUTARIA.f_trer_valorbalance (PERIODO,PK_FINZ_GESTIONTRIBUTARIA.f_trae_descripcioncuenta(''BC_''||ETQ023,''P'',TIPO_BUSQ_BC),TIPO_BUSQ_BC),0)	+NVL(PK_FINZ_GESTIONTRIBUTARIA.f_trer_valorbalance (PERIODO,PK_FINZ_GESTIONTRIB'
||'UTARIA.f_trae_descripcioncuenta(''BC_''||ETQ023,''S'',TIPO_BUSQ_BC),TIPO_BUSQ_BC),0)) AS ETQ023,',
'        abs(NVL(PK_FINZ_GESTIONTRIBUTARIA.f_trer_valorbalance (PERIODO,PK_FINZ_GESTIONTRIBUTARIA.f_trae_descripcioncuenta(''BC_''||ETQ024,''P'',TIPO_BUSQ_BC),TIPO_BUSQ_BC),0)	+NVL(PK_FINZ_GESTIONTRIBUTARIA.f_trer_valorbalance (PERIODO,PK_FINZ_GESTIONTRIB'
||'UTARIA.f_trae_descripcioncuenta(''BC_''||ETQ024,''S'',TIPO_BUSQ_BC),TIPO_BUSQ_BC),0)) AS ETQ024,',
'        abs(NVL(PK_FINZ_GESTIONTRIBUTARIA.f_trer_valorbalance (PERIODO,PK_FINZ_GESTIONTRIBUTARIA.f_trae_descripcioncuenta(''BC_''||ETQ025,''P'',TIPO_BUSQ_BC),TIPO_BUSQ_BC),0)	+NVL(PK_FINZ_GESTIONTRIBUTARIA.f_trer_valorbalance (PERIODO,PK_FINZ_GESTIONTRIB'
||'UTARIA.f_trae_descripcioncuenta(''BC_''||ETQ025,''S'',TIPO_BUSQ_BC),TIPO_BUSQ_BC),0)) AS ETQ025',
'    FROM t_etiquetas ',
')',
',T_MAYORES AS (',
'    SELECT ',
'        abs(NVL(PK_FINZ_GESTIONTRIBUTARIA.f_trer_valorbalance (PERIODO,PK_FINZ_GESTIONTRIBUTARIA.f_trae_descripcioncuenta(''MY_''||ETQ001,''P'',TIPO_BUSQ_BC),TIPO_BUSQ_BC),0)	+NVL(PK_FINZ_GESTIONTRIBUTARIA.f_trer_valorbalance (PERIODO,PK_FINZ_GESTIONTRIB'
||'UTARIA.f_trae_descripcioncuenta(''MY_''||ETQ001,''S'',TIPO_BUSQ_BC),TIPO_BUSQ_BC),0)) AS ETQ001,',
'        abs(NVL(PK_FINZ_GESTIONTRIBUTARIA.f_trer_valorbalance (PERIODO,PK_FINZ_GESTIONTRIBUTARIA.f_trae_descripcioncuenta(''MY_''||ETQ002,''P'',TIPO_BUSQ_BC),TIPO_BUSQ_BC),0)	+NVL(PK_FINZ_GESTIONTRIBUTARIA.f_trer_valorbalance (PERIODO,PK_FINZ_GESTIONTRIB'
||'UTARIA.f_trae_descripcioncuenta(''MY_''||ETQ002,''S'',TIPO_BUSQ_BC),TIPO_BUSQ_BC),0)) AS ETQ002,',
'        abs(NVL(PK_FINZ_GESTIONTRIBUTARIA.f_trer_valorbalance (PERIODO,PK_FINZ_GESTIONTRIBUTARIA.f_trae_descripcioncuenta(''MY_''||ETQ003,''P'',TIPO_BUSQ_BC),TIPO_BUSQ_BC),0)	+NVL(PK_FINZ_GESTIONTRIBUTARIA.f_trer_valorbalance (PERIODO,PK_FINZ_GESTIONTRIB'
||'UTARIA.f_trae_descripcioncuenta(''MY_''||ETQ003,''S'',TIPO_BUSQ_BC),TIPO_BUSQ_BC),0)) AS ETQ003,',
'        abs(NVL(PK_FINZ_GESTIONTRIBUTARIA.f_trer_valorbalance (PERIODO,PK_FINZ_GESTIONTRIBUTARIA.f_trae_descripcioncuenta(''MY_''||ETQ004,''P'',TIPO_BUSQ_BC),TIPO_BUSQ_BC),0)	+NVL(PK_FINZ_GESTIONTRIBUTARIA.f_trer_valorbalance (PERIODO,PK_FINZ_GESTIONTRIB'
||'UTARIA.f_trae_descripcioncuenta(''MY_''||ETQ004,''S'',TIPO_BUSQ_BC),TIPO_BUSQ_BC),0)) AS ETQ004,',
'        abs(NVL(PK_FINZ_GESTIONTRIBUTARIA.f_trer_valorbalance (PERIODO,PK_FINZ_GESTIONTRIBUTARIA.f_trae_descripcioncuenta(''MY_''||ETQ005,''P'',TIPO_BUSQ_BC),TIPO_BUSQ_BC),0)	+NVL(PK_FINZ_GESTIONTRIBUTARIA.f_trer_valorbalance (PERIODO,PK_FINZ_GESTIONTRIB'
||'UTARIA.f_trae_descripcioncuenta(''MY_''||ETQ005,''S'',TIPO_BUSQ_BC),TIPO_BUSQ_BC),0)) AS ETQ005,',
'        abs(NVL(PK_FINZ_GESTIONTRIBUTARIA.f_trer_valorbalance (PERIODO,PK_FINZ_GESTIONTRIBUTARIA.f_trae_descripcioncuenta(''MY_''||ETQ006,''P'',TIPO_BUSQ_BC),TIPO_BUSQ_BC),0)	+NVL(PK_FINZ_GESTIONTRIBUTARIA.f_trer_valorbalance (PERIODO,PK_FINZ_GESTIONTRIB'
||'UTARIA.f_trae_descripcioncuenta(''MY_''||ETQ006,''S'',TIPO_BUSQ_BC),TIPO_BUSQ_BC),0)) AS ETQ006,',
'        abs(NVL(PK_FINZ_GESTIONTRIBUTARIA.f_trer_valorbalance (PERIODO,PK_FINZ_GESTIONTRIBUTARIA.f_trae_descripcioncuenta(''MY_''||ETQ007,''P'',TIPO_BUSQ_BC),TIPO_BUSQ_BC),0)	+NVL(PK_FINZ_GESTIONTRIBUTARIA.f_trer_valorbalance (PERIODO,PK_FINZ_GESTIONTRIB'
||'UTARIA.f_trae_descripcioncuenta(''MY_''||ETQ007,''S'',TIPO_BUSQ_BC),TIPO_BUSQ_BC),0)) AS ETQ007,',
'        abs(NVL(PK_FINZ_GESTIONTRIBUTARIA.f_trer_valorbalance (PERIODO,PK_FINZ_GESTIONTRIBUTARIA.f_trae_descripcioncuenta(''MY_''||ETQ008,''P'',TIPO_BUSQ_BC),TIPO_BUSQ_BC),0)	+NVL(PK_FINZ_GESTIONTRIBUTARIA.f_trer_valorbalance (PERIODO,PK_FINZ_GESTIONTRIB'
||'UTARIA.f_trae_descripcioncuenta(''MY_''||ETQ008,''S'',TIPO_BUSQ_BC),TIPO_BUSQ_BC),0)) AS ETQ008,',
'        abs(NVL(PK_FINZ_GESTIONTRIBUTARIA.f_trer_valorbalance (PERIODO,PK_FINZ_GESTIONTRIBUTARIA.f_trae_descripcioncuenta(''MY_''||ETQ009,''P'',TIPO_BUSQ_BC),TIPO_BUSQ_BC),0)	+NVL(PK_FINZ_GESTIONTRIBUTARIA.f_trer_valorbalance (PERIODO,PK_FINZ_GESTIONTRIB'
||'UTARIA.f_trae_descripcioncuenta(''MY_''||ETQ009,''S'',TIPO_BUSQ_BC),TIPO_BUSQ_BC),0)) AS ETQ009,',
'        abs(NVL(PK_FINZ_GESTIONTRIBUTARIA.f_trer_valorbalance (PERIODO,PK_FINZ_GESTIONTRIBUTARIA.f_trae_descripcioncuenta(''MY_''||ETQ010,''P'',TIPO_BUSQ_BC),TIPO_BUSQ_BC),0)	+NVL(PK_FINZ_GESTIONTRIBUTARIA.f_trer_valorbalance (PERIODO,PK_FINZ_GESTIONTRIB'
||'UTARIA.f_trae_descripcioncuenta(''MY_''||ETQ010,''S'',TIPO_BUSQ_BC),TIPO_BUSQ_BC),0)) AS ETQ010,',
'        abs(NVL(PK_FINZ_GESTIONTRIBUTARIA.f_trer_valorbalance (PERIODO,PK_FINZ_GESTIONTRIBUTARIA.f_trae_descripcioncuenta(''MY_''||ETQ011,''P'',TIPO_BUSQ_BC),TIPO_BUSQ_BC),0)	+NVL(PK_FINZ_GESTIONTRIBUTARIA.f_trer_valorbalance (PERIODO,PK_FINZ_GESTIONTRIB'
||'UTARIA.f_trae_descripcioncuenta(''MY_''||ETQ011,''S'',TIPO_BUSQ_BC),TIPO_BUSQ_BC),0)) AS ETQ011,',
'        abs(NVL(PK_FINZ_GESTIONTRIBUTARIA.f_trer_valorbalance (PERIODO,PK_FINZ_GESTIONTRIBUTARIA.f_trae_descripcioncuenta(''MY_''||ETQ012,''P'',TIPO_BUSQ_BC),TIPO_BUSQ_BC),0)	+NVL(PK_FINZ_GESTIONTRIBUTARIA.f_trer_valorbalance (PERIODO,PK_FINZ_GESTIONTRIB'
||'UTARIA.f_trae_descripcioncuenta(''MY_''||ETQ012,''S'',TIPO_BUSQ_BC),TIPO_BUSQ_BC),0)) AS ETQ012,',
'        abs(NVL(PK_FINZ_GESTIONTRIBUTARIA.f_trer_valorbalance (PERIODO,PK_FINZ_GESTIONTRIBUTARIA.f_trae_descripcioncuenta(''MY_''||ETQ013,''P'',TIPO_BUSQ_BC),TIPO_BUSQ_BC),0)	+NVL(PK_FINZ_GESTIONTRIBUTARIA.f_trer_valorbalance (PERIODO,PK_FINZ_GESTIONTRIB'
||'UTARIA.f_trae_descripcioncuenta(''MY_''||ETQ013,''S'',TIPO_BUSQ_BC),TIPO_BUSQ_BC),0)) AS ETQ013,',
'        abs(NVL(PK_FINZ_GESTIONTRIBUTARIA.f_trer_valorbalance (PERIODO,PK_FINZ_GESTIONTRIBUTARIA.f_trae_descripcioncuenta(''MY_''||ETQ014,''P'',TIPO_BUSQ_BC),TIPO_BUSQ_BC),0)	+NVL(PK_FINZ_GESTIONTRIBUTARIA.f_trer_valorbalance (PERIODO,PK_FINZ_GESTIONTRIB'
||'UTARIA.f_trae_descripcioncuenta(''MY_''||ETQ014,''S'',TIPO_BUSQ_BC),TIPO_BUSQ_BC),0)) AS ETQ014,',
'        abs(NVL(PK_FINZ_GESTIONTRIBUTARIA.f_trer_valorbalance (PERIODO,PK_FINZ_GESTIONTRIBUTARIA.f_trae_descripcioncuenta(''MY_''||ETQ015,''P'',TIPO_BUSQ_BC),TIPO_BUSQ_BC),0)	+NVL(PK_FINZ_GESTIONTRIBUTARIA.f_trer_valorbalance (PERIODO,PK_FINZ_GESTIONTRIB'
||'UTARIA.f_trae_descripcioncuenta(''MY_''||ETQ015,''S'',TIPO_BUSQ_BC),TIPO_BUSQ_BC),0)) AS ETQ015,',
'        abs(NVL(PK_FINZ_GESTIONTRIBUTARIA.f_trer_valorbalance (PERIODO,PK_FINZ_GESTIONTRIBUTARIA.f_trae_descripcioncuenta(''MY_''||ETQ016,''P'',TIPO_BUSQ_BC),TIPO_BUSQ_BC),0)	+NVL(PK_FINZ_GESTIONTRIBUTARIA.f_trer_valorbalance (PERIODO,PK_FINZ_GESTIONTRIB'
||'UTARIA.f_trae_descripcioncuenta(''MY_''||ETQ016,''S'',TIPO_BUSQ_BC),TIPO_BUSQ_BC),0)) AS ETQ016,',
'        abs(NVL(PK_FINZ_GESTIONTRIBUTARIA.f_trer_valorbalance (PERIODO,PK_FINZ_GESTIONTRIBUTARIA.f_trae_descripcioncuenta(''MY_''||ETQ017,''P'',TIPO_BUSQ_BC),TIPO_BUSQ_BC),0)	+NVL(PK_FINZ_GESTIONTRIBUTARIA.f_trer_valorbalance (PERIODO,PK_FINZ_GESTIONTRIB'
||'UTARIA.f_trae_descripcioncuenta(''MY_''||ETQ017,''S'',TIPO_BUSQ_BC),TIPO_BUSQ_BC),0)) AS ETQ017,',
'        abs(NVL(PK_FINZ_GESTIONTRIBUTARIA.f_trer_valorbalance (PERIODO,PK_FINZ_GESTIONTRIBUTARIA.f_trae_descripcioncuenta(''MY_''||ETQ018,''P'',TIPO_BUSQ_BC),TIPO_BUSQ_BC),0)	+NVL(PK_FINZ_GESTIONTRIBUTARIA.f_trer_valorbalance (PERIODO,PK_FINZ_GESTIONTRIB'
||'UTARIA.f_trae_descripcioncuenta(''MY_''||ETQ018,''S'',TIPO_BUSQ_BC),TIPO_BUSQ_BC),0)) AS ETQ018,',
'        abs(NVL(PK_FINZ_GESTIONTRIBUTARIA.f_trer_valorbalance (PERIODO,PK_FINZ_GESTIONTRIBUTARIA.f_trae_descripcioncuenta(''MY_''||ETQ019,''P'',TIPO_BUSQ_BC),TIPO_BUSQ_BC),0)	+NVL(PK_FINZ_GESTIONTRIBUTARIA.f_trer_valorbalance (PERIODO,PK_FINZ_GESTIONTRIB'
||'UTARIA.f_trae_descripcioncuenta(''MY_''||ETQ019,''S'',TIPO_BUSQ_BC),TIPO_BUSQ_BC),0)) AS ETQ019,',
'        abs(NVL(PK_FINZ_GESTIONTRIBUTARIA.f_trer_valorbalance (PERIODO,PK_FINZ_GESTIONTRIBUTARIA.f_trae_descripcioncuenta(''MY_''||ETQ020,''P'',TIPO_BUSQ_BC),TIPO_BUSQ_BC),0)	+NVL(PK_FINZ_GESTIONTRIBUTARIA.f_trer_valorbalance (PERIODO,PK_FINZ_GESTIONTRIB'
||'UTARIA.f_trae_descripcioncuenta(''MY_''||ETQ020,''S'',TIPO_BUSQ_BC),TIPO_BUSQ_BC),0)) AS ETQ020,',
'        abs(NVL(PK_FINZ_GESTIONTRIBUTARIA.f_trer_valorbalance (PERIODO,PK_FINZ_GESTIONTRIBUTARIA.f_trae_descripcioncuenta(''MY_''||ETQ021,''P'',TIPO_BUSQ_BC),TIPO_BUSQ_BC),0)	+NVL(PK_FINZ_GESTIONTRIBUTARIA.f_trer_valorbalance (PERIODO,PK_FINZ_GESTIONTRIB'
||'UTARIA.f_trae_descripcioncuenta(''MY_''||ETQ021,''S'',TIPO_BUSQ_BC),TIPO_BUSQ_BC),0)) AS ETQ021,',
'        abs(NVL(PK_FINZ_GESTIONTRIBUTARIA.f_trer_valorbalance (PERIODO,PK_FINZ_GESTIONTRIBUTARIA.f_trae_descripcioncuenta(''MY_''||ETQ022,''P'',TIPO_BUSQ_BC),TIPO_BUSQ_BC),0)	+NVL(PK_FINZ_GESTIONTRIBUTARIA.f_trer_valorbalance (PERIODO,PK_FINZ_GESTIONTRIB'
||'UTARIA.f_trae_descripcioncuenta(''MY_''||ETQ022,''S'',TIPO_BUSQ_BC),TIPO_BUSQ_BC),0)) AS ETQ022,',
'        abs(NVL(PK_FINZ_GESTIONTRIBUTARIA.f_trer_valorbalance (PERIODO,PK_FINZ_GESTIONTRIBUTARIA.f_trae_descripcioncuenta(''MY_''||ETQ023,''P'',TIPO_BUSQ_BC),TIPO_BUSQ_BC),0)	+NVL(PK_FINZ_GESTIONTRIBUTARIA.f_trer_valorbalance (PERIODO,PK_FINZ_GESTIONTRIB'
||'UTARIA.f_trae_descripcioncuenta(''MY_''||ETQ023,''S'',TIPO_BUSQ_BC),TIPO_BUSQ_BC),0)) AS ETQ023,',
'        abs(NVL(PK_FINZ_GESTIONTRIBUTARIA.f_trer_valorbalance (PERIODO,PK_FINZ_GESTIONTRIBUTARIA.f_trae_descripcioncuenta(''MY_''||ETQ024,''P'',TIPO_BUSQ_BC),TIPO_BUSQ_BC),0)	+NVL(PK_FINZ_GESTIONTRIBUTARIA.f_trer_valorbalance (PERIODO,PK_FINZ_GESTIONTRIB'
||'UTARIA.f_trae_descripcioncuenta(''MY_''||ETQ024,''S'',TIPO_BUSQ_BC),TIPO_BUSQ_BC),0)) AS ETQ024,',
'        abs(NVL(PK_FINZ_GESTIONTRIBUTARIA.f_trer_valorbalance (PERIODO,PK_FINZ_GESTIONTRIBUTARIA.f_trae_descripcioncuenta(''MY_''||ETQ025,''P'',TIPO_BUSQ_BC),TIPO_BUSQ_BC),0)	+NVL(PK_FINZ_GESTIONTRIBUTARIA.f_trer_valorbalance (PERIODO,PK_FINZ_GESTIONTRIB'
||'UTARIA.f_trae_descripcioncuenta(''MY_''||ETQ025,''S'',TIPO_BUSQ_BC),TIPO_BUSQ_BC),0)) AS ETQ025',
'    FROM t_etiquetas ',
')',
',T_DIFBALANCE AS (',
'    SELECT SUM( etq001)  etq001,SUM( etq002)  etq002,SUM( etq003)  etq003,SUM( etq004)  etq004,SUM( etq005)  etq005,SUM( etq006)  etq006,SUM( etq007)  etq007,SUM( etq008)  etq008,SUM( etq009)  etq009,SUM( etq010)  etq010,SUM( etq011)  etq011,SUM( etq'
||'012)  etq012,SUM( etq013)  etq013,SUM( etq014)  etq014,SUM( etq015)  etq015,SUM( etq016)  etq016,SUM( etq017)  etq017,SUM( etq018)  etq018,SUM( etq019)  etq019,SUM( etq020)  etq020,SUM( etq021)  etq021,SUM( etq022)  etq022,SUM( etq023)  etq023,SUM( e'
||'tq024)  etq024,SUM( etq025 )  etq025 ',
'    FROM (',
'        SELECT etq001, etq002, etq003, etq004, etq005, etq006, etq007, etq008, etq009, etq010, etq011, etq012, etq013, etq014, etq015, etq016, etq017, etq018, etq019, etq020, etq021, etq022, etq023, etq024, etq025  FROM T_BALANCE',
'        UNION ALL ',
'        SELECT "DIV" ,"RET_FTE_37" ,"RET_FTE_35" ,"RET_FTE_25" ,"RET_FTE_22" ,"RET_FTE_12_50" ,"RET_FTE_10" ,"RET_FTE_8" ,"RET_FTE_3" ,"RET_FTE_2_75" ,"RET_FTE_2" ,"RET_FTE_1_75" ,"RET_FTE_1" ,"RET_FTE_0_10" ,"RET_FTE_0_01" ,"RET_FTE_0" ,"AUT_RET_-3"'
||' ,"RET_IVA_0" ,"RET_IVA_10" ,"RET_IVA_14_29" ,"RET_IVA_20" ,"RET_IVA_30" ,"RET_IVA_67" ,"RET_IVA_70" ,"RET_IVA_100" FROM T_TOTALES',
'    )',
')',
',T_DIFMAYORES AS (',
'    SELECT SUM( etq001)  etq001,SUM( etq002)  etq002,SUM( etq003)  etq003,SUM( etq004)  etq004,SUM( etq005)  etq005,SUM( etq006)  etq006,SUM( etq007)  etq007,SUM( etq008)  etq008,SUM( etq009)  etq009,SUM( etq010)  etq010,SUM( etq011)  etq011,SUM( etq'
||'012)  etq012,SUM( etq013)  etq013,SUM( etq014)  etq014,SUM( etq015)  etq015,SUM( etq016)  etq016,SUM( etq017)  etq017,SUM( etq018)  etq018,SUM( etq019)  etq019,SUM( etq020)  etq020,SUM( etq021)  etq021,SUM( etq022)  etq022,SUM( etq023)  etq023,SUM( e'
||'tq024)  etq024,SUM( etq025 )  etq025 ',
'    FROM (',
'        SELECT etq001, etq002, etq003, etq004, etq005, etq006, etq007, etq008, etq009, etq010, etq011, etq012, etq013, etq014, etq015, etq016, etq017, etq018, etq019, etq020, etq021, etq022, etq023, etq024, etq025  FROM T_MAYORES',
'        UNION ALL ',
'        SELECT "DIV" ,"RET_FTE_37" ,"RET_FTE_35" ,"RET_FTE_25" ,"RET_FTE_22" ,"RET_FTE_12_50" ,"RET_FTE_10" ,"RET_FTE_8" ,"RET_FTE_3" ,"RET_FTE_2_75" ,"RET_FTE_2" ,"RET_FTE_1_75" ,"RET_FTE_1" ,"RET_FTE_0_10" ,"RET_FTE_0_01" ,"RET_FTE_0" ,"AUT_RET_-3"'
||' ,"RET_IVA_0" ,"RET_IVA_10" ,"RET_IVA_14_29" ,"RET_IVA_20" ,"RET_IVA_30" ,"RET_IVA_67" ,"RET_IVA_70" ,"RET_IVA_100" FROM T_TOTALES',
'    )',
')',
',T_RESUMEN AS(',
'    SELECT 1 ID, ''TOTALES:''RESUMEN ,T.* FROM T_TOTALES  T UNION ALL',
'    select 2 ID, '' '',etq001,etq002,etq003,etq004,etq005,etq006,etq007,etq008,etq009,etq010,etq011,etq012,etq013,etq014,etq015,etq016,etq017,etq018,etq019,etq020,etq021,etq022,etq023,etq024,etq025 from T_filavacia union all',
'    SELECT 3 ID, ''BALANCE:''RESUMEN ,T.* FROM T_BALANCE  T UNION ALL',
'    select 4 ID, '' '',etq001,etq002,etq003,etq004,etq005,etq006,etq007,etq008,etq009,etq010,etq011,etq012,etq013,etq014,etq015,etq016,etq017,etq018,etq019,etq020,etq021,etq022,etq023,etq024,etq025 from T_filavacia union all',
'    SELECT 5 ID, ''MAYORES:''RESUMEN ,T.* FROM T_MAYORES  T UNION ALL',
'    select 6 ID, '' '',etq001,etq002,etq003,etq004,etq005,etq006,etq007,etq008,etq009,etq010,etq011,etq012,etq013,etq014,etq015,etq016,etq017,etq018,etq019,etq020,etq021,etq022,etq023,etq024,etq025 from T_filavacia union all',
'    SELECT 7 ID, ''DIF. BALANCE:''RESUMEN ,T.* FROM T_DIFBALANCE  T UNION ALL',
'    select 8 ID, '' '',etq001,etq002,etq003,etq004,etq005,etq006,etq007,etq008,etq009,etq010,etq011,etq012,etq013,etq014,etq015,etq016,etq017,etq018,etq019,etq020,etq021,etq022,etq023,etq024,etq025 from T_filavacia union all',
'    SELECT 9 ID, ''DIF. MAYORES:''RESUMEN ,T.* FROM T_DIFMAYORES T ',
')',
'SELECT RESUMEN, TO_NUMBER(DECODE("DIV",0,null,"DIV")) as "DIV",	TO_NUMBER(DECODE("RET_FTE_37",0,null,"RET_FTE_37")) as "RET_FTE_37",	TO_NUMBER(DECODE("RET_FTE_35",0,null,"RET_FTE_35")) as "RET_FTE_35",	TO_NUMBER(DECODE("RET_FTE_25",0,null,"RET_FTE_25'
||'")) as "RET_FTE_25",	TO_NUMBER(DECODE("RET_FTE_22",0,null,"RET_FTE_22")) as "RET_FTE_22",	TO_NUMBER(DECODE("RET_FTE_12_50",0,null,"RET_FTE_12_50")) as "RET_FTE_12_50",	TO_NUMBER(DECODE("RET_FTE_10",0,null,"RET_FTE_10")) as "RET_FTE_10",	TO_NUMBER(DEC'
||'ODE("RET_FTE_8",0,null,"RET_FTE_8")) as "RET_FTE_8",	TO_NUMBER(DECODE("RET_FTE_3",0,null,"RET_FTE_3")) as "RET_FTE_3",	TO_NUMBER(DECODE("RET_FTE_2_75",0,null,"RET_FTE_2_75")) as "RET_FTE_2_75",	TO_NUMBER(DECODE("RET_FTE_2",0,null,"RET_FTE_2")) as "RE'
||'T_FTE_2",	TO_NUMBER(DECODE("RET_FTE_1_75",0,null,"RET_FTE_1_75")) as "RET_FTE_1_75",	TO_NUMBER(DECODE("RET_FTE_1",0,null,"RET_FTE_1")) as "RET_FTE_1",	TO_NUMBER(DECODE("RET_FTE_0_10",0,null,"RET_FTE_0_10")) as "RET_FTE_0_10",	TO_NUMBER(DECODE("RET_FT'
||'E_0_01",0,null,"RET_FTE_0_01")) as "RET_FTE_0_01",	TO_NUMBER(DECODE("RET_FTE_0",0,null,"RET_FTE_0")) as "RET_FTE_0",	TO_NUMBER(DECODE("AUT_RET_-3",0,null,"AUT_RET_-3")) as "AUT_RET_-3",	TO_NUMBER(DECODE("RET_IVA_0",0,null,"RET_IVA_0")) as "RET_IVA_0"'
||',	TO_NUMBER(DECODE("RET_IVA_10",0,null,"RET_IVA_10")) as "RET_IVA_10",	TO_NUMBER(DECODE("RET_IVA_14_29",0,null,"RET_IVA_14_29")) as "RET_IVA_14_29",	TO_NUMBER(DECODE("RET_IVA_20",0,null,"RET_IVA_20")) as "RET_IVA_20",	TO_NUMBER(DECODE("RET_IVA_30",0,'
||'null,"RET_IVA_30")) as "RET_IVA_30",	TO_NUMBER(DECODE("RET_IVA_67",0,null,"RET_IVA_67")) as "RET_IVA_67",	TO_NUMBER(DECODE("RET_IVA_70",0,null,"RET_IVA_70")) as "RET_IVA_70",	TO_NUMBER(DECODE("RET_IVA_100",0,null,"RET_IVA_100")) as "RET_IVA_100"',
'FROM T_RESUMEN',
' order by id;'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_plug_display_when_condition=>'P194_IDPROCESO'
,p_plug_display_when_cond2=>'003'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
,p_updated_on=>wwv_flow_imp.dz('20251114140451Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(50211096067203124)
,p_max_row_count=>'1000000'
,p_allow_report_saving=>'N'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_show_search_textbox=>'N'
,p_report_list_mode=>'NONE'
,p_lazy_loading=>true
,p_show_detail_link=>'N'
,p_show_rows_per_page=>'N'
,p_show_filter=>'N'
,p_show_sort=>'N'
,p_show_control_break=>'N'
,p_show_highlight=>'N'
,p_show_computation=>'N'
,p_show_chart=>'N'
,p_show_group_by=>'N'
,p_show_pivot=>'N'
,p_show_flashback=>'N'
,p_show_reset=>'N'
,p_show_help=>'N'
,p_download_formats=>'XLSX'
,p_enable_mail_download=>'N'
,p_owner=>'EMASABANDA'
,p_internal_uid=>50211096067203124
,p_updated_on=>wwv_flow_imp.dz('20251114140451Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(50249093920209237)
,p_db_column_name=>'RESUMEN'
,p_display_order=>10
,p_column_identifier=>'AB'
,p_column_label=>'-'
,p_sync_form_label=>'N'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
,p_updated_on=>wwv_flow_imp.dz('20250815164440Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(50211267686203126)
,p_db_column_name=>'DIV'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Div'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'NUMBER'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G990D00'
,p_use_as_row_header=>'N'
,p_updated_on=>wwv_flow_imp.dz('20250815164440Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(50211385049203127)
,p_db_column_name=>'RET_FTE_37'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Ret Fte 37'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'NUMBER'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G990D00'
,p_use_as_row_header=>'N'
,p_updated_on=>wwv_flow_imp.dz('20250815164440Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(50211401795203128)
,p_db_column_name=>'RET_FTE_35'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Ret Fte 35'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'NUMBER'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G990D00'
,p_use_as_row_header=>'N'
,p_updated_on=>wwv_flow_imp.dz('20250815164440Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(50211561745203129)
,p_db_column_name=>'RET_FTE_25'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Ret Fte 25'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'NUMBER'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G990D00'
,p_use_as_row_header=>'N'
,p_updated_on=>wwv_flow_imp.dz('20250815164440Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(50211622484203130)
,p_db_column_name=>'RET_FTE_22'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'Ret Fte 22'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'NUMBER'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G990D00'
,p_use_as_row_header=>'N'
,p_updated_on=>wwv_flow_imp.dz('20250815164440Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(50211781703203131)
,p_db_column_name=>'RET_FTE_12_50'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>'Ret Fte 12 50'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'NUMBER'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G990D00'
,p_use_as_row_header=>'N'
,p_updated_on=>wwv_flow_imp.dz('20250815164440Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(50211829997203132)
,p_db_column_name=>'RET_FTE_10'
,p_display_order=>80
,p_column_identifier=>'H'
,p_column_label=>'Ret Fte 10'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'NUMBER'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G990D00'
,p_use_as_row_header=>'N'
,p_updated_on=>wwv_flow_imp.dz('20250815164441Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(50211914458203133)
,p_db_column_name=>'RET_FTE_8'
,p_display_order=>90
,p_column_identifier=>'I'
,p_column_label=>'Ret Fte 8'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'NUMBER'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G990D00'
,p_use_as_row_header=>'N'
,p_updated_on=>wwv_flow_imp.dz('20250815164441Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(50212086532203134)
,p_db_column_name=>'RET_FTE_3'
,p_display_order=>100
,p_column_identifier=>'J'
,p_column_label=>'Ret Fte 3'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'NUMBER'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G990D00'
,p_use_as_row_header=>'N'
,p_updated_on=>wwv_flow_imp.dz('20250815164441Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(50212122136203135)
,p_db_column_name=>'RET_FTE_2_75'
,p_display_order=>110
,p_column_identifier=>'K'
,p_column_label=>'Ret Fte 2 75'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'NUMBER'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G990D00'
,p_use_as_row_header=>'N'
,p_updated_on=>wwv_flow_imp.dz('20250815164441Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(50212252635203136)
,p_db_column_name=>'RET_FTE_2'
,p_display_order=>120
,p_column_identifier=>'L'
,p_column_label=>'Ret Fte 2'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'NUMBER'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G990D00'
,p_use_as_row_header=>'N'
,p_updated_on=>wwv_flow_imp.dz('20250815164441Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(50212363046203137)
,p_db_column_name=>'RET_FTE_1_75'
,p_display_order=>130
,p_column_identifier=>'M'
,p_column_label=>'Ret Fte 1 75'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'NUMBER'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G990D00'
,p_use_as_row_header=>'N'
,p_updated_on=>wwv_flow_imp.dz('20250815164441Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(50212452122203138)
,p_db_column_name=>'RET_FTE_1'
,p_display_order=>140
,p_column_identifier=>'N'
,p_column_label=>'Ret Fte 1'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'NUMBER'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G990D00'
,p_use_as_row_header=>'N'
,p_updated_on=>wwv_flow_imp.dz('20250815164441Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(50212534844203139)
,p_db_column_name=>'RET_FTE_0_10'
,p_display_order=>150
,p_column_identifier=>'O'
,p_column_label=>'Ret Fte 0 10'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'NUMBER'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G990D00'
,p_use_as_row_header=>'N'
,p_updated_on=>wwv_flow_imp.dz('20250815164441Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(50212640040203140)
,p_db_column_name=>'RET_FTE_0_01'
,p_display_order=>160
,p_column_identifier=>'P'
,p_column_label=>'Ret Fte 0 01'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'NUMBER'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G990D00'
,p_use_as_row_header=>'N'
,p_updated_on=>wwv_flow_imp.dz('20250815164441Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(50212754575203141)
,p_db_column_name=>'RET_FTE_0'
,p_display_order=>170
,p_column_identifier=>'Q'
,p_column_label=>'Ret Fte 0'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'NUMBER'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G990D00'
,p_use_as_row_header=>'N'
,p_updated_on=>wwv_flow_imp.dz('20250815164441Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(50212825245203142)
,p_db_column_name=>'AUT_RET_-3'
,p_display_order=>180
,p_column_identifier=>'R'
,p_column_label=>'Aut Ret -3'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'NUMBER'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G990D00'
,p_use_as_row_header=>'N'
,p_updated_on=>wwv_flow_imp.dz('20250815164441Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(50212965544203143)
,p_db_column_name=>'RET_IVA_0'
,p_display_order=>190
,p_column_identifier=>'S'
,p_column_label=>'Ret Iva 0'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'NUMBER'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G990D00'
,p_use_as_row_header=>'N'
,p_updated_on=>wwv_flow_imp.dz('20250815164441Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(50213038304203144)
,p_db_column_name=>'RET_IVA_10'
,p_display_order=>200
,p_column_identifier=>'T'
,p_column_label=>'Ret Iva 10'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'NUMBER'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G990D00'
,p_use_as_row_header=>'N'
,p_updated_on=>wwv_flow_imp.dz('20250815164441Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(50213114844203145)
,p_db_column_name=>'RET_IVA_14_29'
,p_display_order=>210
,p_column_identifier=>'U'
,p_column_label=>'Ret Iva 14 29'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'NUMBER'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G990D00'
,p_use_as_row_header=>'N'
,p_updated_on=>wwv_flow_imp.dz('20250815164441Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(50213251256203146)
,p_db_column_name=>'RET_IVA_20'
,p_display_order=>220
,p_column_identifier=>'V'
,p_column_label=>'Ret Iva 20'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'NUMBER'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G990D00'
,p_use_as_row_header=>'N'
,p_updated_on=>wwv_flow_imp.dz('20250815164441Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(50213375343203147)
,p_db_column_name=>'RET_IVA_30'
,p_display_order=>230
,p_column_identifier=>'W'
,p_column_label=>'Ret Iva 30'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'NUMBER'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G990D00'
,p_use_as_row_header=>'N'
,p_updated_on=>wwv_flow_imp.dz('20250815164441Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(50213496140203148)
,p_db_column_name=>'RET_IVA_67'
,p_display_order=>240
,p_column_identifier=>'X'
,p_column_label=>'Ret Iva 67'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'NUMBER'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G990D00'
,p_use_as_row_header=>'N'
,p_updated_on=>wwv_flow_imp.dz('20250815164441Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(50213503224203149)
,p_db_column_name=>'RET_IVA_70'
,p_display_order=>250
,p_column_identifier=>'Y'
,p_column_label=>'Ret Iva 70'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'NUMBER'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G990D00'
,p_use_as_row_header=>'N'
,p_updated_on=>wwv_flow_imp.dz('20250815164441Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(50213658744203150)
,p_db_column_name=>'RET_IVA_100'
,p_display_order=>260
,p_column_identifier=>'Z'
,p_column_label=>'Ret Iva 100'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'NUMBER'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G990D00'
,p_use_as_row_header=>'N'
,p_updated_on=>wwv_flow_imp.dz('20250815164441Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(50268052692209792)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'502681'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'RESUMEN:DIV:RET_FTE_37:RET_FTE_25:RET_FTE_10:RET_FTE_8:RET_FTE_3:RET_FTE_2_75:RET_FTE_2:RET_FTE_1_75:RET_FTE_1:RET_FTE_0:AUT_RET_-3:RET_IVA_0:RET_IVA_10:RET_IVA_20:RET_IVA_30:RET_IVA_70:RET_IVA_100:'
,p_updated_on=>wwv_flow_imp.dz('20250815165842Z')
,p_updated_by=>'EMASABANDA'
);
wwv_flow_imp_page.create_worksheet_condition(
 p_id=>wwv_flow_imp.id(141503172876910137)
,p_report_id=>wwv_flow_imp.id(50268052692209792)
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'RESUMEN'
,p_operator=>'='
,p_expr=>'DIF. BALANCE:'
,p_condition_sql=>' (case when ("RESUMEN" = #APXWS_EXPR#) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# = ''DIF. BALANCE:''  '
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_row_bg_color=>'#0a1962'
,p_row_font_color=>'#fafafa'
,p_created_on=>wwv_flow_imp.dz('20250815165842Z')
,p_updated_on=>wwv_flow_imp.dz('20250815165842Z')
,p_created_by=>'EMASABANDA'
,p_updated_by=>'EMASABANDA'
);
wwv_flow_imp_page.create_worksheet_condition(
 p_id=>wwv_flow_imp.id(141503555007910139)
,p_report_id=>wwv_flow_imp.id(50268052692209792)
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'RESUMEN'
,p_operator=>'='
,p_expr=>'DIF. MAYORES:'
,p_condition_sql=>' (case when ("RESUMEN" = #APXWS_EXPR#) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# = ''DIF. MAYORES:''  '
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_row_bg_color=>'#0a1962'
,p_row_font_color=>'#fafafa'
,p_created_on=>wwv_flow_imp.dz('20250815165842Z')
,p_updated_on=>wwv_flow_imp.dz('20250815165842Z')
,p_created_by=>'EMASABANDA'
,p_updated_by=>'EMASABANDA'
);
wwv_flow_imp_page.create_worksheet_condition(
 p_id=>wwv_flow_imp.id(141503936556910140)
,p_report_id=>wwv_flow_imp.id(50268052692209792)
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'RESUMEN'
,p_operator=>'not in'
,p_expr=>'DIF. BALANCE:,DIF. MAYORES:'
,p_condition_sql=>' (case when ("RESUMEN" not in (#APXWS_EXPR_VAL1#, #APXWS_EXPR_VAL2#)) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# #APXWS_OP_NAME# ''DIF. BALANCE:, DIF. MAYORES:''  '
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_column_bg_color=>'#6e6c6c'
,p_column_font_color=>'#fafafa'
,p_created_on=>wwv_flow_imp.dz('20250815165842Z')
,p_updated_on=>wwv_flow_imp.dz('20250815165842Z')
,p_created_by=>'EMASABANDA'
,p_updated_by=>'EMASABANDA'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(50245502628209202)
,p_plug_name=>'botones'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(38290276266120143)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_03'
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(50248713476209234)
,p_plug_name=>'Resumen Retenciones Recibidas'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(38289867500120143)
,p_plug_display_sequence=>50
,p_location=>null
,p_plug_source_type=>'NATIVE_DISPLAY_SELECTOR'
,p_plug_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_plug_display_when_condition=>'P194_IDPROCESO'
,p_plug_display_when_cond2=>'007'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'display_region_icons', 'N',
  'include_show_all', 'N',
  'rds_mode', 'STANDARD',
  'remember_selection', 'USER')).to_clob
,p_updated_on=>wwv_flow_imp.dz('20250731194458Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(50248861988209235)
,p_name=>'Resumen Retenciones Clientes'
,p_parent_plug_id=>wwv_flow_imp.id(50248713476209234)
,p_template=>wwv_flow_imp.id(38289867500120143)
,p_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_display_point=>'SUB_REGIONS'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
' ',
'   ',
'WITH ',
'     T_DATOSRETC AS (',
'    select',
'          ''Recibidos'' RESUMEN',
'        ,ABS(SUM (pk_commons.safe_to_number(RETENCION_IVA)))VALOR ',
'        , max((SELECT VALOR FROM DATA.T_CORP_UDC WHERE REGEXP_LIKE (ID_CABECERA, ''FINZ_GT05'') AND ID_TABLA!=''000''  and descripcion2 =''BUSQUEDA DE BALANCE D/C RETC'' )) TIPO_BUSQ_BC',
'        , :P194_PERIODO PERIODO ',
'    from ',
'    (SELECT jt.* FROM t_finz_gestiontributariadatos t,JSON_TABLE( case when t.estado=3 then t.DATOSFIN ELSE t.DATOSMOD END ,''$[*]'' COLUMNS( IMPORTE_BRUTO number PATH''$.TIPO_COMPROBANTE'', IMPORTE_PENDIENTE  number PATH''$.IMPORTE_PENDIENTE'', RENTA numb'
||'er PATH''$.RENTA'', IVA  number PATH''$.IVA'', RETENCION_IVA  number PATH''$.RETENCION_IVA'') )jt WHERE id=:P194_IDDATO) FEJ20',
')',
',T_DETALLE AS (SELECT ROWNUM ID , ''BC_RET_REC_1'' TIPO_RESUMEN, RESUMEN, VALOR, TIPO_BUSQ_BC, PERIODO FROM T_DATOSRETC UNION ALL',
'SELECT MAX(ROWNUM)+1 ID , ''BC_RET_REC'' TIPO_RESUMEN, ''TOTAL'' RESUMEN, SUM(VALOR)VALOR, TIPO_BUSQ_BC, PERIODO FROM T_DATOSRETC GROUP BY TIPO_BUSQ_BC, PERIODO ',
')--SELECT * FROM T_DETALLE ;',
'SELECT ID, RESUMEN, VALOR, DESCRIP_BALANCE, CTA_BALANCE,PK_FINZ_GESTIONTRIBUTARIA.f_trer_valorbalance (PERIODO,BUSQ,TIPO_BUSQ_BC) BC',
',(PK_FINZ_GESTIONTRIBUTARIA.f_trer_valorbalance (PERIODO,BUSQ,TIPO_BUSQ_BC)-(VALOR))dif',
'FROM (SELECT ROWNUM ID,TIPO_RESUMEN,RESUMEN,TIPO_BUSQ_BC,PERIODO,VALOR',
',PK_FINZ_GESTIONTRIBUTARIA.f_trae_descripcioncuenta(TIPO_RESUMEN,''P'',''D'') DESCRIP_BALANCE',
',PK_FINZ_GESTIONTRIBUTARIA.f_trae_descripcioncuenta(TIPO_RESUMEN,''P'',''C'') CTA_BALANCE',
',PK_FINZ_GESTIONTRIBUTARIA.f_trae_descripcioncuenta(TIPO_RESUMEN,''P'',TIPO_BUSQ_BC) BUSQ ',
'FROM T_DETALLE',
')',
'where :P194_IDPROCESO=''007'';'))
,p_ajax_enabled=>'Y'
,p_lazy_loading=>true
,p_query_row_template=>wwv_flow_imp.id(37830327650106535)
,p_query_headings_type=>'QUERY_COLUMNS_INITCAP'
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'Y'
,p_prn_format=>'XLS'
,p_prn_output_link_text=>'Excel'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width_units=>'PERCENTAGE'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
,p_updated_on=>wwv_flow_imp.dz('20251029192523Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(57436066026017608)
,p_query_column_id=>1
,p_column_alias=>'ID'
,p_column_display_sequence=>10
,p_column_heading=>'Id'
,p_use_as_row_header=>'N'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(57436128758017609)
,p_query_column_id=>2
,p_column_alias=>'RESUMEN'
,p_column_display_sequence=>20
,p_column_heading=>'Resumen'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(57436213295017610)
,p_query_column_id=>3
,p_column_alias=>'VALOR'
,p_column_display_sequence=>60
,p_column_heading=>'Valor'
,p_use_as_row_header=>'N'
,p_column_format=>'FML999G999G999G999G990D00'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20251029192126Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(57436357106017611)
,p_query_column_id=>4
,p_column_alias=>'DESCRIP_BALANCE'
,p_column_display_sequence=>40
,p_column_heading=>'Descrip Balance'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(57436463778017612)
,p_query_column_id=>5
,p_column_alias=>'CTA_BALANCE'
,p_column_display_sequence=>50
,p_column_heading=>'Cta Balance'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(57436528251017613)
,p_query_column_id=>6
,p_column_alias=>'BC'
,p_column_display_sequence=>70
,p_column_heading=>'Bc'
,p_use_as_row_header=>'N'
,p_column_format=>'FML999G999G999G999G990D00'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20251029192126Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(57436661914017614)
,p_query_column_id=>7
,p_column_alias=>'DIF'
,p_column_display_sequence=>80
,p_column_heading=>'Dif'
,p_use_as_row_header=>'N'
,p_column_format=>'FML999G999G999G999G990D00'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20251029192126Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(57436791274017615)
,p_name=>'Resumen Retenciones Faltantes en JDE'
,p_parent_plug_id=>wwv_flow_imp.id(50248713476209234)
,p_template=>wwv_flow_imp.id(37806762584106520)
,p_display_sequence=>30
,p_include_in_reg_disp_sel_yn=>'Y'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_display_point=>'SUB_REGIONS'
,p_item_display_point=>'BELOW'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select TIPO_COMPROBANTE,SERIE_COMPROBANTE,CLAVE_ACCESO,VALIDACIONES',
'        from (',
'            SELECT jt.* ,t.USERMODI ,t.USERMODI usuario_modificacion',
'            FROM t_finz_gestiontributariadatos t',
'            ,JSON_TABLE(',
'                t.DATOSMOD,''$[*]'' COLUMNS(',
'                    IDJS VARCHAR(3999) PATH''$.ID'',',
'                    IDPADRE VARCHAR(3999) PATH''$.IDPADRE'',',
'                    TIPO_COMPROBANTE VARCHAR(3999) PATH''$.TIPO_COMPROBANTE'',',
'                    SERIE_COMPROBANTE VARCHAR(3999) PATH''$.SERIE_COMPROBANTE'',CLAVE_ACCESO VARCHAR(3999) PATH''$.CLAVE_ACCESO'',',
'                    NUMERO_RETENCION VARCHAR(3999) PATH''$.NUMERO_RETENCION'',',
'                    VALIDACIONES VARCHAR(3999) PATH''$.VALIDACIONES''',
'                )',
'            )jt WHERE id=:P194_IDDATO',
'        ) FEJ20',
'        where 1=1 ',
'        AND  (FEJ20.NUMERO_RETENCION IS NULL)  AND FEJ20.CLAVE_ACCESO IS NOT NULL'))
,p_display_condition_type=>'NEVER'
,p_ajax_enabled=>'Y'
,p_ajax_items_to_submit=>'P194_IDDATO'
,p_lazy_loading=>true
,p_query_row_template=>wwv_flow_imp.id(37830327650106535)
,p_query_num_rows=>1000
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_csv_output=>'N'
,p_prn_output=>'Y'
,p_prn_format=>'XLS'
,p_prn_output_link_text=>'Excel'
,p_prn_content_disposition=>'INLINE'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width_units=>'PERCENTAGE'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
,p_updated_on=>wwv_flow_imp.dz('20251029192443Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(57438190503017629)
,p_query_column_id=>1
,p_column_alias=>'TIPO_COMPROBANTE'
,p_column_display_sequence=>50
,p_column_heading=>'Tipo Comprobante'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(57438271377017630)
,p_query_column_id=>2
,p_column_alias=>'SERIE_COMPROBANTE'
,p_column_display_sequence=>60
,p_column_heading=>'Serie Comprobante'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(57438359872017631)
,p_query_column_id=>3
,p_column_alias=>'CLAVE_ACCESO'
,p_column_display_sequence=>70
,p_column_heading=>'Clave Acceso'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(57438402220017632)
,p_query_column_id=>4
,p_column_alias=>'VALIDACIONES'
,p_column_display_sequence=>80
,p_column_heading=>'Validaciones'
,p_use_as_row_header=>'N'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'N'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(50249730751209244)
,p_plug_name=>'Resumen de ICE '
,p_title=>'Resumen de ICE'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(38289867500120143)
,p_plug_display_sequence=>70
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'WITH ',
' T_ICE AS(',
'    SELECT  CODIGO_ICE,TP_DOC,SUM (pk_commons.safe_to_number(CANTIDAD_PEDIDA))CANTIDAD_PEDIDA ,SUM (pk_commons.safe_to_number(VALOR_ICE))ICE ,''C'' TIPO_BUSQ_BC, :P194_PERIODO PERIODO ',
'    FROM t_finz_gestiontributariadatos t,',
'    JSON_TABLE(',
'        case when t.estado=3 then t.DATOSFIN ELSE t.DATOSMOD END ,''$[*]'' COLUMNS(TP_DOC VARCHAR(3999) PATH''$.TP_DOC'',CODIGO_ICE VARCHAR(3999) PATH''$.CODIGO_ICE'',CANTIDAD_PEDIDA NUMBER PATH''$.CANTIDAD_PEDIDA'',VALOR_ICE NUMBER PATH''$.VALOR_ICE'')',
'    )jt WHERE id=:P194_IDDATO',
'    group by  CODIGO_ICE,TP_DOC',
'    order by TP_DOC',
')',
',T_DETALLE AS (',
'    SELECT 1 id       , ''IMPUESTO CONSUMOS ESPECIALES''       TIPO_RESUMEN,''CONSOLIDAD'' RESUMEN, (TIPO_BUSQ_BC)TIPO_BUSQ_BC, (PERIODO)PERIODO, CODIGO_ICE, TP_DOC, CANTIDAD_PEDIDA, ICE FROM T_ICE UNION ALL',
'    SELECT  1 id, ''IMPUESTO CONSUMOS ESPECIALES NETTO'' TIPO_RESUMEN,''TOTAL''      RESUMEN, MAX(TIPO_BUSQ_BC)TIPO_BUSQ_BC, MAX(PERIODO)PERIODO, NULL CODIGO_ICE, NULL TP_DOC, SUM(CANTIDAD_PEDIDA)CANTIDAD_PEDIDA, SUM(ICE)ICE FROM T_ICE',
')',
'SELECT ID, RESUMEN, CODIGO_ICE, TP_DOC, CANTIDAD_PEDIDA, ICE, DESCRIP_BALANCE, CTA_BALANCE,PK_FINZ_GESTIONTRIBUTARIA.f_trer_valorbalance (PERIODO,BUSQ,TIPO_BUSQ_BC) BC,(abs(PK_FINZ_GESTIONTRIBUTARIA.f_trer_valorbalance (PERIODO,BUSQ,TIPO_BUSQ_BC))-ab'
||'s(ICE))dif',
'FROM (SELECT ROWNUM ID, TIPO_RESUMEN, RESUMEN, TIPO_BUSQ_BC, PERIODO, CODIGO_ICE, TP_DOC, CANTIDAD_PEDIDA, ICE,PK_FINZ_GESTIONTRIBUTARIA.f_trae_descripcioncuenta(TIPO_RESUMEN,''P'',''D'') DESCRIP_BALANCE,PK_FINZ_GESTIONTRIBUTARIA.f_trae_descripcioncuenta'
||'(TIPO_RESUMEN,''P'',''C'') CTA_BALANCE,PK_FINZ_GESTIONTRIBUTARIA.f_trae_descripcioncuenta(TIPO_RESUMEN,''P'',TIPO_BUSQ_BC) BUSQ FROM T_DETALLE',
')',
'where :P194_IDPROCESO=''006'';'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_plug_display_when_condition=>'P194_IDPROCESO'
,p_plug_display_when_cond2=>'006'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'Resumen de ICE'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
,p_updated_on=>wwv_flow_imp.dz('20260205164436Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(50249822480209245)
,p_max_row_count=>'1000000'
,p_allow_report_saving=>'N'
,p_show_search_textbox=>'N'
,p_report_list_mode=>'NONE'
,p_lazy_loading=>true
,p_show_detail_link=>'N'
,p_show_rows_per_page=>'N'
,p_show_filter=>'N'
,p_show_sort=>'N'
,p_show_control_break=>'N'
,p_show_highlight=>'N'
,p_show_computation=>'N'
,p_show_aggregate=>'N'
,p_show_chart=>'N'
,p_show_group_by=>'N'
,p_show_pivot=>'N'
,p_show_flashback=>'N'
,p_show_reset=>'N'
,p_show_help=>'N'
,p_download_formats=>'XLSX'
,p_enable_mail_download=>'N'
,p_owner=>'EMASABANDA'
,p_internal_uid=>50249822480209245
,p_updated_on=>wwv_flow_imp.dz('20260205164436Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(50249929899209246)
,p_db_column_name=>'ID'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Id'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'NUMBER'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(50250098451209247)
,p_db_column_name=>'RESUMEN'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'-'
,p_alternative_label=>'Resumen de ICE'
,p_sync_form_label=>'N'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(57435604024017604)
,p_db_column_name=>'CODIGO_ICE'
,p_display_order=>40
,p_column_identifier=>'G'
,p_column_label=>'Codigo Ice'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(57435703977017605)
,p_db_column_name=>'TP_DOC'
,p_display_order=>50
,p_column_identifier=>'H'
,p_column_label=>'Tp Doc'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(57435821744017606)
,p_db_column_name=>'CANTIDAD_PEDIDA'
,p_display_order=>60
,p_column_identifier=>'I'
,p_column_label=>'Cant. Pedida'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'NUMBER'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(57435969426017607)
,p_db_column_name=>'ICE'
,p_display_order=>70
,p_column_identifier=>'J'
,p_column_label=>'Valor Ice'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'NUMBER'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G990D00'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(50250151960209248)
,p_db_column_name=>'DESCRIP_BALANCE'
,p_display_order=>80
,p_column_identifier=>'C'
,p_column_label=>'Descrip Balance'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(57435545705017603)
,p_db_column_name=>'CTA_BALANCE'
,p_display_order=>90
,p_column_identifier=>'F'
,p_column_label=>'Cta Balance'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(50250279578209249)
,p_db_column_name=>'BC'
,p_display_order=>110
,p_column_identifier=>'D'
,p_column_label=>'Bc'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'NUMBER'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G990D00'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(50250315992209250)
,p_db_column_name=>'DIF'
,p_display_order=>120
,p_column_identifier=>'E'
,p_column_label=>'Dif'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'NUMBER'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G990D00'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(57446022330096918)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'574461'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'ID:TP_DOC:CODIGO_ICE:RESUMEN:DESCRIP_BALANCE:CTA_BALANCE:ICE:CANTIDAD_PEDIDA:BC:DIF:'
,p_updated_on=>wwv_flow_imp.dz('20250801172159Z')
,p_updated_by=>'EMASABANDA'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(57438555420017633)
,p_plug_name=>'Barra de Acciones'
,p_region_template_options=>'#DEFAULT#:t-Form--stretchInputs'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(38289497777120142)
,p_plug_display_sequence=>20
,p_plug_display_point=>'REGION_POSITION_01'
,p_location=>null
,p_menu_id=>wwv_flow_imp.id(37761271469106475)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(37860983999106559)
,p_plug_display_condition_type=>'EXPRESSION'
,p_plug_display_when_condition=>':P194_IDPROCESO in (''007'')'
,p_plug_display_when_cond2=>'PLSQL'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(57438663567017634)
,p_plug_name=>'&P194_TITULO.'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(38290610465120145)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_location=>null
,p_menu_id=>wwv_flow_imp.id(37761271469106475)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(37860983999106559)
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(123117967305713222)
,p_plug_name=>'Resumen de Compras'
,p_title=>'Resumen de Compras'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(38289867500120143)
,p_plug_display_sequence=>20
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'WITH ',
'    T_DATOSCOMP AS (',
'        SELECT ',
'            TP_DOC                        TP_DOC,',
'            tipo_y_n                      tipo_y_n,',
'            explc_fisc                    explc_fisc,',
'            SUM(pk_commons.safe_to_number(importe_base_0))           importe_base_0,',
'            SUM(pk_commons.safe_to_number(iva_0))                    iva_0,',
'            SUM(pk_commons.safe_to_number(importe_base_12) )         importe_base_12,',
'            SUM(pk_commons.safe_to_number(iva_12))                   iva_12,',
'            SUM(pk_commons.safe_to_number(importe_base_15))          importe_base_15,',
'            SUM(pk_commons.safe_to_number(iva_15))                   iva_15,',
'            SUM(pk_commons.safe_to_number(importe_base_5))           importe_base_5,',
'            SUM(pk_commons.safe_to_number(importe_no_objeto_de_iva)) importe_no_objeto_de_iva,',
'            (SELECT VALOR FROM DATA.T_CORP_UDC WHERE REGEXP_LIKE (ID_CABECERA, ''FINZ_GT05'') AND ID_TABLA!=''000''  and descripcion2 =''BUSQUEDA DE BALANCE D/C COMP'' ) TIPO_BUSQ_BC,',
'            :P194_PERIODO PERIODO',
'        FROM t_finz_gestiontributariadatos t',
'        ,JSON_TABLE(',
'            case when t.estado=3 then t.DATOSFIN ELSE t.DATOSMOD END ',
'            ,''$[*]'' COLUMNS(',
'                 TP_DOC VARCHAR(3999) PATH''$.TP_DOC_VAL''',
'                ,TIPO_Y_N VARCHAR(3999) PATH''$.TIPO_Y_N_VAL''',
'                ,EXPLC_FISC VARCHAR(3999) PATH''$.EXPLC_FISC''',
'                ,IMPORTE_BASE_0 NUMBER PATH''$.IMPORTE_BASE_0''',
'                ,IVA_0 NUMBER PATH''$.IVA_0''',
'                ,IMPORTE_BASE_12 NUMBER PATH''$.IMPORTE_BASE_12''',
'                ,IVA_12 NUMBER PATH''$.IVA_12''',
'                ,IMPORTE_BASE_15 NUMBER PATH''$.IMPORTE_BASE_15''',
'                ,IVA_15 NUMBER PATH''$.IVA_15''',
'                ,IMPORTE_BASE_5 NUMBER PATH''$.IMPORTE_BASE_5''',
'                ,IMPORTE_NO_OBJETO_DE_IVA NUMBER PATH''$.IMPORTE_NO_OBJETO_DE_IVA''',
'            )',
'        )jt WHERE id=:P194_IDDATO',
'        and :P194_IDPROCESO=''004''',
'        GROUP BY TP_DOC,tipo_y_n,explc_fisc',
'    )  --SELECT * FROM T_DATOSCOMP ;',
'    ,T_DETALLECOMP AS(',
'        SELECT 1 id, ''COMPRAS TARIFA 12'' TIPO_RESUMEN,MAX(TIPO_BUSQ_BC)TIPO_BUSQ_BC,MAX(PERIODO)PERIODO,',
'            (sum(case when TP_DOC in (''PV'',''P3'',''PF'',''PJ'') then importe_base_12  else 0 end )',
'            -sum(case when EXPLC_FISC = ''ACTIVO FIJO'' then importe_base_12  else 0 end )',
'            +sum(case when TP_DOC in (''PD'',''QB'') then importe_base_12  else 0 end ))                 as VENTA_BRUTA,',
'            (sum(case when TP_DOC in (''PV'',''P3'',''PF'',''PJ'') then importe_base_12  else 0 end )',
'            -sum(case when EXPLC_FISC = ''ACTIVO FIJO'' then importe_base_12  else 0 end )',
'            +sum(case when TP_DOC in (''PD'',''QB'') then importe_base_12  else 0 end ))                 as VENTA_NETA,',
'            (sum(case when TP_DOC in (''PV'',''P3'',''PF'',''PJ'') then importe_base_12  else 0 end )',
'            -sum(case when EXPLC_FISC = ''ACTIVO FIJO'' then importe_base_12  else 0 end )',
'            +sum(case when TP_DOC in (''PD'',''QB'') then importe_base_12  else 0 end ))*TO_NUMBER(0.12) as IVA_VENTAS',
'        FROM T_DATOSCOMP',
'        UNION ALL ',
'        SELECT 2 id, ''COMPRAS TARIFA 15'' TIPO_RESUMEN,MAX(TIPO_BUSQ_BC)TIPO_BUSQ_BC,MAX(PERIODO)PERIODO,',
'            (sum(case when TP_DOC in (''PV'',''P3'',''PF'',''PJ'') then importe_base_15  else 0 end )',
'            -sum(case when EXPLC_FISC = ''ACTIVO FIJO'' then importe_base_15  else 0 end )',
'            +sum(case when TP_DOC in (''PD'',''QB'') then importe_base_15  else 0 end ))                 as VENTA_BRUTA,',
'            (sum(case when TP_DOC in (''PV'',''P3'',''PF'',''PJ'') then importe_base_15  else 0 end )',
'            -sum(case when EXPLC_FISC = ''ACTIVO FIJO'' then importe_base_15  else 0 end )',
'            +sum(case when TP_DOC in (''PD'',''QB'') then importe_base_15  else 0 end ))                 as VENTA_NETA,',
'            (sum(case when TP_DOC in (''PV'',''P3'',''PF'',''PJ'') then importe_base_15  else 0 end )',
'            -sum(case when EXPLC_FISC = ''ACTIVO FIJO'' then importe_base_15  else 0 end )',
'            +sum(case when TP_DOC in (''PD'',''QB'') then importe_base_15  else 0 end ))*TO_NUMBER(0.15) as IVA_VENTAS',
'        FROM T_DATOSCOMP',
'        UNION ALL ',
'        SELECT 3 id, ''COMPRAS TARIFA 5'' TIPO_RESUMEN,MAX(TIPO_BUSQ_BC)TIPO_BUSQ_BC,MAX(PERIODO)PERIODO,',
'            SUM(case when TP_DOC in (''PV'') then importe_base_5  else 0 end )as VENTA_BRUTA,',
'            SUM(case when TP_DOC in (''PV'') then importe_base_5  else 0 end )as VENTA_NETA,',
'            SUM(case when TP_DOC in (''PV'') then importe_base_5  else 0 end )*TO_NUMBER(0.05) as IVA_VENTAS',
'        FROM T_DATOSCOMP',
'        UNION ALL ',
'        SELECT 4 id, ''NOTAS DE CREDITO 12%'' TIPO_RESUMEN,MAX(TIPO_BUSQ_BC)TIPO_BUSQ_BC,MAX(PERIODO)PERIODO,',
'            NULL                                                                                as VENTA_BRUTA,',
'            SUM(case when TP_DOC in (''PC'') then importe_base_12  else 0 end )                    as VENTA_NETA,',
'            SUM(case when TP_DOC in (''PC'') then importe_base_12  else 0 end )*TO_NUMBER(0.12)    as IVA_VENTAS',
'        FROM T_DATOSCOMP',
'        UNION ALL ',
'        SELECT 5 id, ''NOTAS DE CREDITO 14%'' TIPO_RESUMEN,',
'        (SELECT VALOR FROM DATA.T_CORP_UDC WHERE REGEXP_LIKE (ID_CABECERA, ''FINZ_GT05'') AND ID_TABLA!=''000''  and descripcion2 =''BUSQUEDA DE BALANCE D/C COMP'' ) TIPO_BUSQ_BC,',
'            :P194_PERIODO PERIODO,',
'            NULL                                                                                as VENTA_BRUTA,',
'            0                                                                                   as VENTA_NETA,',
'            0                                                                                   as IVA_VENTAS',
'        FROM DUAL',
'        UNION ALL ',
'        SELECT 6 id, ''NOTAS DE CREDITO 15%'' TIPO_RESUMEN,MAX(TIPO_BUSQ_BC)TIPO_BUSQ_BC,MAX(PERIODO)PERIODO,',
'            NULL                                                                                as VENTA_BRUTA,',
'            SUM(case when TP_DOC in (''PC'') then importe_base_15  else 0 end )                   as VENTA_NETA,',
'            SUM(case when TP_DOC in (''PC'') then importe_base_15  else 0 end )*TO_NUMBER(0.15)   as IVA_VENTAS',
'        FROM T_DATOSCOMP',
'        UNION ALL ',
'        SELECT 7 id, ''COMPRAS AF 12%'' TIPO_RESUMEN,MAX(TIPO_BUSQ_BC)TIPO_BUSQ_BC,MAX(PERIODO)PERIODO,',
'            SUM(case when EXPLC_FISC in (''ACTIVO FIJO'') then importe_base_12  else 0 end )                   as VENTA_BRUTA,',
'            SUM(case when EXPLC_FISC in (''ACTIVO FIJO'') then importe_base_12  else 0 end )                   as VENTA_NETA,',
'            SUM(case when EXPLC_FISC in (''ACTIVO FIJO'') then importe_base_12  else 0 end )*TO_NUMBER(0.12)   as IVA_VENTAS',
'        FROM T_DATOSCOMP',
'        UNION ALL ',
'        SELECT 8 id, ''COMPRAS AF 15%'' TIPO_RESUMEN,MAX(TIPO_BUSQ_BC)TIPO_BUSQ_BC,MAX(PERIODO)PERIODO,',
'            SUM(case when EXPLC_FISC in (''ACTIVO FIJO'') then importe_base_15  else 0 end )                   as VENTA_BRUTA,',
'            SUM(case when EXPLC_FISC in (''ACTIVO FIJO'') then importe_base_15  else 0 end )                   as VENTA_NETA,',
'            SUM(case when EXPLC_FISC in (''ACTIVO FIJO'') then importe_base_15  else 0 end )*TO_NUMBER(0.15)   as IVA_VENTAS',
'        FROM T_DATOSCOMP',
'        UNION ALL ',
'        SELECT 8 id, ''IMP.SERVICIOS 12%'' TIPO_RESUMEN,MAX(TIPO_BUSQ_BC)TIPO_BUSQ_BC,MAX(PERIODO)PERIODO,',
'            (',
'                SUM(DECODE(TP_DOC,''PQ'',importe_base_12,0))',
'                -SUM(CASE WHEN EXPLC_FISC=''ACTIVO FIJO'' AND TP_DOC=''PQ'' THEN importe_base_12 ELSE 0 END)  ',
'                -SUM(CASE WHEN TIPO_Y_N=''LIQSEVPN12'' AND TP_DOC=''PQ'' THEN importe_base_12 ELSE 0 END)    )                 as VENTA_BRUTA,',
'            (',
'                SUM(DECODE(TP_DOC,''PQ'',importe_base_12,0))',
'                -SUM(CASE WHEN EXPLC_FISC=''ACTIVO FIJO'' AND TP_DOC=''PQ'' THEN importe_base_12 ELSE 0 END)  ',
'                -SUM(CASE WHEN TIPO_Y_N=''LIQSEVPN12'' AND TP_DOC=''PQ'' THEN importe_base_12 ELSE 0 END)    )                   as VENTA_NETA,',
'            (',
'                SUM(DECODE(TP_DOC,''PQ'',importe_base_12,0))',
'                -SUM(CASE WHEN EXPLC_FISC=''ACTIVO FIJO'' AND TP_DOC=''PQ'' THEN importe_base_12 ELSE 0 END)  ',
'                -SUM(CASE WHEN TIPO_Y_N=''LIQSEVPN12'' AND TP_DOC=''PQ'' THEN importe_base_12 ELSE 0 END)    )*TO_NUMBER(0.12)   as IVA_VENTAS',
'        FROM T_DATOSCOMP',
'        UNION ALL ',
'        SELECT 9 id, ''IMP.SERVICIOS 15%'' TIPO_RESUMEN,MAX(TIPO_BUSQ_BC)TIPO_BUSQ_BC,MAX(PERIODO)PERIODO,',
'            (',
'                SUM(DECODE(TP_DOC,''PQ'',importe_base_15,0))',
'                -SUM(CASE WHEN EXPLC_FISC=''ACTIVO FIJO'' AND TP_DOC=''PQ'' THEN importe_base_15 ELSE 0 END)  ',
'                -SUM(CASE WHEN TIPO_Y_N=''LIQSEVPN12'' AND TP_DOC=''PQ'' THEN importe_base_15 ELSE 0 END)    )                 as VENTA_BRUTA,',
'            (',
'                SUM(DECODE(TP_DOC,''PQ'',importe_base_15,0))',
'                -SUM(CASE WHEN EXPLC_FISC=''ACTIVO FIJO'' AND TP_DOC=''PQ'' THEN importe_base_15 ELSE 0 END)  ',
'                -SUM(CASE WHEN TIPO_Y_N=''LIQSEVPN12'' AND TP_DOC=''PQ'' THEN importe_base_15 ELSE 0 END)    )                   as VENTA_NETA,',
'            (',
'                SUM(DECODE(TP_DOC,''PQ'',importe_base_15,0))',
'                -SUM(CASE WHEN EXPLC_FISC=''ACTIVO FIJO'' AND TP_DOC=''PQ'' THEN importe_base_15 ELSE 0 END)  ',
'                -SUM(CASE WHEN TIPO_Y_N=''LIQSEVPN12'' AND TP_DOC=''PQ'' THEN importe_base_15 ELSE 0 END)    )*TO_NUMBER(0.15)   as IVA_VENTAS',
'        FROM T_DATOSCOMP',
'        UNION ALL ',
'        SELECT 10 id, ''COMPRAS TARIFA 0'' TIPO_RESUMEN,MAX(TIPO_BUSQ_BC)TIPO_BUSQ_BC,MAX(PERIODO)PERIODO,',
'            ',
'            (',
'                 sum(case when TP_DOC in (''P5'',''PV'',''P3'',''PF'',''PJ'',''PQ'') then importe_base_0  else 0 end )',
'                -sum(case when EXPLC_FISC = ''ACTIVO FIJO'' then importe_base_0  else 0 end )',
'                +sum(case when TP_DOC in (''DI'',''J2'') then importe_base_0  else 0 end )',
'                -SUM(case when TIPO_Y_N in (''RIMPE NEGP'') then importe_base_0  else 0 end )                )                   as VENTA_BRUTA,',
'            (',
'                 sum(case when TP_DOC in (''P5'',''PV'',''P3'',''PF'',''PJ'',''PQ'',''PC'') then importe_base_0  else 0 end )',
'                -sum(case when EXPLC_FISC = ''ACTIVO FIJO'' then importe_base_0  else 0 end )',
'                +sum(case when TP_DOC in (''DI'',''J2'') then importe_base_0  else 0 end )',
'                -SUM(case when TIPO_Y_N in (''RIMPE NEGP'') then importe_base_0  else 0 end )                )                    as VENTA_NETA,',
'            NULL   as IVA_VENTAS',
'                ',
'        FROM T_DATOSCOMP',
'        UNION ALL ',
'        SELECT 11 id, ''COMPRAS AF 0%'' TIPO_RESUMEN,MAX(TIPO_BUSQ_BC)TIPO_BUSQ_BC,MAX(PERIODO)PERIODO,',
'            SUM(case when EXPLC_FISC in (''ACTIVO FIJO'') then importe_base_0  else 0 end )                   as VENTA_BRUTA,',
'            SUM(case when EXPLC_FISC in (''ACTIVO FIJO'') then importe_base_0  else 0 end )                   as VENTA_NETA,',
'            NULL                                                                                            as IVA_VENTAS',
'        FROM T_DATOSCOMP        ',
'        UNION ALL ',
'        SELECT 12 id, ''COMPRAS NO OBJETO NO IVA'' TIPO_RESUMEN,MAX(TIPO_BUSQ_BC)TIPO_BUSQ_BC,MAX(PERIODO)PERIODO,',
'            SUM(case when TP_DOC in (''DI-ALIC'',''DI-ACCI'',''PV-ACCI'',''DI'',''PV'',''PJ'',''PD'') then IMPORTE_NO_OBJETO_DE_IVA  else 0 end ) as VENTA_BRUTA,',
'            SUM(case when TP_DOC in (''DI-ALIC'',''DI-ACCI'',''PV-ACCI'',''DI'',''PV'',''PJ'',''PD'') then IMPORTE_NO_OBJETO_DE_IVA  else 0 end ) as VENTA_NETA,',
'            null  as IVA_VENTAS',
'        FROM T_DATOSCOMP        ',
'        UNION ALL ',
'        SELECT 13 id, ''COMPRAS RISE'' TIPO_RESUMEN,MAX(TIPO_BUSQ_BC)TIPO_BUSQ_BC,MAX(PERIODO)PERIODO,',
'            SUM(case when TIPO_Y_N in (''RIMPE NEGP'') then importe_base_0  else 0 end ) as VENTA_BRUTA,',
'            SUM(case when TIPO_Y_N in (''RIMPE NEGP'') then importe_base_0  else 0 end ) as VENTA_NETA,',
'            null  as IVA_VENTAS',
'        FROM T_DATOSCOMP        ',
'        UNION ALL ',
'        SELECT 14 id, ''COMPRAS PN CON LIQUIDACION COMPRAS'' TIPO_RESUMEN,MAX(TIPO_BUSQ_BC)TIPO_BUSQ_BC,MAX(PERIODO)PERIODO,',
'            SUM(case when TIPO_Y_N = (''LIQSEVPN12'') then importe_base_12  else 0 end ) as VENTA_BRUTA,',
'            SUM(case when TIPO_Y_N = (''LIQSEVPN12'') then importe_base_12  else 0 end ) as VENTA_NETA,',
'            SUM(case when TIPO_Y_N = (''LIQSEVPN12'') then importe_base_12  else 0 end ) *TO_NUMBER(0.12)  as IVA_VENTAS',
'        FROM T_DATOSCOMP        ',
'        UNION ALL ',
'        SELECT 15 id, ''REEMBOLSO INTERMEDIARIO BASE 12%'' TIPO_RESUMEN,MAX(TIPO_BUSQ_BC)TIPO_BUSQ_BC,MAX(PERIODO)PERIODO,        ',
'            ( sum(case when TP_DOC = ''PV-INTER'' then importe_base_12 else 0 end )',
'            +sum(case when TP_DOC = ''PV-INTER'' then IMPORTE_NO_OBJETO_DE_IVA else 0 end)',
'            +sum(case when TP_DOC = ''PJ-INTER'' then importe_base_12 else 0 end  ) )  as VENTA_BRUTA,',
'            ( sum(case when TP_DOC = ''PV-INTER'' then importe_base_12 else 0 end )',
'            +sum(case when TP_DOC = ''PV-INTER'' then IMPORTE_NO_OBJETO_DE_IVA else 0 end)',
'            +sum(case when TP_DOC = ''PJ-INTER'' then importe_base_12 else 0 end  ) )  as VENTA_NETA,',
'            ( sum(case when TP_DOC = ''PV-INTER'' then importe_base_12 else 0 end )',
'            +sum(case when TP_DOC = ''PV-INTER'' then IMPORTE_NO_OBJETO_DE_IVA else 0 end)',
'            +sum(case when TP_DOC = ''PJ-INTER'' then importe_base_12 else 0 end  ) )  *TO_NUMBER(0.12)  as IVA_VENTAS',
'        FROM T_DATOSCOMP        ',
'        UNION ALL ',
'        SELECT 16 id, ''REEMBOLSO INTERMEDIARIO BASE 0%'' TIPO_RESUMEN,MAX(TIPO_BUSQ_BC)TIPO_BUSQ_BC,MAX(PERIODO)PERIODO,        ',
'            ( sum(case when TP_DOC = ''PV-INTER'' then importe_base_0 else 0 end )',
'            +sum(case when TP_DOC = ''PV-INTER'' then IMPORTE_NO_OBJETO_DE_IVA else 0 end)',
'            +sum(case when TP_DOC = ''PC-INTER'' then importe_base_0 else 0 end  ) )  as VENTA_BRUTA,',
'            ( sum(case when TP_DOC = ''PV-INTER'' then importe_base_0 else 0 end )',
'            +sum(case when TP_DOC = ''PV-INTER'' then IMPORTE_NO_OBJETO_DE_IVA else 0 end)',
'            +sum(case when TP_DOC = ''PC-INTER'' then importe_base_0 else 0 end  ) )  as VENTA_NETA,',
'            ( sum(case when TP_DOC = ''PV-INTER'' then importe_base_0 else 0 end )',
'            +sum(case when TP_DOC = ''PV-INTER'' then IMPORTE_NO_OBJETO_DE_IVA else 0 end)',
'            +sum(case when TP_DOC = ''PC-INTER'' then importe_base_0 else 0 end  ) )  *TO_NUMBER(0.0)  as IVA_VENTAS',
'        FROM T_DATOSCOMP',
'        )',
'        ,T_RESUMENCOMP as(',
'            select ',
'                ID, TIPO_RESUMEN RESUMEN, PERIODO, VENTA_BRUTA, VENTA_NETA, IVA_VENTAS, DESCRIP_BALANCE, CTA_BALANCE, BUSQ ',
'                ,PK_FINZ_GESTIONTRIBUTARIA.f_trer_valorbalance (PERIODO,BUSQ,TIPO_BUSQ_BC) BC',
'                ,(nvl(PK_FINZ_GESTIONTRIBUTARIA.f_trer_valorbalance (PERIODO,BUSQ,TIPO_BUSQ_BC),0)-nvl(IVA_VENTAS,0))dif',
'            from ( SELECT ID, TIPO_RESUMEN, TIPO_BUSQ_BC, PERIODO, VENTA_BRUTA, VENTA_NETA, IVA_VENTAS,PK_FINZ_GESTIONTRIBUTARIA.f_trae_descripcioncuenta(TIPO_RESUMEN,''P'',''D'') DESCRIP_BALANCE,PK_FINZ_GESTIONTRIBUTARIA.f_trae_descripcioncuenta(TIPO_RE'
||'SUMEN,''P'',''C'') CTA_BALANCE',
'                    ,PK_FINZ_GESTIONTRIBUTARIA.f_trae_descripcioncuenta(TIPO_RESUMEN,''P'',TIPO_BUSQ_BC) BUSQ',
'                    FROM T_DETALLECOMP D',
'                    WHERE 1=1 and :P194_IDPROCESO=''004''',
'            )',
'    )',
'	,t_reporte as (',
'    SELECT ',
'         ID,RESUMEN,DESCRIP_BALANCE,CTA_BALANCE,pk_commons.safe_to_number(decode(VENTA_BRUTA,0,null,VENTA_BRUTA))VENTA_BRUTA,pk_commons.safe_to_number(decode(VENTA_NETA,0,null,VENTA_NETA))VENTA_NETA',
'        ,pk_commons.safe_to_number(decode(IVA_VENTAS,0,null,IVA_VENTAS))IVA_VENTAS,pk_commons.safe_to_number(decode(BC,0,null,BC))BC,pk_commons.safe_to_number(decode(DIF,0,null,DIF))DIF',
'    FROM T_RESUMENCOMP',
'	) select*',
'	from t_reporte ',
'	where nvl(abs(IVA_VENTAS),0)>0 or nvl(abs(VENTA_BRUTA),0)>0 or nvl(abs(VENTA_NETA),0)>0;'))
,p_plug_source_type=>'NATIVE_IR'
,p_ajax_items_to_submit=>'P194_IDPROCESO,P194_IDDATO,P194_PERIODO'
,p_plug_display_condition_type=>'EXPRESSION'
,p_plug_display_when_condition=>':P194_IDPROCESO in (''004'')'
,p_plug_display_when_cond2=>'PLSQL'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'Resumen de Compras'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
,p_created_on=>wwv_flow_imp.dz('20250731194344Z')
,p_updated_on=>wwv_flow_imp.dz('20250909142021Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(123118007294713223)
,p_max_row_count=>'1000000'
,p_allow_report_saving=>'N'
,p_show_search_textbox=>'N'
,p_report_list_mode=>'NONE'
,p_lazy_loading=>true
,p_show_detail_link=>'N'
,p_show_rows_per_page=>'N'
,p_show_filter=>'N'
,p_show_sort=>'N'
,p_show_control_break=>'N'
,p_show_highlight=>'N'
,p_show_computation=>'N'
,p_show_aggregate=>'N'
,p_show_chart=>'N'
,p_show_group_by=>'N'
,p_show_pivot=>'N'
,p_show_flashback=>'N'
,p_show_reset=>'N'
,p_show_help=>'N'
,p_download_formats=>'XLSX'
,p_enable_mail_download=>'N'
,p_owner=>'DDELACRUZ'
,p_internal_uid=>123118007294713223
,p_created_on=>wwv_flow_imp.dz('20250731194345Z')
,p_updated_on=>wwv_flow_imp.dz('20250909142021Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(123118102265713224)
,p_db_column_name=>'ID'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Id'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'NUMBER'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20250731194345Z')
,p_updated_on=>wwv_flow_imp.dz('20250731194345Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(123118286083713225)
,p_db_column_name=>'RESUMEN'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'-'
,p_sync_form_label=>'N'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20250731194345Z')
,p_updated_on=>wwv_flow_imp.dz('20250731194345Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(123118337512713226)
,p_db_column_name=>'VENTA_BRUTA'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'V. Bruta'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'NUMBER'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G990D00'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20250731194345Z')
,p_updated_on=>wwv_flow_imp.dz('20250814050716Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(123118453826713227)
,p_db_column_name=>'VENTA_NETA'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'V. Neta'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'NUMBER'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G990D00'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20250731194345Z')
,p_updated_on=>wwv_flow_imp.dz('20250814050716Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(123118518968713228)
,p_db_column_name=>'IVA_VENTAS'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Iva Ventas'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'NUMBER'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G990D00'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20250731194345Z')
,p_updated_on=>wwv_flow_imp.dz('20250814050716Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(123118673607713229)
,p_db_column_name=>'DESCRIP_BALANCE'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'Descrip Balance'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_display_condition=>'APP_USER'
,p_display_condition2=>'EMASABANDA'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20250731194345Z')
,p_updated_on=>wwv_flow_imp.dz('20250731194345Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(123118739158713230)
,p_db_column_name=>'BC'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>'Bc'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'NUMBER'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G990D00'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20250731194345Z')
,p_updated_on=>wwv_flow_imp.dz('20250731194345Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(123118850068713231)
,p_db_column_name=>'DIF'
,p_display_order=>80
,p_column_identifier=>'H'
,p_column_label=>'Dif'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'NUMBER'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G990D00'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20250731194345Z')
,p_updated_on=>wwv_flow_imp.dz('20250731194345Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(123118905652713232)
,p_db_column_name=>'CTA_BALANCE'
,p_display_order=>90
,p_column_identifier=>'I'
,p_column_label=>'Cta Balance'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20250731194345Z')
,p_updated_on=>wwv_flow_imp.dz('20250731194345Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(124954548027465338)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'1249546'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'ID:RESUMEN:DESCRIP_BALANCE:CTA_BALANCE:VENTA_BRUTA:VENTA_NETA:IVA_VENTAS:BC:DIF:'
,p_sum_columns_on_break=>'VENTA_BRUTA:IVA_VENTAS:VENTA_NETA'
,p_created_on=>wwv_flow_imp.dz('20250731201114Z')
,p_updated_on=>wwv_flow_imp.dz('20250814050804Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'EMASABANDA'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(180870063858614209)
,p_plug_name=>'Resumen de SENAE'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(37806762584106520)
,p_plug_display_sequence=>80
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'WITH ',
'     T_DATOSSENAE AS (',
'        SELECT  ',
'         NUMERO_CUENTA',
'        ,''C'' TIPO_BUSQ_BC',
'        , ((SELECT A.PERIODO FROM t_finz_gestiontributaria A, t_finz_gestiontributariadET B  WHERE A.ID= B.IDGTB AND B.ID=T.IDDET)) PERIODO',
'        ,((nvl(FODINFA,0)+nvl(ADVALOREM,0)+nvl(SALVAGUARDIA,0)+nvl(TASA_CONTROL,0))+(nvl(VALOR_FOB_UNITARIO,0)+nvl(FLETE_NACIONAL,0)+nvl(FLETE_EXTERIOR,0)+nvl(SEGURO_NACIONAL,0)+nvl(SEGURO_EXTERIOR,0)+nvl(AJUSTE,0)))BASE',
'        ,(((nvl(FODINFA,0)+nvl(ADVALOREM,0)+nvl(SALVAGUARDIA,0)+nvl(TASA_CONTROL,0))+(nvl(VALOR_FOB_UNITARIO,0)+nvl(FLETE_NACIONAL,0)+nvl(FLETE_EXTERIOR,0)+nvl(SEGURO_NACIONAL,0)+nvl(SEGURO_EXTERIOR,0)+nvl(AJUSTE,0))))*0.15 COMP1',
'        FROM t_finz_gestiontributariadatos t,',
'        JSON_TABLE(',
'            case when t.estado=3 then t.DATOSFIN ELSE t.DATOSMOD END ',
'            ,''$[*]'' COLUMNS( TP_DOC varchar2(399) PATH''$.TP_DOC'',N_DOC varchar2(399) PATH''$.N_DOC'',NUMERO_CUENTA varchar2(399) PATH''$.NUMERO_CUENTA'',',
'                     FODINFA NUMBER PATH''$.FODINFA'',ADVALOREM NUMBER PATH''$.ADVALOREM'',SALVAGUARDIA NUMBER PATH''$.SALVAGUARDIA'',TASA_CONTROL NUMBER PATH''$.TASA_CONTROL'',VALOR_FOB_UNITARIO NUMBER PATH''$.VALOR_FOB_UNITARIO'',FLETE_NACIONAL NUMBER PATH''$'
||'.FLETE_NACIONAL'',FLETE_EXTERIOR NUMBER PATH''$.FLETE_EXTERIOR'',SEGURO_NACIONAL NUMBER PATH''$.SEGURO_NACIONAL'',SEGURO_EXTERIOR NUMBER PATH''$.SEGURO_EXTERIOR'',AJUSTE	NUMBER PATH''$.AJUSTE''',
'                     )',
'        )jt WHERE 1=1',
'        and t.id=:P194_IDDATO',
'        and :P194_IDPROCESO=''005''',
'        ',
'     )-- SELECT * FROM T_DATOSSENAE;',
'    ,T_DETALLE AS (',
'        SELECT 1 id, ''Iva importaciones 15%'' TIPO_RESUMEN,MAX(TIPO_BUSQ_BC)TIPO_BUSQ_BC,MAX(PERIODO)PERIODO,',
'              SUM(BASE)BASE,',
'              SUM(COMP1) COMP1,',
'              SUM(BASE)+SUM(COMP1)  TOTAL',
'        FROM T_DATOSSENAE WHERE NUMERO_CUENTA=''11000.22301.16''',
'		UNION ALL',
'        SELECT 2 id, ''Iva Importaciones AF 15%'' TIPO_RESUMEN,MAX(TIPO_BUSQ_BC)TIPO_BUSQ_BC,MAX(PERIODO)PERIODO,',
'              SUM(BASE)BASE,',
'              SUM(COMP1)COMP1,',
'              SUM(BASE)+SUM(COMP1)  TOTAL',
'        FROM T_DATOSSENAE WHERE NUMERO_CUENTA=''11000.22301.17''',
'    )',
'    ,T_RESUMEN as(',
'        select ',
'            ID, TIPO_RESUMEN RESUMEN, PERIODO, BASE , COMP1,  TOTAL, DESCRIP_BALANCE, CTA_BALANCE, BUSQ ',
'            ,PK_FINZ_GESTIONTRIBUTARIA.f_trer_valorbalance ( PERIODO,BUSQ,TIPO_BUSQ_BC) BC',
'			,abs(nvl(pk_finz_gestiontributaria.f_trer_valorbalance (periodo,busq,tipo_busq_bc),0))-abs(nvl(COMP1 ,0))dif',
'        from ( SELECT ID, TIPO_RESUMEN, TIPO_BUSQ_BC, PERIODO,  BASE ,TOTAL, COMP1,PK_FINZ_GESTIONTRIBUTARIA.f_trae_descripcioncuenta(TIPO_RESUMEN,''P'',''D'') DESCRIP_BALANCE,PK_FINZ_GESTIONTRIBUTARIA.f_trae_descripcioncuenta(TIPO_RESUMEN,''P'',''C'') CTA_B'
||'ALANCE',
'                ,PK_FINZ_GESTIONTRIBUTARIA.f_trae_descripcioncuenta(TIPO_RESUMEN,''P'',TIPO_BUSQ_BC) BUSQ',
'                FROM T_DETALLE D',
'        )',
'    )',
'    SELECT ',
'         ID,RESUMEN,DESCRIP_BALANCE,CTA_BALANCE',
'		 ,pk_commons.safe_to_number(BASE) BASE',
'		 ,pk_commons.safe_to_number(COMP1) COMP1',
'		 ,pk_commons.safe_to_number(TOTAL) TOTAL',
'		 ,pk_commons.safe_to_number(BC) BC',
'		 ,pk_commons.safe_to_number(DIF) DIF',
'    FROM T_RESUMEN ',
'	where ',
'	   nvl(abs(pk_commons.safe_to_number(BASE)),0)>0 ',
'	or nvl(abs(pk_commons.safe_to_number(COMP1)),0)>0 ',
'	or  nvl(abs(pk_commons.safe_to_number(TOTAL) ),0)>0'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_plug_display_when_condition=>'P194_IDPROCESO'
,p_plug_display_when_cond2=>'005'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
,p_created_on=>wwv_flow_imp.dz('20250930174349Z')
,p_updated_on=>wwv_flow_imp.dz('20251021201355Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(180870173219614210)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'DDELACRUZ'
,p_internal_uid=>180870173219614210
,p_created_on=>wwv_flow_imp.dz('20250930174554Z')
,p_updated_on=>wwv_flow_imp.dz('20251021201355Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(180870288988614211)
,p_db_column_name=>'ID'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Id'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20250930174554Z')
,p_updated_on=>wwv_flow_imp.dz('20250930174740Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(180870351044614212)
,p_db_column_name=>'RESUMEN'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Resumen'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20250930174554Z')
,p_updated_on=>wwv_flow_imp.dz('20250930174740Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(180870488590614213)
,p_db_column_name=>'DESCRIP_BALANCE'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Descrip Balance'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20250930174554Z')
,p_updated_on=>wwv_flow_imp.dz('20250930174740Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(180870536835614214)
,p_db_column_name=>'CTA_BALANCE'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Cta Balance'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20250930174554Z')
,p_updated_on=>wwv_flow_imp.dz('20250930174740Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(180870688208614215)
,p_db_column_name=>'BASE'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Base'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G990D00'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20250930174554Z')
,p_updated_on=>wwv_flow_imp.dz('20250930174740Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(180870786882614216)
,p_db_column_name=>'COMP1'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'Comp1'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G990D00'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20250930174554Z')
,p_updated_on=>wwv_flow_imp.dz('20250930174740Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(180870810423614217)
,p_db_column_name=>'TOTAL'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>'Total'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G990D00'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20250930174554Z')
,p_updated_on=>wwv_flow_imp.dz('20250930174740Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(180870997986614218)
,p_db_column_name=>'BC'
,p_display_order=>80
,p_column_identifier=>'H'
,p_column_label=>'Bc'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G990D00'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20250930174554Z')
,p_updated_on=>wwv_flow_imp.dz('20250930174740Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(180871054542614219)
,p_db_column_name=>'DIF'
,p_display_order=>90
,p_column_identifier=>'I'
,p_column_label=>'Dif'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G990D00'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20250930174554Z')
,p_updated_on=>wwv_flow_imp.dz('20250930174740Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(199302574462834074)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'1993026'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'ID:RESUMEN:DESCRIP_BALANCE:CTA_BALANCE:BASE:COMP1:TOTAL:BC:DIF'
,p_created_on=>wwv_flow_imp.dz('20250930174618Z')
,p_updated_on=>wwv_flow_imp.dz('20250930174618Z')
,p_created_by=>'EMASABANDA'
,p_updated_by=>'EMASABANDA'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(180871732762614226)
,p_plug_name=>'Resumen de Documentos Electonicos'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(37806762584106520)
,p_plug_display_sequence=>90
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'	select CODIGOAN8 CODIGOAN8_2,',
'				CODIGOAN8, RUC_EMISOR,TIPODOCUMENTO||'' - ''||COMPROBANTE   COMPROBANTE  ',
'	            ,COUNT(1) TOTAL',
'	            ,SUM(CASE WHEN TOTALJDE IS NULL THEN 1 ELSE null END) NO_CONTABILIZADO',
'	            ,SUM(CASE WHEN TOTALJDE IS NULL THEN null ELSE 1 END) CONTABILIZADO',
'	            ,SUM(CASE WHEN TOTALSRI IS NULL THEN 1 ELSE null END) NO_REG_SRI',
'	            ,SUM(CASE WHEN TOTALSRI IS NULL THEN null ELSE 1 END) REG_SRI',
'			from ',
'				(SELECT jt.* FROM t_finz_gestiontributariadatos t,JSON_TABLE(t.DATOSMOD,''$[*]'' COLUMNS(COMPROBANTE varchar2(3999) PATH''$.COMPROBANTE'',CLAVEACCESO varchar2(3999) PATH''$.CLAVEACCESO'',DOCUMENTO varchar2(3999) PATH''$.DOCUMENTO'',TIPODOCUMENTO varchar2'
||'(3999) PATH''$.TIPODOCUMENTO'',CODIGOAN8 varchar2(3999) PATH''$.CODIGO_EMISOR'',ALERTAEXTRA varchar2(3999) PATH''$.ALERTAEXTRA'',RUC_EMISOR varchar2(3999) PATH''$.RUC_EMISOR'',TIPO_COMPROBANTE varchar2(3999) PATH''$.TIPO_COMPROBANTE'',NUMERO_DOCUMENTO_MODIFICA'
||'DO varchar2(3999) PATH''$.NUMERO_DOCUMENTO_MODIFICADO'',TOTALJDE number PATH''$.TOTALJDE'',TOTALREC number PATH''$.TOTALREC'',TOTALSRI number PATH''$.TOTALSRI''))jt WHERE id=:P194_IDDATO) doceel',
'			where 1=1 ',
'	        GROUP BY CODIGOAN8, RUC_EMISOR,TIPODOCUMENTO||'' - ''||COMPROBANTE   ',
''))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_plug_display_when_condition=>'P194_IDPROCESO'
,p_plug_display_when_cond2=>'001'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
,p_created_on=>wwv_flow_imp.dz('20251001185050Z')
,p_updated_on=>wwv_flow_imp.dz('20251007204516Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(180871857730614227)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'DDELACRUZ'
,p_internal_uid=>180871857730614227
,p_created_on=>wwv_flow_imp.dz('20251001185051Z')
,p_updated_on=>wwv_flow_imp.dz('20251007204516Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(180871942285614228)
,p_db_column_name=>'CODIGOAN8'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'PROVEEDOR/CLIENTE'
,p_column_type=>'STRING'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_rpt_named_lov=>wwv_flow_imp.id(92685403493351092)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20251001185051Z')
,p_updated_on=>wwv_flow_imp.dz('20251001191035Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(180872024037614229)
,p_db_column_name=>'RUC_EMISOR'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Ruc Emisor'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20251001185051Z')
,p_updated_on=>wwv_flow_imp.dz('20251001191035Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(180872709488614236)
,p_db_column_name=>'COMPROBANTE'
,p_display_order=>30
,p_column_identifier=>'I'
,p_column_label=>'Comprobante'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20251001190250Z')
,p_updated_on=>wwv_flow_imp.dz('20251001191035Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(180872394702614232)
,p_db_column_name=>'CONTABILIZADO'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Contabilizado'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20251001185051Z')
,p_updated_on=>wwv_flow_imp.dz('20251001191035Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(180872434599614233)
,p_db_column_name=>'NO_CONTABILIZADO'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'No Contabilizado'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20251001185051Z')
,p_updated_on=>wwv_flow_imp.dz('20251001191035Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(180872534965614234)
,p_db_column_name=>'REG_SRI'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>'Reg Sri'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20251001185051Z')
,p_updated_on=>wwv_flow_imp.dz('20251001191035Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(180872666391614235)
,p_db_column_name=>'NO_REG_SRI'
,p_display_order=>80
,p_column_identifier=>'H'
,p_column_label=>'No Reg Sri'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20251001185051Z')
,p_updated_on=>wwv_flow_imp.dz('20251001191035Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(180872279528614231)
,p_db_column_name=>'TOTAL'
,p_display_order=>90
,p_column_identifier=>'D'
,p_column_label=>'Total'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20251001185051Z')
,p_updated_on=>wwv_flow_imp.dz('20251001191035Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(180873180633614240)
,p_db_column_name=>'CODIGOAN8_2'
,p_display_order=>100
,p_column_identifier=>'J'
,p_column_label=>'Codigoan8 2'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20251007204216Z')
,p_updated_on=>wwv_flow_imp.dz('20251007204216Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(200974379128865535)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'2009744'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'CODIGOAN8:RUC_EMISOR:COMPROBANTE:CONTABILIZADO:NO_CONTABILIZADO:REG_SRI:NO_REG_SRI:TOTAL:'
,p_sort_column_1=>'CODIGOAN8'
,p_sort_direction_1=>'ASC'
,p_sort_column_2=>'COMPROBANTE'
,p_sort_direction_2=>'ASC'
,p_sort_column_3=>'0'
,p_sort_direction_3=>'ASC'
,p_sort_column_4=>'0'
,p_sort_direction_4=>'ASC'
,p_sort_column_5=>'0'
,p_sort_direction_5=>'ASC'
,p_sort_column_6=>'0'
,p_sort_direction_6=>'ASC'
,p_break_on=>'CODIGOAN8:RUC_EMISOR'
,p_sum_columns_on_break=>'TOTAL'
,p_created_on=>wwv_flow_imp.dz('20251001185133Z')
,p_updated_on=>wwv_flow_imp.dz('20251001192307Z')
,p_created_by=>'EMASABANDA'
,p_updated_by=>'EMASABANDA'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(50245630101209203)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(50245502628209202)
,p_button_name=>'Cerrar'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860181880106559)
,p_button_image_alt=>'Cerrar'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(50247046227209217)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(57438555420017633)
,p_button_name=>'Procesar'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860056812106557)
,p_button_image_alt=>'Procesar'
,p_warn_on_unsaved_changes=>null
,p_button_condition=>'P194_IDPROCESO'
,p_button_condition2=>'007'
,p_button_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_icon_css_classes=>'fa-gears'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(43069752076983345)
,p_name=>'P194_IDDATO'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(43069874278983346)
,p_prompt=>'Iddato'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_updated_on=>wwv_flow_imp.dz('20250801032553Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(44521847350941342)
,p_name=>'P194_IDPROCESO'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(43069874278983346)
,p_prompt=>'Idproceso'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(44522235740941346)
,p_name=>'P194_PERIODO'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(43069874278983346)
,p_prompt=>'Periodo'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(48116768287027032)
,p_name=>'P194_TITULO'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(43069874278983346)
,p_prompt=>'Titulo'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_tag_attributes=>'style="font-size: x-large;"'
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--radioButtonGroup'
,p_attribute_01=>'N'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'N'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(57498190148306239)
,p_name=>'P194_ORDER_BY'
,p_is_required=>true
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(43069874278983346)
,p_item_default=>'ID'
,p_prompt=>'Order By'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'STATIC2:ID;ID'
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_warn_on_unsaved_changes=>'I'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'NONE'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(50245772580209204)
,p_name=>'New'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(50245630101209203)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(50245871680209205)
,p_event_id=>wwv_flow_imp.id(50245772580209204)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CLOSE'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(50247210432209219)
,p_name=>'RetencionesRecibidas'
,p_event_sequence=>20
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(50247046227209217)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
,p_updated_on=>wwv_flow_imp.dz('20250801033158Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(50247466262209221)
,p_event_id=>wwv_flow_imp.id(50247210432209219)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'mostrarBarra();'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(50247381648209220)
,p_event_id=>wwv_flow_imp.id(50247210432209219)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    v_filadat       t_finz_gestiontributariadatos%rowtype;',
'    v_json_array    json_array_t;',
'    v_json_obj      json_object_t;',
'    v_retorno       NUMBER;',
'    v_compania      VARCHAR2(5) := TRIM(TO_CHAR(:G_COMPANIA, ''00000''));',
'    v_usuario       VARCHAR2(39) := TRIM(:app_user);',
'    v_claveacceso   VARCHAR2(50):='''';',
'    v_idjson        VARCHAR2(39);',
'    v_json_path     VARCHAR2(3999);',
'    v_sql           VARCHAR2(3999);',
'BEGIN',
'    -- 1. Obtener el JSON actual',
'    SELECT * INTO v_filadat FROM t_finz_gestiontributariadatos WHERE id = :P194_IDDATO;',
'',
'    v_json_array := json_array_t.parse(v_filadat.datosmod);',
'',
'    FOR i IN 0 .. v_json_array.get_size - 1 LOOP',
'        v_json_obj := TREAT(v_json_array.get(i) AS json_object_t);',
'        v_claveacceso := TRIM(v_json_obj.get_string(''CLAVE_ACCESO''));',
'        IF v_json_obj.get_string(''NUMERO_RETENCION'') IS NULL THEN',
'            begin',
'                pk_finanzas.sp_documentoelectronico(v_compania,''REP:109:194:''||:APP_USER,v_claveacceso,V_RETORNO);',
'            exception when others then',
'                DBMS_OUTPUT.PUT_LINE(''SQLERRM:''||SQLERRM);',
'                V_RETORNO:=null;',
'            end ;',
'            V_RETORNO:=nvl(V_RETORNO,999);',
'            DBMS_OUTPUT.PUT_LINE(''V_RETORNO:''||V_RETORNO);',
'            v_idjson:= TRIM(to_char(v_json_obj.get_string(''ID'')));',
'            v_json_path := to_char(''$[*]?(@.ID==''||v_idjson||'').VALIDACIONES'');',
'',
'            if (v_retorno = -1)then',
'                v_sql := ''<li style="color:orange;">El documento xml ya se encuentra registrado, pero falta procesar en JDE</li>'';',
'            ELSif (v_retorno = 0)then',
unistr('                v_sql := ''<li style="color:red;">No se ha encontrado ning\00FAn documento asociado a la clave de acceso proporcionada</li>'';'),
'            ELSif (v_retorno=1)then',
'                v_sql := ''<li style="color:green;">VALIDADO</li>'';',
'            ELSE ',
'                v_sql := NULL;',
'            end if;',
'            if (v_sql is not null)then',
'                v_sql := ''UPDATE t_finz_gestiontributariadatos SET datosmod = JSON_TRANSFORM( datosmod, SET '''''' || v_json_path || '''''' = ''''<li style="color:green;">''||v_sql||''</li>'''' ) WHERE id = ''||:P194_IDDATO;',
'                DBMS_OUTPUT.PUT_LINE(''v_sql:''||v_sql);',
'                EXECUTE IMMEDIATE v_sql;',
'                commit;',
'            end if;',
'            DBMS_OUTPUT.PUT_LINE(RPAD(''*'',180,''*''));',
'        END IF;',
'    END LOOP;',
'END;',
''))
,p_attribute_02=>'P194_IDDATO'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20250801033158Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(50247576227209222)
,p_event_id=>wwv_flow_imp.id(50247210432209219)
,p_event_result=>'TRUE'
,p_action_sequence=>50
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'ocultarBarra();'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(44522303151941347)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'SetupPage'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
':P194_IDDATO:=:G_GT_IDJSON;',
':P194_IDPROCESO:= :G_GT_ACTIVIDADES;',
'',
'SELECT gtb.periodo into :P194_PERIODO FROM t_finz_gestiontributaria gtb',
'inner join t_finz_gestiontributariadet det on gtb.id= det.idgtb',
'inner join t_finz_gestiontributariadatos dat on det.id = dat.iddet ',
'where dat.id=:P194_IDDATO;',
'',
':P194_TITULO:=Case :P194_IDPROCESO ',
'                when ''001'' THEN ''RESUMEN DE DOCUMENTOS ELECTRONICOS RECIBIDOS''',
'                when ''002'' THEN ''RESUMEN DE VENTAS''',
'                when ''003'' THEN ''RESUMEN DE RETENCIONES EMITIDAS'' ',
'                when ''004'' THEN ''RESUMEN DE COMPRAS''',
'                when ''005'' THEN ''RESUMEN DE SENAE''',
'                when ''007'' THEN ''RESUMEN DE RETENCIONES RECIBIDAS''',
'                ELSE ''DATOS RESUMEN '' ',
'              END;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>44522303151941347
,p_updated_on=>wwv_flow_imp.dz('20251001185212Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp.component_end;
end;
/
