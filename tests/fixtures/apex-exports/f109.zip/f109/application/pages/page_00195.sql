prompt --application/pages/page_00195
begin
--   Manifest
--     PAGE: 00195
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>109
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_page.create_page(
 p_id=>195
,p_name=>'GESTION TRIBUTARIA - FORMULARIOS PDF'
,p_alias=>'GESTION-TRIBUTARIA-FORMULARIOS-PDF'
,p_step_title=>'GESTION TRIBUTARIA - FORMULARIOS PDF'
,p_autocomplete_on_off=>'OFF'
,p_html_page_header=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<meta charset="UTF-8">',
'<script src="https://cdnjs.cloudflare.com/ajax/libs/xlsx/0.18.5/xlsx.full.min.js"></script>',
'<script src="https://cdn.jsdelivr.net/npm/xlsx-js-style@1.2.0/dist/xlsx.bundle.js"></script>',
''))
,p_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
' function renderFormularios(){',
'    renderFormularioConHTML({idItemJson: "P195_DATOS_103",idItemHtml: "P195_HTMLFINAL_103",idRegion: "frm103",idItemConcepto: "P195_CONCEPTOXMLJSON_103",idItemConseptosResultado: "P195_CONCEPTO_RESULTADO_103",ordenPersonalizado: [] });',
'    renderFormularioConHTML({idItemJson: "P195_DATOS_104",idItemHtml: "P195_HTMLFINAL_104",idRegion: "frm104",idItemConcepto: "P195_CONCEPTOXMLJSON_104",idItemConseptosResultado: "P195_CONCEPTO_RESULTADO_104",ordenPersonalizado: [] });',
'    renderFormularioConHTML({idItemJson: "P195_DATOS_105",idItemHtml: "P195_HTMLFINAL_105",idRegion: "frm105",idItemConcepto: "P195_CONCEPTOXMLJSON_105",idItemConseptosResultado: "P195_CONCEPTO_RESULTADO_105",ordenPersonalizado: [{ casillero: "RUC", '
||'posicion: "fin" }] });',
'    renderFormularioConHTML({idItemJson: "P195_DATOS_115",idItemHtml: "P195_HTMLFINAL_115",idRegion: "frm115",idItemConcepto: "P195_CONCEPTOXMLJSON_115",idItemConseptosResultado: "P195_CONCEPTO_RESULTADO_115",ordenPersonalizado: [] });',
'}',
'',
'',
' ',
'function renderFormularioConHTML(config) {',
'    try {',
'        let data = "";',
'        if ($v(config.idItemJson) !== "") {',
'            data = JSON.parse($v(config.idItemJson));',
'        }',
'',
'        let html = $v(config.idItemHtml);',
'        if (!html) { console.warn(config.idItemHtml + ": VACIO"); return; }',
'',
'        const region = document.getElementById(config.idRegion);',
'        region.innerHTML = html;',
'',
'        if ($v(config.idItemJson) === "") {',
'            console.warn(config.idItemJson + ": VACIO");',
'            return;',
'        }',
'',
'        // Asignar data-codigo a celdas con {xxx}',
'        region.querySelectorAll(".cellEdit, [data-formula]").forEach(celda => {',
'            if (!celda.hasAttribute("data-codigo")) {',
'                const match = celda.innerHTML.match(/\{(\d+)\}/);',
'                if (match) {',
'                    celda.setAttribute("data-codigo", match[1]);',
'                }',
'            }',
'        });',
'',
'        // Reemplazar llaves {xxx} con datos del JSON',
'        region.querySelectorAll(".cellEdit, [data-formula]").forEach(celda => {',
'            if (celda.innerHTML === "{NOMBREMES}") {',
'                celda.innerHTML = celda.innerHTML.replace("{NOMBREMES}", data["NOMBREMES"] || "");',
'            } else if (celda.innerHTML === "{ANIO}") {',
'                celda.innerHTML = celda.innerHTML.replace("{ANIO}", data["ANIO"] || "");',
'            } else {',
'                const match = celda.innerHTML.match(/\{(\d+)\}/);',
'                if (match) {',
'                    const codigo = match[1];',
'                    const valor = data[codigo];',
'                    if (valor !== undefined) {',
'                        celda.innerHTML = celda.innerHTML.replace( new RegExp("\\{" + codigo + "\\}", "g"), valor );',
'                    }',
'                }',
'            }',
'        });',
'',
'        function parseNumeroFlexible(valor) {',
'            if (typeof valor !== ''string'') valor = valor?.toString() || '''';',
'            valor = valor.replace(/\s/g, '''');',
'            if (/^\d{1,3}(\.\d{3})*,\d+$/.test(valor)) {',
'                return parseFloat(valor.replace(/\./g, '''').replace('','', ''.''));',
'            }',
'            if (/^\d{1,3}(,\d{3})*\.\d+$/.test(valor)) {',
'                return parseFloat(valor.replace(/,/g, ''''));',
'            }',
'            if (/^\d+,\d+$/.test(valor)) {',
'                return parseFloat(valor.replace('','', ''.''));',
'            }',
'            if (/^\d+(\.\d+)?$/.test(valor)) {',
'                return parseFloat(valor);',
'            }',
'            return NaN;',
'        }',
'',
'        // NUEVA: redondear a N decimales (por defecto 4), devolviendo string con coma',
'        function redondearNdec(valor, ndecimal = 4) {',
'            let num = parseNumeroFlexible(valor);',
'            if (isNaN(num)) return "";',
'            let fijo = num.toFixed(ndecimal);',
'            return fijo.replace(".", ","); // "0.9779" -> "0,9779"',
'        }',
'',
'        function parsearAFormatoDecimal(val) {',
'            if (typeof val !== "string") val = val.toString();',
'            const original = val.trim();',
'',
'            if (/^-?\d+(,\d+)?$/.test(original)) {',
'                return parseFloat(original.replace(",", ".")).toFixed(2);',
'            }',
'            if (/^-?\d+(\.\d+)?$/.test(original)) {',
'                return parseFloat(original).toFixed(2);',
'            }',
'            return original;',
'        }',
'',
'        function formatDecimal(num, decimales) {',
'            return Number(num).toLocaleString(''es-EC'', {',
'                minimumFractionDigits: decimales,',
'                maximumFractionDigits: decimales',
'            });',
'        }',
'',
'        function decodeHTMLAttribute(str) {',
'            return str',
'                .replace(/&lt;/g, ''<'')',
'                .replace(/&gt;/g, ''>'')',
'                .replace(/&amp;/g, ''&'');',
'        }',
'',
'        function evalFormula(formula, lookupFn) {',
'            try {',
'                console.log("formula:" + formula);',
'',
'                const decoded = decodeHTMLAttribute(formula);',
'                const expr = decoded.replace(/(?<![\d.])\b\d{3,6}\b(?!\.\d)/g, (match) => {',
'                    console.log("match:" + match);',
'                    let val = lookupFn(match);',
'                    if (typeof val === ''string'' && val.trim().endsWith(''%'')) {',
'                        const porcentaje = parseNumeroFlexible(val.replace(''%'', '''').trim());',
'                        return isNaN(porcentaje) ? 0 : (porcentaje / 100);',
'                    }',
'                    const num = parseNumeroFlexible(val);',
'                    return isNaN(num) ? 0 : num;',
'                });',
'                return eval(expr);',
'            } catch (e) {',
unistr('                console.warn(''Error evaluando f\00F3rmula:'', formula, e);'),
'                return '''';',
'            }',
'        }',
'',
'        function generarJsonPorConcepto() {',
'            let conceptosRaw = $v(config.idItemConcepto);',
'            if (!conceptosRaw) return;',
'',
'            let conceptosJson = [];',
'            try {',
'                conceptosJson = JSON.parse(conceptosRaw);',
'            } catch (e) {',
'                console.warn("Error parseando JSON de conceptos");',
'                return;',
'            }',
'',
'            const conceptosMap = {};',
'            conceptosJson.forEach(entry => {',
'                conceptosMap[entry.CASILLERO] = entry.CONCEPTO;',
'            });',
'',
'            const ordenPersonalizado = config.ordenPersonalizado || [];',
'',
'            const entradas = [];',
'            const usados = new Set();',
'',
'            region.querySelectorAll("*[data-codigo]").forEach(celda => {',
'                const casillero = celda.dataset.codigo;',
'                if (!casillero || usados.has(casillero) || casillero === "RUC") return;',
'',
'                usados.add(casillero);',
'                const concepto = conceptosMap[casillero];',
'                let val = data[casillero];',
'',
'                if (concepto && val !== undefined && val !== null && val.toString().trim() !== "") {',
'                    entradas.push({ concepto, casillero, valor: parsearAFormatoDecimal(val) });',
'                }',
'            });',
'',
'            // Agregar RUC (desde P195_RUC_CONTADOR)',
'            if (conceptosMap["RUC"]) {',
'                const rucVal = $v("P195_RUC_CONTADOR")?.trim();',
'                if (rucVal) {',
'                    entradas.push({ concepto: conceptosMap["RUC"], casillero: "RUC", valor: rucVal });',
'                }',
'            }',
'            const detalles = {};',
'            entradas.forEach(({ concepto, valor }) => {',
'                detalles[concepto] = valor;',
'            });',
'            const resultadoFinal = { detallesDeclaracion: detalles };',
'            const resultadoTexto = JSON.stringify(resultadoFinal);',
'            apex.item(config.idItemConseptosResultado).setValue(resultadoTexto);',
'        }',
'',
'',
'        function actualizarFormulas() {',
'            const formulaCeldas = region.querySelectorAll(''[data-formula]'');',
'            formulaCeldas.forEach(td => {',
'                const formula = td.dataset.formula;',
'                const result = evalFormula(formula, (codigo) => {',
'                    const celda = region.querySelector(`*[data-codigo="${codigo}"]`);',
'                    return celda ? (celda.dataset.valor || celda.textContent.trim()) : '''';',
'                });',
'',
'                if (!isNaN(result)) {',
'                    const dec = td.dataset.decimal ? parseInt(td.dataset.decimal) : 2;',
'                    const valorRed = redondearNdec(result); // almacena con N decimales (4 por defecto)',
'                    td.dataset.valor = valorRed;',
'                    td.textContent = formatDecimal(result, dec);',
'                    const codigo = td.dataset.codigo;',
'                    if (codigo) {',
'                        data[codigo] = valorRed;',
'                    }',
'                } else {',
'                    td.dataset.valor = '''';',
'                    td.textContent = '''';',
'                }',
'            });',
'            apex.item(config.idItemJson).setValue(JSON.stringify(data));',
'            generarJsonPorConcepto();',
'        }',
'',
unistr('        // Habilitar edici\00F3n y control en celdas con data-codigo'),
'        region.querySelectorAll("*[data-codigo]").forEach(celda => {',
'            const esEditable = celda.getAttribute("contenteditable") !== "false";',
'            if (esEditable) {',
'                celda.setAttribute("contenteditable", "true");',
'                // Valor inicial normalizado',
'                const valRawInicial = celda.textContent.trim();',
'                const valNumInicial = parseNumeroFlexible(valRawInicial);',
'                const dec = celda.dataset.decimal ? parseInt(celda.dataset.decimal) : 2;',
'                if (!isNaN(valNumInicial)) {',
'                    const valorRedIni = redondearNdec(valNumInicial);',
'                    celda.dataset.valor = valorRedIni;',
'                    celda.textContent = formatDecimal(valNumInicial, dec);',
'                } else {',
'                    celda.dataset.valor = valRawInicial;',
'                }',
'',
'                celda.addEventListener("input", function () {',
'                    const texto = celda.textContent.trim();',
'                    const codigo = celda.dataset.codigo;',
'                    const num = parseNumeroFlexible(texto);',
'                    if (!isNaN(num)) {',
'                        const valorRed = redondearNdec(num);',
'                        celda.dataset.valor = valorRed;',
'                        if (codigo) { data[codigo] = valorRed; }',
'                    } else {',
'                        celda.dataset.valor = texto;',
'                        if (codigo) { data[codigo] = texto; }',
'                    }',
'                    apex.item(config.idItemJson).setValue(JSON.stringify(data));',
'                    actualizarFormulas();',
'                    apex.item(config.idItemHtml).setValue(region.innerHTML);',
'                });',
'            }',
'        });',
'',
'        actualizarFormulas();',
'        apex.item(config.idItemHtml).setValue(region.innerHTML);',
'',
'    } catch (e) {',
'        console.error("Error procesando formulario:", config, e);',
'    }',
'}',
unistr('//   3.- Exporta UNA regi\00F3n preservando colores y celdas combinadas (colspan/rowspan).'),
'  window.exportarRegionExcelConEstilos = function({regionId, nombreHoja, archivo, selectorTabla="table"}){',
'    if (typeof XLSX === "undefined") { apex.message.alert("Falta xlsx-js-style."); return; }',
'',
'    const cont = document.getElementById(regionId);',
unistr('    if (!cont) { apex.message.alert("Regi\00F3n no encontrada: "+regionId); return; }'),
'',
'    // localizar tabla',
'    let tabla = cont.querySelector(selectorTabla);',
'    if (!tabla) {',
'      const htmlItem = cont.querySelector("[data-html=''1''], .js-rendered-html, .u-HTML");',
'      if (htmlItem) {',
'        const tmp = document.createElement("div");',
'        tmp.innerHTML = htmlItem.innerHTML;',
'        tabla = tmp.querySelector("table");',
'      }',
'    }',
unistr('    if (!tabla) { apex.message.alert("No se encontr\00F3 una <table> en "+regionId); return; }'),
'',
'    // helpers',
'    const rgb2hex = (rgb) => {',
'      const m = /rgba?\((\d+),\s*(\d+),\s*(\d+)/.exec(rgb||"");',
'      if (!m) return "FFFFFF";',
'      return [m[1],m[2],m[3]].map(v => Number(v).toString(16).padStart(2,"0")).join("").toUpperCase();',
'    };',
'    const toAlign = (t) => t==="center" ? "center" : (t==="right"||t==="end" ? "right" : "left");',
'    const toNumberGeneral = (v) => {',
'      if (v == null) return null;',
'      if (typeof v === "number" && Number.isFinite(v)) return v;',
'      let s = String(v).trim();',
'      if (!s) return null;',
'      s = s.replace(/^\((.*)\)$/, "-$1"); // (1,23) -> -1,23',
'      const hasPct = /%$/.test(s);',
'      s = s.replace(/[^\d.,-]/g, "");',
'      const lastDot = s.lastIndexOf(".");',
'      const lastCom = s.lastIndexOf(",");',
'      if (lastDot > lastCom) s = s.replace(/,/g, "");',
'      else if (lastCom > lastDot) s = s.replace(/\./g, "").replace(/,/g, ".");',
'      let n = Number(s);',
'      if (!Number.isFinite(n)) return null;',
'      return hasPct ? n/100 : n;',
'    };',
'',
'    // matrices',
'    const data = [];',
'    const styleM = [];',
'    const merges = [];',
'    const occupied = []; // occupied[r][c] = true si celda ya tomada por merge',
'',
'    const rows = Array.from(tabla.rows);',
'    rows.forEach((tr, r) => {',
'      data[r] = data[r] || [];',
'      styleM[r] = styleM[r] || [];',
'      occupied[r] = occupied[r] || [];',
'',
'      let c = 0;',
'      const cells = Array.from(tr.cells);',
'      cells.forEach(td => {',
'        // avanzar a siguiente columna libre',
'        while (occupied[r][c]) c++;',
'',
'        const rs = Math.max(1, parseInt(td.getAttribute("rowspan")||"1",10));',
'        const cs = Math.max(1, parseInt(td.getAttribute("colspan")||"1",10));',
'',
'        // valor',
'        const raw = td.getAttribute("data-val") ?? td.innerText;',
'        const preferNum = td.dataset.type === "number" || td.classList.contains("num");',
'        const valNum = preferNum ? toNumberGeneral(raw) : null;',
'        const val = (valNum !== null) ? valNum : raw;',
'',
'        data[r][c] = val;',
'',
'        // estilos computados',
'        const csx = getComputedStyle(td);',
'        const bg = csx.backgroundColor;',
'        const fg = csx.color;',
'        const bold = (parseInt(csx.fontWeight,10) || 400) >= 600 || td.tagName === "TH";',
'        const italic = csx.fontStyle === "italic";',
'        const underline = csx.textDecorationLine.includes("underline");',
'        const hAlign = toAlign(csx.textAlign);',
'        const vAlign = (csx.verticalAlign==="middle" ? "center" :',
'                        csx.verticalAlign==="bottom" ? "bottom" : "top");',
'        const wrap = csx.whiteSpace !== "nowrap";',
'',
'        const baseStyle = {',
'          font: { name:"Calibri", sz:11, bold, italic, underline, color:{rgb: rgb2hex(fg)} },',
'          alignment: { horizontal:hAlign, vertical:vAlign, wrapText:wrap },',
'          border: {',
'            top:{style:"thin", color:{rgb:"FFCCCCCC"}}, left:{style:"thin", color:{rgb:"FFCCCCCC"}},',
'            right:{style:"thin", color:{rgb:"FFCCCCCC"}}, bottom:{style:"thin", color:{rgb:"FFCCCCCC"}}',
'          }',
'        };',
'        if (bg && !/rgba?\(0,\s*0,\s*0,\s*0\)/.test(bg) && bg!=="transparent") {',
'          baseStyle.fill = { patternType:"solid", fgColor:{rgb: rgb2hex(bg)} };',
'        }',
'',
unistr('        // formato num\00E9rico opcional (usa data-fmt si existe)'),
'        let numFmt = td.getAttribute("data-fmt");',
'        if (!numFmt && valNum !== null) {',
unistr('          // heur\00EDstica simple'),
'          numFmt = String(raw).includes(",") || String(raw).includes(".") ? "0.00" : "0";',
'        }',
'',
'        // poner estilo en top-left',
'        styleM[r][c] = Object.assign({}, baseStyle);',
'        if (numFmt) styleM[r][c].z = numFmt;',
'',
'        // marcar ocupados y clonar estilo a todo el bloque',
'        for (let rr = r; rr < r + rs; rr++) {',
'          occupied[rr] = occupied[rr] || [];',
'          data[rr] = data[rr] || [];',
'          styleM[rr] = styleM[rr] || [];',
'          for (let cc = c; cc < c + cs; cc++) {',
'            if (rr === r && cc === c) { occupied[rr][cc] = true; continue; }',
'            occupied[rr][cc] = true;',
'            // para que el color se vea en todo el merged',
'            styleM[rr][cc] = Object.assign({}, baseStyle);',
'            if (numFmt) styleM[rr][cc].z = numFmt;',
'          }',
'        }',
'',
'        // registrar merge si aplica',
'        if (rs > 1 || cs > 1) {',
'          merges.push({',
'            s: { r, c },',
'            e: { r: r + rs - 1, c: c + cs - 1 }',
'          });',
'        }',
'',
'        c += 1; // siguiente columna libre',
'      });',
'    });',
'',
'    // construir hoja',
'    const wb = XLSX.utils.book_new();',
'    const ws = XLSX.utils.aoa_to_sheet(data);',
'',
'    // merges',
'    if (merges.length) ws["!merges"] = merges;',
'',
'    // estilos celda a celda',
'    const range = XLSX.utils.decode_range(ws["!ref"]);',
'    for (let R = range.s.r; R <= range.e.r; R++) {',
'      for (let C = range.s.c; C <= range.e.c; C++) {',
'        const addr = XLSX.utils.encode_cell({r:R, c:C});',
'        if (!ws[addr]) continue;',
'        const s = styleM[R]?.[C];',
'        if (s) ws[addr].s = s;',
'      }',
'    }',
'',
'    // anchos de columnas',
'    const colWidths = [];',
'    for (let R = range.s.r; R <= range.e.r; R++) {',
'      for (let C = range.s.c; C <= range.e.c; C++) {',
'        const v = data[R]?.[C];',
'        const w = String(v ?? "").length + 2;',
'        colWidths[C] = Math.max(colWidths[C]||10, Math.min(w, 60));',
'      }',
'    }',
'    ws["!cols"] = (colWidths||[]).map(w => ({wch:w}));',
'',
'    XLSX.utils.book_append_sheet(wb, ws, (nombreHoja||regionId).substring(0,31));',
'    XLSX.writeFile(wb, archivo || (regionId+".xlsx"));',
'  };',
''))
,p_javascript_code_onload=>wwv_flow_string.join(wwv_flow_t_varchar2(
'$(secItems).hide();',
'$(''.apex-rds'').data(''onRegionChange'', function(mode, activeTab) {',
'    console.warn(activeTab.href);',
'});',
''))
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'    td{color:black;font-style:normal;padding-left:5px;padding-right:5px;font-size:8pt;}',
'    tr{border:0.05px dotted #f1f1f14d;}',
'    .algLeft{text-align:left!important;}.algCenter{text-align:center !important;}.algRight{text-align:right !important;}',
'    .cellBlue		{background:#003399!important;color:white!important;border:none;padding-top:0px;padding-right:5px;padding-left:5px;padding-bottom:0px;font-weight:bold;text-wrap-mode:nowrap;text-align:center !important;}',
'    .cellLigthBlue	{background:#CCECFF!important;font-weight:bold;text-align:left !important;width:70px;max-width:70px;min-width:70px;}',
'    .cellEdit 	    {background:azure!important ;width:70px;max-width:70px;min-width:70px;text-align:right !important;}',
'    .cellFormula	{background:#b4dcef!important;text-align:right;width:70px;max-width:70px;min-width:70px;}',
'    .cellWhite		{background:white!important ;}',
'    .cellWithe		{background:white!important ;width:70px;max-width:70px;min-width:70px;}',
'    .cellOrange		{background:#FFCC66!important;font-weight:bold;}',
'    .cellfullWhite	{background:white!important	 ;color:white!important	;}',
'    .cellGray		{background:#EAEAEA!important;}',
'    .cellDarkGray	{background:#959697!important}',
'    @page{size:A4;margin:0;}',
'    html,body{padding:0;margin-left:5px;margin-right:5px;margin-top:5px;margin-bottom:5px;font-family:Arial, Helvetica, sans-serif,sans-serif;color:black;text-decoration:none;vertical-align:middle;}'))
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'16'
,p_last_updated_on=>wwv_flow_imp.dz('20251113144437Z')
,p_last_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(58702409457752242)
,p_plug_name=>'items'
,p_region_name=>'secItems'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(38289867500120143)
,p_plug_display_sequence=>40
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(58702981507752247)
,p_plug_name=>'Barra de Acciones'
,p_region_template_options=>'#DEFAULT#:t-Form--stretchInputs'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(38289497777120142)
,p_plug_display_sequence=>20
,p_plug_display_point=>'REGION_POSITION_01'
,p_location=>null
,p_menu_id=>wwv_flow_imp.id(37761271469106475)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(37860983999106559)
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(60505061691174922)
,p_plug_name=>'tabformulario'
,p_region_name=>'tblformulario'
,p_region_template_options=>'#DEFAULT#:js-useLocalStorage:t-TabsRegion-mod--fillLabels:t-TabsRegion-mod--pill:t-TabsRegion-mod--small'
,p_plug_template=>wwv_flow_imp.id(37814656137106525)
,p_plug_display_sequence=>20
,p_location=>null
,p_plug_source_type=>'NATIVE_DISPLAY_SELECTOR'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'display_region_icons', 'Y',
  'include_show_all', 'N',
  'rds_mode', 'STANDARD',
  'remember_selection', 'USER')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(58702322601752241)
,p_plug_name=>'form103'
,p_title=>'Formulartio 103'
,p_region_name=>'frm103'
,p_parent_plug_id=>wwv_flow_imp.id(60505061691174922)
,p_region_template_options=>'#DEFAULT#:t-Form--noPadding:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels:margin-top-none'
,p_plug_template=>wwv_flow_imp.id(95503811913299190)
,p_plug_display_sequence=>20
,p_plug_display_point=>'SUB_REGIONS'
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
,p_updated_on=>wwv_flow_imp.dz('20251002151956Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(60504613366174918)
,p_plug_name=>'form104'
,p_title=>'Formulartio 104'
,p_region_name=>'frm104'
,p_parent_plug_id=>wwv_flow_imp.id(60505061691174922)
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(38289867500120143)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
,p_updated_on=>wwv_flow_imp.dz('20251002151956Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(60507871093174950)
,p_plug_name=>'form105'
,p_title=>'Formulartio 105'
,p_region_name=>'frm105'
,p_parent_plug_id=>wwv_flow_imp.id(60505061691174922)
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(38289867500120143)
,p_plug_display_sequence=>40
,p_plug_display_point=>'SUB_REGIONS'
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
,p_updated_on=>wwv_flow_imp.dz('20251002151956Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(65696196571146319)
,p_plug_name=>'form115'
,p_title=>'Formulartio 115'
,p_region_name=>'frm115'
,p_parent_plug_id=>wwv_flow_imp.id(60505061691174922)
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(38289867500120143)
,p_plug_display_sequence=>50
,p_plug_display_point=>'SUB_REGIONS'
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
,p_updated_on=>wwv_flow_imp.dz('20251002151956Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(60507775018174949)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(58702981507752247)
,p_button_name=>'ATRAS'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860056812106557)
,p_button_image_alt=>'Atras'
,p_button_position=>'ABOVE_BOX'
,p_button_alignment=>'LEFT'
,p_button_redirect_url=>'f?p=&APP_ID.:182:&SESSION.::&DEBUG.:::'
,p_icon_css_classes=>'fa-arrow-left'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(65698928077146347)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(58702981507752247)
,p_button_name=>'JSON'
,p_button_static_id=>'btnDescargarJson'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860056812106557)
,p_button_image_alt=>'Json'
,p_button_position=>'ABOVE_BOX'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-file-json-o'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(60505700848174929)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(58702981507752247)
,p_button_name=>'PDF'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860056812106557)
,p_button_image_alt=>'PDF'
,p_button_position=>'ABOVE_BOX'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-file-pdf-o'
,p_updated_on=>wwv_flow_imp.dz('20251014145506Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(65694761548146305)
,p_button_sequence=>50
,p_button_plug_id=>wwv_flow_imp.id(58702981507752247)
,p_button_name=>'EXCEL'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860056812106557)
,p_button_image_alt=>'Excel'
,p_button_position=>'ABOVE_BOX'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-file-excel-o'
,p_updated_on=>wwv_flow_imp.dz('20251007172323Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(65695084254146308)
,p_button_sequence=>60
,p_button_plug_id=>wwv_flow_imp.id(58702981507752247)
,p_button_name=>'Recargar'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860056812106557)
,p_button_image_alt=>'Recargar'
,p_button_position=>'ABOVE_BOX'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
,p_show_processing=>'Y'
,p_confirm_message=>wwv_flow_string.join(wwv_flow_t_varchar2(
unistr('\00BFEst\00E1 seguro de realizar esta acci\00F3n?'),
'una vez que confirme se perderan los datos en pantalla y se sustituiran por los datos de base de datos.'))
,p_confirm_style=>'warning'
,p_button_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE ',
'V_CONTADOR NUMBER;',
'BEGIN',
'	select COUNT(distinct 1) CERRAR INTO V_CONTADOR from t_finz_gestiontributaria where estado!=3 and id =:P195_IDPERIODO;',
'	IF (V_CONTADOR=1) THEN ',
'		RETURN TRUE;',
'	ELSE',
'		RETURN FALSE;',
'	END IF;',
'END;',
'	'))
,p_button_condition2=>'PLSQL'
,p_button_condition_type=>'FUNCTION_BODY'
,p_icon_css_classes=>'fa-refresh'
,p_updated_on=>wwv_flow_imp.dz('20251015145214Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(58702557885752243)
,p_name=>'P195_DATOS_103'
,p_data_type=>'CLOB'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(58702409457752242)
,p_prompt=>'Datos 103'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>30
,p_cHeight=>5
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_warn_on_unsaved_changes=>'I'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(58702782412752245)
,p_name=>'P195_HTMLFINAL_103'
,p_data_type=>'CLOB'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(58702409457752242)
,p_prompt=>'Htmlfinal 103'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>30
,p_cHeight=>5
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_warn_on_unsaved_changes=>'I'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(60503069491174902)
,p_name=>'P195_IDPERIODO'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(58702409457752242)
,p_prompt=>'Idperiodo'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_warn_on_unsaved_changes=>'I'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(60505398521174925)
,p_name=>'P195_DATOS_104'
,p_data_type=>'CLOB'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(58702409457752242)
,p_prompt=>'Datos 104'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>30
,p_cHeight=>5
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_warn_on_unsaved_changes=>'I'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(60505421345174926)
,p_name=>'P195_HTMLFINAL_104'
,p_data_type=>'CLOB'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(58702409457752242)
,p_prompt=>'Htmlfinal 104'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>30
,p_cHeight=>5
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_warn_on_unsaved_changes=>'I'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(60505958317174931)
,p_name=>'P195_ARCHIVOPDF_104'
,p_item_sequence=>130
,p_item_plug_id=>wwv_flow_imp.id(58702409457752242)
,p_prompt=>'Archivopdf 104'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_warn_on_unsaved_changes=>'I'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_updated_on=>wwv_flow_imp.dz('20250814011126Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(60506269689174934)
,p_name=>'P195_SERVERDESCARGA'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(58702409457752242)
,p_prompt=>'Serverdescarga'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_warn_on_unsaved_changes=>'I'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_updated_on=>wwv_flow_imp.dz('20250814011126Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(60506373700174935)
,p_name=>'P195_ARCHIVOHTML_104'
,p_item_sequence=>190
,p_item_plug_id=>wwv_flow_imp.id(58702409457752242)
,p_prompt=>'Archivohtml 104'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_warn_on_unsaved_changes=>'I'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_updated_on=>wwv_flow_imp.dz('20250814011126Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(60506426644174936)
,p_name=>'P195_ARCHIVOPDF_103'
,p_item_sequence=>120
,p_item_plug_id=>wwv_flow_imp.id(58702409457752242)
,p_prompt=>'Archivopdf 104'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_warn_on_unsaved_changes=>'I'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_updated_on=>wwv_flow_imp.dz('20250814011126Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(60506515931174937)
,p_name=>'P195_ARCHIVOHTML_103'
,p_item_sequence=>180
,p_item_plug_id=>wwv_flow_imp.id(58702409457752242)
,p_prompt=>'Archivohtml 104'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_warn_on_unsaved_changes=>'I'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_updated_on=>wwv_flow_imp.dz('20250814011126Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(60507208663174944)
,p_name=>'P195_IDFORMULARIO'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(58702409457752242)
,p_prompt=>'Idformulario'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_warn_on_unsaved_changes=>'I'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_updated_on=>wwv_flow_imp.dz('20250814011126Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(65694379267146301)
,p_name=>'P195_HTMLFINAL_105'
,p_data_type=>'CLOB'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_imp.id(58702409457752242)
,p_prompt=>'Htmlfinal 105'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>30
,p_cHeight=>5
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_warn_on_unsaved_changes=>'I'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(65694474926146302)
,p_name=>'P195_ARCHIVOPDF_105'
,p_item_sequence=>160
,p_item_plug_id=>wwv_flow_imp.id(58702409457752242)
,p_prompt=>'Archivopdf 105'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_warn_on_unsaved_changes=>'I'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_updated_on=>wwv_flow_imp.dz('20250814011126Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(65694513590146303)
,p_name=>'P195_ARCHIVOHTML_105'
,p_item_sequence=>200
,p_item_plug_id=>wwv_flow_imp.id(58702409457752242)
,p_prompt=>'Archivohtml 105'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_warn_on_unsaved_changes=>'I'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_updated_on=>wwv_flow_imp.dz('20250814011126Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(65694624871146304)
,p_name=>'P195_DATOS_105'
,p_data_type=>'CLOB'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(58702409457752242)
,p_prompt=>'Datos 105'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>30
,p_cHeight=>5
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_warn_on_unsaved_changes=>'I'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(65696296252146320)
,p_name=>'P195_DATOS_115'
,p_data_type=>'CLOB'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(58702409457752242)
,p_prompt=>'Datos 115'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>30
,p_cHeight=>5
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_warn_on_unsaved_changes=>'I'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(65696309447146321)
,p_name=>'P195_HTMLFINAL_115'
,p_data_type=>'CLOB'
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_imp.id(58702409457752242)
,p_prompt=>'Htmlfinal 115'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>30
,p_cHeight=>5
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_warn_on_unsaved_changes=>'I'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(65696459698146322)
,p_name=>'P195_ARCHIVOPDF_115'
,p_item_sequence=>170
,p_item_plug_id=>wwv_flow_imp.id(58702409457752242)
,p_prompt=>'Archivopdf 115'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_warn_on_unsaved_changes=>'I'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_updated_on=>wwv_flow_imp.dz('20250814011126Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(65696533712146323)
,p_name=>'P195_ARCHIVOHTML_115'
,p_item_sequence=>210
,p_item_plug_id=>wwv_flow_imp.id(58702409457752242)
,p_prompt=>'Archivohtml 115'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_warn_on_unsaved_changes=>'I'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_updated_on=>wwv_flow_imp.dz('20250814011127Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(65697247752146330)
,p_name=>'P195_ERRORHTML_103_1'
,p_item_sequence=>280
,p_item_plug_id=>wwv_flow_imp.id(58702409457752242)
,p_prompt=>'Errorhtml 103 1'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_warn_on_unsaved_changes=>'I'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(65697332126146331)
,p_name=>'P195_ERRORHTML_104_1'
,p_item_sequence=>290
,p_item_plug_id=>wwv_flow_imp.id(58702409457752242)
,p_prompt=>'Errorhtml 104 1'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_warn_on_unsaved_changes=>'I'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(65697495843146332)
,p_name=>'P195_ERRORHTML_105_1'
,p_item_sequence=>300
,p_item_plug_id=>wwv_flow_imp.id(58702409457752242)
,p_prompt=>'Errorhtml 105 1'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_warn_on_unsaved_changes=>'I'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(65697508987146333)
,p_name=>'P195_ERRORHTML_115_1'
,p_item_sequence=>310
,p_item_plug_id=>wwv_flow_imp.id(58702409457752242)
,p_prompt=>'Errorhtml 115 1'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_warn_on_unsaved_changes=>'I'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(65697658334146334)
,p_name=>'P195_ARCHIVOJSON_103'
,p_item_sequence=>220
,p_item_plug_id=>wwv_flow_imp.id(58702409457752242)
,p_prompt=>'Archivojson 103'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_warn_on_unsaved_changes=>'I'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_updated_on=>wwv_flow_imp.dz('20250814011127Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(65697770032146335)
,p_name=>'P195_ARCHIVOJSON_104'
,p_item_sequence=>230
,p_item_plug_id=>wwv_flow_imp.id(58702409457752242)
,p_prompt=>'Archivojson 104'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_warn_on_unsaved_changes=>'I'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_updated_on=>wwv_flow_imp.dz('20250814011127Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(65697843813146336)
,p_name=>'P195_ARCHIVOJSON_105'
,p_item_sequence=>240
,p_item_plug_id=>wwv_flow_imp.id(58702409457752242)
,p_prompt=>'Archivojson 105'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_warn_on_unsaved_changes=>'I'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_updated_on=>wwv_flow_imp.dz('20250814011127Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(65697968964146337)
,p_name=>'P195_ARCHIVOJSON_115'
,p_item_sequence=>270
,p_item_plug_id=>wwv_flow_imp.id(58702409457752242)
,p_prompt=>'Archivojson 115'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_warn_on_unsaved_changes=>'I'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_updated_on=>wwv_flow_imp.dz('20250814011127Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(65698103739146339)
,p_name=>'P195_CONCEPTOXMLJSON_103'
,p_item_sequence=>320
,p_item_plug_id=>wwv_flow_imp.id(58702409457752242)
,p_prompt=>'Conceptoxmljson 103'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_warn_on_unsaved_changes=>'I'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_updated_on=>wwv_flow_imp.dz('20250814011127Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(65698268776146340)
,p_name=>'P195_CONCEPTO_RESULTADO_103'
,p_item_sequence=>360
,p_item_plug_id=>wwv_flow_imp.id(58702409457752242)
,p_prompt=>'Concepto Resultado 103'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_warn_on_unsaved_changes=>'I'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_updated_on=>wwv_flow_imp.dz('20250814011127Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(65698333176146341)
,p_name=>'P195_CONCEPTOXMLJSON_104'
,p_item_sequence=>330
,p_item_plug_id=>wwv_flow_imp.id(58702409457752242)
,p_prompt=>'Conceptoxmljson 104'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_warn_on_unsaved_changes=>'I'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_updated_on=>wwv_flow_imp.dz('20250814011127Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(65698479595146342)
,p_name=>'P195_CONCEPTOXMLJSON_105'
,p_item_sequence=>340
,p_item_plug_id=>wwv_flow_imp.id(58702409457752242)
,p_prompt=>'Conceptoxmljson 105'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_warn_on_unsaved_changes=>'I'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_updated_on=>wwv_flow_imp.dz('20250814011127Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(65698598532146343)
,p_name=>'P195_CONCEPTOXMLJSON_115'
,p_item_sequence=>350
,p_item_plug_id=>wwv_flow_imp.id(58702409457752242)
,p_prompt=>'Conceptoxmljson 115'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_warn_on_unsaved_changes=>'I'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_updated_on=>wwv_flow_imp.dz('20250814011127Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(65698643856146344)
,p_name=>'P195_CONCEPTO_RESULTADO_104'
,p_item_sequence=>370
,p_item_plug_id=>wwv_flow_imp.id(58702409457752242)
,p_prompt=>'Concepto Resultado 104'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_warn_on_unsaved_changes=>'I'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_updated_on=>wwv_flow_imp.dz('20250814011127Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(65698775405146345)
,p_name=>'P195_CONCEPTO_RESULTADO_105'
,p_item_sequence=>380
,p_item_plug_id=>wwv_flow_imp.id(58702409457752242)
,p_prompt=>'Concepto Resultado 105'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_warn_on_unsaved_changes=>'I'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_updated_on=>wwv_flow_imp.dz('20250814011127Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(65698829491146346)
,p_name=>'P195_CONCEPTO_RESULTADO_115'
,p_item_sequence=>390
,p_item_plug_id=>wwv_flow_imp.id(58702409457752242)
,p_prompt=>'Concepto Resultado 115'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_warn_on_unsaved_changes=>'I'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_updated_on=>wwv_flow_imp.dz('20250814011128Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(65699030177146348)
,p_name=>'P195_RUC_CONTADOR'
,p_item_sequence=>400
,p_item_plug_id=>wwv_flow_imp.id(58702409457752242)
,p_prompt=>'Ruc Contador'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_warn_on_unsaved_changes=>'I'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_updated_on=>wwv_flow_imp.dz('20250814011128Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(60504784798174919)
,p_name=>'PageLoad'
,p_event_sequence=>10
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'ready'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(60504821164174920)
,p_event_id=>wwv_flow_imp.id(60504784798174919)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'renderFormularios();',
''))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(60507027242174942)
,p_name=>'ActiveTab'
,p_event_sequence=>40
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(60505061691174922)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'custom'
,p_bind_event_type_custom=>'atabsactivate'
,p_updated_on=>wwv_flow_imp.dz('20250731211406Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(60507169508174943)
,p_event_id=>wwv_flow_imp.id(60507027242174942)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'$("#btnDescargarJson").hide();',
'var atab =apex.region("tblformulario").widget().aTabs("getActive").href;',
'var ttab = atab.replace("SR_","") ;',
'$s("P195_IDFORMULARIO",ttab);',
'',
'if(ttab=="#frm103" && $v("P195_CONCEPTOXMLJSON_103")!==""){$("#btnDescargarJson").show();}',
'if(ttab=="#frm104" && $v("P195_CONCEPTOXMLJSON_104")!==""){$("#btnDescargarJson").show();}',
'if(ttab=="#frm105" && $v("P195_CONCEPTOXMLJSON_105")!==""){$("#btnDescargarJson").show();}',
'if(ttab=="#frm115" && $v("P195_CONCEPTOXMLJSON_115")!==""){$("#btnDescargarJson").show();}'))
,p_updated_on=>wwv_flow_imp.dz('20250731211406Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(60507319712174945)
,p_name=>'PDF'
,p_event_sequence=>50
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(60505700848174929)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
,p_updated_on=>wwv_flow_imp.dz('20251015150910Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(60507574127174947)
,p_event_id=>wwv_flow_imp.id(60507319712174945)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'mostrarBarra();'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(60507438988174946)
,p_event_id=>wwv_flow_imp.id(60507319712174945)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'v_numeroarchivo NUMBER;',
'BEGIN',
'    :P195_ARCHIVOHTML_103:=null;',
'    :P195_ARCHIVOPDF_103:=null;',
'    :P195_ARCHIVOJSON_103:=null;',
'    :P195_ARCHIVOHTML_104:=null;',
'    :P195_ARCHIVOPDF_104:=null;',
'    :P195_ARCHIVOJSON_104:=null;',
'    :P195_ARCHIVOHTML_105:=null;',
'    :P195_ARCHIVOPDF_105:=null;',
'    :P195_ARCHIVOJSON_105:=null;',
'    :P195_ARCHIVOHTML_115:=null;',
'    :P195_ARCHIVOPDF_115:=null;',
'    :P195_ARCHIVOJSON_115:=null;',
'',
'    -- Guarda el html Y JSON DE DATOS en la tabla T_APEX_ARCHIVO',
'    if (:P195_IDFORMULARIO=''#frm103'')then pk_finz_gestiontributaria.sp_generaPDFformulario(  :P195_HTMLFINAL_103,:P195_DATOS_103,:P195_IDPERIODO,''103'',:P195_ARCHIVOHTML_103,:P195_ARCHIVOPDF_103,:P195_ARCHIVOJSON_103 ); end if;',
'    if (:P195_IDFORMULARIO=''#frm104'')then pk_finz_gestiontributaria.sp_generaPDFformulario(  :P195_HTMLFINAL_104,:P195_DATOS_104,:P195_IDPERIODO,''104'',:P195_ARCHIVOHTML_104,:P195_ARCHIVOPDF_104,:P195_ARCHIVOJSON_104 ); end if;',
'    if (:P195_IDFORMULARIO=''#frm105'')then pk_finz_gestiontributaria.sp_generaPDFformulario(  :P195_HTMLFINAL_105,:P195_DATOS_105,:P195_IDPERIODO,''105'',:P195_ARCHIVOHTML_105,:P195_ARCHIVOPDF_105,:P195_ARCHIVOJSON_105 ); end if;',
'    if (:P195_IDFORMULARIO=''#frm115'')then pk_finz_gestiontributaria.sp_generaPDFformulario(  :P195_HTMLFINAL_115,:P195_DATOS_115,:P195_IDPERIODO,''115'',:P195_ARCHIVOHTML_115,:P195_ARCHIVOPDF_115,:P195_ARCHIVOJSON_115 ); end if;',
'	',
'END;',
'',
'',
'    '))
,p_attribute_02=>'P195_DATOS_103,P195_HTMLFINAL_103,P195_ARCHIVOHTML_103,P195_ARCHIVOPDF_103,P195_ARCHIVOJSON_103 ,P195_DATOS_104,P195_HTMLFINAL_104,P195_ARCHIVOHTML_104,P195_ARCHIVOPDF_104,P195_ARCHIVOJSON_104 ,P195_DATOS_105,P195_HTMLFINAL_105,P195_ARCHIVOHTML_105,P'
||'195_ARCHIVOPDF_105,P195_ARCHIVOJSON_105 ,P195_DATOS_106,P195_HTMLFINAL_115,P195_ARCHIVOHTML_115,P195_ARCHIVOPDF_115,P195_ARCHIVOJSON_115 ,P195_IDFORMULARIO,P195_IDPERIODO'
,p_attribute_03=>'P195_ARCHIVOHTML_104,P195_ARCHIVOPDF_104,P195_ARCHIVOHTML_103,P195_ARCHIVOPDF_103,P195_ARCHIVOHTML_105,P195_ARCHIVOPDF_105,P195_ARCHIVOHTML_115,P195_ARCHIVOPDF_115,P195_HTMLFINAL_105,P195_IDPERIODO,P195_ARCHIVOJSON_103,P195_ARCHIVOJSON_104,P195_ARCHI'
||'VOJSON_105,P195_ARCHIVOJSON_115'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20251015150844Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(60506162307174933)
,p_event_id=>wwv_flow_imp.id(60507319712174945)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'console.clear();',
'var NUMEROARCHIVO;',
'if ($v("P195_ARCHIVOPDF_103")!==""){',
'    NUMEROARCHIVO=$v("P195_ARCHIVOPDF_103");',
'}',
'if ($v("P195_ARCHIVOPDF_104")!==""){',
'    NUMEROARCHIVO=$v("P195_ARCHIVOPDF_104");',
'}',
'if ($v("P195_ARCHIVOPDF_105")!==""){',
'    NUMEROARCHIVO=$v("P195_ARCHIVOPDF_105");',
'}',
'if ($v("P195_ARCHIVOPDF_115")!==""){',
'    NUMEROARCHIVO=$v("P195_ARCHIVOPDF_115");',
'}',
'',
'',
'if(NUMEROARCHIVO!==""){',
'    var url="http://"+$v("P195_SERVERDESCARGA")+".zaimella.com/QCPs/fileApexDownloadWS/"+NUMEROARCHIVO;',
'    console.log(url);',
'    window.open(url, "_blank");',
'}',
''))
,p_updated_on=>wwv_flow_imp.dz('20251015150910Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(60507602216174948)
,p_event_id=>wwv_flow_imp.id(60507319712174945)
,p_event_result=>'TRUE'
,p_action_sequence=>60
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'ocultarBarra();'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(65695120473146309)
,p_event_id=>wwv_flow_imp.id(60507319712174945)
,p_event_result=>'TRUE'
,p_action_sequence=>70
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_02=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(65694870908146306)
,p_name=>'Excel'
,p_event_sequence=>60
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(65694761548146305)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
,p_updated_on=>wwv_flow_imp.dz('20251007174703Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(65694978135146307)
,p_event_id=>wwv_flow_imp.id(65694870908146306)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'var nombreArchivo="";',
'var hoja="";',
'var region="";',
'region=$v(''P195_IDFORMULARIO'');',
'region=region.replace("#","");',
'if (region==="frm103"){',
'    nombreArchivo="Formulario 103";',
'    hoja="F103";',
'}',
'if (region==="frm104"){',
'    nombreArchivo="Formulario 104";',
'    hoja="F104";',
'}',
'if (region==="frm105"){',
'    nombreArchivo="Formulario 105";',
'    hoja="F105";',
'}',
'console.log(region);',
'nombreArchivo = nombreArchivo.replace(/ /g, "_");',
'console.log(nombreArchivo);',
'//exportTabla2Xlsx(nombreArchivo ,region,hoja);',
'',
' exportarRegionExcelConEstilos({',
'  regionId:region,',
'  nombreHoja:hoja,',
'  archivo:nombreArchivo+".xlsx"',
'});'))
,p_updated_on=>wwv_flow_imp.dz('20251007174703Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(65699177594146349)
,p_name=>'Exportar Json'
,p_event_sequence=>70
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(65698928077146347)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(65699235274146350)
,p_event_id=>wwv_flow_imp.id(65699177594146349)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'    const idRaw = $v("P195_IDFORMULARIO"); ',
'    const match = idRaw.match(/(\d{3})$/); ',
'',
'    if (!match) {',
'        alert("No se pudo determinar el formulario a descargar.");',
'        return;',
'    }',
'',
'    const idFormulario = match[1];',
'    if (!idFormulario) {',
unistr('        alert("No se ha seleccionado ning\00FAn formulario.");'),
'        return;',
'    }',
'',
'    const itemResultado = `P195_CONCEPTO_RESULTADO_${idFormulario}`;',
'    const jsonContenido = $v(itemResultado);',
'',
'    if (!jsonContenido || jsonContenido.trim() === "") {',
unistr('        alert("El JSON del formulario est\00E1 vac\00EDo o no ha sido generado a\00FAn.");'),
'        return;',
'    }',
'',
'    const blob = new Blob([jsonContenido], { type: "application/json" });',
'    const url = URL.createObjectURL(blob);',
'    const link = document.createElement("a");',
'    link.href = url;',
'    link.download = `formulario${idFormulario}.json`;',
'    document.body.appendChild(link);',
'    link.click();',
'    document.body.removeChild(link);',
'    URL.revokeObjectURL(url);'))
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(65695294742146310)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'reprocesar datos formulario'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare v_form number;',
'begin',
'    v_form:=replace(:P195_IDFORMULARIO,''#frm'','''');',
'    DBMS_OUTPUT.PUT_LINE(''v_form:''||v_form);',
'        delete files.t_apex_archivos where TABLA = ''T_FINZ_GESTION_TRIBUTARIA_SRI'' AND ID_TABLA = ((:P195_IDPERIODO*1000)+v_form);commit;',
'',
'end;',
''))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(65695084254146308)
,p_internal_uid=>65695294742146310
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(58702623142752244)
,p_process_sequence=>20
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'SetupPage'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    v_fila   files.t_apex_archivos%ROWTYPE;',
'    v_datos  CLOB;',
'    v_html   CLOB;',
'    v_pdf    VARCHAR2(4000);',
'    v_error  VARCHAR2(4000);',
'',
'    PROCEDURE procesar_formulario(p_form_id IN NUMBER) IS',
'        v_id_tabla NUMBER := (:P195_IDPERIODO * 1000) + p_form_id;',
'    BEGIN',
'        BEGIN',
'            DBMS_OUTPUT.PUT_LINE(''v_id_tabla:''||v_id_tabla);',
'            -- ARCH_JSON',
'            SELECT * INTO v_fila',
'            FROM files.t_apex_archivos',
'            WHERE TABLA = ''T_FINZ_GESTION_TRIBUTARIA_SRI''',
'              AND ID_TABLA = v_id_tabla',
'              AND TIPO = ''ARCH_JSON'';',
'            v_datos := pk_finz_gestiontributaria.f_blob_a_clob(v_fila.BLOBCONTENT);',
'            DBMS_OUTPUT.PUT_LINE(''v_datos:''||v_datos);',
'--            return;',
'            -- ARCH_HTML',
'            SELECT * INTO v_fila',
'            FROM files.t_apex_archivos',
'            WHERE TABLA = ''T_FINZ_GESTION_TRIBITARIA_FRM_TMPT''',
'              AND ID_TABLA = p_form_id',
'              AND TIPO = ''ARCH_HTML'';',
'            v_html := pk_finz_gestiontributaria.f_blob_a_clob(v_fila.BLOBCONTENT);',
'',
'            -- ARCH_PDF',
'            SELECT * INTO v_fila',
'            FROM files.t_apex_archivos',
'            WHERE TABLA = ''T_FINZ_GESTION_TRIBUTARIA_SRI''',
'              AND ID_TABLA = v_id_tabla',
'              AND TIPO = ''ARCH_PDF'';',
'            v_pdf := v_fila.NUMEROARCHIVO;',
'',
'            DBMS_OUTPUT.PUT_LINE(''INDEX:'' || v_pdf);',
'        EXCEPTION WHEN OTHERS THEN',
'            v_error := ''1 - ERROR SQLCODE: '' || SQLCODE || '' SQLERRM: '' || SQLERRM || '' TRACE: '' || DBMS_UTILITY.format_error_backtrace;',
'            DBMS_OUTPUT.PUT_LINE(''v_error:''||v_error);',
'',
unistr('            -- Llamada directa seg\00FAn formulario'),
'            IF p_form_id = 104 THEN',
'                PK_FINZ_GESTIONTRIBUTARIA.sp_genera_formulario_104(:P195_IDPERIODO, :g_compania, v_html, v_datos);',
'            ELSIF p_form_id = 103 THEN',
'                PK_FINZ_GESTIONTRIBUTARIA.sp_genera_formulario_103(:P195_IDPERIODO, :g_compania, v_html, v_datos);',
'            ELSIF p_form_id = 105 THEN',
'                PK_FINZ_GESTIONTRIBUTARIA.sp_genera_formulario_105(:P195_IDPERIODO, :g_compania, v_html, v_datos);',
'            ELSIF p_form_id = 115 THEN',
'                PK_FINZ_GESTIONTRIBUTARIA.sp_genera_formulario_115(:P195_IDPERIODO, :g_compania, v_html, v_datos);',
'            END IF;',
'            f_imprimir_clob_completo(p_clob =>v_html);',
'            f_imprimir_clob_completo(p_clob =>v_datos);',
'            v_pdf := NULL;',
'			v_error:=''PK_FINZ_GESTIONTRIBUTARIA.sp_genera_formulario_115(''||:P195_IDPERIODO||'', ''''''||:g_compania||'''''', v_html, v_datos);'';',
'        END;',
'',
unistr('        -- Asignar valores a los items APEX seg\00FAn formulario'),
'        IF p_form_id = 103 THEN',
'            :P195_DATOS_103 := v_datos;',
'            :P195_HTMLFINAL_103 := v_html;',
'            :P195_ARCHIVOPDF_103 := v_pdf;',
'            :P195_ERRORHTML_103_1 := v_error;',
'        ELSIF p_form_id = 104 THEN',
'            :P195_DATOS_104 := v_datos;',
'            :P195_HTMLFINAL_104 := v_html;',
'            :P195_ARCHIVOPDF_104 := v_pdf;',
'            :P195_ERRORHTML_104_1 := v_error;',
'        ELSIF p_form_id = 105 THEN',
'            :P195_DATOS_105 := v_datos;',
'            :P195_HTMLFINAL_105 := v_html;',
'            :P195_ARCHIVOPDF_105 := v_pdf;',
'            :P195_ERRORHTML_105_1 := v_error;',
'        ELSIF p_form_id = 115 THEN',
'            :P195_DATOS_115 := v_datos;',
'            :P195_HTMLFINAL_115 := v_html;',
'            :P195_ARCHIVOPDF_115 := v_pdf;',
'            :P195_ERRORHTML_115_1 := v_error;',
'        END IF;',
'    END;',
'BEGIN',
'    procesar_formulario(104);',
'    procesar_formulario(103);',
'    procesar_formulario(105);',
'    procesar_formulario(115);',
'END;',
'',
'',
'BEGIN',
'    :P195_CONCEPTOXMLJSON_103:='''';',
'    :P195_CONCEPTOXMLJSON_104:='''';',
'    :P195_CONCEPTOXMLJSON_105:='''';',
'    :P195_CONCEPTOXMLJSON_115:='''';',
'    for  xjs in (',
'        SELECT   idformulario, JSON_ARRAYAGG(JSON_OBJECT(*) RETURNING CLOB) conceptoxmljson',
'        FROM ',
'        (',
'            SELECT VALOR idformulario,VALOR2 casillero ,VALOR3 concepto ',
'            FROM DATA.T_CORP_UDC ',
'            WHERE ID_CABECERA=''FINZ_GT09'' and ID_TABLA!=''000''',
'            order by to_number(ID_TABLA)',
'        )',
'        group by idformulario ',
'    )',
'    loop',
'    DBMS_OUTPUT.PUT_LINE(''xjs.valor:''||xjs.idformulario);',
'        if (xjs.idformulario =103)then',
'            :P195_CONCEPTOXMLJSON_103:=xjs.conceptoxmljson;',
'        elsif (xjs.idformulario =104)then',
'            :P195_CONCEPTOXMLJSON_104:=xjs.conceptoxmljson;',
'        elsif (xjs.idformulario =105)then',
'            :P195_CONCEPTOXMLJSON_105:=xjs.conceptoxmljson;',
'        elsif (xjs.idformulario =115)then',
'            :P195_CONCEPTOXMLJSON_115:=xjs.conceptoxmljson;',
'        end if;',
'    end loop;',
'',
'EXCEPTION WHEN OTHERS THEN',
'    :P195_CONCEPTOXMLJSON_103:=''2 - ERROR - ''||SQLERRM;',
'END;',
'',
'declare v_server VARCHAR2(100);',
'begin',
'    v_server:=''pruebas'';',
'    IF(PK_CORP_COMMONS.F_ISPRODUCCION())THEN',
'        v_server:=''apps'';',
'    END IF;',
'    :P195_SERVERDESCARGA:=v_server;',
'    DBMS_OUTPUT.PUT_LINE(''v_server: ''||:P195_SERVERDESCARGA );',
'    :P195_RUC_CONTADOR:=PK_FINZ_GESTIONTRIBUTARIA.f_traervalorudc(P_ID_CABECERA =>''FINZ_GT05'',p_descripcion=>''RUC_CONTADOR'');',
'end;',
''))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>58702623142752244
,p_updated_on=>wwv_flow_imp.dz('20251002210229Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp.component_end;
end;
/
