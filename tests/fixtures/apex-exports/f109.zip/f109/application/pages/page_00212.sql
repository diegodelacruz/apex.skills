prompt --application/pages/page_00212
begin
--   Manifest
--     PAGE: 00212
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>109
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_page.create_page(
 p_id=>212
,p_name=>unistr('Conciliaci\00F3n Manual')
,p_step_title=>unistr('Conciliaci\00F3n Manual')
,p_autocomplete_on_off=>'OFF'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'td[headers="Explicacion"] {',
'    width: 2px !important;',
'}'))
,p_page_template_options=>'#DEFAULT#'
,p_page_component_map=>'03'
,p_created_on=>wwv_flow_imp.dz('20230705164635Z')
,p_last_updated_on=>wwv_flow_imp.dz('20250825215731Z')
,p_last_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(592881144604674730)
,p_plug_name=>'Filtros'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(38289867500120143)
,p_plug_display_sequence=>10
,p_plug_query_headings_type=>'QUERY_COLUMNS'
,p_plug_query_num_rows=>15
,p_plug_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_plug_query_show_nulls_as=>' - '
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML',
  'show_line_breaks', 'N')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(592911962744039507)
,p_plug_name=>'  Datos'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(38289867500120143)
,p_plug_display_sequence=>20
,p_plug_display_column=>1
,p_plug_query_headings_type=>'QUERY_COLUMNS'
,p_plug_query_num_rows=>15
,p_plug_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_plug_query_show_nulls_as=>' - '
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML',
  'show_line_breaks', 'N')).to_clob
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(494471963985158819)
,p_name=>'Reporte Cuentas x Pagar'
,p_parent_plug_id=>wwv_flow_imp.id(592911962744039507)
,p_template=>wwv_flow_imp.id(95503811913299190)
,p_display_sequence=>50
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_region_attributes=>'style="float:right; clear: none;width:50%;"'
,p_new_grid_row=>false
,p_new_grid_column=>false
,p_display_point=>'SUB_REGIONS'
,p_item_display_point=>'BELOW'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'"COMPROBANTE",',
'to_date(FEC_DOC+ 1900000,''yyyyddd'') FEC_DOC,',
'"TIP_DOC",',
'"CUENTA",',
'"BATCH",',
'"MONTO",',
'NUM_DOC,',
'ACT_SN,',
'-- apex_item.hidden (sec_cxc) sec_cxc,',
'apex_item.checkbox (3,',
'                      SEC_CXC, DECODE(ACT_SN,''Y'',''CHECKED'')) SI_NO',
'',
'from DATA.T_FINZ_CONCILIACXC',
'WHERE TRIM(CUENTA) = :P212_CUENTA and monto <0',
'AND  to_date(FEC_DOC+ 1900000,''yyyyddd'') between :P212_FECDES and :P212_FECHAS',
''))
,p_display_when_condition=>'P212_MOS'
,p_display_when_cond2=>'3'
,p_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_ajax_enabled=>'Y'
,p_ajax_items_to_submit=>'P212_FECHAS,P212_FECDES,P212_CUENTA'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(37830327650106535)
,p_query_num_rows=>700
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_show_nulls_as=>' - '
,p_query_no_data_found=>unistr('No se ha encontrado ning\00FAn dato')
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_query_row_count_max=>1000
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(494472000173158820)
,p_query_column_id=>1
,p_column_alias=>'COMPROBANTE'
,p_column_display_sequence=>1
,p_column_heading=>'Comprobante'
,p_use_as_row_header=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(494472131778158821)
,p_query_column_id=>2
,p_column_alias=>'FEC_DOC'
,p_column_display_sequence=>2
,p_column_heading=>'Fec Doc'
,p_use_as_row_header=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(494472232147158822)
,p_query_column_id=>3
,p_column_alias=>'TIP_DOC'
,p_column_display_sequence=>3
,p_column_heading=>'TIP. DOC'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(494472376942158823)
,p_query_column_id=>4
,p_column_alias=>'CUENTA'
,p_column_display_sequence=>4
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(494472447885158824)
,p_query_column_id=>5
,p_column_alias=>'BATCH'
,p_column_display_sequence=>5
,p_column_heading=>'Batch'
,p_use_as_row_header=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(494472513017158825)
,p_query_column_id=>6
,p_column_alias=>'MONTO'
,p_column_display_sequence=>6
,p_column_heading=>'Monto'
,p_use_as_row_header=>'N'
,p_column_alignment=>'RIGHT'
,p_default_sort_column_sequence=>1
,p_default_sort_dir=>'desc'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(494472695197158826)
,p_query_column_id=>7
,p_column_alias=>'NUM_DOC'
,p_column_display_sequence=>7
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(494472785416158827)
,p_query_column_id=>8
,p_column_alias=>'ACT_SN'
,p_column_display_sequence=>8
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(494472858378158828)
,p_query_column_id=>9
,p_column_alias=>'SI_NO'
,p_column_display_sequence=>9
,p_column_heading=>'Si No'
,p_use_as_row_header=>'N'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(595529964216321944)
,p_name=>'Banco '
,p_parent_plug_id=>wwv_flow_imp.id(592911962744039507)
,p_template=>wwv_flow_imp.id(37807886111106520)
,p_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Report--stretch:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_region_attributes=>'style="float:right; clear: none;width:100%;"'
,p_new_grid_row=>false
,p_display_point=>'SUB_REGIONS'
,p_item_display_point=>'BELOW'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'apex_item.checkbox (1,SEC_BAN,DECODE(ACT_SN,''Y'',''CHECKED'')) SI_NO,',
'COMP_BANCO,    ',
'VALOR,',
'EXPLICACION,',
'to_date(FECHA+ 1900000,''yyyyddd'') FEC_DOC,',
'ACT_SN,',
'(SELECT OFICINA FROM T_FINZ_EDOCTAINFOADI WHERE TRIM(CUENTA) = CUENTABANCO AND TRIM(COMP_BANCO) = REFERENCIA AND ROWNUM = 1) OFICINA',
'FROM DATA.T_FINZ_CONCILIABAN',
'WHERE',
'TRIM(CUENTA) = :P212_CUENTA ',
'AND to_date(FECHA+ 1900000,''yyyyddd'') between :P212_FECDES and :P212_FECHAS ',
'AND TRIM(USUARIO) =:P212_USU'))
,p_display_when_condition=>'P212_MOS'
,p_display_when_cond2=>'1'
,p_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(37830327650106535)
,p_query_num_rows=>1000
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_show_nulls_as=>' - '
,p_query_no_data_found=>unistr('No se ha encontrado ning\00FAn dato')
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_query_row_count_max=>10000
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_report_total_text_format=>'Total'
,p_csv_output=>'Y'
,p_csv_output_link_text=>'Descargar'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_query_asc_image=>'apex/builder/dup.gif'
,p_query_asc_image_attr=>'width="16" height="16" alt="" '
,p_query_desc_image=>'apex/builder/ddown.gif'
,p_query_desc_image_attr=>'width="16" height="16" alt="" '
,p_plug_query_exp_filename=>'EstadoDeCuenta'
,p_plug_query_strip_html=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(480263126595613017)
,p_query_column_id=>1
,p_column_alias=>'SI_NO'
,p_column_display_sequence=>6
,p_column_heading=>'SI/NO'
,p_use_as_row_header=>'N'
,p_column_alignment=>'CENTER'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_report_column_width=>50
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(480263513282613020)
,p_query_column_id=>2
,p_column_alias=>'COMP_BANCO'
,p_column_display_sequence=>4
,p_column_heading=>'Comprobante'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_report_column_width=>50
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(480263928781613020)
,p_query_column_id=>3
,p_column_alias=>'VALOR'
,p_column_display_sequence=>5
,p_column_heading=>'Valor'
,p_use_as_row_header=>'N'
,p_column_alignment=>'RIGHT'
,p_default_sort_column_sequence=>1
,p_disable_sort_column=>'N'
,p_sum_column=>'Y'
,p_report_column_width=>50
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(480264347935613020)
,p_query_column_id=>4
,p_column_alias=>'EXPLICACION'
,p_column_display_sequence=>2
,p_column_heading=>unistr('Explicaci\00F3n')
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_report_column_width=>50
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(480264711015613021)
,p_query_column_id=>5
,p_column_alias=>'FEC_DOC'
,p_column_display_sequence=>3
,p_column_heading=>'Fecha'
,p_use_as_row_header=>'N'
,p_column_alignment=>'CENTER'
,p_disable_sort_column=>'N'
,p_report_column_width=>50
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(480265126266613021)
,p_query_column_id=>6
,p_column_alias=>'ACT_SN'
,p_column_display_sequence=>1
,p_column_heading=>'Act Sn'
,p_hidden_column=>'Y'
,p_lov_show_nulls=>'NO'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(595660234619844819)
,p_name=>'Reporte Contabilidad'
,p_parent_plug_id=>wwv_flow_imp.id(592911962744039507)
,p_template=>wwv_flow_imp.id(37807886111106520)
,p_display_sequence=>20
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_region_attributes=>'style="float:right; clear: none;width:100%;"'
,p_new_grid_row=>false
,p_display_point=>'SUB_REGIONS'
,p_item_display_point=>'BELOW'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'"COMPROBANTE",',
'to_date(FEC_DOC+ 1900000,''yyyyddd'') FEC_DOC,',
'"TIP_DOC",',
'"CUENTA",',
'"BATCH",',
'"MONTO",',
'NUM_DOC,',
'EXPLICACION,',
'ACT_SN,',
'(select CODIGO || '' ''|| NOMBRES from vt_jde_cliente where CODIGO in (select GLAN8 FROM F0911@JDEDTADL WHERE  GLICU = BATCH and GLDCT = TIP_DOC AND ROWNUM = 1)) CLIENTE,',
'apex_item.checkbox (4,SEC_CXC, DECODE(ACT_SN,''Y'',''CHECKED'')) SI_NO',
', numerodireccion',
'',
'from DATA.T_FINZ_CONCILIACXC ',
'WHERE TRIM(CUENTA) = :P212_CUENTA',
'AND  to_date(FEC_DOC+ 1900000,''yyyyddd'') between :P212_FECDES and  :P212_FECHAS'))
,p_display_when_condition=>'P212_MOS'
,p_display_when_cond2=>'1'
,p_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(37830327650106535)
,p_query_num_rows=>1000
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_show_nulls_as=>' - '
,p_query_no_data_found=>unistr('No se ha encontrado ning\00FAn dato')
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_query_row_count_max=>10000
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_report_total_text_format=>'Total'
,p_csv_output=>'Y'
,p_csv_output_link_text=>'Descargar'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_query_asc_image=>'apex/builder/dup.gif'
,p_query_asc_image_attr=>'width="16" height="16" alt="" '
,p_query_desc_image=>'apex/builder/ddown.gif'
,p_query_desc_image_attr=>'width="16" height="16" alt="" '
,p_plug_query_exp_filename=>'Contabilidad'
,p_plug_query_strip_html=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(480265836156613023)
,p_query_column_id=>1
,p_column_alias=>'COMPROBANTE'
,p_column_display_sequence=>4
,p_column_heading=>'Comprobante'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_report_column_width=>15
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(480266248331613025)
,p_query_column_id=>2
,p_column_alias=>'FEC_DOC'
,p_column_display_sequence=>7
,p_column_heading=>'Fecha'
,p_use_as_row_header=>'N'
,p_column_alignment=>'CENTER'
,p_disable_sort_column=>'N'
,p_report_column_width=>15
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(480266650378613025)
,p_query_column_id=>3
,p_column_alias=>'TIP_DOC'
,p_column_display_sequence=>5
,p_column_heading=>'Tipo'
,p_use_as_row_header=>'N'
,p_column_alignment=>'CENTER'
,p_disable_sort_column=>'N'
,p_report_column_width=>15
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(480267073614613026)
,p_query_column_id=>4
,p_column_alias=>'CUENTA'
,p_column_display_sequence=>8
,p_column_heading=>'CUENTA'
,p_hidden_column=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(480267441311613026)
,p_query_column_id=>5
,p_column_alias=>'BATCH'
,p_column_display_sequence=>9
,p_column_heading=>'Batch'
,p_use_as_row_header=>'N'
,p_report_column_width=>15
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(480267883842613026)
,p_query_column_id=>6
,p_column_alias=>'MONTO'
,p_column_display_sequence=>2
,p_column_heading=>'Monto'
,p_use_as_row_header=>'N'
,p_column_alignment=>'RIGHT'
,p_default_sort_column_sequence=>1
,p_disable_sort_column=>'N'
,p_sum_column=>'Y'
,p_report_column_width=>15
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(480268254637613026)
,p_query_column_id=>7
,p_column_alias=>'NUM_DOC'
,p_column_display_sequence=>10
,p_column_heading=>'Num Doc'
,p_hidden_column=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(480268644803613028)
,p_query_column_id=>8
,p_column_alias=>'EXPLICACION'
,p_column_display_sequence=>6
,p_column_heading=>unistr('Explicaci\00F3n')
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_report_column_width=>15
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(480269047617613028)
,p_query_column_id=>9
,p_column_alias=>'ACT_SN'
,p_column_display_sequence=>3
,p_column_heading=>'Act Sn'
,p_hidden_column=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(88297206275861205)
,p_query_column_id=>10
,p_column_alias=>'CLIENTE'
,p_column_display_sequence=>11
,p_column_heading=>'Cliente'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(480269425293613028)
,p_query_column_id=>11
,p_column_alias=>'SI_NO'
,p_column_display_sequence=>1
,p_column_heading=>'SI/NO'
,p_use_as_row_header=>'N'
,p_column_alignment=>'CENTER'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_report_column_width=>15
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(88297332204861206)
,p_query_column_id=>12
,p_column_alias=>'NUMERODIRECCION'
,p_column_display_sequence=>12
,p_column_heading=>unistr('C\00F3d. Cliente')
,p_use_as_row_header=>'N'
,p_column_alignment=>'CENTER'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(596455555418401315)
,p_name=>unistr('REVERSO-CONCILIACI\00D3N')
,p_region_name=>'f08'
,p_parent_plug_id=>wwv_flow_imp.id(592911962744039507)
,p_template=>wwv_flow_imp.id(37806762584106520)
,p_display_sequence=>30
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_display_point=>'SUB_REGIONS'
,p_item_display_point=>'BELOW'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select MPCKNU SEC_BAN, MPCKNU COMP_BAN, GLICU COM_CONT, ',
'to_date(GLDGJ + 1900000, ''YYYYDDD'') FECHA, MPAA/100 VALOR_BANCO, GLAA/100 VALOR_CONT, GLDCT TIP_DOC ,',
'APEX_ITEM.CHECKBOX(5,trim(MPCKNU)) SI_NO',
'from f5509505@jdedtadl, f0911@jdedtadl',
'WHERE ',
'GLDGJ between TO_CHAR(TO_DATE(:P212_FECDES, ''DD/MM/YYYY''),''YYYYDDD'') - 1900000 and TO_CHAR(TO_DATE(:P212_FECHAS, ''DD/MM/YYYY''),''YYYYDDD'') - 1900000 ',
'AND MPAID=GLAID',
'AND GLRCND =''R'' AND GLAA>0 AND MPEV02=''1''',
'AND MPCKNU = GLEXR',
'AND GLAID = :P212_CUENTA'))
,p_display_when_condition=>'P212_MOS'
,p_display_when_cond2=>'2'
,p_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(37830327650106535)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_show_nulls_as=>'-'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_query_asc_image=>'apex/builder/dup.gif'
,p_query_asc_image_attr=>'width="16" height="16" alt="" '
,p_query_desc_image=>'apex/builder/ddown.gif'
,p_query_desc_image_attr=>'width="16" height="16" alt="" '
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(478830598907331347)
,p_query_column_id=>1
,p_column_alias=>'SEC_BAN'
,p_column_display_sequence=>1
,p_column_heading=>'Sec Ban'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(478830651144331348)
,p_query_column_id=>2
,p_column_alias=>'COMP_BAN'
,p_column_display_sequence=>2
,p_column_heading=>'Comp Ban'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(478830790468331349)
,p_query_column_id=>3
,p_column_alias=>'COM_CONT'
,p_column_display_sequence=>3
,p_column_heading=>'Com Cont'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(478830880522331350)
,p_query_column_id=>4
,p_column_alias=>'FECHA'
,p_column_display_sequence=>4
,p_column_heading=>'Fecha'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(529295579327066501)
,p_query_column_id=>5
,p_column_alias=>'VALOR_BANCO'
,p_column_display_sequence=>5
,p_column_heading=>'Valor Banco'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(529295603309066502)
,p_query_column_id=>6
,p_column_alias=>'VALOR_CONT'
,p_column_display_sequence=>6
,p_column_heading=>'Valor Cont'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(529295716772066503)
,p_query_column_id=>7
,p_column_alias=>'TIP_DOC'
,p_column_display_sequence=>7
,p_column_heading=>'Tip Doc'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(529295867631066504)
,p_query_column_id=>8
,p_column_alias=>'SI_NO'
,p_column_display_sequence=>8
,p_column_heading=>'Si No'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(601531455989059860)
,p_name=>'Reporte  Cuentas x Cobrar'
,p_parent_plug_id=>wwv_flow_imp.id(592911962744039507)
,p_template=>wwv_flow_imp.id(95503811913299190)
,p_display_sequence=>40
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_region_attributes=>'style="float:right; clear: none;width:50%;"'
,p_new_grid_row=>false
,p_new_grid_column=>false
,p_display_point=>'SUB_REGIONS'
,p_item_display_point=>'BELOW'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'"COMPROBANTE",',
'to_date(FEC_DOC+ 1900000,''yyyyddd'') FEC_DOC,',
'"TIP_DOC",',
'"CUENTA",',
'"BATCH",',
'"MONTO",',
'NUM_DOC,',
'ACT_SN,',
'--apex_item.hidden (sec_cxc)  sec_cxc,',
'apex_item.checkbox (2,',
'                      SEC_CXC, DECODE(ACT_SN,''Y'',''CHECKED'')) SI_NO',
'',
'from DATA.T_FINZ_CONCILIACXC',
'WHERE TRIM(CUENTA) = :P212_CUENTA AND MONTO >0',
'AND  to_date(FEC_DOC+ 1900000,''yyyyddd'') between :P212_FECDES and :P212_FECHAS'))
,p_display_when_condition=>'P212_MOS'
,p_display_when_cond2=>'3'
,p_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(37830327650106535)
,p_query_num_rows=>700
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_show_nulls_as=>' - '
,p_query_no_data_found=>unistr('No se ha encontrado ning\00FAn dato')
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_query_row_count_max=>1000
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_query_asc_image=>'apex/builder/dup.gif'
,p_query_asc_image_attr=>'width="16" height="16" alt="" '
,p_query_desc_image=>'apex/builder/ddown.gif'
,p_query_desc_image_attr=>'width="16" height="16" alt="" '
,p_plug_query_strip_html=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(480273670496613056)
,p_query_column_id=>1
,p_column_alias=>'COMPROBANTE'
,p_column_display_sequence=>8
,p_column_heading=>'Comprobante'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(480274008912613056)
,p_query_column_id=>2
,p_column_alias=>'FEC_DOC'
,p_column_display_sequence=>3
,p_column_heading=>'Fec Doc'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(480274420838613067)
,p_query_column_id=>3
,p_column_alias=>'TIP_DOC'
,p_column_display_sequence=>2
,p_column_heading=>'TIP. DOC'
,p_heading_alignment=>'LEFT'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_lov_show_nulls=>'NO'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(480274842239613067)
,p_query_column_id=>4
,p_column_alias=>'CUENTA'
,p_column_display_sequence=>5
,p_column_heading=>'Cuenta'
,p_hidden_column=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(480275298561613067)
,p_query_column_id=>5
,p_column_alias=>'BATCH'
,p_column_display_sequence=>6
,p_column_heading=>'Batch'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(480275689886613073)
,p_query_column_id=>6
,p_column_alias=>'MONTO'
,p_column_display_sequence=>7
,p_column_heading=>'Monto'
,p_column_alignment=>'RIGHT'
,p_default_sort_column_sequence=>1
,p_default_sort_dir=>'desc'
,p_disable_sort_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(480276016928613073)
,p_query_column_id=>7
,p_column_alias=>'NUM_DOC'
,p_column_display_sequence=>4
,p_column_heading=>'Num Doc'
,p_hidden_column=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(480276482482613073)
,p_query_column_id=>8
,p_column_alias=>'ACT_SN'
,p_column_display_sequence=>9
,p_column_heading=>'Act Sn'
,p_hidden_column=>'Y'
,p_lov_show_nulls=>'NO'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(480276848743613073)
,p_query_column_id=>9
,p_column_alias=>'SI_NO'
,p_column_display_sequence=>1
,p_column_heading=>'Si No'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_lov_show_nulls=>'NO'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(3250272339662527153)
,p_plug_name=>'Barra de acciones'
,p_region_template_options=>'#DEFAULT#:t-Form--stretchInputs'
,p_plug_template=>wwv_flow_imp.id(38289497777120142)
,p_plug_display_sequence=>85
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'REGION_POSITION_01'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(480255884693612973)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(3250272339662527153)
,p_button_name=>'REVERSOS'
,p_button_static_id=>'P6400307_REV'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860056812106557)
,p_button_image_alt=>'Reversos'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_icon_css_classes=>'fa-undo-arrow'
,p_request_source=>'Go'
,p_request_source_type=>'STATIC'
,p_updated_on=>wwv_flow_imp.dz('20250318204300Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(480256688995612981)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(3250272339662527153)
,p_button_name=>'ACTUALIZACION'
,p_button_static_id=>'P6400307_REVCONT'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860056812106557)
,p_button_image_alt=>'Act. Contable'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_icon_css_classes=>'fa-bolt'
,p_request_source=>'CONTABLE'
,p_request_source_type=>'STATIC'
,p_updated_on=>wwv_flow_imp.dz('20250318204300Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(480068134464017525)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(3250272339662527153)
,p_button_name=>'PROCESO'
,p_button_static_id=>'PROCESO'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860181880106559)
,p_button_image_alt=>'Marca Contable'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_button_condition=>'P212_MOS'
,p_button_condition2=>'3'
,p_button_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_updated_on=>wwv_flow_imp.dz('20250318203912Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(480068289990017526)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(3250272339662527153)
,p_button_name=>'REVERSAR'
,p_button_static_id=>'REVERSAR'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860181880106559)
,p_button_image_alt=>'Reversar'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_button_condition=>'P212_MOS'
,p_button_condition2=>'2'
,p_button_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_updated_on=>wwv_flow_imp.dz('20250318203912Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(480068567616017529)
,p_button_sequence=>60
,p_button_plug_id=>wwv_flow_imp.id(3250272339662527153)
,p_button_name=>'MARCAR'
,p_button_static_id=>'MARCAR'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860056812106557)
,p_button_image_alt=>'Procesar'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_button_condition=>'P212_MOS'
,p_button_condition2=>'1'
,p_button_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_icon_css_classes=>'fa-check-circle-o'
,p_updated_on=>wwv_flow_imp.dz('20250318203912Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(480256274143612976)
,p_button_sequence=>70
,p_button_plug_id=>wwv_flow_imp.id(3250272339662527153)
,p_button_name=>'AUTOMATICA'
,p_button_static_id=>'CONCILIACION_AUTOMATICA'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860056812106557)
,p_button_image_alt=>unistr('Cons. Autom\00E1tica')
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_icon_css_classes=>'fa-server-clock'
,p_updated_on=>wwv_flow_imp.dz('20250318204553Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(480068698414017530)
,p_button_sequence=>80
,p_button_plug_id=>wwv_flow_imp.id(3250272339662527153)
,p_button_name=>'RESPLADO'
,p_button_static_id=>'RES'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860056812106557)
,p_button_image_alt=>'Respaldo'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_button_condition=>'P212_MOS'
,p_button_condition2=>'1000000'
,p_button_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_icon_css_classes=>'fa-database-lock'
,p_updated_on=>wwv_flow_imp.dz('20250318203912Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(480257067011612982)
,p_button_sequence=>90
,p_button_plug_id=>wwv_flow_imp.id(3250272339662527153)
,p_button_name=>'BUSCAR'
,p_button_static_id=>'BUSCAR'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860056812106557)
,p_button_image_alt=>'Buscar'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_icon_css_classes=>'fa-search'
,p_updated_on=>wwv_flow_imp.dz('20250318204300Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(480285527458613546)
,p_branch_action=>'f?p=&APP_ID.:212:&SESSION.&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_sequence=>1
,p_save_state_before_branch_yn=>'Y'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(480285915716613551)
,p_branch_action=>'f?p=&APP_ID.:212:&SESSION.&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_sequence=>1
,p_save_state_before_branch_yn=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(480257439424612982)
,p_name=>'P212_CUENTA'
,p_is_required=>true
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(592881144604674730)
,p_prompt=>'Cuenta:'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'select trim(ayaid) || '' - '' || trim(upper(aydl01)) d, trim(ayaid) r from f0030@jdedtadl where trim(aycbnk) is not null and trim(aydl01) is not null;'
,p_lov_display_null=>'YES'
,p_lov_null_text=>'Seleccione'
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(480257844886612990)
,p_name=>'P212_FECDES'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(592881144604674730)
,p_item_default=>'LAST_DAY(add_months(sysdate, -1)) +1'
,p_item_default_type=>'EXPRESSION'
,p_item_default_language=>'PLSQL'
,p_prompt=>'Fecha Desde:'
,p_format_mask=>'DD/MM/YYYY'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(480258123255612990)
,p_name=>'P212_FECHAS'
,p_is_required=>true
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(592881144604674730)
,p_item_default=>'LAST_DAY(sysdate) '
,p_item_default_type=>'EXPRESSION'
,p_item_default_language=>'PLSQL'
,p_prompt=>'Fecha Hasta:'
,p_format_mask=>'DD/MM/YYYY'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_cMaxlength=>4000
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(480258577693612990)
,p_name=>'P212_USU'
,p_is_required=>true
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(592881144604674730)
,p_item_default=>'OIMBAQUING'
,p_prompt=>'Usuario:'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_cMaxlength=>4000
,p_begin_on_new_line=>'N'
,p_read_only_when_type=>'ALWAYS'
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(480258995194612990)
,p_name=>'P212_MOD'
,p_is_required=>true
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(592881144604674730)
,p_item_default=>'1'
,p_prompt=>'Tipo:'
,p_display_as=>'NATIVE_RADIOGROUP'
,p_lov=>'STATIC:Cuentas/Cobrar;1,Cuentas/Pagar;2'
,p_read_only_when=>'Select 1 from dual where :APP_USER in (''DDELACRUZ'',''GCACHIPUENDO'')'
,p_read_only_when_type=>'NOT_EXISTS'
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'2'
,p_attribute_02=>'NONE'
,p_updated_on=>wwv_flow_imp.dz('20250825215731Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(480259325236612992)
,p_name=>'P212_MOS'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(592881144604674730)
,p_item_default=>'1'
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
,p_updated_on=>wwv_flow_imp.dz('20250318204725Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(480259723135612992)
,p_name=>'P212_REF'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_imp.id(592881144604674730)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
,p_updated_on=>wwv_flow_imp.dz('20250318204725Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(480262096400613014)
,p_name=>'P212_ORDEN'
,p_is_required=>true
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(592881144604674730)
,p_item_default=>'1'
,p_prompt=>unistr('Orden Conciliaci\00F3n:')
,p_display_as=>'NATIVE_RADIOGROUP'
,p_lov=>'STATIC2:Estado de Cuenta-LM;1, LM-Estado de Cuenta;2'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'2'
,p_attribute_02=>'NONE'
,p_updated_on=>wwv_flow_imp.dz('20250318204725Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(480262426062613014)
,p_name=>'P212_MENSAJES'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(592911962744039507)
,p_prompt=>'Mensajes:'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(480281846262613421)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Temporal'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'v_log_app	varchar2(25);',
'v_log_dsc	varchar2(999);',
'begin',
'	v_log_app := ''apex.109.212.temporal'';',
unistr('	v_log_dsc := ''Par\00E1metros: P212_MOD: ''||:p212_mod||'', P212_CUENTA: ''||:p212_cuenta||'', P212_FECDES: ''||:p212_fecdes||'', P212_FECHAS: ''||:p212_fechas||'', P212_USU: ''||:p212_usu;'),
'',
'	-- Vaciamos las temportales',
'	delete from data.t_finz_conciliaban; delete from data.t_finz_conciliacxc;',
'	pk_commons.sp_apex_log(p_aplicacion=>v_log_app,p_paso=>0,p_descripcion=>v_log_dsc,p_mensaje=>null,p_observacion=>null,p_query=>null);',
'',
'	if :p212_mod  = 1 then',
'		insert into data.t_finz_conciliacxc (fec_doc,tip_doc,num_doc,cuenta,batch,monto,comprobante,explicacion,numerodireccion)',
'		select gldgj fec_doc',
'			, gldct tip_doc',
'			, 0 num_doc',
'			, glaid cuenta',
'			, glicu batch',
'			, glaa/100 monto',
'			, nvl(trim(decode(substr(glexr,1,1),''0'',glexr,glexr )),glexa) comprobante',
'			, glexa',
'            , glan8',
'		from f0911@jdedtadl ',
'		where gldct in (''RC'',''RO'',''J#'',''JE'',''JO'')',
'			and glrcnd = '' ''',
'			and glaa > 0',
'			and glaid = :p212_cuenta',
'			and gldgj between pk_commons.f_g2jde(:p212_fecdes) and pk_commons.f_g2jde(:p212_fechas)',
'			and glre != ''V''',
'			and gllt = ''AA'';',
'',
'		insert into data.t_finz_conciliaban (comp_banco,cuenta,valor,act_sn,fecha,usuario,explicacion,num_linea)',
'		select mpcknu comprobante',
'			, mpaid',
'			, mpaa/100 monto',
'			, '' ''',
'			, mpdgj',
'			, mpedus',
'			, trim(mpexr)||'' | ''||trim(mpdl01)',
'			, mpedln',
'		from f5509505@jdedtadl',
'		where mpdgj between pk_commons.f_g2jde(:p212_fecdes) and pk_commons.f_g2jde(:p212_fechas)',
'		and trim(mpaid) = :p212_cuenta ',
'		and mpaa > 0',
'		and mpev01 != ''P''',
'		and decode(mpev01,'' '',''1'') != mpev02',
'		and trim(mpedus) = :p212_usu;',
'	else',
'		insert into data.t_finz_conciliacxc(fec_doc,tip_doc,num_doc,cuenta,batch,monto,comprobante,explicacion,numerodireccion)',
'		select gldgj fec_doc',
'			, gldct tip_doc',
'			, 0',
'			, glaid cuenta',
'			, glicu batch',
'			, glaa/100 monto',
'			, nvl(trim(decode(gldct,''JU'',glexr,''JE'',glexr,''N1'',glexr,''N2'',glexr,''RM'',glexr,''DI'',glexr,glcknu)),glexa) comprobante',
'			, glexa',
'            , glan8',
'		from f0911@jdedtadl   ',
'		where gldgj between pk_commons.f_g2jde(:p212_fecdes) and pk_commons.f_g2jde(:p212_fechas)',
'			and glaid = :p212_cuenta',
'			and gldct not in (''RC'',''RO'',''J#'',''RZ'',''PZ'',''MZ'',''4Z'')',
'			and glrcnd = '' ''',
'			and glaa < 0',
'			and glre != ''V''',
'			and gllt = ''AA'';',
'',
'		insert into data.t_finz_conciliaban (comp_banco,cuenta,valor,act_sn,fecha,usuario,explicacion,num_linea)',
'		select mpcknu comprobante',
'			, mpaid',
'			, mpaa/100 monto',
'			, '' ''',
'			, mpdgj',
'			, mpedus',
'			, trim(mpexr)||'' | ''||trim(mpdl01)',
'			, mpedln',
'		from f5509505@jdedtadl',
'		where mpdgj between pk_commons.f_g2jde(:p212_fecdes) and pk_commons.f_g2jde(:p212_fechas)',
'			and mpaid = :p212_cuenta',
'			and mpaa < 0 ',
'			and mpev01 != ''P''',
'			and decode(mpev01,'' '',''1'') != mpev02',
'			and trim(mpedus) =:p212_usu;',
'	end if;',
'',
'	:p212_mensajes	:= '' '';',
'	:p212_mos		:= 1;',
'	commit;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_process_when_button_id=>wwv_flow_imp.id(480257067011612982)
,p_internal_uid=>480281846262613421
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(480282203643613431)
,p_process_sequence=>30
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>unistr('Actualizaci\00F3n')
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'v_updatecont	number := 0;',
'v_updatebanco	number := 0;',
'v_batch			number := 0;',
'v_sum_banco		number := 0;',
'v_sum_cont		number := 0;',
'v_sum_acub		number := 0;',
'v_sum_acuc		number := 0;',
'v_condicion		number := 0;',
'v_log_app		varchar2(100);',
'v_log_dsc		varchar2(999);',
'begin',
unistr('	v_log_app := ''apex.109.212.actualizaci\00F3n'';'),
unistr('	v_log_dsc := ''Par\00E1metros: P212_MOD: ''||:p212_mod||'', P212_ORDEN: ''||:p212_orden||'', P212_CUENTA: ''||:p212_cuenta||'', P212_MOD: ''||:p212_mod;'),
'',
'	pk_commons.sp_apex_log(p_aplicacion=>v_log_app,p_paso=>0,p_descripcion=>v_log_dsc,p_mensaje=>null,p_observacion=>null,p_query=>null);',
'',
'	:p212_mensajes := '' '';',
'',
unistr('	-- Validaci\00F3n de montos'),
'	-- -- Comprobantes Bancarios',
'	for i in 1..apex_application.g_f01.count loop',
'		select valor into v_sum_banco from data.t_finz_conciliaban where sec_ban = apex_application.g_f01(i);',
'		v_sum_acub := v_sum_acub + v_sum_banco;',
'	end loop;',
'',
'	for i in 1..apex_application.g_f04.count loop',
'		select monto,batch into v_sum_cont,v_batch from data.t_finz_conciliacxc where sec_cxc = apex_application.g_f04(i);',
'		v_sum_acuc := v_sum_acuc + v_sum_cont;',
'	end loop;',
'',
'	:p212_mensajes := apex_application.g_f01.count||v_sum_acuc||v_sum_acub;',
'',
'	-- Borro actualizaciones anteriores',
'	update data.t_finz_conciliaban set act_sn = ''N''; update data.t_finz_conciliacxc set act_sn = ''N'';',
'',
'	-- Condicionamiento de orden',
'	if :p212_orden = 1 then ',
'		v_condicion := apex_application.g_f01.count;',
'	else',
'		v_condicion := apex_application.g_f04.count;',
'	end if;',
'',
'	-- Actualiza banco',
'	-- -- Comprobante',
'   for i in 1..apex_application.g_f01.count loop',
'		update data.t_finz_conciliaban set act_sn = ''Y'' where sec_ban = apex_application.g_f01(i);',
'		v_updatebanco := v_updatebanco + 1;',
'	end loop;',
'',
'	-- Actualiza contabilidad',
'	-- -- Comprobante',
'	for i in 1..apex_application.g_f04.count loop',
'		update data.t_finz_conciliacxc set act_sn = ''Y'' where sec_cxc = apex_application.g_f04(i);',
'		v_updatecont := v_updatecont + 1;',
'	end loop;',
'	-- commit;',
'',
'	if v_sum_acuc = v_sum_acub and v_condicion = 1 then',
'		-- Inserta en tabla de reversos',
'		insert into data.t_finz_conciliarev (sec_ban,comp_ban,tip_doc,com_cont,fecha,valor_banco,valor_cont,cuenta,num_linea)',
'		select comprobante',
'			, comp_banco',
'			, trim(tip_doc)',
'			, batch',
'			, sysdate',
'			, valor',
'			, monto',
'			, :p212_cuenta',
'			, num_linea',
'		from data.t_finz_conciliacxc x,data.t_finz_conciliaban y',
'		where x.act_sn = y.act_sn',
'			and x.act_sn = ''Y'';',
'',
'		-- Actualiza tablas reales',
'		-- -- Comprobante',
'		for i in 1..apex_application.g_f01.count loop',
'			update f5509505@jdedtadl set mpev02 = ''1''',
'			where trim(mpcknu)	= (select trim(comp_banco)	from data.t_finz_conciliaban where sec_ban = apex_application.g_f01(i))',
'				and mpdgj 		= (select fecha				from data.t_finz_conciliaban where sec_ban = apex_application.g_f01(i))',
'				and (mpaa/100)	= (select valor 			from data.t_finz_conciliaban where sec_ban = apex_application.g_f01(i)) ',
'				and mpedln		= (select num_linea			from data.t_finz_conciliaban where sec_ban = apex_application.g_f01(i));',
'		end loop;',
'',
'		if :p212_mod = 1 then',
'			for i in 1..apex_application.g_f04.count loop',
'				update F0911@jdedtadl set glrcnd = ''R''',
'				where glaid = :p212_cuenta and glre != ''V'' and glrcnd != ''R'' and glaa > 0',
'					and nvl(trim(decode(substr(glexr,1,1),''0'',glexr,glexr)),trim(glexa))',
'									= (select trim(comprobante)	from data.t_finz_conciliacxc where sec_cxc = apex_application.g_f04(i))',
'					and (glaa/100)	= (select monto 			from data.t_finz_conciliacxc where sec_cxc = apex_application.g_f04(i))',
'					and gldct 		= (select tip_doc 			from data.t_finz_conciliacxc where sec_cxc = apex_application.g_f04(i))',
'					and glicu 		= (select batch 			from data.t_finz_conciliacxc where sec_cxc = apex_application.g_f04(i));',
'			end loop;',
'		else',
'			for i in 1..apex_application.g_f04.count loop',
'				update F0911@jdedtadl set glrcnd = ''R''',
'				where glaid = :p212_cuenta  and glre != ''V'' and glrcnd != ''R'' and glaa < 0',
'					and nvl(trim(decode(gldct,''JU'',glexr,''JE'',glexr,''N1'',glexr,''N2'',glexr,''RM'',glexr,''DI'',glexr,glcknu)),trim(glexa))',
'									= (select trim(comprobante) from data.t_finz_conciliacxc where sec_cxc=  apex_application.g_f04(i))',
'					and (glaa/100)	= (select monto 			from data.t_finz_conciliacxc where sec_cxc = apex_application.g_f04(i))',
'					and gldct 		= (select tip_doc 			from data.t_finz_conciliacxc where sec_cxc = apex_application.g_f04(i))',
'					and glicu 		= (select batch 			from data.t_finz_conciliacxc where sec_cxc = apex_application.g_f04(i));',
'			end loop;',
'		end if;',
'',
unistr('		:p212_mensajes	:= ''Se actualiz\00F3 '' ||(v_updatecont + v_updatebanco)||'' registros.'';'),
'		:p212_ref		:= 1;',
'	else',
unistr('		:p212_mensajes	:= ''Los valores no coinciden ''||v_sum_acub||'' ''||v_sum_acuc||'' ''||'' o se ha seleccionado m\00E1s de dos comprobantes en el orden no especificado.'';'),
'		:p212_ref		:= 2;',
'	end if;',
'	commit;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_process_when_button_id=>wwv_flow_imp.id(480068567616017529)
,p_internal_uid=>480282203643613431
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(480282603223613464)
,p_process_sequence=>40
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Temporal Condicional'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'v_log_app		varchar2(50);',
'v_log_dsc		varchar2(999);',
'begin',
'	v_log_app := ''apex.109.212.temporalcondicional'';',
unistr('	v_log_dsc := ''Par\00E1metros: P212_MOD: ''||:p212_mod||'', P212_ORDEN: ''||:p212_orden||'', P212_CUENTA: ''||:p212_cuenta||'', P212_MOD: ''||:p212_mod;'),
'',
'	pk_commons.sp_apex_log(p_aplicacion=>v_log_app,p_paso=>0,p_descripcion=>v_log_dsc,p_mensaje=>null,p_observacion=>null,p_query=>null);',
'	delete from data.t_finz_conciliaban; delete from data.t_finz_conciliacxc;',
'	-- Seleccionamos los datos:',
'',
'	if :p212_mod = 1 then',
'		insert into data.t_finz_conciliacxc (fec_doc,tip_doc,num_doc,cuenta,batch,monto,comprobante,explicacion)',
'		select gldgj fec_doc',
'			, gldct tip_doc',
'			, 0 num_doc',
'			, glaid cuenta',
'			, glicu batch',
'			, glaa/100 monto',
'			, nvl(trim(decode(substr(glexr,1,1),''0'',substr(glexr,2),glexr)),glexa) comprobante',
'			, glexa',
'		from f0911@jdedtadl',
'		where gldct in (''RC'',''RO'',''J#'',''JE'') ',
'			and glrcnd = '' ''',
'			and (glaa/100) > 0 ',
'			and glaid = :p212_cuenta',
'			and gldgj between pk_commons.f_g2jde(:p212_fecdes) and pk_commons.f_g2jde(:p212_fechas)',
'			and glre != ''V''',
'			and gllt = ''AA'';',
'',
'		insert into data.t_finz_conciliaban (comp_banco,cuenta,valor,act_sn,fecha,usuario,explicacion,num_linea)',
'		select mpcknu comprobante',
'			, mpaid',
'			, mpaa/100 monto',
'			, '' ''',
'			, mpdgj',
'			, mpedus',
'			, trim(mpexr)||'' | ''||trim(mpdl01)',
'			, mpedln  ',
'		from f5509505@jdedtadl',
'		where mpdgj between pk_commons.f_g2jde(:p212_fecdes) and pk_commons.f_g2jde(:p212_fechas)',
'			and mpaid = :p212_cuenta   ',
'			and mpaa > 0 ',
'			and mpev01 != ''P'' ',
'			and decode(mpev01,'' '',''1'') != mpev02		',
'			and trim(mpedus) = :p212_usu;',
'	else',
'		insert into  data.t_finz_conciliacxc (fec_doc,tip_doc,num_doc,cuenta,batch,monto,comprobante,explicacion)',
'		select gldgj fec_doc',
'			, gldct tip_doc',
'			, 0',
'			, glaid cuenta',
'			, glicu batch',
'			, glaa/100 monto',
'			, nvl(trim(decode(gldct,''JU'',glexr,''JE'',glexr,''N1'',glexr,''N2'',glexr,''RM'',glexr,''DI'',glexr,glcknu)),glexa) comprobante',
'			, glexa',
'		from f0911@jdedtadl   ',
'		where gldgj between pk_commons.f_g2jde(:p212_fecdes) and pk_commons.f_g2jde(:p212_fechas)',
'			and glaid = :p212_cuenta  ',
'			and gldct not in (''RC'',''RO'',''J#'',''RZ'',''PZ'',''MZ'',''4Z'')',
'			and glrcnd = '' ''',
'			and glaa < 0 ',
'			and glre != ''V'' ',
'			and gllt = ''AA'';',
'',
'		insert into data.t_finz_conciliaban (comp_banco,cuenta,valor,act_sn,fecha,usuario,explicacion,num_linea)',
'		select mpcknu comprobante',
'			, mpaid',
'			, mpaa/100 monto',
'			, '' ''',
'			, mpdgj',
'			, mpedus',
'			, trim(mpexr)||'' | ''||trim(mpdl01)',
'			, mpedln',
'		from f5509505@jdedtadl',
'		where mpdgj between pk_commons.f_g2jde(:p212_fecdes) and pk_commons.f_g2jde(:p212_fechas)',
'			and mpaid = :p212_cuenta  ',
'			and mpaa < 0 ',
'			and mpev01 != ''P'' ',
'			and decode(mpev01,'' '',''1'') != mpev02  ',
'			and trim(mpedus) = :p212_usu ;',
'	end if;',
'	:p212_mos :=1;',
'	commit;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_process_when_button_id=>wwv_flow_imp.id(480068567616017529)
,p_process_when=>'P212_REF '
,p_process_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_process_when2=>'1'
,p_internal_uid=>480282603223613464
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(480283057074613532)
,p_process_sequence=>60
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Reverso'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'v_comprobante 	varchar2(100); ',
'v_contador 		number := 0;',
'v_cuenta 		varchar2(60); ',
'v_gldct 		varchar2 (3); ',
'v_gldoc 		varchar2(60);',
'v_glicu 		number := 0;',
'v_linea 		number := 0;',
'v_log_app 		varchar2(50);',
'v_log_dsc 		varchar2(999);',
'v_valor 		number := 0; ',
'begin',
'	v_log_app := ''apex.109.212.reverso'';',
unistr('	v_log_dsc := ''Par\00E1metros: P212_MOD: ''||:p212_mod||'', P212_ORDEN: ''||:p212_orden||'', P212_CUENTA: ''||:p212_cuenta||'', P212_MOD: ''||:p212_mod;'),
'',
'	pk_commons.sp_apex_log(p_aplicacion=>v_log_app,p_paso=>0,p_descripcion=>v_log_dsc,p_mensaje=>null,p_observacion=>null,p_query=>null);',
'',
'	-- Se reversa la conciliacion en las tablas reales',
'	for i in 1..apex_application.g_f05.count loop',
'		select gldoc,glicu,gldct,mpcknu,mpaa,mpedln,glaid into v_gldoc,v_glicu,v_gldct,v_comprobante,v_valor,v_linea,v_cuenta',
'		from f5509505@jdedtadl,f0911@jdedtadl',
'		where gldgj between pk_commons.f_g2jde(:p212_fecdes) and pk_commons.f_g2jde(:p212_fechas)',
'			and mpaid = glaid',
'			and glrcnd = ''R''',
'			and glaa > 0',
'			and mpev02 = ''1''',
'			and mpcknu = glexr',
'			and mpaa = glaa',
'			and glaid = :p212_cuenta',
'			and trim(mpcknu) = apex_application.g_f05(i);',
'',
'		update F0911@JDEDTADL SET GLRCND = '' ''',
'		where glaid = v_cuenta and trim(to_char(gldct)) =  v_gldct and gldoc = v_gldoc and glicu = v_glicu and glrcnd = ''R'' and glaa > 0;',
'',
'		update f5509505@jdedtadl set mpev02 = '' '' where trim(mpcknu) = trim(v_comprobante) and (mpaa) = v_valor and mpedln = v_linea;',
'',
'		v_contador := v_contador + 1;',
'	end loop;',
unistr('	:p212_mensajes := ''Se revers\00F3 ''||v_contador||'' registros.'';'),
'	commit;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_process_when_button_id=>wwv_flow_imp.id(480068289990017526)
,p_internal_uid=>480283057074613532
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(480283465659613539)
,p_process_sequence=>70
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>unistr('Autom\00E1tica')
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'v_log_app 		varchar2(50);',
'v_log_dsc 		varchar2(999);',
'begin',
unistr('	v_log_app := ''apex.109.212.autom\00E1tica'';'),
unistr('	v_log_dsc := ''Par\00E1metros: P212_USU: ''||:p212_usu||'', P212_CUENTA: ''||:p212_cuenta||'', P212_FECHAS: ''||:p212_fechas;'),
'',
'	pk_commons.sp_apex_log(p_aplicacion=>v_log_app,p_paso=>0,p_descripcion=>v_log_dsc,p_mensaje=>null,p_observacion=>null,p_query=>null);',
'',
'	--BORRADO DE TEMPORALES',
'	delete from data.t_finz_conciliaban; delete from data.t_finz_conciliacxc;',
'	commit;',
'',
'	data.pk_finz_cobroclientes.sp_conciliacion_auto(fecha_a=>:p212_fechas,cuenta => :p212_cuenta,usuario => :p212_usu);',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_process_when_button_id=>wwv_flow_imp.id(480256274143612976)
,p_internal_uid=>480283465659613539
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(480283859562613540)
,p_process_sequence=>80
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Periodo'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
'',
'--BORRO EL RESPALDO DEL MES SI HUBIERA',
'--BORRO DATOS CONTABLES',
'DELETE FROM DATA.T_FINZ_CONCILIARESP WHERE PERIODO = :P212_FECHAS AND CUENTA =:P212_CUENTA;',
'',
'--BORRO DATOS BANCOS',
'DELETE FROM DATA.T_FINZ_CONCILIARESP WHERE PERIODO = :P212_FECHAS AND CUENTA_BAN=:P212_CUENTA;',
'',
'',
'--INSERTO LA PARTE CONTABLE CXC',
'',
'INSERT INTO DATA.T_FINZ_CONCILIARESP  (FEC_DOC, TIP_DOC, CUENTA, BATCH, MONTO , COMP_CONT, PERIODO,NUM_LIN_CONT,NUM_DOC_CONT)',
'SELECT  max(GLDGJ)  FEC_DOC,GLDCT TIP_DOC, MAX( GLAID) CUENTA,GLICU BATCH, SUM(GLAA/100 ) MONTO  ,',
'DECODE(SUBSTR(GLEXR,1,1),''0'',SUBSTR(GLEXR,2) , GLEXR )  COMPROBANTE,:P212_FECHAS,GLJELN, GLDOC',
'FROM F0911@JDEDTADL',
'WHERE  GLDCT IN (''RC'',''RO'',''J#'',''JE'') AND GLRCND ='' '' ',
'AND (GLAA/100)>0 AND',
'GLAID =:P212_CUENTA  AND GLLT =''AA''   AND to_date(GLDGJ+ 1900000,''yyyyddd'')   between :P212_FECDES  and :P212_FECHAS  and GLRE!=''V''',
'GROUP BY  GLDCT,  GLANI, GLICU, GLEXR ,GLJELN ,GLDOC',
'UNION',
'SELECT GLDGJ  FEC_DOC,MAX(GLDCT) TIP_DOC,MAX(  GLAID) CUENTA,MAX(GLICU) BATCH, SUM( GLAA/100) MONTO  ,DECODE( GLDCT,''JU'',GLEXR, ',
'    ''JE'', GLEXR,''N1'',GLEXR,''N2'',GLEXR,''RM'',GLEXR,''DI'', GLEXR,  GLCKNU) COMPROBANTE,:P212_FECHAS ,GLJELN, GLDOC',
'FROM F0911@JDEDTADL  WHERE TO_DATE(GLDGJ  + 1900000,''yyyyddd'') between :P212_FECDES  and :P212_FECHAS ',
'AND GLAID =:P212_CUENTA  AND GLDCT NOT IN (''RC'',''RO'',''J#'',''RZ'',''PZ'',''MZ'',''4Z'') AND GLRCND ='' ''  AND GLAA<0 AND GLRE!=''V''',
' AND GLLT =''AA'' ',
'GROUP BY GLDGJ ,DECODE( GLDCT,''JU'',GLEXR, ',
'    ''JE'', GLEXR,''N1'',GLEXR,''N2'',GLEXR,''RM'',GLEXR,''DI'', GLEXR,  GLCKNU),GLJELN, GLDOC ;',
'',
'---SE INSERTA LA PARTE CONTABLE CXP',
'',
'INSERT INTO DATA.T_FINZ_CONCILIARESP (COMP_BAN,CUENTA_BAN, VALOR, FEC_BAN, USUARIO,PERIODO, NUM_LIN_BAN )',
'SELECT MPCKNU COMPROBANTE, MAX(MPAID), SUM(MPAA/100) MONTO, MPDGJ, MAX(MPEDUS),:P212_FECHAS, MPEDLN',
'FROM F5509505@JDEDTADL  WHERE   to_date(MPDGJ+ 1900000,''yyyyddd'') between :P212_FECDES  and :P212_FECHAS ',
'AND TRIM(MPAID) =:P212_CUENTA   AND MPAA>0  AND MPEV01<>''P'' AND DECODE(MPEV01,'' '', ''1'') <>MPEV02  ',
'--AND TRIM(MPEDUS) = :P212_USU ',
'GROUP BY MPCKNU,MPDGJ,MPEDLN',
'UNION',
'SELECT MPCKNU COMPROBANTE,MAX(MPAID), SUM(MPAA/100) MONTO,MPDGJ, MAX(MPEDUS ),:P212_FECHAS,MPEDLN',
'FROM F5509505@JDEDTADL  WHERE   TO_DATE(MPDGJ+ 1900000,''yyyyddd'') between :P212_FECDES  and :P212_FECHAS ',
'AND TRIM(MPAID) =:P212_CUENTA  AND MPAA<0 ',
'AND MPEV01<>''P'' AND DECODE(MPEV01,'' '', ''1'') <>MPEV02   ',
'--AND TRIM(MPEDUS) =:P212_USU ',
'GROUP BY MPCKNU,MPDGJ,MPEDLN;',
'',
'',
'COMMIT;',
'',
'',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_process_error_message=>'NO SE HA GENERADO EL RESPALDO '
,p_process_when_button_id=>wwv_flow_imp.id(480068698414017530)
,p_process_success_message=>'SE HA REALIZADO EL RESPALDO CORRECTAMENTE'
,p_internal_uid=>480283859562613540
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(480284630011613545)
,p_process_sequence=>105
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Carga Contador'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'v_log_app		varchar2(100);',
'v_log_dsc		varchar2(999);',
'begin',
'	v_log_app := ''apex.109.212.cargacontador'';',
unistr('	v_log_dsc := ''Par\00E1metros: P212_MOD: ''||:p212_mod||'', P212_ORDEN: ''||:p212_orden||'', P212_CUENTA: ''||:p212_cuenta;'),
'',
'	pk_commons.sp_apex_log(p_aplicacion=>v_log_app,p_paso=>0,p_descripcion=>v_log_dsc,p_mensaje=>null,p_observacion=>null,p_query=>null);',
'',
'	delete from data.t_finz_conciliacxc;',
'',
'	insert into data.t_finz_conciliacxc (fec_doc,tip_doc,num_doc,cuenta,batch,monto,comprobante)',
'	select  max(gldgj) fec_doc',
'		, gldct tip_doc',
'		, 0 num_doc',
'		, max(glaid) cuenta',
'		, glicu batch',
'		, sum(glaa)/100 monto',
'		, glexr comprobante',
'	from f0911@jdedtadl',
'	where gldct in (''RC'',''RO'',''J#'',''JE'',''PO'',''JO'')',
'		and glrcnd = '' '' ',
'		and glaa > 0',
'		and gllt = ''AA''',
'		and glaid = :p212_cuenta',
'		and gldgj between pk_commons.f_g2jde(:p212_fecdes) and pk_commons.f_g2jde(:p212_fechas)',
'		and glre != ''V''',
'	group by gldct,glani,glicu,glexr;',
'',
'	insert into data.t_finz_conciliacxc (fec_doc,tip_doc,num_doc,cuenta,batch,monto,comprobante)',
'	select gldgj fec_doc',
'		, max(gldct) tip_doc',
'		, 0',
'		, max(glaid) cuenta',
'		, max(glicu) batch',
'		, sum(glaa)/100 monto',
'		, decode(gldct,''JU'',glexr,''JE'',glexr,''N1'',glexr,''N2'',glexr,''RM'',glexr,''DI'',glexr,glcknu) comprobante',
'	from f0911@jdedtadl',
'	where gldgj between pk_commons.f_g2jde(:p212_fecdes) and pk_commons.f_g2jde(:p212_fechas)',
'		and glaid = :p212_cuenta',
'		and gldct not in (''RC'',''J#'')',
'		and glrcnd = '' ''',
'		and glaa < 0',
'		and glre != ''V''',
'		and gllt = ''AA''',
'	group by gldgj,decode(gldct,''JU'',glexr,''JE'',glexr,''N1'',glexr,''N2'',glexr,''RM'',glexr,''DI'',glexr,glcknu);',
'',
'	:p212_mensajes := '' '';',
'	:p212_mos := 3;',
'	commit;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_process_when_button_id=>wwv_flow_imp.id(480256688995612981)
,p_internal_uid=>480284630011613545
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(480284256805613542)
,p_process_sequence=>110
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Actualiza Contador'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'v_updatecont	number := 0;',
'v_updatebanco	number := 0;',
'v_sum_banc		number := 0;',
'v_sum_cont		number := 0;',
'v_sum_acub		number := 0;',
'v_sum_acuc		number := 0;',
'v_log_app		varchar2(100);',
'v_log_dsc		varchar2(999);',
'begin',
'	v_log_app := ''apex.109.212.actualizacontador'';',
unistr('	v_log_dsc := ''Par\00E1metros: P212_MOD: ''||:p212_mod||'', P212_ORDEN: ''||:p212_orden||'', P212_CUENTA: ''||:p212_cuenta||'', P212_MOD: ''||:p212_mod;'),
'',
'	pk_commons.sp_apex_log(p_aplicacion=>v_log_app,p_paso=>0,p_descripcion=>v_log_dsc,p_mensaje=>null,p_observacion=>null,p_query=>null);',
unistr('	-- Validaci\00F3n de montos'),
'	for i in 1..apex_application.g_f02.count loop',
'		select monto into v_sum_banc from data.t_finz_conciliacxc where sec_cxc = apex_application.g_f02(i);',
'		v_sum_acub := v_sum_acub + v_sum_banc;',
'	end loop;',
'',
'	for i in 1..apex_application.g_f03.count loop',
'		select monto into v_sum_cont from data.t_finz_conciliacxc where sec_cxc = apex_application.g_f03(i);',
'		v_sum_acuc := v_sum_acuc + v_sum_cont;',
'	end loop;',
'',
'	if ((v_sum_acuc)*-1) = v_sum_acub then',
'		-- Actualiza banco',
'		for i in 1..apex_application.g_f02.count loop',
'			update data.t_finz_conciliacxc set act_sn = ''Y'' where sec_cxc = apex_application.g_f02(i);',
'			v_updatebanco := v_updatebanco + 1;',
'		end loop;',
'		-- Actualiza contabilidad',
'		for i in 1..apex_application.g_f03.count loop',
'			update data.t_finz_conciliacxc set act_sn = ''Y'' where sec_cxc = apex_application.g_f03(i);',
'			v_updatecont := v_updatecont + 1;',
'		end loop;',
'',
'		-- Inserta en tabla de reversos',
'		insert into data.t_finz_conciliarev (sec_ban,comp_ban,tip_doc,com_cont,fecha,valor_banco,valor_cont,cuenta)',
'		select comprobante',
'			, '' ''',
'			, trim(tip_doc)',
'			, batch',
'			, sysdate',
'			, 0',
'			, monto',
'			, :p212_cuenta',
'		from data.t_finz_conciliacxc where act_sn = ''Y'' and monto > 0;',
'',
'		insert into data.t_finz_conciliarev(sec_ban,comp_ban,tip_doc,com_cont,fecha,valor_banco,valor_cont,cuenta)',
'		select comprobante',
'			, '' ''',
'			, trim(tip_doc)',
'			, batch',
'			, sysdate',
'			, 0',
'			, monto',
'			, :p212_cuenta',
'		from data.t_finz_conciliacxc where act_sn = ''Y'' and monto < 0;',
'',
'		update f0911@jdedtadl set glrcnd =',
'				(select ''R'' from data.t_finz_conciliarev where tip_doc = gldct and trim(glexr) = trim(sec_ban) and com_cont = glicu)',
'		where glaid = :p212_cuenta',
'			and glre != ''V''',
'			and glrcnd != ''R''',
'			and gllt = ''AA''',
'			and exists',
'				(select ''R'' from data.t_finz_conciliarev where tip_doc = gldct and trim(glexr) = trim(sec_ban) and com_cont = glicu);',
'		',
unistr('		:p212_mensajes := ''Se actualiz\00F3 '' ||(v_updatecont + v_updatebanco)||'' registros.'';'),
'	else',
unistr('		:p212_mensajes := ''Los valores no coinciden: '' ||(v_sum_acuc)*-1||'' - ''||v_sum_acub ||'', ''||'' o se ha seleccionado m\00E1s de dos registros.'';'),
'	end if;',
'	commit;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_process_when_button_id=>wwv_flow_imp.id(480068134464017525)
,p_internal_uid=>480284256805613542
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(480285089307613545)
,p_process_sequence=>120
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Mostrar'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'	:p212_mos		:= 2;',
'	:p212_mensajes	:='' '';',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_process_when_button_id=>wwv_flow_imp.id(480255884693612973)
,p_internal_uid=>480285089307613545
);
wwv_flow_imp.component_end;
end;
/
