prompt --application/pages/page_00465
begin
--   Manifest
--     PAGE: 00465
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>109
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_page.create_page(
 p_id=>465
,p_name=>'Activos Fijos - Reportes'
,p_alias=>'REPORTES-ACTIVOS-FIJOS'
,p_page_mode=>'NON_MODAL'
,p_step_title=>'Reportes'
,p_autocomplete_on_off=>'OFF'
,p_javascript_code_onload=>'$(regOcultos).hide();'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'18'
,p_created_on=>wwv_flow_imp.dz('20260130050758Z')
,p_last_updated_on=>wwv_flow_imp.dz('20260326142508Z')
,p_created_by=>'DDELACRUZ'
,p_last_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(336785719735176410)
,p_plug_name=>'Ocultos'
,p_region_name=>'regOcultos'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(38289867500120143)
,p_plug_display_sequence=>20
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
,p_created_on=>wwv_flow_imp.dz('20260130050937Z')
,p_updated_on=>wwv_flow_imp.dz('20260224174721Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(336785885429176411)
,p_plug_name=>unistr('Contabilidad vs. M\00F3dulo')
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(37806762584106520)
,p_plug_display_sequence=>40
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select txt01',
'	, txt02',
'	, txt03',
'	, num01',
'	, txt04',
'	, num02',
'	, num03',
'	, num04',
'	, txt05',
'	, txt06',
'	, txt07',
'	, num05',
'from data.t_apex_temporal',
'where 1 = 1',
'	and :p465_item = ''CVM''',
'	and flag = ''reporte''',
'	and control01 = :g_compania',
'	and control02 = ''FINZ''',
'	and control03 = :app_user',
'	and control04 = ''pk_finz_activosfijos.sp_contabilidadxmodulo'';',
''))
,p_plug_source_type=>'NATIVE_IR'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
,p_created_on=>wwv_flow_imp.dz('20260130052233Z')
,p_updated_on=>wwv_flow_imp.dz('20260224174721Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(336785938075176412)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_highlight=>'N'
,p_show_computation=>'N'
,p_show_aggregate=>'N'
,p_show_chart=>'N'
,p_show_group_by=>'N'
,p_show_pivot=>'N'
,p_show_flashback=>'N'
,p_show_help=>'N'
,p_download_formats=>'XLSX'
,p_enable_mail_download=>'N'
,p_owner=>'DDELACRUZ'
,p_internal_uid=>336785938075176412
,p_created_on=>wwv_flow_imp.dz('20260130052233Z')
,p_updated_on=>wwv_flow_imp.dz('20260130150359Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(336786073280176413)
,p_db_column_name=>'TXT01'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>unistr('Compan\00EDa')
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_created_on=>wwv_flow_imp.dz('20260130052233Z')
,p_updated_on=>wwv_flow_imp.dz('20260130150254Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(336786197817176414)
,p_db_column_name=>'TXT02'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Cuenta'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20260130052233Z')
,p_updated_on=>wwv_flow_imp.dz('20260130150254Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(336786204456176415)
,p_db_column_name=>'TXT03'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Nombre Cuenta'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20260130052233Z')
,p_updated_on=>wwv_flow_imp.dz('20260130052856Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(336786346528176416)
,p_db_column_name=>'NUM01'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>unistr('A\00F1o')
,p_column_type=>'NUMBER'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20260130052233Z')
,p_updated_on=>wwv_flow_imp.dz('20260130052856Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(336786441118176417)
,p_db_column_name=>'TXT04'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Mes'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20260130052233Z')
,p_updated_on=>wwv_flow_imp.dz('20260130150254Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(336786536759176418)
,p_db_column_name=>'NUM02'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>unistr('Val. M\00F3dulo')
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20260130052233Z')
,p_updated_on=>wwv_flow_imp.dz('20260130052856Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(336786655164176419)
,p_db_column_name=>'NUM03'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>'Val. Contable'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20260130052233Z')
,p_updated_on=>wwv_flow_imp.dz('20260130052856Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(336786761899176420)
,p_db_column_name=>'NUM04'
,p_display_order=>80
,p_column_identifier=>'H'
,p_column_label=>'Diferencia'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20260130052233Z')
,p_updated_on=>wwv_flow_imp.dz('20260130052856Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(336786833554176421)
,p_db_column_name=>'TXT05'
,p_display_order=>90
,p_column_identifier=>'I'
,p_column_label=>'Libro'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20260130052233Z')
,p_updated_on=>wwv_flow_imp.dz('20260130052856Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(336786968851176422)
,p_db_column_name=>'TXT06'
,p_display_order=>100
,p_column_identifier=>'J'
,p_column_label=>unistr('C\00F3d. Activo')
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20260130052233Z')
,p_updated_on=>wwv_flow_imp.dz('20260130150255Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(336787041611176423)
,p_db_column_name=>'TXT07'
,p_display_order=>110
,p_column_identifier=>'K'
,p_column_label=>unistr('C\00F3d. Cuenta')
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20260130052233Z')
,p_updated_on=>wwv_flow_imp.dz('20260130052856Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(336787179355176424)
,p_db_column_name=>'NUM05'
,p_display_order=>120
,p_column_identifier=>'L'
,p_column_label=>'Cant. Registros'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_created_on=>wwv_flow_imp.dz('20260130052233Z')
,p_updated_on=>wwv_flow_imp.dz('20260130150255Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(337378516587650233)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'3373786'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_display_rows=>100
,p_report_columns=>'TXT02:TXT07:TXT03:TXT05:NUM01:TXT04:TXT06:NUM02:NUM03:NUM04:'
,p_created_on=>wwv_flow_imp.dz('20260130145547Z')
,p_updated_on=>wwv_flow_imp.dz('20260130150322Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(465578002590004843)
,p_plug_name=>'Barra de acciones'
,p_region_template_options=>'#DEFAULT#:t-Form--stretchInputs'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(38289497777120142)
,p_plug_display_sequence=>10
,p_location=>null
,p_menu_id=>wwv_flow_imp.id(37761271469106475)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(37860983999106559)
,p_ai_enabled=>false
,p_created_on=>wwv_flow_imp.dz('20260224174449Z')
,p_updated_on=>wwv_flow_imp.dz('20260224174721Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(355334524974124212)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(465578002590004843)
,p_button_name=>'REFRESH'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860056812106557)
,p_button_image_alt=>'Refrescar'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-refresh'
,p_grid_new_row=>'Y'
,p_created_on=>wwv_flow_imp.dz('20260224174721Z')
,p_updated_on=>wwv_flow_imp.dz('20260224175733Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(336787268843176425)
,p_name=>'P465_ITEM'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(336785719735176410)
,p_prompt=>'Item'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_created_on=>wwv_flow_imp.dz('20260130052328Z')
,p_updated_on=>wwv_flow_imp.dz('20260130052328Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(336787374769176426)
,p_name=>'P465_BANDERA'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(336785719735176410)
,p_prompt=>'Bandera'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_created_on=>wwv_flow_imp.dz('20260130052328Z')
,p_updated_on=>wwv_flow_imp.dz('20260130052328Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(355334699893124213)
,p_name=>'Refresh'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(355334524974124212)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
,p_created_on=>wwv_flow_imp.dz('20260224174722Z')
,p_updated_on=>wwv_flow_imp.dz('20260224175733Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(355334765251124214)
,p_event_id=>wwv_flow_imp.id(355334699893124213)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'mostrarBarra();'
,p_created_on=>wwv_flow_imp.dz('20260224174722Z')
,p_updated_on=>wwv_flow_imp.dz('20260224174722Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(355334875138124215)
,p_event_id=>wwv_flow_imp.id(355334699893124213)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>'data.pk_finz_activosfijos.sp_contabilidadxmodulo(:g_compania,:app_user);'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
,p_created_on=>wwv_flow_imp.dz('20260224174722Z')
,p_updated_on=>wwv_flow_imp.dz('20260224174722Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(355334993813124216)
,p_event_id=>wwv_flow_imp.id(355334699893124213)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'ocultarBarra();'
,p_created_on=>wwv_flow_imp.dz('20260224174722Z')
,p_updated_on=>wwv_flow_imp.dz('20260224174722Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(355335052694124217)
,p_event_id=>wwv_flow_imp.id(355334699893124213)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_02=>'Y'
,p_created_on=>wwv_flow_imp.dz('20260224174722Z')
,p_updated_on=>wwv_flow_imp.dz('20260224174722Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(336787445593176427)
,p_process_sequence=>10
,p_process_point=>'AFTER_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'SetUp'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'v_qty_cvm	number;',
'v_item		varchar2(10);',
'begin',
'	:p465_bandera	:= 0;',
'',
'	v_item			:= :p465_item;',
'',
'	if v_item = ''CVM'' then',
'		select count(1) into v_qty_cvm',
'		from data.t_apex_temporal',
'		where 1 = 1',
'			and flag = ''reporte''',
'			and control01 = :g_compania',
'			and control02 = ''FINZ''',
'			and control03 = :app_user',
'			and control04 = ''pk_finz_activosfijos.sp_contabilidadxmodulo'';',
'',
'		if v_qty_cvm = 0 then',
'			data.pk_finz_activosfijos.sp_contabilidadxmodulo(:g_compania,:app_user);',
'		end if;',
'	end if;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>336787445593176427
,p_created_on=>wwv_flow_imp.dz('20260130052856Z')
,p_updated_on=>wwv_flow_imp.dz('20260130053658Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp.component_end;
end;
/
