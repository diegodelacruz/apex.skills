prompt --application/pages/page_00211
begin
--   Manifest
--     PAGE: 00211
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>109
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_page.create_page(
 p_id=>211
,p_name=>unistr('Reporte de Conciliaci\00F3n Bancaria')
,p_step_title=>unistr('Reporte de Conciliaci\00F3n Bancaria')
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_page_component_map=>'03'
,p_created_on=>wwv_flow_imp.dz('20230705164635Z')
,p_last_updated_on=>wwv_flow_imp.dz('20210913155556Z')
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1469932777567380196)
,p_plug_name=>unistr('Reporte de Conciliaci\00F3n Bancaria')
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(37817215439106526)
,p_plug_display_sequence=>1
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_item_display_point=>'BELOW'
,p_menu_id=>wwv_flow_imp.id(37761271469106475)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(37860983999106559)
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1469933284399393862)
,p_plug_name=>unistr('Reporte de conciliaci\00F3n Bancaria')
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(38289867500120143)
,p_plug_display_sequence=>11
,p_plug_new_grid_row=>false
,p_plug_display_column=>1
,p_plug_item_display_point=>'BELOW'
,p_plug_query_headings_type=>'QUERY_COLUMNS'
,p_plug_query_num_rows=>15
,p_plug_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_plug_query_show_nulls_as=>' - '
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML',
  'show_line_breaks', 'N')).to_clob
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(1470061677239486379)
,p_name=>'Nosotros Debitamos_Banco No Acredita'
,p_parent_plug_id=>wwv_flow_imp.id(1469933284399393862)
,p_template=>wwv_flow_imp.id(37807886111106520)
,p_display_sequence=>21
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_new_grid_row=>false
,p_new_grid_column=>false
,p_display_point=>'SUB_REGIONS'
,p_item_display_point=>'BELOW'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
unistr('SELECT F_JDE2G(GLDGJ ) FEC_DOC,GLDCT TIP_DOC, GLDOC NUM_DOC, GLANI CUENTA,GLICU BATCH, GLAA/100 MONTO  ,GLEXR COMPROBANTE, GLEXA DESCRIPCI\00D3N'),
'FROM F0911@JDEDTADL WHERE GLDGJ <= to_char(to_date(:FEC_HASTA, ''DD/MM/YYYY''), ''YYYYDDD'') -1900000 AND (GLAA/100)>0 AND ',
'GLAID =:CUENTA AND GLDCT IN (''RC'',''RO'',''J#'',''JE'') AND GLRE !=''V'' and GLRCND ='' '' and gllt=''AA''',
'ORDER BY GLDGJ;'))
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(37830327650106535)
,p_query_num_rows=>20
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_show_nulls_as=>' - '
,p_query_no_data_found=>unistr('No se ha encontrado ning\00FAn dato')
,p_query_num_rows_type=>'ROW_RANGES_WITH_LINKS'
,p_query_row_count_max=>10000
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_query_asc_image=>'apex/builder/dup.gif'
,p_query_asc_image_attr=>'width="16" height="16" alt="" '
,p_query_desc_image=>'apex/builder/ddown.gif'
,p_query_desc_image_attr=>'width="16" height="16" alt="" '
,p_plug_query_strip_html=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(480399407538705670)
,p_query_column_id=>1
,p_column_alias=>'FEC_DOC'
,p_column_display_sequence=>1
,p_column_heading=>'Fec Doc'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(480402109380705742)
,p_query_column_id=>2
,p_column_alias=>'TIP_DOC'
,p_column_display_sequence=>2
,p_column_heading=>'Tip Doc'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(480399875173705740)
,p_query_column_id=>3
,p_column_alias=>'NUM_DOC'
,p_column_display_sequence=>3
,p_column_heading=>'Num Doc'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(480400118240705740)
,p_query_column_id=>4
,p_column_alias=>'CUENTA'
,p_column_display_sequence=>4
,p_column_heading=>'Cuenta'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(480400542411705740)
,p_query_column_id=>5
,p_column_alias=>'BATCH'
,p_column_display_sequence=>5
,p_column_heading=>'Batch'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(480400992263705740)
,p_query_column_id=>6
,p_column_alias=>'MONTO'
,p_column_display_sequence=>6
,p_column_heading=>'Monto'
,p_column_alignment=>'RIGHT'
,p_sum_column=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(480401399274705742)
,p_query_column_id=>7
,p_column_alias=>'COMPROBANTE'
,p_column_display_sequence=>7
,p_column_heading=>'Comprobante'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(480401770822705742)
,p_query_column_id=>8
,p_column_alias=>unistr('DESCRIPCI\00D3N')
,p_column_display_sequence=>8
,p_column_heading=>unistr('Descripci\00F3n')
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(1470074487318792074)
,p_name=>'Nosotros Acreditamos___ Banco No Debita'
,p_parent_plug_id=>wwv_flow_imp.id(1469933284399393862)
,p_template=>wwv_flow_imp.id(37806762584106520)
,p_display_sequence=>31
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_new_grid_row=>false
,p_new_grid_column=>false
,p_display_point=>'SUB_REGIONS'
,p_item_display_point=>'BELOW'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
unistr('SELECT F_JDE2G(GLDGJ ) FEC_DOC,GLDCT TIP_DOC, GLDOC NUM_DOC, GLANI CUENTA,GLICU BATCH, GLAA/100 MONTO  ,GLCKNU COMPROBANTE, GLEXA DESCRIPCI\00D3N'),
'FROM F0911@JDEDTADL   WHERE GLDGJ <= to_char(to_date(:FEC_HASTA, ''DD/MM/YYYY''), ''YYYYDDD'') -1900000 AND',
'GLAID =:CUENTA  AND GLDCT NOT IN (''RC'',''RO'',''J#'',''RZ'',''PZ'',''MZ'',''4Z'') AND GLRCND ='' ''  AND GLAA<0',
'AND GLRE !=''V'' AND GLLT=''AA''',
'ORDER BY GLDGJ;'))
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(37830327650106535)
,p_query_num_rows=>50
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_show_nulls_as=>' - '
,p_query_no_data_found=>unistr('No se ha encontrado ning\00FAn dato')
,p_query_num_rows_type=>'ROW_RANGES_WITH_LINKS'
,p_query_row_count_max=>10000
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'Y'
,p_csv_output_link_text=>'exportar'
,p_prn_output=>'N'
,p_prn_format=>'PDF'
,p_prn_output_show_link=>'Y'
,p_prn_output_link_text=>'Print'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width_units=>'PERCENTAGE'
,p_prn_width=>11
,p_prn_height=>85
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#ffffff'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_sort_null=>'L'
,p_query_asc_image=>'apex/builder/dup.gif'
,p_query_asc_image_attr=>'width="16" height="16" alt="" '
,p_query_desc_image=>'apex/builder/ddown.gif'
,p_query_desc_image_attr=>'width="16" height="16" alt="" '
,p_plug_query_exp_filename=>'banco noacredita'
,p_plug_query_strip_html=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(480404083768705745)
,p_query_column_id=>1
,p_column_alias=>'FEC_DOC'
,p_column_display_sequence=>1
,p_column_heading=>'Fec Doc'
,p_include_in_export=>'Y'
,p_print_col_width=>'12'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(480404419358705745)
,p_query_column_id=>2
,p_column_alias=>'TIP_DOC'
,p_column_display_sequence=>2
,p_column_heading=>'Tip Doc'
,p_include_in_export=>'Y'
,p_print_col_width=>'12'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(480404819109705745)
,p_query_column_id=>3
,p_column_alias=>'NUM_DOC'
,p_column_display_sequence=>3
,p_column_heading=>'Num Doc'
,p_include_in_export=>'Y'
,p_print_col_width=>'12'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(480405279773705779)
,p_query_column_id=>4
,p_column_alias=>'CUENTA'
,p_column_display_sequence=>4
,p_column_heading=>'Cuenta'
,p_include_in_export=>'Y'
,p_print_col_width=>'12'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(480405668676705779)
,p_query_column_id=>5
,p_column_alias=>'BATCH'
,p_column_display_sequence=>5
,p_column_heading=>'Batch'
,p_include_in_export=>'Y'
,p_print_col_width=>'12'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(480402872051705743)
,p_query_column_id=>6
,p_column_alias=>'MONTO'
,p_column_display_sequence=>6
,p_column_heading=>'Monto'
,p_column_alignment=>'RIGHT'
,p_sum_column=>'Y'
,p_include_in_export=>'Y'
,p_print_col_width=>'12'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(480403212573705743)
,p_query_column_id=>7
,p_column_alias=>'COMPROBANTE'
,p_column_display_sequence=>7
,p_column_heading=>'Comprobante'
,p_include_in_export=>'Y'
,p_print_col_width=>'12'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(480403639615705743)
,p_query_column_id=>8
,p_column_alias=>unistr('DESCRIPCI\00D3N')
,p_column_display_sequence=>8
,p_column_heading=>unistr('Descripci\00F3n')
,p_include_in_export=>'Y'
,p_print_col_width=>'12'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(1470075678361817898)
,p_name=>'Banco Acredita___ Nosotros No Debitamos'
,p_parent_plug_id=>wwv_flow_imp.id(1469933284399393862)
,p_template=>wwv_flow_imp.id(37806762584106520)
,p_display_sequence=>41
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_new_grid_row=>false
,p_new_grid_column=>false
,p_display_point=>'SUB_REGIONS'
,p_item_display_point=>'BELOW'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
unistr('SELECT MPCKNU COMPROBANTE, MPAA/100 MONTO,MPEXR EXPLICACI\00D3N,F_JDE2G(MPDGJ) FECHA   '),
'FROM F5509505@JDEDTADL  WHERE   MPDGJ <= to_char(to_date(:FEC_HASTA, ''DD/MM/YYYY''), ''YYYYDDD'') -1900000',
'AND MPAID =:CUENTA  AND MPAA>0 AND MPEV01 <>''P'' AND MPEV02<>''1'';',
''))
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(37830327650106535)
,p_query_num_rows=>20
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_show_nulls_as=>' - '
,p_query_no_data_found=>unistr('No se ha encontrado ning\00FAn dato')
,p_query_num_rows_type=>'ROW_RANGES_WITH_LINKS'
,p_query_row_count_max=>10000
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_query_asc_image=>'apex/builder/dup.gif'
,p_query_asc_image_attr=>'width="16" height="16" alt="" '
,p_query_desc_image=>'apex/builder/ddown.gif'
,p_query_desc_image_attr=>'width="16" height="16" alt="" '
,p_plug_query_strip_html=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(480406341896705782)
,p_query_column_id=>1
,p_column_alias=>'COMPROBANTE'
,p_column_display_sequence=>2
,p_column_heading=>'Comprobante'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(480406732182705782)
,p_query_column_id=>2
,p_column_alias=>'MONTO'
,p_column_display_sequence=>3
,p_column_heading=>'Monto'
,p_column_alignment=>'RIGHT'
,p_sum_column=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(480407191735705782)
,p_query_column_id=>3
,p_column_alias=>unistr('EXPLICACI\00D3N')
,p_column_display_sequence=>4
,p_column_heading=>unistr('Explicaci\00F3n')
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(480407509534705784)
,p_query_column_id=>4
,p_column_alias=>'FECHA'
,p_column_display_sequence=>1
,p_column_heading=>'Fecha'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(1470076989883877918)
,p_name=>'Banco Debita Nosotros No Acreditamos'
,p_parent_plug_id=>wwv_flow_imp.id(1469933284399393862)
,p_template=>wwv_flow_imp.id(37806762584106520)
,p_display_sequence=>41
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_new_grid_row=>false
,p_new_grid_column=>false
,p_display_point=>'SUB_REGIONS'
,p_item_display_point=>'BELOW'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
unistr('SELECT MPCKNU COMPROBANTE, MPAA/100 MONTO,MPEXR EXPLICACI\00D3N,F_JDE2G(MPDGJ) FECHA   '),
'FROM F5509505@JDEDTADL  WHERE   MPDGJ <= to_char(to_date(:FEC_HASTA, ''DD/MM/YYYY''), ''YYYYDDD'') -1900000',
'AND MPAID =:CUENTA  AND MPAA<0 AND MPEV01 <>''P'' AND MPEV02<>''1'';',
''))
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(37830327650106535)
,p_query_num_rows=>20
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_show_nulls_as=>' - '
,p_query_no_data_found=>unistr('No se ha encontrado ning\00FAn dato')
,p_query_num_rows_type=>'ROW_RANGES_WITH_LINKS'
,p_query_row_count_max=>10000
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_query_asc_image=>'apex/builder/dup.gif'
,p_query_asc_image_attr=>'width="16" height="16" alt="" '
,p_query_desc_image=>'apex/builder/ddown.gif'
,p_query_desc_image_attr=>'width="16" height="16" alt="" '
,p_plug_query_strip_html=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(480408212315705787)
,p_query_column_id=>1
,p_column_alias=>'COMPROBANTE'
,p_column_display_sequence=>2
,p_column_heading=>'Comprobante'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(480408528220705789)
,p_query_column_id=>2
,p_column_alias=>'MONTO'
,p_column_display_sequence=>3
,p_column_heading=>'Monto'
,p_column_alignment=>'RIGHT'
,p_sum_column=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(480408942656705789)
,p_query_column_id=>3
,p_column_alias=>unistr('EXPLICACI\00D3N')
,p_column_display_sequence=>4
,p_column_heading=>unistr('Explicaci\00F3n')
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(480409359107705806)
,p_query_column_id=>4
,p_column_alias=>'FECHA'
,p_column_display_sequence=>1
,p_column_heading=>'Fecha'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(4211035119583479594)
,p_plug_name=>'Barra de acciones'
,p_region_template_options=>'#DEFAULT#:t-Form--stretchInputs'
,p_plug_template=>wwv_flow_imp.id(38289497777120142)
,p_plug_display_sequence=>51
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'REGION_POSITION_01'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(480410037495705810)
,p_button_sequence=>100
,p_button_plug_id=>wwv_flow_imp.id(4211035119583479594)
,p_button_name=>'BTN_EJECUTAR'
,p_button_static_id=>'BTN_EJECUTAR'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860056812106557)
,p_button_image_alt=>'EJECUTAR'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_icon_css_classes=>'fa-search'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(480410864827705821)
,p_branch_action=>'f?p=&FLOW_ID.:211:&SESSION.'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_sequence=>99
,p_save_state_before_branch_yn=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(480393122902705559)
,p_name=>'CUENTA'
,p_is_required=>true
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(1469933284399393862)
,p_prompt=>'Banco:'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'select trim(ayaid) || '' - '' || trim(upper(aydl01)) d, trim(ayaid) r from f0030@jdedtadl where trim(aycbnk) is not null and trim(aydl01) is not null;'
,p_lov_display_null=>'YES'
,p_lov_null_text=>'Seleccione'
,p_cHeight=>1
,p_colspan=>7
,p_grid_label_column_span=>3
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(480393599922705581)
,p_name=>'FEC_DESDE'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(1469933284399393862)
,p_item_default=>'ADD_MONTHS(SYSDATE,-2)'
,p_item_default_type=>'EXPRESSION'
,p_item_default_language=>'PLSQL'
,p_format_mask=>'DD/MM/YYYY'
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(480393964054705581)
,p_name=>'FEC_HASTA'
,p_is_required=>true
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(1469933284399393862)
,p_item_default=>'ADD_MONTHS(SYSDATE,-1)'
,p_item_default_type=>'EXPRESSION'
,p_item_default_language=>'PLSQL'
,p_prompt=>'Hasta:'
,p_format_mask=>'DD/MM/YYYY'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_cMaxlength=>4000
,p_colspan=>7
,p_grid_label_column_span=>3
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(480394334705705582)
,p_name=>'ITEM_SALCUENTA'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(1469933284399393862)
,p_use_cache_before_default=>'NO'
,p_item_default=>'0'
,p_prompt=>'Saldo de Cuenta:'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT NVL(sum(GLAA/100),0)  FROM F0911@JDEDTADL ',
'WHERE GLPOST =''P'' ',
'AND GLLT=''AA'' AND  GLRE !=''V''',
'AND ROWNUM = 1',
'AND GLAID= :cuenta',
'AND GLDGJ  <= to_char(to_date(:fec_hasta, ''DD/MM/YYYY''), ''YYYYDDD'') -1900000'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_grid_label_column_span=>3
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(480394750322705582)
,p_name=>'ITEM_BANACR'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(1469933284399393862)
,p_prompt=>'Banco Acredita, Nosotros no Debitamos:'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT nvl(SUM(MPAA/100),0) FROM F5509505@JDEDTADL ',
'WHERE   MPDGJ <= to_char(to_date(:FEC_HASTA, ''DD/MM/YYYY''), ''YYYYDDD'') -1900000',
'AND MPAID =:CUENTA  AND MPAA>0 AND MPEV01<>''P'' AND MPEV02<>''1'''))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_grid_label_column_span=>3
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(480395191020705582)
,p_name=>'ITEM_BANDEB'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(1469933284399393862)
,p_prompt=>'Banco Debita, Nosotros no Acreditamos:'
,p_format_mask=>'999G999G999G999G990D00PR'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT nvl(SUM(MPAA/100),0) FROM F5509505@JDEDTADL ',
' WHERE   MPDGJ <= to_char(to_date(:FEC_HASTA, ''DD/MM/YYYY''), ''YYYYDDD'') -1900000',
'AND MPAID =:CUENTA  AND MPAA<0 AND MPEV01<>''P'' AND DECODE(MPEV01,'' '', ''1'') <>MPEV02'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_grid_label_column_span=>3
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(480395554981705584)
,p_name=>'TOTLM'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(1469933284399393862)
,p_use_cache_before_default=>'NO'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'V_VALOR_CC NUMBER :=0;',
'V_VALOR_CP  NUMBER :=0;',
'V_TOT_LM  NUMBER :=0;',
'',
'BEGIN',
'',
'',
'SELECT NVL(SUM(MPAA/100),0) INTO V_VALOR_CC FROM F5509505@JDEDTADL ',
'WHERE   MPDGJ <=F_G2JDE(:FEC_HASTA)',
'AND MPAID =:LV_CUENTA  AND MPAA>0 AND MPEV01<>''P'' AND MPEV02<>''1'';',
'',
'SELECT NVL(SUM(MPAA/100),0) INTO V_VALOR_CP FROM F5509505@JDEDTADL ',
' WHERE   MPDGJ <= F_G2JDE(:FEC_HASTA)',
'AND MPAID =:LV_CUENTA  AND MPAA<0 AND MPEV01<>''P'' AND DECODE(MPEV01,'' '', ''1'') <>MPEV02;',
'',
'',
'',
' ',
'SELECT (sum(GLAA/100) +(V_VALOR_CC))-(ABS(V_VALOR_CP)) INTO V_TOT_LM  FROM F0911@JDEDTADL ',
' WHERE GLDGJ  <= F_G2JDE(:FEC_HASTA) AND GLPOST =''P''  AND GLLT=''AA'' AND GLRE!=''V''',
'AND GLAID= :CUENTA;',
'',
'RETURN V_TOT_LM;',
'',
'END;'))
,p_source_type=>'FUNCTION_BODY'
,p_source_language=>'PLSQL'
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(480395936353705584)
,p_name=>'ITEM_BANCONO'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_imp.id(1469933284399393862)
,p_prompt=>'Nosotros Debitamos, Banco no Acredita:'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT nvl(SUM(GLAA/100),0) FROM F0911@JDEDTADL ',
'WHERE GLDGJ <= to_char(to_date(:FEC_HASTA, ''DD/MM/YYYY''), ''YYYYDDD'') -1900000',
'AND GLAA>0 AND GLLT=''AA''',
'AND GLAID =:CUENTA',
'AND GLDCT IN (''RC'',''RO'',''J#'',''JE'')',
'AND GLRCND = '' ''',
'AND GLRE !=''V'';'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_grid_label_column_span=>3
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(480396384163705584)
,p_name=>'ITEM_NODEB'
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_imp.id(1469933284399393862)
,p_prompt=>'Nosotros Acreditamos, Banco no Debita:'
,p_format_mask=>'999G999G999G999G990D00PR'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT nvl(SUM(GLAA/100),0) FROM F0911@JDEDTADL ',
'WHERE GLDGJ <= to_char(to_date(:FEC_HASTA, ''DD/MM/YYYY''), ''YYYYDDD'') -1900000',
'AND GLAID = :CUENTA',
'AND GLDCT NOT IN (''RC'',''RO'',''J#'',''RZ'',''PZ'',''MZ'',''4Z'')',
'AND GLRCND = '' ''',
'AND GLAA < 0',
'AND GLRE != ''V''',
'AND GLLT = ''AA'';'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_grid_label_column_span=>3
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(480396711978705587)
,p_name=>'ITEM_SALINI'
,p_item_sequence=>120
,p_item_plug_id=>wwv_flow_imp.id(1469933284399393862)
,p_item_default=>'0'
,p_source=>'53614.3'
,p_source_type=>'STATIC'
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(480397113676705589)
,p_name=>'TOTBN'
,p_item_sequence=>130
,p_item_plug_id=>wwv_flow_imp.id(1469933284399393862)
,p_use_cache_before_default=>'NO'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'V_VALOR_CC1 NUMBER :=0;',
'V_VALOR_CP1  NUMBER :=0;',
'V_TOT_BN  NUMBER :=0;',
'',
'BEGIN',
'',
'',
'SELECT nvl(SUM(GLAA/100),0) INTO V_VALOR_CC1 FROM F0911@JDEDTADL ',
'  WHERE GLDGJ <= to_char(to_date(:FEC_HASTA, ''DD/MM/YYYY''), ''YYYYDDD'') -1900000 AND GLAA>0 AND',
'GLAID =:CUENTA AND GLDCT IN (''RC'',''RO'',''J#'',''JE'') AND GLRCND ='' '' AND GLRE !=''V''  AND GLLT=''AA'';',
'',
'SELECT nvl(SUM(GLAA/100),0) INTO V_VALOR_CP1 FROM F0911@JDEDTADL ',
'WHERE GLDGJ <= to_char(to_date(:FEC_HASTA, ''DD/MM/YYYY''), ''YYYYDDD'') -1900000 AND',
'GLAID =:CUENTA AND  GLDCT NOT IN (''RC'',''RO'',''J#'',''RZ'',''PZ'',''MZ'',''4Z'') AND GLRCND ='' ''  AND GLAA<0 AND GLRE !=''V''  AND GLLT=''AA'';',
'',
'',
'SELECT  (SUM(MPAA/100)+V_VALOR_CC1) -(ABS(V_VALOR_CP1))  INTO V_TOT_BN   FROM F5509505@JDEDTADL ',
' WHERE MPAID =:CUENTA AND MPDGJ <= to_char(to_date(:FEC_HASTA, ''DD/MM/YYYY''), ''YYYYDDD'') -1900000 ;',
'',
'',
'RETURN V_TOT_BN;',
'',
'END;'))
,p_source_type=>'FUNCTION_BODY'
,p_source_language=>'PLSQL'
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(480397569841705589)
,p_name=>'ITEM_SDO_STO_CTA'
,p_item_sequence=>140
,p_item_plug_id=>wwv_flow_imp.id(1469933284399393862)
,p_prompt=>'(=) Saldo en Estado de Cuenta:'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'nvl(:ITEM_SALCUENTA,0) +  nvl(:ITEM_BANDEB,0) - nvl(:ITEM_BANCONO,0) - nvl(:ITEM_NODEB,0)   + nvl(:ITEM_BANACR,0)',
'FROM DUAL'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_grid_label_column_span=>3
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(480397994620705589)
,p_name=>'ITEM_SALBNC'
,p_item_sequence=>150
,p_item_plug_id=>wwv_flow_imp.id(1469933284399393862)
,p_prompt=>'Estado Cuenta Banco:'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT  nvl(SUM(MPAA/100),0) FROM F5509505@JDEDTADL ',
' WHERE MPAID =:CUENTA AND MPDGJ <= to_char(to_date(:FEC_HASTA, ''DD/MM/YYYY''), ''YYYYDDD'') -1900000;'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_grid_label_column_span=>3
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(480398323207705612)
,p_name=>'DIF'
,p_item_sequence=>160
,p_item_plug_id=>wwv_flow_imp.id(1469933284399393862)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Diferencia:'
,p_source_post_computation=>'nvl((abs(:TOTLM) - :TOTBN),0)'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_cattributes_element=>' style="color:#003e6f;font-family: arial;font-size:15px;font-weight:bold;"'
,p_grid_label_column_span=>3
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp.component_end;
end;
/
