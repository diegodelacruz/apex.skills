prompt --application/shared_components/navigation/breadcrumbs/breadcrumb
begin
--   Manifest
--     MENU: Breadcrumb
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>109
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_shared.create_menu(
 p_id=>wwv_flow_imp.id(37761271469106475)
,p_name=>'Breadcrumb'
,p_updated_on=>wwv_flow_imp.dz('20251027022403Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(24935117824070090)
,p_short_name=>'Listado de Liquidaciones por Orden de Compra'
,p_link=>'f?p=&APP_ID.:120:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>120
,p_created_on=>wwv_flow_imp.dz('20230711153637Z')
,p_updated_on=>wwv_flow_imp.dz('20230711153637Z')
,p_created_by=>'EMASABANDA'
,p_updated_by=>'EMASABANDA'
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(37761491258106476)
,p_short_name=>'Home'
,p_link=>'f?p=&APP_ID.:1:&APP_SESSION.::&DEBUG.'
,p_page_id=>1
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(38423147296497856)
,p_short_name=>unistr('Gesti\00F3n de Activos')
,p_link=>'f?p=&APP_ID.:1000:&SESSION.'
,p_page_id=>1000
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(38518473618401242)
,p_parent_id=>wwv_flow_imp.id(38423147296497856)
,p_short_name=>'Detalle de Activo Fijo'
,p_link=>'f?p=&APP_ID.:1001:&SESSION.'
,p_page_id=>1001
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(39495194166928887)
,p_short_name=>'Etiqueta Activo'
,p_link=>'f?p=&APP_ID.:1002:&SESSION.'
,p_page_id=>1002
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(39557850332417901)
,p_short_name=>unistr('Informaci\00F3n de Activo Fijo')
,p_link=>'f?p=&APP_ID.:1003:&SESSION.'
,p_page_id=>1003
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(40821155222078935)
,p_short_name=>'Valida Tipo Despedicio'
,p_link=>'f?p=&APP_ID.:177:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>177
,p_created_on=>wwv_flow_imp.dz('20250527195327Z')
,p_updated_on=>wwv_flow_imp.dz('20250527195327Z')
,p_created_by=>'DBURBANO'
,p_updated_by=>'DBURBANO'
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(42494555782630844)
,p_short_name=>'GESTION TRIBUTARIA - PRUEBA DEPARTAMENTAL'
,p_link=>'f?p=&APP_ID.:188:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>188
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(58984656849014702)
,p_short_name=>unistr('Gesti\00F3n Datos JDE')
,p_link=>'f?p=&APP_ID.:121:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>121
,p_created_on=>wwv_flow_imp.dz('20230814143039Z')
,p_updated_on=>wwv_flow_imp.dz('20230814143039Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(75141689344513987)
,p_short_name=>'Validaci&#xF3;n Pre-Orden'
,p_link=>'f?p=&APP_ID.:178:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>178
,p_created_on=>wwv_flow_imp.dz('20250619143808Z')
,p_updated_on=>wwv_flow_imp.dz('20250619143808Z')
,p_created_by=>'DBURBANO'
,p_updated_by=>'DBURBANO'
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(77950198301056331)
,p_short_name=>'Costo OP'
,p_link=>'f?p=&APP_ID.:176:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>176
,p_created_on=>wwv_flow_imp.dz('20250621152152Z')
,p_updated_on=>wwv_flow_imp.dz('20250621152152Z')
,p_created_by=>'DBURBANO'
,p_updated_by=>'DBURBANO'
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(78068663034370780)
,p_short_name=>'Detalle Costo Orden Producci&#xF3;n'
,p_link=>'f?p=&APP_ID.:1761:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>1761
,p_created_on=>wwv_flow_imp.dz('20250621214736Z')
,p_updated_on=>wwv_flow_imp.dz('20250621214736Z')
,p_created_by=>'DBURBANO'
,p_updated_by=>'DBURBANO'
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(110051514583071401)
,p_short_name=>'Revisi&#xF3;n fechas transacci&#xF3;n reportes de producci&#xF3;n'
,p_link=>'f?p=&APP_ID.:179:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>179
,p_created_on=>wwv_flow_imp.dz('20250718195855Z')
,p_updated_on=>wwv_flow_imp.dz('20250718195855Z')
,p_created_by=>'DBURBANO'
,p_updated_by=>'DBURBANO'
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(110208552150494452)
,p_short_name=>'Modifica fecha Transacci&#xF3;n'
,p_link=>'f?p=&APP_ID.:1791:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>1791
,p_created_on=>wwv_flow_imp.dz('20250718210925Z')
,p_updated_on=>wwv_flow_imp.dz('20250718210925Z')
,p_created_by=>'DBURBANO'
,p_updated_by=>'DBURBANO'
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(116354638722393461)
,p_short_name=>'Valida Coherencia M&#xE9;todo de Costo'
,p_link=>'f?p=&APP_ID.:180:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>180
,p_created_on=>wwv_flow_imp.dz('20250724154555Z')
,p_updated_on=>wwv_flow_imp.dz('20250724154555Z')
,p_created_by=>'DBURBANO'
,p_updated_by=>'DBURBANO'
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(123593435757440278)
,p_short_name=>'M&#xE9;todo Costo'
,p_link=>'f?p=&APP_ID.:201:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>201
,p_created_on=>wwv_flow_imp.dz('20250730215344Z')
,p_updated_on=>wwv_flow_imp.dz('20250730215344Z')
,p_created_by=>'DBURBANO'
,p_updated_by=>'DBURBANO'
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(169269623380318675)
,p_short_name=>'Conteo Activo Fijo'
,p_link=>'f?p=&APP_ID.:1005:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>1005
,p_created_on=>wwv_flow_imp.dz('20231211194042Z')
,p_updated_on=>wwv_flow_imp.dz('20231211194042Z')
,p_created_by=>'MALBAN'
,p_updated_by=>'MALBAN'
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(178159029216618024)
,p_short_name=>'Detalle Activos Fijos'
,p_link=>'f?p=&APP_ID.:1006:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>1006
,p_created_on=>wwv_flow_imp.dz('20231220182355Z')
,p_updated_on=>wwv_flow_imp.dz('20231220182355Z')
,p_created_by=>'MALBAN'
,p_updated_by=>'MALBAN'
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(230297060085580566)
,p_short_name=>'GESTION TRIBUTARIA - REPORTE AREAS FISCALES'
,p_link=>'f?p=&APP_ID.:199:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>199
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(263837030946395913)
,p_short_name=>'Producto Terminado'
,p_link=>'f?p=&APP_ID.:502221:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>502221
,p_created_on=>wwv_flow_imp.dz('20240321152302Z')
,p_updated_on=>wwv_flow_imp.dz('20240321152302Z')
,p_created_by=>'CVACA'
,p_updated_by=>'CVACA'
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(338255859477422871)
,p_short_name=>'Solicitud de Bloqueo de Pagos'
,p_link=>'f?p=&APP_ID.:111:&SESSION.'
,p_page_id=>111
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(338327006109934364)
,p_short_name=>'Mesa de Trabajo'
,p_link=>'f?p=&APP_ID.:100:&SESSION.'
,p_page_id=>100
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(339856185885024443)
,p_short_name=>'Reporte de Pagos Retenidos'
,p_link=>'f?p=&APP_ID.:115:&SESSION.'
,p_page_id=>115
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(339963213188256339)
,p_short_name=>'Solicitud Desbloqueo de Pagos'
,p_link=>'f?p=&APP_ID.:112:&SESSION.'
,p_page_id=>112
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(340006512229886092)
,p_short_name=>unistr('Aprobaci\00F3n Desbloqueo de Pago')
,p_link=>'f?p=&APP_ID.:116:&SESSION.'
,p_page_id=>116
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(343693317014323770)
,p_short_name=>unistr('Revisi\00F3n de Requisiciones')
,p_link=>'f?p=&APP_ID.:2001:&SESSION.'
,p_page_id=>2001
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(348860049697811767)
,p_parent_id=>wwv_flow_imp.id(38423147296497856)
,p_short_name=>'Validaci&#xF3;n de Activos Fijos'
,p_link=>'f?p=&APP_ID.:1004:&SESSION.'
,p_page_id=>1004
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(350296030278527464)
,p_short_name=>'Costeo'
,p_link=>'f?p=&APP_ID.:1100:&SESSION.'
,p_page_id=>1100
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(350360133100000262)
,p_parent_id=>wwv_flow_imp.id(350296030278527464)
,p_short_name=>'Registro de Tasas'
,p_link=>'f?p=&APP_ID.:1102:&SESSION.'
,p_page_id=>1102
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(365089603569561017)
,p_parent_id=>wwv_flow_imp.id(350296030278527464)
,p_short_name=>unistr('Aprobaci\00F3n de Est\00E1ndares de Manufactura')
,p_link=>'f?p=&APP_ID.:1104:&SESSION.'
,p_page_id=>1104
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(368616483124592415)
,p_short_name=>'MP Cierre de orden'
,p_link=>'f?p=&APP_ID.:500:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>500
,p_created_on=>wwv_flow_imp.dz('20240703181306Z')
,p_updated_on=>wwv_flow_imp.dz('20240703181306Z')
,p_created_by=>'MALBAN'
,p_updated_by=>'MALBAN'
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(398225196311041601)
,p_short_name=>'Envases - Costo Capital'
,p_link=>'f?p=&APP_ID.:125:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>125
,p_created_on=>wwv_flow_imp.dz('20240801214042Z')
,p_updated_on=>wwv_flow_imp.dz('20240801214042Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(445022427698447408)
,p_short_name=>unistr('Variaci\00F3n STD')
,p_link=>'f?p=&APP_ID.:510:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>510
,p_created_on=>wwv_flow_imp.dz('20240917194820Z')
,p_updated_on=>wwv_flow_imp.dz('20240917194820Z')
,p_created_by=>'MALBAN'
,p_updated_by=>'MALBAN'
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(479209766625095926)
,p_short_name=>'Carga Estado de Cuenta'
,p_link=>'f?p=&APP_ID.:210:&SESSION.'
,p_page_id=>210
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(480281488399613367)
,p_short_name=>unistr('Conciliaci\00F3n Manual')
,p_link=>'f?p=&APP_ID.:212:&SESSION.'
,p_page_id=>212
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(480410597843705814)
,p_short_name=>unistr('Reporte de Conciliaci\00F3n Bancaria')
,p_link=>'f?p=&APP_ID.:211:&SESSION.'
,p_page_id=>211
);
wwv_flow_imp.component_end;
end;
/
