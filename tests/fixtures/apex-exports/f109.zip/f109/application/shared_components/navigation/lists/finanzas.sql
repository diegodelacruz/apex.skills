prompt --application/shared_components/navigation/lists/finanzas
begin
--   Manifest
--     LIST: Finanzas
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>109
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(38387485495133968)
,p_name=>'Finanzas'
,p_list_type=>'SQL_QUERY'
,p_list_query=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select 1 NIVEL, (SELECT DESCRIPCION FROM T_ADMI_COMPANIA WHERE CODIGO=:G_COMPANIA) LABEL, ''#'' TARGET, '''' IS_CURRENT, ''-'' ICONOCSS from dual ',
'union all',
'select * from (SELECT NIVEL, OPCIONMENU label, ',
'      DECODE(RUTAPAGINA ,NULL,''#'',RUTA||'':''||:APP_SESSION||''::NO:RP,''||RUTAPAGINA) target,',
'       NULL is_current, ''fa''||'' ''||iconocss',
'FROM (SELECT DISTINCT NIVEL, OPCIONMENU , RUTAPAGINA ,RUTA, iconocss, CODIGOPAGINA,codigopadre, ORDEN',
'from DATA.VT_CORP_PAGINAS WHERE  CODIGOUSUARIO=:APP_USER AND GRUPO=''APEX'' AND OBJETO IS NULL AND ',
'CODIGO_TG IS NULL AND  CODIGOCOMPANIA=:G_COMPANIA)',
'  START WITH codigopadre is null',
'       CONNECT BY PRIOR CODIGOPAGINA=codigopadre  ',
'          -- and PRIOR CODIGOUSUARIO=:APP_USER AND ',
'-- PRIOR CODIGOCOMPANIA=:G_COMPANIA AND ',
'--PRIOR GRUPO=''APEX''',
'--AND PRIOR OBJETO IS NULL AND PRIOR  CODIGO_TG IS NULL',
'ORDER SIBLINGS BY ORDEN);'))
,p_list_status=>'PUBLIC'
,p_version_scn=>116621131373
,p_updated_on=>wwv_flow_imp.dz('20251027022403Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(24934295785070080)
,p_list_item_display_sequence=>10
,p_list_item_link_text=>'Listado de Liquidaciones por Orden de Compra'
,p_list_item_link_target=>'f?p=&APP_ID.:120:&APP_SESSION.::&DEBUG.:::'
,p_list_item_icon=>'fa-file-o'
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'120'
,p_created_on=>wwv_flow_imp.dz('20230711153637Z')
,p_updated_on=>wwv_flow_imp.dz('20230711153637Z')
,p_created_by=>'EMASABANDA'
,p_updated_by=>'EMASABANDA'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(58983835934014672)
,p_list_item_display_sequence=>20
,p_list_item_link_text=>unistr('Gesti\00F3n Datos JDE')
,p_list_item_link_target=>'f?p=&APP_ID.:121:&APP_SESSION.::&DEBUG.:::'
,p_list_item_icon=>'fa-file-o'
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'121'
,p_created_on=>wwv_flow_imp.dz('20230814143038Z')
,p_updated_on=>wwv_flow_imp.dz('20230814143038Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(169268725465318667)
,p_list_item_display_sequence=>30
,p_list_item_link_text=>'Conteo Activo Fijo'
,p_list_item_link_target=>'f?p=&APP_ID.:1005:&APP_SESSION.::&DEBUG.:::'
,p_list_item_icon=>'fa-file-o'
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'1005'
,p_created_on=>wwv_flow_imp.dz('20231211194042Z')
,p_updated_on=>wwv_flow_imp.dz('20231211194042Z')
,p_created_by=>'MALBAN'
,p_updated_by=>'MALBAN'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(178158156440618008)
,p_list_item_display_sequence=>40
,p_list_item_link_text=>'Detalle Activos Fijos'
,p_list_item_link_target=>'f?p=&APP_ID.:1006:&APP_SESSION.::&DEBUG.:::'
,p_list_item_icon=>'fa-file-o'
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'1006'
,p_created_on=>wwv_flow_imp.dz('20231220182355Z')
,p_updated_on=>wwv_flow_imp.dz('20231220182355Z')
,p_created_by=>'MALBAN'
,p_updated_by=>'MALBAN'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(368615697859592402)
,p_list_item_display_sequence=>50
,p_list_item_link_text=>'MP Cierre de orden'
,p_list_item_link_target=>'f?p=&APP_ID.:500:&APP_SESSION.::&DEBUG.:::'
,p_list_item_icon=>'fa-file-o'
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'500'
,p_created_on=>wwv_flow_imp.dz('20240703181305Z')
,p_updated_on=>wwv_flow_imp.dz('20240703181305Z')
,p_created_by=>'MALBAN'
,p_updated_by=>'MALBAN'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(398224200226041591)
,p_list_item_display_sequence=>60
,p_list_item_link_text=>'Envases - Costo Capital'
,p_list_item_link_target=>'f?p=&APP_ID.:125:&APP_SESSION.::&DEBUG.:::'
,p_list_item_icon=>'fa-file-o'
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'125'
,p_created_on=>wwv_flow_imp.dz('20240801214042Z')
,p_updated_on=>wwv_flow_imp.dz('20240801214042Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(445021555435447391)
,p_list_item_display_sequence=>70
,p_list_item_link_text=>unistr('Variaci\00F3n STD')
,p_list_item_link_target=>'f?p=&APP_ID.:510:&APP_SESSION.::&DEBUG.:::'
,p_list_item_icon=>'fa-file-o'
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'510'
,p_created_on=>wwv_flow_imp.dz('20240917194820Z')
,p_updated_on=>wwv_flow_imp.dz('20240917194820Z')
,p_created_by=>'MALBAN'
,p_updated_by=>'MALBAN'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(40820204083078920)
,p_list_item_display_sequence=>80
,p_list_item_link_text=>'Valida Tipo Despedicio'
,p_list_item_link_target=>'f?p=&APP_ID.:177:&APP_SESSION.::&DEBUG.:::'
,p_list_item_icon=>'fa-table-pointer'
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'177'
,p_created_on=>wwv_flow_imp.dz('20250527195327Z')
,p_updated_on=>wwv_flow_imp.dz('20250527195327Z')
,p_created_by=>'DBURBANO'
,p_updated_by=>'DBURBANO'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(75140717295513960)
,p_list_item_display_sequence=>90
,p_list_item_link_text=>unistr('Validaci\00F3n Pre-Orden')
,p_list_item_link_target=>'f?p=&APP_ID.:178:&APP_SESSION.::&DEBUG.:::'
,p_list_item_icon=>'fa-table-pointer'
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'178'
,p_created_on=>wwv_flow_imp.dz('20250619143808Z')
,p_updated_on=>wwv_flow_imp.dz('20250619143808Z')
,p_created_by=>'DBURBANO'
,p_updated_by=>'DBURBANO'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(77949214161056315)
,p_list_item_display_sequence=>100
,p_list_item_link_text=>'Costo OP'
,p_list_item_link_target=>'f?p=&APP_ID.:176:&APP_SESSION.::&DEBUG.:::'
,p_list_item_icon=>'fa-table-pointer'
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'176'
,p_created_on=>wwv_flow_imp.dz('20250621152152Z')
,p_updated_on=>wwv_flow_imp.dz('20250621152152Z')
,p_created_by=>'DBURBANO'
,p_updated_by=>'DBURBANO'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(78067779299370773)
,p_list_item_display_sequence=>110
,p_list_item_link_text=>unistr('Detalle Costo Orden Producci\00F3n')
,p_list_item_link_target=>'f?p=&APP_ID.:1761:&APP_SESSION.::&DEBUG.:::'
,p_list_item_icon=>'fa-table'
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'1761'
,p_created_on=>wwv_flow_imp.dz('20250621214736Z')
,p_updated_on=>wwv_flow_imp.dz('20250621214736Z')
,p_created_by=>'DBURBANO'
,p_updated_by=>'DBURBANO'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(110050432979071364)
,p_list_item_display_sequence=>120
,p_list_item_link_text=>unistr('Revisi\00F3n fechas transacci\00F3n reportes de producci\00F3n')
,p_list_item_link_target=>'f?p=&APP_ID.:179:&APP_SESSION.::&DEBUG.:::'
,p_list_item_icon=>'fa-table'
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'179'
,p_created_on=>wwv_flow_imp.dz('20250718195855Z')
,p_updated_on=>wwv_flow_imp.dz('20250718195855Z')
,p_created_by=>'DBURBANO'
,p_updated_by=>'DBURBANO'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(110207650300494450)
,p_list_item_display_sequence=>130
,p_list_item_link_text=>unistr('Modifica fecha Transacci\00F3n')
,p_list_item_link_target=>'f?p=&APP_ID.:1791:&APP_SESSION.::&DEBUG.:::'
,p_list_item_icon=>'fa-table-pointer'
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'1791'
,p_created_on=>wwv_flow_imp.dz('20250718210925Z')
,p_updated_on=>wwv_flow_imp.dz('20250718210925Z')
,p_created_by=>'DBURBANO'
,p_updated_by=>'DBURBANO'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(116353709376393438)
,p_list_item_display_sequence=>140
,p_list_item_link_text=>unistr('Valida Coherencia M\00E9todo de Costo')
,p_list_item_link_target=>'f?p=&APP_ID.:180:&APP_SESSION.::&DEBUG.:::'
,p_list_item_icon=>'fa-table-pointer'
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'180'
,p_created_on=>wwv_flow_imp.dz('20250724154555Z')
,p_updated_on=>wwv_flow_imp.dz('20250724154555Z')
,p_created_by=>'DBURBANO'
,p_updated_by=>'DBURBANO'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(123592618134440257)
,p_list_item_display_sequence=>150
,p_list_item_link_text=>unistr('M\00E9todo Costo')
,p_list_item_link_target=>'f?p=&APP_ID.:201:&APP_SESSION.::&DEBUG.:::'
,p_list_item_icon=>'fa-table-pointer'
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'201'
,p_created_on=>wwv_flow_imp.dz('20250730215344Z')
,p_updated_on=>wwv_flow_imp.dz('20250730215344Z')
,p_created_by=>'DBURBANO'
,p_updated_by=>'DBURBANO'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(230296106606580550)
,p_list_item_display_sequence=>160
,p_list_item_link_text=>'GESTION TRIBUTARIA - REPORTE AREAS FISCALES'
,p_list_item_link_target=>'f?p=&APP_ID.:199:&APP_SESSION.::&DEBUG.:::'
,p_list_item_icon=>'fa-table'
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'199'
,p_created_on=>wwv_flow_imp.dz('20251027022403Z')
,p_updated_on=>wwv_flow_imp.dz('20251027022403Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp.component_end;
end;
/
