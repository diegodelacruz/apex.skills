prompt --application/shared_components/logic/application_items/g_navegadortabs
begin
--   Manifest
--     APPLICATION ITEM: G_NAVEGADORTABS
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>109
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_shared.create_flow_item(
 p_id=>wwv_flow_imp.id(398136361592758225)
,p_name=>'G_NAVEGADORTABS'
,p_scope=>'GLOBAL'
,p_protection_level=>'N'
,p_version_scn=>1
,p_created_on=>wwv_flow_imp.dz('20240801205328Z')
,p_updated_on=>wwv_flow_imp.dz('20240801205328Z')
,p_created_by=>'MALBAN'
,p_updated_by=>'MALBAN'
);
wwv_flow_imp.component_end;
end;
/
