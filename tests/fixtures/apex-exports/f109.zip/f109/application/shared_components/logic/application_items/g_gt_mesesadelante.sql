prompt --application/shared_components/logic/application_items/g_gt_mesesadelante
begin
--   Manifest
--     APPLICATION ITEM: G_GT_MESESADELANTE
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>109
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_shared.create_flow_item(
 p_id=>wwv_flow_imp.id(540115069426625183)
,p_name=>'G_GT_MESESADELANTE'
,p_protection_level=>'N'
,p_version_scn=>1
);
wwv_flow_imp.component_end;
end;
/
