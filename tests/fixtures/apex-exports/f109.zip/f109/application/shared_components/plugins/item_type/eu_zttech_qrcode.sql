prompt --application/shared_components/plugins/item_type/eu_zttech_qrcode
begin
--   Manifest
--     PLUGIN: EU.ZTTECH.QRCODE
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>109
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_shared.create_plugin(
 p_id=>wwv_flow_imp.id(42424972768745286)
,p_plugin_type=>'ITEM TYPE'
,p_name=>'EU.ZTTECH.QRCODE'
,p_display_name=>'QR Code'
,p_supported_component_types=>'APEX_APPLICATION_PAGE_ITEMS:APEX_APPL_PAGE_IG_COLUMNS'
,p_image_prefix => nvl(wwv_flow_application_install.get_static_plugin_file_prefix('ITEM TYPE','EU.ZTTECH.QRCODE'),'')
,p_plsql_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'PROCEDURE render_qrcode(',
'    p_item                IN apex_plugin.t_item,',
'    p_plugin              IN apex_plugin.t_plugin,',
'    p_param               IN apex_plugin.t_item_render_param,',
'    p_result              OUT apex_plugin.t_item_render_result) IS',
'    ',
'BEGIN',
'    if p_param.value is null then',
'        htp.p(''no data'');',
'    else',
'',
'        -- Printer Friendly Display',
'        IF p_param.is_printer_friendly THEN',
'            apex_plugin_util.print_display_only(p_item_name        => p_item.name,',
'                                                p_display_value    => p_param.value,',
'                                                p_show_line_breaks => FALSE,',
'                                                p_escape           => TRUE,',
'                                                p_attributes       => p_item.element_attributes);',
'        -- Read Only Display',
'        ELSIF p_param.is_readonly THEN',
'            apex_plugin_util.print_hidden_if_readonly(p_item_name           => p_item.name,',
'                                                      p_value               => p_param.value,',
'                                                      p_is_readonly         => p_param.is_readonly,',
'                                                      p_is_printer_friendly => p_param.is_printer_friendly);',
'',
'        -- Normal Display',
'        ELSE',
'            if p_item.attribute_02 = ''HTML'' then',
'                pk_codigoqr.p_qr_as_html_table(',
'                    p_data => p_param.value,',
'                    p_error_correction => p_item.attribute_01,',
'                    p_module_size_in_px => p_item.attribute_03,',
'                    p_margines => (CASE WHEN p_item.attribute_05 = ''Y'' THEN true ELSE false END)',
'                );',
'            elsif p_item.attribute_02 = ''BMP'' then',
'                pk_codigoqr.p_qr_as_img_tag_base64(',
'                    p_data => p_param.value,',
'                    p_error_correction => p_item.attribute_01,',
'                    p_image_size_px => p_item.attribute_04,',
'                    p_margines => p_item.attribute_05',
'                );',
'            else',
'                htp.prn(''Error - unsupported display type.'');',
'            end if;',
'            ',
'        end if;',
'        ',
'    end if;',
'',
'    p_result.is_navigable := false;',
'    ',
'END render_qrcode;'))
,p_api_version=>2
,p_render_function=>'render_qrcode'
,p_standard_attributes=>'VISIBLE:FORM_ELEMENT:SESSION_STATE:SOURCE'
,p_substitute_attributes=>true
,p_version_scn=>1
,p_subscribe_plugin_settings=>true
,p_help_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'QR plugin version 1.0.0',
'Usage and details on GitHub',
'https://github.com/zorantica/plsql-qr-code'))
,p_version_identifier=>'1.0.0.0'
,p_about_url=>'https://github.com/zorantica/plsql-qr-code'
);
wwv_flow_imp_shared.create_plugin_attribute(
 p_id=>wwv_flow_imp.id(42453296792573305)
,p_plugin_id=>wwv_flow_imp.id(42424972768745286)
,p_attribute_scope=>'COMPONENT'
,p_attribute_sequence=>1
,p_display_sequence=>10
,p_prompt=>'Error correction level'
,p_attribute_type=>'SELECT LIST'
,p_is_required=>true
,p_default_value=>'L'
,p_supported_component_types=>'APEX_APPLICATION_PAGE_ITEMS:APEX_APPL_PAGE_IG_COLUMNS'
,p_is_translatable=>false
,p_lov_type=>'STATIC'
);
wwv_flow_imp_shared.create_plugin_attr_value(
 p_id=>wwv_flow_imp.id(42453874055575071)
,p_plugin_attribute_id=>wwv_flow_imp.id(42453296792573305)
,p_display_sequence=>10
,p_display_value=>'L - Low (7% of data)'
,p_return_value=>'L'
);
wwv_flow_imp_shared.create_plugin_attr_value(
 p_id=>wwv_flow_imp.id(42454240083577490)
,p_plugin_attribute_id=>wwv_flow_imp.id(42453296792573305)
,p_display_sequence=>20
,p_display_value=>'M - Medium (15% of data)'
,p_return_value=>'M'
);
wwv_flow_imp_shared.create_plugin_attr_value(
 p_id=>wwv_flow_imp.id(42454688568579344)
,p_plugin_attribute_id=>wwv_flow_imp.id(42453296792573305)
,p_display_sequence=>30
,p_display_value=>'Q - Quartile (25% of data)'
,p_return_value=>'Q'
);
wwv_flow_imp_shared.create_plugin_attr_value(
 p_id=>wwv_flow_imp.id(42455054433580230)
,p_plugin_attribute_id=>wwv_flow_imp.id(42453296792573305)
,p_display_sequence=>40
,p_display_value=>'H - High (30% of data)'
,p_return_value=>'H'
);
wwv_flow_imp_shared.create_plugin_attribute(
 p_id=>wwv_flow_imp.id(42461751282179962)
,p_plugin_id=>wwv_flow_imp.id(42424972768745286)
,p_attribute_scope=>'COMPONENT'
,p_attribute_sequence=>2
,p_display_sequence=>20
,p_prompt=>'Display Type'
,p_attribute_type=>'SELECT LIST'
,p_is_required=>true
,p_default_value=>'HTML'
,p_supported_component_types=>'APEX_APPLICATION_PAGE_ITEMS:APEX_APPL_PAGE_IG_COLUMNS'
,p_is_translatable=>false
,p_lov_type=>'STATIC'
);
wwv_flow_imp_shared.create_plugin_attr_value(
 p_id=>wwv_flow_imp.id(42462338325181383)
,p_plugin_attribute_id=>wwv_flow_imp.id(42461751282179962)
,p_display_sequence=>10
,p_display_value=>'HTML Table'
,p_return_value=>'HTML'
);
wwv_flow_imp_shared.create_plugin_attr_value(
 p_id=>wwv_flow_imp.id(42462713504183023)
,p_plugin_attribute_id=>wwv_flow_imp.id(42461751282179962)
,p_display_sequence=>20
,p_display_value=>'BMP Image'
,p_return_value=>'BMP'
);
wwv_flow_imp_shared.create_plugin_attribute(
 p_id=>wwv_flow_imp.id(42464552681214083)
,p_plugin_id=>wwv_flow_imp.id(42424972768745286)
,p_attribute_scope=>'COMPONENT'
,p_attribute_sequence=>3
,p_display_sequence=>30
,p_prompt=>'Module size'
,p_attribute_type=>'NUMBER'
,p_is_required=>true
,p_default_value=>'8'
,p_display_length=>5
,p_max_length=>2
,p_unit=>'pixels'
,p_supported_component_types=>'APEX_APPLICATION_PAGE_ITEMS:APEX_APPL_PAGE_IG_COLUMNS'
,p_is_translatable=>false
,p_depending_on_attribute_id=>wwv_flow_imp.id(42461751282179962)
,p_depending_on_has_to_exist=>true
,p_depending_on_condition_type=>'EQUALS'
,p_depending_on_expression=>'HTML'
);
wwv_flow_imp_shared.create_plugin_attribute(
 p_id=>wwv_flow_imp.id(42465941339230936)
,p_plugin_id=>wwv_flow_imp.id(42424972768745286)
,p_attribute_scope=>'COMPONENT'
,p_attribute_sequence=>4
,p_display_sequence=>40
,p_prompt=>'Image size'
,p_attribute_type=>'NUMBER'
,p_is_required=>true
,p_display_length=>5
,p_max_length=>4
,p_unit=>'pixels'
,p_is_translatable=>false
,p_depending_on_attribute_id=>wwv_flow_imp.id(42461751282179962)
,p_depending_on_has_to_exist=>true
,p_depending_on_condition_type=>'EQUALS'
,p_depending_on_expression=>'BMP'
);
wwv_flow_imp_shared.create_plugin_attribute(
 p_id=>wwv_flow_imp.id(42466516726234684)
,p_plugin_id=>wwv_flow_imp.id(42424972768745286)
,p_attribute_scope=>'COMPONENT'
,p_attribute_sequence=>5
,p_display_sequence=>50
,p_prompt=>'Margines'
,p_attribute_type=>'CHECKBOX'
,p_is_required=>true
,p_default_value=>'N'
,p_supported_component_types=>'APEX_APPLICATION_PAGE_ITEMS:APEX_APPL_PAGE_IG_COLUMNS'
,p_is_translatable=>false
);
end;
/
begin
wwv_flow_imp.component_end;
end;
/
