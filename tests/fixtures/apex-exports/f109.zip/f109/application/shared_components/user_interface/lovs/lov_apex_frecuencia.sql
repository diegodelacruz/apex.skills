prompt --application/shared_components/user_interface/lovs/lov_apex_frecuencia
begin
--   Manifest
--      LOV_APEX_FRECUENCIA
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>109
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(341489306372633407)
,p_lov_name=>' LOV_APEX_FRECUENCIA'
,p_lov_query=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select valor codigo, descripcion, valor2 codaumento, to_number(valor3) valaumento ',
'from data.t_corp_udc  where id_cabecera = ''APEX'' and id_tabla = ''FRECUENCIA''',
'order by valor2,to_number(valor3)'))
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_return_column_name=>'CODIGO'
,p_display_column_name=>'DESCRIPCION'
,p_version_scn=>120833281726
,p_created_on=>wwv_flow_imp.dz('20260203045939Z')
,p_updated_on=>wwv_flow_imp.dz('20260203045939Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp.component_end;
end;
/
