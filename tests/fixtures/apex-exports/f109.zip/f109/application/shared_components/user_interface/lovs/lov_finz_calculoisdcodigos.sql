prompt --application/shared_components/user_interface/lovs/lov_finz_calculoisdcodigos
begin
--   Manifest
--     LOV_FINZ_CALCULOISDCODIGOS
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>109
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(214708572085569954)
,p_lov_name=>'LOV_FINZ_CALCULOISDCODIGOS'
,p_lov_query=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ID_TABLA, DESCRIPCION, VALOR, VIGENCIADESDE, VIGENCIAHASTA',
'  from T_CORP_UDC',
' where ID_CABECERA=''FINZ_VISD'' and id_tabla!=''S/N'' ORDER BY ID_TABLA,DESCRIPCION',
' '))
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_return_column_name=>'ID_TABLA'
,p_display_column_name=>'DESCRIPCION'
,p_group_sort_direction=>'ASC'
,p_default_sort_direction=>'ASC'
,p_version_scn=>123479420172
);
wwv_flow_imp_shared.create_list_of_values_cols(
 p_id=>wwv_flow_imp.id(214709089870576595)
,p_query_column_name=>'ID_TABLA'
,p_heading=>unistr('C\00F3digo')
,p_display_sequence=>10
,p_data_type=>'VARCHAR2'
,p_is_visible=>'N'
,p_is_searchable=>'N'
);
wwv_flow_imp_shared.create_list_of_values_cols(
 p_id=>wwv_flow_imp.id(214709428712576596)
,p_query_column_name=>'DESCRIPCION'
,p_heading=>unistr('Descripci\00F3n')
,p_display_sequence=>20
,p_data_type=>'VARCHAR2'
);
wwv_flow_imp_shared.create_list_of_values_cols(
 p_id=>wwv_flow_imp.id(214709862444576596)
,p_query_column_name=>'VALOR'
,p_heading=>'Porcentaje'
,p_display_sequence=>30
,p_data_type=>'VARCHAR2'
);
wwv_flow_imp_shared.create_list_of_values_cols(
 p_id=>wwv_flow_imp.id(214710216616576596)
,p_query_column_name=>'VIGENCIADESDE'
,p_heading=>'Vig. Desde'
,p_display_sequence=>40
,p_data_type=>'DATE'
);
wwv_flow_imp_shared.create_list_of_values_cols(
 p_id=>wwv_flow_imp.id(214710620916576596)
,p_query_column_name=>'VIGENCIAHASTA'
,p_heading=>'Vig.  Hasta'
,p_display_sequence=>50
,p_data_type=>'DATE'
);
wwv_flow_imp.component_end;
end;
/
