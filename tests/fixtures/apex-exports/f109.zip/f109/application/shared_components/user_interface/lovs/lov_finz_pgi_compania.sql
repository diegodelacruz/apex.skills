prompt --application/shared_components/user_interface/lovs/lov_finz_pgi_compania
begin
--   Manifest
--     LOV_FINZ_PGI_COMPANIA
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>109
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(152989705504933707)
,p_lov_name=>'LOV_FINZ_PGI_COMPANIA'
,p_lov_query=>wwv_flow_string.join(wwv_flow_t_varchar2(
'      SELECT DESCRIPCION, ID_TABLA IDCOMPANIA',
'FROM t_corp_udc ',
'where id_cabecera=''COMP_CGZCM'' ',
'and ID_TABLA!=''00000'' ',
'/*and ACTIVO=''1''*/',
'order by ID_TABLA;'))
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_return_column_name=>'IDCOMPANIA'
,p_display_column_name=>'DESCRIPCION'
,p_version_scn=>119549157107
);
wwv_flow_imp.component_end;
end;
/
