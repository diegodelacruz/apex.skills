prompt --application/shared_components/user_interface/lovs/lov_finz_gtperiodos
begin
--   Manifest
--     LOV_FINZ_GTPERIODOS
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>109
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(540091265122236224)
,p_lov_name=>'LOV_FINZ_GTPERIODOS'
,p_lov_query=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT  ',
'    TO_CHAR(ADD_MONTHS(TRUNC(ADD_MONTHS(SYSDATE,NVL(:G_GT_MESESADELANTE,1)), ''MM''), -LEVEL + 1), ''Month YYYY'', ''NLS_DATE_LANGUAGE=SPANISH'') AS mes_nombre,',
'    TO_CHAR(ADD_MONTHS(TRUNC(ADD_MONTHS(SYSDATE,NVL(:G_GT_MESESADELANTE,1)), ''MM''), -LEVEL + 1), ''YYYYMM'') AS mes_valor',
'FROM DUAL',
'CONNECT BY LEVEL <= NVL(:G_GT_MESESTRAS+:G_GT_MESESADELANTE,1);'))
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_use_local_sync_table=>false
,p_return_column_name=>'MES_VALOR'
,p_display_column_name=>'MES_NOMBRE'
,p_group_sort_direction=>'ASC'
,p_default_sort_direction=>'ASC'
,p_version_scn=>1
);
wwv_flow_imp.component_end;
end;
/
