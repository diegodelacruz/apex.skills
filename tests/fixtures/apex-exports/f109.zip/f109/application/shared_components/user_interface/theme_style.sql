prompt --application/shared_components/user_interface/theme_style
begin
--   Manifest
--     THEME STYLE: 109
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>109
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_shared.create_theme_style(
 p_id=>wwv_flow_imp.id(483090947023065517)
,p_theme_id=>42
,p_name=>'Quality Styles'
,p_css_file_urls=>wwv_flow_string.join(wwv_flow_t_varchar2(
'#THEME_IMAGES#css/Vista#MIN#.css?v=#APEX_VERSION#',
'#THEME_DB_IMAGES#css/zaimella.css'))
,p_is_current=>true
,p_is_public=>true
,p_is_accessible=>true
,p_theme_roller_read_only=>false
,p_reference_id=>367791006966361435
);
wwv_flow_imp_shared.create_theme_style(
 p_id=>wwv_flow_imp.id(483091339819065517)
,p_theme_id=>42
,p_name=>'Vista'
,p_css_file_urls=>'#THEME_IMAGES#css/Vista#MIN#.css?v=#APEX_VERSION#'
,p_is_current=>false
,p_is_public=>true
,p_is_accessible=>true
,p_theme_roller_read_only=>true
,p_reference_id=>48413211054022020
);
wwv_flow_imp_shared.create_theme_style(
 p_id=>wwv_flow_imp.id(483091781728065517)
,p_theme_id=>42
,p_name=>'Vita'
,p_is_current=>false
,p_is_public=>true
,p_is_accessible=>true
,p_theme_roller_input_file_urls=>'#THEME_IMAGES#less/theme/Vita.less'
,p_theme_roller_output_file_url=>'#THEME_IMAGES#css/Vita#MIN#.css?v=#APEX_VERSION#'
,p_theme_roller_read_only=>true
,p_reference_id=>48413640797022021
);
wwv_flow_imp_shared.create_theme_style(
 p_id=>wwv_flow_imp.id(483092179618065517)
,p_theme_id=>42
,p_name=>'Vita - Dark'
,p_is_current=>false
,p_is_public=>true
,p_is_accessible=>false
,p_theme_roller_input_file_urls=>'#THEME_IMAGES#less/theme/Vita-Dark.less'
,p_theme_roller_output_file_url=>'#THEME_IMAGES#css/Vita-Dark#MIN#.css?v=#APEX_VERSION#'
,p_theme_roller_read_only=>true
,p_reference_id=>48414098990022021
);
wwv_flow_imp_shared.create_theme_style(
 p_id=>wwv_flow_imp.id(483092434023065557)
,p_theme_id=>42
,p_name=>'Vita - Red'
,p_is_current=>false
,p_is_public=>true
,p_is_accessible=>false
,p_theme_roller_input_file_urls=>'#THEME_IMAGES#less/theme/Vita-Red.less'
,p_theme_roller_output_file_url=>'#THEME_IMAGES#css/Vita-Red#MIN#.css?v=#APEX_VERSION#'
,p_theme_roller_read_only=>true
,p_reference_id=>48414403692022021
);
wwv_flow_imp_shared.create_theme_style(
 p_id=>wwv_flow_imp.id(483092851893065557)
,p_theme_id=>42
,p_name=>'Vita - Slate'
,p_is_current=>false
,p_is_public=>true
,p_is_accessible=>false
,p_theme_roller_input_file_urls=>'#THEME_IMAGES#less/theme/Vita-Slate.less'
,p_theme_roller_config=>'{"customCSS":"","vars":{"@g_Accent-BG":"#505f6d","@g_Accent-OG":"#ececec","@g_Body-Title-BG":"#dee1e4","@l_Link-Base":"#337ac0","@g_Body-BG":"#f5f5f5"}}'
,p_theme_roller_output_file_url=>'#THEME_IMAGES#css/Vita-Slate#MIN#.css?v=#APEX_VERSION#'
,p_theme_roller_read_only=>true
,p_reference_id=>48414812873022021
);
wwv_flow_imp_shared.create_theme_style(
 p_id=>wwv_flow_imp.id(483093230742065557)
,p_theme_id=>42
,p_name=>'Zaimella Styles'
,p_css_file_urls=>wwv_flow_string.join(wwv_flow_t_varchar2(
'#THEME_IMAGES#css/Vista#MIN#.css?v=#APEX_VERSION#',
'#THEME_DB_IMAGES#css/zaimella.css'))
,p_is_current=>false
,p_is_public=>true
,p_is_accessible=>true
,p_theme_roller_read_only=>false
,p_reference_id=>49510680342080164
);
wwv_flow_imp.component_end;
end;
/
