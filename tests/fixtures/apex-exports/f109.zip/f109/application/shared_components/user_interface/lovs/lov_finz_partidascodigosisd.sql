prompt --application/shared_components/user_interface/lovs/lov_finz_partidascodigosisd
begin
--   Manifest
--     LOV_FINZ_PARTIDASCODIGOSISD
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>109
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(249302130615878860)
,p_lov_name=>'LOV_FINZ_PARTIDASCODIGOSISD'
,p_lov_query=>wwv_flow_string.join(wwv_flow_t_varchar2(
'WITH codigoisd AS (',
'    SELECT u.id_tabla,',
'           u.descripcion,',
'           u.valor,',
'           u.codigocompania,',
'           u.vigenciadesde,',
'           u.vigenciahasta',
'    FROM t_corp_udc u',
'    WHERE u.id_cabecera = ''FINZ_VISD''',
'      AND u.id_tabla <> ''S/N''',
'      AND u.activo = ''1''',
'      AND trunc(sysdate) BETWEEN trunc(u.vigenciadesde) AND trunc(u.vigenciahasta)',
'),',
'parancel AS (',
'    SELECT vt_cat.drky pararanc,',
'           vt_cat.drdl01 descripcion01,',
'           vt_cat.drdl02 descripcion02,',
'            vt_cat.drky ||'' ''||',
'           vt_cat.drdl01 ||'' ''||',
'           vt_cat.drdl02 descripcion03',
'',
'    FROM data.vt_jde_udcjde vt_cat',
'    WHERE vt_cat.drsy = ''41''',
'      AND vt_cat.drrt = ''10''',
'      AND vt_cat.drky IS NOT NULL',
')',
'SELECT',
'    a.pararc,',
'    c.descripcion01,',
'    c.descripcion02,',
'    c.descripcion03,',
'    a.codisd,',
'    a.tasisd,',
'    b.descripcion,',
'    b.vigenciadesde,',
'    b.vigenciahasta',
'FROM data.t_finz_calculoisdprt a',
'JOIN codigoisd b ON b.id_tabla = a.codisd',
'JOIN parancel c ON c.pararanc = a.pararc',
'WHERE a.activo = 1;'))
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_return_column_name=>'PARARC'
,p_display_column_name=>'DESCRIPCION03'
,p_group_sort_direction=>'ASC'
,p_default_sort_direction=>'ASC'
,p_version_scn=>124145393531
);
wwv_flow_imp_shared.create_list_of_values_cols(
 p_id=>wwv_flow_imp.id(249311698933919527)
,p_query_column_name=>'PARARC'
,p_heading=>'Cod. Partida Arancelaria'
,p_display_sequence=>10
,p_data_type=>'VARCHAR2'
);
wwv_flow_imp_shared.create_list_of_values_cols(
 p_id=>wwv_flow_imp.id(249399114663624452)
,p_query_column_name=>'DESCRIPCION03'
,p_heading=>'Descripcion03'
,p_display_sequence=>30
,p_data_type=>'VARCHAR2'
);
wwv_flow_imp_shared.create_list_of_values_cols(
 p_id=>wwv_flow_imp.id(249312462194919527)
,p_query_column_name=>'CODISD'
,p_heading=>unistr('C\00F3digo ISD')
,p_display_sequence=>40
,p_data_type=>'VARCHAR2'
);
wwv_flow_imp_shared.create_list_of_values_cols(
 p_id=>wwv_flow_imp.id(249399593137624453)
,p_query_column_name=>'DESCRIPCION'
,p_heading=>'Descripcion'
,p_display_sequence=>50
,p_data_type=>'VARCHAR2'
);
wwv_flow_imp_shared.create_list_of_values_cols(
 p_id=>wwv_flow_imp.id(249312808606919531)
,p_query_column_name=>'TASISD'
,p_heading=>unistr('Porcentaje C\00F3digo')
,p_display_sequence=>60
,p_data_type=>'NUMBER'
);
wwv_flow_imp_shared.create_list_of_values_cols(
 p_id=>wwv_flow_imp.id(249399980070624453)
,p_query_column_name=>'VIGENCIADESDE'
,p_heading=>'Vigenciadesde'
,p_display_sequence=>70
,p_data_type=>'DATE'
);
wwv_flow_imp_shared.create_list_of_values_cols(
 p_id=>wwv_flow_imp.id(249400393734624453)
,p_query_column_name=>'VIGENCIAHASTA'
,p_heading=>'Vigenciahasta'
,p_display_sequence=>80
,p_data_type=>'DATE'
);
wwv_flow_imp.component_end;
end;
/
