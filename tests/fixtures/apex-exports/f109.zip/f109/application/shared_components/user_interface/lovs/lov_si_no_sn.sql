prompt --application/shared_components/user_interface/lovs/lov_si_no_sn
begin
--   Manifest
--     LOV_SI_NO_SN
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>109
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(341484489208595861)
,p_lov_name=>'LOV_SI_NO_SN'
,p_lov_query=>'.'||wwv_flow_imp.id(341484489208595861)||'.'
,p_location=>'STATIC'
,p_version_scn=>120833266905
,p_created_on=>wwv_flow_imp.dz('20260203045324Z')
,p_updated_on=>wwv_flow_imp.dz('20260203045401Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(341484783257595889)
,p_lov_disp_sequence=>1
,p_lov_disp_value=>unistr('S\00CD')
,p_lov_return_value=>'S'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(341485131266595891)
,p_lov_disp_sequence=>2
,p_lov_disp_value=>'NO'
,p_lov_return_value=>'N'
);
wwv_flow_imp.component_end;
end;
/
