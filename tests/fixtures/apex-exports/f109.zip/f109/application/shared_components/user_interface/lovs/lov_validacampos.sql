prompt --application/shared_components/user_interface/lovs/lov_validacampos
begin
--   Manifest
--     LOV_VALIDACAMPOS
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>109
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(532114744404583514)
,p_lov_name=>'LOV_VALIDACAMPOS'
,p_lov_query=>'.'||wwv_flow_imp.id(532114744404583514)||'.'
,p_location=>'STATIC'
,p_version_scn=>1
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(532115044065583515)
,p_lov_disp_sequence=>1
,p_lov_disp_value=>'Uno o varios campos son incorrectos'
,p_lov_return_value=>'-1'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(532115462005583517)
,p_lov_disp_sequence=>2
,p_lov_disp_value=>'No hay campos registrados'
,p_lov_return_value=>'0'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(532115810840583518)
,p_lov_disp_sequence=>3
,p_lov_disp_value=>unistr('Configuraci\00F3n correcta')
,p_lov_return_value=>'1'
);
wwv_flow_imp.component_end;
end;
/
