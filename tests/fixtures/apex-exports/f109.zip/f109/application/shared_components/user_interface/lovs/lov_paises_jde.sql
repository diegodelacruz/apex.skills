prompt --application/shared_components/user_interface/lovs/lov_paises_jde
begin
--   Manifest
--     LOV_PAISES_JDE
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>109
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(101783646995806318)
,p_lov_name=>'LOV_PAISES_JDE'
,p_lov_query=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT DESCRIPCION, ID_TABLA',
'from DATA.T_CORP_UDC ',
'WHERE ID_CABECERA = ''663'' AND ACTIVO = ''S''  and valor2=''1''',
'order by descripcion'))
,p_source_type=>'LEGACY_SQL'
,p_location=>'LOCAL'
,p_version_scn=>1
);
wwv_flow_imp.component_end;
end;
/
