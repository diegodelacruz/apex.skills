prompt --application/shared_components/user_interface/lovs/lov_jde_udc_tipodocumento
begin
--   Manifest
--     LOV_JDE_UDC_TIPODOCUMENTO
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>109
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(83961973077696144)
,p_lov_name=>'LOV_JDE_UDC_TIPODOCUMENTO'
,p_lov_query=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select DRKY||''-''||DRDL01 D, DRKY R',
'from vt_jde_udcjde@datadl where drsy = ''00'' and drrt = ''DT'';'))
,p_source_type=>'LEGACY_SQL'
,p_location=>'LOCAL'
,p_version_scn=>1
);
wwv_flow_imp.component_end;
end;
/
