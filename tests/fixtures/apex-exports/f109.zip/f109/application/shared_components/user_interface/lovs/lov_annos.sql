prompt --application/shared_components/user_interface/lovs/lov_annos
begin
--   Manifest
--     LOV_ANNOS
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>109
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(350339259209671131)
,p_lov_name=>'LOV_ANNOS'
,p_lov_query=>'select to_char(sysdate,''yyyy'') + (level-3) d,to_char(sysdate,''yyyy'') + (level-3) r from dual connect by level <= 4'
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_return_column_name=>'R'
,p_display_column_name=>'D'
,p_default_sort_column_name=>'D'
,p_default_sort_direction=>'ASC'
,p_version_scn=>1
,p_updated_on=>wwv_flow_imp.dz('20241231163952Z')
,p_updated_by=>'CVACA'
);
wwv_flow_imp.component_end;
end;
/
