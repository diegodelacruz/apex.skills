prompt --application/shared_components/user_interface/lovs/lov_costeo_stdvsreal
begin
--   Manifest
--     LOV_COSTEO_STDVSREAL
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>109
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(480770113451537162)
,p_lov_name=>'LOV_COSTEO_STDVSREAL'
,p_lov_query=>'.'||wwv_flow_imp.id(480770113451537162)||'.'
,p_location=>'STATIC'
,p_version_scn=>1
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(480770446184537190)
,p_lov_disp_sequence=>1
,p_lov_disp_value=>'UND mes'
,p_lov_return_value=>'1'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(480770824996537228)
,p_lov_disp_sequence=>2
,p_lov_disp_value=>'Segunda'
,p_lov_return_value=>'2'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(480771217837537228)
,p_lov_disp_sequence=>3
,p_lov_disp_value=>'Desperdicio'
,p_lov_return_value=>'3'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(480771648277537228)
,p_lov_disp_sequence=>4
,p_lov_disp_value=>'Turno/mes'
,p_lov_return_value=>'4'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(480772085207537228)
,p_lov_disp_sequence=>5
,p_lov_disp_value=>'Horas/mes'
,p_lov_return_value=>'5'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(493742966324678476)
,p_lov_disp_sequence=>6
,p_lov_disp_value=>'Porcentaje Efectividad'
,p_lov_return_value=>'6'
);
wwv_flow_imp.component_end;
end;
/
