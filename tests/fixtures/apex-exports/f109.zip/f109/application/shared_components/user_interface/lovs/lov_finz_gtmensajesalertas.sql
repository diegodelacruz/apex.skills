prompt --application/shared_components/user_interface/lovs/lov_finz_gtmensajesalertas
begin
--   Manifest
--     LOV_FINZ_GTMENSAJESALERTAS
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>109
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(555182144916921250)
,p_lov_name=>'LOV_FINZ_GTMENSAJESALERTAS'
,p_lov_query=>'SELECT  DESCRIPCION, ID_TABLA FROM "DATA"."T_CORP_UDC" WHERE REGEXP_LIKE (ID_CABECERA, ''FINZ_GT06'') AND ID_TABLA!=''000''  ORDER BY 1'
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_use_local_sync_table=>false
,p_return_column_name=>'ID_TABLA'
,p_display_column_name=>'DESCRIPCION'
,p_group_sort_direction=>'ASC'
,p_default_sort_direction=>'ASC'
,p_version_scn=>1
);
wwv_flow_imp.component_end;
end;
/
