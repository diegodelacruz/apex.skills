prompt --application/shared_components/user_interface/lovs/lov_pyg_nivel01
begin
--   Manifest
--     LOV_PYG_NIVEL01
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>109
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(119193859528059131)
,p_lov_name=>'LOV_PYG_NIVEL01'
,p_lov_query=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT  TRIM(DRKY) || '' - '' || DRDL01 D, TRIM(DRKY) R ',
'FROM VT_JDE_UDC ',
'WHERE DRSY=''09'' AND DRRT IN (''41'') AND TRIM(DRKY) IS NOT NULL ',
'ORDER BY DRRT, TO_NUMBER(TRIM(DRKY))'))
,p_source_type=>'LEGACY_SQL'
,p_location=>'LOCAL'
,p_version_scn=>1
);
wwv_flow_imp.component_end;
end;
/
