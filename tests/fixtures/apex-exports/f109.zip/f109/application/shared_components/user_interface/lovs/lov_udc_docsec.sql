prompt --application/shared_components/user_interface/lovs/lov_udc_docsec
begin
--   Manifest
--     LOV_UDC_DOCSEC
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>109
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(174061179140947522)
,p_lov_name=>'LOV_UDC_DOCSEC'
,p_lov_query=>'select ID_CABECERA, ID_TABLA, VALOR, DESCRIPCION, DESCRIPCION3, VALOR2, ACTIVO from vt_finz_udc_doce_seccionetiqueta ;'
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_return_column_name=>'VALOR'
,p_display_column_name=>'DESCRIPCION'
,p_default_sort_column_name=>'DESCRIPCION'
,p_default_sort_direction=>'ASC'
,p_version_scn=>1
);
wwv_flow_imp.component_end;
end;
/
