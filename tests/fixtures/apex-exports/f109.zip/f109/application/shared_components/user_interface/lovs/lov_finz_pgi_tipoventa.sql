prompt --application/shared_components/user_interface/lovs/lov_finz_pgi_tipoventa
begin
--   Manifest
--     LOV_FINZ_PGI_TIPOVENTA
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>109
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(121710145807591205)
,p_lov_name=>'LOV_FINZ_PGI_TIPOVENTA'
,p_lov_query=>wwv_flow_string.join(wwv_flow_t_varchar2(
'	select trim(campo3)campo3,trim(campo2)campo2',
'from table(pk_commons.f_split2table(''',
'    10:VM:Venta Modulo;',
'    20:VN:Venta Neta;',
'    30:CV:Costo Venta;',
'    40:CF:Costo Flete;',
'    50:GF:Gasto Flete;',
'    60:VR:Variaciones;',
'    70:GV:Gastos Venta;',
'    80:OG:Otros Gastos;',
unistr('    90:BD:Base de Distribuci\00F3n;'),
unistr('    100:CD:Condiciones Distribuci\00F3n'','':'','';''))ORDER BY TO_NUMBER(CAMPO1)')))
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_return_column_name=>'CAMPO2'
,p_display_column_name=>'CAMPO3'
,p_group_sort_direction=>'ASC'
,p_default_sort_direction=>'ASC'
,p_version_scn=>122786739884
,p_updated_on=>wwv_flow_imp.dz('20260327021949Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp.component_end;
end;
/
