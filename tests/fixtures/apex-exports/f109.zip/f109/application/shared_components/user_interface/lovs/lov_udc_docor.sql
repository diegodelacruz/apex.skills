prompt --application/shared_components/user_interface/lovs/lov_udc_docor
begin
--   Manifest
--     LOV_UDC_DOCOR
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>109
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(172258066150805822)
,p_lov_name=>'LOV_UDC_DOCOR'
,p_lov_query=>'SELECT DESCRIPCION, VALOR FROM vt_finz_udc_doce_origendatos order by TO_NUMBER(ID_TABLA);'
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_use_local_sync_table=>false
,p_return_column_name=>'VALOR'
,p_display_column_name=>'DESCRIPCION'
,p_group_sort_direction=>'ASC'
,p_default_sort_direction=>'ASC'
,p_version_scn=>1
,p_updated_on=>wwv_flow_imp.dz('20240607161234Z')
,p_updated_by=>'EMASABANDA'
);
wwv_flow_imp.component_end;
end;
/
