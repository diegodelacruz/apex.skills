prompt --application/shared_components/user_interface/lovs/lov_finz_calculoisdestado
begin
--   Manifest
--     LOV_FINZ_CALCULOISDESTADO
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>109
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(108342589181457914)
,p_lov_name=>'LOV_FINZ_CALCULOISDESTADO'
,p_lov_query=>'.'||wwv_flow_imp.id(108342589181457914)||'.'
,p_location=>'STATIC'
,p_version_scn=>1
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(108342879210457922)
,p_lov_disp_sequence=>1
,p_lov_disp_value=>unistr('C\00E1lculo ISD')
,p_lov_return_value=>'1'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(108343237793457924)
,p_lov_disp_sequence=>2
,p_lov_disp_value=>unistr('C\00E1culo Factor Humedad')
,p_lov_return_value=>'2'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(108343695415457924)
,p_lov_disp_sequence=>3
,p_lov_disp_value=>'Finalizado'
,p_lov_return_value=>'3'
);
wwv_flow_imp.component_end;
end;
/
