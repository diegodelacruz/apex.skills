prompt --application/shared_components/user_interface/lovs/lov_finz_pgi_ctascontables
begin
--   Manifest
--     LOV_FINZ_PGI_CTASCONTABLES
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>109
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(124865455833884289)
,p_lov_name=>'LOV_FINZ_PGI_CTASCONTABLES'
,p_lov_query=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT   ',
'     trim(gmobj) gmobj',
'    ,TRIM(gmsub)  gmsub',
'    ,trim(gmobj) ||''.''||TRIM(gmsub)||'' ''||TRIM(gmdl01) gmdl01',
'    ,PK_COMMONS.F_JDE2G(GMUPMJ)GMUPMJ',
'    ,trim(trim(gmobj) ||''.''||TRIM(gmsub)) GMAID',
'    /*,a.**/',
'FROM f0901@jdedtadl a',
'WHERE TRIM(gmsub) IS NOT NULL',
'AND GMMCU=''     1MODELO''',
'',
'order by GMOBJ, GMSUB,  GMUPMJ DESC,gmdl01'))
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_return_column_name=>'GMAID'
,p_display_column_name=>'GMDL01'
,p_group_sort_direction=>'ASC'
,p_default_sort_direction=>'ASC'
,p_version_scn=>117166676209
);
wwv_flow_imp_shared.create_list_of_values_cols(
 p_id=>wwv_flow_imp.id(124866198700891584)
,p_query_column_name=>'GMAID'
,p_heading=>'ID de cuenta'
,p_display_sequence=>10
,p_data_type=>'VARCHAR2'
,p_is_searchable=>'N'
);
wwv_flow_imp_shared.create_list_of_values_cols(
 p_id=>wwv_flow_imp.id(124911908275459689)
,p_query_column_name=>'GMOBJ'
,p_heading=>'Gmobj'
,p_display_sequence=>10
,p_data_type=>'VARCHAR2'
);
wwv_flow_imp_shared.create_list_of_values_cols(
 p_id=>wwv_flow_imp.id(124866582670891585)
,p_query_column_name=>'GMDL01'
,p_heading=>unistr('Descripci\00F3n')
,p_display_sequence=>20
,p_data_type=>'VARCHAR2'
);
wwv_flow_imp_shared.create_list_of_values_cols(
 p_id=>wwv_flow_imp.id(124867316232891585)
,p_query_column_name=>'GMSUB'
,p_heading=>'Cuenta de Auxiliar'
,p_display_sequence=>40
,p_data_type=>'VARCHAR2'
);
wwv_flow_imp_shared.create_list_of_values_cols(
 p_id=>wwv_flow_imp.id(124872617856025361)
,p_query_column_name=>'GMUPMJ'
,p_heading=>'Fecha - Actualizada'
,p_display_sequence=>50
,p_data_type=>'DATE'
);
wwv_flow_imp.component_end;
end;
/
