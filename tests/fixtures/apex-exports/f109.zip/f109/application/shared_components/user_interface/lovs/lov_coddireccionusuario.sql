prompt --application/shared_components/user_interface/lovs/lov_coddireccionusuario
begin
--   Manifest
--     LOV_CODDIRECCIONUSUARIO
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>109
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(336564499940306120)
,p_lov_name=>'LOV_CODDIRECCIONUSUARIO'
,p_lov_query=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select coderp, trim(apellidos)||'' ''||trim(nombres) colaborador',
'from data.vt_corp_usuario',
'where compania = :g_compania and nvl(coderp,0) > 0'))
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_return_column_name=>'CODERP'
,p_display_column_name=>'COLABORADOR'
,p_group_sort_direction=>'ASC'
,p_default_sort_column_name=>'COLABORADOR'
,p_default_sort_direction=>'ASC'
,p_version_scn=>122534203714
,p_created_on=>wwv_flow_imp.dz('20260129211826Z')
,p_updated_on=>wwv_flow_imp.dz('20260320141951Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp.component_end;
end;
/
