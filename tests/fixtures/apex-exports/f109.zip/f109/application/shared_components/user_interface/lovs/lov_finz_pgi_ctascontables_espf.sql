prompt --application/shared_components/user_interface/lovs/lov_finz_pgi_ctascontables_espf
begin
--   Manifest
--     LOV_FINZ_PGI_CTASCONTABLES_ESPF
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>109
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(142706424163243595)
,p_lov_name=>'LOV_FINZ_PGI_CTASCONTABLES_ESPF'
,p_lov_query=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT distinct   GMMCU,',
'     trim(gmobj) gmobj',
'    ,TRIM(gmsub)  gmsub',
'    ,TRIM(gmdl01) gmddl01',
'    ,trim(GMMCU) ||''.''||trim(gmobj) ||''.''||TRIM(gmsub)||'' ''||TRIM(gmdl01) gmdl01',
'    ,PK_COMMONS.F_JDE2G(GMUPMJ)GMUPMJ',
'    ,trim(trim(GMMCU) ||''.''||trim(gmobj) ||''.''||TRIM(gmsub)) GMAID',
'    /*,a.**/',
'FROM f0901@jdedtadl a',
'WHERE TRIM(gmsub) IS NOT NULL',
'AND GMMCU not in (''     1MODELO'',''    FINANZAS'',''     1CIERRE'')',
'order by  TRIM(gmddl01) ,GMMCU,GMOBJ,GMSUB,GMUPMJ DESC,gmdl01'))
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_return_column_name=>'GMAID'
,p_display_column_name=>'GMDL01'
,p_group_sort_direction=>'ASC'
,p_default_sort_direction=>'ASC'
,p_version_scn=>118223246191
);
wwv_flow_imp_shared.create_list_of_values_cols(
 p_id=>wwv_flow_imp.id(142707721578265478)
,p_query_column_name=>'GMMCU'
,p_heading=>'Centro Costo'
,p_display_sequence=>10
,p_data_type=>'VARCHAR2'
);
wwv_flow_imp_shared.create_list_of_values_cols(
 p_id=>wwv_flow_imp.id(142708112108265478)
,p_query_column_name=>'GMOBJ'
,p_heading=>'Objeto'
,p_display_sequence=>20
,p_data_type=>'VARCHAR2'
);
wwv_flow_imp_shared.create_list_of_values_cols(
 p_id=>wwv_flow_imp.id(142708513610265479)
,p_query_column_name=>'GMSUB'
,p_heading=>'Auxiliar'
,p_display_sequence=>40
,p_data_type=>'VARCHAR2'
);
wwv_flow_imp_shared.create_list_of_values_cols(
 p_id=>wwv_flow_imp.id(142708959452265479)
,p_query_column_name=>'GMDL01'
,p_heading=>unistr('Descripci\00F3n')
,p_display_sequence=>50
,p_data_type=>'VARCHAR2'
);
wwv_flow_imp_shared.create_list_of_values_cols(
 p_id=>wwv_flow_imp.id(142709398513265479)
,p_query_column_name=>'GMAID'
,p_display_sequence=>50
,p_data_type=>'VARCHAR2'
,p_is_visible=>'N'
,p_is_searchable=>'N'
);
wwv_flow_imp.component_end;
end;
/
