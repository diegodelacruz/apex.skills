prompt --application/shared_components/user_interface/lovs/lov_jde_glclass
begin
--   Manifest
--     LOV_JDE_GLCLASS
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>109
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(114135955609459248)
,p_lov_name=>'LOV_JDE_GLCLASS'
,p_lov_query=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select TRIM(DRKY) || '' - '' || DRDL01, DRKY ',
'from  vt_jde_udcjde where drsy=''41'' and drrt=''9'' AND DRSPHD=''ZAIMELLA  ''',
'order by 1'))
,p_source_type=>'LEGACY_SQL'
,p_location=>'LOCAL'
,p_version_scn=>1
);
wwv_flow_imp.component_end;
end;
/
