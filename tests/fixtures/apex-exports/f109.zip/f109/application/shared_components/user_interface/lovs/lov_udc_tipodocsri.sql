prompt --application/shared_components/user_interface/lovs/lov_udc_tipodocsri
begin
--   Manifest
--     LOV_UDC_TIPODOCSRI
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>109
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(307266993010198593)
,p_lov_name=>'LOV_UDC_TIPODOCSRI'
,p_lov_query=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select descripcion, id_tabla codigo',
'from data.t_corp_udc',
'where 1 = 1',
'	and codigocompania = :g_compania',
'	and id_cabecera = ''FINZ_TDSRI''',
'	and activo = 1',
'	order by descripcion'))
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_return_column_name=>'CODIGO'
,p_display_column_name=>'DESCRIPCION'
,p_version_scn=>119790015646
,p_created_on=>wwv_flow_imp.dz('20260105191351Z')
,p_updated_on=>wwv_flow_imp.dz('20260105191351Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp.component_end;
end;
/
