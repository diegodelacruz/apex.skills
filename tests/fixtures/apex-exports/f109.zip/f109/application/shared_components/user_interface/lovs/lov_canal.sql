prompt --application/shared_components/user_interface/lovs/lov_canal
begin
--   Manifest
--     LOV_CANAL
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>109
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(379248457893624940)
,p_lov_name=>'LOV_CANAL'
,p_lov_query=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select DRDL01  as d,',
'     DRKY    as r',
'  from VT_JDE_UDCJDE WHERE DRSY= ''01'' AND DRRT= ''02''',
' order by 1'))
,p_source_type=>'LEGACY_SQL'
,p_location=>'LOCAL'
,p_version_scn=>1
);
wwv_flow_imp.component_end;
end;
/
