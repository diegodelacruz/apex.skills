prompt --application/shared_components/user_interface/lovs/lov_finz_pgi_dimensionmetododistribucion
begin
--   Manifest
--     LOV_FINZ_PGI_DIMENSIONMETODODISTRIBUCION
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>109
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(118594849862133559)
,p_lov_name=>'LOV_FINZ_PGI_DIMENSIONMETODODISTRIBUCION'
,p_lov_query=>wwv_flow_string.join(wwv_flow_t_varchar2(
' select  CTABT1||'' - ''|| TRIM(CTDL01) CTDL01,CTABT1 ',
' from ',
' f1620@jdedtadl ORDER BY 1; '))
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_return_column_name=>'CTABT1'
,p_display_column_name=>'CTDL01'
,p_group_sort_direction=>'ASC'
,p_default_sort_direction=>'ASC'
,p_version_scn=>117624903267
);
wwv_flow_imp.component_end;
end;
/
