prompt --application/shared_components/user_interface/lovs/lov_udc_opcionesconcilia
begin
--   Manifest
--     LOV_UDC_OPCIONESCONCILIA
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>109
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(539374206110883010)
,p_lov_name=>'LOV_UDC_OPCIONESCONCILIA'
,p_lov_query=>'select descripcion, id_tabla from t_corp_udc where id_cabecera = ''713'' order by 1'
,p_source_type=>'LEGACY_SQL'
,p_location=>'LOCAL'
,p_version_scn=>1
);
wwv_flow_imp.component_end;
end;
/
