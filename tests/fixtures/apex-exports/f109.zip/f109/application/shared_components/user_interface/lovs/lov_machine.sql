prompt --application/shared_components/user_interface/lovs/lov_machine
begin
--   Manifest
--     LOV_MACHINE
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>109
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(108799505812474951)
,p_lov_name=>'LOV_MACHINE'
,p_lov_query=>'.'||wwv_flow_imp.id(108799505812474951)||'.'
,p_location=>'STATIC'
,p_version_scn=>1
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(108799811326474951)
,p_lov_disp_sequence=>1
,p_lov_disp_value=>'MACHINE1'
,p_lov_return_value=>'MAC001'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(108800244731474953)
,p_lov_disp_sequence=>2
,p_lov_disp_value=>'MACHINE2'
,p_lov_return_value=>'MAC002'
);
wwv_flow_imp.component_end;
end;
/
