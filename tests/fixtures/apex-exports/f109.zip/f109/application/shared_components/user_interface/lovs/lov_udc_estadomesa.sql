prompt --application/shared_components/user_interface/lovs/lov_udc_estadomesa
begin
--   Manifest
--     LOV_UDC_ESTADOMESA
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>109
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(338281992483453171)
,p_lov_name=>'LOV_UDC_ESTADOMESA'
,p_lov_query=>'SELECT DESCRIPCION, ID_TABLA FROM T_CORP_UDC WHERE id_cabecera=''ESTADOMESA'' ORDER BY id_tabla;'
,p_source_type=>'LEGACY_SQL'
,p_location=>'LOCAL'
,p_version_scn=>1
);
wwv_flow_imp.component_end;
end;
/
