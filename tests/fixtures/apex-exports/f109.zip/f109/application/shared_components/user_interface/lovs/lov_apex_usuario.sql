prompt --application/shared_components/user_interface/lovs/lov_apex_usuario
begin
--   Manifest
--     LOV_APEX_USUARIO
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>109
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(341755321671030417)
,p_lov_name=>'LOV_APEX_USUARIO'
,p_lov_query=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select case',
'	when trim(apellidos) is null then trim(nombres)',
'	when trim(nombres) is null then trim(apellidos)',
'	else trim(apellidos)||'' ''||trim(nombres) end d',
'	, nombreusuario r',
'from data.vt_corp_usuario',
'where 1 = 1',
'order by 1'))
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_return_column_name=>'R'
,p_display_column_name=>'D'
,p_version_scn=>120835277701
,p_created_on=>wwv_flow_imp.dz('20260203060549Z')
,p_updated_on=>wwv_flow_imp.dz('20260203060549Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp.component_end;
end;
/
