prompt --application/shared_components/user_interface/lovs/lov_finz_gtcondicionantes
begin
--   Manifest
--     LOV_FINZ_GTCONDICIONANTES
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>109
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(542425179350034424)
,p_lov_name=>'LOV_FINZ_GTCONDICIONANTES'
,p_lov_query=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT CASE WHEN ID<=6 THEN CAMPO1 ||'' '' ELSE '''' END ||CAMPO2 d,campo1 r',
unistr('FROM TABLE(PK_COMMONS.f_split2table(''=|IGUAL\00AC<|MENOR\00AC>|MAYOR\00AC<=|MENOR IGUAL\00AC>=|MAYOR IGUAL\00AC<>|DIFERENTE\00ACIS_NULL|ES NULO\00ACIS_NOT_NULL|NO ES NULO\00ACIN|DENTRO (SEPARADO POR COMAS)\00ACNOT_IN|NO DENTRO (SEPARADO POR COMAS)\00ACBETWEEN|ENTRE\00ACNOT_BETWEEN|NO ENTRE\00ACLIK')
||unistr('E|CONTIENE\00ACNOT_LIKE|NO CONTIENE'',''|'',''\00AC'') ) A order by id')))
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_use_local_sync_table=>false
,p_return_column_name=>'R'
,p_group_sort_direction=>'ASC'
,p_default_sort_direction=>'ASC'
,p_version_scn=>112440838839
);
wwv_flow_imp.component_end;
end;
/
