prompt --application/shared_components/user_interface/lovs/lov_pygenv_codificacionvalores
begin
--   Manifest
--     LOV_PYGENV_CODIFICACIONVALORES
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>109
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(107613280412709733)
,p_lov_name=>'LOV_PYGENV_CODIFICACIONVALORES'
,p_lov_query=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT',
'    descripcion,',
'    id_tabla',
'FROM',
'    t_corp_udc',
'WHERE',
'    id_cabecera = ''pygformu''',
'ORDER BY',
'    descripcion'))
,p_source_type=>'LEGACY_SQL'
,p_location=>'LOCAL'
,p_version_scn=>1
);
wwv_flow_imp.component_end;
end;
/
