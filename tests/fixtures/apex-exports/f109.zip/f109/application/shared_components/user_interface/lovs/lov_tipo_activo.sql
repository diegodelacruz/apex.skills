prompt --application/shared_components/user_interface/lovs/lov_tipo_activo
begin
--   Manifest
--     LOV_TIPO_ACTIVO
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>109
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(178348587659336835)
,p_lov_name=>'LOV_TIPO_ACTIVO'
,p_lov_query=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT DESCRIPCION, VALOR ',
'FROM T_CORP_UDC',
'WHERE ID_CABECERA = ''FINZ_ACTFI''',
'AND DESCRIPCION2=''TIPO ACTIVO''',
'AND ACTIVO=1',
'ORDER BY 2;'))
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_return_column_name=>'VALOR'
,p_display_column_name=>'DESCRIPCION'
,p_version_scn=>1
,p_created_on=>wwv_flow_imp.dz('20231220202344Z')
,p_updated_on=>wwv_flow_imp.dz('20231220202344Z')
,p_created_by=>'MALBAN'
,p_updated_by=>'MALBAN'
);
wwv_flow_imp.component_end;
end;
/
