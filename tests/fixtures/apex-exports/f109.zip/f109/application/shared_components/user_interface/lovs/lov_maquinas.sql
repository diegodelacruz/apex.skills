prompt --application/shared_components/user_interface/lovs/lov_maquinas
begin
--   Manifest
--     LOV_MAQUINAS
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>109
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(370773065378615016)
,p_lov_name=>'LOV_MAQUINAS'
,p_lov_query=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select trim(mcmcu)||'' - ''||trim(mcdc) d, trim(mcmcu) r from f0006@jdedtadl ',
'WHERE MCSTYL=''WC''',
'order by 1;'))
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_return_column_name=>'R'
,p_display_column_name=>'D'
,p_version_scn=>1
,p_created_on=>wwv_flow_imp.dz('20240705144332Z')
,p_updated_on=>wwv_flow_imp.dz('20240705144332Z')
,p_created_by=>'MALBAN'
,p_updated_by=>'MALBAN'
);
wwv_flow_imp.component_end;
end;
/
