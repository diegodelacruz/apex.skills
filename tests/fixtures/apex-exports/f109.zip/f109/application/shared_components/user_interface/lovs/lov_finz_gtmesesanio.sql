prompt --application/shared_components/user_interface/lovs/lov_finz_gtmesesanio
begin
--   Manifest
--     LOV_FINZ_GTMESESANIO
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>109
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(42658224691575348)
,p_lov_name=>'LOV_FINZ_GTMESESANIO'
,p_lov_query=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT TO_CHAR(TO_DATE(LEVEL, ''MM''), ''Month'', ''NLS_DATE_LANGUAGE=Spanish'') AS display_value,',
'       TO_CHAR(LEVEL, ''FM09'') AS return_value',
'FROM dual',
'CONNECT BY LEVEL <= 12'))
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_return_column_name=>'RETURN_VALUE'
,p_display_column_name=>'DISPLAY_VALUE'
,p_group_sort_direction=>'ASC'
,p_default_sort_column_name=>'DISPLAY_VALUE'
,p_default_sort_direction=>'ASC'
,p_version_scn=>111321966701
);
wwv_flow_imp.component_end;
end;
/
