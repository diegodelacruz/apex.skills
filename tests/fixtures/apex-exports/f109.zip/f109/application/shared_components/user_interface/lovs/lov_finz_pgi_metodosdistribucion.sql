prompt --application/shared_components/user_interface/lovs/lov_finz_pgi_metodosdistribucion
begin
--   Manifest
--     LOV_FINZ_PGI_METODOSDISTRIBUCION
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>109
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(118261982109617557)
,p_lov_name=>'LOV_FINZ_PGI_METODOSDISTRIBUCION'
,p_lov_query=>wwv_flow_string.join(wwv_flow_t_varchar2(
'with cfg as (',
'    SELECT ID, case TABLAPROCESO ',
'when ''t_finz_distribucionasc'' then ''ASIENTOS CONTABLES'' ',
'when ''t_finz_distribucionvta'' then ''VENTAS'' ',
'end proceso, DESCRIPCION, ESTADO FROM T_FINZ_DISTRIBUCIONcfg where UPPER(ESTADO)=''ACTIVO''',
'order by proceso desc',
')--SELECT * FROM cfg  ;',
unistr(',METS AS (SELECT a.ID id,b.DESCRIPCION,b.PROCESO,a.IDREF REFERENCIA,''V''||TRIM(to_char(a.VERSION,''00000'')) VERSION, a.TIPO,a.DIMENSIONES , CASE WHEN a.criterio IS NULL THEN ''No'' ELSE ''S\00ED'' END CRITERIO'),
', b.PROCESO ||''/''|| b.DESCRIPCION||''/''||''V''||TRIM(to_char(a.VERSION,''00000''))||''(''||UPPER(a.ESTADO)||'')'' RETDESCRIPCION',
'FROM t_finz_distribucionmtd a ',
'left join cfg b on a.idcfg=b.id',
'where (a.id !=:G_VALORMTD or :G_VALORMTD is null) and a.IDCFG=:G_VALORCFG  ',
' order by version',
' )',
' SELECT a.ID, a.DESCRIPCION, a.PROCESO, B.RETDESCRIPCION REFERENCIA, a.VERSION, a.TIPO, a.DIMENSIONES, a.CRITERIO, a.RETDESCRIPCION',
' FROM METS A LEFT JOIN METS B ON A.REFERENCIA = B.ID'))
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_return_column_name=>'ID'
,p_display_column_name=>'RETDESCRIPCION'
,p_group_sort_direction=>'ASC'
,p_default_sort_direction=>'ASC'
,p_version_scn=>117247042998
);
wwv_flow_imp_shared.create_list_of_values_cols(
 p_id=>wwv_flow_imp.id(118262391314620199)
,p_query_column_name=>'ID'
,p_display_sequence=>10
,p_data_type=>'NUMBER'
,p_is_visible=>'N'
,p_is_searchable=>'N'
);
wwv_flow_imp_shared.create_list_of_values_cols(
 p_id=>wwv_flow_imp.id(126207079436269554)
,p_query_column_name=>'RETDESCRIPCION'
,p_heading=>'Retdescripcion'
,p_display_sequence=>10
,p_data_type=>'VARCHAR2'
,p_is_visible=>'N'
);
wwv_flow_imp_shared.create_list_of_values_cols(
 p_id=>wwv_flow_imp.id(126181704620183105)
,p_query_column_name=>'PROCESO'
,p_heading=>'Proceso'
,p_display_sequence=>20
,p_data_type=>'VARCHAR2'
);
wwv_flow_imp_shared.create_list_of_values_cols(
 p_id=>wwv_flow_imp.id(126182159582183106)
,p_query_column_name=>'DESCRIPCION'
,p_heading=>'Descripcion'
,p_display_sequence=>30
,p_data_type=>'VARCHAR2'
);
wwv_flow_imp_shared.create_list_of_values_cols(
 p_id=>wwv_flow_imp.id(126182563194183106)
,p_query_column_name=>'REFERENCIA'
,p_heading=>'Referencia'
,p_display_sequence=>40
,p_data_type=>'NUMBER'
);
wwv_flow_imp_shared.create_list_of_values_cols(
 p_id=>wwv_flow_imp.id(118262759736620200)
,p_query_column_name=>'VERSION'
,p_heading=>'Version'
,p_display_sequence=>50
,p_data_type=>'NUMBER'
);
wwv_flow_imp_shared.create_list_of_values_cols(
 p_id=>wwv_flow_imp.id(118263168342620200)
,p_query_column_name=>'TIPO'
,p_heading=>'Tipo'
,p_display_sequence=>60
,p_data_type=>'VARCHAR2'
);
wwv_flow_imp_shared.create_list_of_values_cols(
 p_id=>wwv_flow_imp.id(118263521187620200)
,p_query_column_name=>'DIMENSIONES'
,p_heading=>'Dimensiones'
,p_display_sequence=>70
,p_data_type=>'CLOB'
);
wwv_flow_imp_shared.create_list_of_values_cols(
 p_id=>wwv_flow_imp.id(126200445707232846)
,p_query_column_name=>'CRITERIO'
,p_heading=>'Tiene Criterio Dist?'
,p_display_sequence=>80
,p_data_type=>'NUMBER'
);
wwv_flow_imp.component_end;
end;
/
