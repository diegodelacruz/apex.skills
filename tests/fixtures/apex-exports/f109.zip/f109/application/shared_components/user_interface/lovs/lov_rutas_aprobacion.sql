prompt --application/shared_components/user_interface/lovs/lov_rutas_aprobacion
begin
--   Manifest
--     LOV_RUTAS_APROBACION
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>109
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(105115734127455389)
,p_lov_name=>'LOV_RUTAS_APROBACION'
,p_lov_query=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select    trim(NOMBRE) NOMBRE,  trim(TIPO1)',
'from  t_admi_ruta ',
'where 1=1',
'AND TIPO1 IN(''PERIODO'') ',
' ',
'GROUP BY trim(NOMBRE) ,  trim(TIPO1)'))
,p_source_type=>'LEGACY_SQL'
,p_location=>'LOCAL'
,p_version_scn=>1
);
wwv_flow_imp.component_end;
end;
/
