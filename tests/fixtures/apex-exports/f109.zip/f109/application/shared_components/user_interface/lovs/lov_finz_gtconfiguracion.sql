prompt --application/shared_components/user_interface/lovs/lov_finz_gtconfiguracion
begin
--   Manifest
--     LOV_FINZ_GTCONFIGURACION
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>109
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(16929366129683584)
,p_lov_name=>'LOV_FINZ_GTCONFIGURACION'
,p_lov_query=>wwv_flow_string.join(wwv_flow_t_varchar2(
'with ',
'      tob as ( SELECT id_tabla tob_id, descripcion tob_descripcion FROM DATA.T_CORP_UDC WHERE activo=''1'' and id_cabecera = ''FINZ_GT02'' AND id_tabla != ''000'' )',
'    , tpr as ( SELECT id_tabla tpr_id, descripcion tpr_descripcion FROM DATA.T_CORP_UDC WHERE activo=''1'' and id_cabecera = ''FINZ_GT01'' AND id_tabla != ''000'' )',
'    , obj as ( select item cfg_id,id orden  from table(pk_commons.f_dividirtexto(:G_GT_OBJETOS,'':'')))',
'SELECT ',
'    tpr_descripcion ||'' - ''||cfg.descripcion ||'' (''||PK_FINZ_GESTIONTRIBUTARIA.F_OBTENER_ALIAS_JSON(cfg.ID) ||'')'' cfg_descripcion,cfg.id',
'FROM t_finz_gestiontributariacfg cfg',
'INNER JOIN tob ON tob_id = cfg.tipoobjeto',
'INNER JOIN tpr ON tpr_id = cfg.idproceso',
'inner join obj on cfg_id = cfg.id',
'WHERE 1=1',
'order by orden'))
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_return_column_name=>'ID'
,p_display_column_name=>'CFG_DESCRIPCION'
,p_group_sort_direction=>'ASC'
,p_default_sort_direction=>'ASC'
,p_version_scn=>116361734343
,p_updated_on=>wwv_flow_imp.dz('20251019230010Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp.component_end;
end;
/
