prompt --application/shared_components/user_interface/lovs/lov_estadoactivo
begin
--   Manifest
--     LOV_ESTADOACTIVO
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>109
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(178312318617222764)
,p_lov_name=>'LOV_ESTADOACTIVO'
,p_lov_query=>'.'||wwv_flow_imp.id(178312318617222764)||'.'
,p_location=>'STATIC'
,p_version_scn=>1
,p_created_on=>wwv_flow_imp.dz('20231220200443Z')
,p_updated_on=>wwv_flow_imp.dz('20231220200443Z')
,p_created_by=>'MALBAN'
,p_updated_by=>'MALBAN'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(178312692642222766)
,p_lov_disp_sequence=>1
,p_lov_disp_value=>'BUENO'
,p_lov_return_value=>'1'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(178313038149222767)
,p_lov_disp_sequence=>2
,p_lov_disp_value=>'MALO'
,p_lov_return_value=>'2'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(178313471555222767)
,p_lov_disp_sequence=>3
,p_lov_disp_value=>'REGULAR'
,p_lov_return_value=>'3'
);
wwv_flow_imp.component_end;
end;
/
