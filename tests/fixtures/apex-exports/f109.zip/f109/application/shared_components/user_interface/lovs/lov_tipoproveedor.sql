prompt --application/shared_components/user_interface/lovs/lov_tipoproveedor
begin
--   Manifest
--     LOV_TIPOPROVEEDOR
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>109
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(107474199533629316)
,p_lov_name=>'LOV_TIPOPROVEEDOR'
,p_lov_query=>'.'||wwv_flow_imp.id(107474199533629316)||'.'
,p_location=>'STATIC'
,p_version_scn=>1
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(107474479718629318)
,p_lov_disp_sequence=>1
,p_lov_disp_value=>'Exterior'
,p_lov_return_value=>'PE'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(107474801745629319)
,p_lov_disp_sequence=>2
,p_lov_disp_value=>'Local'
,p_lov_return_value=>'PL'
);
wwv_flow_imp.component_end;
end;
/
