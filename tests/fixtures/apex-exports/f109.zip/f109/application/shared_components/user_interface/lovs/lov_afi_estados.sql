prompt --application/shared_components/user_interface/lovs/lov_afi_estados
begin
--   Manifest
--     LOV_AFI_ESTADOS
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>109
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(103056739471701431)
,p_lov_name=>'LOV_AFI_ESTADOS'
,p_lov_query=>'.'||wwv_flow_imp.id(103056739471701431)||'.'
,p_location=>'STATIC'
,p_version_scn=>115681369376
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(103057017388701444)
,p_lov_disp_sequence=>1
,p_lov_disp_value=>'CREADO'
,p_lov_return_value=>'CREADO'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(103057458653701446)
,p_lov_disp_sequence=>2
,p_lov_disp_value=>'ENVIADO'
,p_lov_return_value=>'ENVIADO'
);
wwv_flow_imp.component_end;
end;
/
