prompt --application/shared_components/user_interface/lovs/lov_jde_tipo_je
begin
--   Manifest
--     LOV_JDE_TIPO_JE
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>109
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(84294601321551800)
,p_lov_name=>'LOV_JDE_TIPO_JE'
,p_lov_query=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select DRDL01 d, DRKY r',
'from vt_jde_udcjde@datadl where drsy = ''56'' and drrt = ''TP''',
'AND DRKY IS NOT NULL'))
,p_source_type=>'LEGACY_SQL'
,p_location=>'LOCAL'
,p_version_scn=>1
,p_updated_on=>wwv_flow_imp.dz('20240802182457Z')
,p_updated_by=>'MALBAN'
);
wwv_flow_imp.component_end;
end;
/
