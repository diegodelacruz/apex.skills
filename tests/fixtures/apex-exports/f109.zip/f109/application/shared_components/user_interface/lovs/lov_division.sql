prompt --application/shared_components/user_interface/lovs/lov_division
begin
--   Manifest
--     LOV_DIVISION
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>109
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(108738458708371445)
,p_lov_name=>'LOV_DIVISION'
,p_lov_query=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT DRDL01 d,DRKY r',
'FROM F0005@jdectldl',
'WHERE DRSY=''41'' AND DRRT=''P3'''))
,p_source_type=>'LEGACY_SQL'
,p_location=>'LOCAL'
,p_version_scn=>1
);
wwv_flow_imp.component_end;
end;
/
