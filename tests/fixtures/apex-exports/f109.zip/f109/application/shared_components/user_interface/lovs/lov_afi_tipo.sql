prompt --application/shared_components/user_interface/lovs/lov_afi_tipo
begin
--   Manifest
--     LOV_AFI_TIPO
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>109
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(98576969558658537)
,p_lov_name=>'LOV_AFI_TIPO'
,p_lov_query=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select DRDL01 D, DRKY R',
'from vt_jde_udcjde where drsy = ''12'' and drrt = ''21''',
'and DRKY is not null',
'order by 2;'))
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_return_column_name=>'R'
,p_display_column_name=>'D'
,p_group_sort_direction=>'ASC'
,p_default_sort_direction=>'ASC'
,p_version_scn=>115898606348
);
wwv_flow_imp.component_end;
end;
/
