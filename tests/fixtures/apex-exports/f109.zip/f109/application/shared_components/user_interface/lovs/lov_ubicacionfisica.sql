prompt --application/shared_components/user_interface/lovs/lov_ubicacionfisica
begin
--   Manifest
--     LOV_UBICACIONFISICA
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>109
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(178343065914317040)
,p_lov_name=>'LOV_UBICACIONFISICA'
,p_lov_query=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT DESCRIPCION d, VALOR  r',
'FROM T_CORP_UDC',
'WHERE ID_CABECERA = ''FINZ_ACTFI''',
'AND DESCRIPCION2=''UBICACION FISICA''',
'AND ACTIVO=1'))
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_return_column_name=>'R'
,p_display_column_name=>'D'
,p_default_sort_column_name=>'D'
,p_default_sort_direction=>'ASC'
,p_version_scn=>1
,p_created_on=>wwv_flow_imp.dz('20231220202026Z')
,p_updated_on=>wwv_flow_imp.dz('20231220202026Z')
,p_created_by=>'MALBAN'
,p_updated_by=>'MALBAN'
);
wwv_flow_imp.component_end;
end;
/
