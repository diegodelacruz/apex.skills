prompt --application/shared_components/user_interface/lovs/lov_unpadre
begin
--   Manifest
--     LOV_UNPADRE
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>109
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(350603703974816017)
,p_lov_name=>'LOV_UNPADRE'
,p_lov_query=>'select drdl01,drky from vt_jde_udcjde where DRSY = ''00'' and DRRT = ''50'' and drky is not null order by drdl01'
,p_source_type=>'LEGACY_SQL'
,p_location=>'LOCAL'
,p_version_scn=>1
);
wwv_flow_imp.component_end;
end;
/
