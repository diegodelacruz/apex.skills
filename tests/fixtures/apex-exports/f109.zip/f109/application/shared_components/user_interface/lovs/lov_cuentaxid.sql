prompt --application/shared_components/user_interface/lovs/lov_cuentaxid
begin
--   Manifest
--     LOV_CUENTAXID
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>109
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(532084568011346114)
,p_lov_name=>'LOV_CUENTAXID'
,p_lov_query=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select replace(gmmcu||''.''||gmobj||''.''||gmsub,'' '',null)||'' - ''||trim(gmdl01) d',
'	, trim(gmaid) r',
'from f0901@jdedtadl',
'where 1 = 1',
'	and gmco = :g_compania',
'	and replace(gmmcu,'' '',''x'') != ''xxxxxxxxxxxx''',
'	and not regexp_like(gmmcu,''MODELO|FINANZAS|CIERRE'')',
'	and replace(gmobj,'' '',''x'') != ''xxxxxx''',
'	and replace(gmsub,'' '',''x'') != ''xxxxxxxx'''))
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_return_column_name=>'R'
,p_display_column_name=>'D'
,p_group_sort_direction=>'ASC'
,p_default_sort_column_name=>'D'
,p_default_sort_direction=>'ASC'
,p_version_scn=>121115509737
,p_updated_on=>wwv_flow_imp.dz('20260210190216Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp.component_end;
end;
/
