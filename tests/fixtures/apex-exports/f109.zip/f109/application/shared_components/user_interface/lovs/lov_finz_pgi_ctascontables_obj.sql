prompt --application/shared_components/user_interface/lovs/lov_finz_pgi_ctascontables_obj
begin
--   Manifest
--     LOV_FINZ_PGI_CTASCONTABLES_OBJ
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>109
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(360692744238225505)
,p_lov_name=>'LOV_FINZ_PGI_CTASCONTABLES_OBJ'
,p_lov_query=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT distinct   GMMCU,',
'     trim(gmobj) gmobj',
'    ,TRIM(gmsub)  gmsub',
'    ,TRIM(gmdl01) gmddl01',
'    ,trim(GMMCU) ||''.''||trim(gmobj) ||''.''||TRIM(gmsub)||'' ''||TRIM(gmdl01) gmdl01',
'    ,PK_COMMONS.F_JDE2G(GMUPMJ)GMUPMJ',
'    ,trim(trim(GMMCU) ||''.''||trim(gmobj) ||''.''||TRIM(gmsub)) GMAID',
'    /*,a.**/',
'FROM f0901@jdedtadl a',
'WHERE TRIM(gmsub) IS NOT NULL',
'AND GMMCU not in (''     1MODELO'',''    FINANZAS'',''     1CIERRE'')',
'order by  TRIM(gmddl01) ,GMMCU,GMOBJ,GMSUB,GMUPMJ DESC,gmdl01'))
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_return_column_name=>'GMAID'
,p_display_column_name=>'GMDL01'
,p_group_sort_direction=>'ASC'
,p_default_sort_direction=>'ASC'
,p_version_scn=>121452387415
,p_created_on=>wwv_flow_imp.dz('20260219195140Z')
,p_updated_on=>wwv_flow_imp.dz('20260219195218Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_shared.create_list_of_values_cols(
 p_id=>wwv_flow_imp.id(360693142188225506)
,p_query_column_name=>'GMMCU'
,p_heading=>'Centro Costo'
,p_display_sequence=>10
,p_data_type=>'VARCHAR2'
,p_created_on=>wwv_flow_imp.dz('20260219195140Z')
,p_updated_on=>wwv_flow_imp.dz('20260219195218Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_shared.create_list_of_values_cols(
 p_id=>wwv_flow_imp.id(360693543430225506)
,p_query_column_name=>'GMOBJ'
,p_heading=>'Objeto'
,p_display_sequence=>20
,p_data_type=>'VARCHAR2'
,p_created_on=>wwv_flow_imp.dz('20260219195140Z')
,p_updated_on=>wwv_flow_imp.dz('20260219195218Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_shared.create_list_of_values_cols(
 p_id=>wwv_flow_imp.id(360693908694225506)
,p_query_column_name=>'GMSUB'
,p_heading=>'Auxiliar'
,p_display_sequence=>40
,p_data_type=>'VARCHAR2'
,p_created_on=>wwv_flow_imp.dz('20260219195140Z')
,p_updated_on=>wwv_flow_imp.dz('20260219195218Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_shared.create_list_of_values_cols(
 p_id=>wwv_flow_imp.id(360694371792225506)
,p_query_column_name=>'GMDL01'
,p_heading=>unistr('Descripci\00F3n')
,p_display_sequence=>50
,p_data_type=>'VARCHAR2'
,p_created_on=>wwv_flow_imp.dz('20260219195140Z')
,p_updated_on=>wwv_flow_imp.dz('20260219195218Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_shared.create_list_of_values_cols(
 p_id=>wwv_flow_imp.id(360694712552225506)
,p_query_column_name=>'GMAID'
,p_display_sequence=>50
,p_data_type=>'VARCHAR2'
,p_is_visible=>'N'
,p_is_searchable=>'N'
,p_created_on=>wwv_flow_imp.dz('20260219195140Z')
,p_updated_on=>wwv_flow_imp.dz('20260219195218Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp.component_end;
end;
/
