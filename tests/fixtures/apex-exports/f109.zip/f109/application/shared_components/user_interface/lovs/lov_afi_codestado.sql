prompt --application/shared_components/user_interface/lovs/lov_afi_codestado
begin
--   Manifest
--     LOV_AFI_CODESTADO
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>109
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(336839242037362526)
,p_lov_name=>'LOV_AFI_CODESTADO'
,p_lov_query=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select drky codigo, drky||'' - ''||drdl01 descripcion',
'from data.vt_jde_udcjde where drsy = ''12'' and drrt = ''ES'' and drky is not null'))
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_return_column_name=>'CODIGO'
,p_display_column_name=>'DESCRIPCION'
,p_default_sort_column_name=>'DESCRIPCION'
,p_default_sort_direction=>'ASC'
,p_version_scn=>120681882017
,p_created_on=>wwv_flow_imp.dz('20260130054750Z')
,p_updated_on=>wwv_flow_imp.dz('20260130054750Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp.component_end;
end;
/
