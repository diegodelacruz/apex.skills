prompt --application/shared_components/user_interface/lovs/lov_evol_departamentos
begin
--   Manifest
--     LOV_EVOL_DEPARTAMENTOS
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>109
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(179523276456374527)
,p_lov_name=>'LOV_EVOL_DEPARTAMENTOS'
,p_lov_query=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select COD_DEP||'' - ''||DESCRIPCION D,COD_DEP R from evolution .departamentos where STATUS = ''A''',
''))
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_return_column_name=>'R'
,p_display_column_name=>'D'
,p_default_sort_column_name=>'D'
,p_default_sort_direction=>'ASC'
,p_version_scn=>121707059066
);
wwv_flow_imp.component_end;
end;
/
