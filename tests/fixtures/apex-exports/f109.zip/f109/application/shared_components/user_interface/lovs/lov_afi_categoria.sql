prompt --application/shared_components/user_interface/lovs/lov_afi_categoria
begin
--   Manifest
--     LOV_AFI_CATEGORIA
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>109
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(98577560814666584)
,p_lov_name=>'LOV_AFI_CATEGORIA'
,p_lov_query=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select DRDL01 D, DRKY R',
'from vt_jde_udcjde@datadl where drsy = ''12'' and drrt = ''22''',
'order by 2;'))
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_return_column_name=>'R'
,p_display_column_name=>'D'
,p_group_sort_direction=>'ASC'
,p_default_sort_direction=>'ASC'
,p_version_scn=>115898609668
);
wwv_flow_imp.component_end;
end;
/
