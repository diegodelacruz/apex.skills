prompt --application/shared_components/user_interface/lovs/lov_finz_pgi_tipometododistribucion
begin
--   Manifest
--     LOV_FINZ_PGI_TIPOMETODODISTRIBUCION
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>109
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(118594610075125436)
,p_lov_name=>'LOV_FINZ_PGI_TIPOMETODODISTRIBUCION'
,p_lov_query=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ID_TABLA||'' - ''||DESCRIPCION DESCRIPCION,ID_TABLA ',
'FROM DATA.T_CORP_UDC ',
'WHERE ID_CABECERA = ''FINZ_PGI01'' ',
'AND ACTIVO =''1'' ',
'ORDER BY TO_NUMBER(NVL(VALOR3,0))'))
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_return_column_name=>'ID_TABLA'
,p_display_column_name=>'DESCRIPCION'
,p_group_sort_direction=>'ASC'
,p_default_sort_direction=>'ASC'
,p_version_scn=>116754796842
);
wwv_flow_imp.component_end;
end;
/
