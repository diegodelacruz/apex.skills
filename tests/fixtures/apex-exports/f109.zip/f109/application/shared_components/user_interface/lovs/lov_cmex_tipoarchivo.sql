prompt --application/shared_components/user_interface/lovs/lov_cmex_tipoarchivo
begin
--   Manifest
--     LOV_CMEX_TIPOARCHIVO
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>109
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(579798104154684694)
,p_lov_name=>'LOV_CMEX_TIPOARCHIVO'
,p_lov_query=>'select descripcion, id_tabla from t_corp_udc where id_cabecera = ''CMEX_TARC'''
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_return_column_name=>'ID_TABLA'
,p_display_column_name=>'DESCRIPCION'
,p_default_sort_column_name=>'DESCRIPCION'
,p_default_sort_direction=>'ASC'
,p_version_scn=>1
,p_created_on=>wwv_flow_imp.dz('20250126033310Z')
,p_updated_on=>wwv_flow_imp.dz('20250126033310Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp.component_end;
end;
/
