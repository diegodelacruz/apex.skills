prompt --application/shared_components/user_interface/lovs/lov_estadocostosec
begin
--   Manifest
--     LOV_ESTADOCOSTOSEC
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>109
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(92683063879351084)
,p_lov_name=>'LOV_ESTADOCOSTOSEC'
,p_lov_query=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT',
'    entry,',
unistr('    b.descripcion descripci\00F3n,'),
unistr('    a.iddescripcion "id descripci\00F3n",'),
'    a.activo',
'FROM dp.t_pf_estadocostos a',
'INNER JOIN dp.t_generaldet b ON ( a.iddescripcion = b.id_tabla AND b.id_tgralcab = 598 )',
'WHERE a.activo = 1',
'    AND iddescripcion IN ( SELECT item FROM TABLE ( pk_commons.f_dividirtexto(( SELECT valor FROM "DATA"."T_CORP_UDC" WHERE id_cabecera = ''COMP_ESTCO'' AND id_tabla = ''DT'' ), '','') ) )',
'ORDER BY',
'    to_number(a.iddescripcion);'))
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_use_local_sync_table=>false
,p_return_column_name=>unistr('id descripci\00F3n')
,p_display_column_name=>unistr('DESCRIPCI\00D3N')
,p_group_sort_direction=>'ASC'
,p_default_sort_direction=>'ASC'
,p_version_scn=>1
);
wwv_flow_imp_shared.create_list_of_values_cols(
 p_id=>wwv_flow_imp.id(92683426783351086)
,p_query_column_name=>'ENTRY'
,p_display_sequence=>10
,p_data_type=>'NUMBER'
,p_is_visible=>'N'
,p_is_searchable=>'N'
);
wwv_flow_imp_shared.create_list_of_values_cols(
 p_id=>wwv_flow_imp.id(92683831885351087)
,p_query_column_name=>unistr('DESCRIPCI\00D3N')
,p_heading=>unistr('Descripci\00F3n')
,p_display_sequence=>10
,p_data_type=>'VARCHAR2'
);
wwv_flow_imp_shared.create_list_of_values_cols(
 p_id=>wwv_flow_imp.id(92684234405351087)
,p_query_column_name=>unistr('id descripci\00F3n')
,p_heading=>unistr('Id Descripci\00F3n')
,p_display_sequence=>20
,p_data_type=>'VARCHAR2'
);
wwv_flow_imp.component_end;
end;
/
