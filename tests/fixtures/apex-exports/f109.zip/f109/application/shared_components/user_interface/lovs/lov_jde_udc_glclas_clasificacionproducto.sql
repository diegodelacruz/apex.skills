prompt --application/shared_components/user_interface/lovs/lov_jde_udc_glclas_clasificacionproducto
begin
--   Manifest
--     LOV_JDE_UDC_GLCLAS_CLASIFICACIONPRODUCTO
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>109
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(83945546001268044)
,p_lov_name=>'LOV_JDE_UDC_GLCLAS_CLASIFICACIONPRODUCTO'
,p_lov_query=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select DRDL01 D, DRKY R ',
'from vt_jde_udcjde@datadl ',
'where drsy = ''41'' and drrt = ''9'';'))
,p_source_type=>'LEGACY_SQL'
,p_location=>'LOCAL'
,p_version_scn=>1
);
wwv_flow_imp.component_end;
end;
/
