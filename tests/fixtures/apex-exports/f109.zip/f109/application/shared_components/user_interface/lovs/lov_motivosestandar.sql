prompt --application/shared_components/user_interface/lovs/lov_motivosestandar
begin
--   Manifest
--     LOV_MOTIVOSESTANDAR
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>109
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(108781669872424098)
,p_lov_name=>'LOV_MOTIVOSESTANDAR'
,p_lov_query=>'.'||wwv_flow_imp.id(108781669872424098)||'.'
,p_location=>'STATIC'
,p_version_scn=>1
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(108781906798424101)
,p_lov_disp_sequence=>1
,p_lov_disp_value=>'# TURNOS'
,p_lov_return_value=>'001'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(108782396591424103)
,p_lov_disp_sequence=>2
,p_lov_disp_value=>unistr('EFICIENCIA M\00C1QUINA')
,p_lov_return_value=>'002'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(108782753933424103)
,p_lov_disp_sequence=>3
,p_lov_disp_value=>'HORAS X TURNO'
,p_lov_return_value=>'003'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(108783119581424103)
,p_lov_disp_sequence=>4
,p_lov_disp_value=>'UNIDADES POR MINUTO'
,p_lov_return_value=>'004'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(108783577867424103)
,p_lov_disp_sequence=>5
,p_lov_disp_value=>'LABOR'
,p_lov_return_value=>'005'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(108783906522424103)
,p_lov_disp_sequence=>6
,p_lov_disp_value=>'MAINTENENCE'
,p_lov_return_value=>'006'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(108784398371424103)
,p_lov_disp_sequence=>7
,p_lov_disp_value=>'OVER HEAD'
,p_lov_return_value=>'007'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(108784749940424103)
,p_lov_disp_sequence=>8
,p_lov_disp_value=>'UNIDADES POR  MES'
,p_lov_return_value=>'008'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(108785172915424104)
,p_lov_disp_sequence=>9
,p_lov_disp_value=>'ESTANDAR LABOR'
,p_lov_return_value=>'009'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(108785545111424104)
,p_lov_disp_sequence=>10
,p_lov_disp_value=>'ESTANDAR MAINTENENCE'
,p_lov_return_value=>'010'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(108785920595424104)
,p_lov_disp_sequence=>11
,p_lov_disp_value=>'ESTANDAR OVERHEAD'
,p_lov_return_value=>'011'
);
wwv_flow_imp.component_end;
end;
/
