prompt --application/shared_components/user_interface/lovs/lov_estajde
begin
--   Manifest
--     LOV_ESTAJDE
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>109
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(178293200891170070)
,p_lov_name=>'LOV_ESTAJDE'
,p_lov_query=>'.'||wwv_flow_imp.id(178293200891170070)||'.'
,p_location=>'STATIC'
,p_version_scn=>1
,p_created_on=>wwv_flow_imp.dz('20231220195556Z')
,p_updated_on=>wwv_flow_imp.dz('20231220195556Z')
,p_created_by=>'MALBAN'
,p_updated_by=>'MALBAN'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(178293591778170074)
,p_lov_disp_sequence=>1
,p_lov_disp_value=>'NUEVO'
,p_lov_return_value=>'0'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(178293916654170076)
,p_lov_disp_sequence=>2
,p_lov_disp_value=>'JDE'
,p_lov_return_value=>'1'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(178294339850170076)
,p_lov_disp_sequence=>3
,p_lov_disp_value=>'BASE FINANZAS'
,p_lov_return_value=>'9'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(178294781492170076)
,p_lov_disp_sequence=>4
,p_lov_disp_value=>'NO ACTIVO'
,p_lov_return_value=>'99'
);
wwv_flow_imp.component_end;
end;
/
