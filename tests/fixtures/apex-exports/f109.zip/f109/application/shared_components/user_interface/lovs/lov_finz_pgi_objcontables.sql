prompt --application/shared_components/user_interface/lovs/lov_finz_pgi_objcontables
begin
--   Manifest
--     LOV_FINZ_PGI_OBJCONTABLES
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>109
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(360690588878225486)
,p_lov_name=>'LOV_FINZ_PGI_OBJCONTABLES'
,p_lov_query=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT   ',
'     trim(gmobj) gmobj',
'     ,trim(gmobj) ||'' ''||TRIM(gmdl01) gmdl01',
'    ,PK_COMMONS.F_JDE2G(GMUPMJ)GMUPMJ',
'    ,trim(trim(gmobj) ) GMAID',
'    /*,a.**/',
'    ,TRIM(gmsub) ',
'FROM f0901@jdedtadl a',
'WHERE TRIM(gmsub) IS   NULL',
'AND GMMCU=''     1MODELO''',
'order by GMOBJ, GMSUB,  GMUPMJ DESC,gmdl01'))
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_return_column_name=>'GMAID'
,p_display_column_name=>'GMDL01'
,p_group_sort_direction=>'ASC'
,p_default_sort_direction=>'ASC'
,p_version_scn=>121452391357
,p_created_on=>wwv_flow_imp.dz('20260219195140Z')
,p_updated_on=>wwv_flow_imp.dz('20260219195312Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_shared.create_list_of_values_cols(
 p_id=>wwv_flow_imp.id(360690861248225504)
,p_query_column_name=>'GMAID'
,p_heading=>'ID de cuenta'
,p_display_sequence=>10
,p_data_type=>'VARCHAR2'
,p_is_searchable=>'N'
,p_created_on=>wwv_flow_imp.dz('20260219195140Z')
,p_updated_on=>wwv_flow_imp.dz('20260219195312Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_shared.create_list_of_values_cols(
 p_id=>wwv_flow_imp.id(360691299925225505)
,p_query_column_name=>'GMOBJ'
,p_heading=>'Gmobj'
,p_display_sequence=>10
,p_data_type=>'VARCHAR2'
,p_created_on=>wwv_flow_imp.dz('20260219195140Z')
,p_updated_on=>wwv_flow_imp.dz('20260219195312Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_shared.create_list_of_values_cols(
 p_id=>wwv_flow_imp.id(360691653873225505)
,p_query_column_name=>'GMDL01'
,p_heading=>unistr('Descripci\00F3n')
,p_display_sequence=>20
,p_data_type=>'VARCHAR2'
,p_created_on=>wwv_flow_imp.dz('20260219195140Z')
,p_updated_on=>wwv_flow_imp.dz('20260219195312Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_shared.create_list_of_values_cols(
 p_id=>wwv_flow_imp.id(360692478183225505)
,p_query_column_name=>'GMUPMJ'
,p_heading=>'Fecha - Actualizada'
,p_display_sequence=>50
,p_data_type=>'DATE'
,p_created_on=>wwv_flow_imp.dz('20260219195140Z')
,p_updated_on=>wwv_flow_imp.dz('20260219195312Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp.component_end;
end;
/
