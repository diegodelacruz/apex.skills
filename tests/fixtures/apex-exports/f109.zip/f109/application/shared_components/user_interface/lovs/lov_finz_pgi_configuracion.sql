prompt --application/shared_components/user_interface/lovs/lov_finz_pgi_configuracion
begin
--   Manifest
--     LOV_FINZ_PGI_CONFIGURACION
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>109
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(118255539256470970)
,p_lov_name=>'LOV_FINZ_PGI_CONFIGURACION'
,p_lov_query=>wwv_flow_string.join(wwv_flow_t_varchar2(
'WITH ',
'CPN AS (SELECT DESCRIPCION CPNDESCRIPCION,ID_TABLA CPNID FROM t_corp_udc where id_cabecera=''COMP_CGZCM'' and ID_TABLA!=''00000'' /*and ACTIVO=''1''*/),',
'TOB AS (SELECT DESCRIPCION TOBDESCRIPCION,ID_TABLA TOBID FROM T_CORP_UDC WHERE ID_CABECERA=''FINZ_GT02'' AND ID_TABLA  in(''001'')  AND ACTIVO=''1''  ),',
'SQM AS (SELECT DESCRIPCION SQMDESCRIPCION,ID_TABLA SQMID FROM T_CORP_UDC WHERE ID_CABECERA=''FINZ_GT04'' AND ID_TABLA!=''000''  AND ACTIVO=''1''),',
'erp as (SELECT DESCRIPCION ERPDESCRIPCION,ID_TABLA ERPID FROM T_CORP_UDC WHERE ID_CABECERA=''FINZ_GT03'' AND ID_TABLA!=''000'' AND ACTIVO=''1''  order by to_number(ID_TABLA)',
')',
'select ID,',
'    CPNDESCRIPCION COMPANIA,',
'    DECODE(UPPER(TABLAPROCESO),''T_FINZ_DISTRIBUCIONASC'',''ASIENTOS CONTABLES'',''T_FINZ_DISTRIBUCIONVTA'',''VENTAS'') TABLAPROCESO,  ',
'    DESCRIPCION,',
'    ESTADO,',
'    ERPDESCRIPCION ERP,',
'    SQMDESCRIPCION ESQUEMA,',
'    TOBDESCRIPCION TIPOOBJETO,',
'    OBJETO    ',
'from T_FINZ_DISTRIBUCIONCFG',
'LEFT JOIN TOB ON TIPOOBJETO=TOBID',
'LEFT JOIN SQM ON ESQUEMA=SQMID',
'LEFT JOIN CPN ON COMPANIA=CPNID',
'LEFT JOIN ERP ON ERP=ERPID',
'WHERE (COMPANIA= :G_COMPANIADIST)',
'order by CPNDESCRIPCION,DESCRIPCION'))
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_return_column_name=>'ID'
,p_display_column_name=>'DESCRIPCION'
,p_group_sort_direction=>'ASC'
,p_default_sort_column_name=>'DESCRIPCION'
,p_default_sort_direction=>'ASC'
,p_version_scn=>117208123872
);
wwv_flow_imp_shared.create_list_of_values_cols(
 p_id=>wwv_flow_imp.id(118256098799483122)
,p_query_column_name=>'ID'
,p_display_sequence=>10
,p_data_type=>'NUMBER'
,p_is_visible=>'N'
,p_is_searchable=>'N'
);
wwv_flow_imp_shared.create_list_of_values_cols(
 p_id=>wwv_flow_imp.id(118256490226483122)
,p_query_column_name=>'COMPANIA'
,p_heading=>'Compania'
,p_display_sequence=>20
,p_data_type=>'VARCHAR2'
);
wwv_flow_imp_shared.create_list_of_values_cols(
 p_id=>wwv_flow_imp.id(118256896076483123)
,p_query_column_name=>'DESCRIPCION'
,p_heading=>'Descripcion'
,p_display_sequence=>30
,p_data_type=>'VARCHAR2'
);
wwv_flow_imp_shared.create_list_of_values_cols(
 p_id=>wwv_flow_imp.id(118257274546483123)
,p_query_column_name=>'TABLAPROCESO'
,p_heading=>'Proceso'
,p_display_sequence=>40
,p_data_type=>'VARCHAR2'
);
wwv_flow_imp.component_end;
end;
/
