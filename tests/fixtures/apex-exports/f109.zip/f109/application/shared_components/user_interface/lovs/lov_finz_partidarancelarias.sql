prompt --application/shared_components/user_interface/lovs/lov_finz_partidarancelarias
begin
--   Manifest
--     LOV_FINZ_PARTIDARANCELARIAS
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>109
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(216498906088861323)
,p_lov_name=>'LOV_FINZ_PARTIDARANCELARIAS'
,p_lov_query=>wwv_flow_string.join(wwv_flow_t_varchar2(
unistr('select vt_cat.drky , vt_cat.drdl01, vt_cat.drdl02, decode(trim(vt_cat.drsphd),''S'',''S\00CD'',''NO'') ct'),
',trim(DRKY)||'' - ''||trim(DRDL01)||'' ''||trim(DRDL02) DRDL00',
'from data.vt_jde_udcjde vt_cat ',
'where vt_cat.drsy = ''41'' and vt_cat.drrt = ''10'' and DRKY is not null and DRKY!=''N/A'''))
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_use_local_sync_table=>false
,p_return_column_name=>'DRKY'
,p_display_column_name=>'DRDL00'
,p_group_sort_direction=>'ASC'
,p_default_sort_column_name=>'DRDL00'
,p_default_sort_direction=>'ASC'
,p_version_scn=>123513859571
);
wwv_flow_imp_shared.create_list_of_values_cols(
 p_id=>wwv_flow_imp.id(216499274881861371)
,p_query_column_name=>'DRKY'
,p_heading=>unistr('C\00F3digo')
,p_display_sequence=>5
,p_data_type=>'VARCHAR2'
);
wwv_flow_imp_shared.create_list_of_values_cols(
 p_id=>wwv_flow_imp.id(216500411151861373)
,p_query_column_name=>'DRDL01'
,p_heading=>'P. Arancelaria'
,p_display_sequence=>10
,p_data_type=>'VARCHAR2'
);
wwv_flow_imp_shared.create_list_of_values_cols(
 p_id=>wwv_flow_imp.id(216509558267872344)
,p_query_column_name=>'DRDL00'
,p_heading=>'Drdl00'
,p_display_sequence=>10
,p_data_type=>'VARCHAR2'
,p_is_visible=>'N'
);
wwv_flow_imp_shared.create_list_of_values_cols(
 p_id=>wwv_flow_imp.id(216500010083861373)
,p_query_column_name=>'DRDL02'
,p_heading=>unistr('Descripci\00F3n')
,p_display_sequence=>20
,p_data_type=>'VARCHAR2'
);
wwv_flow_imp_shared.create_list_of_values_cols(
 p_id=>wwv_flow_imp.id(216499685838861372)
,p_query_column_name=>'CT'
,p_heading=>'Aplica CT'
,p_display_sequence=>30
,p_data_type=>'VARCHAR2'
);
wwv_flow_imp.component_end;
end;
/
