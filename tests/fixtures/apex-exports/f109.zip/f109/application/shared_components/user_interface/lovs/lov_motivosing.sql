prompt --application/shared_components/user_interface/lovs/lov_motivosing
begin
--   Manifest
--     LOV_MOTIVOSING
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>109
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(108787365326430302)
,p_lov_name=>'LOV_MOTIVOSING'
,p_lov_query=>'.'||wwv_flow_imp.id(108787365326430302)||'.'
,p_location=>'STATIC'
,p_version_scn=>1
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(108802517564491927)
,p_lov_disp_sequence=>1
,p_lov_disp_value=>'# TURNOS'
,p_lov_return_value=>'001'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(108788007097430309)
,p_lov_disp_sequence=>2
,p_lov_disp_value=>unistr('EFICIENCIA M\00C1QUINA')
,p_lov_return_value=>'002'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(108788484342430310)
,p_lov_disp_sequence=>3
,p_lov_disp_value=>'HORAS X TURNO'
,p_lov_return_value=>'003'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(108788878357430310)
,p_lov_disp_sequence=>4
,p_lov_disp_value=>'UNIDADES POR MINUTO'
,p_lov_return_value=>'004'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(108789274735430310)
,p_lov_disp_sequence=>5
,p_lov_disp_value=>'LABOR'
,p_lov_return_value=>'005'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(108789680620430310)
,p_lov_disp_sequence=>6
,p_lov_disp_value=>'MAINTENENCE'
,p_lov_return_value=>'006'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(108790066689430310)
,p_lov_disp_sequence=>7
,p_lov_disp_value=>'OVER HEAD'
,p_lov_return_value=>'007'
);
wwv_flow_imp.component_end;
end;
/
