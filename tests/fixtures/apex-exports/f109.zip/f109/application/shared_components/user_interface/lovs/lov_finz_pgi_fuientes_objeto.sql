prompt --application/shared_components/user_interface/lovs/lov_finz_pgi_fuientes_objeto
begin
--   Manifest
--     LOV_FINZ_PGI_FUIENTES_OBJETO
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>109
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(142729312902456972)
,p_lov_name=>'LOV_FINZ_PGI_FUIENTES_OBJETO'
,p_lov_query=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT',
'    case OWNER||''.''|| TABLE_NAME ',
'        when  ''DATA.T_FINZ_DISTRIBUCIONASC'' then ''CONTABLE(MODULO)''',
'        when  ''DATA.T_FINZ_DISTRIBUCIONTMP'' then ''T. TEMPORAL(MES)''',
unistr('        when  ''DATA.T_FINZ_DISTRIBUCIONVTA'' then ''FACTURACI\00D3N(MODULO)'''),
'        when  ''DATA.T_TMP_A'' then ''T. APEX TEMPORAL A''',
'        when  ''DATA.T_TMP_B'' then ''T. APEX TEMPORAL B''',
'    end D',
',OWNER||''.''|| TABLE_NAME R FROM ALL_TABLES',
'WHERE TABLE_NAME IN (''T_FINZ_DISTRIBUCIONVTA'',''T_FINZ_DISTRIBUCIONTMP'',''T_FINZ_DISTRIBUCIONASC'',''T_TMP_B'',''T_TMP_A'')  ',
'AND OWNER=''DATA''',
'UNION ALL',
'SELECT',
'    case OWNER||''.''|| VIEW_NAME ',
'        when  ''DATA.VT_FINZ_DISTRIBUCIONTMP_MES'' then ''V. VENTAS NETA(MES)''',
'    end D',
'',
',OWNER||''.''|| VIEW_NAME R FROM all_views',
'WHERE VIEW_NAME IN (''VT_FINZ_DISTRIBUCIONTMP_MES'')  ',
'AND OWNER=''DATA'' ',
'ORDER BY 1'))
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_return_column_name=>'R'
,p_display_column_name=>'D'
,p_group_sort_direction=>'ASC'
,p_default_sort_direction=>'ASC'
,p_version_scn=>122786762391
,p_updated_on=>wwv_flow_imp.dz('20260327022343Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp.component_end;
end;
/
