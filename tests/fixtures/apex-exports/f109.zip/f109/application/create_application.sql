prompt --application/create_application
begin
--   Manifest
--     FLOW: 109
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>109
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_imp_workspace.create_flow(
 p_id=>wwv_flow.g_flow_id
,p_owner=>nvl(wwv_flow_application_install.get_schema,'DATA')
,p_name=>nvl(wwv_flow_application_install.get_application_name,'Finanzas')
,p_alias=>nvl(wwv_flow_application_install.get_application_alias,'A109')
,p_page_view_logging=>'YES'
,p_page_protection_enabled_y_n=>'Y'
,p_checksum_salt=>'304BAA408E76D3E95E53AA3E9330A449B61159667EAC33607534100D333540AE'
,p_bookmark_checksum_function=>'SH1'
,p_accept_old_checksums=>false
,p_compatibility_mode=>'5.1'
,p_accessible_read_only=>'N'
,p_session_state_commits=>'IMMEDIATE'
,p_flow_language=>'es-ec'
,p_flow_language_derived_from=>'FLOW_PRIMARY_LANGUAGE'
,p_allow_feedback_yn=>'Y'
,p_direction_right_to_left=>'N'
,p_flow_image_prefix => nvl(wwv_flow_application_install.get_image_prefix,'')
,p_documentation_banner=>'Application created from create application wizard 2019.10.21.'
,p_authentication_id=>wwv_flow_imp.id(37760996557106473)
,p_application_tab_set=>1
,p_logo_type=>'T'
,p_logo_text=>'Finanzas'
,p_app_builder_icon_name=>'app-icon.svg'
,p_proxy_server=>nvl(wwv_flow_application_install.get_proxy,'')
,p_no_proxy_domains=>nvl(wwv_flow_application_install.get_no_proxy_domains,'')
,p_flow_version=>'Release 1.0'
,p_flow_status=>'AVAILABLE_W_EDIT_LINK'
,p_flow_unavailable_text=>'This application is currently unavailable at this time.'
,p_exact_substitutions_only=>'Y'
,p_browser_cache=>'N'
,p_browser_frame=>'D'
,p_referrer_policy=>'strict-origin-when-cross-origin'
,p_pass_ecid=>'N'
,p_authorize_batch_job=>'N'
,p_rejoin_existing_sessions=>'N'
,p_csv_encoding=>'Y'
,p_auto_time_zone=>'N'
,p_tokenize_row_search=>'N'
,p_friendly_url=>'N'
,p_substitution_string_01=>'APP_NAME'
,p_substitution_value_01=>'Finanzas'
,p_substitution_string_02=>'APP_MODULO'
,p_substitution_value_02=>'FINZ'
,p_substitution_string_03=>'APP_OBJETO'
,p_substitution_value_03=>'RETENCION DE PAGO'
,p_substitution_string_04=>'APP_PAGINA'
,p_substitution_string_05=>'APP_OBJETO_STDMNF'
,p_substitution_value_05=>'ESTANDARESMANUFACTURA'
,p_substitution_string_06=>'APP_OBJETO_VARGTOMNF'
,p_substitution_value_06=>'VARGASTOSMANUFACTURA'
,p_created_on=>wwv_flow_imp.dz('20230705164633Z')
,p_last_updated_on=>wwv_flow_imp.dz('20260812185112Z')
,p_created_by=>'CVACA'
,p_last_updated_by=>'DDELACRUZ'
,p_file_prefix => nvl(wwv_flow_application_install.get_static_app_file_prefix,'')
,p_files_version=>24
,p_print_server_type=>'INSTANCE'
,p_file_storage=>'DB'
,p_is_pwa=>'N'
);
wwv_flow_imp.component_end;
end;
/
