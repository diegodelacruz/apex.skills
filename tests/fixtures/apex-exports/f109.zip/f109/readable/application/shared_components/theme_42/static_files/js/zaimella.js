
function mensaje(Type,Msg){
    var findSpan = $('#APEX_SUCCESS_MESSAGE').length;
    if (findSpan == 1){
        $('#APEX_SUCCESS_MESSAGE').remove();

        // Re-Run
        mensaje(Type,Msg);
    } else{
            // Adding HTML code!
            $('body').prepend(
                '<span id="APEX_SUCCESS_MESSAGE" class="apex-page-success"><div class="t-Body-alert">'
                + '<div class="t-Alert t-Alert--defaultIcons t-Alert--success t-Alert--horizontal t-Alert--page t-Alert--colorBG" '
                + 'id="t_Alert_Success" role="alert" style="display: none;"><div class="t-Alert-wrap"><div class="t-Alert-icon">'
                + '<span style="color: white; font-size: 25px;" class="fa fa-check fa-xl fa-anim-flash"></span></div>'
                + '<div class="t-Alert-content"><div class="t-Alert-header"><h2 class="t-Alert-title">'
                + Msg
                + '</h2></div></div><div class="t-Alert-buttons"><button class="t-Button t-Button--noUI t-Button--icon t-Button--closeAlert" '
                + 'type="button" title="Close Notification"><span class="t-Icon icon-close"></span></button></div></div></div></div></span>');

                $('#t_Alert_Success > div > div.t-Alert-buttons > button[title="Close Notification"]')
                    .on('click',function(){
                    $('#APEX_SUCCESS_MESSAGE').remove();
                });

            if(Type=='exito'){
                $.when(
                    // Auto close success message
                    $('#t_Alert_Success').show(),
                    $('#t_Alert_Success').fadeIn(300).delay(2000).fadeOut(400)
                ).then(
                        function(){
                            $('#APEX_SUCCESS_MESSAGE').remove();
                        });

            }else if(Type=='error'){
                    // Set error style ...
                    $('#t_Alert_Success').attr('style','background-color: #e95b54;');
                    $('#t_Alert_Success div div.t-Alert-icon span').removeClass('fa-check');
                    $('#t_Alert_Success div div.t-Alert-icon span').addClass('fa-close');
                    $('#t_Alert_Success').show();
            }       
    }
}

function mensajeExito(Msg){
	mensaje('exito',Msg);
}

function mensajeError(Msg){
	mensaje('error',Msg);
}
//FLUJO DE APROBACION
var restBuscarToken='http://pruebas.zaimella.com/FlujoAprobacion-WebService/rest/flujoAprobacion/buscarFlujoToken/';
var compania;
var modulo;
var usuario;
var objeto;
var objetoId;
var carga;


function buscarFlujoToken(detalle, token, resultado) {
	var url = restBuscarToken+detalle+'/'+token;
    console.log("buscarFlujoToken url: "+url);
    jQuery.ajax({
        type: "GET",
        url: url,
        
        dataType: "jsonp",
        success: function (data, status, jqXHR) {           
            resultado(data);
        },
        error: function (jqXHR, status) {
            resultado({
            "mensaje": "Error al buscar flujo con Token",
            "codigo": "0",
            "exito": false,
            "resultado": ""
			});
        }
    });
}

function buscarFlujoAprobacion(detalle, token, itemCompania, itemModulo, itemUsuario, itemObjeto, itemId){	
		buscarFlujoToken(detalle,token, function (trama) {		
		console.log("resultado: "+trama.exito);
		console.log("resultado: "+trama.resultado);
			if (trama.exito === true) {
				compania= trama.resultado.codCompania;
				modulo = trama.resultado.codModulo;
				usuario = trama.resultado.usuarioActual;
				objeto= trama.resultado.entidadClase;
				objetoId = trama.resultado.entidadId;	
				llenarItemFlujoAprobacion(itemCompania, itemModulo, itemUsuario, itemObjeto, itemId);		
				apex.server.process("CARGAR_DATOS", 
				{ x01: trama.resultado.codCompania, x02: trama.resultado.codModulo , x03: trama.resultado.usuarioActual,
					x04: trama.resultado.entidadClase, x05: trama.resultado.entidadId},
				   {
					  success: function(pData) {
						 console.log("process CARGAR_DATOS" + pData);
					  }
				   }
				);	
				mensaje('exito', 'Se genero con exito');				
			} else {					
				mensaje('error', trama.mensaje);   
				alert(trama.mensaje);				
			}
		});
}

function llenarItemFlujoAprobacion(itemCompania, itemModulo, itemUsuario, itemObjeto, itemId){
	console.log("llenarItemFlujoAprobacion "
	+itemCompania+": "+compania+" "
	+itemModulo+": "+modulo+" "+itemUsuario+": "+usuario+" "
	+itemObjeto+": "+objeto+" "+itemId+": "+objetoId+" "
	);
	apex.item(itemCompania).setValue(compania)
	apex.item(itemModulo).setValue(modulo)
	apex.item(itemUsuario).setValue(usuario)
	apex.item(itemObjeto).setValue(objeto)
	apex.item(itemId).setValue(objetoId)	
}

/*INTERACTIVE GRID 
function (config) {
 return cargarToolbar(config);
}
*/
function cargarToolbar(config) {
  
  config.toolbarData = [
        {
            groupTogether: true,
            controls: [
                {
                    type: "TEXT",
                    id: "search_field",
                    placeholder: "Buscar todos",
                    enterAction: "search"
                }
             ]
        },
        {
            align: "end",
            controls: [
				{
                    type: "BUTTON",
                    action: "show-download-dialog",
                    title: "Descargar",
                    id:"btnDescargar",
                    label: " ",
                    icon:"fa fa-file-excel-o"
                },
                {
                    type: "BUTTON",
                    action: "save",
                    title: "Guardar",
                    id:"btnGuardar",
                    label: " ",
                    icon:"fa fa-save"
                },
                {
                    type: "BUTTON",
                    action: "row-add-row",
                    title: "Agregar",
                    id:"btnAgregar",
                    label: " ",
                    icon:"fa fa-plus"
                },
                {
                    type: "BUTTON",
                    id:"btnEliminar",
                    action: "selection-delete",
                    title: "Eliminar",
                    label: " ",
                    icon:"fa fa-trash"
                }
                
            ]
        }
    ];
    
      config.initActions = function( actions ) {
        actions.remove("single-row-view");
        actions.remove("selection-refresh");
        actions.remove("selection-copy");
        actions.remove("selection-revert");
        actions.remove("selection-duplicate");
        actions.remove("row-refresh");
        actions.remove("row-revert");
        var selectionDelete = actions.lookup("selection-delete"),
            originalDeleteAction = selectionDelete.action; 
        var save = actions.lookup("save"), 
            originalSave = save.action;
         selectionDelete.action = function(_, el) {
             apex.message.confirm("¿Esta seguro de eliminar el registro?", function(ok) {
                 if (ok){
                    originalDeleteAction(_, el);
                    originalSave(_,el);
                 }
             });
        };
    };
    
    return config;
}


function moverToolbar() {
   $(".btnAccion").each(function () { 
		$(this).appendTo($(this).parent().parent().parent().find(".a-IG-header .a-Toolbar-groupContainer.a-Toolbar-groupContainer--end .a-Toolbar-group"));
	});
	
	$(".t-Region-headerItems.t-Region-headerItems--buttons").each(function () { 
		$(this).appendTo($(this).parent().parent().parent().find(".a-IRR-toolbar"));
	});
}

window.onload = function() {
 $('.apex-item-wrapper--rich-text-editor').find('br').remove();
};


var spinner;

function mostrarBarra(){
//	spinner = apex.util.showSpinner();	
	spinner = apex.widget.waitPopup();
}

function ocultarBarra(){
	spinner.remove();
}


//funcion para generar una tabla html desde json
//AUTOR: JOSE MASABANDA C. 15/05/2025
// === Filtros estilo Excel integrados ===
// Congela encabezado+filtros y columnas con freezeHeader() y freezeCols() como ya tienes.
// === Filtros estilo Excel + freeze. Versión que SÍ filtra (valores desde el DOM) ===
function f_genera_tablahtml_json(
	p_data, p_columnas, p_visibles, p_acc_edita, p_acc_borra, p_acc_copia,
	p_columnas_orden, p_proceso, p_filtro
	){
  if (!p_data || p_data.trim()==="") { console.log("Sin datos."); return; }

  try{
    let jsonData   = JSON.parse(p_data);
    let configData = JSON.parse(p_columnas);
    const regionId = "report_detail";
    if (!jsonData.length){ $("#"+regionId).html("<p>No hay datos disponibles.</p>"); return; }

    let allCols = configData.map(col => { col.ALIAS = col.ALIAS.replaceAll('"',''); return col; });
    function mostrarColumna(col){
      if (p_visibles===0) return col.VISIBLE==="N";
      if (p_visibles===1) return col.VISIBLE==="Y";
      return true;
    }

    if (p_columnas_orden && typeof p_columnas_orden==="string"){
      const ordenKeys = p_columnas_orden.split(",").map(k=>k.trim());
      jsonData.sort((a,b)=>{
        for (let key of ordenKeys){ if (a[key]<b[key]) return -1; if (a[key]>b[key]) return 1; }
        return 0;
      });
    }

    const maxID = Math.max(...jsonData.map(i=>i.ID||0)) + 1000;
    let newRowID = null;
    if (p_acc_edita===2){
      const newRow = { ID:maxID, IDPADRE:maxID };
      allCols.forEach(c=>{ if(!(c.ALIAS in newRow)) newRow[c.ALIAS] = ""; });
      jsonData.unshift(newRow);
      newRowID = maxID;
    }

    if (!document.getElementById("flt-excel-style")){
      const st = document.createElement("style");
      st.id = "flt-excel-style";
      st.textContent = `
        .hdr-cell{display:flex;align-items:center;gap:.25rem;justify-content:space-between}
        .hdr-title{white-space:nowrap}
        .flt-btn,.flt-clear{border:0;background:transparent;cursor:pointer;padding:2px}
        .flt-btn.active{color:#1a7f5a}
        .flt-popup{position:fixed;min-width:240px;background:#fff;border:1px solid #c6c6c6;border-radius:6px;
          box-shadow:0 8px 24px rgba(0,0,0,.12);padding:8px;z-index:1000}
        .flt-popup .hdr{font-size:12px;margin-bottom:6px;color:#555}
        .flt-popup .row{margin-bottom:6px}
        .flt-list{max-height:160px;overflow:auto;border:1px solid #eee;padding:6px;border-radius:4px}
        .flt-actions{display:flex;gap:8px;justify-content:flex-end;margin-top:8px}
        .flt-actions button{padding:6px 10px;border-radius:4px;border:1px solid #c6c6c6;background:#f5f5f5;cursor:pointer}
        .flt-actions .ok{background:#18a27a;color:#fff;border-color:#18a27a}
        .btn-act{border:1px solid #c6c6c6;border-radius:4px;background:#f5f5f5;padding:2px 6px;cursor:pointer}
      `;
      document.head.appendChild(st);
    }

    const getValidadorSRI = (row)=>{
      const k = Object.keys(row).find(k => k.replace(/\s|_/g,'').toUpperCase()==='VALIDADORSRI');
      return ((k ? row[k] : "") + "").trim().toUpperCase();
    };

    const parseFecha = s=>{
      if (!s) return null;
      const m1 = String(s).match(/^(\d{1,2})[\/\-](\d{1,2})[\/\-](\d{4})$/);
      if (m1){
        const d=+m1[1], mo=+m1[2]-1, y=+m1[3];
        const dt = new Date(y,mo,d);
        return isNaN(dt.getTime()) ? null : dt;
      }
      const dt=new Date(s);
      return isNaN(dt.getTime()) ? null : dt;
    };

    const toNum = v=>{
      if (v==null || v==="") return NaN;
      let s = String(v).trim().replace(/^\((.*)\)$/,"-$1").replace(/[^0-9,.\-]/g,"");
      const lastDot=s.lastIndexOf("."), lastCom=s.lastIndexOf(",");
      if (lastDot>lastCom) s=s.replace(/,/g,"");
      else if (lastCom>lastDot){ s=s.replace(/\./g,""); s=s.replace(/,/g,"."); }
      else s=s.replace(/[.,]/g,"");
      const n = parseFloat(s);
      return Number.isFinite(n)?n:NaN;
    };

    // === NUEVO: helpers para celdas con HTML (<ul><li>) ===
    function _extractLI(html){
      if (!html) return [];
      const d = document.createElement("div");
      d.innerHTML = String(html);
      const lis = Array.from(d.querySelectorAll("li")).map(li => li.textContent.trim()).filter(Boolean);
      if (lis.length) return lis;
      const txt = d.textContent.trim();
      return txt ? [txt] : [];
    }
    function _cellInfo($td){
      const alias = String($td.attr("data-alias")||"").toUpperCase();
      const tipo  = String($td.data("tipodato")||"C");
      const rawHTML = $td.get(0)?.innerHTML || "";
      if (alias === "VALIDACIONES"){
        const tokens = _extractLI(rawHTML);
        return { alias, tipo, text: tokens.join(" | "), tokens };
      }
      const d = document.createElement("div"); d.innerHTML = rawHTML;
      const text = d.textContent.trim();
      return { alias, tipo, text, tokens:[text] };
    }

    const filtrosExcel = (window._filtrosExcel = window._filtrosExcel || {});
    if (p_filtro===1){
      const colVal = allCols.find(c=>c.ALIAS.toUpperCase()==="VALIDACIONES");
      if (colVal && !filtrosExcel[colVal.ALIAS]) filtrosExcel[colVal.ALIAS] = { mode:"notnull" };
    }

    let monedaCols = [];
    const showAcc = (p_proceso==='009' || p_proceso==='004');

    let tableHtml = `
    <div id="scroll-top" style="overflow-x:auto;overflow-y:hidden;height:20px;width:100%;">
      <div id="scroll-top-inner"></div>
    </div>
    <div id="scroll-bottom" style="overflow-x:auto;width:100%;">
      <div id="scroll-bottom-inner" style="max-height:700px;overflow-y:auto;">
        <table border="1" class="t-Report-report" style="min-width:800px;table-layout:auto;white-space:nowrap;border-collapse:collapse;">
          <thead>
            <tr class="color-light-title">`;

    if (p_acc_borra===1) tableHtml += `<th class='t-Report-colHead' data-alias='#BORRAR'><div class="hdr-cell"><span class="hdr-title">-</span></div></th>`;
    if (p_acc_copia===1) tableHtml += `<th class='t-Report-colHead' data-alias='#COPIAR'><div class="hdr-cell"><span class="hdr-title">-</span></div></th>`;
    if (showAcc)         tableHtml += `<th class='t-Report-colHead' data-alias='DETALLAR'><div class="hdr-cell"><span class="hdr-title">-</span></div></th>`;

    allCols.forEach(col=>{
      const thStyle = mostrarColumna(col)? "" : "display:none;";
      const title = f_capitalizarCadena(col.ALIAS);
      if (col.TIPODATO==="M") monedaCols.push(col.ALIAS);
      tableHtml += `
      <th class='t-Report-colHead' style="width:250px;${thStyle}" data-alias="${col.ALIAS}" data-tipodato="${col.TIPODATO}">
        <div class="hdr-cell">
          <span class="hdr-title">${title}</span>
          <span>
            <button type="button" class="flt-btn"  data-col="${col.ALIAS}" data-tipo="${col.TIPODATO}" title="Filtrar"><i class="fa fa-filter"></i></button>
            <button type="button" class="flt-clear" data-col="${col.ALIAS}" title="Limpiar" style="display:none"><i class="fa fa-times"></i></button>
          </span>
        </div>
      </th>`;
    });

    tableHtml += `</tr><tr class="filtro-header">`;
    if (p_acc_borra===1) tableHtml += `<th></th>`;
    if (p_acc_copia===1) tableHtml += `<th></th>`;
    if (showAcc)         tableHtml += `<th></th>`;
    allCols.forEach(col=>{
      const thStyle = mostrarColumna(col)? "" : "display:none;";
      const def = (col.ALIAS.toUpperCase()==="VALIDACIONES" && p_filtro===1) ? JSON.stringify({mode:"notnull"}) : "";
      tableHtml += `<th style="${thStyle}"><input type="hidden" class="filtro-input" data-col="${col.ALIAS}" value='${def}'></th>`;
    });
    tableHtml += `</tr></thead><tbody>`;

    let totales={}, totalesGenerales={}; monedaCols.forEach(c=>{ totales[c]=0; totalesGenerales[c]=0; });

    jsonData.forEach((row,i)=>{
      const rowClass = (i%2===0)?'nth_child_even':'nth_child_odd';
      let rowvali = (row['VALIDACIONES']||'').toUpperCase();
      let trStyle = rowvali==="N DOC ANTERIOR" ? 'tr_secini' : rowvali==="REVISION SECUENCIAL" ? 'tr_secper' : "";
      let tr = `<tr class="tr-hover ${rowClass} ${trStyle}">`;

      const addEmptyActions = ()=>{ let h=""; if (p_acc_borra===1) h+="<td></td>"; if (p_acc_copia===1) h+="<td></td>"; if (showAcc) h+="<td></td>"; return h; };

      if (rowvali!=="N DOC ANTERIOR" && rowvali!=="REVISION SECUENCIAL"){
        if (p_acc_borra===1) tr += `<td><a href='javascript:f_setearRegistro(${row['ID']},${row['IDPADRE']},"borrar")'><span class='fa fa-trash-o'></span></a></td>`;
        if (p_acc_copia===1){
          tr += (row['ID']===row['IDPADRE'])
            ? `<td><a href='javascript:f_setearRegistro(${row['ID']},${row['IDPADRE']},"duplicar")'><span class='fa fa-clone'></span></a></td>`
            : `<td></td>`;
        }
        if (p_proceso==='009'){
          const tdTip = String(row['TIPO_DOC']||'').toUpperCase();
          const aplica = tdTip==='PJ';
          const btn = aplica? `<a href='javascript:f_setearPopUp(${row['NUM_DOC']},"${row['TIPO_DOC']}","reemb")'><span class='fa fa-eye'></span></a>`: ``;
          tr += `<td>${btn}</td>`;
        } else if (p_proceso==='004'){
          tr += `<td><a href='javascript:f_setearPopUp(${row['NUMERO_DOCUMENTO']},"${row['TP_DOC']}","detal")'><span class='fa fa-eye'></span></a></td>`;
        }
      } else {
        tr += addEmptyActions();
      }

      allCols.forEach(col=>{
        const v_alias = col.ALIAS;
        let value = row[v_alias];
        let formattedValue = value ?? "-";
        let align = "left";
        let editable = "";
        let styleEditable = "";

        if (!["ID","IDPADRE","VALIDACION","VALIDACIONES"].includes(v_alias.toUpperCase())){
          if ((p_acc_edita===1 || p_acc_edita===2) && col.EDITABLE==="Y"){ editable="contenteditable='true'"; styleEditable="background-color:#f0ffff;"; }
          if ((p_acc_edita===2) && row['ID']===newRowID){ editable="contenteditable='true'"; styleEditable="background-color:#f0ffff;"; }
        }

        if (col.TIPODATO==="F" && value){
          const d = parseFecha(value);
          formattedValue = d ? `${String(d.getDate()).padStart(2,'0')}/${String(d.getMonth()+1).padStart(2,'0')}/${d.getFullYear()}` : value;
          align = "center";
        } else if (["N","D","M"].includes(col.TIPODATO) && value!=null){
          align="right";
          const n = toNum(value);
          if (!isNaN(n)){
            if (col.TIPODATO==="N") formattedValue = n;
            if (col.TIPODATO==="D") formattedValue = n.toLocaleString("es-EC",{minimumFractionDigits:2,maximumFractionDigits:2});
            if (col.TIPODATO==="M") formattedValue = `<span style='float:left;'>$</span>` + n.toLocaleString("es-EC",{minimumFractionDigits:2,maximumFractionDigits:2});
            if (monedaCols.includes(v_alias)){
              const vSRI = getValidadorSRI(row);
              if (vSRI!=="T" && vSRI!=="S"){
                totales[v_alias] += n;
                totalesGenerales[v_alias] += n;
              }
            }
          }
        }

        const cellHidden = mostrarColumna(col)? "" : "display:none;";
        const tdStyle = `${cellHidden}text-align:${align};${styleEditable}`;
        tr += `<td ${editable} style="${tdStyle}" data-alias="${v_alias}" data-id="${row.ID}" data-row="${i}" data-tipodato="${col.TIPODATO}">${formattedValue}</td>`;
      });

      tableHtml += tr + `</tr>`;
    });

    const renderFilaTotales = (tot, clase)=>{
      let fila = `<tr class='${clase}'>`;
      if (p_acc_borra===1) fila += "<td></td>";
      if (p_acc_copia===1) fila += "<td></td>";
      if (showAcc)         fila += "<td></td>";
      let ic=0;
      allCols.forEach(col=>{
        const v_alias=col.ALIAS;
        const cellHidden = mostrarColumna(col)? "" : "display:none;";
        const tdStyle = `${cellHidden}text-align:right;font-weight:bold;`;
        if (monedaCols.includes(v_alias)){
          const s = tot[v_alias]||0;
          fila += `<td style='${tdStyle}'>$${s.toLocaleString("es-EC",{minimumFractionDigits:2})}</td>`;
        } else {
          fila += ic===0 ? `<td style='${tdStyle}'>TOTAL:</td>` : `<td style='${tdStyle}'></td>`;
          ic++;
        }
      });
      return fila + "</tr>";
    };

    tableHtml += renderFilaTotales(totales,"tr-total");
    tableHtml += renderFilaTotales(totalesGenerales,"tr-total-general");
    tableHtml += `</tbody></table></div></div>`;

    $("#"+regionId).html(tableHtml);
    try{ $(secDetalle).show(); }catch(_){}

    document.querySelectorAll(".btn-act").forEach(b=>{
      b.addEventListener("click", ()=>{
        const id  = b.dataset.id || "";
        const tip = b.dataset.tip || "";
        apex.navigation.redirect(`f?p=&APP_ID.:198:&SESSION.::NO::P198_ID,P198_TIPO:${id},${tip}`);
      });
    });

    setTimeout(()=>{
      const topScroll=document.getElementById('scroll-top');
      const bottomScroll=document.getElementById('scroll-bottom');
      const bottomInner=document.getElementById('scroll-bottom-inner');
      const topInner=document.getElementById('scroll-top-inner');
      if (bottomInner && topInner && topScroll && bottomScroll){
        topInner.style.width = bottomInner.scrollWidth + 'px';
        topScroll.onscroll    = ()=>{ bottomScroll.scrollLeft = topScroll.scrollLeft; };
        bottomScroll.onscroll = ()=>{ topScroll.scrollLeft  = bottomScroll.scrollLeft; };
      }
    },0);

    setTimeout(()=>{
      if (typeof freezeCols === "function"){
        freezeCols({
          incluirBorra:(p_acc_borra===1),
          incluirCopia:(p_acc_copia===1),
          incluirVer: showAcc,
          aliases:(typeof getFreeze==="function"?getFreeze(p_proceso):[])
        });
      }
      if (typeof freezeHeader === "function") freezeHeader();
    },0);

    let popup = document.getElementById("flt-popup");
    if (!popup){
      popup = document.createElement("div");
      popup.id="flt-popup"; popup.className="flt-popup"; popup.style.display="none";
      document.body.appendChild(popup);
    }

    if (!window._fltSubmitGuardsBound){
      document.addEventListener("click", (e)=>{
        if (e.target.closest(".flt-btn,.flt-clear,#flt-popup .ok,#flt-popup .cl")){
          e.preventDefault(); e.stopPropagation();
        }
      });
      document.addEventListener("keydown", (e)=>{
        if (e.key!=="Enter") return;
        if (!popup || !popup.contains(e.target)) return;
        const t = e.target;
        const commit = t.classList?.contains("flt-search") || t.classList?.contains("flt-v1") || t.classList?.contains("flt-v2");
        if (commit){ e.preventDefault(); e.stopPropagation(); popup.querySelector(".ok")?.click(); }
      });
      window._fltSubmitGuardsBound = true;
    }

    // === NUEVO: uniqueValues consciente de <ul><li> en VALIDACIONES ===
	function uniqueValues(alias){
		const rows = document.querySelectorAll('#scroll-bottom-inner tbody tr');
		const set = new Set();
		let hasEmpty = false;
		const up = String(alias||"").toUpperCase();

		rows.forEach(tr=>{
			if (tr.classList.contains('tr-total') || tr.classList.contains('tr-total-general')) return;
			if (tr.style.display === 'none') return;
			const td = tr.querySelector(`td[data-alias='${alias}']`);
			if (!td) return;

			if (up === "VALIDACIONES"){
			// usar _cellInfo para tokens
			const info = (function(){
				const $td = $(td);
				return _cellInfo($td);
			})();
			if (info.tokens.length===0) { hasEmpty = true; }
			else info.tokens.forEach(v => { if (v) set.add(v); });
			} else {
			// texto plano
			const txt = td.textContent.trim();
			if (txt==="") hasEmpty = true;
			else set.add(txt);
			}
		});

		const arr = Array.from(set).sort((a,b)=>a.localeCompare(b,'es'));
		if (hasEmpty) arr.unshift("(vacío)");
		return arr.length ? arr : ["(vacío)"];
	}


    function openPopupFor(col, tipo, anchorEl){
      if (!document.getElementById("flt-list-style")){
        const st = document.createElement("style");
        st.id = "flt-list-style";
        st.textContent = `.flt-list{display:block;max-height:260px;overflow:auto;border:1px solid #eee;padding:6px;border-radius:4px}
          .flt-list label{display:block !important;margin:2px 0;white-space:nowrap}`;
        document.head.appendChild(st);
      }

      const vals = uniqueValues(col);
      const st0  = (window._filtrosExcel||{})[col] || null;
      const isNum  = tipo==="N" || tipo==="D" || tipo==="M";
      const isDate = tipo==="F";
      const checked = v => !st0 || st0.mode!=="set" ? true : (st0.values||[]).includes(v);

      popup.innerHTML = `
        <div class="hdr">Filtrar ${col}</div>
        <table border="0" width="100%" class="row" style="display:flex;gap:21px;align-items:center">
          <tr>
            <td><input type="text" class="flt-search" placeholder="Buscar" style="flex:1"></td>
            <td><label style="font-size:12px;user-select:none;white-space:nowrap"><input type="checkbox" class="flt-all"> Todos</label></td>
          </tr>
          <tr><td class="row" colspan="2">
            ${isNum || isDate ? `
              <select style="width:100%" class="flt-op">
                <option value="set">Lista</option>
                <option value="=">=</option><option value="!=">!=</option>
                <option value=">">&gt;</option><option value=">=">&gt;=</option>
                <option value="<">&lt;</option><option value="<=">&lt;=</option>
                <option value="between">Entre</option>
                <option value="notnull">No vacíos</option>
                <option value="null">Vacíos</option>
              </select>`: ``}
          </td></tr>
          <tr><td class="row" colspan="2">
            ${isNum || isDate ? `
              <input id="v01" class="flt-v1" placeholder="${isDate?'dd/mm/aaaa':'valor'}" style="width:100%">
              <input id="v02" class="flt-v2" placeholder="${isDate?'dd/mm/aaaa':'valor'}" style="width:100%;display:none">`: ``}
          </td></tr>
        </table>
        <div class="row flt-list">
          ${vals.map(v=>`<label><input type="checkbox" class="flt-item" value="${v.replace(/"/g,"&quot;")}" ${checked(v)?'checked':''}> ${v || "(vacío)"} </label>`).join("")}
        </div>
        <div class="flt-actions">
          <button type="button" class="ok">Aplicar</button>
          <button type="button" class="cl">Limpiar</button>
        </div>
      `;

      const opSel = popup.querySelector(".flt-op");
      const v1    = popup.querySelector(".flt-v1");
      const v2    = popup.querySelector(".flt-v2");
      const list  = popup.querySelector(".flt-list");
      const srch  = popup.querySelector(".flt-search");
      const chkAll= popup.querySelector(".flt-all");
      const items = Array.from(list.querySelectorAll(".flt-item"));

      if (opSel && st0){
        opSel.value = st0.mode || "set";
        if (st0.mode==="between"){ v2.style.display="inline-block"; v1.value = st0.v1??""; v2.value = st0.v2??""; }
        else if (["=","!=","<",">","<=",">="].includes(st0.mode)){ v1.value = st0.v1??""; v2.style.display="none"; }
      }
      opSel?.addEventListener("change", ()=>{ v2.style.display = opSel.value==="between" ? "inline-block" : "none"; });

      const isVisible = lbl => lbl.style.display !== "none";
      const visibleItems = () => items.filter(i => isVisible(i.closest("label")));
      function syncChkAll(){
        const vis = visibleItems();
        const total = vis.length;
        const n = vis.filter(i => i.checked).length;
        chkAll.checked = total>0 && n===total;
        chkAll.indeterminate = n>0 && n<total;
      }
      function applyListFilter(){
        const q = srch.value.toLowerCase();
        list.querySelectorAll("label").forEach(l=>{
          const match = l.textContent.toLowerCase().includes(q);
        l.style.display = match ? "" : "none";
        });
        syncChkAll();
      }
      srch.addEventListener("input", applyListFilter);

      chkAll.addEventListener("change", ()=>{
        const vis = visibleItems();
        vis.forEach(i => { i.checked = chkAll.checked; });
        chkAll.indeterminate = false;
      });
      items.forEach(i => i.addEventListener("change", syncChkAll));
      applyListFilter();

      popup.querySelector(".ok").addEventListener("click",(e)=>{
        e.preventDefault(); e.stopPropagation();
        let newState;
        if (opSel && opSel.value!=="set"){
          newState = { mode: opSel.value, v1: v1?.value||"", v2: v2?.value||"" };
        } else if (!(isNum||isDate) && srch.value.trim()){
          newState = { mode:"contains", q: srch.value.trim() };
        } else {
          const sel = Array.from(list.querySelectorAll(".flt-item"))
            .filter(i => i.checked && isVisible(i.closest("label")))
            .map(i => i.value);
          newState = { mode:"set", values: sel };
        }
        (window._filtrosExcel = window._filtrosExcel || {})[col] = newState;

        document.querySelector(`.flt-btn[data-col='${col}']`)?.classList.add("active");
        document.querySelectorAll(`.flt-clear[data-col='${col}']`).forEach(b=>b.style.display="inline-block");

        const hidden = document.querySelector(`#scroll-bottom-inner thead .filtro-header input[data-col='${col}']`);
        if (hidden){ hidden.value = JSON.stringify(newState); $(hidden).trigger("input"); }
        closePopup();
      });

      popup.querySelector(".cl").addEventListener("click",(e)=>{
        e.preventDefault(); e.stopPropagation();
        delete (window._filtrosExcel || {})[col];
        document.querySelectorAll(`.flt-btn[data-col='${col}']`).forEach(b=>b.classList.remove("active"));
        document.querySelectorAll(`.flt-clear[data-col='${col}']`).forEach(b=>b.style.display="none");
        const hidden = document.querySelector(`#scroll-bottom-inner thead .filtro-header input[data-col='${col}']`);
        if (hidden){ hidden.value=""; $(hidden).trigger("input"); }
        closePopup();
      });

      const r = anchorEl.getBoundingClientRect();
      popup.style.left = Math.min(r.left, window.innerWidth - 260) + "px";
      popup.style.top  = (r.bottom + 4) + "px";
      popup.style.display = "block";
    }

    function closePopup(){ popup.style.display="none"; }
    document.addEventListener("click", e=>{
      if (popup.style.display==="none") return;
      if (!popup.contains(e.target) && !e.target.closest(".flt-btn")) closePopup();
    });

    document.querySelectorAll("#scroll-bottom-inner thead .flt-btn").forEach(btn=>{
      btn.setAttribute("type","button");
      btn.addEventListener("click", (e)=>{
        e.preventDefault(); e.stopPropagation();
        openPopupFor(btn.dataset.col, btn.dataset.tipo, btn);
      });
    });

    document.querySelectorAll("#scroll-bottom-inner thead .flt-clear").forEach(btn=>{
      btn.setAttribute("type","button");
      btn.addEventListener("click", (e)=>{
        e.preventDefault(); e.stopPropagation();
        const col = btn.dataset.col;
        delete filtrosExcel[col];
        btn.style.display="none";
        document.querySelector(`.flt-btn[data-col='${col}']`)?.classList.remove("active");
        const hidden = document.querySelector(`#scroll-bottom-inner thead .filtro-header input[data-col='${col}']`);
        if (hidden){ hidden.value=""; $(hidden).trigger("input"); }
      });
    });

    // === Motor de filtrado con soporte tokens VALIDACIONES ===
    const _aplica = ()=>{
      const filas = $("#scroll-bottom-inner table tbody tr");
      filas.each(function(){
        if (this.classList.contains("tr-total") || this.classList.contains("tr-total-general")) { $(this).show(); return; }
        let visible = true;

        for (const [col,state] of Object.entries(filtrosExcel)){
          if (!state) continue;
          const celda = $(this).find(`td[data-alias='${col}']`);
          if (!celda.length) continue;

          const info  = _cellInfo(celda);
          const tipo  = info.tipo;
          const texto = info.text;
          const t     = texto.toLowerCase();

          const pass = (()=>{
            if (state.mode==="notnull") return (info.tokens.some(x => x && x!=="-"));
            if (state.mode==="null")    return (!info.tokens.length || info.tokens.every(x => !x || x==="-" ));
            if (state.mode==="contains") return t.includes((state.q || "").toLowerCase());

      		if (state.mode==="set"){
				const sel = state.values || [];
				if (!sel.length) return true;

				const wantsEmpty = sel.includes("(vacío)");

				if (info.alias==="VALIDACIONES"){
					const hasAnySelected = info.tokens.some(tok => sel.includes(tok));
					const isEmpty = info.tokens.length===0;
					return hasAnySelected || (wantsEmpty && isEmpty);
				} else {
					const match = sel.includes(texto);
					const isEmpty = (texto==="" || texto==="-" );
					return match || (wantsEmpty && isEmpty);
				}
			}

            if (["N","D","M"].includes(tipo)){
              const num = toNum(texto), v1 = toNum(state.v1), v2 = toNum(state.v2);
              if (state.mode==="=")  return !isNaN(num) && !isNaN(v1) && num===v1;
              if (state.mode==="!=") return !isNaN(num) && !isNaN(v1) && num!==v1;
              if (state.mode===">")  return !isNaN(num) && !isNaN(v1) && num>v1;
              if (state.mode===">=") return !isNaN(num) && !isNaN(v1) && num>=v1;
              if (state.mode==="<")  return !isNaN(num) && !isNaN(v1) && num<v1;
              if (state.mode==="<=") return !isNaN(num) && !isNaN(v1) && num<=v1;
              if (state.mode==="between"){
                if (isNaN(num) || isNaN(v1) || isNaN(v2)) return false;
                const a = Math.min(v1,v2), b = Math.max(v1,v2); return num>=a && num<=b;
              }
            }

            if (tipo==="F"){
              const d = parseFecha(texto), a = parseFecha(state.v1), b = parseFecha(state.v2);
              if (state.mode==="between") return d && a && b && d>=a && d<=b;
              if (state.mode==="=")  return d && a && +d===+a;
              if (state.mode==="!=") return d && a && +d!==+a;
              if (state.mode===">")  return d && a && d>a;
              if (state.mode===">=") return d && a && d>=a;
              if (state.mode==="<")  return d && a && d<a;
              if (state.mode==="<=") return d && a && d<=a;
            }
            return true;
          })();

          if (!pass){ visible=false; break; }
        }
        $(this).toggle(visible);
      });

      f_recalcular_totales(monedaCols, p_proceso, allCols, p_acc_borra, p_acc_copia, showAcc);
      $(".tr-total,.tr-total-general").show();
    };

    let _rafToken = null;
    function aplicaFiltros(){
      if (_rafToken) cancelAnimationFrame(_rafToken);
      _rafToken = requestAnimationFrame(_aplica);
    }

    $(".filtro-input").off("input").on("input", function(){
      const col = ($(this).data("col")||"").toString();
      const val = $(this).val().trim();
      if (!val){ delete filtrosExcel[col]; }
      else { try { filtrosExcel[col] = JSON.parse(val); } catch {} }
      const active = !!filtrosExcel[col];
      document.querySelectorAll(`.flt-btn[data-col='${col}']`).forEach(b=>b.classList.toggle("active",active));
      document.querySelectorAll(`.flt-clear[data-col='${col}']`).forEach(b=>b.style.display = active?"inline-block":"none");
      aplicaFiltros();
    });

    allCols.forEach(col=>{
      const hid = document.querySelector(`#scroll-bottom-inner thead .filtro-header input[data-col='${col.ALIAS}']`);
      if (!hid) return;
      if (filtrosExcel[col.ALIAS]) hid.value = JSON.stringify(filtrosExcel[col.ALIAS]);
      $(hid).trigger("input");
    });

  } catch(e){
    console.error("Error al procesar:", e);
  }
}


//funcion para limpiar los filtros
//AUTOR: JOSE MASABANDA C. 15/05/2025
async function f_limpiarFiltrosTabla() {
    try {
        mostrarBarra();

        await new Promise((resolve) => {
            setTimeout(() => {
				$(".filtro-input").each(function () {
					$(this).val("");
				});
				$(".filtro-input").trigger("input");
				resolve();
            }, 0); // Esto permite que la barra se muestre antes de ejecutar f_generatabla
        });

    } catch (error) {
        console.error("Error al ejecutar f_generatabla:", error);
    } finally {
        ocultarBarra();
    }
}

//funcion obtener lso datos modificados
//AUTOR: JOSE MASABANDA C. 15/05/2025

// // Normaliza números, y FECHAS "F" a DD/MM/YYYY antes de guardar.
// function f_obtener_datos_editados() {
//   const filas = document.querySelectorAll('#scroll-bottom-inner table tbody tr');
//   const datos = [];

//   // ------- helpers -------
//   const toNumber = (s) => {
//     if (s == null) return NaN;
//     if (typeof s === "number") return Number.isFinite(s) ? s : NaN;
//     let v = String(s).trim();
//     if (!v) return NaN;
//     v = v.replace(/\s+/g, "").replace(/\$/g, "").replace(/^\((.*)\)$/, "-$1");
//     const lastDot = v.lastIndexOf("."), lastCom = v.lastIndexOf(",");
//     if (lastCom > lastDot) v = v.replace(/\./g, "").replace(/,/g, ".");
//     else v = v.replace(/,/g, "");
//     v = v.replace(/[^0-9.\-]/g, "");
//     const n = parseFloat(v);
//     return Number.isFinite(n) ? n : NaN;
//   };

//   const pad2 = (n) => String(n).padStart(2, "0");
//   const fmtDDMMYYYY = (y, m, d) => `${pad2(d)}/${pad2(m)}/${String(y)}`;

//   // ACEPTA: ISO 8601 (YYYY-MM-DDTHH:MM:SSZ), YYYY-MM-DD, YYYY/MM/DD, DD/MM/YYYY, DD-MM-YYYY, epoch ms
//   const normFecha = (raw) => {
//     if (raw == null) return "";
//     let s = String(raw).trim();
//     if (!s) return "";

//     // 1) ISO o YYYY-MM-DD al inicio
//     let m = s.match(/^(\d{4})-(\d{2})-(\d{2})/);
//     if (m) return fmtDDMMYYYY(m[1], m[2], m[3]);

//     // 2) YYYY/MM/DD
//     m = s.match(/^(\d{4})\/(\d{2})\/(\d{2})$/);
//     if (m) return fmtDDMMYYYY(m[1], m[2], m[3]);

//     // 3) DD/MM/YYYY
//     m = s.match(/^(\d{2})\/(\d{2})\/(\d{4})$/);
//     if (m) return fmtDDMMYYYY(m[3], m[2], m[1]); // ya viene bien

//     // 4) DD-MM-YYYY
//     m = s.match(/^(\d{2})-((\d{2}))-(\d{4})$/);
//     if (m) return fmtDDMMYYYY(m[3], m[2], m[1]).replace(/-/g, "/");

//     // 5) Epoch ms
//     if (/^\d{10,13}$/.test(s)) {
//       const t = parseInt(s, 10);
//       const d = new Date(t.toString().length === 10 ? t * 1000 : t);
//       if (!isNaN(d.getTime())) return fmtDDMMYYYY(d.getFullYear(), d.getMonth() + 1, d.getDate());
//     }

//     // 6) Intento con Date si trae "T" (ISO completo) u otra forma válida
//     if (/[T:Z]/.test(s) || /^\d{4}[-/]\d{2}[-/]\d{2}/.test(s)) {
//       const d = new Date(s);
//       if (!isNaN(d.getTime())) return fmtDDMMYYYY(d.getFullYear(), d.getMonth() + 1, d.getDate());
//     }

//     // Si no se pudo interpretar, devolver tal cual (usuario lo corregirá en UI)
//     return s;
//   };

//   const getCellValue = (td) => {
//     const tipo = td.getAttribute('data-tipodato'); // "M","D","N","F", etc.
//     const ctrl = td.querySelector('input, select, textarea, [contenteditable="true"]');
//     let raw = ctrl
//       ? (("value" in ctrl && ctrl.value != null) ? ctrl.value : ctrl.textContent)
//       : td.innerText;
//     raw = String(raw == null ? "" : raw).trim();

//     if (tipo === "F") return normFecha(raw);                 // <<< clave de la solicitud
//     if (tipo === "M" || tipo === "D" || tipo === "N") {
//       const n = toNumber(raw);
//       return Number.isFinite(n) ? n : "";
//     }
//     return raw.toUpperCase();
//   };

//   // ------- recorrido -------
//   filas.forEach(tr => {
//     const fila = {};
//     tr.querySelectorAll('td[data-alias]').forEach(td => {
//       const alias = td.getAttribute('data-alias');
//       fila[alias] = getCellValue(td);
//     });

//     const idAttr = tr.querySelector('td[data-id]')?.getAttribute('data-id');
//     const idPadreAttr = tr.querySelector('td[data-idpadre]')?.getAttribute('data-idpadre');
//     if (idAttr != null && idAttr !== "") fila["ID"] = parseInt(idAttr, 10);
//     if (idPadreAttr != null && idPadreAttr !== "") fila["IDPADRE"] = parseInt(idPadreAttr, 10);

//     const valores = Object.entries(fila)
//       .filter(([k]) => k !== "ID" && k !== "IDPADRE")
//       .map(([, v]) => v);

//     const vacia = valores.every(v => {
//       if (v === null) return true;
//       if (typeof v === "number") return Number.isNaN(v);
//       const s = String(v).trim();
//       return s === "" || s === "-";
//     });

//     if (!vacia && ("ID" in fila)) datos.push(fila);
//   });

//   return JSON.stringify(datos);
// }
function f_obtener_datos_editados() {
  const filas = document.querySelectorAll('#scroll-bottom-inner table tbody tr');
  const datos = [];

  // ------- helpers -------
  const cleanRaw = (s) => {
    let t = String(s ?? "").trim();
    if (t === "-" || t === "—") return "";
    return t;
  };

  const toNumber = (s) => {
    s = cleanRaw(s);
    if (!s) return NaN;
    if (typeof s === "number") return Number.isFinite(s) ? s : NaN;
    let v = s.replace(/\s+/g, "").replace(/\$/g, "").replace(/^\((.*)\)$/, "-$1");
    const lastDot = v.lastIndexOf("."), lastCom = v.lastIndexOf(",");
    if (lastCom > lastDot) v = v.replace(/\./g, "").replace(/,/g, ".");
    else v = v.replace(/,/g, "");
    v = v.replace(/[^0-9.\-]/g, "");
    const n = parseFloat(v);
    return Number.isFinite(n) ? n : NaN;
  };

  const pad2 = (n) => String(n).padStart(2, "0");
  const fmtDDMMYYYY = (y, m, d) => `${pad2(d)}/${pad2(m)}/${String(y)}`;

  const normFecha = (raw) => {
    let s = cleanRaw(raw);
    if (!s) return "";

    s = s.replace(/,\d{1,9}\s*$/,'').trim();

    let m = s.match(/^(\d{2})\/(\d{2})\/(\d{4})\b/);
    if (m) return fmtDDMMYYYY(m[3], m[2], m[1]);

    m = s.match(/^(\d{2})-(\d{2})-(\d{4})\b/);
    if (m) return fmtDDMMYYYY(m[3], m[2], m[1]);

    m = s.match(/^(\d{4})-(\d{2})-(\d{2})/);
    if (m) return fmtDDMMYYYY(m[1], m[2], m[3]);

    m = s.match(/^(\d{4})\/(\d{2})\/(\d{2})/);
    if (m) return fmtDDMMYYYY(m[1], m[2], m[3]);

    if (/^\d{10,13}$/.test(s)) {
      const t = parseInt(s, 10);
      const d = new Date(t.toString().length === 10 ? t * 1000 : t);
      if (!isNaN(d.getTime())) return fmtDDMMYYYY(d.getFullYear(), d.getMonth() + 1, d.getDate());
    }

    if (/[T:Z]/.test(s) || /^\d{4}[-/]\d{2}[-/]\d{2}/.test(s)) {
      const d = new Date(s);
      if (!isNaN(d.getTime())) return fmtDDMMYYYY(d.getFullYear(), d.getMonth() + 1, d.getDate());
    }

    return s;
  };

  const getCellValue = (td) => {
    const tipo = td.getAttribute('data-tipodato'); // "M","D","N","F", etc.
    const ctrl = td.querySelector('input, select, textarea, [contenteditable="true"]');
    let raw = ctrl
      ? (("value" in ctrl && ctrl.value != null) ? ctrl.value : ctrl.textContent)
      : td.innerText;

    raw = cleanRaw(raw);

    if (tipo === "F") return normFecha(raw);
    if (tipo === "M" || tipo === "D" || tipo === "N") {
      const n = toNumber(raw);
      return Number.isFinite(n) ? n : "";
    }
    return raw ? raw.toUpperCase() : "";
  };

  // ------- recorrido -------
  filas.forEach(tr => {
    const fila = {};
    tr.querySelectorAll('td[data-alias]').forEach(td => {
      const alias = td.getAttribute('data-alias');
      fila[alias] = getCellValue(td);
    });

    const idAttr = tr.querySelector('td[data-id]')?.getAttribute('data-id');
    const idPadreAttr = tr.querySelector('td[data-idpadre]')?.getAttribute('data-idpadre');
    if (idAttr != null && idAttr !== "") fila["ID"] = parseInt(idAttr, 10);
    if (idPadreAttr != null && idPadreAttr !== "") fila["IDPADRE"] = parseInt(idPadreAttr, 10);

    const valores = Object.entries(fila)
      .filter(([k]) => k !== "ID" && k !== "IDPADRE")
      .map(([, v]) => v);

    const vacia = valores.every(v => {
      if (v === null) return true;
      if (typeof v === "number") return Number.isNaN(v);
      const s = String(v ?? "").trim();
      return s === "";
    });

    if (!vacia && ("ID" in fila)) datos.push(fila);
  });

  return JSON.stringify(datos);
}


function f_recalcular_totales(monedaCols, p_proceso, allCols, p_acc_borra, p_acc_copia, incluirVer) {
  const table = document.querySelector('#scroll-bottom-inner table');
  if (!table) return;

  // ---------- helpers ----------
  const norm = s => (s || "").toString().trim().replace(/\s|_/g, '').toUpperCase();
  const toNum = (txt) => {
    const s0 = (txt || "").toString().trim()
      .replace(/^\((.*)\)$/, '-$1')
      .replace(/[^0-9,.\-]/g, '');
    const lastDot = s0.lastIndexOf('.'), lastCom = s0.lastIndexOf(',');
    let s = s0;
    if (lastDot > lastCom) s = s0.replace(/,/g, '');
    else if (lastCom > lastDot) s = s0.replace(/\./g, '').replace(/,/g, '.');
    else s = s0.replace(/[.,]/g, '');
    const n = parseFloat(s);
    return Number.isFinite(n) ? n : NaN;
  };

  // ---------- estructura / índices ----------
  const actionOffset =
    (p_acc_borra === 1 ? 1 : 0) +
    (p_acc_copia === 1 ? 1 : 0) +
    (incluirVer ? 1 : 0);

  // mapa alias -> índice real en la tabla (thead/tbody incluyen columnas ocultas, pero están presentes)
  const idxByAlias = {};
  allCols.forEach((c, j) => { idxByAlias[c.ALIAS] = actionOffset + j; });

  // índice de VALIDADORSRI (normalizando alias en allCols)
  const aliasSri = (allCols.find(c => norm(c.ALIAS) === 'VALIDADORSRI') || {}).ALIAS;
  const sriIdx = aliasSri ? idxByAlias[aliasSri] : -1;

  // índices de columnas moneda
  const monedaIdx = {};
  monedaCols.forEach(a => { if (a in idxByAlias) monedaIdx[a] = idxByAlias[a]; });

  // primera columna de datos visible (para poner "TOTAL:")
  const firstVisibleDataIdx =
    actionOffset +
    Math.max(0, allCols.findIndex(c => String(c.VISIBLE || 'Y').toUpperCase() !== 'N'));

  // ---------- filas a procesar ----------
  const bodyRows = Array.from(table.querySelectorAll('tbody tr'));
  const dataRows = bodyRows.filter(tr => !tr.classList.contains('tr-total') && !tr.classList.contains('tr-total-general'));
  const visibleRows = dataRows.filter(tr => tr.style.display !== 'none');

  // ---------- sumas ----------
  const sumsAll = {}, sumsVis = {};
  Object.keys(monedaIdx).forEach(a => { sumsAll[a] = 0; sumsVis[a] = 0; });

  const acum = (tr, bucket) => {
    // regla: no sumar si VALIDADORSRI es "T" o "S"
    const sriVal = sriIdx >= 0 ? norm(tr.children[sriIdx]?.textContent) : '';
    if (sriVal === 'T' || sriVal === 'S') return;

    for (const [alias, idx] of Object.entries(monedaIdx)) {
      const td = tr.children[idx];
      if (!td) continue;
      const n = toNum(td.textContent);
      if (Number.isFinite(n)) bucket[alias] += n;
    }
  };

  dataRows.forEach(tr => acum(tr, sumsAll));
  visibleRows.forEach(tr => acum(tr, sumsVis));

  // ---------- actualizar filas de total en su columna exacta ----------
  const trTot = table.querySelector('tbody tr.tr-total');
  const trGen = table.querySelector('tbody tr.tr-total-general');

  const renderTotalsIntoRow = (tr, sums) => {
    if (!tr) return;
    const tds = tr.children;
    // limpia todo
    for (let i = 0; i < tds.length; i++) {
      tds[i].innerHTML = '';
      tds[i].style.textAlign = 'right';
    }
    // etiqueta TOTAL
    if (tds[firstVisibleDataIdx]) {
      tds[firstVisibleDataIdx].style.textAlign = 'left';
      tds[firstVisibleDataIdx].innerHTML = 'TOTAL:';
    }
    // números en su propia columna
    for (const [alias, idx] of Object.entries(monedaIdx)) {
      const td = tds[idx];
      if (!td) continue;
      const s = sums[alias] || 0;
      td.innerHTML = `$${s.toLocaleString('es-EC', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
      td.style.textAlign = 'right';
    }
  };

  renderTotalsIntoRow(trTot, sumsVis);   // total filtrado
  renderTotalsIntoRow(trGen, sumsAll);   // total general

  // asegúrate que estén visibles
  if (trTot) trTot.style.display = '';
  if (trGen) trGen.style.display = '';
}


//funcion inmoviliza los encabezados de las columnas
// AUTOR: JOSE MASABANDA C. 15/05/2025
function freezeHeader() {
  const table = document.querySelector("#scroll-bottom-inner table");
  if (!table) return;
  const rows = table.querySelectorAll("thead tr");
  if (!rows.length) return;

  const hdr = rows[0];
  const h = hdr.getBoundingClientRect().height || hdr.offsetHeight || 0;

  // fila encabezado
  hdr.querySelectorAll("th").forEach(th => {
    th.style.position = "sticky";
    th.style.top = "0px";
    th.style.zIndex = "50";           // por encima de columnas congeladas
    th.style.background = "#e9edee";
    th.style.border = "1px solid #000";
  });

  // fila filtros
  const filt = rows[1];
  if (filt) {
    filt.querySelectorAll("th").forEach(th => {
      th.style.position = "sticky";
      th.style.top = h + "px";
      th.style.zIndex = "49";
      th.style.background = "#e9edee";
      th.style.border = "1px solid #000";
    });
  }
}

//funcion inmoviliza las columnas
// AUTOR: JOSE MASABANDA C. 15/05/2025
function freezeCols({ aliases = [], incluirBorra = false, incluirCopia = false, incluirVer = false } = {}) {
  const table = document.querySelector("#scroll-bottom-inner table");
  if (!table) return;

  // limpia solo left/zIndex/position de columnas
  table.querySelectorAll("th,td").forEach(c => {
    c.style.left = "";
    c.style.zIndex = "";
    c.style.position = c.style.position === "sticky" ? "sticky" : "";
  });

  const idxs = [];
  const headRow = table.tHead?.rows[0] || table.rows[0];
  const firstBodyRow = table.tBodies[0]?.rows[0];

  const getCellWidth = (i) => {
    const hc = headRow?.cells[i];
    const bc = firstBodyRow?.cells[i];
    return (hc?.getBoundingClientRect().width || hc?.offsetWidth || bc?.getBoundingClientRect()?.width || bc?.offsetWidth || 0);
  };

  // columnas de acciones al inicio, en orden: borrar -> copiar -> ver
  let nextIdx = 0;
  // acciones
  if (incluirBorra) {
    idxs.push({ idx: nextIdx, width: getCellWidth(nextIdx) });
    nextIdx++;
  }
  if (incluirCopia) {
    idxs.push({ idx: nextIdx, width: getCellWidth(nextIdx) });
    nextIdx++;
  }
  if (incluirVer) {
    idxs.push({ idx: nextIdx, width: getCellWidth(nextIdx) });
    nextIdx++;
  }

  // por alias → índice
  const colIndexByAlias = a => {
    const td = table.querySelector(`tbody td[data-alias='${a}']`);
    if (!td) return -1;
    let i = 0; for (let c of td.parentElement.children) { if (c === td) break; i++; }
    return i;
  };
  try {
    aliases.forEach(a => {
      const i = colIndexByAlias(a);
      if (i >= 0) {
        idxs.push({ idx: i, width: getCellWidth(i) });
      }
    });

  } catch {}


  idxs.sort((a,b)=>a.idx-b.idx);

  const allRows = table.querySelectorAll("thead tr, tbody tr");
  let offset = 0;
  idxs.forEach(info => {
    const left = offset;
    allRows.forEach(tr => {
      const cell = tr.children[info.idx];
      if (!cell) return;
      const isHead = tr.parentElement.tagName === "THEAD";
      cell.style.position = "sticky";
      cell.style.left = left + "px";
      cell.style.zIndex = isHead ? "40" : "30";// debajo del header (50/49)
      cell.style.background = "#e9edee";
      cell.style.border = "1px solid #000";
    });
    offset += info.width;
  });
}

//funcion indica que columnas por proceso se frezean
// AUTOR: JOSE MASABANDA C. 15/05/2025
function getFreeze(p_proceso){
  if (p_proceso==="002"){ // VENTAS
    return ["NDOC","N_DOC"];
  }
  if (p_proceso==="003"){ // RETENCIONES
    return ["RANGO_NO_SIG_1","NUM_DOCUMENTO"];
  }
  if (p_proceso==="004"){ // COMPRAS
    return ["NDOC","N_DOC"];
  }
  if (p_proceso==="006"){ // ICE
    return ["NDOC","N_DOC"];
  }
  if (p_proceso==="005"){ // SENAE
    return ["NDOC","N_DOC"];
  }
  if (p_proceso==="007"){ // RETENCIONES CLIENTES
    return ["TIPO_COMPROBANTE","SERIE_COMPROBANTE","NO_DOCUMENTO"];
  }
  return " ";
}

//funcion formatear fecha
//AUTOR: JOSE MASABANDA C. 15/05/2025
function parseFechaFormat(cadena) {
    let partes = cadena.split("/");
    if (partes.length === 3) {
        return new Date(`${partes[2]}-${partes[1]}-${partes[0]}`);
    } else {
        return null;
    }
}
//funcion capitalizar las cadenas
//AUTOR: JOSE MASABANDA C. 15/05/2025
function f_capitalizarCadena(cadena) {
    // Si la cadena es como "C11301_01" → "11301.01"
    if (/^C\d{5,}_\d{2}$/.test(cadena)) {
        return cadena.replace(/^C/, "").replace("_", ".");
    }

    return cadena
        .toLowerCase()
        .replace(/_/g, " ")
        .split(/\s+/)
        .map((palabra, index, arr) => {
            if (["de", "la"].includes(palabra) && index !== 0 && index !== arr.length - 1) {
                return palabra;
            }
            return palabra.charAt(0).toUpperCase() + palabra.slice(1);
        })
        .join(" ");
}


//funcion obtener la estructura de un json
//AUTOR: JOSE MASABANDA C. 15/05/2025
function getJsonStructure(jsonArray) {
    if (!Array.isArray(jsonArray) || jsonArray.length === 0) {
        return "El JSON proporcionado no es un array v�lido.";
    }
    let structure = {};
    // Toma el primer objeto y extrae solo las claves
    Object.keys(jsonArray[0]).forEach(key => {
        structure[key] = "";
    });
    return structure;
}


// Exporta solo columnas visibles según columnasJson y tipa cada celda por TIPODATO
function exportTabla2Xlsx(nombre, regionId, hoja, columnasJson) {
  if (!window.XLSX) return;
console.log("nombre:"+nombre+",regionId:"+regionId+",hoja:"+hoja+",columnasJson:"+columnasJson);
  // --- util: sanitiza nombres ---
  const clean = s => String(s || "")
    .replace(/[\/\\:*?"<>|]+/g, "_")
    .replace(/\s+/g, "_")
    .replace(/_+/g, "_")
    .replace(/^_+|_+$/g, "");

  nombre = clean(nombre);
  hoja   = clean(hoja || "Hoja1");

  // --- parse columnas ---
  let colsCfg = [];
  try {
    colsCfg = typeof columnasJson === "string" ? JSON.parse(columnasJson) : (columnasJson || []);
  } catch (e) { colsCfg = []; }

  // Solo visibles, mantén el orden dado. Normaliza alias sin comillas.
  const visibles = colsCfg
    .filter(c => String(c.VISIBLE || "Y").toUpperCase() === "Y")
    .map(c => ({
      ALIAS: String(c.ALIAS || "").replace(/"/g, "").toUpperCase(),
      ETIQUETA: c.ETIQUETA || c.ALIAS || "",
      TIPODATO: String(c.TIPODATO || "").toUpperCase()
    }));

  if (!visibles.length) return;

  // --- helpers de conversión ---
  function toNumberGeneral(v) {
    if (v == null) return null;
    let s = String(v).trim();
    if (!s) return null;
    // negativos con paréntesis
    s = s.replace(/^\((.*)\)$/, "-$1");
    // quita símbolos no numéricos
    s = s.replace(/[^0-9.,\-]/g, "");
    // decide decimal por el último separador
    const lastDot = s.lastIndexOf(".");
    const lastCom = s.lastIndexOf(",");
    let dec = null;
    if (lastDot > lastCom) dec = ".";
    else if (lastCom > lastDot) dec = ",";
    // normaliza miles y decimal a punto
    if (dec === ".") s = s.replace(/,/g, "");
    else if (dec === ",") { s = s.replace(/\./g, ""); s = s.replace(/,/g, "."); }
    else s = s.replace(/[.,]/g, "");
    const n = parseFloat(s);
    return Number.isFinite(n) ? n : null;
  }

  function toCurrency(v) {
    const n = toNumberGeneral(v);
    return n;
  }

  function toPercent(v) {
    if (v == null) return null;
    let s = String(v).trim();
    const hasPct = /%/.test(s);
    const n = toNumberGeneral(s);
    if (n == null) return null;
    // Convención: si trae % → divide por 100. Si no trae % y n>1, asume 3 => 0.03
    return hasPct ? n / 100 : (n > 1 ? n / 100 : n);
  }

  function toDateVal(v) {
    if (!v) return null;
    const s = String(v).trim();
    // dd/mm/yyyy o dd-mm-yyyy
    let m = s.match(/^(\d{1,2})[\/\-](\d{1,2})[\/\-](\d{4})$/);
    if (m) {
      const d = parseInt(m[1], 10);
      const mo = parseInt(m[2], 10) - 1;
      const y = parseInt(m[3], 10);
      const dt = new Date(y, mo, d);
      return isNaN(dt.getTime()) ? null : dt;
    }
    // yyyy-mm-dd
    m = s.match(/^(\d{4})[\/\-](\d{1,2})[\/\-](\d{1,2})$/);
    if (m) {
      const y = parseInt(m[1], 10);
      const mo = parseInt(m[2], 10) - 1;
      const d = parseInt(m[3], 10);
      const dt = new Date(y, mo, d);
      return isNaN(dt.getTime()) ? null : dt;
    }
    const dt = new Date(s);
    return isNaN(dt.getTime()) ? null : dt;
  }

  // --- toma filas del DOM y arma AOA en el orden de columnas visibles ---
  const region = document.getElementById(regionId);
  if (!region) return;

  const rows = region.querySelectorAll("tbody tr");
  if (!rows.length) return;

  // Cabeceras
  const header = visibles.map(c => String(c.ETIQUETA || c.ALIAS).replace(/"/g, "").trim());

  // Extrae valor por alias usando td[data-alias="ALIAS"]
  function getCellText(tr, alias) {
    const td = tr.querySelector(`td[data-alias='${alias}']`);
    if (!td) return "";
    return td.textContent.trim();
  }

  const aoaRaw = [header];
  const typesByCol = visibles.map(c => c.TIPODATO); // paralelo a visibles

  for (const tr of rows) {
    // Si quieres exportar solo filas visibles en pantalla, descomenta:
    // const st = window.getComputedStyle(tr);
    // if (st.display === "none" || st.visibility === "hidden") continue;

    const row = visibles.map(c => getCellText(tr, c.ALIAS));
    aoaRaw.push(row);
  }

  // Convierte según TIPODATO para que XLSX asigne tipos correctos
  const aoaVal = aoaRaw.map((r, i) => {
    if (i === 0) return r; // encabezados
    return r.map((v, j) => {
      const t = typesByCol[j];
      if (t === "N") {
        const n = toNumberGeneral(v);
        return n == null ? null : n;
      } else if (t === "M") {
        const n = toCurrency(v);
        return n == null ? null : n;
      } else if (t === "P") {
        const n = toPercent(v);
        return n == null ? null : n; // Excel lo verá como número; aplicamos formato %
      } else if (t === "F") {
        const d = toDateVal(v);
        return d || v; // si no parsea, queda texto original
      }
      return String(v ?? "");
    });
  });

  // Crea hoja
  const ws = XLSX.utils.aoa_to_sheet(aoaVal, { cellDates: true });

  // Aplica formatos z por TIPODATO
  if (ws["!ref"]) {
    const range = XLSX.utils.decode_range(ws["!ref"]);
    for (let c = range.s.c; c <= range.e.c; c++) {
      const tip = typesByCol[c];
      for (let r = range.s.r + 1; r <= range.e.r; r++) { // salta encabezado
        const addr = XLSX.utils.encode_cell({ r, c });
        const cell = ws[addr];
        if (!cell || cell.v == null) continue;

        if (tip === "M") {
          cell.t = "n";
          cell.z = '"$"#,##0.00';
        } else if (tip === "N") {
          cell.t = "n";
          // entero si no tiene decimales
          if (typeof cell.v === "number" && Number.isInteger(cell.v)) cell.z = "0";
          else cell.z = "#,##0.00";
        } else if (tip === "P") {
          cell.t = "n";
          cell.z = "0.00%";
        } else if (tip === "F") {
          // Si es Date real, márcalo; si no, queda texto
          if (cell.v instanceof Date) {
            cell.t = "d";
            cell.z = "dd/mm/yyyy";
          }
        } else {
          cell.t = "s";
        }
      }
    }
  }

  // Auto ancho simple
  const widths = header.map((h, idx) => {
    const maxLen = Math.max(
      h.length,
      ...aoaRaw.slice(1).map(r => String(r[idx] ?? "").length)
    );
    return { wch: Math.min(Math.max(10, maxLen + 2), 50) };
  });
  ws["!cols"] = widths;

  // Libro y guardar
  const wb = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(wb, ws, hoja);
  XLSX.writeFile(wb, nombre + ".xlsx");
}


//funcion obtener en consolala hora y fecha actual
//AUTOR: JOSE MASABANDA C. 15/05/2025
function obtenerFechaHoraActual() {
    const ahora = new Date();

    const dia = String(ahora.getDate()).padStart(2, '0');
    const mes = String(ahora.getMonth() + 1).padStart(2, '0'); // enero = 0
    const anio = ahora.getFullYear();

    const horas = String(ahora.getHours()).padStart(2, '0');
    const minutos = String(ahora.getMinutes()).padStart(2, '0');
    const segundos = String(ahora.getSeconds()).padStart(2, '0');

    return `${dia}/${mes}/${anio} ${horas}:${minutos}:${segundos}`;
}

function alertaWarn(msg, autoClose = true, ms = 2000) {
  const WRAP_ID = "APEX_WARNING_MESSAGE";
  const ALERT_ID = "t_Alert_Warn";

  // limpiar anterior
  $("#" + WRAP_ID).remove();

  // insertar
  $("body").prepend(
    '<span id="' + WRAP_ID + '" class="apex-page-warning">' +
      '<div class="t-Body-alert">' +
        '<div class="t-Alert t-Alert--defaultIcons t-Alert--horizontal t-Alert--page t-Alert--colorBG" ' +
             'id="' + ALERT_ID + '" role="alert" style="display:none;background-color:#FFA000;">' +
          '<div class="t-Alert-wrap">' +
            '<div class="t-Alert-icon">' +
              '<span class="fa fa-exclamation-triangle" style="color:#fff;font-size:24px;"></span>' +
            '</div>' +
            '<div class="t-Alert-content">' +
              '<div class="t-Alert-header"><h2 class="t-Alert-title">' + (msg || "") + '</h2></div>' +
            '</div>' +
            '<div class="t-Alert-buttons">' +
              '<button class="t-Button t-Button--noUI t-Button--icon t-Button--closeAlert" type="button" title="Close">' +
                '<span class="t-Icon icon-close"></span>' +
              '</button>' +
            '</div>' +
          '</div>' +
        '</div>' +
      '</div>' +
    '</span>'
  );

  // cerrar manual
  $("#" + ALERT_ID + " .t-Button--closeAlert").on("click", function () {
    $("#" + WRAP_ID).remove();
  });

  // mostrar y autocerrar
  const $al = $("#" + ALERT_ID).fadeIn(200);
  if (autoClose) {
    $al.delay(ms).fadeOut(300, function () { $("#" + WRAP_ID).remove(); });
  }
}
