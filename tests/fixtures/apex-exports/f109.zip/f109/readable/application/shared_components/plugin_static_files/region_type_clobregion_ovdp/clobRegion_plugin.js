(function(parent, $, undefined){
    
	// check if not initialized yet
    if (parent.clobRegionPlugin === undefined) {

        parent.clobRegionPlugin = function () {

		   /**
			* pSetting = {
				item : the region item
				ajaxIdentifier : ajaxIdentifier of the plugin
				pageItemsToSubmit : page items that have to be submitted
			  }
			*/
			function init ( pSettings ) {
				var regionSelector      = '#'+pSettings.item
				  , region$             = $(regionSelector)
				  , ajaxIdentifier    = pSettings.ajaxIdentifier
				  , pageItemsToSubmit = pSettings.pageItemsToSubmit
				
				// bind apexrefresh event handler				
				region$.on( 'apexrefresh', function (e){
					apex.debug.log('Refresh ClobRegion')
					var options = {
						event             : e,
						ajaxIdentifier    : ajaxIdentifier,
						pageItemsToSubmit : pageItemsToSubmit
					}
					refreshClobReportAjax( options )
				})
			}
			
			
			function refreshClobReportAjax ( options ){
				var target$ = $(options.event.target)
				
				var pAjaxIdentifier = options.ajaxIdentifier
				  , pData = { pageItems: options.pageItemsToSubmit }
				  , pOptions = { refreshObject : target$, loadingIndicator : target$, loadingIndicatorPosition : 'centered', dataType : 'html' }
				
				var promise = apex.server.plugin( pAjaxIdentifier, pData, pOptions )
				
				promise.done(function(pData){
					target$.find( '.contentContainer' ).html( pData )
				})				
			}
			
			// return public interface
			return {init : init};
		}();
    }
	
})(window, apex.jQuery)